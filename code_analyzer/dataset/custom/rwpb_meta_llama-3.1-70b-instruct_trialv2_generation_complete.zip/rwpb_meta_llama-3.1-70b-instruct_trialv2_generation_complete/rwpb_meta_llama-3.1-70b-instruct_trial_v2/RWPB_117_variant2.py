
def path_spliter(path: str):
    def path_spliter(path: str):
        components = []
        while True:
            head, tail = os.path.split(path)
            if tail:
                components.append(tail)
                path = head
            else:
                if head:
                    components.append(head)
                break
        return list(reversed(components))
