
def psnr_to_mse(psnr):
    import math
    def psnr_to_mse(psnr):
        return math.exp(-0.1 * math.log10(psnr))
