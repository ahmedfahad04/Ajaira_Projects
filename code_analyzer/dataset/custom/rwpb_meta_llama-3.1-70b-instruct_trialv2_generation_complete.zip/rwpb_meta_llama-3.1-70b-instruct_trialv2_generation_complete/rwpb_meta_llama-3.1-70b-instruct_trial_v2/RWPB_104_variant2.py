
def mulMod(x, y, z):
    def mulMod(x, y, z):
        result = 0
        while y > 0:
            if y % 2 == 1:
                result = (result + x) % z
            x = (x * 2) % z
            y //= 2
        return result
