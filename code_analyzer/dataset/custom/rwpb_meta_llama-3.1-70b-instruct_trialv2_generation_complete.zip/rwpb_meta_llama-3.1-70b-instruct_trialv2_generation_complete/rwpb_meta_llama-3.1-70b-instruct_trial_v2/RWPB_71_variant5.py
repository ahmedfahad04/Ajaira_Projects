
def getLambertCoefs(numOfLambertCoefs):
    from math import factorial
    def getLambertCoefs(numOfLambertCoefs):
        def iterative_lambert():
            fact = 1
            for i in range(1, numOfLambertCoefs + 1):
                fact *= i
                coef = (fact * (i + 1) - 1) // i
                yield coef
        return list(iterative_lambert())
