
def parity(cycles):
    def parity(cycles):
        total_transpositions = 0
        for cycle in cycles:
            total_transpositions += len(cycle) - 1
        return total_transpositions & 1
