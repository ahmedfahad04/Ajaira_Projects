
def make_even_first_dim(tensor):
    def make_even_first_dim(tensor):
        return tensor[:tensor.shape[0] // 2 * 2]
