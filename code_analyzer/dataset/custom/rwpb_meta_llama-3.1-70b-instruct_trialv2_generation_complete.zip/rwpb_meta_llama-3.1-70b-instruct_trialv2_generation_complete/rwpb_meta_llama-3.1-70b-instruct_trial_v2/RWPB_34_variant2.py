
def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
    def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
        if len(tokens.shape) == 1:
            tokens = tokens[np.newaxis, :]
        batch_size, sequence_length = tokens.shape
        padded_tokens = np.full((batch_size, context_window + 1), pad_token)
        for i in range(batch_size):
            padded_tokens[i, :min(sequence_length, context_window + 1)] = tokens[i, :min(sequence_length, context_window + 1)]
        return padded_tokens
