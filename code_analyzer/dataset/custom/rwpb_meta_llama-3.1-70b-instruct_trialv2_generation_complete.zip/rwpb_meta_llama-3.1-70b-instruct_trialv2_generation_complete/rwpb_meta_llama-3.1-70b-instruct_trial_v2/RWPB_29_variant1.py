
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        if ignore is not None:
            preds = preds[labels != ignore]
            labels = labels[labels != ignore]
        intersection = (preds * labels).sum()
        union = preds.sum() + labels.sum() - intersection
        if union == 0:
            return EMPTY * 100
        iou = intersection / union
        if per_image:
            iou = iou * 100
        else:
            iou = (iou * 100).mean()
        return iou
