
def round_nearest_multiple(number, a, direction='standard'):
    def round_nearest_multiple(number, a, direction='standard'):
        remainder = number % a
        if direction == 'standard':
            if remainder >= a / 2:
                return number + (a - remainder)
            else:
                return number - remainder
        elif direction == 'down':
            return number - remainder
        elif direction == 'up':
            return number + (a - remainder)
        else:
            raise ValueError("Invalid direction")
