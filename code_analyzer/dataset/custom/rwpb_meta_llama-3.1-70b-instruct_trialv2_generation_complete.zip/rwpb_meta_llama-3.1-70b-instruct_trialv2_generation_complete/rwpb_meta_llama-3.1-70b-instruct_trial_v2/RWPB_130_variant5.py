
def bbox_ioa(box1, box2, iou=False, eps=1e-7):
    import numpy as np
    def bbox_ioa(box1, box2, iou=False, eps=1e-7):
        def _area(box):
            return np.prod(np.split(box, 2, axis=1), axis=0)
        inter_x1 = np.maximum(box1[:, :2], box2[:, :2])
        inter_x2 = np.minimum(box1[:, 2:], box2[:, 2:])
        inter_area = _area(np.concatenate([inter_x1, inter_x2], axis=1))
        box2_area = _area(box2)
        if iou:
            box1_area = _area(box1)
            union_area = box1_area[:, None] + box2_area[None, :] - inter_area
            return inter_area / (union_area + eps)
        else:
            return inter_area / (box2_area + eps)
