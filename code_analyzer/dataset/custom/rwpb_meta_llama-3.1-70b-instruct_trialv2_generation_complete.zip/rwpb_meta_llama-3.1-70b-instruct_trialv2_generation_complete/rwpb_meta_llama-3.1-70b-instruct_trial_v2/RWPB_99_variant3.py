
def focal2fov(focal, pixels):
    import math
    def focal2fov(focal, pixels):
        if focal == 0:
            raise KeyError("Focal length cannot be zero")
        sensor_size = pixels / focal
        return 2 * math.atan(sensor_size / 2)
