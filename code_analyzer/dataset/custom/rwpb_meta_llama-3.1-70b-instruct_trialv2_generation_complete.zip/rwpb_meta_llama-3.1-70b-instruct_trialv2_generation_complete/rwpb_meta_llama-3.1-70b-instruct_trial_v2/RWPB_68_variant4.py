
def last_before(val, arr):
    def last_before(val, arr):
        low, high = 0, len(arr) - 1
        while low <= high:
            mid = (low + high) // 2
            if arr[mid] <= val:
                if mid == len(arr) - 1 or arr[mid + 1] > val:
                    return mid
                else:
                    low = mid + 1
            else:
                high = mid - 1
        return -1
