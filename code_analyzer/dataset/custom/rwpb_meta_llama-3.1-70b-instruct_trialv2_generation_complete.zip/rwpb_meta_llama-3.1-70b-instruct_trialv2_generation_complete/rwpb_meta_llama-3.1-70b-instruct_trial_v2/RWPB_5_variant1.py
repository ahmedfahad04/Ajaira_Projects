
def seconds_to_hh_mm_ss(seconds):
    def seconds_to_hh_mm_ss(seconds):
        if seconds < 0:
            return "00:00:00"
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        seconds = seconds % 60
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
