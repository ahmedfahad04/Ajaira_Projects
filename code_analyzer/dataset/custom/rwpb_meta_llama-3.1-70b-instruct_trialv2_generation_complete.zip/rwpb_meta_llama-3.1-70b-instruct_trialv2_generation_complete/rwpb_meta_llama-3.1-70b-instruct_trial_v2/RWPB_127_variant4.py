
def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
    def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
        if src_dim < 0:
            src_dim = x.dim() + src_dim
        if dest_dim < 0:
            dest_dim = x.dim() + dest_dim
        result = x.transpose(src_dim, dest_dim)
        dims = list(range(x.dim()))
        dims.remove(dest_dim)
        dims.insert(dest_dim, src_dim)
        result = result.permute(*dims)
        if make_contiguous:
            result = result.contiguous()
        return result
