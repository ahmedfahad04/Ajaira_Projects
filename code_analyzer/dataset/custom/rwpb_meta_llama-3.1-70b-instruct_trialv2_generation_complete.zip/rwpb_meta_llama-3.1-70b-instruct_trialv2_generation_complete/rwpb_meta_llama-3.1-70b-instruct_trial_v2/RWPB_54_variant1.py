
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        x, y, x1, y1 = box
        cx, cy = (x + x1) / 2, (y + y1) / 2
        w, h = x1 - x, y1 - y
        new_w, new_h = w * expand, h * expand
        new_x, new_y = cx - new_w / 2, cy - new_h / 2
        new_x1, new_y1 = cx + new_w / 2, cy + new_h / 2
        s = (new_w + new_h) / 4
        return [new_x, new_y, new_x1, new_y1], s
