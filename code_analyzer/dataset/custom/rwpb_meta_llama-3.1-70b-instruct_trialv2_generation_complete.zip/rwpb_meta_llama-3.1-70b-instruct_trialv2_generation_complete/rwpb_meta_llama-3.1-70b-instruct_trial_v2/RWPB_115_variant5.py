
def compute_tri_normal(geometry, tris):
    def compute_tri_normal(geometry, tris):
        batch_size, num_points, _ = geometry.shape
        num_tris, _ = tris.shape
        # Get the vertex indices for each triangle
        v0 = geometry.gather(1, tris[:, 0].view(1, -1, 1).repeat(batch_size, 1, 3))
        v1 = geometry.gather(1, tris[:, 1].view(1, -1, 1).repeat(batch_size, 1, 3))
        v2 = geometry.gather(1, tris[:, 2].view(1, -1, 1).repeat(batch_size, 1, 3))
        # Compute the normal vectors
        normals = torch.cross(v1 - v0, v2 - v0, dim=2)
        normals = normals / torch.norm(normals, dim=2, keepdim=True)
        return normals
