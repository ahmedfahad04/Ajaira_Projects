
def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        if upcast:
            x = x.float()
            weight = weight.float()
            bias = bias.float() if bias is not None else None
            residual = residual.float() if residual is not None else None
        mean = x.mean(dim=-1, keepdim=True)
        std = x.std(dim=-1, keepdim=True)
        normalized = (x - mean) / (std + eps)
        output = normalized * weight
        if bias is not None:
            output = output + bias
        if residual is not None:
            output = output + residual
        if prenorm:
            return output, x
        else:
            return output
