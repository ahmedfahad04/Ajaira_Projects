
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        result = {}
        def helper(curr_dict, curr_key):
            for key, value in curr_dict.items():
                new_key = f"{curr_key}{sep}{key}" if curr_key else key
                if isinstance(value, dict):
                    helper(value, new_key)
                else:
                    result[new_key] = value
        helper(d, parent_key)
        return result
