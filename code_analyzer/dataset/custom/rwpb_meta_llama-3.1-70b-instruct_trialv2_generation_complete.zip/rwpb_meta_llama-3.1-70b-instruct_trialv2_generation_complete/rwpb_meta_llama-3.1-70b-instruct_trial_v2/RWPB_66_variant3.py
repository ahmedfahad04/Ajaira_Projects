
def focal_length_to_fovy(focal_length, sensor_height):
    import numpy as np
    def focal_length_to_fovy(focal_length, sensor_height):
        return 2 * np.arctan(sensor_height / (2 * focal_length))
