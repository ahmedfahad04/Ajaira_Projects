
def rot_trans_geo(geometry, rot, trans):
    def rot_trans_geo(geometry, rot, trans):
        result = []
        for i in range(geometry.shape[0]):
            result.append(torch.matmul(geometry[i], rot[i]) + trans[i])
        return torch.stack(result)
