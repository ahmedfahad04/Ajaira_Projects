
def interleave(tensor1, tensor2):
    def interleave(tensor1, tensor2):
        result1 = torch.empty((len(tensor1) + len(tensor2),), dtype=tensor1.dtype)
        result2 = torch.empty((len(tensor1) + len(tensor2),), dtype=tensor1.dtype)
        result1[::2] = tensor1
        result1[1::2] = tensor2
        result2[::2] = tensor2
        result2[1::2] = tensor1
        return result1, result2
