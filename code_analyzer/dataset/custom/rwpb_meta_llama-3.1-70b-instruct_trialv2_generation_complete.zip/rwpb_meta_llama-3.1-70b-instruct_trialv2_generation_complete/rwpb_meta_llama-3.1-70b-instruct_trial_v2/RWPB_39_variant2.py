
def clean_html(:
    import re
    from bs4 import BeautifulSoup
    from typing import List
    def clean_html(html_to_clean: str, tags_to_remove: List[str] = ["style", "svg", "script"], attributes_to_keep: List[str] = ["id", "href"]) -> str:
        soup = BeautifulSoup(html_to_clean, 'html.parser')
        for tag in soup.find_all(True):
            if tag.name in tags_to_remove:
                tag.decompose()
            else:
                for attr in list(tag.attrs.keys()):
                    if attr not in attributes_to_keep:
                        del tag.attrs[attr]
        return str(soup)
