
def submatrix(matrix, col):
    def submatrix(matrix, col):
        return list(map(lambda row: row[:col] + row[col+1:], matrix))
