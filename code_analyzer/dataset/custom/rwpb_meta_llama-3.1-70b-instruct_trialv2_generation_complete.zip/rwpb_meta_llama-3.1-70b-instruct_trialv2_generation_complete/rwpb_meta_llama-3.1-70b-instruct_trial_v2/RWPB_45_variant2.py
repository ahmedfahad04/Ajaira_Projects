
def invalid_to_zeros(arr, valid_mask, ndim=999):
    import torch
    def invalid_to_zeros(arr, valid_mask, ndim=999):
        arr = arr.clone()
        arr.masked_fill_(~valid_mask, 0)
        if ndim != 999 and arr.ndim > ndim:
            arr = arr.flatten(end_dim=ndim-1)
        if valid_mask is not None:
            nnz = valid_mask.nonzero(as_tuple=False).shape[0]
        else:
            nnz = arr.shape[0]
        return arr, nnz
