
def round_nearest_multiple(number, a, direction='standard'):
    def round_nearest_multiple(number, a, direction='standard'):
        if direction == 'standard':
            return round(number / a) * a
        elif direction == 'down':
            return int(number / a) * a
        elif direction == 'up':
            return int(number / a + 1) * a
        else:
            raise ValueError("Invalid direction")
