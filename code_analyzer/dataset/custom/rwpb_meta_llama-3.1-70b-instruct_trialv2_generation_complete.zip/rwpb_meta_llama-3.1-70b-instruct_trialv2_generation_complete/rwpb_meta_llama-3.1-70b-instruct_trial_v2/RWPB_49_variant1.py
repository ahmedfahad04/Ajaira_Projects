
def make_even_first_dim(tensor):
    def make_even_first_dim(tensor):
        if tensor.shape[0] % 2 != 0:
            return tensor[:-1]
        return tensor
