
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    import itertools
    def generate_grids(lower_limit, upper_limit, grid_size):
        num_dims = len(lower_limit)
        steps = [(upper_limit[i] - lower_limit[i]) / grid_size[i] for i in range(num_dims)]
        lower_bounds = []
        upper_bounds = []
        for indices in itertools.product(*[range(grid_size[i]) for i in range(num_dims)]):
            lower_bound = torch.tensor([lower_limit[i] + indices[i] * steps[i] for i in range(num_dims)])
            upper_bound = torch.tensor([lower_bound[i] + steps[i] for i in range(num_dims)])
            lower_bounds.append(lower_bound)
            upper_bounds.append(upper_bound)
        lower_bounds = torch.stack(lower_bounds)
        upper_bounds = torch.stack(upper_bounds)
        return lower_bounds, upper_bounds
