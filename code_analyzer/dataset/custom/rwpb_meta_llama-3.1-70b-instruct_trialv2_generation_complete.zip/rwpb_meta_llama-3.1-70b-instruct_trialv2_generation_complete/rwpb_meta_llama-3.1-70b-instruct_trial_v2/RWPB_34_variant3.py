
def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
    def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
        if len(tokens.shape) == 1:
            tokens = tokens[np.newaxis, :]
        batch_size, sequence_length = tokens.shape
        padded_tokens = np.zeros((batch_size, context_window + 1), dtype=tokens.dtype)
        padded_tokens.fill(pad_token)
        for i in range(batch_size):
            trunc_length = min(sequence_length, context_window + 1)
            padded_tokens[i, :trunc_length] = tokens[i, :trunc_length]
        return padded_tokens
