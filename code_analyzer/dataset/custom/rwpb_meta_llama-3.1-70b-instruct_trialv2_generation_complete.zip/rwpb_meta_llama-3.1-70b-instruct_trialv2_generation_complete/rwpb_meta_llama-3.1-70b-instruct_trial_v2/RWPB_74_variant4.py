
def arccos2(vector, value):
    import numpy as np
    def arccos2(vector, value):
        if vector[0] >= 0 and vector[1] >= 0:
            angle = np.arccos(value)
        elif vector[0] < 0 and vector[1] >= 0:
            angle = np.pi - np.arccos(value)
        elif vector[0] < 0 and vector[1] < 0:
            angle = np.pi + np.arccos(value)
        else:
            angle = 2 * np.pi - np.arccos(value)
        return angle
