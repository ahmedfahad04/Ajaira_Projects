
def view_range(x, i, j, shape):
    def view_range(x, i, j, shape):
        if j is None:
            j = len(x.shape)
        i = i % len(x.shape)
        j = j % len(x.shape)
        if i > j:
            raise ValueError("i must be less than or equal to j")
        dims_before = x.shape[:i]
        dims_after = x.shape[j:]
        return x.view(*dims_before, *shape, *dims_after)
