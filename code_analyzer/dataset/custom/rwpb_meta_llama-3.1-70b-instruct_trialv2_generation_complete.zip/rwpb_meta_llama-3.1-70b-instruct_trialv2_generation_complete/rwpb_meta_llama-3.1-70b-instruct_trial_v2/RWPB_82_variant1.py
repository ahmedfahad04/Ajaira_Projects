
def is_tensor(x):
    def is_tensor(x):
        if importlib.util.find_spec("torch") is not None:
            import torch
            return isinstance(x, torch.Tensor) or isinstance(x, np.ndarray)
        else:
            return isinstance(x, np.ndarray)
