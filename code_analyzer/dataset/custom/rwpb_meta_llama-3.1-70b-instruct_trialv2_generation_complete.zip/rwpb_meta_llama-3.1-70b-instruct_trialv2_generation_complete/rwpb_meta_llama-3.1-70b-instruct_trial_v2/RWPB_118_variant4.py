
def filter_nan(ts, vs):
    def filter_nan(ts, vs):
        filtered_ts = np.array([t for t, v in zip(ts, vs) if not np.isnan(t)])
        filtered_vs = np.array([v for t, v in zip(ts, vs) if not np.isnan(t)])
        return filtered_ts, filtered_vs
