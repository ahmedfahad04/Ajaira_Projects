
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        if upcast:
            x = x.to(torch.float32)
            weight = weight.to(torch.float32)
            if bias is not None:
                bias = bias.to(torch.float32)
            if residual is not None:
                residual = residual.to(torch.float32)
        norm = torch.linalg.norm(x, dim=-1, keepdim=True)
        normalized = x / (norm + eps)
        output = torch.matmul(normalized, weight) + bias if bias is not None else torch.matmul(normalized, weight)
        if residual is not None:
            output = output + residual
        if prenorm:
            return output, x
        else:
            return output
