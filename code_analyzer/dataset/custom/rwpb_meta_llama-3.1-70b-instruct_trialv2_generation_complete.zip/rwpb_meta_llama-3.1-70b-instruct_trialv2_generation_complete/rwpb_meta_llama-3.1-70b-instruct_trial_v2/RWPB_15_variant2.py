
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        if len(a) != len(b):
            raise KeyError("Length of a and b must be equal")
        return 1 - np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
