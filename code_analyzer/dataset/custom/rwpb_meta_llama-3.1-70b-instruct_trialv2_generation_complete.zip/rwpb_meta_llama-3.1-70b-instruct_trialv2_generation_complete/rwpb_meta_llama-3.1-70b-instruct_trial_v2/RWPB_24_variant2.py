
def check(x, checksum_token):
    def check(x, checksum_token):
        pattern = r'\b[0-9a-f]{64}\b'
        match = re.findall(pattern, x)
        if match:
            original_checksum = match[0]
            new_string = re.sub(pattern, checksum_token, x)
            hash_object = hashlib.sha256(new_string.encode())
            return hash_object.hexdigest() == original_checksum
        return False
