
def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        if upcast:
            x = x.float()
            weight = weight.float()
            bias = bias.float() if bias is not None else None
            residual = residual.float() if residual is not None else None
        class LayerNorm(torch.autograd.Function):
            @staticmethod
            def forward(ctx, x, weight, bias, eps):
                mean = x.mean(dim=-1, keepdim=True)
                std = x.std(dim=-1, keepdim=True)
                output = (x - mean) / (std + eps) * weight + bias
                ctx.save_for_backward(x, weight, bias, eps)
                return output
            @staticmethod
            def backward(ctx, grad_output):
                x, weight, bias, eps = ctx.saved_tensors
                mean = x.mean(dim=-1, keepdim=True)
                std = x.std(dim=-1, keepdim=True)
                grad_x = grad_output / (std + eps) * weight
                grad_weight = (grad_output * (x - mean) / (std + eps)).sum(dim=-1)
                grad_bias = grad_output.sum(dim=-1)
                return grad_x, grad_weight, grad_bias, None
        output = LayerNorm.apply(x, weight, bias, eps)
        if residual is not None:
            output = output + residual
        if prenorm:
            return output, x
        else:
            return output
