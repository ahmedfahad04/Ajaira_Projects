
def fuse_deconv_and_bn(deconv, bn):
    def fuse_deconv_and_bn(deconv, bn):
        weight = deconv.weight * bn.weight[:, None, None, None] / (bn.running_var + bn.eps)**0.5
        if deconv.bias is not None:
            bias = (deconv.bias - bn.running_mean) / (bn.running_var + bn.eps)**0.5 * bn.weight + bn.bias
        else:
            bias = (bn.bias - bn.running_mean) / (bn.running_var + bn.eps)**0.5 * bn.weight
        return torch.nn.ConvTranspose2d(deconv.in_channels, deconv.out_channels, deconv.kernel_size, 
                                       deconv.stride, deconv.padding, deconv.output_padding, 
                                       deconv.groups, bias is not None, deconv.dilation).to(deconv.weight.device)
