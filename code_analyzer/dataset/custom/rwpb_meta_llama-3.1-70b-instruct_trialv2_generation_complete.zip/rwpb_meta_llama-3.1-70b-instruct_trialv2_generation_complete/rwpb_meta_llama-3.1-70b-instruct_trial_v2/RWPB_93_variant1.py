
def unsafeSub(x, y):
    def unsafeSub(x, y):
        return (x - y) & MAX_VAL
