
def dynamic_import_function(function_path):
    def dynamic_import_function(function_path):
        module_path, function_name = function_path.rsplit('.', 1)
        try:
            module = importlib.import_module(module_path)
            return getattr(module, function_name)
        except ImportError as e:
            if 'No module named' in str(e):
                raise ModuleNotFoundError(f"No module named '{module_path}'")
            raise
        except AttributeError as e:
            if f"'{module_path}' has no attribute '{function_name}'" in str(e):
                raise ModuleNotFoundError(f"No function named '{function_name}' in module '{module_path}'")
            raise
