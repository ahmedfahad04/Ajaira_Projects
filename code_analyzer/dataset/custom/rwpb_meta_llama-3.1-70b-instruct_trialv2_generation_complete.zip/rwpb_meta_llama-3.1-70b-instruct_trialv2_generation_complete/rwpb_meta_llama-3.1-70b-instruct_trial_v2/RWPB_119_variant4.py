
def rotate_about_x_axis(vector, theta):
    import numpy as np
    from scipy.spatial.transform import Rotation as R
    def rotate_about_x_axis(vector, theta):
        rotation = R.from_euler('x', theta)
        return rotation.apply(vector)
