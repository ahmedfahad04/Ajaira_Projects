
def fovx_to_fovy(fovx, aspect):
    import math
    def fovx_to_fovy(fovx, aspect):
        return 2 * math.atan(math.tan(fovx / 2) / aspect)
