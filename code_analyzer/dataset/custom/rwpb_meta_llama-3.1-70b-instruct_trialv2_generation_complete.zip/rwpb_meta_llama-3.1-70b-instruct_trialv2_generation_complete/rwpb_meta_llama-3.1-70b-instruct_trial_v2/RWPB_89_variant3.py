
def format_ratio(ratio):
    def format_ratio(ratio):
        formatted_ratio = "{:.3f}".format(ratio)
        return f"percentage:{formatted_ratio}"
