
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        grid = torch.zeros((B, 2, H, W))
        for b in range(B):
            for h in range(H):
                for w in range(W):
                    grid[b, 0, h, w] = w
                    grid[b, 1, h, w] = h
        return grid
