
def xywh2xyxy(x):
    def xywh2xyxy(x):
        if isinstance(x, np.ndarray):
            x1 = x[:, 0]
            y1 = x[:, 1]
            x2 = x[:, 0] + x[:, 2]
            y2 = x[:, 1] + x[:, 3]
            return np.column_stack((x1, y1, x2, y2))
        elif isinstance(x, torch.Tensor):
            x1 = x[:, 0]
            y1 = x[:, 1]
            x2 = x[:, 0] + x[:, 2]
            y2 = x[:, 1] + x[:, 3]
            return torch.column_stack((x1, y1, x2, y2))
