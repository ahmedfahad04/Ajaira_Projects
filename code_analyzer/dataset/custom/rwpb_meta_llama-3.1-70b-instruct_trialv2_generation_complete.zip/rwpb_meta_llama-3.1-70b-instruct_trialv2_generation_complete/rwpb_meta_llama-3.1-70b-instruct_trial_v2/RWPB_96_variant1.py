
def movmean(arr, n_avg):
    def movmean(arr, n_avg):
        if n_avg > len(arr):
            return np.array([])
        mov_avg = np.convolve(arr, np.ones(n_avg)/n_avg, mode='valid')
        return mov_avg
