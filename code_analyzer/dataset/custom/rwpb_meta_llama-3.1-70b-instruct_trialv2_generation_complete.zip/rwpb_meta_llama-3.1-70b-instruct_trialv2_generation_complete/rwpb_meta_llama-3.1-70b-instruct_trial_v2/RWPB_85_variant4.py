
def window_partition(x: torch.Tensor, window_size: Sequence[int]):
    def window_partition(x: torch.Tensor, window_size: Sequence[int]):
        B, H, W, C = x.shape
        win_h, win_w = window_size
        patches = x.unfold(1, win_h, win_h).unfold(2, win_w, win_w)
        patches = patches.permute(0, 1, 2, 5, 3, 4).contiguous().view(B * H // win_h * W // win_w, win_h, win_w, C)
        return patches
