
def rot_trans_geo(geometry, rot, trans):
    def rot_trans_geo(geometry, rot, trans):
        return torch.einsum('ijk,ik->ij', rot, geometry) + trans[:, None, :]
