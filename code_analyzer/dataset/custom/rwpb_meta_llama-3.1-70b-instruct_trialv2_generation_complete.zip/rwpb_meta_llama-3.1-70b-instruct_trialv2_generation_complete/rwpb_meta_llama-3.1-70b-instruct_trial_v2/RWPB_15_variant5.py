
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        if len(a) != len(b):
            raise KeyError("Length of a and b must be equal")
        a_unit = a / np.linalg.norm(a)
        b_unit = b / np.linalg.norm(b)
        return 1 - np.dot(a_unit, b_unit)
