
def box_iou(box1, box2, eps=1e-7):
    import torch
    def box_iou(box1, box2, eps=1e-7):
        x1, y1, x2, y2 = box1[:, 0], box1[:, 1], box1[:, 2], box1[:, 3]
        x1g, y1g, x2g, y2g = box2[:, 0], box2[:, 1], box2[:, 2], box2[:, 3]
        x1 = x1.view(-1, 1)
        y1 = y1.view(-1, 1)
        x2 = x2.view(-1, 1)
        y2 = y2.view(-1, 1)
        x2g = x2g.view(1, -1)
        y2g = y2g.view(1, -1)
        x1g = x1g.view(1, -1)
        y1g = y1g.view(1, -1)
        x1_int = torch.max(x1, x1g)
        y1_int = torch.max(y1, y1g)
        x2_int = torch.min(x2, x2g)
        y2_int = torch.min(y2, y2g)
        area_int = torch.clamp(x2_int - x1_int, 0) * torch.clamp(y2_int - y1_int, 0)
        area1 = (x2 - x1) * (y2 - y1)
        area2 = (x2g - x1g) * (y2g - y1g)
        area_union = area1.view(-1, 1) + area2.view(1, -1) - area_int
        return area_int / (area_union + eps)
