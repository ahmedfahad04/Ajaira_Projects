
def rotate_about_z_axis(vector, theta):
    import numpy as np
    def rotate_about_z_axis(vector, theta):
        x, y, z = vector
        new_x = x * np.cos(theta) - y * np.sin(theta)
        new_y = x * np.sin(theta) + y * np.cos(theta)
        return np.array([new_x, new_y, z])
