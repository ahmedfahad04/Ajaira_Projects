
def euler2rot(euler_angle):
    import torch
    import math
    import numpy as np
    def euler2rot(euler_angle):
        batch_size = euler_angle.shape[0]
        rotation_matrices = torch.zeros((batch_size, 3, 3), device=euler_angle.device)
        for i in range(batch_size):
            angle_x, angle_y, angle_z = euler_angle[i]
            rotation_x = np.array([
                [1, 0, 0],
                [0, math.cos(angle_x), -math.sin(angle_x)],
                [0, math.sin(angle_x), math.cos(angle_x)]
            ])
            rotation_y = np.array([
                [math.cos(angle_y), 0, math.sin(angle_y)],
                [0, 1, 0],
                [-math.sin(angle_y), 0, math.cos(angle_y)]
            ])
            rotation_z = np.array([
                [math.cos(angle_z), -math.sin(angle_z), 0],
                [math.sin(angle_z), math.cos(angle_z), 0],
                [0, 0, 1]
            ])
            rotation_matrices[i] = torch.tensor(np.dot(rotation_z, np.dot(rotation_y, rotation_x)), device=euler_angle.device)
        return rotation_matrices
