
def unpad_image_shape(current_height, current_width, original_size):
    def unpad_image_shape(current_height, current_width, original_size):
        original_width, original_height = original_size
        original_aspect_ratio = original_width / original_height
        current_aspect_ratio = current_width / current_height
        if original_aspect_ratio > current_aspect_ratio:
            new_height = int(current_width / original_aspect_ratio)
            padding = (current_height - new_height) // 2
            return new_height, current_width
        else:
            new_width = int(current_height * original_aspect_ratio)
            padding = (current_width - new_width) // 2
            return current_height, new_width
