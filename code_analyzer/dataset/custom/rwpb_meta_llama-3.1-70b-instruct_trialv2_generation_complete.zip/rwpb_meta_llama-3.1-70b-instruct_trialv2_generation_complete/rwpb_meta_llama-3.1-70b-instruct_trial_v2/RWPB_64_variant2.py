
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        smoothed = []
        residuals = []
        for i in range(len(arr) - window_size + 1):
            window = arr[i:i + window_size]
            avg = np.mean(window)
            smoothed.append(avg)
            residuals.extend([x - avg for x in window])
        return np.array(smoothed), np.array(residuals)
