
def extract_code_from_funct(funct: Callable) -> List[str]:
    import inspect
    from typing import Callable, List
    def extract_code_from_funct(funct: Callable) -> List[str]:
        source = inspect.getsource(funct)
        lines = source.split('\n')
        func_def_line = lines[0]
        indent_level = len(func_def_line) - len(func_def_line.lstrip())
        lines = lines[1:]
        while lines and lines[-1].strip() == 'return':
            lines.pop()
        lines = [line[indent_level:] for line in lines]
        return lines
