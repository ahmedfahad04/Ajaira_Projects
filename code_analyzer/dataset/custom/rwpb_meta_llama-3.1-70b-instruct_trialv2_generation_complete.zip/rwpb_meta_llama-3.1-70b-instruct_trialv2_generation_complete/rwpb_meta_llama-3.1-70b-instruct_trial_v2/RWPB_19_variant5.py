
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        total = 0
        correct = 0
        for i in range(len(preds)):
            for j in range(len(preds)):
                if i != j:
                    total += 1
                    if (preds[i] > preds[j] and references[i] > references[j]) or (preds[i] < preds[j] and references[i] < references[j]) or (preds[i] == preds[j] and references[i] == references[j]):
                        correct += 1
        return correct / total if total > 0 else 0.0
