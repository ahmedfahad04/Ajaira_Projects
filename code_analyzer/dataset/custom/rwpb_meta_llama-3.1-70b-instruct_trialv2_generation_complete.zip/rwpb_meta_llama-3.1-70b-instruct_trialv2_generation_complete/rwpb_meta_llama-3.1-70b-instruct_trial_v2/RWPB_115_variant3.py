
def compute_tri_normal(geometry, tris):
    def compute_tri_normal(geometry, tris):
        batch_size, num_points, _ = geometry.shape
        num_tris, _ = tris.shape
        # Get the vertex indices for each triangle
        v0 = geometry[torch.arange(batch_size)[:, None, None], tris[None, :, 0]]
        v1 = geometry[torch.arange(batch_size)[:, None, None], tris[None, :, 1]]
        v2 = geometry[torch.arange(batch_size)[:, None, None], tris[None, :, 2]]
        # Compute the normal vectors
        normals = torch.cross(v1 - v0, v2 - v0, dim=2)
        normals = normals / torch.norm(normals, dim=2, keepdim=True)
        return normals
