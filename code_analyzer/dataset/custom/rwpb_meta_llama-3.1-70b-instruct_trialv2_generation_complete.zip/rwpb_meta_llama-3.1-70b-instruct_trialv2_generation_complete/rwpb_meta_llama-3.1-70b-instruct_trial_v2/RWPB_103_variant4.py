
def unsafeAdd(x, y):
    def unsafeAdd(x, y):
        return x + y & MAX_VAL
