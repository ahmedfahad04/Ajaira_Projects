
def round(number, num_decimal_places, leave_int=False):
    def round(number, num_decimal_places, leave_int=False):
        if isinstance(number, int) and not leave_int:
            return number
        return float(np.round(number, num_decimal_places))
