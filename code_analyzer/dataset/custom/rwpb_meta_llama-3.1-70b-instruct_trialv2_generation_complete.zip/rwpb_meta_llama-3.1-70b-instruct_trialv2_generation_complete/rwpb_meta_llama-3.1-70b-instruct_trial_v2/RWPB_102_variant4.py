
def rotate_about_z_axis(vector, theta):
    import numpy as np
    def rotate_about_z_axis(vector, theta):
        x, y, z = vector
        c, s = np.cos(theta), np.sin(theta)
        new_x = c * x - s * y
        new_y = s * x + c * y
        return np.array([new_x, new_y, z])
