
def divide_to_patches(image, patch_size):
    def divide_to_patches(image, patch_size):
        width, height = image.size
        patches = []
        for i in range(0, height, patch_size):
            for j in range(0, width, patch_size):
                patch = image.crop((j, i, min(j + patch_size, width), min(i + patch_size, height)))
                patches.append(patch)
        return patches
