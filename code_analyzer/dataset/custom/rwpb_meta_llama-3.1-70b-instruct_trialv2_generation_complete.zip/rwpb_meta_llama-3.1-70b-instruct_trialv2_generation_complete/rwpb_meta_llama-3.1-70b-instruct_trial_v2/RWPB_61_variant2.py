
def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        if upcast:
            x = x.float()
            weight = weight.float()
            bias = bias.float() if bias is not None else None
            residual = residual.float() if residual is not None else None
        normalized = torch.nn.functional.layer_norm(x, x.shape[-1:], weight, bias, eps)
        if residual is not None:
            normalized = normalized + residual
        if prenorm:
            return normalized, x
        else:
            return normalized
