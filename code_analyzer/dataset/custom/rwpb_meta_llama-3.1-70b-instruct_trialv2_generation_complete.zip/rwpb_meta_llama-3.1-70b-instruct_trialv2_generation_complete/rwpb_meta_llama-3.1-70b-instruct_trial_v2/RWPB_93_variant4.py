
def unsafeSub(x, y):
    def unsafeSub(x, y):
        result = x - y
        if result < 0:
            result += MAX_VAL + 1
        return result
