
def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
    import torch
    def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
        return torch.stack([start + (stop - start) * i / (num - 1) for i in range(num)])
