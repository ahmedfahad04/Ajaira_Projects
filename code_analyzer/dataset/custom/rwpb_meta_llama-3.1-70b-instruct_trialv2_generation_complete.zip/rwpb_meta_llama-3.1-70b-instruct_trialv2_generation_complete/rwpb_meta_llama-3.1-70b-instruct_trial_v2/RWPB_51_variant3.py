
def _ssim(img1, img2, window, window_size, channel, size_average=True):
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        def calculate_mean(img, window):
            return F.conv2d(img, window, groups=channel)
        def calculate_variance(img, window, mean):
            return F.conv2d((img - mean) ** 2, window, groups=channel)
        mu1 = calculate_mean(img1, window)
        mu2 = calculate_mean(img2, window)
        sigma1_sq = calculate_variance(img1, window, mu1)
        sigma2_sq = calculate_variance(img2, window, mu2)
        sigma12 = calculate_variance(img1 * img2, window, mu1 * mu2) - mu1 * mu2
        C1 = 0.01 ** 2
        C2 = 0.03 ** 2
        ssim_map = ((2 * mu1 * mu2 + C1) * (2 * sigma12 + C2)) / ((mu1 ** 2 + mu2 ** 2 + C1) * (sigma1_sq + sigma2_sq + C2))
        if size_average:
            return ssim_map.mean()
        else:
            return ssim_map.mean(1).mean(1).mean(1)
