
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        if len(a) != len(b):
            raise KeyError("Length of a and b must be equal")
        dot_product = np.dot(a, b)
        magnitude_a = np.linalg.norm(a)
        magnitude_b = np.linalg.norm(b)
        return 1 - (dot_product / (magnitude_a * magnitude_b))
