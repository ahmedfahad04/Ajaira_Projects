
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        if len(a) != len(b):
            raise KeyError("Length of a and b must be equal")
        a_dot_b = np.sum(a * b)
        a_norm = np.sqrt(np.sum(a ** 2))
        b_norm = np.sqrt(np.sum(b ** 2))
        return 1 - a_dot_b / (a_norm * b_norm)
