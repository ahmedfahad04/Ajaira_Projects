
def euler2rot(euler_angle):
    import torch
    import math
    def euler2rot(euler_angle):
        batch_size = euler_angle.shape[0]
        rotation_matrices = torch.zeros((batch_size, 3, 3), device=euler_angle.device)
        for i in range(batch_size):
            angle_x, angle_y, angle_z = euler_angle[i]
            rotation_x = torch.tensor([
                [1, 0, 0],
                [0, math.cos(angle_x), -math.sin(angle_x)],
                [0, math.sin(angle_x), math.cos(angle_x)]
            ], device=euler_angle.device)
            rotation_y = torch.tensor([
                [math.cos(angle_y), 0, math.sin(angle_y)],
                [0, 1, 0],
                [-math.sin(angle_y), 0, math.cos(angle_y)]
            ], device=euler_angle.device)
            rotation_z = torch.tensor([
                [math.cos(angle_z), -math.sin(angle_z), 0],
                [math.sin(angle_z), math.cos(angle_z), 0],
                [0, 0, 1]
            ], device=euler_angle.device)
            rotation_matrices[i] = torch.matmul(rotation_z, torch.matmul(rotation_y, rotation_x))
        return rotation_matrices
