
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        angle_rad = np.deg2rad(angle)
        rotation_matrix = np.array([
            [np.cos(angle_rad), 0, np.sin(angle_rad)],
            [0, 1, 0],
            [-np.sin(angle_rad), 0, np.cos(angle_rad)]
        ])
        rotated_normal_map = np.zeros_like(normal_map)
        for i in range(normal_map.shape[0]):
            for j in range(normal_map.shape[1]):
                rotated_normal_map[i, j] = np.dot(rotation_matrix, normal_map[i, j])
        return rotated_normal_map
