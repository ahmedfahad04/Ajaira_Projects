
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        if ignore is not None:
            mask = labels != ignore
            preds = preds[mask]
            labels = labels[mask]
        tp = (preds * labels).sum()
        fp = (preds * (1 - labels)).sum()
        fn = ((1 - preds) * labels).sum()
        if tp + fp + fn == 0:
            return EMPTY * 100
        iou = (tp / (tp + fp + fn)) * 100
        if per_image:
            return iou.mean()
        else:
            return iou
