
def merge_dicts_recursively(*dicts):
    def merge_dicts_recursively(*dicts):
        result = {}
        for d in reversed(dicts):
            for k, v in d.items():
                if isinstance(v, dict) and k in result and isinstance(result[k], dict):
                    result[k] = merge_dicts_recursively({k: result[k]}, {k: v})[k]
                else:
                    result[k] = v
        return result
