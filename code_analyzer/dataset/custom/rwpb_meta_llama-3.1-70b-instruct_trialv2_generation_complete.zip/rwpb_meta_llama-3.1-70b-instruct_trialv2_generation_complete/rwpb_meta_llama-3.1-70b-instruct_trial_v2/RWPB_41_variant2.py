
def merge_short_sentences_en(sens):
    def merge_short_sentences_en(sens):
        result = []
        i = 0
        while i < len(sens):
            if len(sens[i].split()) < 5 and i < len(sens) - 1:
                result.append(sens[i] + " " + sens[i + 1])
                i += 2
            else:
                result.append(sens[i])
                i += 1
        return result
