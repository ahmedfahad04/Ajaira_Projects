
def validate_user_id(user_id):
    import re
    def validate_user_id(user_id):
        pattern = r'^[a-zA-Z][\w]*$'
        return bool(re.match(pattern, user_id))
