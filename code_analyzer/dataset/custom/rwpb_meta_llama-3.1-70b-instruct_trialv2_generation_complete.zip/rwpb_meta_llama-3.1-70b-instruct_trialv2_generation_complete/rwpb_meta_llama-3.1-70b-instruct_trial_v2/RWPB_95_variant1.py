
def lines_focal(o, d):
    import torch
    def lines_focal(o, d):
        d = d / d.norm(dim=1, keepdim=True)
        I = torch.eye(3, dtype=o.dtype, device=o.device)
        S = torch.sum((d[:, None, :] * d[:, :, None] - I)[:, None, :, :] * d[:, :, None, None], dim=0)
        C = torch.sum((d[:, None, :] * d[:, :, None] - I) @ o[:, :, None], dim=0)
        return torch.linalg.pinv(S) @ C
