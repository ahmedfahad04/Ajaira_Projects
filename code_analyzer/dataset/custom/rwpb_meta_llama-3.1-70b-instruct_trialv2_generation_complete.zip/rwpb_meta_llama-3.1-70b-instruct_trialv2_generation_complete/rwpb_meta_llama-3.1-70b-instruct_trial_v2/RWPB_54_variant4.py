
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        x, y, x1, y1 = box
        center_x, center_y = (x + x1) / 2, (y + y1) / 2
        width, height = x1 - x, y1 - y
        new_dimensions = [width * expand, height * expand]
        s = sum(new_dimensions) / 4
        new_box = [
            center_x - new_dimensions[0] / 2,
            center_y - new_dimensions[1] / 2,
            center_x + new_dimensions[0] / 2,
            center_y + new_dimensions[1] / 2,
        ]
        return new_box, s
