
def invalid_to_zeros(arr, valid_mask, ndim=999):
    import torch
    def invalid_to_zeros(arr, valid_mask, ndim=999):
        arr = arr.clone()
        arr[~valid_mask] = 0
        if ndim != 999 and arr.ndim > ndim:
            arr = arr.view(*arr.shape[:ndim], -1)
        if valid_mask is not None:
            nnz = valid_mask.sum().item()
        else:
            nnz = arr.numel() // arr.shape[0]
        return arr, nnz
