
def euler2rot(euler_angle):
    import torch
    def euler2rot(euler_angle):
        batch_size = euler_angle.shape[0]
        rotation_matrices = torch.zeros((batch_size, 3, 3), device=euler_angle.device)
        sx, sy, sz = torch.sin(euler_angle).unbind(-1)
        cx, cy, cz = torch.cos(euler_angle).unbind(-1)
        rotation_matrices[:, 0, 0] = cy * cz
        rotation_matrices[:, 0, 1] = -cy * sz
        rotation_matrices[:, 0, 2] = sy
        rotation_matrices[:, 1, 0] = sx * sy * cz + cx * sz
        rotation_matrices[:, 1, 1] = -sx * sy * sz + cx * cz
        rotation_matrices[:, 1, 2] = -sx * cy
        rotation_matrices[:, 2, 0] = -cx * sy * cz + sx * sz
        rotation_matrices[:, 2, 1] = cx * sy * sz + sx * cz
        rotation_matrices[:, 2, 2] = cx * cy
        return rotation_matrices
