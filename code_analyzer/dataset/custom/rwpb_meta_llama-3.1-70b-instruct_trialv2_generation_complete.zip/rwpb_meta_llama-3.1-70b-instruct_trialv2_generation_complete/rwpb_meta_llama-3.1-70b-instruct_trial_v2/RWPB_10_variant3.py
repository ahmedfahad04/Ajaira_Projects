
def euler2rot(euler_angle):
    import torch
    def euler2rot(euler_angle):
        batch_size = euler_angle.shape[0]
        rotation_matrices = torch.zeros((batch_size, 3, 3), device=euler_angle.device)
        def create_rotation_matrix(angle, i, j, k):
            return torch.tensor([
                [torch.cos(angle), -torch.sin(angle), 0],
                [torch.sin(angle), torch.cos(angle), 0],
                [0, 0, 1]
            ], device=euler_angle.device, dtype=torch.float32)
        for i in range(batch_size):
            rotation_x = create_rotation_matrix(euler_angle[i, 0], 0, 1, 2)
            rotation_y = create_rotation_matrix(euler_angle[i, 1], 1, 2, 0)
            rotation_z = create_rotation_matrix(euler_angle[i, 2], 2, 0, 1)
            rotation_matrices[i] = torch.matmul(rotation_z, torch.matmul(rotation_y, rotation_x))
        return rotation_matrices
