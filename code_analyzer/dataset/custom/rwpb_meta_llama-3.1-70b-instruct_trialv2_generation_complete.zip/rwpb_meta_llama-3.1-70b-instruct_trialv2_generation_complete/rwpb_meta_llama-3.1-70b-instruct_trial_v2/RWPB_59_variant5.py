
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        batch_size, vocab_size = logits.shape
        penalty_tensor = torch.ones((batch_size, vocab_size), device=logits.device)
        for i in range(batch_size):
            penalty_tensor[i].scatter_(0, prev_output_tokens[i], torch.ones_like(prev_output_tokens[i]) * repetition_penalty)
        return logits * penalty_tensor
