
def last_before(val, arr):
    def last_before(val, arr):
        for i in range(len(arr) - 1, -1, -1):
            if arr[i] <= val:
                return i
        return -1
