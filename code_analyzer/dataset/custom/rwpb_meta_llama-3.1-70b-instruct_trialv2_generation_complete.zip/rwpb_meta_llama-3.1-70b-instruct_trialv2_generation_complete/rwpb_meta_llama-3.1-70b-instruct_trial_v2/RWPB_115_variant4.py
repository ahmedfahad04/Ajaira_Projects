
def compute_tri_normal(geometry, tris):
    def compute_tri_normal(geometry, tris):
        batch_size, num_points, _ = geometry.shape
        num_tris, _ = tris.shape
        normals = torch.zeros(batch_size, num_tris, 3, device=geometry.device)
        for i in range(batch_size):
            for j in range(num_tris):
                v0 = geometry[i, tris[j, 0]]
                v1 = geometry[i, tris[j, 1]]
                v2 = geometry[i, tris[j, 2]]
                # Compute the normal vector
                normal = torch.cross(v1 - v0, v2 - v0)
                normal = normal / torch.norm(normal)
                normals[i, j] = normal
        return normals
