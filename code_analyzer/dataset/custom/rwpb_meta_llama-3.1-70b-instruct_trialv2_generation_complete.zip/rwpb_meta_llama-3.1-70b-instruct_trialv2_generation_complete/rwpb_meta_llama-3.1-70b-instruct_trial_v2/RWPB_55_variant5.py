
def numpy_to_pytorch(x):
    def numpy_to_pytorch(x):
        x = torch.tensor(x, dtype=torch.float32)
        x = x / 255.0
        x = x.unsqueeze(0)
        return x
