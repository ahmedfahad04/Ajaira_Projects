
def focal_length_to_fovy(focal_length, sensor_height):
    import math
    def focal_length_to_fovy(focal_length, sensor_height):
        return 2 * math.atan2(sensor_height / 2, focal_length)
