
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        if isinstance(divisor, torch.Tensor):
            divisor = int(divisor.max().item())
        remainder = x % divisor
        if remainder < divisor / 2:
            return x - remainder
        else:
            return x + (divisor - remainder)
