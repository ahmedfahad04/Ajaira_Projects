
def rotate_y(a, device=None):
    import torch
    import numpy as np
    def rotate_y(a, device=None):
        if device is None:
            device = torch.device('cpu')
        sin_a = torch.sin(a).to(device)
        cos_a = torch.cos(a).to(device)
        matrix = torch.tensor([
            [cos_a, 0, -sin_a, 0],
            [0, 1, 0, 0],
            [sin_a, 0, cos_a, 0],
            [0, 0, 0, 1]
        ]).to(device)
        return matrix
