
def mean(l, ignore_nan=False, empty=0):
    import numpy as np
    def mean(l, ignore_nan=False, empty=0):
        l = np.fromiter(l, dtype=float)
        if ignore_nan:
            l = l[~np.isnan(l)]
        if len(l) == 0:
            if empty == 'raise':
                raise ValueError("Input iterable is empty")
            return empty
        return np.mean(l)
