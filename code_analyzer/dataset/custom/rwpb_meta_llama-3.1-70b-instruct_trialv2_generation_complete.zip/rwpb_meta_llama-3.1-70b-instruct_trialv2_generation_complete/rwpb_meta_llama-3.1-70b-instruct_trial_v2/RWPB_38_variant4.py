
def extract_imports_from_lines(lines: List[str]) -> str:
    def extract_imports_from_lines(lines: List[str]) -> str:
        import_set = set()
        for line in lines:
            line = line.strip()
            if line.startswith('import') or line.startswith('from'):
                import_set.add(line)
        return '\n'.join(sorted(import_set))
