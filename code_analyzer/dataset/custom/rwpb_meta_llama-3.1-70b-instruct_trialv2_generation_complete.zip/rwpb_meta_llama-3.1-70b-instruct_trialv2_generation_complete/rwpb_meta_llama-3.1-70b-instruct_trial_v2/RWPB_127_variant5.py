
def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
    def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
        if src_dim < 0:
            src_dim = x.dim() + src_dim
        if dest_dim < 0:
            dest_dim = x.dim() + dest_dim
        dims = torch.tensor(list(range(x.dim())))
        dims = torch.cat((dims[:src_dim], dims[src_dim+1:]))
        dims = torch.cat((dims[:dest_dim], torch.tensor([src_dim]), dims[dest_dim:]))
        result = x.permute(*dims.tolist())
        if make_contiguous:
            result = result.contiguous()
        return result
