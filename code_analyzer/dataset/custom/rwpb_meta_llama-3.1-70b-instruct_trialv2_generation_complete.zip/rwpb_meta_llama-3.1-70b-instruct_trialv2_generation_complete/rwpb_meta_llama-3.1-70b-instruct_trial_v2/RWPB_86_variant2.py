
def inverse_sigmoid(x):
    import torch
    def inverse_sigmoid(x):
        return torch.log(torch.clamp(x, 1e-10, 1 - 1e-10) / (1 - torch.clamp(x, 1e-10, 1 - 1e-10)))
