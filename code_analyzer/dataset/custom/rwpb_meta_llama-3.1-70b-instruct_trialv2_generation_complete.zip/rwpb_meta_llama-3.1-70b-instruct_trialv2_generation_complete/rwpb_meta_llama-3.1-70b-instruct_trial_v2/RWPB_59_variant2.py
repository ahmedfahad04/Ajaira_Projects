
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        vocab_size = logits.shape[1]
        batch_size, seq_len = prev_output_tokens.shape
        penalty_tensor = torch.ones_like(logits)
        for i in range(batch_size):
            prev_tokens = prev_output_tokens[i]
            for token in prev_tokens:
                penalty_tensor[i, token] *= repetition_penalty
        return logits * penalty_tensor
