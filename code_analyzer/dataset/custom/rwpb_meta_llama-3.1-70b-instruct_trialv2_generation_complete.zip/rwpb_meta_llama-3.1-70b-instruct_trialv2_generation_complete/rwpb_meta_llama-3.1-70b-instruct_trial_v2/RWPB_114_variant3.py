
def reshape_weight_task_tensors(task_tensors, weights):
    def reshape_weight_task_tensors(task_tensors, weights):
        diff = len(task_tensors.shape) - len(weights.shape)
        new_shape = [1] * diff + list(weights.shape)
        return weights.reshape(new_shape)
