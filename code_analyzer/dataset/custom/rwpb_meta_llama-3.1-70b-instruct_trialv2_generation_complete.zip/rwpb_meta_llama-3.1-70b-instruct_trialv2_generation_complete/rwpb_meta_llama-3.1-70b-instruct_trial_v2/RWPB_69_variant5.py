
def fovx_to_fovy(fovx, aspect):
    import math
    def fovx_to_fovy(fovx, aspect):
        tan_half_fovx = math.tan(fovx / 2)
        return 2 * math.atan(tan_half_fovx / aspect)
