
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        x = torch.linspace(0, W - 1, W)
        y = torch.linspace(0, H - 1, H)
        x, y = torch.meshgrid(x, y)
        grid = torch.stack((x, y), dim=0)
        return grid.unsqueeze(0).repeat(B, 1, 1, 1)
