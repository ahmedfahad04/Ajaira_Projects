
def validate_user_id(user_id):
    import re
    def validate_user_id(user_id):
        pattern = r'^[a-zA-Z][\w]*$'
        match = re.search(pattern, user_id)
        return match is not None and match.group() == user_id
