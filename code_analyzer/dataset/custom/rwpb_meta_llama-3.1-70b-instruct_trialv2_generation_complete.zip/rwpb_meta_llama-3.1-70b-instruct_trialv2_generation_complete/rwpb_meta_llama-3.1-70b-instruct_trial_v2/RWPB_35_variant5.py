
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    import collections
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        result = collections.OrderedDict()
        queue = collections.deque([(d, parent_key)])
        while queue:
            curr_dict, parent_key = queue.popleft()
            for key, value in curr_dict.items():
                new_key = f"{parent_key}{sep}{key}" if parent_key else key
                if isinstance(value, dict):
                    queue.append((value, new_key))
                else:
                    result[new_key] = value
        return dict(result)
