
def divide_to_patches(image, patch_size):
    def divide_to_patches(image, patch_size):
        width, height = image.size
        patches = []
        for y in range(0, height, patch_size):
            for x in range(0, width, patch_size):
                patch_box = (x, y, x + patch_size, y + patch_size)
                patch_box = tuple(min(max(val, 0), size) for val, size in zip(patch_box, (x, y, width, height)))
                patch = image.crop(patch_box)
                patches.append(patch)
        return patches
