
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        smoothed = np.convolve(arr, np.ones(window_size) / window_size, mode='valid')
        residuals = arr[window_size - 1:] - smoothed
        return smoothed, residuals
