
def unsafeSub(x, y):
    def unsafeSub(x, y):
        mask = (1 << 256) - 1
        return ((x & mask) - (y & mask)) & mask
