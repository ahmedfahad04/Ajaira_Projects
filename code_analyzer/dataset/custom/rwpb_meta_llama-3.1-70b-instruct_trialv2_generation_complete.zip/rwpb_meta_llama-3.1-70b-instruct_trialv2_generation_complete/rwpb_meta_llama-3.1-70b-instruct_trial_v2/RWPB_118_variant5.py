
def filter_nan(ts, vs):
    def filter_nan(ts, vs):
        mask = np.isfinite(ts)
        return ts[mask], vs[mask]
