
def format_seconds(seconds: float) -> str:
    def format_seconds(seconds: float) -> str:
        if seconds >= 3600:
            hours = int(seconds // 3600)
            minutes = int((seconds % 3600) // 60)
            seconds = round(seconds % 60, 3)
            return f"{hours:02d}:{minutes:02d}:{seconds:06.3f}"
        else:
            minutes = int(seconds // 60)
            seconds = round(seconds % 60, 3)
            return f"{minutes:02d}:{seconds:06.3f}"
