
def pad_camera_extrinsics_4x4(extrinsics):
    def pad_camera_extrinsics_4x4(extrinsics):
        return torch.cat([extrinsics, torch.zeros((*extrinsics.shape[:-2], 1, 4), device=extrinsics.device)], dim=-2)
