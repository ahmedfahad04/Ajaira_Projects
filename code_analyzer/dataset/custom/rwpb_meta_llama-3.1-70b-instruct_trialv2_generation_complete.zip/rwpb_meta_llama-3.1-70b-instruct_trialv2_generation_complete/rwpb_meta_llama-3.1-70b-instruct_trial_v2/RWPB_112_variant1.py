
def submatrix(matrix, col):
    def submatrix(matrix, col):
        return [row[:col] + row[col+1:] for row in matrix]
