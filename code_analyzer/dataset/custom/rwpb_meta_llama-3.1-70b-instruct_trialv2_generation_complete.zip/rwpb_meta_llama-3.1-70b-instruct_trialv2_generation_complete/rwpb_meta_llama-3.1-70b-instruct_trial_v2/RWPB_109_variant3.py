
def rot_trans_geo(geometry, rot, trans):
    def rot_trans_geo(geometry, rot, trans):
        batch_size, num_points, _ = geometry.shape
        geometry = geometry.view(-1, 3)
        rot = rot.view(-1, 3, 3)
        trans = trans.view(-1, 3)
        result = torch.matmul(geometry, rot) + trans
        return result.view(batch_size, num_points, 3)
