
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        x = torch.arange(W)
        y = torch.arange(H)
        x, y = torch.meshgrid(x, y, indexing='xy')
        grid = torch.stack((x, y), dim=0)
        return grid.unsqueeze(0).repeat(B, 1, 1, 1)
