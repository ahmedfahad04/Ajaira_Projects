
def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        batch_size, num_points, _ = coordinates.shape
        num_planes, _, _ = planes.shape
        # Reshape coordinates to (batch_size * num_points, 3)
        coordinates = coordinates.view(batch_size * num_points, 3)
        # Create a tensor to store the projected points
        projected_points = torch.zeros(batch_size * num_planes * num_points, 2, device=coordinates.device)
        # Iterate over each plane
        for i in range(num_planes):
            # Extract the plane's axes
            x_axis, y_axis, normal = planes[i]
            # Project the points onto the plane's x and y axes
            x_coords = torch.dot(coordinates, x_axis)
            y_coords = torch.dot(coordinates, y_axis)
            # Store the projected points
            projected_points[i * batch_size * num_points:(i + 1) * batch_size * num_points] = torch.stack([x_coords, y_coords], dim=1)
        # Reshape the projected points to (batch_size * num_planes, num_points, 2)
        projected_points = projected_points.view(batch_size * num_planes, num_points, 2)
        return projected_points
