
def window_partition(x: torch.Tensor, window_size: Sequence[int]):
    def window_partition(x: torch.Tensor, window_size: Sequence[int]):
        B, H, W, C = x.shape
        win_h, win_w = window_size
        x = x.view(B, H // win_h, win_h, W, C)
        x = x.permute(0, 1, 3, 2, 4).contiguous().view(B * H // win_h, W * win_h, C)
        x = x.view(B * H // win_h, W // win_w, win_w, win_h, C)
        x = x.permute(0, 1, 3, 2, 4).contiguous().view(B * H // win_h * W // win_w, win_h, win_w, C)
        return x
