
def getLambertCoefs(numOfLambertCoefs):
    from math import factorial
    def getLambertCoefs(numOfLambertCoefs):
        def recursive_lambert(i):
            if i == 1:
                return 1
            else:
                return (factorial(i + 1) - 1) // i
        lambert_coefs = [recursive_lambert(i) for i in range(1, numOfLambertCoefs + 1)]
        return lambert_coefs
