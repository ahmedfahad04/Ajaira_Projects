
def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
    from typing import Callable, Dict, Tuple, Any
    from functools import partial
    import inspect
    def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
        func_params = inspect.signature(func).parameters
        valid_params = {}
        for param in func_params:
            if param in params:
                valid_params[param] = params[param]
        partial_func = partial(func, **valid_params)
        return partial_func, valid_params
