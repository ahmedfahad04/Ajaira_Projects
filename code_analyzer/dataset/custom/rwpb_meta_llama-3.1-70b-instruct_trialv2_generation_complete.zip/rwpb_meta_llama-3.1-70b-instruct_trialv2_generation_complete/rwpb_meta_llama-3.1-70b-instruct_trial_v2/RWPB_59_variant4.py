
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        batch_size, vocab_size = logits.shape
        penalty_tensor = torch.ones((batch_size, vocab_size), device=logits.device)
        penalty_tensor.scatter_add_(1, prev_output_tokens, torch.ones_like(prev_output_tokens) * (repetition_penalty - 1))
        return logits * penalty_tensor
