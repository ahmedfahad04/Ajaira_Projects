
def unsafeAdd(x, y):
    def unsafeAdd(x, y):
        result = x + y
        if result > MAX_VAL:
            result -= (1 << 256)
        return result
