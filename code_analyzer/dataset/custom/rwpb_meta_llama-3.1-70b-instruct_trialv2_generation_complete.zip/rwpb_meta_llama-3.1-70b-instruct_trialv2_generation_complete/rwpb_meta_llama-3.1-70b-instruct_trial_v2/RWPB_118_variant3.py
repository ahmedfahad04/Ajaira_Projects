
def filter_nan(ts, vs):
    def filter_nan(ts, vs):
        return ts[~np.isnan(ts)], vs[~np.isnan(ts)]
