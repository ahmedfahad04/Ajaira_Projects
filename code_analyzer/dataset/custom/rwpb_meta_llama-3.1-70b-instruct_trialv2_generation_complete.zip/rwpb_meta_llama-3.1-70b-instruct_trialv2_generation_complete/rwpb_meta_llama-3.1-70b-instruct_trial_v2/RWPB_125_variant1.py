
def resample_segments(segments, n=1000):
    import numpy as np
    def resample_segments(segments, n=1000):
        resampled_segments = []
        for segment in segments:
            t = np.linspace(0, 1, len(segment))
            t_resampled = np.linspace(0, 1, n)
            x_resampled = np.interp(t_resampled, t, segment[:, 0])
            y_resampled = np.interp(t_resampled, t, segment[:, 1])
            resampled_segments.append(np.column_stack((x_resampled, y_resampled)))
        return resampled_segments
