
def unpad_image_shape(current_height, current_width, original_size):
    def unpad_image_shape(current_height, current_width, original_size):
        original_width, original_height = original_size
        original_aspect_ratio = original_width / original_height
        current_aspect_ratio = current_width / current_height
        def calculate_new_size(scale_factor):
            new_width = round(original_width * scale_factor)
            new_height = round(original_height * scale_factor)
            return new_height, new_width
        if original_aspect_ratio > current_aspect_ratio:
            scale_factor = current_width / original_width
            return calculate_new_size(scale_factor)
        else:
            scale_factor = current_height / original_height
            return calculate_new_size(scale_factor)
