
def path_spliter(path: str):
    import os
    def path_spliter(path: str):
        return path.split(os.sep)
