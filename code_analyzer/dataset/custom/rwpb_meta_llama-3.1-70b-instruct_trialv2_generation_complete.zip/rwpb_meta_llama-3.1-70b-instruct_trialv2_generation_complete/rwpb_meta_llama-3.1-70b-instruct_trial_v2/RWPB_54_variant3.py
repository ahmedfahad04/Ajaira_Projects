
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        x, y, x1, y1 = box
        cx, cy = (x + x1) / 2, (y + y1) / 2
        w, h = x1 - x, y1 - y
        s = (w * expand + h * expand) / 4
        new_x, new_y = cx - (w * expand) / 2, cy - (h * expand) / 2
        new_x1, new_y1 = cx + (w * expand) / 2, cy + (h * expand) / 2
        return [new_x, new_y, new_x1, new_y1], s
