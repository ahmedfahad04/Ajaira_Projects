
def pad_camera_extrinsics_4x4(extrinsics):
    def pad_camera_extrinsics_4x4(extrinsics):
        batch_shape = extrinsics.shape[:-2]
        padded_extrinsics = torch.zeros((*batch_shape, 4, 4), device=extrinsics.device)
        padded_extrinsics[..., :3, :] = extrinsics
        padded_extrinsics[..., 3, 3] = 1.0
        return padded_extrinsics
