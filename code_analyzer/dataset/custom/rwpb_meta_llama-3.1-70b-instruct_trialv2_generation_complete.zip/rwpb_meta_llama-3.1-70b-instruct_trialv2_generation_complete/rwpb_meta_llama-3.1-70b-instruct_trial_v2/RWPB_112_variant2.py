
def submatrix(matrix, col):
    def submatrix(matrix, col):
        sub_matrix = []
        for row in matrix:
            sub_matrix.append([x for i, x in enumerate(row) if i != col])
        return sub_matrix
