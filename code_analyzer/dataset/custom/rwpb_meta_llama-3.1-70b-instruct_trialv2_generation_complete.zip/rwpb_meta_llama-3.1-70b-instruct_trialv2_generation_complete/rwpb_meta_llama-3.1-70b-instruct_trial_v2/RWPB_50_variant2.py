
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        original_height, original_width = original_size
        current_height, current_width = tensor.shape[1], tensor.shape[2]
        aspect_ratio_diff = original_width / original_height - current_width / current_height
        if aspect_ratio_diff > 0:
            target_height = current_height
            target_width = int(current_height * original_width / original_height)
            start_width = (current_width - target_width) // 2
            end_width = start_width + target_width
            return tensor[:, :, start_width:end_width, :]
        else:
            target_width = current_width
            target_height = int(current_width * original_height / original_width)
            start_height = (current_height - target_height) // 2
            end_height = start_height + target_height
            return tensor[:, start_height:end_height, :, :]
