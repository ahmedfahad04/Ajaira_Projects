
def unpad_image_shape(current_height, current_width, original_size):
    def unpad_image_shape(current_height, current_width, original_size):
        original_width, original_height = original_size
        original_aspect_ratio = original_width / original_height
        current_aspect_ratio = current_width / current_height
        if original_aspect_ratio >= current_aspect_ratio:
            scale_factor = current_width / original_width
            new_height = int(original_height * scale_factor)
            return new_height, current_width
        else:
            scale_factor = current_height / original_height
            new_width = int(original_width * scale_factor)
            return current_height, new_width
