
def arccos2(vector, value):
    import numpy as np
    def arccos2(vector, value):
        dot_product = np.dot(vector, np.array([1, 0]))
        det = np.linalg.det(np.array([[vector[0], vector[1]], [1, 0]]))
        angle = np.arctan2(det, dot_product)
        if np.abs(angle) > np.pi / 2 and value > 0:
            angle = np.pi - angle
        elif np.abs(angle) > np.pi / 2 and value < 0:
            angle = -np.pi - angle
        return angle
