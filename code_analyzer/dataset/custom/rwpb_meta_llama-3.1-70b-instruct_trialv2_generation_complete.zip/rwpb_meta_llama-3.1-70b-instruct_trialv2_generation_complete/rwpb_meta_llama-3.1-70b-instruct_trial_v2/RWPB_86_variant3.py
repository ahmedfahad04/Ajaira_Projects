
def inverse_sigmoid(x):
    import torch
    def inverse_sigmoid(x):
        return -torch.log(1 / x - 1)
