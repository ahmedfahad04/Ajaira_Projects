
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        if padding:
            h, w = shape
            masks = F.adaptive_avg_pool2d(masks, (h, w))
        else:
            masks = F.interpolate(masks, size=shape, mode='bilinear', align_corners=False)
        return masks
