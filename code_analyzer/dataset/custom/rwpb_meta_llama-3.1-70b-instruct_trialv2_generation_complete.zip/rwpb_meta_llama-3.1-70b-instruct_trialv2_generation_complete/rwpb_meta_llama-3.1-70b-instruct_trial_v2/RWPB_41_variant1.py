
def merge_short_sentences_en(sens):
    def merge_short_sentences_en(sens):
        result = []
        short_sentence = ""
        for sentence in sens:
            if len(sentence.split()) < 5 and short_sentence:
                result.append(short_sentence + " " + sentence)
                short_sentence = ""
            elif len(sentence.split()) < 5:
                short_sentence = sentence
            else:
                if short_sentence:
                    result.append(short_sentence)
                    short_sentence = ""
                result.append(sentence)
        if short_sentence:
            if result:
                result[-1] += " " + short_sentence
            else:
                result.append(short_sentence)
        return result
