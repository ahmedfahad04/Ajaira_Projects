
def fuse_deconv_and_bn(deconv, bn):
    def fuse_deconv_and_bn(deconv, bn):
        fused_conv = torch.nn.ConvTranspose2d(deconv.in_channels, deconv.out_channels, deconv.kernel_size, 
                                             deconv.stride, deconv.padding, deconv.output_padding, 
                                             deconv.groups, deconv.bias is not None, deconv.dilation)
        fused_conv.weight.data = deconv.weight * bn.weight[:, None, None, None] / (bn.running_var + bn.eps)**0.5
        if deconv.bias is not None:
            fused_conv.bias.data = (deconv.bias - bn.running_mean) / (bn.running_var + bn.eps)**0.5 * bn.weight + bn.bias
        else:
            fused_conv.bias.data = (bn.bias - bn.running_mean) / (bn.running_var + bn.eps)**0.5 * bn.weight
        return fused_conv
