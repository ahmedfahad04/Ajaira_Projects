
def clean_html(:
    import re
    from html.parser import HTMLParser
    from typing import List
    class HTMLCleaner(HTMLParser):
        def __init__(self, tags_to_remove, attributes_to_keep):
            super().__init__()
            self.tags_to_remove = tags_to_remove
            self.attributes_to_keep = attributes_to_keep
            self.result = []
        def handle_starttag(self, tag, attrs):
            if tag not in self.tags_to_remove:
                attrs = [(key, value) for key, value in attrs if key in self.attributes_to_keep]
                self.result.append(f'<{tag} {" ".join(f"{key}={value}" for key, value in attrs)}>')
        def handle_endtag(self, tag):
            if tag not in self.tags_to_remove:
                self.result.append(f'</{tag}>')
        def handle_data(self, data):
            self.result.append(data)
    def clean_html(html_to_clean: str, tags_to_remove: List[str] = ["style", "svg", "script"], attributes_to_keep: List[str] = ["id", "href"]) -> str:
        parser = HTMLCleaner(tags_to_remove, attributes_to_keep)
        parser.feed(html_to_clean)
        return ''.join(parser.result)
