
def dynamic_import_function(function_path):
    def dynamic_import_function(function_path):
        try:
            spec = importlib.util.find_spec(function_path)
            if spec is None:
                raise ModuleNotFoundError(f"No module named '{function_path}'")
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            return module
        except ImportError:
            raise ModuleNotFoundError(f"Failed to import function '{function_path}'")
