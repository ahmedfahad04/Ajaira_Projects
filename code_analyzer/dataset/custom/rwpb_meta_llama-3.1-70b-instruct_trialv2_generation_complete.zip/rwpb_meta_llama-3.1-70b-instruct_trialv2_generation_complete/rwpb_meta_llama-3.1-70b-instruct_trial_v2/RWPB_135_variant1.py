
def mask_iou(mask1, mask2, eps=1e-7):
    def mask_iou(mask1, mask2, eps=1e-7):
        intersection = torch.matmul(mask1, mask2.T)
        union = (mask1.sum(1, keepdim=True) + mask2.sum(1, keepdim=True).T) - intersection
        return intersection / (union + eps)
