
def exp_smooth(vals, alpha):
    import numpy as np
    from functools import reduce
    def exp_smooth(vals, alpha):
        if len(vals) == 0:
            raise KeyError("Input array is empty")
        def smooth(prev, val):
            return alpha * val + (1 - alpha) * prev
        smoothed = np.array([vals[0]] + list(reduce(lambda x, val: x + [smooth(x[-1], val)], vals[1:], [])))
        return smoothed
