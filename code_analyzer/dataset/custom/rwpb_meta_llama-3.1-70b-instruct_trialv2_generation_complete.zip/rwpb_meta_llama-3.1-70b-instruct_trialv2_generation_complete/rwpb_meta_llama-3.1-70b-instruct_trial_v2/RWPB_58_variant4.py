
def unpad_image_shape(current_height, current_width, original_size):
    def unpad_image_shape(current_height, current_width, original_size):
        original_width, original_height = original_size
        original_aspect_ratio = original_width / original_height
        current_aspect_ratio = current_width / current_height
        scale_factor_width = current_width / original_width
        scale_factor_height = current_height / original_height
        if scale_factor_width > scale_factor_height:
            new_height = round(original_height * scale_factor_width)
            return new_height, current_width
        else:
            new_width = round(original_width * scale_factor_height)
            return current_height, new_width
