
def last_before(val, arr):
    def last_before(val, arr):
        idx = np.searchsorted(arr, val, side='left') - 1
        if idx >= 0 and arr[idx] <= val:
            return idx
        else:
            return -1
