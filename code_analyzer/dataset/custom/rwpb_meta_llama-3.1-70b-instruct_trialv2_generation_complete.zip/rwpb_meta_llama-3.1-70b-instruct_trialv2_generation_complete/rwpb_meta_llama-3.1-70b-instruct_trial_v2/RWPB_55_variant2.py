
def numpy_to_pytorch(x):
    def numpy_to_pytorch(x):
        x = x.astype(np.float32, copy=False)
        x = x / 255.0
        x = np.atleast_1d(x)
        x = np.atleast_2d(x)
        x = torch.tensor(x, dtype=torch.float32)
        return x
