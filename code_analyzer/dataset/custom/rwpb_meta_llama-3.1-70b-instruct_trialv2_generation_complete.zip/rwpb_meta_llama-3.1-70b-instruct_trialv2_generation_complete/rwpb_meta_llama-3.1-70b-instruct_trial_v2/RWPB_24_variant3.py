
def check(x, checksum_token):
    def check(x, checksum_token):
        pattern = r'\b[0-9a-f]{64}\b'
        for match in re.finditer(pattern, x):
            original_checksum = match.group()
            new_string = re.sub(pattern, checksum_token, x)
            hash_object = hashlib.sha256(new_string.encode())
            if hash_object.hexdigest() == original_checksum:
                return True
        return False
