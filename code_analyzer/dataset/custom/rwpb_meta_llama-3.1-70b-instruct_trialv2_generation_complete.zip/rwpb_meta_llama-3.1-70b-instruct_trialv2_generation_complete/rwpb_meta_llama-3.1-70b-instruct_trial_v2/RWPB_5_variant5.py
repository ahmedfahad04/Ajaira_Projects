
def seconds_to_hh_mm_ss(seconds):
    def seconds_to_hh_mm_ss(seconds):
        if seconds < 0:
            return "00:00:00"
        time_string = "{:02d}:{:02d}:{:02d}"
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        seconds = seconds % 60
        return time_string.format(hours, minutes, seconds)
