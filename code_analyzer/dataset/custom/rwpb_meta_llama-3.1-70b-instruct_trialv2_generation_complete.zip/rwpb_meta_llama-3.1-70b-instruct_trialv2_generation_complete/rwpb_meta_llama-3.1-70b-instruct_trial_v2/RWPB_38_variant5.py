
def extract_imports_from_lines(lines: List[str]) -> str:
    def extract_imports_from_lines(lines: List[str]) -> str:
        def is_import(line):
            return line.strip().startswith(('import', 'from'))
        import_lines = list(filter(is_import, lines))
        return '\n'.join(map(str.strip, import_lines))
