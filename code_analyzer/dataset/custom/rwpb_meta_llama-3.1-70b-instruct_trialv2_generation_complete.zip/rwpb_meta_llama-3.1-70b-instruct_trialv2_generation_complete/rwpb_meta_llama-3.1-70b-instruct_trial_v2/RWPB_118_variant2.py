
def filter_nan(ts, vs):
    def filter_nan(ts, vs):
        indices = np.where(~np.isnan(ts))[0]
        return ts[indices], vs[indices]
