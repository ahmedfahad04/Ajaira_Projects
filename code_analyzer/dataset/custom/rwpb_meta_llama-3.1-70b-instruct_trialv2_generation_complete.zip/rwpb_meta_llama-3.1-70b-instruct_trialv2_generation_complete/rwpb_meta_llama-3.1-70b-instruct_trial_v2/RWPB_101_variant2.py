
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    def generate_grids(lower_limit, upper_limit, grid_size):
        num_dims = len(lower_limit)
        lower_bounds = []
        upper_bounds = []
        for i in range(num_dims):
            step = (upper_limit[i] - lower_limit[i]) / grid_size[i]
            lower_bound = lower_limit[i] + torch.arange(grid_size[i]) * step
            upper_bound = lower_bound + step
            lower_bounds.append(lower_bound[:-1])
            upper_bounds.append(upper_bound[1:])
        lower_bounds = torch.stack(torch.meshgrid(lower_bounds), dim=-1)
        upper_bounds = torch.stack(torch.meshgrid(upper_bounds), dim=-1)
        return lower_bounds, upper_bounds
