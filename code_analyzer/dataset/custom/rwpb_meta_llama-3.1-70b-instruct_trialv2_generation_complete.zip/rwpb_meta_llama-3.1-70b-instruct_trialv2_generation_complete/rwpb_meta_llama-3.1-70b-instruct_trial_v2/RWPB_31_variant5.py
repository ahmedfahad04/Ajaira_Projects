
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        current_batch_size = tensor.shape[0]
        if current_batch_size == batch_size:
            return tensor
        else:
            return tensor.take(torch.arange(batch_size) % current_batch_size)
