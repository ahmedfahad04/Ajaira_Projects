
def exp_smooth(vals, alpha):
    import numpy as np
    def exp_smooth(vals, alpha):
        if len(vals) == 0:
            raise KeyError("Input array is empty")
        smoothed = [vals[0]]
        for val in vals[1:]:
            smoothed.append(alpha * val + (1 - alpha) * smoothed[-1])
        return np.array(smoothed)
