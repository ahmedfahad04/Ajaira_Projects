
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        if upcast:
            x = x.to(torch.float32)
            weight = weight.to(torch.float32)
            if bias is not None:
                bias = bias.to(torch.float32)
            if residual is not None:
                residual = residual.to(torch.float32)
        x_squared = x ** 2
        x_mean_squared = torch.mean(x_squared, dim=-1, keepdim=True)
        norm = torch.sqrt(x_mean_squared + eps)
        normalized = x / norm
        output = torch.nn.functional.linear(normalized, weight, bias=bias)
        if residual is not None:
            output = output + residual
        if prenorm:
            return output, x
        else:
            return output
