
def get_confusion_matrix(gt_label, pred_label, num_classes):
    def get_confusion_matrix(gt_label, pred_label, num_classes):
        if len(gt_label) != len(pred_label):
            raise ValueError("The length of gt_label is not equal to the length of pred_label")
        return np.array([[sum((gt_label==i) & (pred_label==j)) for j in range(num_classes)] for i in range(num_classes)])
