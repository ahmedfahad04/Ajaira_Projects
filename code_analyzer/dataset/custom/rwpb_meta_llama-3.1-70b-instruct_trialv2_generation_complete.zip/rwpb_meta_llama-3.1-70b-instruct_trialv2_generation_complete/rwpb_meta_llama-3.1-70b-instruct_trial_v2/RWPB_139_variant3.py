
def rotate_normalmap_by_angle_torch(normal_map, angle):
    import torch
    import math
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        angle_rad = math.radians(angle)
        cos_angle = math.cos(angle_rad)
        sin_angle = math.sin(angle_rad)
        x, y, z = normal_map.unbind(dim=-1)
        new_x = x * cos_angle - z * sin_angle
        new_z = x * sin_angle + z * cos_angle
        return torch.stack([new_x, y, new_z], dim=-1)
