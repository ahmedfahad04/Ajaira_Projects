
def getLambertCoefs(numOfLambertCoefs):
    from math import factorial
    def getLambertCoefs(numOfLambertCoefs):
        lambert_coefs = []
        fact = 1
        for i in range(1, numOfLambertCoefs + 1):
            fact *= i
            coef = (fact * (i + 1) - 1) // i
            lambert_coefs.append(coef)
        return lambert_coefs
