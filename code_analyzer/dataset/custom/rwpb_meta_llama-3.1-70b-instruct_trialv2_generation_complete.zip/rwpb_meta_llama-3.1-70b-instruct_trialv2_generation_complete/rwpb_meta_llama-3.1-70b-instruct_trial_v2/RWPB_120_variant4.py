
def parity(cycles):
    def parity(cycles):
        from functools import reduce
        from operator import xor
        return reduce(xor, (len(cycle) - 1 for cycle in cycles), 0)
