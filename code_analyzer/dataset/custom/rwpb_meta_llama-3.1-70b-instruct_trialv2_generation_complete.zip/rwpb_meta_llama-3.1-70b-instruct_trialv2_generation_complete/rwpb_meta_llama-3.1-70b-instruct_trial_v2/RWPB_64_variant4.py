
def moving_average(arr, window_size):
    import numpy as np
    from scipy.signal import lfilter
    def moving_average(arr, window_size):
        smoothed = lfilter([1.0 / window_size] * window_size, 1, arr)
        smoothed = smoothed[window_size - 1:]
        residuals = arr[window_size - 1:] - smoothed
        return smoothed, residuals
