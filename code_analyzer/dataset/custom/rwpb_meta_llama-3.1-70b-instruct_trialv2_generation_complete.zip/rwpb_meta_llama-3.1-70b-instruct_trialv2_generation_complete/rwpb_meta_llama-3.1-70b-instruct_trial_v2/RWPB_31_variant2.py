
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        current_batch_size = tensor.shape[0]
        if current_batch_size == batch_size:
            return tensor
        else:
            ratio = batch_size / current_batch_size
            return torch.nn.functional.interpolate(
                tensor.unsqueeze(0), 
                scale_factor=(ratio, 1, 1), 
                mode='trilinear', 
                align_corners=False
            ).squeeze(0)
