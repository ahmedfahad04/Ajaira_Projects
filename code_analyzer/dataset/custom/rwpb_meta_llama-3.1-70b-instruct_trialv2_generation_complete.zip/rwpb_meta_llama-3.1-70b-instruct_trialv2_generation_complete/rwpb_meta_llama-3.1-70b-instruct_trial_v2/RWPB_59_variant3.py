
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        penalty_tensor = torch.ones_like(logits)
        for i, prev_tokens in enumerate(prev_output_tokens):
            for token in prev_tokens:
                penalty_tensor[i, token] *= repetition_penalty
        return logits * penalty_tensor
