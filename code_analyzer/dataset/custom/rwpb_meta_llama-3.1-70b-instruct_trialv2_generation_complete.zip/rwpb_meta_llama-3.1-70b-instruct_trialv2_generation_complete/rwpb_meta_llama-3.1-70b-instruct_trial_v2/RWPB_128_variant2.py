
def xywh2xyxy(x):
    def xywh2xyxy(x):
        if isinstance(x, np.ndarray):
            return np.array([x[:, 0], x[:, 1], x[:, 0] + x[:, 2], x[:, 1] + x[:, 3]]).T
        elif isinstance(x, torch.Tensor):
            return torch.tensor([x[:, 0], x[:, 1], x[:, 0] + x[:, 2], x[:, 1] + x[:, 3]]).T
