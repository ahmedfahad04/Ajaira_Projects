
def exp_smooth(vals, alpha):
    import numpy as np
    def exp_smooth(vals, alpha):
        if len(vals) == 0:
            raise KeyError("Input array is empty")
        smoothed = np.zeros(len(vals))
        smoothed[0] = vals[0]
        smoothed[1:] = alpha * np.array(vals[1:]) + (1 - alpha) * smoothed[:-1]
        return smoothed
