
def reshape_weight_task_tensors(task_tensors, weights):
    def reshape_weight_task_tensors(task_tensors, weights):
        return weights.view(*([1] * (len(task_tensors.shape) - len(weights.shape))), *weights.shape)
