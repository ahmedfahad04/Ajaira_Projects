
def make_even_first_dim(tensor):
    def make_even_first_dim(tensor):
        shape = list(tensor.shape)
        if shape[0] % 2 != 0:
            shape[0] -= 1
        return tensor.reshape(shape)
