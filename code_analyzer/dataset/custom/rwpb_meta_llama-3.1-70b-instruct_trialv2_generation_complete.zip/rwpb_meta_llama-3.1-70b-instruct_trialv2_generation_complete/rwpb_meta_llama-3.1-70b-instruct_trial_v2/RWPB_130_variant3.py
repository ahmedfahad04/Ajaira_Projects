
def bbox_ioa(box1, box2, iou=False, eps=1e-7):
    import numpy as np
    def bbox_ioa(box1, box2, iou=False, eps=1e-7):
        inter_x1 = np.maximum(box1[:, 0, None], box2[:, 0])
        inter_y1 = np.maximum(box1[:, 1, None], box2[:, 1])
        inter_x2 = np.minimum(box1[:, 2, None], box2[:, 2])
        inter_y2 = np.minimum(box1[:, 3, None], box2[:, 3])
        inter_area = np.maximum(0, inter_x2 - inter_x1) * np.maximum(0, inter_y2 - inter_y1)
        box2_area = (box2[:, 2] - box2[:, 0]) * (box2[:, 3] - box2[:, 1])
        if iou:
            box1_area = (box1[:, 2] - box1[:, 0]) * (box1[:, 3] - box1[:, 1])
            union_area = box1_area[:, None] + box2_area[None, :] - inter_area
            return inter_area / (union_area + eps)
        else:
            return inter_area / (box2_area + eps)
