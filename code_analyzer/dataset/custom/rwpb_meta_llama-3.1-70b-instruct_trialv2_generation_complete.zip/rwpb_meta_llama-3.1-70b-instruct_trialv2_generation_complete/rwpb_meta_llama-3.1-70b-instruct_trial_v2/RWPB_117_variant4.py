
def path_spliter(path: str):
    def path_spliter(path: str):
        components = []
        current_component = ''
        for char in path:
            if char in ['/', '\\']:
                if current_component:
                    components.append(current_component)
                    current_component = ''
            else:
                current_component += char
        if current_component:
            components.append(current_component)
        return components
