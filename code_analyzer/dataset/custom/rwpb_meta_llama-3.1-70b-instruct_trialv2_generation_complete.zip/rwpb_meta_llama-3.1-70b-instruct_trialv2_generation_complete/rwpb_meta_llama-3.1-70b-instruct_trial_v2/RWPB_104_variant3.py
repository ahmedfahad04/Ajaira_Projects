
def mulMod(x, y, z):
    def mulMod(x, y, z):
        return pow(x * y, 1, z)
