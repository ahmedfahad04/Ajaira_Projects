
def extract_code_from_funct(funct: Callable) -> List[str]:
    import inspect
    from typing import Callable, List
    def extract_code_from_funct(funct: Callable) -> List[str]:
        source = inspect.getsource(funct)
        lines = source.split('\n')
        func_def_line = lines[0]
        indent_level = len(func_def_line) - len(func_def_line.lstrip())
        body_lines = []
        for line in lines[1:]:
            if line.strip() == 'return':
                break
            body_lines.append(line)
        body_lines = [line[indent_level:] for line in body_lines]
        return body_lines
