
def merge_short_sentences_en(sens):
    def merge_short_sentences_en(sens):
        result = []
        temp = ""
        for sentence in sens:
            if len(sentence.split()) < 5:
                temp += sentence + " "
            else:
                if temp:
                    result.append(temp.strip())
                    temp = ""
                result.append(sentence)
        if temp:
            if result:
                result[-1] += " " + temp.strip()
            else:
                result.append(temp.strip())
        return result
