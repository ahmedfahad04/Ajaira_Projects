
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        from scipy.special import comb
        total = comb(len(preds), 2)
        correct = sum(1 for i in range(len(preds)) for j in range(i + 1, len(preds)) if (preds[i] > preds[j] and references[i] > references[j]) or (preds[i] < preds[j] and references[i] < references[j]))
        return correct / total if total > 0 else 0.0
