
def mean(l, ignore_nan=False, empty=0):
    import math
    def mean(l, ignore_nan=False, empty=0):
        sum_val = 0
        count = 0
        for x in l:
            if ignore_nan and math.isnan(x):
                continue
            sum_val += x
            count += 1
        if count == 0:
            if empty == 'raise':
                raise ValueError("Input iterable is empty")
            return empty
        return sum_val / count
