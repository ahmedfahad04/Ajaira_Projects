
def mulMod(x, y, z):
    def mulMod(x, y, z):
        result = 0
        x %= z
        while y > 0:
            result += x * (y % z)
            y //= z
            x *= x
        return result % z
