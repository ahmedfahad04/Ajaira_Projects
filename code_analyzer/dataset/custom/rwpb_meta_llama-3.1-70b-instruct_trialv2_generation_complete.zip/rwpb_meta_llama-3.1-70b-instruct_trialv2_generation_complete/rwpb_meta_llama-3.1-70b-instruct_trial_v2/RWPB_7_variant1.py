
def dynamic_import_function(function_path):
    def dynamic_import_function(function_path):
        module_path, function_name = function_path.rsplit('.', 1)
        try:
            module = importlib.import_module(module_path)
        except ImportError:
            raise ModuleNotFoundError(f"No module named '{module_path}'")
        try:
            return getattr(module, function_name)
        except AttributeError:
            raise ModuleNotFoundError(f"No function named '{function_name}' in module '{module_path}'")
