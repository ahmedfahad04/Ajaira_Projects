
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        grid_x = torch.arange(W).repeat(H, 1)
        grid_y = torch.arange(H).repeat(W, 1).transpose(0, 1)
        grid = torch.stack((grid_x, grid_y), dim=0)
        return grid.unsqueeze(0).expand(B, -1, -1, -1)
