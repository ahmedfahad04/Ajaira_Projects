
def bbox_ioa(box1, box2, iou=False, eps=1e-7):
    import numpy as np
    def bbox_ioa(box1, box2, iou=False, eps=1e-7):
        x1, y1, x2, y2 = np.split(box1, 4, axis=1)
        x3, y3, x4, y4 = np.split(box2, 4, axis=1)
        inter_x1 = np.maximum(x1, x3.T)
        inter_y1 = np.maximum(y1, y3.T)
        inter_x2 = np.minimum(x2, x4.T)
        inter_y2 = np.minimum(y2, y4.T)
        inter_area = np.maximum(0, inter_x2 - inter_x1) * np.maximum(0, inter_y2 - inter_y1)
        box2_area = (x4 - x3) * (y4 - y3)
        result = inter_area / (box2_area + eps)
        if iou:
            box1_area = (x2 - x1) * (y2 - y1)
            union_area = box1_area[:, None] + box2_area[None, :] - inter_area
            result = result * union_area / (union_area + eps)
        return result
