
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        return max(possible_resolutions, key=lambda x: (min(x[0], original_size[0]), min(x[1], original_size[1])))
