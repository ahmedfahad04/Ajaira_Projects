
def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        if upcast:
            x = x.float()
            weight = weight.float()
            bias = bias.float() if bias is not None else None
            residual = residual.float() if residual is not None else None
        def _layer_norm(x, weight, bias, eps):
            mean = x.mean(dim=-1, keepdim=True)
            std = x.std(dim=-1, keepdim=True)
            return (x - mean) / (std + eps) * weight + bias
        output = _layer_norm(x, weight, bias, eps)
        if residual is not None:
            output = output + residual
        if prenorm:
            return output, x
        else:
            return output
