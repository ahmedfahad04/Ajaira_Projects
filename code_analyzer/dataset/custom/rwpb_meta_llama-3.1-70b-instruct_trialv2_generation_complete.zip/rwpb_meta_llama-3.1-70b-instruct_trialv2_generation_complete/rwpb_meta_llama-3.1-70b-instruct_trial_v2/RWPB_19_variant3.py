
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        total = sum(1 for _ in range(len(preds)) for _ in range(_ + 1, len(preds)))
        correct = sum(1 for i in range(len(preds)) for j in range(i + 1, len(preds)) if (preds[i] > preds[j] and references[i] > references[j]) or (preds[i] < preds[j] and references[i] < references[j]))
        return correct / total if total > 0 else 0.0
