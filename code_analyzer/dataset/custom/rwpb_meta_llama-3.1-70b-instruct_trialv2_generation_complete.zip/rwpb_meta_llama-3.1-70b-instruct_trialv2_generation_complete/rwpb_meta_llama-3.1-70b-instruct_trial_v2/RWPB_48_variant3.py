
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        best_resolution = None
        best_ratio = 0
        for resolution in possible_resolutions:
            ratio = min(resolution[0] / original_size[0], resolution[1] / original_size[1])
            if ratio > best_ratio:
                best_ratio = ratio
                best_resolution = resolution
        return best_resolution
