
def rotate_about_x_axis(vector, theta):
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        x, y, z = vector
        new_y = y * np.cos(theta) - z * np.sin(theta)
        new_z = y * np.sin(theta) + z * np.cos(theta)
        return np.array([x, new_y, new_z])
