
def pad_camera_extrinsics_4x4(extrinsics):
    def pad_camera_extrinsics_4x4(extrinsics):
        ones = torch.ones((*extrinsics.shape[:-2], 1, 1), device=extrinsics.device)
        zeros = torch.zeros((*extrinsics.shape[:-2], 1, 3), device=extrinsics.device)
        last_row = torch.cat([zeros, ones], dim=-1)
        return torch.cat([extrinsics, last_row], dim=-2)
