
def is_byte_token(s: str) -> bool:
    def is_byte_token(s: str) -> bool:
        pattern = r'^<0x[0-9A-F]{2}>$'
        import re
        return bool(re.match(pattern, s))
