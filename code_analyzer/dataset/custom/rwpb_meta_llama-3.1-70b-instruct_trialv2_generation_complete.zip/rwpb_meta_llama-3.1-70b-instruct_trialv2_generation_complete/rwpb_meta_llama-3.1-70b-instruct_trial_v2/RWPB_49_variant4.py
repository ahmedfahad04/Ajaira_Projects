
def make_even_first_dim(tensor):
    def make_even_first_dim(tensor):
        dim = tensor.shape[0]
        if dim % 2 != 0:
            dim -= 1
        return tensor.narrow(0, 0, dim)
