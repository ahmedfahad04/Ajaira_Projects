
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        if len(image.shape) not in [2, 3]:
            raise ValueError("Invalid image shape")
        if len(image.shape) == 2:
            image = image[np.newaxis, :, :]
        else:
            image = image.transpose(2, 0, 1)
        return torch.tensor(image, dtype=torch.float) / 255.0
