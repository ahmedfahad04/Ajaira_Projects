
def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        batch_size, num_points, _ = coordinates.shape
        num_planes, _, _ = planes.shape
        # Create a tensor to store the projected points
        projected_points = torch.zeros(batch_size * num_planes, num_points, 2, device=coordinates.device)
        # Iterate over each plane
        for i in range(num_planes):
            # Extract the plane's axes
            x_axis, y_axis, normal = planes[i]
            # Project the points onto the plane's x and y axes
            x_coords = torch.tensordot(coordinates, x_axis, dims=([2], [0]))
            y_coords = torch.tensordot(coordinates, y_axis, dims=([2], [0]))
            # Store the projected points
            projected_points[i * batch_size:(i + 1) * batch_size] = torch.stack([x_coords, y_coords], dim=2)
        # Reshape the projected points to (batch_size * num_planes, num_points, 2)
        projected_points = projected_points.view(batch_size * num_planes, num_points, 2)
        return projected_points
