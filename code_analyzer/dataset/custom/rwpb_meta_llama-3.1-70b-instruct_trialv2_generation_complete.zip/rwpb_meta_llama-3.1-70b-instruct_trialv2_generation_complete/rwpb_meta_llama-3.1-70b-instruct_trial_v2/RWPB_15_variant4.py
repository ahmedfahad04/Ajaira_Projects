
def cosine_distance(a, b):
    import numpy as np
    from scipy import spatial
    def cosine_distance(a, b):
        if len(a) != len(b):
            raise KeyError("Length of a and b must be equal")
        return spatial.distance.cosine(a, b)
