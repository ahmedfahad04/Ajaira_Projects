
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        if np.allclose(a, b):
            return None, None
        v = np.cross(a, b)
        s = np.linalg.norm(v)
        c = np.dot(a, b)
        if s != 0:
            v = v / s
        angle = np.arctan2(s, c)
        return v, angle
