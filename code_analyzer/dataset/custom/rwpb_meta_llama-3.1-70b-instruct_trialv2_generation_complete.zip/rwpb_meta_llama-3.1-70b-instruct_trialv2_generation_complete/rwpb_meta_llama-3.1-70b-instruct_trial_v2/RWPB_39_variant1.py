
def clean_html(:
    import re
    from typing import List
    def clean_html(html_to_clean: str, tags_to_remove: List[str] = ["style", "svg", "script"], attributes_to_keep: List[str] = ["id", "href"]) -> str:
        for tag in tags_to_remove:
            html_to_clean = re.sub(rf'<{tag}.*?>.*?<\/{tag}>', '', html_to_clean, flags=re.DOTALL)
        html_to_clean = re.sub(r'\s+', ' ', html_to_clean)
        html_to_clean = re.sub(r'<([^>]*?)\s+([^>]*?)=(["\'])(.*?)\3([^>]*?)>', lambda m: f'<{m.group(1)} {m.group(2)}={m.group(3)}{m.group(4)}{m.group(3)}>' if m.group(2) in attributes_to_keep else '', html_to_clean)
        html_to_clean = re.sub(r'<([^>]*?)\s+([^>]*?)=(["\'])(.*?)\3>', lambda m: f'<{m.group(1)}>' if m.group(2) not in attributes_to_keep else f'<{m.group(1)} {m.group(2)}={m.group(3)}{m.group(4)}{m.group(3)}>', html_to_clean)
        return html_to_clean
