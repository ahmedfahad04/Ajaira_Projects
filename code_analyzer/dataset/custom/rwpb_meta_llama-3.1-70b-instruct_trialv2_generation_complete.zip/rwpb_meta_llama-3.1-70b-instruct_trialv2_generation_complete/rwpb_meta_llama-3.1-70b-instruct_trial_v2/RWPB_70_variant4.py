
def psnr_to_mse(psnr):
    import math
    def psnr_to_mse(psnr):
        return math.pow(10, -0.1 * psnr)
