
def format_ratio(ratio):
    def format_ratio(ratio):
        return f"percentage:{ratio:.3f}"
