
def numpy_to_pytorch(x):
    def numpy_to_pytorch(x):
        x = np.array(x, dtype=np.float32, ndmin=2)
        x = x / 255.0
        x = np.ascontiguousarray(x)
        x = torch.as_tensor(x)
        return x.float()
