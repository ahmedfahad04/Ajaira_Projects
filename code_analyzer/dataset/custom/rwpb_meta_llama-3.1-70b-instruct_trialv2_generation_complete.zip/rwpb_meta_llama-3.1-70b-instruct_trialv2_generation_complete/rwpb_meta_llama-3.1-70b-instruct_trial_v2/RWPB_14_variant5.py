
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    from math import acos, sqrt
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        if np.allclose(a, b):
            return None, None
        axis = np.cross(a, b)
        if np.allclose(axis, np.zeros(3)):
            axis = None
        else:
            axis = axis / np.linalg.norm(axis)
        dot_product = np.dot(a, b)
        magnitude_a = np.linalg.norm(a)
        magnitude_b = np.linalg.norm(b)
        angle = acos(dot_product / (magnitude_a * magnitude_b))
        return axis, angle
