
def extract_imports_from_lines(lines: List[str]) -> str:
    def extract_imports_from_lines(lines: List[str]) -> str:
        import_statements = []
        for line in lines:
            line = line.strip()
            if line.startswith('import') or line.startswith('from'):
                import_statements.append(line)
        return '\n'.join(import_statements)
