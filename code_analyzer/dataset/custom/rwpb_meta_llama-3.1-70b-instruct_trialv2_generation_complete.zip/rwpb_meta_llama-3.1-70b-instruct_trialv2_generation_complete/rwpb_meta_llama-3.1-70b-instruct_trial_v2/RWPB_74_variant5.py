
def arccos2(vector, value):
    import numpy as np
    def arccos2(vector, value):
        norm = np.linalg.norm(vector)
        if norm == 0:
            raise ValueError("Vector cannot be zero-length")
        unit_vector = vector / norm
        x = unit_vector[0]
        y = unit_vector[1]
        if x == 0:
            if y > 0:
                angle = np.pi / 2
            else:
                angle = 3 * np.pi / 2
        else:
            angle = np.arctan(y / x)
            if x < 0:
                angle += np.pi
        if value < 0:
            angle = np.pi - angle
        return angle
