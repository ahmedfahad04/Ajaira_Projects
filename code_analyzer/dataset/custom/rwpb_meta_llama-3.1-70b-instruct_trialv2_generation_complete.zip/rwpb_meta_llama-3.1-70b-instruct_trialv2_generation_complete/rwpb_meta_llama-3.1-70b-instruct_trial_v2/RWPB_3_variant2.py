
def get_focalLength_from_fieldOfView(fov=60, img_size=512):
    import numpy as np
    def get_focalLength_from_fieldOfView(fov=60, img_size=512):
        return (img_size / 2) / np.tan(np.radians(fov / 2))
