
def round(number, num_decimal_places, leave_int=False):
    def round(number, num_decimal_places, leave_int=False):
        if isinstance(number, int) and not leave_int:
            return number
        return float(format(number, '.{}f'.format(num_decimal_places)))
