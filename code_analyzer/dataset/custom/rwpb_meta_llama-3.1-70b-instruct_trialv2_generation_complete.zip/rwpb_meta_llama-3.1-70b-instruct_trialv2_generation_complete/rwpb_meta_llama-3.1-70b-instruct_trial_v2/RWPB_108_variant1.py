
def norm_grid(v_grid):
    def norm_grid(v_grid):
        B, _, H, W = v_grid.size()
        v_grid = v_grid.view(B, 2, -1)
        v_grid[:, 0, :] = 2 * (v_grid[:, 0, :] - v_grid[:, 0, :].min(dim=1)[0].unsqueeze(1)) / (v_grid[:, 0, :].max(dim=1)[0].unsqueeze(1) - v_grid[:, 0, :].min(dim=1)[0].unsqueeze(1)) - 1
        v_grid[:, 1, :] = 2 * (v_grid[:, 1, :] - v_grid[:, 1, :].min(dim=1)[0].unsqueeze(1)) / (v_grid[:, 1, :].max(dim=1)[0].unsqueeze(1) - v_grid[:, 1, :].min(dim=1)[0].unsqueeze(1)) - 1
        return v_grid.view(B, H, W, 2)
