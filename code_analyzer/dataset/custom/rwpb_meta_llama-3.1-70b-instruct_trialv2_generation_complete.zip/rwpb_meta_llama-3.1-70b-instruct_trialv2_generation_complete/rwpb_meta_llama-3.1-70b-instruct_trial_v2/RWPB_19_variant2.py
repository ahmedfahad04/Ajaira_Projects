
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        import itertools
        pairs = list(itertools.combinations(range(len(preds)), 2))
        total = len(pairs)
        correct = sum(1 for i, j in pairs if (preds[i] > preds[j] and references[i] > references[j]) or (preds[i] < preds[j] and references[i] < references[j]))
        return correct / total if total > 0 else 0.0
