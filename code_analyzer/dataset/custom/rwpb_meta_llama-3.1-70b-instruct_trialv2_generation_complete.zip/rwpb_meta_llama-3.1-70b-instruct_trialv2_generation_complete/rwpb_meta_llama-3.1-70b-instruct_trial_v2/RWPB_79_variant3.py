
def pr_from_grav(grav):
    import numpy as np
    def pr_from_grav(grav):
        x = grav[:, 0]
        y = grav[:, 1]
        z = grav[:, 2]
        pitches = np.arcsin(-z)
        rolls = np.arctan2(-y, x)
        return pitches, rolls
