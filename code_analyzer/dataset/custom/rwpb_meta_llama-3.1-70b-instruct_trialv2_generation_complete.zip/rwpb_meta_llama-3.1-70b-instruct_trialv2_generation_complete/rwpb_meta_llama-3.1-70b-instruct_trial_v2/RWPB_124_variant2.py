
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        if isinstance(divisor, torch.Tensor):
            divisor = int(divisor.max().item())
        return round(x / divisor) * divisor
