
def scale_masks(masks, shape, padding=True):
    import torch
    def scale_masks(masks, shape, padding=True):
        if padding:
            h, w = shape
            masks = F.interpolate(masks, size=(h, w), mode='bilinear', align_corners=False)
        else:
            masks = F.interpolate(masks, size=shape, mode='bilinear', align_corners=False)
        return masks
