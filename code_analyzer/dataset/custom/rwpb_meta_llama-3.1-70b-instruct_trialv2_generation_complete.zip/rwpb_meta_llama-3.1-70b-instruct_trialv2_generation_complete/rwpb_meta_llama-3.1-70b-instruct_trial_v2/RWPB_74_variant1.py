
def arccos2(vector, value):
    import numpy as np
    def arccos2(vector, value):
        angle = np.arccos(value)
        if vector[1] < 0:
            angle = 2 * np.pi - angle
        return angle
