
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        if ignore is not None:
            mask = labels != ignore
            preds = preds[mask]
            labels = labels[mask]
        intersection = torch.logical_and(preds, labels).sum()
        union = torch.logical_or(preds, labels).sum()
        if union == 0:
            return EMPTY * 100
        iou = (intersection / union) * 100
        if per_image:
            return iou.mean()
        else:
            return iou
