
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        current_batch_size = tensor.shape[0]
        if current_batch_size == batch_size:
            return tensor
        elif current_batch_size < batch_size:
            repeat_factor = math.ceil(batch_size / current_batch_size)
            return tensor.repeat(repeat_factor, *([1] * (tensor.ndim - 1)))[:batch_size]
        else:
            return tensor[:batch_size]
