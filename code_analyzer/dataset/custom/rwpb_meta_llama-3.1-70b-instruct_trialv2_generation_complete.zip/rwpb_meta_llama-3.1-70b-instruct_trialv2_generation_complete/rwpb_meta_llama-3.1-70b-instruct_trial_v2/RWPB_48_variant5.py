
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        from scipy.spatial import distance
        return min(possible_resolutions, key=lambda x: distance.euclidean(x, original_size))
