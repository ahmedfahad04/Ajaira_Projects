
def logbessel_I_scipy(nu, z, check = True):
    import torch
    from scipy import special, pi
    def logbessel_I_scipy(nu, z, check = True):
        if check:
            z_nonzero = z != 0
            result = torch.where(z_nonzero, torch.log(torch.tensor(special.iv(nu, z.cpu().numpy()), dtype=torch.float32)), torch.tensor(0.0))
        else:
            result = torch.log(torch.tensor(special.iv(nu, z.cpu().numpy()), dtype=torch.float32))
        return result
