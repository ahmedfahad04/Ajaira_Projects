
def B_batch(x, grid, k=0, extend=True, device="cpu"):
    import torch
    def B_batch(x, grid, k=0, extend=True, device="cpu"):
        num_spline, num_sample = x.shape
        num_grid = grid.shape[1]
        if extend:
            grid = torch.cat((torch.tensor([grid[:, 0]] * k, device=device), grid, torch.tensor([grid[:, -1]] * k, device=device)), dim=1)
        else:
            grid = torch.cat((grid, torch.tensor([grid[:, -1]] * k, device=device)), dim=1)
        grid = grid.unsqueeze(2).repeat(1, 1, num_sample)
        x = x.unsqueeze(1).repeat(1, num_grid + k, 1)
        diff = grid - x
        diff = diff.abs()
        diff[:, k:, :] = diff[:, k:, :].minimum(diff[:, :-k, :])
        diff[:, :-k, :] = diff[:, :-k, :].minimum(diff[:, k:, :])
        result = torch.zeros(num_spline, num_grid + k - 1, num_sample, device=device)
        for i in range(k):
            mask = diff <= i + 1
            result += mask * ((i + 1 - diff) ** (k - 1)) / (k ** (k - 1))
        return result
