
def path_spliter(path: str):
    def path_spliter(path: str):
        return [component for component in path.split('/') if component] + [component for component in path.split('\\') if component]
