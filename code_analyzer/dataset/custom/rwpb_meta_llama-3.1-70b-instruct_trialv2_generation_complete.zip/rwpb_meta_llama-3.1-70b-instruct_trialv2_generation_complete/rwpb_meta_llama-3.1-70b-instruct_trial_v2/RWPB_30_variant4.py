
def get_confusion_matrix(gt_label, pred_label, num_classes):
    def get_confusion_matrix(gt_label, pred_label, num_classes):
        if len(gt_label) != len(pred_label):
            raise ValueError("The length of gt_label is not equal to the length of pred_label")
        confusion_matrix = np.zeros((num_classes, num_classes), dtype=int)
        for i, (gt, pred) in enumerate(zip(gt_label, pred_label)):
            confusion_matrix[gt, pred] += 1
        return confusion_matrix
