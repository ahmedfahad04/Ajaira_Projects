
def interleave(tensor1, tensor2):
    def interleave(tensor1, tensor2):
        return torch.cat((tensor1.unsqueeze(1), tensor2.unsqueeze(1)), dim=1).flatten(0, 1), torch.cat((tensor2.unsqueeze(1), tensor1.unsqueeze(1)), dim=1).flatten(0, 1)
