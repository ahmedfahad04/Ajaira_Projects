
def numpy_to_pytorch(x):
    def numpy_to_pytorch(x):
        x = np.asarray(x, dtype=np.float32)
        x = x / 255.0
        x = np.expand_dims(x, axis=0)
        x = np.ascontiguousarray(x)
        x = torch.from_numpy(x)
        return x.float()
