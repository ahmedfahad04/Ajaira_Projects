
def psnr_to_mse(psnr):
    import numpy as np
    def psnr_to_mse(psnr):
        return np.power(10, -0.1 * psnr)
