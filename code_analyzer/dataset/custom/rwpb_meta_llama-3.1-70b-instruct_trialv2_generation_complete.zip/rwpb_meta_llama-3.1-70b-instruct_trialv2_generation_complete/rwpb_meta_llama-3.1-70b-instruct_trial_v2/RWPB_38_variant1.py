
def extract_imports_from_lines(lines: List[str]) -> str:
    def extract_imports_from_lines(lines: List[str]) -> str:
        imports = [line.strip() for line in lines if line.strip().startswith(('import', 'from'))]
        return '\n'.join(imports)
