
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        smoothed = np.array([np.mean(arr[i:i + window_size]) for i in range(len(arr) - window_size + 1)])
        residuals = np.array([arr[i + window_size - 1] - np.mean(arr[i:i + window_size]) for i in range(len(arr) - window_size + 1)])
        return smoothed, residuals
