
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        h, w = img.shape
        mask = np.zeros((h+2, w+2), dtype=np.uint8)
        mask[1:-1, 1:-1] = img
        cv2.floodFill(mask, None, (0,0), 255)
        mask[1:-1, 1:-1] = cv2.bitwise_xor(mask[1:-1, 1:-1], img)
        return cv2.bitwise_or(img, mask[1:-1, 1:-1])
