
def rotate_x(a, device=None):
    import torch
    def rotate_x(a, device=None):
        if device is None:
            device = torch.device('cpu')
        return torch.tensor([
            [1, 0, 0, 0],
            [0, torch.cos(a), -torch.sin(a), 0],
            [0, torch.sin(a), torch.cos(a), 0],
            [0, 0, 0, 1]
        ], device=device, dtype=torch.float32)
