
def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
    import torch
    def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
        diff = stop - start
        return start + torch.stack([diff * i / (num - 1) for i in range(num)])
