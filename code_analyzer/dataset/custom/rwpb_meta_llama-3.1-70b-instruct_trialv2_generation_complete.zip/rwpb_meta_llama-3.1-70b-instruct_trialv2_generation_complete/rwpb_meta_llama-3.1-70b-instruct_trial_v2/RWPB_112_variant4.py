
def submatrix(matrix, col):
    def submatrix(matrix, col):
        sub_matrix = [[x for j, x in enumerate(row) if j != col] for row in matrix]
        return sub_matrix
