
def resample_segments(segments, n=1000):
    import numpy as np
    def resample_segments(segments, n=1000):
        resampled_segments = []
        for segment in segments:
            x = segment[:, 0]
            y = segment[:, 1]
            dx = x[1:] - x[:-1]
            dy = y[1:] - y[:-1]
            dist = np.sqrt(dx**2 + dy**2)
            dist_cumsum = np.cumsum(dist)
            dist_cumsum = np.insert(dist_cumsum, 0, 0)
            t = dist_cumsum / dist_cumsum[-1]
            t_resampled = np.linspace(0, 1, n)
            x_resampled = np.interp(t_resampled, t, x)
            y_resampled = np.interp(t_resampled, t, y)
            x_resampled = np.convolve(x_resampled, np.ones(n)/n, mode='same')
            y_resampled = np.convolve(y_resampled, np.ones(n)/n, mode='same')
            resampled_segments.append(np.column_stack((x_resampled, y_resampled)))
        return resampled_segments
