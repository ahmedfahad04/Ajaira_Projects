
def resize_and_center_crop(image, target_width, target_height):
    from PIL import Image
    import numpy as np
    def resize_and_center_crop(image, target_width, target_height):
        img = Image.fromarray(image)
        scale = max(target_width / img.width, target_height / img.height)
        new_size = (int(img.width * scale), int(img.height * scale))
        img = img.resize(new_size, Image.LANCZOS)
        left = (img.width - target_width) // 2
        top = (img.height - target_height) // 2
        right = left + target_width
        bottom = top + target_height
        img = img.crop((left, top, right, bottom))
        return np.array(img)
