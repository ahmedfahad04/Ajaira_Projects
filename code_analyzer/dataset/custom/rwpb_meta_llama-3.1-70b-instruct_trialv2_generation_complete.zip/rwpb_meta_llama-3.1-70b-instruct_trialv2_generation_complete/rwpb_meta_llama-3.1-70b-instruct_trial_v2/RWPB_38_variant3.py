
def extract_imports_from_lines(lines: List[str]) -> str:
    def extract_imports_from_lines(lines: List[str]) -> str:
        import_lines = filter(lambda line: line.strip().startswith(('import', 'from')), lines)
        return '\n'.join(map(str.strip, import_lines))
