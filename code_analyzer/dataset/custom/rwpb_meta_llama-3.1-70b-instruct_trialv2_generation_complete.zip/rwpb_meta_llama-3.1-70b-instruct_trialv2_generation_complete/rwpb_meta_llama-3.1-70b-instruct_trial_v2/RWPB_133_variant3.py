
def divide_to_patches(image, patch_size):
    def divide_to_patches(image, patch_size):
        width, height = image.size
        patches = []
        for y in range(0, height, patch_size):
            for x in range(0, width, patch_size):
                box = (x, y, min(x + patch_size, width), min(y + patch_size, height))
                patches.append(image.crop(box))
        return patches
