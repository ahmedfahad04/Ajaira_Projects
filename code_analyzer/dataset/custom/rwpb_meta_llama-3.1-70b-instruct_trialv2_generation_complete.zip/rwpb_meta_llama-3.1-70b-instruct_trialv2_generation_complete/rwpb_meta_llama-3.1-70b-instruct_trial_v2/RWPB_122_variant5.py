
def view_range(x, i, j, shape):
    def view_range(x, i, j, shape):
        if j is None:
            j = len(x.shape)
        i = i % len(x.shape)
        j = j % len(x.shape)
        if i > j:
            raise ValueError("i must be less than or equal to j")
        flattened_size = 1
        for dim in x.shape[i:j]:
            flattened_size *= dim
        flattened_x = x.reshape(*x.shape[:i], flattened_size, *x.shape[j:])
        new_shape = list(flattened_x.shape)
        new_shape[i+1:i+1] = list(shape)
        return flattened_x.view(new_shape)
