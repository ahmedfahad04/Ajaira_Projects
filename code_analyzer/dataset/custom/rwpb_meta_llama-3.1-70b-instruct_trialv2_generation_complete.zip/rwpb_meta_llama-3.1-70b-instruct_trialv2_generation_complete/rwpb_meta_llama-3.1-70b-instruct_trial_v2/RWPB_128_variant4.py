
def xywh2xyxy(x):
    def xywh2xyxy(x):
        if isinstance(x, np.ndarray):
            return np.hstack((x[:, :2], x[:, :2] + x[:, 2:]))
        elif isinstance(x, torch.Tensor):
            return torch.cat((x[:, :2], x[:, :2] + x[:, 2:]), dim=1)
