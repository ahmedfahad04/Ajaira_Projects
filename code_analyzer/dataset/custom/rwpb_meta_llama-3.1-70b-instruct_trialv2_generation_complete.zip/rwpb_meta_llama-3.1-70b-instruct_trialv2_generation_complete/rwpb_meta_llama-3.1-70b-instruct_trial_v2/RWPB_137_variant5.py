
def fit_params(:
    import numpy as np
    from sklearn.linear_model import LinearRegression
    def fit_params(x, y, fun, a_range=(-10, 10), b_range=(-10, 10), grid_number=101, iteration=3, verbose=True):
        a_values = np.random.uniform(a_range[0], a_range[1], grid_number)
        b_values = np.random.uniform(b_range[0], b_range[1], grid_number)
        a_best, b_best, c_best, d_best, r2_best = None, None, None, None, -np.inf
        for a in a_values:
            for b in b_values:
                x_transformed = fun(a * x + b)
                model = LinearRegression()
                model.fit(x_transformed.reshape(-1, 1), y)
                c, d = model.coef_[0], model.intercept_
                y_pred = c * x_transformed + d
                r2 = 1 - np.sum((y - y_pred) ** 2) / np.sum((y - np.mean(y)) ** 2)
                if r2 > r2_best:
                    a_best, b_best, c_best, d_best, r2_best = a, b, c, d, r2
        if verbose:
            print(f'r2 is {r2_best:.6f} ({a_best:.4f}, {b_best:.4f}, {c_best:.4f}, {d_best:.4f})')
        return a_best, b_best, c_best, d_best, r2_best
