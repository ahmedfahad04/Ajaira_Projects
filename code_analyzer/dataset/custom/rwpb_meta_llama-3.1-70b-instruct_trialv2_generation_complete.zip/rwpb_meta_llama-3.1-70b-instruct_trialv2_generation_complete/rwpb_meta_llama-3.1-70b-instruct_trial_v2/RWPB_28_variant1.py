
def mean(l, ignore_nan=False, empty=0):
    import numpy as np
    def mean(l, ignore_nan=False, empty=0):
        l = list(l)
        if not l:
            if empty == 'raise':
                raise ValueError("Input iterable is empty")
            return empty
        if ignore_nan:
            l = [x for x in l if not np.isnan(x)]
        if not l:
            return 0
        return np.mean(l)
