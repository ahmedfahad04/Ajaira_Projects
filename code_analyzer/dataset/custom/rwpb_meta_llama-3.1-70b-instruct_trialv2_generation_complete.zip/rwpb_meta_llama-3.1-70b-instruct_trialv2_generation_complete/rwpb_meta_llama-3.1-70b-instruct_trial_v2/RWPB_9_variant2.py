
def is_byte_token(s: str) -> bool:
    def is_byte_token(s: str) -> bool:
        if len(s) != 5 or s[0] != '<' or s[4] != '>':
            return False
        for char in s[1:4]:
            if not char.isdigit() and not char.upper() in 'ABCDEF':
                return False
        return True
