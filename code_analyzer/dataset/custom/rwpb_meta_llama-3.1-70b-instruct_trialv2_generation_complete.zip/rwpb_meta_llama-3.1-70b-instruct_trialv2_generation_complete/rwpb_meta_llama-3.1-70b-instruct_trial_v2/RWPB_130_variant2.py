
def bbox_ioa(box1, box2, iou=False, eps=1e-7):
    import numpy as np
    def bbox_ioa(box1, box2, iou=False, eps=1e-7):
        x1, y1, x2, y2 = box1.T
        x3, y3, x4, y4 = box2.T
        inter_x1 = np.maximum(x1[:, None], x3[None, :])
        inter_y1 = np.maximum(y1[:, None], y3[None, :])
        inter_x2 = np.minimum(x2[:, None], x4[None, :])
        inter_y2 = np.minimum(y2[:, None], y4[None, :])
        inter_area = np.maximum(0, inter_x2 - inter_x1) * np.maximum(0, inter_y2 - inter_y1)
        box2_area = (x4 - x3) * (y4 - y3)
        if iou:
            box1_area = (x2 - x1) * (y2 - y1)
            union_area = box1_area[:, None] + box2_area[None, :] - inter_area
            return inter_area / (union_area + eps)
        else:
            return inter_area / (box2_area + eps)
