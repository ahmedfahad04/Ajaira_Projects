
def view_range(x, i, j, shape):
    def view_range(x, i, j, shape):
        if j is None:
            j = len(x.shape)
        i = i % len(x.shape)
        j = j % len(x.shape)
        if i > j:
            raise ValueError("i must be less than or equal to j")
        return x.reshape(*x.shape[:i], *shape, *x.shape[j:])
