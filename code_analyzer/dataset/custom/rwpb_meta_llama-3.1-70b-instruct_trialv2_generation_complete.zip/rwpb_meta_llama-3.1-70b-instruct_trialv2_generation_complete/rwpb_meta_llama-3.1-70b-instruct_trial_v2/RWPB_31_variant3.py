
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        current_batch_size = tensor.shape[0]
        if current_batch_size == batch_size:
            return tensor
        else:
            indices = torch.arange(0, batch_size, dtype=torch.float32) / batch_size * current_batch_size
            indices = indices.round().long()
            return tensor[indices]
