
def fovx_to_fovy(fovx, aspect):
    import numpy as np
    def fovx_to_fovy(fovx, aspect):
        tan_half_fovx = np.tan(fovx / 2)
        tan_half_fovy = tan_half_fovx / aspect
        half_fovy = np.arctan(tan_half_fovy)
        return 2 * half_fovy
