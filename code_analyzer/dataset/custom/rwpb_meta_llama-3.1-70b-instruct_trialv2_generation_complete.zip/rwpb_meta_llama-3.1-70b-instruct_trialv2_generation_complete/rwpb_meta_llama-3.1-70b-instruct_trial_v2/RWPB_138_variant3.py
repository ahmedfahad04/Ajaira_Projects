
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        angle_rad = np.deg2rad(angle)
        cos_angle = np.cos(angle_rad)
        sin_angle = np.sin(angle_rad)
        rotated_normal_map = np.zeros_like(normal_map)
        rotated_normal_map[:, :, 0] = cos_angle * normal_map[:, :, 0] + sin_angle * normal_map[:, :, 2]
        rotated_normal_map[:, :, 1] = normal_map[:, :, 1]
        rotated_normal_map[:, :, 2] = -sin_angle * normal_map[:, :, 0] + cos_angle * normal_map[:, :, 2]
        return rotated_normal_map
