
def _ssim(img1, img2, window, window_size, channel, size_average=True):
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        def gaussian_filter(img, window):
            return F.conv2d(img, window, groups=channel)
        mu1 = gaussian_filter(img1, window)
        mu2 = gaussian_filter(img2, window)
        mu1_sq = mu1 ** 2
        mu2_sq = mu2 ** 2
        mu1_mu2 = mu1 * mu2
        sigma1_sq = gaussian_filter(img1 ** 2, window) - mu1_sq
        sigma2_sq = gaussian_filter(img2 ** 2, window) - mu2_sq
        sigma12 = gaussian_filter(img1 * img2, window) - mu1_mu2
        C1 = 0.01 ** 2
        C2 = 0.03 ** 2
        ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))
        if size_average:
            return ssim_map.mean()
        else:
            return ssim_map.mean(1).mean(1).mean(1)
