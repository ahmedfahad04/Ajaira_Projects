
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        result = {}
        stack = [(d, parent_key)]
        while stack:
            curr_dict, parent_key = stack.pop()
            for key, value in curr_dict.items():
                new_key = f"{parent_key}{sep}{key}" if parent_key else key
                if isinstance(value, dict):
                    stack.append((value, new_key))
                else:
                    result[new_key] = value
        return result
