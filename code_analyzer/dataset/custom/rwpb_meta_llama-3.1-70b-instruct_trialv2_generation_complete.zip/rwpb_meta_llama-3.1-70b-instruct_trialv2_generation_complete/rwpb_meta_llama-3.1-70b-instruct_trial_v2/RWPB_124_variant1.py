
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        if isinstance(divisor, torch.Tensor):
            divisor = divisor.max().item()
        return math.ceil(x / divisor) * divisor
