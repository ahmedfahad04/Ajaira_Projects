
def round_nearest_multiple(number, a, direction='standard'):
    def round_nearest_multiple(number, a, direction='standard'):
        quotient, remainder = divmod(number, a)
        if direction == 'standard':
            if remainder >= a / 2:
                return (quotient + 1) * a
            else:
                return quotient * a
        elif direction == 'down':
            return quotient * a
        elif direction == 'up':
            return (quotient + 1) * a
        else:
            raise ValueError("Invalid direction")
