
def compute_tri_normal(geometry, tris):
    def compute_tri_normal(geometry, tris):
        batch_size, num_points, _ = geometry.shape
        num_tris, _ = tris.shape
        # Repeat the geometry tensor for each triangle
        geometry = geometry[:, None, :, :].repeat(1, num_tris, 1, 1)
        # Get the vertex indices for each triangle
        v0 = geometry[torch.arange(batch_size)[:, None, None], torch.arange(num_tris)[None, :, None], tris[None, :, 0]][:, :, None, :]
        v1 = geometry[torch.arange(batch_size)[:, None, None], torch.arange(num_tris)[None, :, None], tris[None, :, 1]][:, :, None, :]
        v2 = geometry[torch.arange(batch_size)[:, None, None], torch.arange(num_tris)[None, :, None], tris[None, :, 2]][:, :, None, :]
        # Compute the normal vectors
        normals = torch.cross(v1 - v0, v2 - v0, dim=3)
        normals = normals / torch.norm(normals, dim=3, keepdim=True)
        return normals
