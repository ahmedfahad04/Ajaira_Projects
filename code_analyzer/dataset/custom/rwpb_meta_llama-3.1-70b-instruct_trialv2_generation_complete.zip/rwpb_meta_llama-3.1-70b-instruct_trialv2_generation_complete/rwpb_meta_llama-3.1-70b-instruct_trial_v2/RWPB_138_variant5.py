
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    from scipy.linalg import block_diag
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        angle_rad = np.deg2rad(angle)
        rotation_matrix = np.array([
            [np.cos(angle_rad), 0, np.sin(angle_rad)],
            [0, 1, 0],
            [-np.sin(angle_rad), 0, np.cos(angle_rad)]
        ])
        repeated_rotation_matrix = block_diag(*[rotation_matrix] * (normal_map.shape[0] * normal_map.shape[1]))
        flattened_normal_map = normal_map.reshape(-1, 3)
        rotated_flattened_normal_map = np.dot(flattened_normal_map, rotation_matrix)
        return rotated_flattened_normal_map.reshape(normal_map.shape)
