
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        x, y, x1, y1 = box
        cx, cy = (x + x1) / 2, (y + y1) / 2
        w, h = x1 - x, y1 - y
        new_box = [
            cx - (w * expand) / 2,
            cy - (h * expand) / 2,
            cx + (w * expand) / 2,
            cy + (h * expand) / 2,
        ]
        s = (new_box[2] - new_box[0] + new_box[3] - new_box[1]) / 4
        return new_box, s
