
def norm_grid(v_grid):
    def norm_grid(v_grid):
        B, _, H, W = v_grid.size()
        v_grid_min = v_grid.view(B, 2, -1).min(dim=2)[0].unsqueeze(2).unsqueeze(3)
        v_grid_max = v_grid.view(B, 2, -1).max(dim=2)[0].unsqueeze(2).unsqueeze(3)
        return 2 * (v_grid - v_grid_min) / (v_grid_max - v_grid_min) - 1
