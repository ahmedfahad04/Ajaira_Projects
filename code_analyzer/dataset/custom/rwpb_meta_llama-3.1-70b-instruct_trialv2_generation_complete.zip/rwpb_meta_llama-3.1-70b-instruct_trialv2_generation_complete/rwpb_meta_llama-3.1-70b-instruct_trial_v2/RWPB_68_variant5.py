
def last_before(val, arr):
    def last_before(val, arr):
        from bisect import bisect_left
        idx = bisect_left(arr, val)
        if idx > 0 and arr[idx - 1] <= val:
            return idx - 1
        elif idx < len(arr) and arr[idx] <= val:
            return idx
        else:
            return -1
