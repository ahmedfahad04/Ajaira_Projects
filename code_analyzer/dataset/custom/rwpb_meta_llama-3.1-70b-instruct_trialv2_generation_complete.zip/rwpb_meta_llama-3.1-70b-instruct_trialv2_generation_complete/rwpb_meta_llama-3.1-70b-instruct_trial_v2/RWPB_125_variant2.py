
def resample_segments(segments, n=1000):
    import numpy as np
    from scipy.interpolate import interp1d
    def resample_segments(segments, n=1000):
        resampled_segments = []
        for segment in segments:
            t = np.linspace(0, 1, len(segment))
            f_x = interp1d(t, segment[:, 0])
            f_y = interp1d(t, segment[:, 1])
            t_resampled = np.linspace(0, 1, n)
            x_resampled = f_x(t_resampled)
            y_resampled = f_y(t_resampled)
            resampled_segments.append(np.column_stack((x_resampled, y_resampled)))
        return resampled_segments
