
def unsafeSub(x, y):
    def unsafeSub(x, y):
        if x < y:
            return MAX_VAL - (y - x - 1)
        else:
            return x - y
