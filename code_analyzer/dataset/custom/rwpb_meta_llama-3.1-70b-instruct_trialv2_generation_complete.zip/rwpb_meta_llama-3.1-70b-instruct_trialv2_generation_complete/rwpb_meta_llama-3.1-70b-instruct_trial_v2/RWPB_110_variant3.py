
def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
    import numpy as np
    def find_intersection(plane_normal, plane_point, ray_direction, ray_point):
        denominator = np.dot(plane_normal, ray_direction)
        if denominator == 0:
            return None
        t = np.dot(plane_normal, plane_point - ray_point) / denominator
        intersection = ray_point + t * ray_direction
        return intersection if t >= 0 else None
