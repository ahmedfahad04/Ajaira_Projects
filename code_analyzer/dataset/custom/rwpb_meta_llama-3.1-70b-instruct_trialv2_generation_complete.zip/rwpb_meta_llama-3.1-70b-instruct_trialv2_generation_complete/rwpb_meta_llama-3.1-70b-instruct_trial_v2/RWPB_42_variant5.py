
def resize_and_center_crop(image, target_width, target_height):
    from PIL import Image
    import numpy as np
    def resize_and_center_crop(image, target_width, target_height):
        img = Image.fromarray(image)
        width, height = img.size
        scale = max(target_width / width, target_height / height)
        new_size = (int(width * scale), int(height * scale))
        img = img.resize(new_size, Image.LANCZOS)
        left = max(0, (new_size[0] - target_width) // 2)
        top = max(0, (new_size[1] - target_height) // 2)
        right = min(new_size[0], left + target_width)
        bottom = min(new_size[1], top + target_height)
        img = img.crop((left, top, right, bottom))
        return np.array(img)
