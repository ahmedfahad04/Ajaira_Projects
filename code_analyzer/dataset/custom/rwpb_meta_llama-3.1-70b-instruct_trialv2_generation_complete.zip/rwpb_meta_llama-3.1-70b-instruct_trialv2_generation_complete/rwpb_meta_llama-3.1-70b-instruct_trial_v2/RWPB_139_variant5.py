
def rotate_normalmap_by_angle_torch(normal_map, angle):
    import torch
    import math
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        angle_rad = math.radians(angle)
        cos_angle = math.cos(angle_rad)
        sin_angle = math.sin(angle_rad)
        x, y, z = torch.unbind(normal_map, dim=-1)
        new_x = torch.cos(angle_rad) * x - torch.sin(angle_rad) * z
        new_z = torch.sin(angle_rad) * x + torch.cos(angle_rad) * z
        return torch.stack([new_x, y, new_z], dim=-1)
