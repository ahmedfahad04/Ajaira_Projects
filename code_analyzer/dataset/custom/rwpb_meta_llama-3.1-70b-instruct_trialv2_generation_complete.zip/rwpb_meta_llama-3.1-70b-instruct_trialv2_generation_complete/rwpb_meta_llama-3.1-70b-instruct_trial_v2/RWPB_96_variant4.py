
def movmean(arr, n_avg):
    def movmean(arr, n_avg):
        if n_avg > len(arr):
            return np.array([])
        mov_avg = np.zeros(len(arr)-n_avg+1)
        for i in range(len(arr)-n_avg+1):
            mov_avg[i] = np.sum(arr[i:i+n_avg]) / n_avg
        return mov_avg
