
def remove_scale_from_camera_pose(pose_matrix):
    import numpy as np
    def remove_scale_from_camera_pose(pose_matrix):
        scale = np.sqrt(np.sum(pose_matrix[:3, :3]**2))
        pose_matrix[:3, :3] /= scale
        pose_matrix[:3, 3] /= scale
        return pose_matrix
