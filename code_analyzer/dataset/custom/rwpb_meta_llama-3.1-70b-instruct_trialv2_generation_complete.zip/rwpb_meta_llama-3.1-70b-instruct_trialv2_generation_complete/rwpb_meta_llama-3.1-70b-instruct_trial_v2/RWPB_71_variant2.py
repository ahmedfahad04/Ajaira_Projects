
def getLambertCoefs(numOfLambertCoefs):
    from math import factorial
    def getLambertCoefs(numOfLambertCoefs):
        lambert_coefs = [(factorial(i + 1) - 1) // i for i in range(1, numOfLambertCoefs + 1)]
        return lambert_coefs
