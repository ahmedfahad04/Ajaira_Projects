
def round(number, num_decimal_places, leave_int=False):
    def round(number, num_decimal_places, leave_int=False):
        if isinstance(number, int) and not leave_int:
            return number
        decimal_value = Decimal(str(number))
        if num_decimal_places == 0:
            return int(decimal_value.to_integral_value(rounding=ROUND_HALF_UP))
        return float(decimal_value.quantize(Decimal('0.' + '0' * num_decimal_places), rounding=ROUND_HALF_UP))
