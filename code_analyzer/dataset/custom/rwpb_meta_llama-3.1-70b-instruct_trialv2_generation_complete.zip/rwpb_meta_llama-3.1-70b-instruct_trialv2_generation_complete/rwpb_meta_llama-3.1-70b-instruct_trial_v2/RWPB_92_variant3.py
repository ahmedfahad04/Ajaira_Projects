
def round(number, num_decimal_places, leave_int=False):
    def round(number, num_decimal_places, leave_int=False):
        if isinstance(number, int) and not leave_int:
            return number
        multiplier = 10 ** num_decimal_places
        return float(int(number * multiplier + 0.5) / multiplier)
