
def merge_short_sentences_en(sens):
    def merge_short_sentences_en(sens):
        result = []
        short_sentences = [sentence for sentence in sens if len(sentence.split()) < 5]
        long_sentences = [sentence for sentence in sens if len(sentence.split()) >= 5]
        i = 0
        j = 0
        while i < len(short_sentences) and j < len(long_sentences):
            result.append(short_sentences[i] + " " + long_sentences[j])
            i += 1
            j += 1
        result.extend(long_sentences[j:])
        if i < len(short_sentences):
            result.append(short_sentences[i])
        return result
