
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        smoothed = np.zeros(len(arr) - window_size + 1)
        residuals = np.zeros(len(arr) - window_size + 1)
        for i in range(len(arr) - window_size + 1):
            window = arr[i:i + window_size]
            avg = np.mean(window)
            smoothed[i] = avg
            residuals[i] = arr[i + window_size - 1] - avg
        return smoothed, residuals
