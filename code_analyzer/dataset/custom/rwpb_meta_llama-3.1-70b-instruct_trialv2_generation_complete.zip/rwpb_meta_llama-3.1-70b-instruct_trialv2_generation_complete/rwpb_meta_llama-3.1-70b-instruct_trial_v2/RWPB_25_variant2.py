
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        h, w = img.shape
        mask = np.zeros((h+2, w+2), dtype=np.uint8)
        for i in range(1, h+1):
            for j in range(1, w+1):
                if img[i-1, j-1] == 0:
                    cv2.floodFill(img, mask, (j, i), 255)
        return cv2.bitwise_or(img, mask[1:-1, 1:-1])
