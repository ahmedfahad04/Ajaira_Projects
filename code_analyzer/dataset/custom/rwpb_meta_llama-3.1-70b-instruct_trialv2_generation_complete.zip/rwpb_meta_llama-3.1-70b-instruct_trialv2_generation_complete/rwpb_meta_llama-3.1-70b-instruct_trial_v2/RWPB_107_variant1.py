
def pad_camera_extrinsics_4x4(extrinsics):
    def pad_camera_extrinsics_4x4(extrinsics):
        shape = extrinsics.shape
        padded_extrinsics = torch.zeros((*shape[:-2], 4, 4), device=extrinsics.device)
        padded_extrinsics[..., :3, :] = extrinsics
        padded_extrinsics[..., 3, 3] = 1.0
        return padded_extrinsics
