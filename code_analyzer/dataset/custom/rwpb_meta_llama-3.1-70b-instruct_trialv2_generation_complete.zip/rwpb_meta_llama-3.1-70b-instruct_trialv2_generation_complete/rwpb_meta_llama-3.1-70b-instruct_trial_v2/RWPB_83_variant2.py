
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        min_height, min_width = size
        height, width = sample["image"].shape[:2]
        scale = min(min_height / height, min_width / width) if min(height, width) < min(min_height, min_width) else 1
        new_size = (int(height * scale), int(width * scale))
        sample["image"] = cv2.resize(sample["image"], new_size, interpolation=image_interpolation_method)
        sample["disparity"] = cv2.resize(sample["disparity"], new_size, interpolation=cv2.INTER_NEAREST)
        sample["mask"] = cv2.resize(sample["mask"], new_size, interpolation=cv2.INTER_NEAREST)
        return new_size
