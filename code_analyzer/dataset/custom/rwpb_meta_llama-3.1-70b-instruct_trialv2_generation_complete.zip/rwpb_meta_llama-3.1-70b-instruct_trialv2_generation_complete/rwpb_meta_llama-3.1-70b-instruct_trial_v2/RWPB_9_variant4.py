
def is_byte_token(s: str) -> bool:
    def is_byte_token(s: str) -> bool:
        if len(s) == 5 and s.startswith('<') and s.endswith('>'):
            try:
                int(s[1:4], 16)
                return True
            except ValueError:
                pass
        return False
