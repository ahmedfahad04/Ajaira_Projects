
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        try:
            if len(image.shape) == 2:
                image = image[np.newaxis, :, :]
            elif len(image.shape) == 3:
                image = image.transpose(2, 0, 1)
            else:
                raise ValueError
        except ValueError:
            raise ValueError("Invalid image shape")
        return torch.from_numpy(image).to(dtype=torch.float) / 255.0
