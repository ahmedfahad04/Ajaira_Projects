
def extract_code_from_funct(funct: Callable) -> List[str]:
    import inspect
    from typing import Callable, List
    def extract_code_from_funct(funct: Callable) -> List[str]:
        source = inspect.getsource(funct)
        lines = source.split('\n')
        start_idx = 1
        end_idx = len(lines) - 1
        while lines[end_idx].strip() == 'return':
            end_idx -= 1
        func_def_line = lines[0]
        indent_level = len(func_def_line) - len(func_def_line.lstrip())
        lines = lines[start_idx:end_idx+1]
        lines = [line[indent_level:] for line in lines]
        return lines
