
def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
    import torch
    def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
        tensor = torch.empty(num, *start.shape)
        for i in range(num):
            tensor[i] = start + (stop - start) * i / (num - 1)
        return tensor
