
def validate_user_id(user_id):
    import re
    def validate_user_id(user_id):
        return bool(re.fullmatch(r'[a-zA-Z][\w]*', user_id))
