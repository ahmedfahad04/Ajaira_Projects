
def get_focalLength_from_fieldOfView(fov=60, img_size=512):
    import math
    def get_focalLength_from_fieldOfView(fov=60, img_size=512):
        diagonal = math.sqrt(2 * img_size**2)
        return (diagonal / 2) / math.tan(math.radians(fov / 2))
