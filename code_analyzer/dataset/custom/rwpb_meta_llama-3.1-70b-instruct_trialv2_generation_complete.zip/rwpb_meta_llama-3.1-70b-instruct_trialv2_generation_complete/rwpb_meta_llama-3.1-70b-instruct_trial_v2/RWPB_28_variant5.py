
def mean(l, ignore_nan=False, empty=0):
    import functools
    def mean(l, ignore_nan=False, empty=0):
        if ignore_nan:
            l = (x for x in l if not (x != x))  # filter out NaN
        sum_val = functools.reduce(lambda x, y: x + y, l, 0)
        count = sum(1 for _ in l)
        if count == 0:
            if empty == 'raise':
                raise ValueError("Input iterable is empty")
            return empty
        return sum_val / count
