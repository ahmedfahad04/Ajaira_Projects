
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        if isinstance(divisor, torch.Tensor):
            divisor = int(divisor.max().item())
        lower = math.floor(x / divisor) * divisor
        upper = math.ceil(x / divisor) * divisor
        if abs(x - lower) < abs(x - upper):
            return lower
        else:
            return upper
