
def mask_iou(mask1, mask2, eps=1e-7):
    def mask_iou(mask1, mask2, eps=1e-7):
        intersection = torch.matmul(mask1, mask2.T)
        area1 = mask1.sum(1, keepdim=True)
        area2 = mask2.sum(1, keepdim=True).T
        union = area1 + area2 - intersection
        return intersection / (union + eps)
