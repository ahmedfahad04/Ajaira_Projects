
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        if len(image.shape) == 3:
            image = image.transpose(2, 0, 1)
        elif len(image.shape) == 2:
            image = image[np.newaxis, :, :]
        else:
            raise ValueError("Invalid image shape")
        image = image / 255.0
        return torch.from_numpy(image).to(dtype=torch.float)
