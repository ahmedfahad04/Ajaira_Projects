
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        result = {}
        for key, value in d.items():
            new_key = f"{parent_key}{sep}{key}" if parent_key else key
            if isinstance(value, dict):
                for subkey, subvalue in flatten_dict(value, new_key, sep).items():
                    result[subkey] = subvalue
            else:
                result[new_key] = value
        return result
