
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        x, y, x1, y1 = box
        center_x = (x + x1) / 2
        center_y = (y + y1) / 2
        width = x1 - x
        height = y1 - y
        new_width = width * expand
        new_height = height * expand
        half_new_width = new_width / 2
        half_new_height = new_height / 2
        new_x = center_x - half_new_width
        new_y = center_y - half_new_height
        new_x1 = center_x + half_new_width
        new_y1 = center_y + half_new_height
        s = (new_width + new_height) / 4
        return [new_x, new_y, new_x1, new_y1], s
