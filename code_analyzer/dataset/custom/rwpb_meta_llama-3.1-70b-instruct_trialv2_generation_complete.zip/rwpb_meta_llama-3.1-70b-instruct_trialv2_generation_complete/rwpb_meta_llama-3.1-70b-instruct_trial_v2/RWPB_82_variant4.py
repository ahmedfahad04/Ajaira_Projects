
def is_tensor(x):
    def is_tensor(x):
        if hasattr(x, '__module__'):
            return x.__module__.startswith('torch') or x.__module__.startswith('numpy')
        else:
            return False
