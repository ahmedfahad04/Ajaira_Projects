
def parity(cycles):
    def parity(cycles):
        total_transpositions = sum(len(cycle) - 1 for cycle in cycles)
        return total_transpositions % 2
