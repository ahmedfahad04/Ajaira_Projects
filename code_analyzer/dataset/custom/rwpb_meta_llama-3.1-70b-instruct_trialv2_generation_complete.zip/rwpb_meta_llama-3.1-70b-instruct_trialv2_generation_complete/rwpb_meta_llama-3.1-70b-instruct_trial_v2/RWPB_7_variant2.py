
def dynamic_import_function(function_path):
    def dynamic_import_function(function_path):
        try:
            module_name, func_name = function_path.rsplit('.', 1)
            module = importlib.import_module(module_name)
            return getattr(module, func_name)
        except (ImportError, AttributeError):
            raise ModuleNotFoundError(f"Failed to import function '{function_path}'")
