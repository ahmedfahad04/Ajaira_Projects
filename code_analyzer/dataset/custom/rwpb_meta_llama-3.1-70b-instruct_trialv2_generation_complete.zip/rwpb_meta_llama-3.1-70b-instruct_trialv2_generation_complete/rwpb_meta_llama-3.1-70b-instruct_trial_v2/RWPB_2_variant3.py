
def logbessel_I_scipy(nu, z, check = True):
    import torch
    from scipy import special, pi
    def logbessel_I_scipy(nu, z, check = True):
        result = torch.tensor(special.iv(nu, z.cpu().numpy()), dtype=torch.float32)
        if check:
            result = torch.where(result != 0, torch.log(result), torch.tensor(0.0))
        else:
            result = torch.log(result)
        return result
