
def numpy_to_pytorch(x):
    def numpy_to_pytorch(x):
        x = np.array(x, dtype=np.float32, copy=False, ndmin=2)
        x = x / 255.0
        x = torch.from_numpy(x)
        return x.float()
