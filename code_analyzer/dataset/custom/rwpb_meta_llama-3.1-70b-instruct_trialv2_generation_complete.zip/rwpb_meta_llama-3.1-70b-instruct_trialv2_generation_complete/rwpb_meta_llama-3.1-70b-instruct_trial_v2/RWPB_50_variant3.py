
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        original_height, original_width = original_size
        current_height, current_width = tensor.shape[1], tensor.shape[2]
        original_aspect_ratio = original_width / original_height
        current_aspect_ratio = current_width / current_height
        if original_aspect_ratio > current_aspect_ratio:
            height_to_width_ratio = current_height / current_width
            target_height = int(height_to_width_ratio * original_width)
            if target_height > current_height:
                target_height = current_height
            start_height = (current_height - target_height) // 2
            end_height = start_height + target_height
            return tensor[:, start_height:end_height, :, :]
        else:
            width_to_height_ratio = current_width / current_height
            target_width = int(width_to_height_ratio * original_height)
            if target_width > current_width:
                target_width = current_width
            start_width = (current_width - target_width) // 2
            end_width = start_width + target_width
            return tensor[:, :, start_width:end_width, :]
