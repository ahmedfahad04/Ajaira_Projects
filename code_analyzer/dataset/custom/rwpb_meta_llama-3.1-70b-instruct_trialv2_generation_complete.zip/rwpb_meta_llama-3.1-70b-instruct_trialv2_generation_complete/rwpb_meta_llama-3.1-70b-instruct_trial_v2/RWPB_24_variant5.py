
def check(x, checksum_token):
    def check(x, checksum_token):
        pattern = r'\b[0-9a-f]{64}\b'
        def replace(match):
            nonlocal count
            count += 1
            if count == 1:
                return checksum_token
            else:
                return match.group()
        count = 0
        new_string = re.sub(pattern, replace, x)
        match = re.search(pattern, x)
        if match:
            original_checksum = match.group()
            hash_object = hashlib.sha256(new_string.encode())
            return hash_object.hexdigest() == original_checksum
        return False
