
def box_iou(box1, box2, eps=1e-7):
    import torch
    def box_iou(box1, box2, eps=1e-7):
        area1 = (box1[:, 2] - box1[:, 0]) * (box1[:, 3] - box1[:, 1])
        area2 = (box2[:, 2] - box2[:, 0]) * (box2[:, 3] - box2[:, 1])
        lt = torch.max(box1[:, :2].unsqueeze(1), box2[:, :2].unsqueeze(0))
        rb = torch.min(box1[:, 2:].unsqueeze(1), box2[:, 2:].unsqueeze(0))
        wh = (rb - lt).clamp(min=0)
        inter = wh[:, :, 0] * wh[:, :, 1]
        union = area1.unsqueeze(1) + area2.unsqueeze(0) - inter
        return inter / (union + eps)
