
def is_byte_token(s: str) -> bool:
    def is_byte_token(s: str) -> bool:
        if len(s) != 5:
            return False
        if s[0] != '<' or s[4] != '>':
            return False
        try:
            int(s[1:4], 16)
            return True
        except ValueError:
            return False
