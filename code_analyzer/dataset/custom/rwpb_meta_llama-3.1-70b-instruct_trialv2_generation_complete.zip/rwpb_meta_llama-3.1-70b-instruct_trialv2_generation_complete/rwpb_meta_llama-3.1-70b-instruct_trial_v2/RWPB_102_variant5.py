
def rotate_about_z_axis(vector, theta):
    import numpy as np
    from Quaternion import Quaternion
    def rotate_about_z_axis(vector, theta):
        q = Quaternion.from_axis_angle(np.array([0, 0, 1]), theta)
        return q.rotate(vector)
