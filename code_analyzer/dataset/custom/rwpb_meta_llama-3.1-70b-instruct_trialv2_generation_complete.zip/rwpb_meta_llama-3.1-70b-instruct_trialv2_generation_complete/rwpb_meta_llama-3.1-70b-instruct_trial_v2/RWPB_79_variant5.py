
def pr_from_grav(grav):
    import numpy as np
    def pr_from_grav(grav):
        theta = np.arctan2(np.linalg.norm(grav[:, :2], axis=1), -grav[:, 2])
        phi = np.arctan2(grav[:, 1], grav[:, 0])
        pitches = np.pi/2 - theta
        rolls = phi
        return pitches, rolls
