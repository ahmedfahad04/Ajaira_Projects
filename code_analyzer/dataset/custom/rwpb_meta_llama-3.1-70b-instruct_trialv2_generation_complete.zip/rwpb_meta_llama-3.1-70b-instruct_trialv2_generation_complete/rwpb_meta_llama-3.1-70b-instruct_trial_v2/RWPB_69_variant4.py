
def fovx_to_fovy(fovx, aspect):
    import math
    def fovx_to_fovy(fovx, aspect):
        half_fovx = math.tan(fovx / 2)
        half_fovy = math.atan(half_fovx / aspect)
        return 2 * half_fovy
