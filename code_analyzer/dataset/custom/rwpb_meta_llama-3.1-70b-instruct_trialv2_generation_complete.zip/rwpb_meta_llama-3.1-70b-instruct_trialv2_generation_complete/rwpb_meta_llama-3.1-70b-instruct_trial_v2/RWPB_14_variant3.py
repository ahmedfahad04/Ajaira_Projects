
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    from scipy.spatial.transform import Rotation as R
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        if np.allclose(a, b):
            return None, None
        a = a / np.linalg.norm(a)
        b = b / np.linalg.norm(b)
        rotation = R.from_vectors(a, b)
        axis_angle = rotation.as_rotvec()
        angle = np.linalg.norm(axis_angle)
        axis = axis_angle / angle if angle != 0 else np.zeros(3)
        return axis, angle
