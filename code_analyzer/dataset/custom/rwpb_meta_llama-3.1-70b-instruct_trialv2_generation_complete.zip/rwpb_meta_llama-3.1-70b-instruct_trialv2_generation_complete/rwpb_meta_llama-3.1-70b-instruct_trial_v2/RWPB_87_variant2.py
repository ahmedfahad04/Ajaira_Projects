
def rotate_x(a, device=None):
    import torch
    import math
    def rotate_x(a, device=None):
        if device is None:
            device = torch.device('cpu')
        cos_a = torch.cos(torch.tensor(a, device=device))
        sin_a = torch.sin(torch.tensor(a, device=device))
        return torch.tensor([
            [1, 0, 0, 0],
            [0, cos_a, -sin_a, 0],
            [0, sin_a, cos_a, 0],
            [0, 0, 0, 1]
        ], device=device, dtype=torch.float32)
