
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        if padding:
            h, w = shape
            masks = F.max_pool2d(masks, kernel_size=(2, 2), stride=(2, 2))
            masks = F.interpolate(masks, size=(h, w), mode='bilinear', align_corners=False)
        else:
            masks = F.interpolate(masks, size=shape, mode='bilinear', align_corners=False)
        return masks
