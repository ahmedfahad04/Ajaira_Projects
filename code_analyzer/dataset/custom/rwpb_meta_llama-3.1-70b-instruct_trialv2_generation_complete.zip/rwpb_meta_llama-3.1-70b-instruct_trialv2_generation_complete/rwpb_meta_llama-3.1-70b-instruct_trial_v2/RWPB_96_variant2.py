
def movmean(arr, n_avg):
    def movmean(arr, n_avg):
        if n_avg > len(arr):
            return np.array([])
        mov_avg = []
        for i in range(len(arr)-n_avg+1):
            mov_avg.append(np.mean(arr[i:i+n_avg]))
        return np.array(mov_avg)
