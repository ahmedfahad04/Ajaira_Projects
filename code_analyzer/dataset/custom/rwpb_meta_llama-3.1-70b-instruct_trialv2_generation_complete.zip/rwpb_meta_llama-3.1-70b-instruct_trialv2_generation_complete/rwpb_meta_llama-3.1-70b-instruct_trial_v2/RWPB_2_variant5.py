
def logbessel_I_scipy(nu, z, check = True):
    import torch
    from scipy import special, pi
    def logbessel_I_scipy(nu, z, check = True):
        if check:
            result = torch.tensor(special.iv(nu, z.cpu().numpy()), dtype=torch.float32)
            result = torch.log(result)
            result[z == 0] = 0.0
        else:
            result = torch.log(torch.tensor(special.iv(nu, z.cpu().numpy()), dtype=torch.float32))
        return result
