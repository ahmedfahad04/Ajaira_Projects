
def last_before(val, arr):
    def last_before(val, arr):
        def recursive_search(low, high):
            if low > high:
                return -1
            mid = (low + high) // 2
            if arr[mid] <= val:
                if mid == len(arr) - 1 or arr[mid + 1] > val:
                    return mid
                else:
                    return recursive_search(mid + 1, high)
            else:
                return recursive_search(low, mid - 1)
        return recursive_search(0, len(arr) - 1)
