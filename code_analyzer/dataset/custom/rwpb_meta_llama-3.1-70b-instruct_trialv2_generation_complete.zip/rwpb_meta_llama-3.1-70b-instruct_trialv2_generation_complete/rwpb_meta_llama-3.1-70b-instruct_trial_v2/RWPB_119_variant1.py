
def rotate_about_x_axis(vector, theta):
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        rotation_matrix = np.array([
            [1, 0, 0],
            [0, np.cos(theta), -np.sin(theta)],
            [0, np.sin(theta), np.cos(theta)]
        ])
        return np.dot(rotation_matrix, vector)
