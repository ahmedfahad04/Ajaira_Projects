
def parity(cycles):
    def parity(cycles):
        def gcd(a, b):
            while b:
                a, b = b, a % b
            return a
        def lcm(a, b):
            return a * b // gcd(a, b)
        total_transpositions = 1
        for cycle in cycles:
            total_transpositions = lcm(total_transpositions, len(cycle))
        return len(cycles) * (total_transpositions - 1) % 2
