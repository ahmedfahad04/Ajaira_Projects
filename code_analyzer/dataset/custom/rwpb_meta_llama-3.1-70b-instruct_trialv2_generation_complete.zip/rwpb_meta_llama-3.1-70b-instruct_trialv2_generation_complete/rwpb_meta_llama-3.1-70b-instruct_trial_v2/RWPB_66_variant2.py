
def focal_length_to_fovy(focal_length, sensor_height):
    import math
    def focal_length_to_fovy(focal_length, sensor_height):
        half_sensor_height = sensor_height / 2
        half_fovy_tangent = half_sensor_height / focal_length
        half_fovy = math.atan(half_fovy_tangent)
        return 2 * half_fovy
