
def round_nearest_multiple(number, a, direction='standard'):
    def round_nearest_multiple(number, a, direction='standard'):
        if direction == 'standard':
            return round(number / a) * a
        elif direction == 'down':
            return math.floor(number / a) * a
        elif direction == 'up':
            return math.ceil(number / a) * a
        else:
            raise ValueError("Invalid direction")
