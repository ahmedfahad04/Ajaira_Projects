
def format_ratio(ratio):
    def format_ratio(ratio):
        return "percentage:" + str(round(ratio, 3))
