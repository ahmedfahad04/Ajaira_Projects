
def rotate_about_z_axis(vector, theta):
    import numpy as np
    from scipy.linalg import expm
    from scipy.linalg import logm
    def rotate_about_z_axis(vector, theta):
        rotation_matrix = np.array([
            [0, theta, 0],
            [-theta, 0, 0],
            [0, 0, 0]
        ])
        return np.dot(expm(rotation_matrix), vector)
