
def filter_nan(ts, vs):
    def filter_nan(ts, vs):
        mask = ~np.isnan(ts)
        filtered_ts = ts[mask]
        filtered_vs = vs[mask]
        return filtered_ts, filtered_vs
