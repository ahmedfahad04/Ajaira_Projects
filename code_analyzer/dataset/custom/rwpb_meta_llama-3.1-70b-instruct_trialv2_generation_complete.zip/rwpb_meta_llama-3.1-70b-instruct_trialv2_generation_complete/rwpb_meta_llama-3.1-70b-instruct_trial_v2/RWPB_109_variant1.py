
def rot_trans_geo(geometry, rot, trans):
    def rot_trans_geo(geometry, rot, trans):
        return torch.matmul(geometry, rot) + trans[:, None, :]
