
def interleave(tensor1, tensor2):
    def interleave(tensor1, tensor2):
        result1 = []
        result2 = []
        for t1, t2 in zip(tensor1, tensor2):
            result1.extend([t1, t2])
            result2.extend([t2, t1])
        return torch.tensor(result1[:len(tensor1) + len(tensor2)]), torch.tensor(result2[:len(tensor1) + len(tensor2)])
