
def pad_camera_extrinsics_4x4(extrinsics):
    def pad_camera_extrinsics_4x4(extrinsics):
        padded_extrinsics = torch.zeros((*extrinsics.shape[:-2], 4, 4), device=extrinsics.device)
        padded_extrinsics[..., :3, :] = extrinsics
        padded_extrinsics[..., 3, :] = torch.tensor([0.0, 0.0, 0.0, 1.0], device=extrinsics.device)
        return padded_extrinsics
