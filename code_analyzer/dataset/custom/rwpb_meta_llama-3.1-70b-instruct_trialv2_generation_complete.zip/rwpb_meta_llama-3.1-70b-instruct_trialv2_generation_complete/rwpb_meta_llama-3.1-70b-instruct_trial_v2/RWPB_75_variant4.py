
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        if np.all(a == b) or np.all(a == -b):
            return None, None
        axis_ = np.cross(a, b)
        axis_ = axis_ / np.linalg.norm(axis_)
        dot_product = np.vdot(a, b)
        angle = np.arccos(dot_product / (np.linalg.norm(a) * np.linalg.norm(b)))
        return axis_, angle
