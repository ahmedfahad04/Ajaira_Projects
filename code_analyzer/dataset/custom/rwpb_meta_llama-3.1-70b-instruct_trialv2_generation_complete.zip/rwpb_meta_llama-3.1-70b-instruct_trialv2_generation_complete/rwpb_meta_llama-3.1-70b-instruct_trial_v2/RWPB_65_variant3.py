
def merge_dicts_recursively(*dicts):
    def merge_dicts_recursively(*dicts):
        def merge(d1, d2):
            result = d1.copy()
            for k, v in d2.items():
                if isinstance(v, dict) and k in result and isinstance(result[k], dict):
                    result[k] = merge(result[k], v)
                else:
                    result[k] = v
            return result
        return reduce(merge, dicts, {})
