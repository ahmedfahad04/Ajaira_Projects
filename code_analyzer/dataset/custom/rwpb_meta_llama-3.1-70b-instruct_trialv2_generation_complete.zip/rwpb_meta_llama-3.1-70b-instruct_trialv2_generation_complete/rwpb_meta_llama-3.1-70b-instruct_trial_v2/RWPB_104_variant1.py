
def mulMod(x, y, z):
    def mulMod(x, y, z):
        return (x * y) % z
