
def window_partition(x: torch.Tensor, window_size: Sequence[int]):
    def window_partition(x: torch.Tensor, window_size: Sequence[int]):
        B, H, W, C = x.shape
        win_h, win_w = window_size
        patches = []
        for i in range(0, H, win_h):
            for j in range(0, W, win_w):
                patch = x[:, i:i+win_h, j:j+win_w, :]
                patches.append(patch)
        patches = torch.cat(patches, dim=0)
        return patches
