
def get_confusion_matrix(gt_label, pred_label, num_classes):
    def get_confusion_matrix(gt_label, pred_label, num_classes):
        if len(gt_label) != len(pred_label):
            raise ValueError("The length of gt_label is not equal to the length of pred_label")
        return np.histogram2d(gt_label, pred_label, bins=[range(num_classes+1), range(num_classes+1)])[0]
