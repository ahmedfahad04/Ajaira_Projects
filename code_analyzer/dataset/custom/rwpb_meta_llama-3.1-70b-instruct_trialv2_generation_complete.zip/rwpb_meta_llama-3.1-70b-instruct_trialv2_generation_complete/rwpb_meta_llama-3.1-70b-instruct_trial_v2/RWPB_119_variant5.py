
def rotate_about_x_axis(vector, theta):
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        return np.array([
            vector[0],
            vector[1] * np.cos(theta) - vector[2] * np.sin(theta),
            vector[1] * np.sin(theta) + vector[2] * np.cos(theta)
        ], dtype=vector.dtype)
