
def format_ratio(ratio):
    def format_ratio(ratio):
        return "percentage:" + "{:.3f}".format(ratio)
