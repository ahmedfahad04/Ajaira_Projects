
def dynamic_import_function(function_path):
    def dynamic_import_function(function_path):
        parts = function_path.split('.')
        module_path = '.'.join(parts[:-1])
        func_name = parts[-1]
        try:
            module = importlib.import_module(module_path)
            return getattr(module, func_name)
        except (ImportError, AttributeError):
            raise ModuleNotFoundError(f"Failed to import function '{function_path}'")
