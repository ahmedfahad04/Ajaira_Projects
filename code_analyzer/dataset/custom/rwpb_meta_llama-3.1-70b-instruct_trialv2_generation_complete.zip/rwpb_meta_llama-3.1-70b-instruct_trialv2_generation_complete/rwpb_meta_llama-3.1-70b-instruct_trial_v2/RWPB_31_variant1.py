
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        current_batch_size = tensor.shape[0]
        if current_batch_size == batch_size:
            return tensor
        elif current_batch_size < batch_size:
            indices = torch.linspace(0, current_batch_size - 1, batch_size).long()
            return tensor[indices]
        else:
            indices = torch.arange(0, batch_size) * (current_batch_size / batch_size)
            return tensor[indices.long()]
