
def fovx_to_fovy(fovx, aspect):
    import math
    def fovx_to_fovy(fovx, aspect):
        half_fovx = fovx / 2
        tan_half_fovx = math.tan(half_fovx)
        tan_half_fovy = tan_half_fovx / aspect
        return 2 * math.atan(tan_half_fovy)
