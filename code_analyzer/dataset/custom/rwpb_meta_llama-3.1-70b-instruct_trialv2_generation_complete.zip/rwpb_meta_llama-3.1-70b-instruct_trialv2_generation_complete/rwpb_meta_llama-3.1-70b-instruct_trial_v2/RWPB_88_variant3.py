
def rotate_y(a, device=None):
    import torch
    import numpy as np
    def rotate_y(a, device=None):
        if device is None:
            device = torch.device('cpu')
        matrix = torch.eye(4, device=device)
        matrix[0, 0] = torch.cos(a).to(device)
        matrix[0, 2] = -torch.sin(a).to(device)
        matrix[2, 0] = torch.sin(a).to(device)
        matrix[2, 2] = torch.cos(a).to(device)
        return matrix
