
def parity(cycles):
    def parity(cycles):
        def is_even(num):
            return num % 2 == 0
        total_transpositions = sum(len(cycle) - 1 for cycle in cycles)
        return int(not is_even(total_transpositions))
