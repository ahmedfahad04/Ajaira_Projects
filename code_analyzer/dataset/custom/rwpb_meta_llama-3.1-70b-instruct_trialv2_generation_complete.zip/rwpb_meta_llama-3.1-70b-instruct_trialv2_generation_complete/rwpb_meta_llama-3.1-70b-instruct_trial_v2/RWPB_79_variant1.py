
def pr_from_grav(grav):
    import numpy as np
    def pr_from_grav(grav):
        pitches = np.arcsin(-grav[:, 2])
        rolls = np.arctan2(-grav[:, 1], grav[:, 0])
        return pitches, rolls
