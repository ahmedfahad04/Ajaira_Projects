
def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
    import torch
    def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
        dot_product = torch.dot(v0, v1)
        if dot_product > DOT_THRESHOLD:
            return v0 + t * (v1 - v0)
        omega = torch.acos(dot_product)
        so = torch.sin(omega)
        return torch.sin((1 - t) * omega) / so * v0 + torch.sin(t * omega) / so * v1
