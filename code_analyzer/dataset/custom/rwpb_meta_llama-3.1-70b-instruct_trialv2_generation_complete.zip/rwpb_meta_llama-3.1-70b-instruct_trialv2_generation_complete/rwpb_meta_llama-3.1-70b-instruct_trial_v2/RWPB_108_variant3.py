
def norm_grid(v_grid):
    def norm_grid(v_grid):
        B, _, H, W = v_grid.size()
        v_grid_min = v_grid.view(B, 2, -1).min(dim=2)[0]
        v_grid_max = v_grid.view(B, 2, -1).max(dim=2)[0]
        return torch.cat([2 * ((v_grid[:, 0, :, :] - v_grid_min[:, 0].unsqueeze(1).unsqueeze(2)) / (v_grid_max[:, 0].unsqueeze(1).unsqueeze(2) - v_grid_min[:, 0].unsqueeze(1).unsqueeze(2))) - 1,
                          2 * ((v_grid[:, 1, :, :] - v_grid_min[:, 1].unsqueeze(1).unsqueeze(2)) / (v_grid_max[:, 1].unsqueeze(1).unsqueeze(2) - v_grid_min[:, 1].unsqueeze(1).unsqueeze(2))) - 1], dim=1).permute(0, 2, 3, 1)
