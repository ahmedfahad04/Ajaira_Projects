
def _ssim(img1, img2, window, window_size, channel, size_average=True):
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        mu1 = F.conv2d(img1, window, groups=channel)
        mu2 = F.conv2d(img2, window, groups=channel)
        mu1_sq, mu2_sq, mu1_mu2 = mu1 ** 2, mu2 ** 2, mu1 * mu2
        sigma1_sq = F.conv2d(img1 ** 2, window, groups=channel) - mu1_sq
        sigma2_sq = F.conv2d(img2 ** 2, window, groups=channel) - mu2_sq
        sigma12 = F.conv2d(img1 * img2, window, groups=channel) - mu1_mu2
        C1, C2 = 0.01 ** 2, 0.03 ** 2
        ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))
        if size_average:
            return ssim_map.mean()
        else:
            return ssim_map.mean(1).mean(1).mean(1)
