
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        min_height, min_width = size
        height, width = sample["image"].shape[:2]
        def resize_image(image, new_size):
            return cv2.resize(image, new_size)
        if height < min_height or width < min_width:
            scale = max(min_height / height, min_width / width)
            new_size = (int(width * scale), int(height * scale))
            sample["image"] = resize_image(sample["image"], new_size)
            sample["disparity"] = resize_image(sample["disparity"], new_size)
            sample["mask"] = resize_image(sample["mask"], new_size)
        return sample["image"].shape[:2]
