
def B_batch(x, grid, k=0, extend=True, device="cpu"):
    import torch
    def B_batch(x, grid, k=0, extend=True, device="cpu"):
        def basis(i, t):
            if k == 0:
                return torch.where(t == i, torch.ones_like(t), torch.zeros_like(t))
            else:
                a = (t - i) / k
                b = (t - (i + 1)) / k
                return (k - 1) * (basis(i, t) * (1 - a) + basis(i + 1, t) * b)
        num_spline, num_sample = x.shape
        num_grid = grid.shape[1]
        if extend:
            grid = torch.cat((torch.tensor([grid[:, 0]] * k, device=device), grid, torch.tensor([grid[:, -1]] * k, device=device)), dim=1)
        else:
            grid = torch.cat((grid, torch.tensor([grid[:, -1]] * k, device=device)), dim=1)
        result = torch.zeros(num_spline, num_grid + k - 1, num_sample, device=device)
        for i in range(num_grid + k - 1):
            result[:, i, :] = basis(i, x)
        return result
