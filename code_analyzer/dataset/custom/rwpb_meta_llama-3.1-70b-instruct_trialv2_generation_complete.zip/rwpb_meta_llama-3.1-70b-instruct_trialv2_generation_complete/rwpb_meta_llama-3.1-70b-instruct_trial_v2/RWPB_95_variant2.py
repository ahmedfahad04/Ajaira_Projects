
def lines_focal(o, d):
    import torch
    def lines_focal(o, d):
        d = d / d.norm(dim=1, keepdim=True)
        I = torch.eye(3, dtype=o.dtype, device=o.device)
        S = torch.zeros((3, 3), dtype=o.dtype, device=o.device)
        C = torch.zeros((3,), dtype=o.dtype, device=o.device)
        for i in range(o.shape[0]):
            S += (d[i, None] * d[i, None] - I)
            C += (d[i, None] * d[i, None] - I) @ o[i]
        return torch.linalg.pinv(S) @ C
