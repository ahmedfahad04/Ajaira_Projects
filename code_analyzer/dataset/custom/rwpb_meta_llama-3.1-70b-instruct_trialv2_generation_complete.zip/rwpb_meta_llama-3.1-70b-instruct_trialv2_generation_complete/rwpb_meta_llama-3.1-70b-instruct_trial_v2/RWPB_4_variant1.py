
def rot6d_to_rotmat(x):
    def rot6d_to_rotmat(x):
        x = torch.tensor(x)
        if x.dim() != 2 or x.shape[1] != 6:
            raise ValueError("Input must be (B,6)")
        x = x.view(-1, 2, 3)
        a1 = x[:, 0]
        a2 = x[:, 1]
        b1 = F.normalize(a1)
        b2 = F.normalize(a2 - torch.einsum('bi,bi->b', b1, a2).unsqueeze(-1) * b1)
        b3 = torch.cross(b1, b2)
        return torch.stack((b1, b2, b3), dim=1)
