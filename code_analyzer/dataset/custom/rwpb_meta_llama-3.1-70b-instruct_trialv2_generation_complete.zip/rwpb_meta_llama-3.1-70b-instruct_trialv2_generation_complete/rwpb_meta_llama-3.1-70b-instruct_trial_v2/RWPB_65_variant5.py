
def merge_dicts_recursively(*dicts):
    def merge_dicts_recursively(*dicts):
        def merge(d1, d2):
            if not d1:
                return d2
            if not d2:
                return d1
            result = {}
            keys = set(d1.keys()) | set(d2.keys())
            for k in keys:
                v1 = d1.get(k)
                v2 = d2.get(k)
                if isinstance(v1, dict) and isinstance(v2, dict):
                    result[k] = merge_dicts_recursively({k: v1}, {k: v2})[k]
                elif v2 is not None:
                    result[k] = v2
                else:
                    result[k] = v1
            return result
        return reduce(merge, dicts, {})
