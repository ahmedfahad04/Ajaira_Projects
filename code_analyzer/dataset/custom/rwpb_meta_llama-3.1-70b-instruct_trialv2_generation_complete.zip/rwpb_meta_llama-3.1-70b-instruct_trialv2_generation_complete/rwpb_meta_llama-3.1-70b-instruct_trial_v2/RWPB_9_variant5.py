
def is_byte_token(s: str) -> bool:
    def is_byte_token(s: str) -> bool:
        if len(s) != 5:
            return False
        if s[0] != '<' or s[4] != '>' or s[1:3] != '0x':
            return False
        for char in s[3]:
            if not char.isdigit() and not char.upper() in 'ABCDEF':
                return False
        return True
