
def logbessel_I_scipy(nu, z, check = True):
    import torch
    from scipy import special, pi
    def logbessel_I_scipy(nu, z, check = True):
        result = torch.log(torch.tensor(special.iv(nu, z.cpu().numpy()), dtype=torch.float32))
        if check:
            result = torch.where(z != 0, result, torch.tensor(0.0))
        return result
