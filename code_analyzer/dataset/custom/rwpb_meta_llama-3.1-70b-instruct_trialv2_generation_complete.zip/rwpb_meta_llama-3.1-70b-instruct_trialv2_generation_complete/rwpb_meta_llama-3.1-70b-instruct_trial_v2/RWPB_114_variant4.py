
def reshape_weight_task_tensors(task_tensors, weights):
    def reshape_weight_task_tensors(task_tensors, weights):
        def recursive_reshape(weights, diff):
            if diff == 0:
                return weights
            else:
                return recursive_reshape(weights.unsqueeze(0), diff - 1)
        diff = len(task_tensors.shape) - len(weights.shape)
        return recursive_reshape(weights, diff)
