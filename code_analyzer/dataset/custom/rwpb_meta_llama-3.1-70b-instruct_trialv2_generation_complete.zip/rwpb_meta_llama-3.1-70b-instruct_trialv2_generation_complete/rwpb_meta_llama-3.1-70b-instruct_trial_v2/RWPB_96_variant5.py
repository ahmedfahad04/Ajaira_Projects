
def movmean(arr, n_avg):
    def movmean(arr, n_avg):
        if n_avg > len(arr):
            return np.array([])
        mov_avg = []
        window_sum = np.sum(arr[:n_avg])
        mov_avg.append(window_sum / n_avg)
        for i in range(n_avg, len(arr)):
            window_sum = window_sum - arr[i-n_avg] + arr[i]
            mov_avg.append(window_sum / n_avg)
        return np.array(mov_avg)
