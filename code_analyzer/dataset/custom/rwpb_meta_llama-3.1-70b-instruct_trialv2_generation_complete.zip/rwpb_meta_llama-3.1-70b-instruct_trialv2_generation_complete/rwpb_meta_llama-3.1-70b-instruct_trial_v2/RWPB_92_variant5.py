
def round(number, num_decimal_places, leave_int=False):
    def round(number, num_decimal_places, leave_int=False):
        if isinstance(number, int) and not leave_int:
            return number
        string_value = str(number)
        if '.' in string_value:
            parts = string_value.split('.')
            if len(parts[1]) <= num_decimal_places:
                return float(string_value)
            integer_part = parts[0]
            decimal_part = parts[1]
            if decimal_part[num_decimal_places] >= '5':
                decimal_part = str(int(decimal_part[:num_decimal_places]) + 1)
                if len(decimal_part) < num_decimal_places:
                    decimal_part += '0' * (num_decimal_places - len(decimal_part))
            else:
                decimal_part = decimal_part[:num_decimal_places]
            return float(integer_part + '.' + decimal_part)
        return float(string_value + '.' + '0' * num_decimal_places)
