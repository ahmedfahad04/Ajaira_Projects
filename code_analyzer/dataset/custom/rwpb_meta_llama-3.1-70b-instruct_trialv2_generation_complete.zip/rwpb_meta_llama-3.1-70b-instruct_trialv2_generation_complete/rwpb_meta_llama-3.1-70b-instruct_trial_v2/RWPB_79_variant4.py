
def pr_from_grav(grav):
    import numpy as np
    def pr_from_grav(grav):
        pitches = np.zeros(len(grav))
        rolls = np.zeros(len(grav))
        for i, g in enumerate(grav):
            pitches[i] = np.arcsin(-g[2])
            rolls[i] = np.arctan2(-g[1], g[0])
        return pitches, rolls
