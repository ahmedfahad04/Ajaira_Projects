
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        min_height, min_width = size
        height, width = sample["image"].shape[:2]
        def calculate_new_size(height, width):
            scale = max(min_height / height, min_width / width)
            return (int(width * scale), int(height * scale))
        new_size = calculate_new_size(height, width)
        if new_size != (width, height):
            sample["image"] = cv2.resize(sample["image"], new_size, interpolation=image_interpolation_method)
            sample["disparity"] = cv2.resize(sample["disparity"], new_size, interpolation=cv2.INTER_NEAREST)
            sample["mask"] = cv2.resize(sample["mask"], new_size, interpolation=cv2.INTER_NEAREST)
        return new_size
