
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    def generate_grids(lower_limit, upper_limit, grid_size):
        num_dims = len(lower_limit)
        lower_bounds = torch.zeros([*grid_size, num_dims])
        upper_bounds = torch.zeros([*grid_size, num_dims])
        for i in range(num_dims):
            step = (upper_limit[i] - lower_limit[i]) / grid_size[i]
            for indices in torch.ndindex(*grid_size):
                lower_bounds[indices][i] = lower_limit[i] + indices[i] * step
                upper_bounds[indices][i] = lower_bounds[indices][i] + step
        return lower_bounds, upper_bounds
