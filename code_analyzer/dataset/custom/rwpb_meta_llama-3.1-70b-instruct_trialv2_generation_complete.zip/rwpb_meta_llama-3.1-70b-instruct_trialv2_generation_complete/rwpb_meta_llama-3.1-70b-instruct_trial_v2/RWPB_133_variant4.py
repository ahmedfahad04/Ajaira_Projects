
def divide_to_patches(image, patch_size):
    def divide_to_patches(image, patch_size):
        width, height = image.size
        patches = []
        y = 0
        while y < height:
            x = 0
            while x < width:
                patch = image.crop((x, y, min(x + patch_size, width), min(y + patch_size, height)))
                patches.append(patch)
                x += patch_size
            y += patch_size
        return patches
