
def path_spliter(path: str):
    import re
    def path_spliter(path: str):
        return re.split('[\\/]+', path) if path else []
