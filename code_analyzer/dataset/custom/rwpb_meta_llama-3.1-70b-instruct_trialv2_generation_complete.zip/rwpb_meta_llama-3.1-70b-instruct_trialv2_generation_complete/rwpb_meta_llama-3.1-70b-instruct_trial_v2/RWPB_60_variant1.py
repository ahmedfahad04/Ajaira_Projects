
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        if upcast:
            x = x.float()
            weight = weight.float()
            if bias is not None:
                bias = bias.float()
            if residual is not None:
                residual = residual.float()
        norm = torch.sqrt(torch.mean(x**2, dim=-1, keepdim=True) + eps)
        normalized = x / norm
        output = normalized * weight + bias if bias is not None else normalized * weight
        if residual is not None:
            output = output + residual
        if prenorm:
            return output, x
        else:
            return output
