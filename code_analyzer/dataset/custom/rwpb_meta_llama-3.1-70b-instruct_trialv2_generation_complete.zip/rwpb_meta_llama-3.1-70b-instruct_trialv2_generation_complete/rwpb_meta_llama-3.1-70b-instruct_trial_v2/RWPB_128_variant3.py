
def xywh2xyxy(x):
    def xywh2xyxy(x):
        def convert_box(box):
            x1 = box[0]
            y1 = box[1]
            x2 = box[0] + box[2]
            y2 = box[1] + box[3]
            return [x1, y1, x2, y2]
        if isinstance(x, np.ndarray):
            return np.array([convert_box(box) for box in x])
        elif isinstance(x, torch.Tensor):
            return torch.tensor([convert_box(box) for box in x])
