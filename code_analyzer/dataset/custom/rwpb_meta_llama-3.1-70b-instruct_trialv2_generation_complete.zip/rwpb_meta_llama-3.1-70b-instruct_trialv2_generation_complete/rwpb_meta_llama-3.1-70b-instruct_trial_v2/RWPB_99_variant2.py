
def focal2fov(focal, pixels):
    import math
    def focal2fov(focal, pixels):
        if focal == 0:
            raise KeyError("Focal length cannot be zero")
        fov = 2 * math.atan(pixels / (2 * focal))
        return fov
