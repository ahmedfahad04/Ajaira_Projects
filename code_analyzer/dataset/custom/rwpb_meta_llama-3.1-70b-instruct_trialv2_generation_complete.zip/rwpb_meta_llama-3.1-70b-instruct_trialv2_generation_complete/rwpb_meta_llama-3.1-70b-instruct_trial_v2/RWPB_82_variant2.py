
def is_tensor(x):
    def is_tensor(x):
        torch_spec = importlib.util.find_spec("torch")
        if torch_spec is not None:
            torch = importlib.util.module_from_spec(torch_spec)
            torch_spec.loader.exec_module(torch)
            return isinstance(x, torch.Tensor) or isinstance(x, np.ndarray)
        else:
            return isinstance(x, np.ndarray)
