
def remove_scale_from_camera_pose(pose_matrix):
    import numpy as np
    def remove_scale_from_camera_pose(pose_matrix):
        u, s, vh = np.linalg.svd(pose_matrix[:3, :3])
        pose_matrix[:3, :3] = np.dot(u, vh)
        return pose_matrix
