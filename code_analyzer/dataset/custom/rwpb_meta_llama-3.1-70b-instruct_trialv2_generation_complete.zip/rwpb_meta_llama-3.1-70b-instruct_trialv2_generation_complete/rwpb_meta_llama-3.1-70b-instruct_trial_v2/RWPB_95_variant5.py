
def lines_focal(o, d):
    import torch
    def lines_focal(o, d):
        d = d / d.norm(dim=1, keepdim=True)
        I = torch.eye(3, dtype=o.dtype, device=o.device)
        S = (d[:, None, :] * d[:, :, None] - I).sum(dim=0)
        C = (d[:, None, :] * d[:, :, None] - I).matmul(o.T).sum(dim=1)
        return torch.linalg.pinv(S) @ C
