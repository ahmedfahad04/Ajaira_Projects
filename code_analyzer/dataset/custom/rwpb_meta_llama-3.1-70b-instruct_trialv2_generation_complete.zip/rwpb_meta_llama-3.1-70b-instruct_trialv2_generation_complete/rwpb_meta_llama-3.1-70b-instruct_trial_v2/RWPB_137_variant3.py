
def fit_params(:
    import numpy as np
    from scipy.optimize import minimize
    from sklearn.linear_model import LinearRegression
    def fit_params(x, y, fun, a_range=(-10, 10), b_range=(-10, 10), iteration=3, verbose=True):
        def loss(params):
            a, b = params
            x_transformed = fun(a * x + b)
            model = LinearRegression()
            model.fit(x_transformed.reshape(-1, 1), y)
            c, d = model.coef_[0], model.intercept_
            y_pred = c * x_transformed + d
            return -1 + np.sum((y - y_pred) ** 2) / np.sum((y - np.mean(y)) ** 2)
        a_best, b_best, c_best, d_best, r2_best = None, None, None, None, -np.inf
        for _ in range(iteration):
            res = minimize(loss, [0, 0], method='SLSQP', bounds=[a_range, b_range])
            a, b = res.x
            x_transformed = fun(a * x + b)
            model = LinearRegression()
            model.fit(x_transformed.reshape(-1, 1), y)
            c, d = model.coef_[0], model.intercept_
            y_pred = c * x_transformed + d
            r2 = 1 - np.sum((y - y_pred) ** 2) / np.sum((y - np.mean(y)) ** 2)
            if r2 > r2_best:
                a_best, b_best, c_best, d_best, r2_best = a, b, c, d, r2
            a_range = (a_best - (a_range[1] - a_range[0]) / 2 ** iteration, a_best + (a_range[1] - a_range[0]) / 2 ** iteration)
            b_range = (b_best - (b_range[1] - b_range[0]) / 2 ** iteration, b_best + (b_range[1] - b_range[0]) / 2 ** iteration)
        if verbose:
            print(f'r2 is {r2_best:.6f} ({a_best:.4f}, {b_best:.4f}, {c_best:.4f}, {d_best:.4f})')
        return a_best, b_best, c_best, d_best, r2_best
