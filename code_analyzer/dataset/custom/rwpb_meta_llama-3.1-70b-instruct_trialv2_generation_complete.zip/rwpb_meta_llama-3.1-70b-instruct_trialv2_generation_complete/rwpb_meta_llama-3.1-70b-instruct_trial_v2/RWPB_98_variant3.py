
def exp_smooth(vals, alpha):
    import numpy as np
    def exp_smooth(vals, alpha):
        if len(vals) == 0:
            raise KeyError("Input array is empty")
        smoothed = np.cumsum(np.array(vals) * (alpha ** np.arange(len(vals))))
        smoothed /= (1 - alpha ** np.arange(1, len(vals)+1))
        smoothed[0] = vals[0]
        return smoothed
