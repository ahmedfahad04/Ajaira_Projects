
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        return min(possible_resolutions, key=lambda x: abs(x[0] - original_size[0]) + abs(x[1] - original_size[1]))
