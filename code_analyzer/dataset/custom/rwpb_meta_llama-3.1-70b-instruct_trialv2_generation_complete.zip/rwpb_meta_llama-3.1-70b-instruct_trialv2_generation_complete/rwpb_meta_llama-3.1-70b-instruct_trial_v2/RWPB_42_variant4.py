
def resize_and_center_crop(image, target_width, target_height):
    from PIL import Image
    import numpy as np
    def resize_and_center_crop(image, target_width, target_height):
        img = Image.fromarray(image)
        width, height = img.size
        if width / height >= target_width / target_height:
            scale = target_width / width
        else:
            scale = target_height / height
        new_size = (int(width * scale), int(height * scale))
        img = img.resize(new_size, Image.LANCZOS)
        left = (new_size[0] - target_width) // 2
        top = (new_size[1] - target_height) // 2
        right = left + target_width
        bottom = top + target_height
        img = img.crop((left, top, right, bottom))
        return np.array(img)
