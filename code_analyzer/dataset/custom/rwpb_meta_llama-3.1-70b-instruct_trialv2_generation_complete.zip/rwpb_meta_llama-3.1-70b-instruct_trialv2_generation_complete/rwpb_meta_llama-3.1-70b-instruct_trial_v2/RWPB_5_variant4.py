
def seconds_to_hh_mm_ss(seconds):
    def seconds_to_hh_mm_ss(seconds):
        if seconds < 0:
            return "00:00:00"
        time_parts = []
        hours = seconds // 3600
        time_parts.append(f"{hours:02d}")
        minutes = (seconds % 3600) // 60
        time_parts.append(f"{minutes:02d}")
        seconds = seconds % 60
        time_parts.append(f"{seconds:02d}")
        return ":".join(time_parts)
