
def round_nearest_multiple(number, a, direction='standard'):
    def round_nearest_multiple(number, a, direction='standard'):
        if direction == 'standard':
            return np.round(number / a) * a
        elif direction == 'down':
            return np.floor(number / a) * a
        elif direction == 'up':
            return np.ceil(number / a) * a
        else:
            raise ValueError("Invalid direction")
