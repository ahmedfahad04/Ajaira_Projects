
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        if np.allclose(a, b):
            return None, None
        axis = np.cross(a, b)
        if np.allclose(axis, np.zeros(3)):
            axis = None
        else:
            axis = axis / np.linalg.norm(axis)
        dot_product = np.dot(a, b)
        angle = np.arccos(dot_product / (np.linalg.norm(a) * np.linalg.norm(b)))
        return axis, angle
