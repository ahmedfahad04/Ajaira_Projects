
def remove_scale_from_camera_pose(pose_matrix):
    import numpy as np
    def remove_scale_from_camera_pose(pose_matrix):
        scale = np.linalg.det(pose_matrix[:3, :3])**(1/3)
        pose_matrix[:3, :3] /= scale
        pose_matrix[:3, 3] /= scale
        return pose_matrix
