
def rotate_x(a, device=None):
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        if device is None:
            device = torch.device('cpu')
        rotation_matrix = np.array([
            [1, 0, 0, 0],
            [0, np.cos(a), -np.sin(a), 0],
            [0, np.sin(a), np.cos(a), 0],
            [0, 0, 0, 1]
        ])
        return torch.from_numpy(rotation_matrix).float().to(device)
