
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        min_height, min_width = size
        height, width = sample["image"].shape[:2]
        aspect_ratio = width / height
        if height < min_height or width < min_width:
            if aspect_ratio > 1:
                new_width = max(min_width, width)
                new_height = int(new_width / aspect_ratio)
            else:
                new_height = max(min_height, height)
                new_width = int(new_height * aspect_ratio)
            sample["image"] = cv2.resize(sample["image"], (new_width, new_height), interpolation=image_interpolation_method)
            sample["disparity"] = cv2.resize(sample["disparity"], (new_width, new_height), interpolation=cv2.INTER_NEAREST)
            sample["mask"] = cv2.resize(sample["mask"], (new_width, new_height), interpolation=cv2.INTER_NEAREST)
        return sample["image"].shape[:2]
