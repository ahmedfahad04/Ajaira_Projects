
def reshape_weight_task_tensors(task_tensors, weights):
    def reshape_weight_task_tensors(task_tensors, weights):
        weights_unsqueezed = weights
        for _ in range(len(task_tensors.shape) - len(weights.shape)):
            weights_unsqueezed = weights_unsqueezed.unsqueeze(0)
        return weights_unsqueezed
