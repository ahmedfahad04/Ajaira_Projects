
def format_seconds(seconds: float) -> str:
    def format_seconds(seconds: float) -> str:
        seconds = round(seconds, 3)
        time_parts = []
        if seconds >= 3600:
            time_parts.append(f"{int(seconds // 3600):02d}")
            seconds %= 3600
        time_parts.append(f"{int(seconds // 60):02d}")
        time_parts.append(f"{seconds % 60:06.3f}")
        return ":".join(time_parts)
