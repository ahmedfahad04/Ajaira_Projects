
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        batch_size = preds.shape[0]
        ious = []
        for i in range(batch_size):
            pred = preds[i]
            label = labels[i]
            if ignore is not None:
                mask = label != ignore
                pred = pred[mask]
                label = label[mask]
            intersection = torch.logical_and(pred, label).sum()
            union = torch.logical_or(pred, label).sum()
            if union == 0:
                iou = EMPTY
            else:
                iou = (intersection / union)
            ious.append(iou)
        if per_image:
            return torch.stack(ious).mean() * 100
        else:
            return torch.stack(ious).sum() * 100 / batch_size
