
def is_tensor(x):
    def is_tensor(x):
        return type(x).__name__ in ['Tensor', 'ndarray'] or (hasattr(x, 'dtype') and hasattr(x, 'shape'))
