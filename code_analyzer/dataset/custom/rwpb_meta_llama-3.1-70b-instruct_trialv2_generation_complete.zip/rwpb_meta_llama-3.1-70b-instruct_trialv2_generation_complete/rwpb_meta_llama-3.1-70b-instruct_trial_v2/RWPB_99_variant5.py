
def focal2fov(focal, pixels):
    import math
    def focal2fov(focal, pixels):
        if focal == 0:
            raise KeyError("Focal length cannot be zero")
        tan_half_fov = pixels / (2 * focal)
        return 2 * math.atan(tan_half_fov)
