
def exp_smooth(vals, alpha):
    import numpy as np
    def exp_smooth(vals, alpha):
        if len(vals) == 0:
            raise KeyError("Input array is empty")
        smoothed = np.zeros(len(vals))
        smoothed[0] = vals[0]
        for i in range(1, len(vals)):
            smoothed[i] = alpha * vals[i] + (1 - alpha) * smoothed[i-1]
        return smoothed
