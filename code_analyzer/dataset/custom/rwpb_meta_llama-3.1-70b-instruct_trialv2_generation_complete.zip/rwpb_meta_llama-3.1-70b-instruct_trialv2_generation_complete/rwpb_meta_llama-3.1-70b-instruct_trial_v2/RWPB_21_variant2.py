
def validate_user_id(user_id):
    import re
    def validate_user_id(user_id):
        if not user_id:
            return False
        return re.match(r'^[a-zA-Z][\w]*$', user_id) is not None
