
def divide_to_patches(image, patch_size):
    def divide_to_patches(image, patch_size):
        width, height = image.size
        patches = []
        for i in range(0, height, patch_size):
            for j in range(0, width, patch_size):
                left = j
                top = i
                right = min(j + patch_size, width)
                bottom = min(i + patch_size, height)
                patch = image.crop((left, top, right, bottom))
                patches.append(patch)
        return patches
