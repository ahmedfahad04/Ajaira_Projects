
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    import numpy as np
    def generate_grids(lower_limit, upper_limit, grid_size):
        num_dims = len(lower_limit)
        lower_bounds = np.zeros([*grid_size, num_dims])
        upper_bounds = np.zeros([*grid_size, num_dims])
        for indices in np.ndindex(*grid_size):
            for i in range(num_dims):
                step = (upper_limit[i] - lower_limit[i]) / grid_size[i]
                lower_bounds[indices][i] = lower_limit[i] + indices[i] * step
                upper_bounds[indices][i] = lower_bounds[indices][i] + step
        return torch.tensor(lower_bounds), torch.tensor(upper_bounds)
