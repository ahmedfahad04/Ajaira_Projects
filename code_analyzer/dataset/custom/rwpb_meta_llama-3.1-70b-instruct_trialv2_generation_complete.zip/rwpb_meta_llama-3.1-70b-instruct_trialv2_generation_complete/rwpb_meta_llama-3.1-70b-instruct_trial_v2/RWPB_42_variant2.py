
def resize_and_center_crop(image, target_width, target_height):
    from PIL import Image
    import numpy as np
    def resize_and_center_crop(image, target_width, target_height):
        img = Image.fromarray(image)
        width, height = img.size
        if width / height >= target_width / target_height:
            new_height = int(height * target_width / width)
            offset = (new_height - target_height) // 2
            img = img.resize((target_width, new_height), Image.LANCZOS)
            img = img.crop((0, offset, target_width, offset + target_height))
        else:
            new_width = int(width * target_height / height)
            offset = (new_width - target_width) // 2
            img = img.resize((new_width, target_height), Image.LANCZOS)
            img = img.crop((offset, 0, offset + target_width, target_height))
        return np.array(img)
