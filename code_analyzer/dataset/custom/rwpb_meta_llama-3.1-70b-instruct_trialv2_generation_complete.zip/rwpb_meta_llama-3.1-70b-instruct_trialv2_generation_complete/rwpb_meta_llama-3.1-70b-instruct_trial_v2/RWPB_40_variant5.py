
def extract_code_from_funct(funct: Callable) -> List[str]:
    import inspect
    from typing import Callable, List
    def extract_code_from_funct(funct: Callable) -> List[str]:
        source = inspect.getsource(funct)
        lines = source.split('\n')
        lines = [line for line in lines if not line.strip().startswith('def') and not line.strip().startswith('return')]
        min_indent = min(len(line) - len(line.lstrip()) for line in lines)
        lines = [line[min_indent:] for line in lines]
        return lines
