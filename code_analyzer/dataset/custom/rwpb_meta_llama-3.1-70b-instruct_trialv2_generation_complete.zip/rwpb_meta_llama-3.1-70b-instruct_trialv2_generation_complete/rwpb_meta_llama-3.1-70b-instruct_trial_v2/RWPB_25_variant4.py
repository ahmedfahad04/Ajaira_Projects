
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        h, w = img.shape
        mask = np.zeros((h+2, w+2), dtype=np.uint8)
        cv2.floodFill(img, mask, (0,0), 255)
        mask[1:-1, 1:-1] = cv2.bitwise_and(mask[1:-1, 1:-1], cv2.bitwise_not(img))
        return cv2.bitwise_or(img, mask[1:-1, 1:-1])
