
def reshape_weight_task_tensors(task_tensors, weights):
    def reshape_weight_task_tensors(task_tensors, weights):
        diff = len(task_tensors.shape) - len(weights.shape)
        return weights[(None,) * diff]
