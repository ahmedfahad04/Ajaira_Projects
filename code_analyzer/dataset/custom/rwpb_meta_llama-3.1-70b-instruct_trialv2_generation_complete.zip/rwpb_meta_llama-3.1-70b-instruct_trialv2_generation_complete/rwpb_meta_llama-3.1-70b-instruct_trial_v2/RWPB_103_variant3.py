
def unsafeAdd(x, y):
    def unsafeAdd(x, y):
        result = x + y
        return result % (1 << 256)
