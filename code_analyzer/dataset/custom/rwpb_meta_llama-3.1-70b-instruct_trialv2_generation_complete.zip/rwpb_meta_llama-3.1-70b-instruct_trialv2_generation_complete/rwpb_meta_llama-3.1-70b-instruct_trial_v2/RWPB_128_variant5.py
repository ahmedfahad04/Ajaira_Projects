
def xywh2xyxy(x):
    def xywh2xyxy(x):
        if isinstance(x, np.ndarray):
            return x[:, :2] + np.hstack((np.zeros(x.shape[:-1] + (2,)), x[:, 2:]))
        elif isinstance(x, torch.Tensor):
            zeros = torch.zeros(x.shape[:-1] + (2,), dtype=x.dtype, device=x.device)
            return torch.cat((zeros, x[:, 2:]), dim=1) + x[:, :2]
