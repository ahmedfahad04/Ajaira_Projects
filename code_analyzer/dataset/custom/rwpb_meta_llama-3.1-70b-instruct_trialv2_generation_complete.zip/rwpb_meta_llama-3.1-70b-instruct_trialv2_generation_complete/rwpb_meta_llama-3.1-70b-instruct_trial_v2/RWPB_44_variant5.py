
def interleave(tensor1, tensor2):
    def interleave(tensor1, tensor2):
        from itertools import chain
        from operator import itemgetter
        zipped = list(zip(tensor1, tensor2))
        return torch.tensor(list(chain(*map(itemgetter(0), zipped), map(itemgetter(1), zipped)))), torch.tensor(list(chain(*map(itemgetter(1), zipped), map(itemgetter(0), zipped))))
