
def interleave(tensor1, tensor2):
    def interleave(tensor1, tensor2):
        interleaved = torch.stack((tensor1, tensor2), dim=1).view(-1)
        return interleaved[:len(interleaved)//2*2:2], interleaved[1:len(interleaved)//2*2+1:2]
