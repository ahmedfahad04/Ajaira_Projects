
def B_batch(x, grid, k=0, extend=True, device="cpu"):
    import torch
    def B_batch(x, grid, k=0, extend=True, device="cpu"):
        num_spline, num_sample = x.shape
        num_grid = grid.shape[1]
        if extend:
            grid = torch.cat((torch.tensor([grid[:, 0]] * k, device=device), grid, torch.tensor([grid[:, -1]] * k, device=device)), dim=1)
        else:
            grid = torch.cat((grid, torch.tensor([grid[:, -1]] * k, device=device)), dim=1)
        result = torch.zeros(num_spline, num_grid + k - 1, num_sample, device=device)
        for i in range(num_spline):
            for j in range(num_grid + k - 1):
                result[i, j, :] = torch.where((grid[i, j] <= x[i, :]) & (x[i, :] < grid[i, j + 1]), (x[i, :] - grid[i, j]) ** (k - 1), torch.zeros_like(x[i, :]))
        return result
