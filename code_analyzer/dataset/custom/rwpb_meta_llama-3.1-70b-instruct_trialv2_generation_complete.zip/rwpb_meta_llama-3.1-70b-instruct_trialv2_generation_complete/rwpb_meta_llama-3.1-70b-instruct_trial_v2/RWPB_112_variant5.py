
def submatrix(matrix, col):
    def submatrix(matrix, col):
        sub_matrix = []
        for row in matrix:
            new_row = []
            for i, x in enumerate(row):
                if i != col:
                    new_row.append(x)
            sub_matrix.append(new_row)
        return sub_matrix
