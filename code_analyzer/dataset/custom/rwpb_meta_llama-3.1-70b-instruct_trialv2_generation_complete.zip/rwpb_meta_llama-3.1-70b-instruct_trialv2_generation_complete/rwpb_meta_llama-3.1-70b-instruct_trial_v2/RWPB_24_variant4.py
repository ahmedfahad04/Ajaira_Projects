
def check(x, checksum_token):
    def check(x, checksum_token):
        pattern = r'\b[0-9a-f]{64}\b'
        match = re.search(pattern, x)
        if match:
            original_checksum = match.group()
            start, end = match.span()
            new_string = x[:start] + checksum_token + x[end:]
            hash_object = hashlib.sha256(new_string.encode())
            return hash_object.hexdigest() == original_checksum
        return False
