
def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        batch_size, num_points, _ = coordinates.shape
        num_planes, _, _ = planes.shape
        # Reshape coordinates to (batch_size * num_points, 3)
        coordinates = coordinates.view(batch_size * num_points, 3)
        # Create a tensor to store the projected points
        projected_points = torch.zeros(batch_size * num_planes * num_points, 2, device=coordinates.device)
        # Extract the plane's axes
        x_axes, y_axes, _ = planes.transpose(0, 1)
        # Project the points onto the plane's x and y axes
        x_coords = torch.matmul(coordinates, x_axes.T)
        y_coords = torch.matmul(coordinates, y_axes.T)
        # Store the projected points
        for i in range(num_planes):
            start_idx = i * batch_size * num_points
            end_idx = (i + 1) * batch_size * num_points
            projected_points[start_idx:end_idx] = torch.stack([x_coords[:, i].repeat(batch_size), y_coords[:, i].repeat(batch_size)], dim=1)
        # Reshape the projected points to (batch_size * num_planes, num_points, 2)
        projected_points = projected_points.view(batch_size * num_planes, num_points, 2)
        return projected_points
