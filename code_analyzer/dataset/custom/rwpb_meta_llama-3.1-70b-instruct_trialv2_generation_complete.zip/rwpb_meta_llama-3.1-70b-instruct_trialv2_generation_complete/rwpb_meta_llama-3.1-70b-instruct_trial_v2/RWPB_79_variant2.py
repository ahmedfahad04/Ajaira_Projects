
def pr_from_grav(grav):
    import numpy as np
    def pr_from_grav(grav):
        norm = np.linalg.norm(grav, axis=1, keepdims=True)
        grav_normalized = grav / norm
        pitches = np.arcsin(-grav_normalized[:, 2])
        rolls = np.arctan2(-grav_normalized[:, 1], grav_normalized[:, 0])
        return pitches, rolls
