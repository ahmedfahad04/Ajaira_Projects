
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    def generate_grids(lower_limit, upper_limit, grid_size):
        num_dims = len(lower_limit)
        grid_points = torch.meshgrid([torch.linspace(lower_limit[i], upper_limit[i], grid_size[i]) for i in range(num_dims)])
        lower_bounds = torch.stack([grid_points[i][:-1, ...] for i in range(num_dims)], dim=-1)
        upper_bounds = torch.stack([grid_points[i][1:, ...] for i in range(num_dims)], dim=-1)
        return lower_bounds, upper_bounds
