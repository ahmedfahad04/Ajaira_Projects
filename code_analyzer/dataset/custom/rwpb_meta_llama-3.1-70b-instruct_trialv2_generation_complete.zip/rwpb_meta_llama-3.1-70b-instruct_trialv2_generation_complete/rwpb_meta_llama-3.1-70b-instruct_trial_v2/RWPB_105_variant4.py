
def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        batch_size, num_points_per_batch, _ = coordinates.shape
        feature_channels, H, W, D = grid.shape[1], grid.shape[2], grid.shape[3], grid.shape[4]
        coordinates = coordinates.view(-1, 3)
        coordinates[:, 0] = (coordinates[:, 0] / (H - 1)) * 2 - 1
        coordinates[:, 1] = (coordinates[:, 1] / (W - 1)) * 2 - 1
        coordinates[:, 2] = (coordinates[:, 2] / (D - 1)) * 2 - 1
        coordinates = coordinates.view(batch_size, num_points_per_batch, 3)
        grid = grid.repeat(batch_size, 1, 1, 1, 1)
        sampled_features = torch.nn.functional.grid_sample(grid, coordinates.unsqueeze(1), align_corners=True)
        return sampled_features.squeeze(2).permute(0, 2, 1, 3)
