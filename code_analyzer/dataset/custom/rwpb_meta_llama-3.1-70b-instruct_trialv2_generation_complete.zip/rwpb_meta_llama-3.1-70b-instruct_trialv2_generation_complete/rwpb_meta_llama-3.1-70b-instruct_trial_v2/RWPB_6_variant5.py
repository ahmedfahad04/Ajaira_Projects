
def format_seconds(seconds: float) -> str:
    def format_seconds(seconds: float) -> str:
        seconds = round(seconds, 3)
        time_parts = [f"{int(seconds % 60):06.3f}"]
        seconds = int(seconds // 60)
        if seconds > 0:
            time_parts.insert(0, f"{seconds % 60:02d}")
            seconds = int(seconds // 60)
            if seconds > 0:
                time_parts.insert(0, f"{seconds:02d}")
        return ":".join(time_parts)
