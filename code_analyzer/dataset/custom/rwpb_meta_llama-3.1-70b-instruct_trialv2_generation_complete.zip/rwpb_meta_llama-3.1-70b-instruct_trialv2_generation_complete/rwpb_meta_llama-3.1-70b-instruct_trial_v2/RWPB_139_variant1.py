
def rotate_normalmap_by_angle_torch(normal_map, angle):
    import torch
    import math
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        angle_rad = math.radians(angle)
        rotation_matrix = torch.tensor([
            [math.cos(angle_rad), 0, math.sin(angle_rad)],
            [0, 1, 0],
            [-math.sin(angle_rad), 0, math.cos(angle_rad)]
        ], device=normal_map.device)
        return torch.einsum('ijk,kl->ijl', normal_map, rotation_matrix)
