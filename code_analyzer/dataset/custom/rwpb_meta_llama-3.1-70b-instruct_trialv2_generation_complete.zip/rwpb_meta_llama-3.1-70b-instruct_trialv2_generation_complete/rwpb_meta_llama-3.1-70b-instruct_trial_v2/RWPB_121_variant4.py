
def isprime(n):
    def isprime(n):
      def check_prime(num, i=2):
        if num <= 1:
          return False
        if num == 2:
          return True
        if num % i == 0:
          return False
        if i * i > num:
          return True
        return check_prime(num, i + 1)
      return check_prime(n)
