
def rot_trans_geo(geometry, rot, trans):
    def rot_trans_geo(geometry, rot, trans):
        geometry = geometry.transpose(1, 2)
        result = torch.matmul(rot, geometry) + trans[:, :, None]
        return result.transpose(1, 2)
