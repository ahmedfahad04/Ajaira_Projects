
def mulMod(x, y, z):
    def mulMod(x, y, z):
        return (x * y) // z * z + (x * y) % z
