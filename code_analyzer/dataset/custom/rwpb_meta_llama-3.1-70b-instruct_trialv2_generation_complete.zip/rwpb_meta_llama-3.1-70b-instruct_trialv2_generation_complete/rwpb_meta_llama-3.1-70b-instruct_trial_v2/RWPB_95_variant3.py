
def lines_focal(o, d):
    import torch
    def lines_focal(o, d):
        d = d / d.norm(dim=1, keepdim=True)
        I = torch.eye(3, dtype=o.dtype, device=o.device)
        S = torch.einsum('ijk,ikl->jkl', (d[:, None, :] * d[:, :, None] - I)[:, None, :, :], d[:, :, None, None]).sum(dim=0)
        C = torch.einsum('ijk,ik->j', (d[:, None, :] * d[:, :, None] - I), o).sum(dim=0)
        return torch.linalg.pinv(S) @ C
