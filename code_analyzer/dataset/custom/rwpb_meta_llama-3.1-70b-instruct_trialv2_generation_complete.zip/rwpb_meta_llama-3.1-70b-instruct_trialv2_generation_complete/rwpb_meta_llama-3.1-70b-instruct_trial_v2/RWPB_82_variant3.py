
def is_tensor(x):
    def is_tensor(x):
        try:
            import torch
            return isinstance(x, torch.Tensor) or isinstance(x, np.ndarray)
        except ImportError:
            return isinstance(x, np.ndarray)
