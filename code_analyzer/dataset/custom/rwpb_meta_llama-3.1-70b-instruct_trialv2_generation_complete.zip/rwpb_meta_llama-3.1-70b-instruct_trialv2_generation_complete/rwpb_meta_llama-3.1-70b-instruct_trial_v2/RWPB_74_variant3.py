
def arccos2(vector, value):
    import numpy as np
    def arccos2(vector, value):
        norm = np.linalg.norm(vector)
        if norm == 0:
            raise ValueError("Vector cannot be zero-length")
        unit_vector = vector / norm
        angle = np.arccos(np.dot(unit_vector, np.array([1, 0])))
        if unit_vector[1] < 0:
            angle = 2 * np.pi - angle
        return angle
