
def norm_grid(v_grid):
    def norm_grid(v_grid):
        B, _, H, W = v_grid.size()
        v_grid = v_grid.permute(0, 2, 3, 1)
        v_grid_min = v_grid.view(B, -1, 2).min(dim=1)[0].unsqueeze(1).unsqueeze(1)
        v_grid_max = v_grid.view(B, -1, 2).max(dim=1)[0].unsqueeze(1).unsqueeze(1)
        return 2 * (v_grid - v_grid_min) / (v_grid_max - v_grid_min) - 1
