
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        best_resolution = None
        min_diff = float('inf')
        for resolution in possible_resolutions:
            diff = abs(resolution[0] - original_size[0]) + abs(resolution[1] - original_size[1])
            if diff < min_diff:
                min_diff = diff
                best_resolution = resolution
        return best_resolution
