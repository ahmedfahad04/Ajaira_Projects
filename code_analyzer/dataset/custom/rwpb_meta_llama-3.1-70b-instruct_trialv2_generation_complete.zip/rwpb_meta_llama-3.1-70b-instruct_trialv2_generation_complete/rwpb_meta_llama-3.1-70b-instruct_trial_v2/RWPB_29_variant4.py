
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        batch_size = preds.shape[0]
        intersection = 0
        union = 0
        for i in range(batch_size):
            pred = preds[i]
            label = labels[i]
            if ignore is not None:
                mask = label != ignore
                pred = pred[mask]
                label = label[mask]
            intersection += torch.logical_and(pred, label).sum()
            union += torch.logical_or(pred, label).sum()
        if union == 0:
            return EMPTY * 100
        iou = (intersection / union) * 100
        if per_image:
            return iou
        else:
            return iou
