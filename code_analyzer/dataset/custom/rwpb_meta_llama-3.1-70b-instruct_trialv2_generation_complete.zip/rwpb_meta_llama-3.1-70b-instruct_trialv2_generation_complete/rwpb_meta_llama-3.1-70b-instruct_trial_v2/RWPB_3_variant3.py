
def get_focalLength_from_fieldOfView(fov=60, img_size=512):
    import math
    def get_focalLength_from_fieldOfView(fov=60, img_size=512):
        sensor_width = img_size
        return (sensor_width / 2) / math.tan(math.radians(fov / 2))
