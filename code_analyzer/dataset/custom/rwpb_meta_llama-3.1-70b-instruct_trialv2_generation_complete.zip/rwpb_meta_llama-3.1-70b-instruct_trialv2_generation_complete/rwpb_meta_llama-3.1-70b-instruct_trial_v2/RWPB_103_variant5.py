
def unsafeAdd(x, y):
    def unsafeAdd(x, y):
        mask = (1 << 256) - 1
        return (x + y) & mask
