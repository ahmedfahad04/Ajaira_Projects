
def rotate_x(a, device=None):
    import torch
    def rotate_x(a, device=None):
        if device is None:
            device = torch.device('cpu')
        rotation_matrix = torch.eye(4, device=device, dtype=torch.float32)
        rotation_matrix[1, 1] = torch.cos(a)
        rotation_matrix[1, 2] = -torch.sin(a)
        rotation_matrix[2, 1] = torch.sin(a)
        rotation_matrix[2, 2] = torch.cos(a)
        return rotation_matrix
