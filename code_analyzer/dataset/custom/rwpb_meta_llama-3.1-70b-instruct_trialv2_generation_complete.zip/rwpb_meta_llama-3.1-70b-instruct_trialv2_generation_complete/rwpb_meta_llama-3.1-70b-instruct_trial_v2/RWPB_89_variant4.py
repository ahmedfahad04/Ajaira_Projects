
def format_ratio(ratio):
    def format_ratio(ratio):
        formatted_ratio = "{:.3f}".format(ratio)
        result = "percentage:"
        result += formatted_ratio
        return result
