
def merge_short_sentences_en(sens):
    def merge_short_sentences_en(sens):
        result = []
        for i, sentence in enumerate(sens):
            if len(sentence.split()) >= 5:
                result.append(sentence)
            elif i < len(sens) - 1:
                sens[i + 1] = sentence + " " + sens[i + 1]
        return result
