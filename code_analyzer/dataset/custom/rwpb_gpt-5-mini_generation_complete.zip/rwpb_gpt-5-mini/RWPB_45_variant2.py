
def invalid_to_zeros(arr, valid_mask, ndim=999):
    import torch
    def invalid_to_zeros(arr, valid_mask, ndim=999):
        if not isinstance(arr, torch.Tensor):
            arr = torch.tensor(arr)
        # flatten trailing dims if requested
        if ndim != 999 and arr.dim() > ndim:
            arr = arr.view(*arr.shape[:ndim - 1], -1)
        # If no mask, assume all valid -> nnz per-image as total elements / batch
        if valid_mask is None:
            if arr.dim() >= 1:
                nnz = arr.numel() // arr.shape[0]
            else:
                nnz = arr.numel()
            return arr, nnz
        mask = valid_mask.bool()
        # Create a mask broadcastable to arr using multiplication approach (non in-place)
        if mask.numel() == arr.numel():
            mask_view = mask.view_as(arr)
        else:
            # try to reshape mask as (B, -1) and then unsqueeze to match arr dims
            if arr.dim() >= 2 and mask.numel() == arr.shape[0] * (arr.numel() // arr.shape[0]):
                mask_view = mask.view(arr.shape[0], -1)
            else:
                try:
                    mask_view = mask.view(arr.shape[0], -1)
                except Exception:
                    mask_view = mask.reshape(-1)
                    if mask_view.numel() == arr.numel():
                        mask_view = mask_view.view_as(arr)
        # If mask_view is 2D and arr has more dims, unsqueeze last dims
        if mask_view.dim() == 2 and arr.dim() > 2:
            shape = list(mask_view.shape) + [1] * (arr.dim() - 2)
            mask_view = mask_view.view(*shape)
        # Broadcast to arr shape
        try:
            mask_b = mask_view.expand_as(arr)
        except Exception:
            # final fallback: flatten arr and mask
            flat_arr = arr.view(-1)
            flat_mask = mask.view(-1)
            out = torch.where(flat_mask, flat_arr, torch.zeros_like(flat_arr))
            out = out.view_as(arr)
            nnz = int(flat_mask.sum().item())
            return out, nnz
        # Use element-wise multiplication to zero invalid entries
        out = arr * mask_b.to(dtype=arr.dtype)
        # Compute nnz: prefer per-image count if possible
        if arr.dim() >= 1:
            nnz = mask_b.view(arr.shape[0], -1).sum(dim=1)
        else:
            nnz = mask_b.sum()
        return out, nnz
