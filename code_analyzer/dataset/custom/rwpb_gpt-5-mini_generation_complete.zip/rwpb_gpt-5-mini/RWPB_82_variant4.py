
def is_tensor(x):
    import numpy as np
    def is_tensor(x):
        if isinstance(x, np.ndarray):
            return True
        t = type(x)
        mod = getattr(t, "__module__", "")
        name = getattr(t, "__name__", "")
        if mod.startswith("torch") and name.endswith("Tensor"):
            return True
        if hasattr(x, "numpy") and callable(getattr(x, "numpy")) and hasattr(x, "dtype"):
            return True
        return False
