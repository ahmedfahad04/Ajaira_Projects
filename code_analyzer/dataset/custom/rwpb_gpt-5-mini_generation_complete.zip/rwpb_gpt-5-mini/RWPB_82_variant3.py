
def is_tensor(x):
    import importlib.util
    import importlib
    import numpy as np
    def is_tensor(x):
        spec = importlib.util.find_spec("torch")
        if spec:
            torch = importlib.import_module("torch")
            tensor_cls = getattr(torch, "Tensor", None)
            if tensor_cls is not None and isinstance(x, tensor_cls):
                return True
        return isinstance(x, np.ndarray)
