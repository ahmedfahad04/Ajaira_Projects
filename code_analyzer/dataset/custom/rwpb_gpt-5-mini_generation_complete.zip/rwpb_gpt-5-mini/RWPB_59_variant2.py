
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        if repetition_penalty == 1.0 or repetition_penalty == 0:
            return logits
        logits = logits.clone()
        batch_size, vocab_size = logits.shape
        device = logits.device
        # Build presence mask per batch via scatter
        # prev_output_tokens: (batch, seq_len)
        # Create mask of size (batch, vocab)
        mask = torch.zeros((batch_size, vocab_size), dtype=torch.bool, device=device)
        # flatten indices for scatter
        batch_idx = torch.arange(batch_size, device=device).unsqueeze(1).expand_as(prev_output_tokens)
        flat_b = batch_idx.reshape(-1)
        flat_t = prev_output_tokens.reshape(-1)
        # ignore negative token indices
        valid = flat_t >= 0
        if valid.any():
            indices_b = flat_b[valid]
            indices_t = flat_t[valid]
            mask[indices_b, indices_t] = True
        # compute penalty multiplier for positive and negative logits
        # for tokens that appeared: multiply by penalty if logit<0 else multiply by 1/repetition_penalty
        penalty_for_pos = 1.0 / repetition_penalty
        penalty_for_neg = repetition_penalty
        # build penalty tensor same shape as logits
        pos_mask = logits > 0
        # default multiplier 1.0
        multiplier = torch.ones_like(logits)
        # for positions that are present and positive
        multiplier = torch.where(mask & pos_mask, torch.tensor(penalty_for_pos, device=device, dtype=logits.dtype), multiplier)
        multiplier = torch.where(mask & (~pos_mask), torch.tensor(penalty_for_neg, device=device, dtype=logits.dtype), multiplier)
        return logits * multiplier
