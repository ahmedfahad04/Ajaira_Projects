
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        if repetition_penalty == 1.0 or repetition_penalty == 0:
            return logits
        # ensure tensors
        logits = logits.clone()
        batch_size, vocab_size = logits.size()
        # handle negative/padding tokens by ignoring them
        for b in range(batch_size):
            prev = prev_output_tokens[b]
            # get unique positive token indices
            unique_tokens = torch.unique(prev)
            # filter out negative indices (if any)
            unique_tokens = unique_tokens[unique_tokens >= 0]
            if unique_tokens.numel() == 0:
                continue
            for tid in unique_tokens.tolist():
                score = logits[b, tid]
                if score < 0:
                    logits[b, tid] = score * repetition_penalty
                else:
                    logits[b, tid] = score / repetition_penalty
        return logits
