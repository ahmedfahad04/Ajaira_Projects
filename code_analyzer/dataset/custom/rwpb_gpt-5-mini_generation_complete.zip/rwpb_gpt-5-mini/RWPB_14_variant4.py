
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float).ravel()[:3]
        b = np.asarray(b, dtype=float).ravel()[:3]
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na == 0 or nb == 0:
            return (None, None)
        u = a / na
        v = b / nb
        if np.allclose(u, v, atol=1e-12):
            return (None, None)
        # compute rotation matrix using formula R = I + K + K^2 * (1/(1+dot))
        dot = np.dot(u, v)
        k = np.array([[0, - (u[1]*v[2] - u[2]*v[1]), (u[1]*v[2] - u[2]*v[1])],
                      [(u[2]*v[0] - u[0]*v[2]), 0, - (u[2]*v[0] - u[0]*v[2])],
                      [-(u[1]*v[0] - u[0]*v[1]), (u[1]*v[0] - u[0]*v[1]), 0]])
        # Note: k above uses cross terms; better compute cross and its skew matrix
        c = np.cross(u, v)
        K = np.array([[0, -c[2], c[1]],
                      [c[2], 0, -c[0]],
                      [-c[1], c[0], 0]])
        denom = 1.0 + dot
        if np.abs(denom) < 1e-12:
            # antiparallel
            idx = np.argmin(np.abs(u))
            tmp = np.zeros(3); tmp[idx] = 1.0
            axis = np.cross(u, tmp)
            axis = axis / np.linalg.norm(axis)
            return (axis, np.pi)
        R = np.eye(3) + K + (K @ K) / denom
        # angle from trace
        trace = np.trace(R)
        angle = np.arccos(np.clip((trace - 1.0) / 2.0, -1.0, 1.0))
        s = np.sin(angle)
        if np.abs(s) < 1e-12:
            # fallback to cross-based axis
            cnorm = np.linalg.norm(c)
            if cnorm < 1e-12:
                return (None, None)
            axis = c / cnorm
            return (axis, angle)
        axis = np.array([R[2,1] - R[1,2], R[0,2] - R[2,0], R[1,0] - R[0,1]]) / (2.0 * s)
        return (axis, angle)
