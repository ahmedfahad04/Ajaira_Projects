
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        if normal_map.ndim != 3 or normal_map.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        theta = np.deg2rad(angle)
        c = np.cos(theta)
        s = np.sin(theta)
        R = np.array([[c, 0.0, s],
                      [0.0, 1.0, 0.0],
                      [-s, 0.0, c]], dtype=np.float64)
        nm = np.asarray(normal_map, dtype=np.float64)
        # apply rotation matrix using einsum to preserve shape
        rotated = np.einsum('ij,hwj->hwi', R, nm)
        # renormalize to unit length to avoid numerical drift
        norm = np.linalg.norm(rotated, axis=-1, keepdims=True)
        eps = 1e-12
        rotated = rotated / np.where(norm > eps, norm, 1.0)
        return rotated.astype(normal_map.dtype)
