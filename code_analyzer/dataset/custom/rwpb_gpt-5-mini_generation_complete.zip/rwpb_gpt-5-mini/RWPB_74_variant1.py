
def arccos2(vector, value):
    import math
    import numpy as np
    def arccos2(vector, value):
        v = np.asarray(vector, dtype=float)
        val = float(value)
        if val != val:
            return float('nan')
        if val > 1.0:
            val = 1.0
        elif val < -1.0:
            val = -1.0
        angle = math.acos(val)
        try:
            norm = np.linalg.norm(v)
        except Exception:
            norm = 0.0
        if norm == 0.0:
            return angle
        if v.shape[0] < 2:
            return angle
        if float(v[1]) < 0.0:
            return -angle
        return angle
