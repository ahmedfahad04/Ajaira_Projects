
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        """
        Variant that rescales each channel independently and optionally thresholds to binary masks.
        """
        if not isinstance(masks, torch.Tensor):
            masks = torch.tensor(masks)
        if masks.ndim != 4:
            raise ValueError("masks must be (N, C, H, W)")
        N, C, H, W = masks.shape
        target_h, target_w = shape
        if not padding:
            resized = F.interpolate(masks, size=(target_h, target_w), mode='bilinear', align_corners=False)
            return resized
        # padding True: center-crop after resizing to square canvas
        s = max(target_h, target_w)
        up = F.interpolate(masks, size=(s, s), mode='bilinear', align_corners=False)
        top = (s - target_h) // 2
        left = (s - target_w) // 2
        cropped = up[:, :, top:top + target_h, left:left + target_w]
        # Make output binary if inputs were integer/bool like; preserve floats otherwise
        if masks.dtype in (torch.uint8, torch.bool) or (masks.dtype.is_floating_point and masks.max() <= 1.0 and masks.min() >= 0.0 and (masks.unique().numel() <= 2)):
            return (cropped >= 0.5).to(cropped.dtype)
        return cropped
