
def seconds_to_hh_mm_ss(seconds):
    def seconds_to_hh_mm_ss(seconds):
        import datetime
        try:
            seconds = int(seconds)
        except Exception:
            return "00:00:00"
        if seconds < 0:
            return "00:00:00"
        td = datetime.timedelta(seconds=seconds)
        total = int(td.total_seconds())
        h = total // 3600
        m = (total % 3600) // 60
        s = total % 60
        return f"{h:02d}:{m:02d}:{s:02d}"
