
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        """
        Variant using grid_sample to perform precise spatial transformation when removing padding.
        Assumes masks are defined on a square letterboxed canvas when padding=True.
        """
        if not isinstance(masks, torch.Tensor):
            masks = torch.tensor(masks)
        if masks.ndim != 4:
            raise ValueError("masks must be 4D tensor")
        N, C, H, W = masks.shape
        target_h, target_w = shape
        device = masks.device
        dtype = masks.dtype
        if not padding:
            return F.interpolate(masks, size=(target_h, target_w), mode='bilinear', align_corners=False)
        # Upsample source masks to the letterboxed square size s
        s = max(target_h, target_w)
        src = F.interpolate(masks, size=(s, s), mode='bilinear', align_corners=False)
        # We'll crop the central (target_h, target_w) region from src.
        # Build a grid for the output of size (target_h, target_w) that samples the correct region from src.
        # normalized coordinates in grid_sample are in [-1,1]
        y0 = (s - target_h) / 2.0
        x0 = (s - target_w) / 2.0
        # Create normalized coordinate grid
        ys = torch.linspace(0, target_h - 1, steps=target_h, device=device, dtype=dtype)
        xs = torch.linspace(0, target_w - 1, steps=target_w, device=device, dtype=dtype)
        ys = (ys + y0) / (s - 1) * 2 - 1
        xs = (xs + x0) / (s - 1) * 2 - 1
        grid_y, grid_x = torch.meshgrid(ys, xs, indexing='ij')
        grid = torch.stack((grid_x, grid_y), dim=2)  # HxWx2 with x,y order for grid_sample
        grid = grid.unsqueeze(0).repeat(N, 1, 1, 1)
        out = F.grid_sample(src, grid, mode='bilinear', padding_mode='zeros', align_corners=True)
        return out
