
def _ssim(img1, img2, window, window_size, channel, size_average=True):
    import torch
    import torch.nn.functional as F
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        # support 3D (C,H,W) or 4D (N,C,H,W)
        if img1.shape != img2.shape:
            raise ValueError("Input images must have the same dimensions.")
        if img1.dim() == 3:
            img1 = img1.unsqueeze(0)
            img2 = img2.unsqueeze(0)
        N, C, H, W = img1.shape
        assert C == channel
        pad = window_size // 2
        # Ensure kernel shape (1,1,ws,ws)
        if window.dim() == 4:
            kernel = window.to(img1.device, dtype=img1.dtype)
        else:
            kernel = window.view(1,1,window_size,window_size).to(img1.device, dtype=img1.dtype)
        C1 = (0.01) ** 2
        C2 = (0.03) ** 2
        # compute per-channel SSIM by iterating channels
        ssim_per_channel_map = []
        for ch in range(C):
            w = kernel
            mu1 = F.conv2d(img1[:, ch:ch+1, :, :], w, padding=pad)
            mu2 = F.conv2d(img2[:, ch:ch+1, :, :], w, padding=pad)
            mu1_sq = mu1 * mu1
            mu2_sq = mu2 * mu2
            mu1_mu2 = mu1 * mu2
            sigma1_sq = F.conv2d(img1[:, ch:ch+1, :, :] * img1[:, ch:ch+1, :, :], w, padding=pad) - mu1_sq
            sigma2_sq = F.conv2d(img2[:, ch:ch+1, :, :] * img2[:, ch:ch+1, :, :], w, padding=pad) - mu2_sq
            sigma12 = F.conv2d(img1[:, ch:ch+1, :, :] * img2[:, ch:ch+1, :, :], w, padding=pad) - mu1_mu2
            num = (2 * mu1_mu2 + C1) * (2 * sigma12 + C2)
            den = (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)
            ssim_map_ch = num / (den + 1e-12)
            ssim_per_channel_map.append(ssim_map_ch)
        ssim_map = torch.cat(ssim_per_channel_map, dim=1)  # (N, C, H, W)
        if size_average:
            return ssim_map.mean()
        else:
            # mean over batch and spatial dims for each channel
            return ssim_map.view(N, C, -1).mean(dim=0).mean(dim=1)
