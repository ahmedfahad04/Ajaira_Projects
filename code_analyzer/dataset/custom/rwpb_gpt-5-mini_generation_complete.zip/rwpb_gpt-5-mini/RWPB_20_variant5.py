
def get_line_angle(x1, y1, x2, y2):
    import cmath
    import math
    def get_line_angle(x1, y1, x2, y2):
        z = complex(x2 - x1, y2 - y1)
        return math.degrees(cmath.phase(z))
