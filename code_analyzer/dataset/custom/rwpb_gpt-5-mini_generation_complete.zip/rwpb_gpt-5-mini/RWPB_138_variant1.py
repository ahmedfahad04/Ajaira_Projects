
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        if normal_map.ndim != 3 or normal_map.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        theta = np.deg2rad(angle)
        c = np.cos(theta)
        s = np.sin(theta)
        normals = np.asarray(normal_map, dtype=np.float64)
        x = normals[..., 0]
        y = normals[..., 1]
        z = normals[..., 2]
        xr = c * x + s * z
        yr = y
        zr = -s * x + c * z
        rotated = np.stack((xr, yr, zr), axis=-1)
        norm = np.linalg.norm(rotated, axis=-1, keepdims=True)
        eps = 1e-12
        rotated = rotated / np.where(norm > eps, norm, 1.0)
        return rotated.astype(normal_map.dtype)
