
def rotate_about_z_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_z_axis(vector, theta):
        v = np.asarray(vector, dtype=float)
        x, y, z = float(v[0]), float(v[1]), float(v[2])
        c = math.cos(theta)
        s = math.sin(theta)
        # use complex multiplication for xy plane rotation
        comp = complex(x, y) * complex(c, s)
        xr, yr = comp.real, comp.imag
        return np.array([xr, yr, z], dtype=float)
