
def view_range(x, i, j, shape):
    import torch
    from functools import reduce
    import operator
    def view_range(x, i, j, shape):
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        ndim = x.dim()
        if j is None:
            j = ndim
        if i < 0:
            i += ndim
        if j < 0:
            j += ndim
        if not (0 <= i <= j <= ndim):
            raise IndexError("Invalid indices")
        # get sizes and product
        sizes = list(x.shape)
        mid_sizes = sizes[i:j]
        def prod(seq):
            p = 1
            for s in seq:
                p *= s
            return p
        mid_prod = prod(mid_sizes)
        target = list(shape)
        if -1 in target:
            if target.count(-1) > 1:
                raise ValueError("Only one -1 allowed")
            known = prod([t for t in target if t != -1])
            if known == 0 or mid_prod % known != 0:
                raise ValueError("Cannot infer -1 or incompatible")
            target[target.index(-1)] = mid_prod // known
        if prod(target) != mid_prod:
            raise ValueError("Target does not match number of elements")
        # Build a list of slices to index into x, then reshape by flattening and unflattening
        # Flatten the middle dimensions into one on the fly using reshape then unflatten using view
        pre = sizes[:i]
        post = sizes[j:]
        flattened = x.reshape(*pre, mid_prod, *post)
        # now unflatten the middle dim into target
        return flattened.reshape(*pre, *target, *post)
