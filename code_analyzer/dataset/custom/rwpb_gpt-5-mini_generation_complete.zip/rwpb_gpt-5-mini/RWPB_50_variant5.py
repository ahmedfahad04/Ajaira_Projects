
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        if not isinstance(tensor, torch.Tensor):
            tensor = torch.tensor(tensor)
        if tensor.ndim != 3:
            raise ValueError("Expected CxHxW tensor")
        C, H, W = tensor.shape
        oh, ow = int(original_size[0]), int(original_size[1])
        if H == oh and W == ow:
            return tensor.contiguous()
        # Prefer exact central crop when possible
        dh = H - oh
        dw = W - ow
        if dh >= 0 and dw >= 0:
            top = dh // 2
            left = dw // 2
            return tensor[:, top:top + oh, left:left + ow].contiguous()
        # If we need to expand, first try symmetric reflect pad (fallback to interpolate)
        pad_top = max(0, (-dh) // 2)
        pad_bottom = max(0, -dh - pad_top)
        pad_left = max(0, (-dw) // 2)
        pad_right = max(0, -dw - pad_left)
        if pad_top + pad_bottom > 0 or pad_left + pad_right > 0:
            try:
                padded = F.pad(tensor, (pad_left, pad_right, pad_top, pad_bottom), mode='reflect')
                if padded.shape[1] == oh and padded.shape[2] == ow:
                    return padded.contiguous()
                return F.interpolate(padded.unsqueeze(0), size=(oh, ow), mode='bilinear', align_corners=False).squeeze(0).contiguous()
            except Exception:
                return F.interpolate(tensor.unsqueeze(0), size=(oh, ow), mode='bilinear', align_corners=False).squeeze(0).contiguous()
        return F.interpolate(tensor.unsqueeze(0), size=(oh, ow), mode='bilinear', align_corners=False).squeeze(0).contiguous()
