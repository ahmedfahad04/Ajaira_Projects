
def fit_params(:
    def fit_params(
        x,
        y,
        fun,
        a_range=(-10, 10),
        b_range=(-10, 10),
        grid_number=101,
        iteration=3,
        verbose=True,
    ):
        import torch
        import numpy as np
        # We'll do a two-stage approach: coarse random search followed by gradient-based refinement (torch autograd)
        device = torch.device("cpu")
        # convert to torch floats
        if torch.is_tensor(x):
            xt = x.to(device).float().reshape(-1)
        else:
            xt = torch.tensor(x, dtype=torch.float32, device=device).reshape(-1)
        if torch.is_tensor(y):
            yt = y.to(device).float().reshape(-1)
        else:
            yt = torch.tensor(y, dtype=torch.float32, device=device).reshape(-1)
        # coarse sampling over grid to get good starting points
        a_min, a_max = float(a_range[0]), float(a_range[1])
        b_min, b_max = float(b_range[0]), float(b_range[1])
        best_r2 = -1e9
        best_state = None
        # coarse grid (smaller)
        G = min(41, grid_number)
        a_vals = np.linspace(a_min, a_max, G)
        b_vals = np.linspace(b_min, b_max, G)
        for a in a_vals:
            for b in b_vals:
                z = torch.tensor(np.asarray(fun(a * xt.cpu().numpy() + b)), dtype=torch.float32)
                # linear solve for c,d using torch
                z_mean = z.mean()
                denom = (z * z).sum() - z_mean * z.sum()
                # use closed form via least squares with intercept
                A = torch.stack([z, torch.ones_like(z)], dim=1)
                sol, _ = torch.lstsq(yt.unsqueeze(1), A)
                # torch.lstsq behavior differs; use pinv
                theta = torch.pinverse(A) @ yt
                c = float(theta[0].item())
                d = float(theta[1].item())
                yp = c * z + d
                ss_res = ((yt - yp) ** 2).sum().item()
                ss_tot = ((yt - yt.mean()) ** 2).sum().item()
                r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else (1.0 if ss_res == 0 else -1e9)
                if r2 > best_r2:
                    best_r2 = r2
                    best_state = (a, b, c, d)
        # use best_state as initialization and refine with gradient-based optimizer
        a_init, b_init, c_init, d_init = best_state
        a_param = torch.tensor(a_init, requires_grad=True, dtype=torch.float32)
        b_param = torch.tensor(b_init, requires_grad=True, dtype=torch.float32)
        c_param = torch.tensor(c_init, requires_grad=True, dtype=torch.float32)
        d_param = torch.tensor(d_init, requires_grad=True, dtype=torch.float32)
        optimizer = torch.optim.Adam([a_param, b_param, c_param, d_param], lr=0.05)
        epochs = 300
        for epoch in range(epochs):
            optimizer.zero_grad()
            z_in = a_param * xt + b_param
            # fun may be numpy or torch; try torch first, fallback to numpy
            try:
                z = fun(z_in)
                if not torch.is_tensor(z):
                    z = torch.tensor(np.asarray(z), dtype=torch.float32)
            except Exception:
                z = torch.tensor(np.asarray(fun(z_in.detach().cpu().numpy())), dtype=torch.float32)
            y_pred = c_param * z + d_param
            loss = ((yt - y_pred) ** 2).mean()
            loss.backward()
            optimizer.step()
        # evaluate final
        with torch.no_grad():
            z_in = a_param * xt + b_param
            try:
                z = fun(z_in)
                if not torch.is_tensor(z):
                    z = torch.tensor(np.asarray(z), dtype=torch.float32)
            except Exception:
                z = torch.tensor(np.asarray(fun(z_in.detach().cpu().numpy())), dtype=torch.float32)
            y_pred = c_param * z + d_param
            ss_res = ((yt - y_pred) ** 2).sum().item()
            ss_tot = ((yt - yt.mean()) ** 2).sum().item()
            r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else (1.0 if ss_res == 0 else -1e9)
        return torch.tensor([a_param.item(), b_param.item(), c_param.item(), d_param.item()], dtype=torch.float64), torch.tensor(float(r2), dtype=torch.float64)
