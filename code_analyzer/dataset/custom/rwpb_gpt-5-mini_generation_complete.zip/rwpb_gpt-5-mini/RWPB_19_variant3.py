
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        n = len(preds)
        if n < 2:
            return 0.0
        idxs = sorted(range(n), key=lambda i: preds[i])
        groups = []
        cur_group = [idxs[0]]
        for k in idxs[1:]:
            if preds[k] == preds[cur_group[0]]:
                cur_group.append(k)
            else:
                groups.append(cur_group)
                cur_group = [k]
        groups.append(cur_group)
        total_pairs = n * (n - 1) // 2 - sum(len(g) * (len(g) - 1) // 2 for g in groups)
        if total_pairs == 0:
            return 0.0
        vals = list(sorted(set(references)))
        rank = {v: i + 1 for i, v in enumerate(vals)}
        size = len(vals) + 2
        BIT = [0] * (size)
        def bit_add(i, v):
            while i < size:
                BIT[i] += v
                i += i & -i
        def bit_sum(i):
            s = 0
            while i > 0:
                s += BIT[i]
                i -= i & -i
            return s
        concordant = 0
        for g in groups:
            for i in g:
                r = rank[references[i]]
                concordant += bit_sum(r - 1)
            for i in g:
                bit_add(rank[references[i]], 1)
        return concordant / total_pairs
