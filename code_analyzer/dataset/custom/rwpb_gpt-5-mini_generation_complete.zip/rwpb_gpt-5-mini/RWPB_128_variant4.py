
def xywh2xyxy(x):
    import numpy as np
    import torch
    def xywh2xyxy(x):
        if isinstance(x, (list, tuple)):
            arr = np.array(x)
            if arr.shape[-1] != 4:
                raise ValueError("Last dimension must be 4")
            out = arr.copy()
            out[..., 2:] = out[..., :2] + out[..., 2:]
            return out
        if isinstance(x, np.ndarray):
            if x.shape[-1] != 4:
                raise ValueError("Last dimension must be 4")
            out = x.copy()
            out[..., 2:] = out[..., :2] + out[..., 2:]
            return out
        if torch.is_tensor(x):
            if x.shape[-1] != 4:
                raise ValueError("Last dimension must be 4")
            out = x.clone()
            out[..., 2:] = out[..., :2] + out[..., 2:]
            return out
        raise TypeError("Input must be numpy array, torch tensor, list or tuple")
