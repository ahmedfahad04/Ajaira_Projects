
def psnr_to_mse(psnr):
    import numpy as np
    def psnr_to_mse(psnr):
        return np.exp(-0.1 * np.log(10.0) * psnr)
