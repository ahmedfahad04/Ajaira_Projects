
def get_confusion_matrix(gt_label, pred_label, num_classes):
    import numpy as np
    def get_confusion_matrix(gt_label, pred_label, num_classes):
        gt = np.asarray(gt_label)
        pred = np.asarray(pred_label)
        if gt.shape != pred.shape:
            raise ValueError("gt_label and pred_label must have the same length")
        if num_classes <= 0:
            return np.zeros((0, 0), dtype=np.int64)
        cm = np.zeros((num_classes, num_classes), dtype=np.int64)
        for t, p in zip(gt.flat, pred.flat):
            if 0 <= int(t) < num_classes and 0 <= int(p) < num_classes:
                cm[int(t), int(p)] += 1
        return cm
