
def round_nearest_multiple(number, a, direction='standard'):
    from fractions import Fraction
    from decimal import Decimal, ROUND_HALF_UP
    def round_nearest_multiple(number, a, direction='standard'):
        if a == 0:
            raise ValueError("a must be non-zero")
        # Use Fraction from string to avoid binary floating issues
        fq = Fraction(str(number)) / Fraction(str(a))
        dir_lower = (direction or 'standard').lower()
        if dir_lower == 'standard':
            # nearest with halves away from zero
            if fq >= 0:
                k = int((fq + Fraction(1, 2)).numerator // (fq + Fraction(1, 2)).denominator)
            else:
                # for negative, add -1/2 and floor via integer division trick
                k = int((fq - Fraction(1, 2)).numerator // (fq - Fraction(1, 2)).denominator)
        elif dir_lower == 'down':
            # floor
            k = fq.numerator // fq.denominator
        elif dir_lower == 'up':
            # ceil
            k = -((-fq.numerator) // fq.denominator)
        else:
            raise ValueError("direction must be 'standard', 'down', or 'up'")
        result_frac = Fraction(str(a)) * k
        # Determine decimal places from 'a'
        da = Decimal(str(a))
        places = -da.as_tuple().exponent if da.as_tuple().exponent < 0 else 0
        # Convert to Decimal for formatting to exact decimal places
        dr = Decimal(result_frac.numerator) / Decimal(result_frac.denominator)
        if places > 0:
            quant = Decimal(1).scaleb(-places)
            dr = dr.quantize(quant, rounding=ROUND_HALF_UP)
        return float(dr)
