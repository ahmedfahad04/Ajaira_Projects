
def bbox_ioa(box1, box2, iou=False, eps=1e-7):
    import numpy as np
    def bbox_ioa(box1, box2, iou=False, eps=1e-7):
        box1 = np.asarray(box1, dtype=float)
        box2 = np.asarray(box2, dtype=float)
        if box1.ndim == 1:
            box1 = box1.reshape(1, 4)
        if box2.ndim == 1:
            box2 = box2.reshape(1, 4)
        n = box1.shape[0]
        m = box2.shape[0]
        if n == 0 or m == 0:
            return np.zeros((n, m), dtype=float)
        x1 = np.maximum(box1[:, None, 0], box2[None, :, 0])
        y1 = np.maximum(box1[:, None, 1], box2[None, :, 1])
        x2 = np.minimum(box1[:, None, 2], box2[None, :, 2])
        y2 = np.minimum(box1[:, None, 3], box2[None, :, 3])
        inter_w = np.clip(x2 - x1, 0, None)
        inter_h = np.clip(y2 - y1, 0, None)
        inter = inter_w * inter_h
        w1 = np.clip(box1[:, 2] - box1[:, 0], 0, None)
        h1 = np.clip(box1[:, 3] - box1[:, 1], 0, None)
        w2 = np.clip(box2[:, 2] - box2[:, 0], 0, None)
        h2 = np.clip(box2[:, 3] - box2[:, 1], 0, None)
        area1 = w1 * h1
        area2 = w2 * h2
        if iou:
            union = area1[:, None] + area2[None, :] - inter
            return inter / (union + eps)
        return inter / (area2[None, :] + eps)
