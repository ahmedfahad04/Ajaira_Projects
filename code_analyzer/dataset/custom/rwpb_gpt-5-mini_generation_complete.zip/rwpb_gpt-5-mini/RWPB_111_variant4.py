
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        ones_H = torch.ones(H, dtype=torch.float32)
        ones_W = torch.ones(W, dtype=torch.float32)
        x = torch.arange(W, dtype=torch.float32)
        y = torch.arange(H, dtype=torch.float32)
        X = ones_H.unsqueeze(1) * x.unsqueeze(0)  # (H, W)
        Y = y.unsqueeze(1) * ones_W.unsqueeze(0)  # (H, W)
        grid = torch.stack([X, Y], dim=0)
        return grid.unsqueeze(0).expand(B, -1, -1, -1)
