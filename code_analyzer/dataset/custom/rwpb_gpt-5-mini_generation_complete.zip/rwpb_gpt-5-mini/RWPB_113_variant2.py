
def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
    import torch
    def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
        # handle edge cases
        if num <= 0:
            return torch.empty(*torch.broadcast_shapes(start.shape, stop.shape), 0, device=start.device, dtype=torch.promote_types(start.dtype, stop.dtype))
        dtype = torch.promote_types(start.dtype, stop.dtype)
        device = start.device
        start = start.to(dtype)
        stop = stop.to(dtype)
        if num == 1:
            return start.unsqueeze(-1)
        # use arange to build normalized positions to avoid using linspace directly
        positions = torch.arange(0, num, dtype=dtype, device=device) / (num - 1)
        nd = max(start.dim(), stop.dim())
        if nd > 0:
            positions = positions.view((1,)*nd + (num,))
        return start + (stop - start) * positions
