
def rotate_normalmap_by_angle_torch(normal_map, angle):
    import torch, math
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        """
        Rotate by adjusting azimuth (atan2) of x,z components: preserves magnitude exactly (mod numeric).
        """
        if not isinstance(normal_map, torch.Tensor):
            raise TypeError("normal_map must be a torch.Tensor")
        if normal_map.shape[-1] != 3:
            raise ValueError("last dimension must be 3")
        device = normal_map.device
        dtype = normal_map.dtype
        theta = math.radians(angle)
        # x,z plane radius
        x = normal_map[..., 0]
        y = normal_map[..., 1]
        z = normal_map[..., 2]
        r = torch.sqrt(x * x + z * z)
        # compute current angle phi = atan2(z, x)
        phi = torch.atan2(z, x)
        phi2 = phi + torch.tensor(theta, device=device, dtype=dtype)
        xr = r * torch.cos(phi2)
        zr = r * torch.sin(phi2)
        rotated = torch.stack((xr, y, zr), dim=-1)
        # Re-normalize to guard numerical issues
        norms = rotated.norm(dim=-1, keepdim=True).clamp(min=1e-8)
        rotated = rotated / norms
        return rotated
