
def exp_smooth(vals, alpha):
    import numpy as np
    import sys
    sys.setrecursionlimit(10000)
    def exp_smooth(vals, alpha):
        arr = np.asarray(vals, dtype=float)
        if arr.size == 0:
            raise KeyError("Input array is empty")
        n = arr.size
        res = [None] * n
        def compute(i):
            if res[i] is not None:
                return res[i]
            if i == 0:
                res[0] = arr[0]
            else:
                res[i] = alpha * arr[i] + (1.0 - alpha) * compute(i - 1)
            return res[i]
        compute(n - 1)
        return np.array(res, dtype=float)
