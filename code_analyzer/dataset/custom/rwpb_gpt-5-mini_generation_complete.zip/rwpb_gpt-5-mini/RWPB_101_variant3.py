
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    def generate_grids(lower_limit, upper_limit, grid_size):
        lower = torch.as_tensor(lower_limit)
        upper = torch.as_tensor(upper_limit)
        gs = torch.as_tensor(grid_size)
        lower = lower.flatten().to(dtype=torch.float32, device=lower.device)
        upper = upper.flatten().to(dtype=torch.float32, device=lower.device)
        gs = gs.flatten()
        D = lower.numel()
        if gs.numel() == 1 and D > 1:
            gs = gs.expand(D)
        gs = gs.to(dtype=torch.long)
        edges_low = []
        edges_high = []
        for i in range(D):
            n = int(gs[i].item())
            if n < 1:
                raise ValueError("grid_size must be >=1")
            edges = torch.linspace(lower[i], upper[i], steps=n + 1, device=lower.device, dtype=lower.dtype)
            edges_low.append(edges[:-1])
            edges_high.append(edges[1:])
        # iterative product using repeat_interleave / repeat
        if D == 0:
            return torch.empty((0, 0), dtype=lower.dtype), torch.empty((0, 0), dtype=lower.dtype)
        # start with first dimension
        curr_low = edges_low[0].unsqueeze(1)
        curr_high = edges_high[0].unsqueeze(1)
        for i in range(1, D):
            vals_low = edges_low[i]
            vals_high = edges_high[i]
            m = curr_low.size(0)
            n = vals_low.size(0)
            # repeat each previous row n times and append tiled new column
            curr_low = torch.cat([curr_low.repeat_interleave(n, dim=0),
                                  vals_low.repeat(m).unsqueeze(1)], dim=1)
            curr_high = torch.cat([curr_high.repeat_interleave(n, dim=0),
                                   vals_high.repeat(m).unsqueeze(1)], dim=1)
        return curr_low, curr_high
