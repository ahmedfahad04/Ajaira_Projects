
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        # Use modulo to compute nearest multiple, prefer lower on exact ties
        if torch.is_tensor(divisor):
            d = float(divisor.max().item())
        else:
            d = float(divisor)
        if d == 0:
            raise ValueError("divisor must be non-zero")
        d = abs(d)
        x_f = float(x)
        r = x_f % d
        lower = x_f - r
        higher = lower + d
        if abs(x_f - lower) <= abs(higher - x_f):
            return int(lower)
        else:
            return int(higher)
