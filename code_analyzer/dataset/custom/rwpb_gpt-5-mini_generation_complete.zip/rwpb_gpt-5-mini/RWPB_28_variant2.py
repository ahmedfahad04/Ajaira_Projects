
def mean(l, ignore_nan=False, empty=0):
    import numpy as np
    import math
    def mean(l, ignore_nan=False, empty=0):
        """
        Convert iterable to numpy array and use numpy mean functions. Handles generators by fromiter.
        """
        # Build float array from iterable
        try:
            arr = np.fromiter((float(x) for x in l), dtype=float)
        except TypeError:
            # Fallback: materialize then convert
            tmp = [float(x) for x in l]
            arr = np.array(tmp, dtype=float)
        if arr.size == 0:
            if empty == 'raise':
                raise ValueError("mean of empty iterable")
            return empty
        if ignore_nan:
            # Count non-nan
            non_nan_mask = ~np.isnan(arr)
            if not np.any(non_nan_mask):
                if empty == 'raise':
                    raise ValueError("mean of empty iterable")
                return empty
            return float(np.nanmean(arr))
        else:
            # If NaN present, numpy.mean will return nan which is acceptable
            return float(np.mean(arr))
