
def fit_params(:
    def fit_params(
        x,
        y,
        fun,
        a_range=(-10, 10),
        b_range=(-10, 10),
        grid_number=101,
        iteration=3,
        verbose=True,
    ):
        import numpy as np
        from sklearn.linear_model import LinearRegression
        import torch
        # Convert to numpy
        if torch.is_tensor(x):
            x_np = x.detach().cpu().numpy()
        else:
            x_np = np.asarray(x)
        if torch.is_tensor(y):
            y_np = y.detach().cpu().numpy()
        else:
            y_np = np.asarray(y)
        a_min, a_max = float(a_range[0]), float(a_range[1])
        b_min, b_max = float(b_range[0]), float(b_range[1])
        best = {"r2": -np.inf, "a": None, "b": None, "c": None, "d": None}
        lr = LinearRegression()
        for it in range(iteration):
            a_vals = np.linspace(a_min, a_max, grid_number)
            b_vals = np.linspace(b_min, b_max, grid_number)
            for a in a_vals:
                ax = a * x_np
                for b in b_vals:
                    z = np.asarray(fun(ax + b)).reshape(-1, 1)
                    # LinearRegression to fit y ~ z (with intercept d)
                    lr.fit(z, y_np)
                    c = float(lr.coef_[0])
                    d = float(lr.intercept_)
                    y_pred = lr.predict(z)
                    ss_res = ((y_np - y_pred) ** 2).sum()
                    ss_tot = ((y_np - y_np.mean()) ** 2).sum()
                    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else (1.0 if ss_res == 0 else -np.inf)
                    if r2 > best["r2"]:
                        best.update({"r2": r2, "a": a, "b": b, "c": c, "d": d})
            # refine around best
            span_a = (a_max - a_min) / 10.0
            span_b = (b_max - b_min) / 10.0
            a_min = best["a"] - span_a
            a_max = best["a"] + span_a
            b_min = best["b"] - span_b
            b_max = best["b"] + span_b
            if verbose:
                print(f"Iter {it+1}/{iteration}, best r2={best['r2']:.6f}, a={best['a']}, b={best['b']}")
        return torch.tensor([best["a"], best["b"], best["c"], best["d"]], dtype=torch.float64), torch.tensor(best["r2"], dtype=torch.float64)
