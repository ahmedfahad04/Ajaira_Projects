
def pad_camera_extrinsics_4x4(extrinsics):
    import torch
    import torch.nn.functional as F
    def pad_camera_extrinsics_4x4(extrinsics):
        if not isinstance(extrinsics, torch.Tensor):
            raise TypeError("extrinsics must be a torch.Tensor")
        if extrinsics.shape[-2:] == (4, 4):
            return extrinsics
        if extrinsics.shape[-2:] != (3, 4):
            raise ValueError("Extrinsics must have shape (...,3,4) or (...,4,4)")
        padded = F.pad(extrinsics, (0, 0, 0, 1))
        padded[..., -1, -1] = 1
        return padded
