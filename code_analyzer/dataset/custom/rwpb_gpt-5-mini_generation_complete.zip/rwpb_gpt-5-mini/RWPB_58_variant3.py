
def unpad_image_shape(current_height, current_width, original_size):
    from fractions import Fraction
    import math
    def unpad_image_shape(current_height, current_width, original_size):
        orig_w, orig_h = original_size
        if orig_w <= 0 or orig_h <= 0:
            return (current_height, current_width)
        # use exact rational arithmetic to decide scale and compute sizes
        scale_w = Fraction(current_width, orig_w)
        scale_h = Fraction(current_height, orig_h)
        scale = scale_w if scale_w <= scale_h else scale_h
        # resulting sizes as Fractions
        new_w_frac = Fraction(orig_w) * scale
        new_h_frac = Fraction(orig_h) * scale
        # round to nearest integer safely
        new_w = max(1, min(current_width, int(math.floor(float(new_w_frac) + 0.5))))
        new_h = max(1, min(current_height, int(math.floor(float(new_h_frac) + 0.5))))
        return (new_h, new_w)
