
def unsafeAdd(x, y):
    MAX_VAL = (1 << 256) - 1
    MOD_MASK = (1 << 256) - 1
    def unsafeAdd(x, y):
        x &= MOD_MASK
        y &= MOD_MASK
        while y:
            carry = (x & y) << 1
            x = (x ^ y) & MOD_MASK
            y = carry & MOD_MASK
        return x & MOD_MASK
