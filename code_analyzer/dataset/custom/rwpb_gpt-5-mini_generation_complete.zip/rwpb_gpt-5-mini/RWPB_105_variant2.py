
def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        """
        Manual vectorized trilinear interpolation.
        Assumes grid shape (1, C, H, W, D) and coordinates in voxel indices (x, y, z).
        """
        if grid.ndim != 5:
            raise ValueError("Grid must be 5D (1, C, H, W, D)")
        device = grid.device
        dtype = grid.dtype
        # Reorder to (C, D, H, W) for easier indexing (remove batch dim 1)
        # Input given as (1, C, H, W, D) => permute to (C, D, H, W)
        vol = grid.permute(1, 4, 2, 3).squeeze(0)  # (C, D, H, W)
        C_ch, D, H, W = vol.shape
        B, P, _ = coordinates.shape
        coords = coordinates.to(device=device, dtype=dtype)
        # interpret coords as (x, y, z) -> map to (W, H, D)
        x = coords[..., 0]
        y = coords[..., 1]
        z = coords[..., 2]
        # Clamp indices within voxel bounds for interpolation base
        x = x.clamp(0, W - 1)
        y = y.clamp(0, H - 1)
        z = z.clamp(0, D - 1)
        x0 = torch.floor(x).to(dtype=torch.long)
        y0 = torch.floor(y).to(dtype=torch.long)
        z0 = torch.floor(z).to(dtype=torch.long)
        x1 = (x0 + 1).clamp(max=W - 1)
        y1 = (y0 + 1).clamp(max=H - 1)
        z1 = (z0 + 1).clamp(max=D - 1)
        xd = (x - x0.to(dtype=dtype)).unsqueeze(2)  # (B,P,1)
        yd = (y - y0.to(dtype=dtype)).unsqueeze(2)
        zd = (z - z0.to(dtype=dtype)).unsqueeze(2)
        # gather values for the 8 corners
        # vol: (C, D, H, W) -> we will index as vol[:, z, y, x]
        # Build index tensors shaped (B*P,)
        idx_shape = (B * P,)
        def gather_vals(ix, iy, iz):
            # ix,iy,iz are long tensors shape (B,P)
            ix_flat = ix.reshape(-1)
            iy_flat = iy.reshape(-1)
            iz_flat = iz.reshape(-1)
            # indexing: produce (C, B*P)
            vals = vol[:, iz_flat, iy_flat, ix_flat]  # (C, B*P)
            return vals.view(C_ch, B, P).permute(1, 2, 0)  # (B, P, C)
        c000 = gather_vals(x0, y0, z0)
        c100 = gather_vals(x1, y0, z0)
        c010 = gather_vals(x0, y1, z0)
        c110 = gather_vals(x1, y1, z0)
        c001 = gather_vals(x0, y0, z1)
        c101 = gather_vals(x1, y0, z1)
        c011 = gather_vals(x0, y1, z1)
        c111 = gather_vals(x1, y1, z1)
        # Interpolate along x
        c00 = c000 * (1 - xd) + c100 * xd
        c01 = c001 * (1 - xd) + c101 * xd
        c10 = c010 * (1 - xd) + c110 * xd
        c11 = c011 * (1 - xd) + c111 * xd
        # Interpolate along y
        c0 = c00 * (1 - yd) + c10 * yd
        c1 = c01 * (1 - yd) + c11 * yd
        # Interpolate along z
        c = c0 * (1 - zd) + c1 * zd  # (B, P, C)
        return c.contiguous()
