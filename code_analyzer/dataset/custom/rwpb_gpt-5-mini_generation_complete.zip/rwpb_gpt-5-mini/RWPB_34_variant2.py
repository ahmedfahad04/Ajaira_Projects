
def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
    import numpy as np
    def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
        arr = np.asarray(tokens)
        target = max(0, int(context_window) + 1)
        orig_ndim = arr.ndim
        if orig_ndim == 0:
            arr = arr.reshape(1)
            orig_ndim = 1
        seq_len = arr.shape[-1]
        lead_shape = arr.shape[:-1]
        batch = int(np.prod(lead_shape)) if lead_shape else 1
        flat = arr.reshape(batch, seq_len)
        out_flat = np.full((batch, target), pad_token, dtype=arr.dtype)
        copy_len = min(seq_len, target)
        if copy_len > 0:
            out_flat[:, :copy_len] = flat[:, :copy_len]
        out = out_flat.reshape(lead_shape + (target,))
        if orig_ndim == 1:
            return out.reshape((target,))
        return out
