
def is_tensor(x):
    import importlib
    import importlib.util
    import numpy as np
    def is_tensor(x):
        if importlib.util.find_spec("torch") is not None:
            torch = importlib.import_module("torch")
            return isinstance(x, getattr(torch, "Tensor", type(None))) or isinstance(x, np.ndarray)
        return isinstance(x, np.ndarray)
