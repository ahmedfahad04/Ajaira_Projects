
def is_byte_token(s: str) -> bool:
    def is_byte_token(s: str) -> bool:
        if not isinstance(s, str) or len(s) != 6:
            return False
        if s[0] != '<' or s[-1] != '>':
            return False
        if s[1:3].lower() != '0x':
            return False
        hexpart = s[3:5]
        try:
            bytes.fromhex(hexpart)
        except Exception:
            return False
        return True
