
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    from collections import deque
    def pad_to_max_seq_length(ls: list, max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be a non-negative integer")
        d = deque(ls)
        cur_len = len(d)
        if cur_len > max_seq_length:
            if check:
                raise ValueError("Length exceeds max_seq_length")
            else:
                # don't modify content if not checking; return truncated copy
                result = list(d)[:max_seq_length]
                return result
        pad_count = max_seq_length - cur_len
        if pad_right:
            d.extend([pad_idx] * pad_count)
        else:
            # extendleft adds elements in reverse order, so we prepare reversed list
            for _ in range(pad_count):
                d.appendleft(pad_idx)
        return list(d)
