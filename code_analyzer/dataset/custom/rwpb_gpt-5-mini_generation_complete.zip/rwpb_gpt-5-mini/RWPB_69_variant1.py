
def fovx_to_fovy(fovx, aspect):
    import math
    def fovx_to_fovy(fovx, aspect):
        return 2.0 * math.atan(math.tan(0.5 * fovx) / aspect)
