
def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
    import torch
    import string
    def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        ndim = x.dim()
        if ndim == 0:
            return x.contiguous() if make_contiguous else x
        src = src_dim if src_dim >= 0 else src_dim + ndim
        dest = dest_dim if dest_dim >= 0 else dest_dim + ndim
        if not (0 <= src < ndim) or not (0 <= dest < ndim):
            raise IndexError("src_dim or dest_dim out of range")
        if src == dest:
            return x.contiguous() if make_contiguous else x
        # Try einsum-based reordering using alphabet labels if possible, else fallback to permute
        labels = list(string.ascii_lowercase + string.ascii_uppercase)
        if ndim <= len(labels):
            src_label_list = labels[:ndim]
            out_labels = src_label_list.copy()
            label = out_labels.pop(src)
            out_labels.insert(dest, label)
            einsum_str = ''.join(src_label_list) + '->' + ''.join(out_labels)
            out = torch.einsum(einsum_str, x)
        else:
            # fallback
            order = list(range(ndim))
            order.pop(src)
            order.insert(dest, src)
            out = x.permute(*order)
        return out.contiguous() if make_contiguous else out
