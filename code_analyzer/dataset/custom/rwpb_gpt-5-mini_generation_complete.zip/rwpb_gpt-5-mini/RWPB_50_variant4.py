
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    import math
    import torch.nn.functional as F
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        if not isinstance(tensor, torch.Tensor):
            tensor = torch.tensor(tensor)
        if tensor.dim() != 3:
            raise ValueError("Expected a CxHxW tensor")
        C, H, W = tensor.shape
        oh, ow = int(original_size[0]), int(original_size[1])
        # Exact match
        if H == oh and W == ow:
            return tensor.contiguous()
        # Center crop using ceil for odd differences to bias top/left
        if H >= oh and W >= ow:
            top = math.floor((H - oh) / 2)
            left = math.floor((W - ow) / 2)
            return tensor[:, top:top + oh, left:left + ow].contiguous()
        # If smaller, use interpolation (keeps central content)
        resized = F.interpolate(tensor.unsqueeze(0), size=(oh, ow), mode='bilinear', align_corners=False)
        return resized.squeeze(0).contiguous()
