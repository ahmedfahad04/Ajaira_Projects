
def xywh2xyxy(x):
    import numpy as np
    import torch
    def xywh2xyxy(x):
        if torch.is_tensor(x):
            if x.dim() == 0:
                raise ValueError("Input must have last dimension 4")
            if x.shape[-1] != 4:
                raise ValueError("Last dimension must be 4")
            x1 = x[..., 0:1]
            y1 = x[..., 1:2]
            x2 = x[..., 0:1] + x[..., 2:3]
            y2 = x[..., 1:2] + x[..., 3:4]
            return torch.cat([x1, y1, x2, y2], dim=-1)
        else:
            arr = np.asarray(x)
            if arr.ndim == 0 or arr.shape[-1] != 4:
                raise ValueError("Last dimension must be 4")
            x1 = arr[..., 0:1]
            y1 = arr[..., 1:2]
            x2 = arr[..., 0:1] + arr[..., 2:3]
            y2 = arr[..., 1:2] + arr[..., 3:4]
            return np.concatenate([x1, y1, x2, y2], axis=-1)
