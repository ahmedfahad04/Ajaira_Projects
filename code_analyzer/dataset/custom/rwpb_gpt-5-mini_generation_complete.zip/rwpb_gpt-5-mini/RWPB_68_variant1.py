
def last_before(val, arr):
    import numpy as np
    def last_before(val, arr):
        arr = np.asarray(arr)
        # Use numpy.searchsorted to find insertion point to the right, subtract 1
        idx = np.searchsorted(arr, val, side='right') - 1
        return int(idx)
