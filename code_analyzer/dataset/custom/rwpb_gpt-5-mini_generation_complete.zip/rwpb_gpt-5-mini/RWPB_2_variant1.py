
def logbessel_I_scipy(nu, z, check = True):
    import numpy as np
    import torch
    from scipy import special
    def logbessel_I_scipy(nu, z, check = True):
        # Convert input z to numpy array
        is_torch = isinstance(z, torch.Tensor)
        if is_torch:
            device = z.device
            dtype = z.dtype
            z_np = z.detach().cpu().numpy()
        else:
            z_np = np.array(z, copy=False)
            dtype = None
            device = None
        # Ensure 1D array
        orig_shape = z_np.shape
        z_flat = np.atleast_1d(z_np).ravel()
        # Compute I_nu using scipy
        iv = special.iv(nu, z_flat)
        # Check for zeros before log if requested
        if check and np.any(iv == 0):
            raise ValueError("Bessel I evaluated to zero for some entries; log undefined.")
        tiny = np.finfo(iv.dtype).tiny
        iv_safe = np.maximum(iv, tiny)
        log_iv = np.log(iv_safe)
        # Reshape back
        log_iv = log_iv.reshape(orig_shape)
        # Return torch tensor if input was torch, otherwise numpy array converted to torch for consistency
        if is_torch:
            return torch.tensor(log_iv, dtype=dtype, device=device)
        else:
            return torch.tensor(log_iv)
