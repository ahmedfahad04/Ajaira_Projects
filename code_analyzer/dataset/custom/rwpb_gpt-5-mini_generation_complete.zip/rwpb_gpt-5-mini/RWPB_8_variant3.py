
def cvimg2torch(img):
    import numpy as np
    import torch
    def cvimg2torch(img):
        """
        Convert image (HxWxC or HxW) to torch tensor 1xCxHxW.
        Uses numpy.moveaxis to change axes then torch.as_tensor to avoid copy if possible.
        Result is float32 scaled to [0,1].
        """
        arr = np.asarray(img)
        if arr.ndim == 2:
            arr = arr[..., None]
        # Move channel to first axis: C,H,W
        arr_ch_first = np.moveaxis(arr, -1, 0)
        # convert to float and normalize
        arr_ch_first = arr_ch_first.astype(np.float32) / 255.0
        tensor = torch.as_tensor(arr_ch_first)
        # add batch dimension at dim 0
        tensor = tensor.unsqueeze(0)
        return tensor
