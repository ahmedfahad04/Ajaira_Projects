
def rotate_about_x_axis(vector, theta):
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        """
        Rotate using Rodrigues' rotation formula for axis [1,0,0].
        """
        v = np.asarray(vector, dtype=float).ravel()
        if v.size < 3:
            raise ValueError("Input vector must have at least 3 components")
        k = np.array([1.0, 0.0, 0.0], dtype=float)  # axis
        v3 = v[:3]
        c = np.cos(theta)
        s = np.sin(theta)
        # Rodrigues: v_rot = v*c + (k x v)*s + k*(k.v)*(1-c)
        k_cross_v = np.cross(k, v3)
        k_dot_v = float(np.dot(k, v3))
        v_rot = v3 * c + k_cross_v * s + k * k_dot_v * (1.0 - c)
        return v_rot
