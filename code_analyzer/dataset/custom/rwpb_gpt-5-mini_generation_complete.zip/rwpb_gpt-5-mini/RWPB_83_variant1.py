
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        min_h, min_w = size
        img = sample.get("image", None)
        if img is None:
            return None
        h, w = img.shape[:2]
        # Determine scale to meet minimum while preserving aspect ratio
        scale = max(float(min_h) / h if h < min_h else 1.0,
                    float(min_w) / w if w < min_w else 1.0)
        if scale <= 1.0:
            return (h, w)
        new_h = int(math.ceil(h * scale))
        new_w = int(math.ceil(w * scale))
        # Resize main image
        resized_img = cv2.resize(img, (new_w, new_h), interpolation=image_interpolation_method)
        sample["image"] = resized_img
        # Resize disparity if present: use linear interpolation and scale disparity values
        disp = sample.get("disparity", None)
        if disp is not None:
            # Ensure disparity is single channel numpy array
            disp_arr = np.asarray(disp)
            # cv2.resize expects float for subpixel accuracy
            disp_resized = cv2.resize(disp_arr, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            disp_resized = (disp_resized * scale).astype(disp_arr.dtype)
            sample["disparity"] = disp_resized
        # Resize mask if present: nearest neighbor, keep binary
        mask = sample.get("mask", None)
        if mask is not None:
            mask_arr = np.asarray(mask)
            mask_resized = cv2.resize(mask_arr, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            # Ensure binary (0/1)
            if mask_resized.dtype != np.bool_:
                mask_resized = (mask_resized > 0.5).astype(mask_arr.dtype)
            sample["mask"] = mask_resized
        return (new_h, new_w)
