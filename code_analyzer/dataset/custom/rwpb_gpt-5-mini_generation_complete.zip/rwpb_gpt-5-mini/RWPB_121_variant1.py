
def isprime(n):
    import math
    def isprime(n):
        if not isinstance(n, int):
            return False
        if n <= 1:
            return False
        if n <= 3:
            return True
        if n % 2 == 0:
            return False
        r = int(math.sqrt(n))
        for i in range(3, r + 1, 2):
            if n % i == 0:
                return False
        return True
