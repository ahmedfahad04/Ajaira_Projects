
def getLambertCoefs(numOfLambertCoefs):
    def getLambertCoefs(numOfLambertCoefs):
        if not isinstance(numOfLambertCoefs, int) or numOfLambertCoefs <= 0:
            return []
        coefs = []
        fact = 1
        for n in range(1, numOfLambertCoefs + 1):
            fact *= n  # n!
            # compute (-n)^(n-1) carefully
            if n == 1:
                numer = 1
            else:
                numer = (-1 if n % 2 else 1) * (n ** (n - 1))
            coefs.append(numer / fact)
        return coefs
