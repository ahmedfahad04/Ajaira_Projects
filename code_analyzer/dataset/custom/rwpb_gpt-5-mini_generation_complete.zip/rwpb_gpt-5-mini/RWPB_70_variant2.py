
def psnr_to_mse(psnr):
    import math
    def psnr_to_mse(psnr):
        if hasattr(psnr, '__iter__') and not isinstance(psnr, (str, bytes)):
            return [math.exp(-0.1 * math.log(10.0) * float(p)) for p in psnr]
        return math.exp(-0.1 * math.log(10.0) * float(psnr))
