
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        result = {}
        # iterative with explicit stack that preserves insertion order
        items = list(d.items())
        stack = [(items, parent_key)]
        while stack:
            chunk, base = stack.pop()
            for k, v in chunk:
                ks = str(k)
                new_key = ks if base == "" else base + sep + ks
                if isinstance(v, dict):
                    if v:
                        stack.append((list(v.items()), new_key))
                    # else ignore empty dict
                else:
                    result[new_key] = v
        return result
