
def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        """
        Another approach using grid_sample but replicating the grid to batch and sampling with
        output layout (B, P, C). This variant treats coordinates as (z, y, x) ordering if detected,
        otherwise uses (x, y, z). It also falls back to nearest neighbor when the grid has degenerate dims.
        """
        if grid.ndim != 5:
            raise ValueError("Grid must be 5D (1, C, H, W, D) or (N, C, D, H, W)")
        B, P, dim3 = coordinates.shape
        if dim3 != 3:
            raise ValueError("Coordinates must have last dimension 3")
        coords = coordinates.clone().to(device=grid.device)
        # Attempt to infer ordering by comparing max coordinate to sizes
        # Permute to (N, C, D, H, W) assuming provided spec (1, C, H, W, D)
        grid_perm = grid.permute(0, 1, 4, 2, 3).contiguous()
        _, _, D, H, W = grid_perm.shape
        # Heuristic: if coords' max value is <= D-1 for first channel, they might be (z,y,x)
        mx0 = float(coords[..., 0].max())
        mx1 = float(coords[..., 1].max())
        mx2 = float(coords[..., 2].max())
        # Default interpret as (x,y,z)
        use_zyx = False
        # if first channel seems to be bounded by D, and last channel by W, treat as (z,y,x)
        if mx0 <= D - 1 + 1e-4 and mx2 <= W - 1 + 1e-4 and mx1 <= H - 1 + 1e-4:
            # ambiguous; but if coordinates look like (z,y,x), switch
            if mx0 > mx2:
                use_zyx = True
        if use_zyx:
            # reorder coords from (z,y,x) -> (x,y,z)
            coords = torch.stack([coords[..., 2], coords[..., 1], coords[..., 0]], dim=-1)
        # If any dimension size is 1, grid_sample with bilinear is meaningless; use nearest in that case.
        mode = 'bilinear'
        if D == 1 or H == 1 or W == 1:
            mode = 'nearest'
        # Normalize coords (voxel indices -> [-1,1])
        def norm(c, size):
            if size == 1:
                return torch.zeros_like(c)
            return 2.0 * c / (size - 1) - 1.0
        x_n = norm(coords[..., 0], W)
        y_n = norm(coords[..., 1], H)
        z_n = norm(coords[..., 2], D)
        grid_pts = torch.stack((x_n, y_n, z_n), dim=-1).view(B, P, 1, 1, 3)
        # replicate grid to batch
        if grid_perm.shape[0] == 1 and B > 1:
            grid_in = grid_perm.expand(B, -1, -1, -1, -1).contiguous()
        else:
            grid_in = grid_perm
        sampled = F.grid_sample(grid_in, grid_pts, mode=mode, padding_mode='zeros', align_corners=True)
        sampled = sampled.view(sampled.shape[0], sampled.shape[1], -1).permute(0, 2, 1).contiguous()
        return sampled
