
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        if not isinstance(tensor, torch.Tensor):
            tensor = torch.tensor(tensor)
        if tensor.dim() != 3:
            raise ValueError("Expected tensor with shape CxHxW")
        C, H, W = tensor.shape
        oh, ow = int(original_size[0]), int(original_size[1])
        if H == oh and W == ow:
            return tensor.contiguous()
        # If current is larger or equal in both dims -> center crop
        if H >= oh and W >= ow:
            top = (H - oh) // 2
            left = (W - ow) // 2
            return tensor[:, top:top + oh, left:left + ow].contiguous()
        # If either dimension is smaller, resize using interpolation to target size
        t = tensor.unsqueeze(0)  # BxCxHxW
        mode = "bilinear" if C > 1 else "bilinear"
        resized = F.interpolate(t, size=(oh, ow), mode=mode, align_corners=False)
        return resized.squeeze(0).contiguous()
