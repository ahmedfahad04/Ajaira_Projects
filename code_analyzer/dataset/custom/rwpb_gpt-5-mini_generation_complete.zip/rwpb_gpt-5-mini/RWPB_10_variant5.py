
def euler2rot(euler_angle):
    import torch
    from functools import reduce
    def euler2rot(euler_angle):
        if not torch.is_tensor(euler_angle):
            euler_angle = torch.tensor(euler_angle)
        a = euler_angle
        if a.dim() == 1:
            a = a.unsqueeze(0)
        batch = a.shape[0]
        def rot_x(th):
            c = torch.cos(th); s = torch.sin(th)
            M = torch.stack([
                torch.stack([torch.ones_like(th), torch.zeros_like(th), torch.zeros_like(th)], dim=1),
                torch.stack([torch.zeros_like(th), c, -s], dim=1),
                torch.stack([torch.zeros_like(th), s, c], dim=1),
            ], dim=1)
            return M.permute(0,2,1)
        def rot_y(th):
            c = torch.cos(th); s = torch.sin(th)
            M = torch.stack([
                torch.stack([c, torch.zeros_like(th), s], dim=1),
                torch.stack([torch.zeros_like(th), torch.ones_like(th), torch.zeros_like(th)], dim=1),
                torch.stack([-s, torch.zeros_like(th), c], dim=1),
            ], dim=1)
            return M.permute(0,2,1)
        def rot_z(th):
            c = torch.cos(th); s = torch.sin(th)
            M = torch.stack([
                torch.stack([c, -s, torch.zeros_like(th)], dim=1),
                torch.stack([s, c, torch.zeros_like(th)], dim=1),
                torch.stack([torch.zeros_like(th), torch.zeros_like(th), torch.ones_like(th)], dim=1),
            ], dim=1)
            return M.permute(0,2,1)
        Rs = []
        for i in range(batch):
            rx = rot_x(a[i:i+1,0])
            ry = rot_y(a[i:i+1,1])
            rz = rot_z(a[i:i+1,2])
            R = reduce(torch.matmul, [rz, ry, rx])
            Rs.append(R[0])
        return torch.stack(Rs, dim=0)
