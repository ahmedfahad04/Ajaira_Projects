
def mulMod(x, y, z):
    def mulMod(x, y, z):
        if z == 0:
            raise ValueError("modulus must be non-zero")
        x %= z
        y %= z
        def rec(a, b):
            if b == 0:
                return 0
            half = rec(a, b >> 1)
            half2 = (half + half) % z
            if b & 1:
                half2 = (half2 + a) % z
            return half2
        return rec(x, y)
