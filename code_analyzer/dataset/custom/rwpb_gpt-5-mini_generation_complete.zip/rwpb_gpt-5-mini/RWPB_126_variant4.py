
def crop_mask(masks, boxes):
    import torch
    import torch.nn.functional as F
    def crop_mask(masks, boxes):
        """
        Uses grid_sample to zero-out pixels outside each box by mapping outside coords out of range.
        """
        if masks.dim() != 3:
            raise ValueError("masks must be [n, h, w]")
        n, h, w = masks.shape
        if boxes.shape[0] != n or boxes.shape[1] != 4:
            raise ValueError("boxes must be [n, 4] and match masks batch size")
        device = masks.device
        dtype = masks.dtype
        # Prepare normalized coordinate grid for image: values in [-1,1]
        ys = torch.linspace(0, h - 1, steps=h, device=device)
        xs = torch.linspace(0, w - 1, steps=w, device=device)
        grid_y, grid_x = torch.meshgrid(ys, xs, indexing='ij')  # (h,w)
        # normalized coordinates
        norm_x = (2.0 * grid_x / (w - 1) - 1.0).unsqueeze(0).unsqueeze(-1)  # (1,h,w,1)
        norm_y = (2.0 * grid_y / (h - 1) - 1.0).unsqueeze(0).unsqueeze(-1)  # (1,h,w,1)
        base_grid = torch.cat([norm_x, norm_y], dim=-1)  # (1,h,w,2)
        base_grid = base_grid.expand(n, -1, -1, -1).clone()  # (n,h,w,2)
        bx = boxes.to(device=device, dtype=torch.float32)
        # Compute mask of which pixels are inside each box (in pixel coords)
        x1 = bx[:, 0].view(n, 1, 1)
        y1 = bx[:, 1].view(n, 1, 1)
        x2 = bx[:, 2].view(n, 1, 1)
        y2 = bx[:, 3].view(n, 1, 1)
        # grids of pixel coords
        grid_x_px = grid_x.unsqueeze(0).expand(n, -1, -1)
        grid_y_px = grid_y.unsqueeze(0).expand(n, -1, -1)
        inside = (grid_x_px >= x1) & (grid_x_px <= x2) & (grid_y_px >= y1) & (grid_y_px <= y2)
        # For outside pixels set normalized coords to 2.0 (out of [-1,1]) so grid_sample returns zeros
        base_grid[~inside] = 2.0
        inp = masks.unsqueeze(1).to(dtype=torch.float32)
        sampled = F.grid_sample(inp, base_grid, align_corners=True, mode='bilinear', padding_mode='zeros')
        # sampled has shape [n,1,h,w]
        return sampled.squeeze(1).to(dtype)
