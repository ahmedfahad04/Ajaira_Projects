
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    import torch.nn.functional as F
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        n = tensor.shape[0]
        if n == batch_size:
            return tensor
        # flatten all non-batch dims into channels and use F.interpolate on width dimension
        device = tensor.device
        orig_dtype = tensor.dtype
        # handle edge case n==0
        if n == 0:
            raise ValueError("tensor has zero batch dimension")
        rest_shape = tensor.shape[1:]
        C = 1
        for s in rest_shape:
            C *= s
        # move to float for interpolation
        t = tensor.reshape(n, C).transpose(0, 1).unsqueeze(0).to(torch.float32)  # shape (1, C, n)
        out = F.interpolate(t, size=batch_size, mode='linear', align_corners=True)
        out = out.squeeze(0).transpose(0, 1).reshape(batch_size, *rest_shape)
        # cast back to original dtype if needed
        if out.dtype != orig_dtype:
            try:
                out = out.to(orig_dtype)
            except Exception:
                out = out.clone().type(orig_dtype)
        return out.to(device)
