
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        n = len(preds)
        if n < 2:
            return 0.0
        concordant = 0
        total = 0
        for i in range(n):
            pi = preds[i]
            ri = references[i]
            for j in range(i + 1, n):
                pj = preds[j]
                dp = pi - pj
                if dp == 0:
                    continue
                total += 1
                dr = ri - references[j]
                if dp * dr > 0:
                    concordant += 1
        return concordant / total if total > 0 else 0.0
