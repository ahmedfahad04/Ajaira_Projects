
def extract_code_from_funct(funct: Callable) -> List[str]:
    from typing import Callable, List
    import inspect
    import textwrap
    import re
    def extract_code_from_funct(funct: Callable) -> List[str]:
        src = inspect.getsource(funct)
        # find the first 'def' or 'async def' using regex, capture up to the first colon that ends the signature
        m = re.search(r'^[ \t]*(async\s+def|def)\b.*?:\s*\n', src, flags=re.M | re.S)
        if not m:
            # fallback: try to find 'def' anywhere
            idx = src.find("def ")
            if idx == -1:
                return []
            # take rest after the def line
            rest = src[idx:]
            parts = rest.splitlines(True)
            # remove first line
            body = "".join(parts[1:])
        else:
            body = src[m.end():]
        dedented = textwrap.dedent(body)
        lines = dedented.splitlines()
        # strip leading/trailing blank lines
        while lines and lines[0].strip() == "":
            lines.pop(0)
        while lines and lines[-1].strip() == "":
            lines.pop()
        # remove final return if present
        if lines:
            if lines[-1].lstrip().startswith("return"):
                lines.pop()
                while lines and lines[-1].strip() == "":
                    lines.pop()
        return lines
