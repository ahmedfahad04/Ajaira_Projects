
def logbessel_I_scipy(nu, z, check = True):
    import numpy as np
    import torch
    from scipy import special
    def logbessel_I_scipy(nu, z, check = True):
        # High-precision fallback using numpy.longdouble where possible
        is_torch = isinstance(z, torch.Tensor)
        if is_torch:
            device = z.device
            dtype = z.dtype
            z_np = z.detach().cpu().numpy()
        else:
            z_np = np.array(z, copy=False)
            device = None
            dtype = None
        orig_shape = z_np.shape
        z_flat = np.atleast_1d(z_np).ravel()
        # Try computing in longdouble precision
        try:
            z_ld = z_flat.astype(np.longdouble)
            iv_ld = special.iv(nu, z_ld)
            # Cast back to float64 for log
            iv = np.array(iv_ld, dtype=np.float64)
        except Exception:
            iv = special.iv(nu, z_flat)
        tiny = np.finfo(np.float64).tiny
        if check and np.any(iv == 0):
            raise ValueError("Bessel I evaluated to zero for some entries; log undefined.")
        iv_safe = np.maximum(iv, tiny)
        log_iv = np.log(iv_safe).reshape(orig_shape)
        if is_torch:
            return torch.tensor(log_iv, dtype=dtype, device=device)
        else:
            return torch.tensor(log_iv)
