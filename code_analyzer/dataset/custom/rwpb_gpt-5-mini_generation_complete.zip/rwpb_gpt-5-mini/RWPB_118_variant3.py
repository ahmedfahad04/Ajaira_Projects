
def filter_nan(ts, vs):
    import numpy as np
    def filter_nan(ts, vs):
        ts = np.asarray(ts)
        vs = np.asarray(vs)
        if ts.shape[0] != vs.shape[0]:
            raise ValueError("ts and vs must have the same length along axis 0")
        kept_t = []
        kept_v = []
        for t, v in zip(ts, vs):
            if not (np.isnan(t) or np.isnan(v)):
                kept_t.append(t)
                kept_v.append(v)
        if len(kept_t) == 0:
            return np.empty((0,)) , np.empty((0,))
        return np.array(kept_t, dtype=ts.dtype), np.array(kept_v, dtype=vs.dtype)
