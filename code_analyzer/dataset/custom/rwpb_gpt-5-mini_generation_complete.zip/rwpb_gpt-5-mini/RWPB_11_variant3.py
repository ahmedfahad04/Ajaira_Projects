
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    def pad_to_max_seq_length(ls: list, max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        # recursive padding approach
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be a non-negative integer")
        def _pad_recursive(curr):
            if len(curr) == max_seq_length:
                return curr
            if len(curr) > max_seq_length:
                if check:
                    raise ValueError("Sequence longer than max_seq_length")
                return curr[:max_seq_length]
            if pad_right:
                return _pad_recursive(curr + [pad_idx])
            else:
                return _pad_recursive([pad_idx] + curr)
        return _pad_recursive(list(ls))
