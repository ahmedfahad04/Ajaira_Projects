
def format_ratio(ratio):
    def format_ratio(ratio):
        try:
            r = float(ratio)
        except Exception:
            r = 0.0
        s = repr(r)
        # handle scientific notation by using a fixed high precision representation
        if 'e' in s or 'E' in s:
            s = format(r, '.12f')
        if '.' not in s:
            intpart = s
            fracpart = ''
        else:
            intpart, fracpart = s.split('.', 1)
        sign = ''
        if intpart.startswith('-'):
            sign = '-'
            intpart = intpart[1:]
        # truncate fractional part to 3 digits
        fracpart = (fracpart + '000')[:3]
        return "percentage:{}{}.{}".format(sign, intpart, fracpart)
