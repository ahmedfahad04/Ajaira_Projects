
def getLambertCoefs(numOfLambertCoefs):
    def getLambertCoefs(numOfLambertCoefs):
        if not isinstance(numOfLambertCoefs, int) or numOfLambertCoefs <= 0:
            return []
        coefs = [1.0]  # a1 = 1
        if numOfLambertCoefs == 1:
            return coefs
        # recurrence: a_{n+1} = a_n * ( - ((n+1)/n)^{n-1} )
        for n in range(1, numOfLambertCoefs):
            ratio = - ((n + 1) / n) ** (n - 1)
            coefs.append(coefs[-1] * ratio)
        return coefs
