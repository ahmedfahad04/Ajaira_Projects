
def invalid_to_zeros(arr, valid_mask, ndim=999):
    import torch
    def invalid_to_zeros(arr, valid_mask, ndim=999):
        if not isinstance(arr, torch.Tensor):
            arr = torch.tensor(arr)
        # flatten trailing dims if specified
        if ndim != 999 and arr.dim() > ndim:
            arr = arr.view(*arr.shape[:ndim - 1], -1)
        # if no mask, assume all valid
        if valid_mask is None:
            nnz = arr.numel() // arr.shape[0] if arr.dim() >= 1 else arr.numel()
            return arr, nnz
        mask = valid_mask.bool()
        # Try a functional approach: create a zero tensor then scatter valid values back
        flat_arr = arr.view(arr.shape[0], -1) if arr.dim() >= 1 else arr.view(1, -1)
        # Align mask to (B, M) if possible
        if mask.numel() == flat_arr.numel():
            flat_mask = mask.view_as(flat_arr)
        else:
            # if mask has B elements, expand to all points
            if flat_arr.size(0) == mask.numel():
                flat_mask = mask.view(-1, 1).expand_as(flat_arr)
            else:
                try:
                    flat_mask = mask.view(flat_arr.size(0), -1)
                except Exception:
                    # fallback: assume all valid
                    flat_mask = torch.ones_like(flat_arr, dtype=torch.bool)
        zeros = torch.zeros_like(flat_arr)
        kept = torch.where(flat_mask, flat_arr, zeros)
        out = kept.view_as(arr)
        # compute nnz per-image
        if arr.dim() >= 1:
            nnz = flat_mask.sum(dim=1)
        else:
            nnz = flat_mask.sum()
        return out, nnz
