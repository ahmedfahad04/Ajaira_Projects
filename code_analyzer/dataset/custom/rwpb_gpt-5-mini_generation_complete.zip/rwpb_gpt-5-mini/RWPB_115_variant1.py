
def compute_tri_normal(geometry, tris):
    import torch
    def compute_tri_normal(geometry, tris):
        """
        Vectorized computation of unit triangle normals using advanced indexing.
        geometry: (B, N, 3)
        tris: (M, 3)
        returns: (B, M, 3)
        """
        if geometry.numel() == 0:
            return torch.empty(geometry.shape[0], tris.shape[0], 3, device=geometry.device, dtype=geometry.dtype)
        tris = tris.to(geometry.device)
        verts = geometry[:, tris]                 # (B, M, 3, 3)
        v0 = verts[:, :, 0, :]                    # (B, M, 3)
        v1 = verts[:, :, 1, :]
        v2 = verts[:, :, 2, :]
        e1 = v1 - v0
        e2 = v2 - v0
        normals = torch.cross(e1, e2, dim=-1)     # (B, M, 3)
        norm = normals.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-8)
        normals = normals / norm
        return normals
