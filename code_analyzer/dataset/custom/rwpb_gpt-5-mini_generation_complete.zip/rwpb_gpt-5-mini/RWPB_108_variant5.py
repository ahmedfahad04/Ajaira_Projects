
def norm_grid(v_grid):
    import torch
    def norm_grid(v_grid):
        """Normalize and clamp to [-1,1] as a final safety step."""
        v = v_grid
        if not isinstance(v, torch.Tensor):
            v = torch.tensor(v)
        B, C, H, W = v.shape
        assert C == 2
        v = v.to(dtype=torch.float32)
        x = v[:, 0, :, :]
        y = v[:, 1, :, :]
        denom_w = max(W - 1, 1)
        denom_h = max(H - 1, 1)
        x_n = x.mul_(2.0 / denom_w).sub_(1.0)
        y_n = y.mul_(2.0 / denom_h).sub_(1.0)
        out = torch.stack((x_n, y_n), dim=-1)
        return out.clamp(-1.0, 1.0)
