
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        if torch.is_tensor(divisor):
            d = float(divisor.max().item())
        else:
            d = float(divisor)
        if d == 0:
            raise ValueError("divisor must be non-zero")
        d = abs(d)
        # Use Python's round on the quotient to get nearest multiple
        q = round(float(x) / d)
        return int(q * d)
