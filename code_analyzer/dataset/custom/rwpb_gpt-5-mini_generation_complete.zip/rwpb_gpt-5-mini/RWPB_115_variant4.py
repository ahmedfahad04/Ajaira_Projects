
def compute_tri_normal(geometry, tris):
    import torch
    import torch.nn.functional as F
    def compute_tri_normal(geometry, tris):
        """
        Use einsum with one-hot triangle selectors to gather vertices, then compute normalized normals.
        geometry: (B, N, 3)
        tris: (M, 3)
        """
        B, N, C = geometry.shape
        M = tris.shape[0]
        if M == 0 or B == 0:
            return torch.empty(B, M, 3, device=geometry.device, dtype=geometry.dtype)
        tris = tris.to(geometry.device)
        one_hot = F.one_hot(tris, num_classes=N).to(dtype=geometry.dtype)  # (M,3,N)
        # Einsum to gather vertices: 'bnc,tvn->btvc' -> (B, M, 3, 3)
        verts = torch.einsum('bnc,tvn->btvc', geometry, one_hot)
        v0 = verts[:, :, 0, :]
        v1 = verts[:, :, 1, :]
        v2 = verts[:, :, 2, :]
        normals = torch.cross(v1 - v0, v2 - v0, dim=-1)
        normals = normals / (normals.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-8))
        return normals
