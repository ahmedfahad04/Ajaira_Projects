
def get_focalLength_from_fieldOfView(fov=60, img_size=512):
    import numpy as np
    def get_focalLength_from_fieldOfView(fov=60, img_size=512):
        """
        Compute focal length in pixels assuming the provided field of view (degrees)
        spans the entire image width/height given by img_size (scalar).
        """
        fov = float(fov)
        if fov == 0:
            return np.inf
        rad = np.deg2rad(fov)
        return (float(img_size) / 2.0) / np.tan(rad / 2.0)
