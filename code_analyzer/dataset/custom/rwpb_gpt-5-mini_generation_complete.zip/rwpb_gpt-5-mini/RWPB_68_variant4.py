
def last_before(val, arr):
    import numpy as np
    def last_before(val, arr):
        arr = np.asarray(arr)
        if arr.size == 0:
            return -1
        mask = arr <= val
        if not mask.any():
            return -1
        # find last True by looking from the end
        last = len(mask) - 1 - mask[::-1].argmax()
        return int(last)
