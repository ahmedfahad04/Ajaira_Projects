
def format_seconds(seconds: float) -> str:
    def format_seconds(seconds: float) -> str:
        from decimal import Decimal, ROUND_HALF_UP
        if not isinstance(seconds, (int, float)):
            raise TypeError("seconds must be a number")
        if not (seconds == seconds) or seconds == float('inf') or seconds == float('-inf'):
            raise ValueError("seconds must be a finite number")
        neg = seconds < 0
        d = Decimal(str(abs(seconds)))
        # round to milliseconds
        total_millis = int((d * Decimal('1000')).to_integral_value(rounding=ROUND_HALF_UP))
        hours = total_millis // 3600000
        rem = total_millis % 3600000
        minutes = rem // 60000
        rem = rem % 60000
        secs = rem // 1000
        millis = rem % 1000
        sign = "-" if neg else ""
        if hours >= 1:
            return f"{sign}{hours:02d}:{minutes:02d}:{secs:02d}.{millis:03d}"
        else:
            return f"{sign}{minutes:02d}:{secs:02d}.{millis:03d}"
