
def norm_grid(v_grid):
    import torch
    def norm_grid(v_grid):
        """Vectorized normalization: (B,2,H,W) -> (B,H,W,2) with coords scaled to [-1,1]."""
        if not isinstance(v_grid, torch.Tensor):
            v_grid = torch.tensor(v_grid)
        B, C, H, W = v_grid.shape
        assert C == 2, "Expected channel dim of size 2"
        # Ensure floating point for division
        x = v_grid[:, 0, :, :].to(dtype=torch.float32)
        y = v_grid[:, 1, :, :].to(dtype=torch.float32)
        denom_w = max(W - 1, 1)
        denom_h = max(H - 1, 1)
        x_norm = (x / denom_w) * 2.0 - 1.0
        y_norm = (y / denom_h) * 2.0 - 1.0
        out = torch.stack((x_norm, y_norm), dim=-1)  # (B, H, W, 2)
        return out
