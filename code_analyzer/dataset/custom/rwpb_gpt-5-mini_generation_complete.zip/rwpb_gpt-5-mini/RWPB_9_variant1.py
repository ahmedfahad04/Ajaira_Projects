
def is_byte_token(s: str) -> bool:
    import re
    def is_byte_token(s: str) -> bool:
        return bool(re.fullmatch(r"<0x[0-9A-Fa-f]{2}>", s))
