
def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
    import torch
    def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        ndim = x.dim()
        if ndim == 0:
            return x.contiguous() if make_contiguous else x
        src = src_dim if src_dim >= 0 else src_dim + ndim
        dest = dest_dim if dest_dim >= 0 else dest_dim + ndim
        if not (0 <= src < ndim) or not (0 <= dest < ndim):
            raise IndexError("src_dim or dest_dim out of range")
        if src == dest:
            return x.contiguous() if make_contiguous else x
        out = x
        # move by swapping adjacent dimensions repeatedly
        if dest > src:
            for i in range(src, dest):
                out = out.transpose(i, i + 1)
        else:
            for i in range(src, dest, -1):
                out = out.transpose(i, i - 1)
        return out.contiguous() if make_contiguous else out
