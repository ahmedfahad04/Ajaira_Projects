
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return original_size
        ow, oh = original_size
        best = None
        best_dist = None
        for w, h in possible_resolutions:
            dx = w - ow
            dy = h - oh
            dist = (dx * dx + dy * dy) ** 0.5
            if best is None or dist < best_dist:
                best = (w, h)
                best_dist = dist
            elif dist == best_dist:
                if w * h > best[0] * best[1]:
                    best = (w, h)
        return best
