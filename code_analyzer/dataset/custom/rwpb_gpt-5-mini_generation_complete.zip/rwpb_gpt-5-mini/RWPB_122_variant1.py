
def view_range(x, i, j, shape):
    import torch
    import operator
    from functools import reduce
    def view_range(x, i, j, shape):
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        ndim = x.dim()
        if j is None:
            j = ndim
        # normalize negative indices
        if i < 0:
            i += ndim
        if j < 0:
            j += ndim
        if not (0 <= i <= j <= ndim):
            raise IndexError("Invalid i, j for tensor with dim {}".format(ndim))
        # compute original product
        orig_dims = list(x.shape[i:j])
        def prod(seq):
            p = 1
            for v in seq:
                p *= v
            return p
        orig_prod = prod(orig_dims)
        # prepare target shape (handle -1 inference)
        target = list(shape)
        if -1 in target:
            if target.count(-1) > 1:
                raise ValueError("Only one -1 allowed in shape")
            known_prod = prod([d for d in target if d != -1])
            if known_prod == 0:
                raise ValueError("Cannot infer -1 with zero known product")
            if orig_prod % known_prod != 0:
                raise ValueError("Incompatible shape with range size")
            inferred = orig_prod // known_prod
            target[target.index(-1)] = inferred
        if prod(target) != orig_prod:
            raise ValueError("Target shape does not match the number of elements in the specified range")
        # build new shape
        new_shape = tuple(list(x.shape[:i]) + target + list(x.shape[j:]))
        return x.reshape(new_shape)
