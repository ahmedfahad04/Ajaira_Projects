
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        if a.shape != (3,) or b.shape != (3,):
            a = a.ravel()[:3]
            b = b.ravel()[:3]
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na == 0 or nb == 0:
            return (None, None)
        u = a / na
        v = b / nb
        if np.allclose(u, v):
            return (None, None)
        # quaternion method
        dot = np.dot(u, v)
        cross = np.cross(u, v)
        q_vec = cross.copy()
        q_w = 1.0 + dot
        if q_w < 1e-12:
            # opposite vectors
            idx = np.argmin(np.abs(u))
            tmp = np.zeros(3)
            tmp[idx] = 1.0
            axis = np.cross(u, tmp)
            axis = axis / np.linalg.norm(axis)
            return (axis, np.pi)
        q = np.empty(4)
        q[0] = q_w
        q[1:] = q_vec
        # normalize quaternion
        q = q / np.linalg.norm(q)
        qw = q[0]
        qv = q[1:]
        # angle and axis
        angle = 2.0 * np.arccos(np.clip(qw, -1.0, 1.0))
        s = np.sqrt(max(0.0, 1.0 - qw * qw))
        if s < 1e-12:
            # axis can be any normalized vector
            axis = qv
            if np.linalg.norm(axis) < 1e-12:
                # fallback
                idx = np.argmin(np.abs(u))
                tmp = np.zeros(3); tmp[idx] = 1.0
                axis = np.cross(u, tmp)
            axis = axis / np.linalg.norm(axis)
        else:
            axis = qv / s
        return (axis, angle)
