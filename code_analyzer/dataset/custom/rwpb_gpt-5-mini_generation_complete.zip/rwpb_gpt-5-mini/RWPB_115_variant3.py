
def compute_tri_normal(geometry, tris):
    import torch
    def compute_tri_normal(geometry, tris):
        """
        Batch loop: index_select per batch to build vertex tensors then compute normals.
        Returns unit normals.
        """
        B, N, _ = geometry.shape
        M = tris.shape[0]
        if M == 0 or B == 0:
            return torch.empty(B, M, 3, device=geometry.device, dtype=geometry.dtype)
        tris = tris.to(geometry.device)
        out = []
        idx_flat = tris.view(-1)  # (M*3,)
        for b in range(B):
            sel = torch.index_select(geometry[b], 0, idx_flat)  # (M*3, 3)
            sel = sel.view(M, 3, 3)  # (M, 3 vertices, 3 coords)
            v0 = sel[:, 0, :]
            v1 = sel[:, 1, :]
            v2 = sel[:, 2, :]
            n = torch.cross(v1 - v0, v2 - v0, dim=-1)
            n = n / (n.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-8))
            out.append(n)
        return torch.stack(out, dim=0)
