
def mean(l, ignore_nan=False, empty=0):
    import math
    def mean(l, ignore_nan=False, empty=0):
        """
        Single-pass streaming Kahan summation for high precision without storing all values.
        """
        s = 0.0
        c = 0.0  # compensation
        count = 0
        for x in l:
            try:
                if ignore_nan and math.isnan(x):
                    continue
            except Exception:
                pass
            try:
                xv = float(x)
            except Exception:
                xv = x
            y = xv - c
            t = s + y
            c = (t - s) - y
            s = t
            count += 1
        if count == 0:
            if empty == 'raise':
                raise ValueError("mean of empty iterable")
            return empty
        return s / count
