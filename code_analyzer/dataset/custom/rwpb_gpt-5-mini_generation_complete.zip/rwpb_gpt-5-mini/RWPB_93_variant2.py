
def unsafeSub(x, y):
    MOD = 1 << 256
    def unsafeSub(x, y):
        return (x - y) % MOD
