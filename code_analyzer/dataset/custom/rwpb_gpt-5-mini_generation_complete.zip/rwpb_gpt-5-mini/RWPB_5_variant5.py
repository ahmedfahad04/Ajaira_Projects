
def seconds_to_hh_mm_ss(seconds):
    def seconds_to_hh_mm_ss(seconds):
        import math
        try:
            seconds = int(seconds)
        except Exception:
            return "00:00:00"
        if seconds < 0:
            return "00:00:00"
        h = seconds // 3600
        m = int(math.floor((seconds - h * 3600) / 60))
        s = seconds - h * 3600 - m * 60
        return "{:02d}:{:02d}:{:02d}".format(h, m, s)
