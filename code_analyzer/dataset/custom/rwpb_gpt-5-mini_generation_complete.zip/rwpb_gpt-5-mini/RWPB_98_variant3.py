
def exp_smooth(vals, alpha):
    import numpy as np
    import itertools
    def exp_smooth(vals, alpha):
        arr = np.asarray(vals, dtype=float)
        if arr.size == 0:
            raise KeyError("Input array is empty")
        def fn(prev, curr):
            return alpha * curr + (1.0 - alpha) * prev
        acc = itertools.accumulate(arr, fn)
        return np.fromiter(acc, dtype=float, count=arr.size)
