
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        from bisect import bisect_left, insort
        n = len(preds)
        if n < 2:
            return 0.0
        idxs = sorted(range(n), key=lambda i: preds[i])
        groups = []
        cur = [idxs[0]]
        for k in idxs[1:]:
            if preds[k] == preds[cur[0]]:
                cur.append(k)
            else:
                groups.append(cur)
                cur = [k]
        groups.append(cur)
        total = n * (n - 1) // 2 - sum(len(g) * (len(g) - 1) // 2 for g in groups)
        if total == 0:
            return 0.0
        prev_sorted = []
        concordant = 0
        for g in groups:
            for i in g:
                r = references[i]
                concordant += bisect_left(prev_sorted, r)
            for i in g:
                insort(prev_sorted, references[i])
        return concordant / total
