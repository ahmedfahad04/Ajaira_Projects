
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        if repetition_penalty == 1.0 or repetition_penalty == 0:
            return logits
        logits = logits.clone()
        batch_size, vocab_size = logits.shape
        device = logits.device
        dtype = logits.dtype
        # collect all (batch_idx, token_idx) pairs for tokens that appeared (unique per batch)
        batch_indices = []
        token_indices = []
        for b in range(batch_size):
            prev = prev_output_tokens[b]
            unique = torch.unique(prev)
            unique = unique[unique >= 0]
            if unique.numel() > 0:
                batch_indices.append(torch.full((unique.numel(),), b, dtype=torch.long, device=device))
                token_indices.append(unique.to(device))
        if not batch_indices:
            return logits
        b_idx = torch.cat(batch_indices)
        t_idx = torch.cat(token_indices)
        # fetch scores
        scores = logits[b_idx, t_idx]
        # apply penalty per score sign
        pos_mask = scores > 0
        multipliers = torch.ones_like(scores, dtype=dtype, device=device)
        multipliers[pos_mask] = 1.0 / repetition_penalty
        multipliers[~pos_mask] = repetition_penalty
        logits[b_idx, t_idx] = scores * multipliers
        return logits
