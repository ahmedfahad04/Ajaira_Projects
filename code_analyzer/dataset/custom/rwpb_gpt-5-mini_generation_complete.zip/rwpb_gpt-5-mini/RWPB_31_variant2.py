
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        n = tensor.shape[0]
        if n == batch_size:
            return tensor
        device = tensor.device
        # Nearest-neighbor resampling using evenly spaced positions
        positions = torch.linspace(0, n - 1, steps=batch_size, device=device)
        idx = torch.clamp((positions.round()).long(), 0, max(n - 1, 0))
        return tensor[idx]
