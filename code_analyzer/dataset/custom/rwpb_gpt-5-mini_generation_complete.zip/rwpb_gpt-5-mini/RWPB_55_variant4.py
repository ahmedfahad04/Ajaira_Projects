
def numpy_to_pytorch(x):
    import numpy as np
    import torch
    def numpy_to_pytorch(x):
        # Use torch.tensor constructor (may copy) then normalize and add batch dim
        t = torch.tensor(x, dtype=torch.float32)
        t = t / 255.0
        if t.dim() == 0:
            t = t.unsqueeze(0)
        else:
            t = t.unsqueeze(0)
        return t.contiguous().float()
