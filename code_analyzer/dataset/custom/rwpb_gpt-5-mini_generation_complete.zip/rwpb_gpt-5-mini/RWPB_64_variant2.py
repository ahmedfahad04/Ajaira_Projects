
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        arr = np.asarray(arr, dtype=float).ravel()
        n = arr.size
        if window_size <= 0:
            raise ValueError("window_size must be positive")
        if n == 0:
            return np.array([]), np.array([])
        k = min(window_size, n)
        # Centered window: left and right spans
        left = (k - 1) // 2
        right = k - 1 - left
        csum = np.empty(n + 1, dtype=float)
        csum[0] = 0.0
        csum[1:] = np.cumsum(arr)
        moving = np.empty(n, dtype=float)
        for i in range(n):
            start = max(0, i - left)
            end = min(n, i + right + 1)
            s = csum[end] - csum[start]
            cnt = end - start
            moving[i] = s / cnt
        residuals = arr - moving
        return moving, residuals
