
def pad_camera_extrinsics_4x4(extrinsics):
    import torch
    def pad_camera_extrinsics_4x4(extrinsics):
        if not isinstance(extrinsics, torch.Tensor):
            raise TypeError("extrinsics must be a torch.Tensor")
        if extrinsics.shape[-2:] == (4, 4):
            return extrinsics
        if extrinsics.shape[-2:] != (3, 4):
            raise ValueError("Input must be (...,3,4) or (...,4,4)")
        orig_shape = extrinsics.shape
        batch = int(torch.prod(torch.tensor(orig_shape[:-2]))) if orig_shape[:-2] else 1
        flat = extrinsics.contiguous().view(batch, 3, 4)
        last_row = flat.new_tensor([0, 0, 0, 1]).unsqueeze(0).expand(batch, 1, 4)
        stacked = torch.cat([flat, last_row], dim=1)
        out_shape = tuple(orig_shape[:-2]) + (4, 4)
        return stacked.view(out_shape)
