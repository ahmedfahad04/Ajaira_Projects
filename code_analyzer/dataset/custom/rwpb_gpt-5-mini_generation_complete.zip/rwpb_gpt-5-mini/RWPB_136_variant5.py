
def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
    import torch
    def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
        import torch
        t_t = v0.new_tensor(t)
        v0 = v0.to(v0.dtype)
        v1 = v1.to(v0.dtype)
        n0 = torch.norm(v0, dim=-1, keepdim=True)
        n1 = torch.norm(v1, dim=-1, keepdim=True)
        u0 = v0 / (n0 + 1e-12)
        u1 = v1 / (n1 + 1e-12)
        dot = torch.sum(u0 * u1, dim=-1, keepdim=True)
        dot = torch.clamp(dot, -1.0, 1.0)
        theta = torch.acos(dot)
        sin_theta = torch.sin(theta)
        small = theta.abs() < 1e-4
        def sinc(x):
            return torch.where(torch.abs(x) < 1e-6, 1.0 - x**2 / 6.0, torch.sin(x) / (x + 1e-12))
        factor = torch.where(small, t_t * sinc(t_t * theta) / (sinc(theta) + 1e-12), torch.sin(t_t * theta) / (sin_theta + 1e-12))
        factor0 = torch.where(small, (1.0 - t_t) * sinc((1.0 - t_t) * theta) / (sinc(theta) + 1e-12), torch.sin((1.0 - t_t) * theta) / (sin_theta + 1e-12))
        factor0 = factor0.expand_as(u0)
        factor = factor.expand_as(u0)
        out = factor0 * u0 + factor * u1
        out = out / (torch.norm(out, dim=-1, keepdim=True) + 1e-12)
        return out * ((1.0 - t_t) * n0 + t_t * n1)
