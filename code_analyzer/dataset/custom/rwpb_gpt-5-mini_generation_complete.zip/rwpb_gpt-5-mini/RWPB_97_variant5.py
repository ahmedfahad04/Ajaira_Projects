
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        # Defensive conversion and validation
        if not isinstance(image, np.ndarray):
            raise ValueError("Not a valid image")
        img = image
        if img.ndim == 2:
            # grayscale
            if img.size == 0:
                raise ValueError("Not a valid image")
            arr = (img.astype(np.float32) / 255.0)[None, :, :]
            return torch.as_tensor(arr, dtype=torch.float32)
        elif img.ndim == 3:
            if img.shape[2] <= 0:
                raise ValueError("Not a valid image")
            arr = img.astype(np.float32) / 255.0
            arr = np.transpose(arr, (2, 0, 1))
            return torch.as_tensor(arr, dtype=torch.float32)
        else:
            raise ValueError("Not a valid image")
