
def pr_from_grav(grav):
    import numpy as np
    def pr_from_grav(grav):
        g = np.asarray(grav, dtype=float)
        if g.ndim == 1:
            if g.size != 3:
                raise ValueError("grav must be shape (n,3) or (3,)")
            g = g[None, :]
        if g.ndim != 2 or g.shape[1] != 3:
            raise ValueError("grav must have shape (n,3)")
        gx = g[:, 0]
        gy = g[:, 1]
        gz = g[:, 2]
        # compute denominator safely
        denom = np.sqrt(gy * gy + gz * gz)
        eps = np.finfo(float).eps
        denom_safe = np.where(denom == 0, eps, denom)
        pitches = np.arctan2(-gx, denom_safe)
        # When gy and gz are both zero, set roll to zero (no defined roll)
        rolls = np.arctan2(gy, gz)
        mask = (np.abs(denom) <= eps)
        if np.any(mask):
            rolls = rolls.copy()
            rolls[mask] = 0.0
        return pitches, rolls
