
def rotate_y(a, device=None):
    import torch
    def rotate_y(a, device=None):
        if device is None:
            dev = None
        else:
            dev = torch.device(device)
        ang = float(a) if not torch.is_tensor(a) else float(a.item())
        c = torch.tensor(ang).cos().item()
        s = torch.tensor(ang).sin().item()
        mat = [[c, 0.0, s, 0.0],
               [0.0, 1.0, 0.0, 0.0],
               [-s, 0.0, c, 0.0],
               [0.0, 0.0, 0.0, 1.0]]
        if dev is None:
            return torch.tensor(mat, dtype=torch.get_default_dtype())
        else:
            return torch.tensor(mat, dtype=torch.get_default_dtype(), device=dev)
