
def check_all_columns_numeric(df):
    import pandas as pd
    import numpy as np
    from pandas.api.types import is_numeric_dtype
    def check_all_columns_numeric(df):
        if df is None:
            return False
        if df.shape[1] == 0:
            return True
        for dt in df.dtypes:
            try:
                if not np.issubdtype(dt, np.number):
                    return False
            except TypeError:
                # Fallback for pandas extension dtypes
                if not is_numeric_dtype(dt):
                    return False
        return True
