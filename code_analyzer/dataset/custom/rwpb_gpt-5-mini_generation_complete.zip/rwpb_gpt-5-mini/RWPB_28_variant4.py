
def mean(l, ignore_nan=False, empty=0):
    import math
    import statistics
    def mean(l, ignore_nan=False, empty=0):
        """
        Materialize the iterable into a list, optionally filtering NaNs, then use statistics.mean.
        """
        vals = []
        for x in l:
            try:
                if ignore_nan and math.isnan(x):
                    continue
            except Exception:
                pass
            vals.append(x)
        if not vals:
            if empty == 'raise':
                raise ValueError("mean of empty iterable")
            return empty
        return float(statistics.mean(vals))
