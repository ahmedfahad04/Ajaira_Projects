
def submatrix(matrix, col):
    def submatrix(matrix, col):
        # recursive approach
        if not matrix:
            return []
        # validate index on first row to determine legality for all rows
        try:
            _ = matrix[0][col]
        except Exception:
            raise IndexError("column index out of range")
        def remove_from_row(row, c):
            return row[:c] + row[c+1:]
        head = remove_from_row(matrix[0], col)
        return [head] + submatrix(matrix[1:], col)
