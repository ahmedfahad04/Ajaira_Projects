
def unpad_image_shape(current_height, current_width, original_size):
    def unpad_image_shape(current_height, current_width, original_size):
        orig_w, orig_h = original_size
        # handle degenerate cases
        if not all(isinstance(x, (int, float)) for x in (current_height, current_width, orig_w, orig_h)):
            raise TypeError("All dimensions must be numbers")
        if orig_w <= 0 or orig_h <= 0 or current_width <= 0 or current_height <= 0:
            return (current_height, current_width)
        # compute aspect ratios
        orig_ratio = orig_w / orig_h
        cur_ratio = current_width / current_height
        if abs(orig_ratio - cur_ratio) < 1e-12:
            # same ratio -> full area used
            return (current_height, current_width)
        if orig_ratio > cur_ratio:
            # original is relatively wider -> width matched, height padded
            new_w = current_width
            new_h = int(round((current_width / orig_w) * orig_h))
        else:
            # original is relatively taller -> height matched, width padded
            new_h = current_height
            new_w = int(round((current_height / orig_h) * orig_w))
        # clamp
        new_h = max(1, min(current_height, new_h))
        new_w = max(1, min(current_width, new_w))
        return (new_h, new_w)
