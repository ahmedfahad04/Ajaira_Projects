
def is_byte_token(s: str) -> bool:
    def is_byte_token(s: str) -> bool:
        if not isinstance(s, str) or len(s) != 6:
            return False
        if s[0] != '<' or s[-1] != '>':
            return False
        if s[1] != '0' or s[2] not in ('x', 'X'):
            return False
        def is_hex_digit(ch):
            o = ord(ch)
            return 48 <= o <= 57 or 65 <= o <= 70 or 97 <= o <= 102
        return is_hex_digit(s[3]) and is_hex_digit(s[4])
