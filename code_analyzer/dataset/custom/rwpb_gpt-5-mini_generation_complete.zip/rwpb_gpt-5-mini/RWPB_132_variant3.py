
def B_batch(x, grid, k=0, extend=True, device="cpu"):
    import torch
    def B_batch(x, grid, k=0, extend=True, device="cpu"):
        x = x.to(device)
        grid = grid.to(device)
        S, N = x.shape
        assert grid.shape[0] == S
        dtype = x.dtype
        outputs = []
        for s in range(S):
            u = x[s]  # (N,)
            knots_inner = grid[s]
            if k > 0 and extend:
                knots = torch.cat([knots_inner[0].repeat(k), knots_inner, knots_inner[-1].repeat(k)])
            else:
                knots = knots_inner.clone()
            p = max(k - 1, 0)
            K = knots.numel()
            nb = max(K - p - 1, 0)
            if nb == 0:
                outputs.append(torch.zeros((0, N), device=device, dtype=dtype))
                continue
            # Build full 2D array N[i, j] where i indexes knot span and j sample using vectorized broadcasting
            spans = K - 1
            lefts = knots[:-1].unsqueeze(1)  # (spans,1)
            rights = knots[1:].unsqueeze(1)  # (spans,1)
            urow = u.unsqueeze(0)  # (1,N)
            Nmat = ((urow >= lefts) & (urow < rights)).to(dtype)
            # assign last-point equality
            last_right = rights[-1].squeeze()
            if (u == last_right).any():
                Nmat[-1, u == last_right] = 1.0
            # Now use vectorized triangular DP without python inner loops over samples
            for d in range(1, p + 1):
                # compute denominators arrays
                i = torch.arange(0, K - d - 1, device=device)
                denom1 = (knots[i + d] - knots[i]).unsqueeze(1)  # (K-d-1,1)
                denom2 = (knots[i + d + 1] - knots[i + 1]).unsqueeze(1)
                # left factor: (u - knots[i]) / denom1 * Nmat[i]
                left_num = (urow - knots[i].unsqueeze(1))
                right_num = (knots[i + d + 1].unsqueeze(1) - urow)
                left = torch.zeros_like(Nmat[:K - d - 1])
                right = torch.zeros_like(left)
                # avoid division by zero by masking
                mask1 = denom1 != 0
                if mask1.any():
                    left[mask1.squeeze(1)] = (left_num[mask1.squeeze(1)] / denom1[mask1]).squeeze(0) * Nmat[:K - d - 1][mask1.squeeze(1)]
                mask2 = denom2 != 0
                if mask2.any():
                    right[mask2.squeeze(1)] = (right_num[mask2.squeeze(1)] / denom2[mask2]).squeeze(0) * Nmat[1:K - d][mask2.squeeze(1)]
                Nmat = left + right
            outputs.append(Nmat[:nb])
        max_b = max((o.shape[0] for o in outputs), default=0)
        out = torch.zeros((S, max_b, N), device=device, dtype=dtype)
        for s in range(S):
            nb = outputs[s].shape[0]
            if nb > 0:
                out[s, :nb, :] = outputs[s]
        return out
