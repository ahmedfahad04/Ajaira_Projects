
def rotate_x(a, device=None):
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        # normalize device
        dev = torch.device(device) if device is not None else None
        # ensure angle is a torch scalar on correct device
        if isinstance(a, torch.Tensor):
            ang = a.to(dev) if dev is not None else a
        else:
            ang = torch.tensor(a, dtype=torch.get_default_dtype(), device=dev)
        c = torch.cos(ang)
        s = torch.sin(ang)
        M = torch.eye(4, dtype=c.dtype, device=c.device if dev is None else dev)
        M[1,1] = c
        M[1,2] = -s
        M[2,1] = s
        M[2,2] = c
        return M
