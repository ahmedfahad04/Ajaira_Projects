
def interpolate_features(features,:
    import numpy as np
    def interpolate_features(features, input_rate, output_rate, output_len):
        features = np.asarray(features)
        if output_len <= 0:
            if features.ndim == 1:
                return np.zeros((0,), dtype=features.dtype)
            return np.zeros((0, features.shape[1]), dtype=features.dtype)
        if features.ndim == 1:
            T = features.shape[0]
            if T == 0:
                return np.zeros((output_len,), dtype=features.dtype)
            x = np.arange(output_len) * (input_rate / float(output_rate))
            x = np.clip(x, 0, T - 1)
            return np.interp(x, np.arange(T), features).astype(features.dtype, copy=False)
        T, D = features.shape
        if T == 0:
            return np.zeros((output_len, D), dtype=features.dtype)
        x = np.arange(output_len) * (input_rate / float(output_rate))
        x = np.clip(x, 0, T - 1)
        xp = np.arange(T)
        result = np.empty((output_len, D), dtype=features.dtype)
        for i, col in enumerate(features.T):
            result[:, i] = np.interp(x, xp, col)
        return result
