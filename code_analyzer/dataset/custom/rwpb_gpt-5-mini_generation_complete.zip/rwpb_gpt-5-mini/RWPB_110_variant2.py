
def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
    import numpy as np
    def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
        n = np.array(plane_normal, dtype=float)
        p0 = np.array(plane_point, dtype=float)
        d = np.array(ray_direction, dtype=float)
        r0 = np.array(ray_point, dtype=float)
        # Ensure shapes
        n = n.ravel()
        p0 = p0.ravel()
        d = d.ravel()
        r0 = r0.ravel()
        if np.linalg.norm(d) == 0:
            return None
        # use normalized plane normal to compute signed distance
        n_norm = n / (np.linalg.norm(n) + 1e-20)
        signed_dist = np.dot(n_norm, p0 - r0)
        denom = np.dot(n_norm, d)
        if abs(denom) < 1e-12:
            return None
        t = signed_dist / denom
        return r0 + t * d
