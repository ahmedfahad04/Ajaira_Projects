
def pad_camera_extrinsics_4x4(extrinsics):
    import torch
    def pad_camera_extrinsics_4x4(extrinsics):
        if not isinstance(extrinsics, torch.Tensor):
            raise TypeError("extrinsics must be a torch.Tensor")
        if extrinsics.shape[-2:] == (4, 4):
            return extrinsics
        if extrinsics.shape[-2:] != (3, 4):
            raise ValueError("Expected extrinsics of shape (...,3,4) or (...,4,4)")
        dtype = extrinsics.dtype
        device = extrinsics.device
        eye4 = torch.eye(4, dtype=dtype, device=device)
        expand_shape = tuple(extrinsics.shape[:-2]) + (4, 4)
        base = eye4.view((1,)*len(extrinsics.shape[:-2]) + (4, 4)).expand(*expand_shape).clone()
        base[..., :3, :] = extrinsics
        return base
