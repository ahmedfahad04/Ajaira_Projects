
def merge_dicts_recursively(*dicts):
    from functools import reduce
    import copy
    def _merge_pair(a, b):
        out = copy.deepcopy(a)
        for k, v in b.items():
            if k in out and isinstance(out[k], dict) and isinstance(v, dict):
                out[k] = _merge_pair(out[k], v)
            else:
                out[k] = copy.deepcopy(v)
        return out
    def merge_dicts_recursively(*dicts):
        if not dicts:
            return {}
        filtered = [d for d in dicts if isinstance(d, dict)]
        return reduce(_merge_pair, filtered, {})
