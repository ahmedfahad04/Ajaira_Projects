
def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
    import torch
    def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
        if num <= 0:
            return torch.empty(*torch.broadcast_shapes(start.shape, stop.shape), 0, device=start.device, dtype=torch.promote_types(start.dtype, stop.dtype))
        # determine dtype and device
        dtype = torch.promote_types(start.dtype, stop.dtype)
        device = start.device
        # create normalized steps in [0,1]
        if num == 1:
            steps = torch.tensor([0.0], dtype=dtype, device=device)
        else:
            steps = torch.linspace(0.0, 1.0, steps=num, dtype=dtype, device=device)
        # number of leading dims to broadcast over
        nd = max(start.dim(), stop.dim())
        if nd > 0:
            steps = steps.view((1,)*nd + (num,))
        # cast inputs to common dtype
        start = start.to(dtype)
        stop = stop.to(dtype)
        # compute linear interpolation with broadcasting
        return start + (stop - start) * steps
