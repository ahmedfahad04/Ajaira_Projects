
def format_ratio(ratio):
    def format_ratio(ratio):
        from decimal import Decimal, ROUND_DOWN
        try:
            d = Decimal(str(ratio))
        except Exception:
            d = Decimal('0')
        quantized = d.quantize(Decimal('0.000'), rounding=ROUND_DOWN)
        # Ensure sign and three decimals preserved
        return "percentage:" + format(quantized, 'f') if '.' in format(quantized, 'f') and len(str(quantized).split('.')[-1])==3 else "percentage:" + format(quantized, 'f')
