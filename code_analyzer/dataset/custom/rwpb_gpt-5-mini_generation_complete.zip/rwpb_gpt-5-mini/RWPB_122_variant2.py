
def view_range(x, i, j, shape):
    import torch
    from functools import reduce
    import operator
    def view_range(x, i, j, shape):
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        ndim = x.dim()
        if j is None:
            j = ndim
        if i < 0:
            i += ndim
        if j < 0:
            j += ndim
        if not (0 <= i <= j <= ndim):
            raise IndexError("Invalid range")
        # flatten middle to a single dim, then reshape that dim to target shape
        left = list(x.shape[:i])
        middle = list(x.shape[i:j])
        right = list(x.shape[j:])
        def prod(seq):
            p = 1
            for v in seq:
                p *= v
            return p
        middle_prod = prod(middle)
        # handle -1 in provided shape
        target = list(shape)
        if -1 in target:
            if target.count(-1) > 1:
                raise ValueError("Only one -1 allowed")
            known = prod([d for d in target if d != -1])
            if known == 0:
                raise ValueError("Cannot infer with zero known product")
            if middle_prod % known != 0:
                raise ValueError("Incompatible shape")
            target[target.index(-1)] = middle_prod // known
        if prod(target) != middle_prod:
            raise ValueError("Shape mismatch")
        # flatten the middle
        flat = x.flatten(start_dim=i, end_dim=j-1)
        # now flat has dims left + [middle_prod] + right
        new_shape = tuple(left + target + right)
        return flat.reshape(new_shape)
