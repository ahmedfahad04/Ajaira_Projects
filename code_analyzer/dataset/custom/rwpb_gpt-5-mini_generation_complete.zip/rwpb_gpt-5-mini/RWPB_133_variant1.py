
def divide_to_patches(image, patch_size):
    from PIL import Image
    def divide_to_patches(image, patch_size):
        if not isinstance(patch_size, int) or patch_size <= 0:
            raise ValueError("patch_size must be a positive integer")
        w, h = image.size
        patches = []
        max_x = (w // patch_size) * patch_size
        max_y = (h // patch_size) * patch_size
        for y in range(0, max_y, patch_size):
            for x in range(0, max_x, patch_size):
                patches.append(image.crop((x, y, x + patch_size, y + patch_size)))
        return patches
