
def interpolate_features(features,:
    import numpy as np
    def interpolate_features(features, input_rate, output_rate, output_len):
        features = np.asarray(features)
        if output_len <= 0:
            if features.ndim == 1:
                return np.zeros((0,), dtype=features.dtype)
            else:
                return np.zeros((0, features.shape[1]), dtype=features.dtype)
        if features.size == 0:
            if features.ndim == 1:
                return np.zeros((output_len,), dtype=features.dtype)
            else:
                return np.zeros((output_len, features.shape[1]), dtype=features.dtype)
        was_1d = False
        if features.ndim == 1:
            features = features[:, None]
            was_1d = True
        T, D = features.shape
        if T == 1:
            out = np.repeat(features, output_len, axis=0)
            return out.ravel() if was_1d else out
        pos = np.arange(output_len) * (input_rate / float(output_rate))
        pos = np.clip(pos, 0.0, T - 1.0)
        left = np.floor(pos).astype(int)
        right = np.minimum(left + 1, T - 1)
        w = pos - left
        left_vals = features[left]      # shape (output_len, D)
        right_vals = features[right]
        out = (1.0 - w)[:, None] * left_vals + w[:, None] * right_vals
        out = out.astype(features.dtype, copy=False)
        return out.ravel() if was_1d else out
