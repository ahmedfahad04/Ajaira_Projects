
def format_ratio(ratio):
    def format_ratio(ratio):
        import math
        try:
            r = float(ratio)
        except Exception:
            r = 0.0
        # truncate towards zero using floor/ceil depending on sign
        scaled = r * 1000.0
        if r >= 0:
            truncated = math.floor(scaled) / 1000.0
        else:
            truncated = math.ceil(scaled) / 1000.0
        return "percentage:{:.3f}".format(truncated)
