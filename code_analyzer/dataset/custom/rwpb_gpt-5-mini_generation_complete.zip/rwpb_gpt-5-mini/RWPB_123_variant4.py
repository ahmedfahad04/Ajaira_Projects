
def fuse_deconv_and_bn(deconv, bn):
    import torch
    import torch.nn as nn
    import numpy as np
    def fuse_deconv_and_bn(deconv, bn):
        if not isinstance(deconv, nn.ConvTranspose2d) or not isinstance(bn, nn.BatchNorm2d):
            raise ValueError("Expected ConvTranspose2d and BatchNorm2d")
        if bn.num_features != deconv.out_channels:
            raise ValueError("BatchNorm num_features must match deconv out_channels")
        W = deconv.weight.detach().cpu().numpy()
        device = deconv.weight.device
        dtype = deconv.weight.dtype
        running_mean = bn.running_mean.detach().cpu().numpy()
        running_var = bn.running_var.detach().cpu().numpy()
        gamma = bn.weight.detach().cpu().numpy() if bn.weight is not None else np.ones_like(running_mean)
        beta = bn.bias.detach().cpu().numpy() if bn.bias is not None else np.zeros_like(running_mean)
        eps = bn.eps
        scale = gamma / np.sqrt(running_var + eps)  # shape [out_channels]
        out_channels = deconv.out_channels
        groups = deconv.groups
        in_channels = deconv.in_channels
        out_per_group = out_channels // groups
        in_per_group = in_channels // groups
        W_fused = np.empty_like(W)
        # W shape (in_channels, out_per_group, kH, kW)
        for oc in range(out_channels):
            g = oc // out_per_group
            idx = oc % out_per_group
            s = scale[oc]
            start = g * in_per_group
            end = (g + 1) * in_per_group
            W_fused[start:end, idx, :, :] = W[start:end, idx, :, :] * s
        b_conv = deconv.bias.detach().cpu().numpy() if deconv.bias is not None else np.zeros(out_channels)
        b_fused = (b_conv - running_mean) * scale + beta
        fused = nn.ConvTranspose2d(
            in_channels=deconv.in_channels,
            out_channels=deconv.out_channels,
            kernel_size=deconv.kernel_size,
            stride=deconv.stride,
            padding=deconv.padding,
            output_padding=deconv.output_padding,
            groups=deconv.groups,
            bias=True,
            dilation=deconv.dilation,
            padding_mode=deconv.padding_mode
        )
        fused.weight.data.copy_(torch.from_numpy(W_fused).to(device=device, dtype=dtype))
        fused.bias.data.copy_(torch.from_numpy(b_fused).to(device=device, dtype=dtype))
        return fused
