
def get_line_angle(x1, y1, x2, y2):
    import math
    def get_line_angle(x1, y1, x2, y2):
        dx = x2 - x1
        dy = y2 - y1
        length = math.hypot(dx, dy)
        if length == 0:
            return 0.0
        cos_theta = max(-1.0, min(1.0, dx / length))
        theta = math.acos(cos_theta)
        if dy < 0:
            theta = -theta
        return math.degrees(theta)
