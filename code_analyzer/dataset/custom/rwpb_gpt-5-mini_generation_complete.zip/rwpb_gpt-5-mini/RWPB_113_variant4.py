
def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
    import torch
    def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
        if num <= 0:
            return torch.empty(*torch.broadcast_shapes(start.shape, stop.shape), 0, device=start.device, dtype=torch.promote_types(start.dtype, stop.dtype))
        dtype = torch.promote_types(start.dtype, stop.dtype)
        start = start.to(dtype)
        stop = stop.to(dtype)
        device = start.device
        if num == 1:
            return start.unsqueeze(-1)
        # Flatten broadcasted tensors to 1D, compute outer interpolation, then reshape back
        bshape = torch.broadcast_shapes(start.shape, stop.shape)
        start_b = start.broadcast_to(bshape).contiguous().view(-1, 1)
        stop_b = stop.broadcast_to(bshape).contiguous().view(-1, 1)
        weights = torch.linspace(0.0, 1.0, steps=num, dtype=dtype, device=device).view(1, num)
        # start*(1-w) + stop*w -> (start * (1 - w)) + (stop * w)
        out_flat = start_b * (1.0 - weights) + stop_b * weights
        # reshape to broadcast shape + (num,)
        return out_flat.view(*bshape, num)
