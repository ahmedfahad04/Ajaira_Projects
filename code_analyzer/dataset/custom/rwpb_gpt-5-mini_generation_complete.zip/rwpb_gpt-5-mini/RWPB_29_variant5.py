
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        # Compact list-comprehension based approach
        if torch.is_tensor(preds) and torch.is_tensor(labels):
            device = preds.device
        else:
            device = None
        # Ensure tensors
        if not torch.is_tensor(preds):
            preds = torch.tensor(preds)
        if not torch.is_tensor(labels):
            labels = torch.tensor(labels)
        # Remove channel dim if singleton
        if preds.ndim == 4 and preds.size(1) == 1:
            preds = preds.squeeze(1)
        if labels.ndim == 4 and labels.size(1) == 1:
            labels = labels.squeeze(1)
        if preds.shape != labels.shape:
            raise ValueError("preds and labels must have same shape")
        if preds.ndim == 2:
            preds = preds.unsqueeze(0)
            labels = labels.unsqueeze(0)
        # compute per-image IoU values
        def single_iou(p, l):
            pm = (p > 0.5).clone()
            lm = (l > 0.5).clone()
            if ignore is not None:
                m = (l == ignore)
                if m.any():
                    pm[m] = False
                    lm[m] = False
            inter = int((pm & lm).sum().item())
            union = int((pm | lm).sum().item())
            if union == 0:
                return float(EMPTY)
            return inter / union
        iou_list = [single_iou(preds[i], labels[i]) for i in range(preds.size(0))]
        if per_image:
            return float(sum(iou_list) / len(iou_list) * 100.0)
        else:
            # aggregate global
            # build global masks
            pm_global = (preds > 0.5)
            lm_global = (labels > 0.5)
            if ignore is not None:
                for i in range(labels.size(0)):
                    mask = (labels[i] == ignore)
                    if mask.any():
                        pm_global[i][mask] = False
                        lm_global[i][mask] = False
            inter = int((pm_global & lm_global).sum().item())
            union = int((pm_global | lm_global).sum().item())
            if union == 0:
                return float(EMPTY * 100.0)
            return float((inter / union) * 100.0)
