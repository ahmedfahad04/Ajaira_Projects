
def movmean(arr, n_avg):
    import numpy as np
    def movmean(arr, n_avg):
        a = np.asarray(arr, dtype=float).ravel()
        if n_avg <= 0:
            return np.array([], dtype=float)
        N = a.size
        if n_avg > N:
            return np.array([], dtype=float)
        # use cumulative sum to get window sums in O(N)
        csum = np.empty(N + 1, dtype=float)
        csum[0] = 0.0
        csum[1:] = np.cumsum(a)
        # window sums: csum[i+n] - csum[i] for i in 0..N-n
        sums = csum[n_avg:] - csum[:-n_avg]
        return sums / float(n_avg)
