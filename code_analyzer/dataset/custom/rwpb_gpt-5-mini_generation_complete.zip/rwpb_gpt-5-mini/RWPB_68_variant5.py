
def last_before(val, arr):
    from bisect import bisect_right
    def last_before(val, arr):
        # Convert to list and use bisect
        try:
            seq = list(arr)
        except TypeError:
            seq = list(arr)
        i = bisect_right(seq, val) - 1
        return i
