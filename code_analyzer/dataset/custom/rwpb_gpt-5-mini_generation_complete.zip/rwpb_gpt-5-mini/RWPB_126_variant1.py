
def crop_mask(masks, boxes):
    import torch
    def crop_mask(masks, boxes):
        """
        Loop-based cropping using integer-clamped box coordinates.
        """
        if masks.dim() != 3:
            raise ValueError("masks must be [n, h, w]")
        n, h, w = masks.shape
        if boxes.shape[0] != n or boxes.shape[1] != 4:
            raise ValueError("boxes must be [n, 4] and match masks batch size")
        device = masks.device
        out = torch.zeros_like(masks)
        b = boxes.to(masks.dtype).to(device)
        # Use floor for x1,y1 and ceil for x2,y2, then clamp to image bounds
        x1 = torch.floor(b[:, 0]).long().clamp(min=0, max=w - 1)
        y1 = torch.floor(b[:, 1]).long().clamp(min=0, max=h - 1)
        x2 = torch.ceil(b[:, 2]).long().clamp(min=0, max=w - 1)
        y2 = torch.ceil(b[:, 3]).long().clamp(min=0, max=h - 1)
        for i in range(n):
            xi1, yi1, xi2, yi2 = x1[i].item(), y1[i].item(), x2[i].item(), y2[i].item()
            if xi1 <= xi2 and yi1 <= yi2:
                out[i, yi1:yi2 + 1, xi1:xi2 + 1] = masks[i, yi1:yi2 + 1, xi1:xi2 + 1]
            # else leave zeros (invalid box)
        return out
