
def submatrix(matrix, col):
    def submatrix(matrix, col):
        if not matrix:
            return []
        # Validate that the column exists in each row
        for row in matrix:
            try:
                _ = row[col]
            except Exception:
                raise IndexError("column index out of range")
        return [row[:col] + row[col+1:] for row in matrix]
