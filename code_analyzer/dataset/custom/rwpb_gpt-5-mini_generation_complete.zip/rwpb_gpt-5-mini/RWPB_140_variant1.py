
def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
    from typing import Callable, Dict, Tuple, Any
    import inspect
    from functools import partial
    def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
        try:
            sig = inspect.signature(func)
        except (TypeError, ValueError):
            return partial(func), {}
        params_dict = {}
        has_varkw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
        for k, v in params.items():
            if not isinstance(k, str):
                continue
            if has_varkw:
                params_dict[k] = v
            else:
                param = sig.parameters.get(k)
                if param is None:
                    continue
                if param.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.VAR_POSITIONAL):
                    continue
                params_dict[k] = v
        return partial(func, **params_dict), params_dict
