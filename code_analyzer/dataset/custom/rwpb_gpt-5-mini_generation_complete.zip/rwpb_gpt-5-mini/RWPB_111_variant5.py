
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        grid = torch.empty((2, H, W), dtype=torch.float32)
        for i in range(H):
            for j in range(W):
                grid[0, i, j] = float(j)
                grid[1, i, j] = float(i)
        return grid.unsqueeze(0).expand(B, -1, -1, -1).contiguous()
