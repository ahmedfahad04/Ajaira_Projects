
def arccos2(vector, value):
    import math
    import numpy as np
    def arccos2(vector, value):
        arr = np.array(vector, dtype=float)
        val = np.clip(value, -1.0, 1.0)
        ang = float(np.arccos(val))
        y = 0.0
        if arr.size >= 2:
            y = float(arr[1])
        elif arr.size == 1:
            y = 0.0
        if y < 0.0:
            return -ang
        return ang
