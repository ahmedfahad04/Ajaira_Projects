
def validate_user_id(user_id):
    import re
    def validate_user_id(user_id):
        if not isinstance(user_id, str):
            return False
        if user_id == '':
            return False
        return re.match(r'[A-Za-z][A-Za-z0-9_]*\\Z', user_id) is not None
