
def fovx_to_fovy(fovx, aspect):
    import numpy as np
    import math
    def fovx_to_fovy(fovx, aspect):
        try:
            # attempt scalar path for speed
            return 2.0 * math.atan(math.tan(0.5 * fovx) / aspect)
        except Exception:
            fovx_arr = np.asarray(fovx, dtype=float)
            aspect_arr = np.asarray(aspect, dtype=float)
            res = 2.0 * np.arctan(np.tan(0.5 * fovx_arr) / aspect_arr)
            if res.shape == ():
                return float(res)
            return res
