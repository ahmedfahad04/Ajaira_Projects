
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        min_h, min_w = size
        img = sample.get("image", None)
        if img is None:
            return None
        h, w = img.shape[:2]
        # Only upscale to meet minimums, preserve aspect ratio
        if h >= min_h and w >= min_w:
            return (h, w)
        scale_h = float(min_h) / h if h < min_h else 1.0
        scale_w = float(min_w) / w if w < min_w else 1.0
        scale = max(scale_h, scale_w)
        # compute integer sizes using rounding to nearest pixel
        new_h = max(1, int(math.ceil(h * scale)))
        new_w = max(1, int(math.ceil(w * scale)))
        # resize using cv2 with dsize (width, height)
        sample["image"] = cv2.resize(img, (new_w, new_h), interpolation=image_interpolation_method)
        # disparity: resize and multiply by scale factor (preserving depth relation)
        if "disparity" in sample and sample["disparity"] is not None:
            d = np.asarray(sample["disparity"])
            # Keep float computation then cast back
            d_resized = cv2.resize(d.astype(np.float32), (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            d_resized = d_resized * (new_w / float(w))  # equal to scale but robust
            sample["disparity"] = d_resized.astype(d.dtype)
        # mask: nearest neighbor, ensure same dtype and binary
        if "mask" in sample and sample["mask"] is not None:
            m = np.asarray(sample["mask"])
            m_resized = cv2.resize(m, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            if m_resized.dtype != m.dtype:
                m_resized = m_resized.astype(m.dtype)
            # normalize to binary if original mask was binary-like
            if m_resized.max() > 1 or m_resized.min() < 0:
                m_resized = (m_resized > 0).astype(m.dtype)
            sample["mask"] = m_resized
        return (new_h, new_w)
