
def unpad_image_shape(current_height, current_width, original_size):
    def unpad_image_shape(current_height, current_width, original_size):
        orig_w, orig_h = original_size
        # Guard against zero or invalid originals
        if orig_w <= 0 or orig_h <= 0 or current_width <= 0 or current_height <= 0:
            return (current_height, current_width)
        # compute scale that was applied during letterbox-style resizing
        scale_w = current_width / orig_w
        scale_h = current_height / orig_h
        scale = min(scale_w, scale_h)
        new_w = max(1, int(round(orig_w * scale)))
        new_h = max(1, int(round(orig_h * scale)))
        # ensure we don't exceed current dims due to rounding
        new_w = min(new_w, current_width)
        new_h = min(new_h, current_height)
        return (new_h, new_w)
