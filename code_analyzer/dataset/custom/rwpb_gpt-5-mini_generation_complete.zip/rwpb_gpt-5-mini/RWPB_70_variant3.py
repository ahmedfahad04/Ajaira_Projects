
def psnr_to_mse(psnr):
    import numpy as np
    import math
    def psnr_to_mse(psnr):
        if isinstance(psnr, (list, tuple, np.ndarray)):
            arr = np.asarray(psnr, dtype=float)
            return np.power(10.0, -arr / 10.0)
        return math.pow(10.0, -float(psnr) / 10.0)
