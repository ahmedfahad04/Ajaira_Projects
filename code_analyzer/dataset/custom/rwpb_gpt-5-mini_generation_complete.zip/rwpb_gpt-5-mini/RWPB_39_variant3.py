
def clean_html(:
    import re
    from typing import List
    from html import escape
    from html.parser import HTMLParser
    def clean_html(
            html_to_clean: str,
            tags_to_remove: List[str] = ["style", "svg", "script"],
            attributes_to_keep: List[str] = ["id", "href"],
    ) -> str:
        class Builder(HTMLParser):
            def __init__(self):
                super().__init__(convert_charrefs=False)
                self.out = []
                self.remove = set(t.lower() for t in tags_to_remove)
                self.keep = set(a.lower() for a in attributes_to_keep)
                self.skip_stack = []
            def _emit_start(self, tag, attrs, selfclose=False):
                if self.skip_stack:
                    return
                kept = []
                for k, v in attrs:
                    if k and k.lower() in self.keep:
                        if v is None:
                            kept.append(k)
                        else:
                            kept.append(f'{k}="{escape(v, quote=True)}"')
                attr_text = (" " + " ".join(kept)) if kept else ""
                if selfclose:
                    self.out.append(f"<{tag}{attr_text}/>")
                else:
                    self.out.append(f"<{tag}{attr_text}>")
            def handle_starttag(self, tag, attrs):
                if tag.lower() in self.remove:
                    self.skip_stack.append(tag.lower())
                else:
                    self._emit_start(tag, attrs, selfclose=False)
            def handle_startendtag(self, tag, attrs):
                if tag.lower() in self.remove:
                    return
                self._emit_start(tag, attrs, selfclose=True)
            def handle_endtag(self, tag):
                if self.skip_stack:
                    if self.skip_stack[-1] == tag.lower():
                        self.skip_stack.pop()
                    return
                self.out.append(f"</{tag}>")
            def handle_data(self, data):
                if self.skip_stack:
                    return
                self.out.append(data)
            def handle_entityref(self, name):
                if self.skip_stack:
                    return
                self.out.append(f"&{name};")
            def handle_charref(self, name):
                if self.skip_stack:
                    return
                self.out.append(f"&#{name};")
            def handle_comment(self, data):
                if self.skip_stack:
                    return
                self.out.append(f"<!--{data}-->")
        p = Builder()
        p.feed(html_to_clean)
        p.close()
        return "".join(p.out)
