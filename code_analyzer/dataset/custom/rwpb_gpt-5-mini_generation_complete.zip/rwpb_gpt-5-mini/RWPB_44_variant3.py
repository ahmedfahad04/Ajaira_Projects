
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        if tensor1.shape[0] != tensor2.shape[0]:
            raise ValueError("First dimension sizes must match")
        parts1 = []
        parts2 = []
        N = tensor1.shape[0]
        for i in range(N):
            parts1.append(tensor1[i:i+1])
            parts1.append(tensor2[i:i+1])
            parts2.append(tensor2[i:i+1])
            parts2.append(tensor1[i:i+1])
        out1 = torch.cat(parts1, dim=0) if parts1 else tensor1.new_empty((0,) + tensor1.shape[1:])
        out2 = torch.cat(parts2, dim=0) if parts2 else tensor1.new_empty((0,) + tensor1.shape[1:])
        return out1, out2
