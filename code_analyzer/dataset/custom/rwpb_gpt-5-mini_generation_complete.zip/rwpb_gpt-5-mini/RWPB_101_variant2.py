
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    def generate_grids(lower_limit, upper_limit, grid_size):
        lower = torch.as_tensor(lower_limit)
        upper = torch.as_tensor(upper_limit)
        gs = torch.as_tensor(grid_size)
        lower = lower.flatten().to(dtype=torch.float64, device=lower.device)
        upper = upper.flatten().to(dtype=torch.float64, device=lower.device)
        gs = gs.flatten()
        D = lower.numel()
        if gs.numel() == 1 and D > 1:
            gs = gs.expand(D)
        gs = gs.to(dtype=torch.long)
        edges_low = []
        edges_high = []
        for i in range(D):
            n = int(gs[i].item())
            if n < 1:
                raise ValueError("grid_size must be >=1")
            edges = torch.linspace(lower[i], upper[i], steps=n + 1, device=lower.device, dtype=lower.dtype)
            edges_low.append(edges[:-1])
            edges_high.append(edges[1:])
        # use meshgrid and stacking
        if D == 0:
            return torch.empty((0, 0), dtype=lower.dtype), torch.empty((0, 0), dtype=lower.dtype)
        low_grids = torch.meshgrid(*edges_low, indexing='ij')
        high_grids = torch.meshgrid(*edges_high, indexing='ij')
        # flatten and stack dims
        flat_low = [g.contiguous().view(-1) for g in low_grids]
        flat_high = [g.contiguous().view(-1) for g in high_grids]
        lower_bounds = torch.stack(flat_low, dim=1)
        upper_bounds = torch.stack(flat_high, dim=1)
        return lower_bounds, upper_bounds
