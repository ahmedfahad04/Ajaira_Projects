
def is_byte_token(s: str) -> bool:
    from string import hexdigits
    def is_byte_token(s: str) -> bool:
        if not isinstance(s, str):
            return False
        if len(s) != 6:
            return False
        if s[0] != '<' or s[-1] != '>':
            return False
        if s[1] != '0' or s[2] not in ('x', 'X'):
            return False
        return all(ch in hexdigits for ch in s[3:5])
