
def _ssim(img1, img2, window, window_size, channel, size_average=True):
    import torch
    import torch.nn.functional as F
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        # Flatten batch and channel to perform one conv op with repeated kernels
        if img1.shape != img2.shape:
            raise ValueError("Input images must have the same dimensions.")
        added = False
        if img1.dim() == 3:
            img1 = img1.unsqueeze(0)
            img2 = img2.unsqueeze(0)
            added = True
        N, C, H, W = img1.shape
        assert C == channel
        pad = window_size // 2
        # repeat kernel for each (batch,channel) to allow grouped conv with groups=N*C
        base_kernel = window.view(1,1,window_size,window_size).to(img1.device, dtype=img1.dtype)
        reps = N * C
        weight = base_kernel.repeat(reps, 1, 1, 1)
        # reshape inputs to (1, N*C, H, W)
        x1 = img1.view(1, N*C, H, W)
        x2 = img2.view(1, N*C, H, W)
        # perform depthwise conv with groups=N*C
        mu1 = F.conv2d(F.pad(x1, (pad,pad,pad,pad)), weight, groups=reps)
        mu2 = F.conv2d(F.pad(x2, (pad,pad,pad,pad)), weight, groups=reps)
        mu1 = mu1.view(N, C, H, W)
        mu2 = mu2.view(N, C, H, W)
        mu1_sq = mu1 * mu1
        mu2_sq = mu2 * mu2
        mu1_mu2 = mu1 * mu2
        sigma1_sq = F.conv2d(F.pad(x1 * x1, (pad,pad,pad,pad)), weight, groups=reps).view(N, C, H, W) - mu1_sq
        sigma2_sq = F.conv2d(F.pad(x2 * x2, (pad,pad,pad,pad)), weight, groups=reps).view(N, C, H, W) - mu2_sq
        sigma12 = F.conv2d(F.pad(x1 * x2, (pad,pad,pad,pad)), weight, groups=reps).view(N, C, H, W) - mu1_mu2
        C1 = (0.01) ** 2
        C2 = (0.03) ** 2
        num = (2 * mu1_mu2 + C1) * (2 * sigma12 + C2)
        den = (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)
        ssim_map = num / (den + 1e-12)
        if size_average:
            return ssim_map.mean()
        else:
            return ssim_map.view(N, C, -1).mean(dim=0).mean(dim=1)
