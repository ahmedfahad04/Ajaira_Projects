
def compute_tri_normal(geometry, tris):
    import torch
    def compute_tri_normal(geometry, tris):
        """
        Compute area-weighted (unnormalized) triangle normals.
        geometry: (B, N, 3)
        tris: (M, 3)
        returns: (B, M, 3)
        """
        if geometry.numel() == 0:
            return torch.empty(geometry.shape[0], tris.shape[0], 3, device=geometry.device, dtype=geometry.dtype)
        tris = tris.to(geometry.device)
        # Use advanced indexing to get vertex coordinates per triangle
        verts = geometry[:, tris]  # (B, M, 3, 3)
        v0 = verts[:, :, 0, :]
        v1 = verts[:, :, 1, :]
        v2 = verts[:, :, 2, :]
        # Area-weighted normal: cross product of two edges (not normalized)
        normals = torch.cross(v1 - v0, v2 - v0, dim=-1)
        return normals
