
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float).reshape(3)
        b = np.asarray(b, dtype=float).reshape(3)
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na == 0 or nb == 0:
            return (None, None)
        u = a / na
        v = b / nb
        if np.allclose(u, v, atol=1e-12):
            return (None, None)
        cross = np.cross(u, v)
        cnorm = np.linalg.norm(cross)
        dot = np.dot(u, v)
        # deterministic choice for antiparallel or tiny cross
        if cnorm < 1e-12:
            if dot > 0:
                return (None, None)
            # antiparallel: construct orthogonal axis by selecting smallest component
            i = int(np.argmin(np.abs(u)))
            perp = np.zeros(3); perp[i] = 1.0
            axis = np.cross(u, perp)
            axis = axis / np.linalg.norm(axis)
            return (axis, np.pi)
        # otherwise axis is normalized cross
        axis = cross / cnorm
        # angle computed robustly
        angle = np.arctan2(cnorm, np.clip(dot, -1.0, 1.0))
        return (axis, angle)
