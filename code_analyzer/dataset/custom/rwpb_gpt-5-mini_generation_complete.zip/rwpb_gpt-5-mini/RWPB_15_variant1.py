
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        if a.ndim != 1:
            return KeyError("a must be a 1-D vector")
        if b.ndim == 1:
            if a.shape[0] != b.shape[0]:
                return KeyError("length mismatch")
            denom = np.linalg.norm(a) * np.linalg.norm(b)
            if denom == 0:
                raise ValueError("zero-length vector")
            cos_sim = np.dot(a, b) / denom
            cos_sim = np.clip(cos_sim, -1.0, 1.0)
            return 1.0 - float(cos_sim)
        elif b.ndim == 2:
            if a.shape[0] != b.shape[1]:
                return KeyError("length mismatch")
            a_norm = np.linalg.norm(a)
            b_norms = np.linalg.norm(b, axis=1)
            denom = a_norm * b_norms
            if np.any(denom == 0):
                raise ValueError("zero-length vector in b or a")
            dots = b.dot(a)
            cos_sim = dots / denom
            cos_sim = np.clip(cos_sim, -1.0, 1.0)
            return 1.0 - cos_sim
        else:
            return KeyError("b must be 1-D or 2-D")
