
def path_spliter(path: str):
    import re
    from pathlib import PurePosixPath, PureWindowsPath
    def path_spliter(path: str):
        if path is None:
            return []
        s = str(path)
        if s == '':
            return []
        # Heuristic: if contains backslashes or drive letter, use Windows parsing
        use_windows = False
        if '\\' in s or re.match(r'^[A-Za-z]:', s) or s.startswith('\\\\') or s.startswith('//'):
            use_windows = True
        if use_windows:
            p = PureWindowsPath(s)
        else:
            p = PurePosixPath(s)
        parts = list(p.parts)
        return parts
