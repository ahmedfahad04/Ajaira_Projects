
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        min_h, min_w = size
        img = sample.get("image", None)
        if img is None:
            return None
        h, w = img.shape[:2]
        # If already meets requirements, return
        if h >= min_h and w >= min_w:
            return (h, w)
        # Iteratively upscale by factors of two until both dims meet requirements (reduces interpolation artifacts)
        new_img = img
        new_disp = np.asarray(sample["disparity"]) if "disparity" in sample and sample["disparity"] is not None else None
        new_mask = np.asarray(sample["mask"]) if "mask" in sample and sample["mask"] is not None else None
        current_h, current_w = h, w
        total_scale = 1.0
        # Double until both dimensions exceed targets, then do final precise scale if necessary
        while current_h < min_h or current_w < min_w:
            # decide doubling
            if current_h * 2 <= min_h or current_w * 2 <= min_w:
                fx = 2.0
                fy = 2.0
            else:
                # final small scale
                scale = max(float(min_h) / current_h if current_h < min_h else 1.0,
                            float(min_w) / current_w if current_w < min_w else 1.0)
                fx = fy = scale
            # perform resize
            new_w = max(1, int(math.ceil(current_w * fx)))
            new_h = max(1, int(math.ceil(current_h * fy)))
            new_img = cv2.resize(new_img, (new_w, new_h), interpolation=image_interpolation_method)
            if new_disp is not None:
                # resize disparity and scale values by fx (same as fy here)
                new_disp = cv2.resize(new_disp.astype(np.float32), (new_w, new_h), interpolation=cv2.INTER_LINEAR)
                new_disp = new_disp * fx
            if new_mask is not None:
                new_mask = cv2.resize(new_mask, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            current_h, current_w = new_h, new_w
            total_scale *= fx
            # break if we've reached or exceeded both minima
            if current_h >= min_h and current_w >= min_w:
                break
        sample["image"] = new_img
        if new_disp is not None:
            # cast back to original dtype if possible
            orig = sample.get("disparity")
            dtype = np.asarray(orig).dtype if orig is not None else new_disp.dtype
            sample["disparity"] = new_disp.astype(dtype)
        if new_mask is not None:
            orig_mask = sample.get("mask")
            dtype = np.asarray(orig_mask).dtype if orig_mask is not None else new_mask.dtype
            # ensure binary
            new_mask = (new_mask > 0.5).astype(dtype)
            sample["mask"] = new_mask
        return (current_h, current_w)
