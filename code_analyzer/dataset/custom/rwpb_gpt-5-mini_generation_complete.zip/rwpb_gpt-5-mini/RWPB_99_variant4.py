
def focal2fov(focal, pixels):
    import math
    def focal2fov(focal, pixels):
        # treat values very close to zero as zero
        if math.isclose(float(focal), 0.0, rel_tol=0.0, abs_tol=1e-12):
            return KeyError
        f = float(focal)
        p = float(pixels)
        return 2.0 * math.atan(p / (2.0 * f))
