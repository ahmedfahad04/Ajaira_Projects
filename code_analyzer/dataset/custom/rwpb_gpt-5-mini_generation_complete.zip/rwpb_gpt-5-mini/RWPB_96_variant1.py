
def movmean(arr, n_avg):
    import numpy as np
    def movmean(arr, n_avg):
        arr = np.asarray(arr)
        if n_avg <= 0:
            return np.array([], dtype=float)
        # flatten to 1D for moving average
        a = arr.ravel()
        L = a.size
        if n_avg > L:
            return np.array([], dtype=float)
        # use convolution with a normalized window
        window = np.ones(n_avg, dtype=float) / float(n_avg)
        mov = np.convolve(a.astype(float), window, mode='valid')
        return mov
