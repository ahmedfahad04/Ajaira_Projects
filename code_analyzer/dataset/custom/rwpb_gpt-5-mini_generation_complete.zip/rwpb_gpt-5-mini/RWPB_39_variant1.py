
def clean_html(:
    import re
    from typing import List
    from html import escape
    from html.parser import HTMLParser
    def clean_html(
            html_to_clean: str,
            tags_to_remove: List[str] = ["style", "svg", "script"],
            attributes_to_keep: List[str] = ["id", "href"],
    ) -> str:
        class Cleaner(HTMLParser):
            def __init__(self):
                super().__init__(convert_charrefs=False)
                self.result = []
                self.remove_stack = []
                self.remove_set = {t.lower() for t in tags_to_remove}
                self.keep_set = {a.lower() for a in attributes_to_keep}
            def handle_starttag(self, tag, attrs):
                t = tag.lower()
                if t in self.remove_set:
                    self.remove_stack.append(t)
                    return
                if self.remove_stack:
                    return
                kept = []
                for k, v in attrs:
                    if k and k.lower() in self.keep_set:
                        if v is None:
                            kept.append(k)
                        else:
                            kept.append(f'{k}="{escape(v, quote=True)}"')
                attr_text = (" " + " ".join(kept)) if kept else ""
                self.result.append(f"<{tag}{attr_text}>")
            def handle_startendtag(self, tag, attrs):
                t = tag.lower()
                if t in self.remove_set:
                    return
                if self.remove_stack:
                    return
                kept = []
                for k, v in attrs:
                    if k and k.lower() in self.keep_set:
                        if v is None:
                            kept.append(k)
                        else:
                            kept.append(f'{k}="{escape(v, quote=True)}"')
                attr_text = (" " + " ".join(kept)) if kept else ""
                self.result.append(f"<{tag}{attr_text}/>")
            def handle_endtag(self, tag):
                t = tag.lower()
                if self.remove_stack:
                    if self.remove_stack and self.remove_stack[-1] == t:
                        self.remove_stack.pop()
                    return
                self.result.append(f"</{tag}>")
            def handle_data(self, data):
                if self.remove_stack:
                    return
                self.result.append(data)
            def handle_entityref(self, name):
                if self.remove_stack:
                    return
                self.result.append(f"&{name};")
            def handle_charref(self, name):
                if self.remove_stack:
                    return
                self.result.append(f"&#{name};")
            def handle_comment(self, data):
                if self.remove_stack:
                    return
                self.result.append(f"<!--{data}-->")
            def handle_decl(self, decl):
                if self.remove_stack:
                    return
                self.result.append(f"<!{decl}>")
        parser = Cleaner()
        parser.feed(html_to_clean)
        parser.close()
        return "".join(parser.result)
