
def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        # Use batched matmul with broadcasting
        if planes.ndim != 3 or planes.size(2) != 3:
            raise ValueError("planes must be (P,3,3)")
        if coordinates.ndim != 3 or coordinates.size(2) != 3:
            raise ValueError("coordinates must be (N,M,3)")
        P = planes.shape[0]
        N, M, _ = coordinates.shape
        # use first two rows (axes) as plane axes
        axes = planes[:, :2, :]  # (P,2,3)
        # transpose to (P,3,2) for dot: coord (3) x axis^T (3,2) -> (2)
        axes_t = axes.transpose(1, 2)  # (P,3,2)
        coords_flat = coordinates.reshape(-1, 3)  # (N*M, 3)
        # prepare for broadcasting: (N*M,1,3) x (1,P,3,2) -> (N*M,P,1,2)
        prod = torch.matmul(coords_flat.unsqueeze(1), axes_t.unsqueeze(0))  # (N*M,P,1,2)
        prod = prod.squeeze(2)  # (N*M,P,2)
        # permute to (P,N,M,2) then reshape to (N*P, M, 2)
        prod = prod.permute(1, 0, 2).reshape(P, N, M, 2).permute(1, 0, 2, 3).reshape(N * P, M, 2)
        return prod
