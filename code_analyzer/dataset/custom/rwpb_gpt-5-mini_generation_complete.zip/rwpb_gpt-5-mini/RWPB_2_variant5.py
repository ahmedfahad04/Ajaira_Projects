
def logbessel_I_scipy(nu, z, check = True):
    import numpy as np
    import torch
    from scipy import special
    def logbessel_I_scipy(nu, z, check = True):
        # Use integer-order recurrence when nu is a small non-negative integer for stability
        is_torch = isinstance(z, torch.Tensor)
        if is_torch:
            device = z.device
            dtype = z.dtype
            z_np = z.detach().cpu().numpy()
        else:
            z_np = np.array(z, copy=False)
            device = None
            dtype = None
        orig_shape = z_np.shape
        z_flat = np.atleast_1d(z_np).ravel().astype(np.float64)
        tiny = np.finfo(np.float64).tiny
        # Detect if nu is a non-negative integer
        is_int_nu = (float(nu).is_integer() and nu >= 0)
        if is_int_nu:
            n = int(nu)
            # Handle special case z==0
            log_vals = np.empty_like(z_flat)
            zero_mask = (z_flat == 0)
            nonzero_mask = ~zero_mask
            if n == 0:
                # I0(0)=1
                log_vals[zero_mask] = 0.0
            else:
                log_vals[zero_mask] = -np.inf  # I_n(0)=0 for n>0 -> log = -inf
                if check and np.any(zero_mask):
                    # if check true, raise because log(0) encountered
                    raise ValueError("Bessel I evaluated to zero at z=0 for nu>0; log undefined.")
            if np.any(nonzero_mask):
                z_nz = z_flat[nonzero_mask]
                # Start with I0 and I1
                I0 = special.iv(0, z_nz)
                I1 = special.iv(1, z_nz)
                if n == 0:
                    Iv = I0
                elif n == 1:
                    Iv = I1
                else:
                    # compute up to n using forward recurrence: I_{k+1} = I_{k-1} - (2k / z) * I_k
                    I_prev = I0
                    I_curr = I1
                    for k in range(1, n):
                        I_next = I_prev - (2.0 * k / z_nz) * I_curr
                        I_prev, I_curr = I_curr, I_next
                    Iv = I_curr
                if check and np.any(Iv == 0):
                    raise ValueError("Bessel I evaluated to zero for some entries; log undefined.")
                Iv_safe = np.maximum(Iv, tiny)
                log_vals[nonzero_mask] = np.log(Iv_safe)
            log_vals = log_vals.reshape(orig_shape)
        else:
            # fallback to direct computation
            Iv = special.iv(nu, z_flat)
            if check and np.any(Iv == 0):
                raise ValueError("Bessel I evaluated to zero for some entries; log undefined.")
            Iv_safe = np.maximum(Iv, tiny)
            log_vals = np.log(Iv_safe).reshape(orig_shape)
        if is_torch:
            return torch.tensor(log_vals, dtype=dtype, device=device)
        else:
            return torch.tensor(log_vals)
