
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        try:
            import numpy as np
        except Exception:
            # fallback to pure python if numpy not available
            x, y, x1, y1 = box
            x, y, x1, y1 = float(x), float(y), float(x1), float(y1)
            cx = (x + x1) / 2.0
            cy = (y + y1) / 2.0
            w = abs(x1 - x)
            h = abs(y1 - y)
            new_w = w * float(expand)
            new_h = h * float(expand)
            new_x = cx - new_w / 2.0
            new_y = cy - new_h / 2.0
            new_x1 = cx + new_w / 2.0
            new_y1 = cy + new_h / 2.0
            s = max(new_w, new_h) / 2.0
            return [new_x, new_y, new_x1, new_y1], s
        arr = np.array(box, dtype=float)
        x, y, x1, y1 = arr
        # ensure ordering
        x_min = min(x, x1)
        x_max = max(x, x1)
        y_min = min(y, y1)
        y_max = max(y, y1)
        center = np.array([(x_min + x_max) / 2.0, (y_min + y_max) / 2.0])
        wh = np.array([x_max - x_min, y_max - y_min])
        new_wh = wh * float(expand)
        half = new_wh / 2.0
        new_min = center - half
        new_max = center + half
        new_box = [float(new_min[0]), float(new_min[1]), float(new_max[0]), float(new_max[1])]
        s = float(max(new_wh[0], new_wh[1]) / 2.0)
        return new_box, s
