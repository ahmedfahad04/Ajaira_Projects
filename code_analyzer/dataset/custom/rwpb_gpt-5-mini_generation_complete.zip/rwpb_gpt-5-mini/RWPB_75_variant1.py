
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        eps = 1e-12
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na < eps or nb < eps:
            return None, None
        ua = a / na
        ub = b / nb
        # cross product gives rotation axis (possibly zero if parallel or anti-parallel)
        axis = np.cross(ua, ub)
        axis_norm = np.linalg.norm(axis)
        dot = np.dot(ua, ub)
        # clamp dot
        dot = max(-1.0, min(1.0, dot))
        if axis_norm < eps:
            # vectors are parallel or anti-parallel
            if dot > 0.999999999:
                return None, None
            else:
                # opposite direction: need any axis orthogonal to ua
                # pick a vector not parallel to ua
                if abs(ua[0]) < abs(ua[1]) and abs(ua[0]) < abs(ua[2]):
                    helper = np.array([1.0, 0.0, 0.0])
                elif abs(ua[1]) < abs(ua[2]):
                    helper = np.array([0.0, 1.0, 0.0])
                else:
                    helper = np.array([0.0, 0.0, 1.0])
                axis = np.cross(ua, helper)
                axis /= np.linalg.norm(axis)
                angle = np.pi
                return axis, angle
        else:
            axis /= axis_norm
            # use atan2 for numerical stability: angle = atan2(||cross||, dot)
            angle = np.arctan2(axis_norm, dot)
            return axis, angle
