
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        stack = [(d, parent_key)]
        flat = {}
        while stack:
            current, base = stack.pop()
            for k, v in current.items():
                key_str = str(k)
                new_key = key_str if base == "" else base + sep + key_str
                if isinstance(v, dict):
                    if v:
                        stack.append((v, new_key))
                    # else skip empty dict
                else:
                    flat[new_key] = v
        return flat
