
def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
    from typing import Callable, Dict, Tuple, Any
    import inspect
    from functools import partial
    def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
        try:
            sig = inspect.signature(func)
        except (TypeError, ValueError):
            return partial(func), {}
        applicable = {}
        bound_kwargs = {}
        for k, v in params.items():
            if not isinstance(k, str):
                continue
            trial = dict(bound_kwargs)
            trial[k] = v
            try:
                sig.bind_partial(**trial)
            except TypeError:
                continue
            bound_kwargs = trial
        applicable = bound_kwargs
        return partial(func, **applicable), applicable
