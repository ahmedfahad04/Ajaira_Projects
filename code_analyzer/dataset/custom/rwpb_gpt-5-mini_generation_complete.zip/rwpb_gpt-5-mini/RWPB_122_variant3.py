
def view_range(x, i, j, shape):
    import torch
    from functools import reduce
    import operator
    def view_range(x, i, j, shape):
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        ndim = x.dim()
        if j is None:
            j = ndim
        if i < 0:
            i += ndim
        if j < 0:
            j += ndim
        if not (0 <= i <= j <= ndim):
            raise IndexError("Invalid i/j")
        left_idxs = list(range(0, i))
        mid_idxs = list(range(i, j))
        right_idxs = list(range(j, ndim))
        # permute middle to the end
        perm = left_idxs + right_idxs + mid_idxs
        permuted = x.permute(perm)
        # compute sizes
        left_right_shape = [permuted.shape[k] for k in range(len(left_idxs) + len(right_idxs))]
        middle_prod = 1
        for k in range(len(left_idxs) + len(right_idxs), permuted.dim()):
            middle_prod *= permuted.shape[k]
        target = list(shape)
        if -1 in target:
            if target.count(-1) > 1:
                raise ValueError("Only one -1 allowed")
            known = 1
            for v in target:
                if v != -1:
                    known *= v
            if known == 0 or middle_prod % known != 0:
                raise ValueError("Cannot infer -1 or incompatible")
            target[target.index(-1)] = middle_prod // known
        prod_target = 1
        for v in target:
            prod_target *= v
        if prod_target != middle_prod:
            raise ValueError("Target shape mismatch")
        # reshape permuted to left_right + target
        new_shape = tuple(left_right_shape + target)
        reshaped = permuted.reshape(new_shape)
        # need to move target dims back between left and right
        # build inverse permutation
        # current order: left, right, target
        # desired order: left, target, right
        L = len(left_idxs)
        R = len(right_idxs)
        T = len(target)
        # permutation to achieve desired order: indices -> new positions
        # construct permute_back such that new order is left (0..L-1), target (L..L+T-1), right (L+T..L+T+R-1)
        permute_back = list(range(L)) + list(range(L+R, L+R+T)) + list(range(L, L+R))
        return reshaped.permute(permute_back)
