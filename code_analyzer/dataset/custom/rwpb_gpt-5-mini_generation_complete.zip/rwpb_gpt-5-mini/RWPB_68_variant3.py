
def last_before(val, arr):
    import numpy as np
    def last_before(val, arr):
        arr = np.asarray(arr)
        idxs = np.nonzero(arr <= val)[0]
        if idxs.size == 0:
            return -1
        return int(idxs[-1])
