
def bbox_ioa(box1, box2, iou=False, eps=1e-7):
    import numpy as np
    def bbox_ioa(box1, box2, iou=False, eps=1e-7):
        b1 = np.asarray(box1, dtype=float)
        b2 = np.asarray(box2, dtype=float)
        if b1.ndim == 1:
            b1 = b1.reshape(1, 4)
        if b2.ndim == 1:
            b2 = b2.reshape(1, 4)
        n = b1.shape[0]
        m = b2.shape[0]
        res = np.zeros((n, m), dtype=float)
        area1 = np.maximum(b1[:, 2] - b1[:, 0], 0.0) * np.maximum(b1[:, 3] - b1[:, 1], 0.0)
        area2 = np.maximum(b2[:, 2] - b2[:, 0], 0.0) * np.maximum(b2[:, 3] - b2[:, 1], 0.0)
        for i in range(n):
            for j in range(m):
                xi1 = max(b1[i, 0], b2[j, 0])
                yi1 = max(b1[i, 1], b2[j, 1])
                xi2 = min(b1[i, 2], b2[j, 2])
                yi2 = min(b1[i, 3], b2[j, 3])
                w = xi2 - xi1
                h = yi2 - yi1
                if w > 0 and h > 0:
                    inter = w * h
                else:
                    inter = 0.0
                if iou:
                    union = area1[i] + area2[j] - inter
                    res[i, j] = inter / (union + eps)
                else:
                    res[i, j] = inter / (area2[j] + eps)
        return res
