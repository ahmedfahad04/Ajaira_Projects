
def dynamic_import_function(function_path):
    def dynamic_import_function(function_path):
        from importlib import import_module
        import sys
        if not isinstance(function_path, str) or '.' not in function_path:
            return ModuleNotFoundError("Invalid path")
        parts = function_path.split('.')
        for i in range(len(parts) - 1, 0, -1):
            mod_name = '.'.join(parts[:i])
            attr_chain = parts[i:]
            try:
                module = import_module(mod_name)
            except Exception:
                continue
            obj = module
            found = True
            for attr in attr_chain:
                if hasattr(obj, attr):
                    obj = getattr(obj, attr)
                else:
                    found = False
                    break
            if found:
                return obj
        return ModuleNotFoundError(f"No matching module/attribute for '{function_path}'")
