
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    def pad_to_max_seq_length(ls: list, max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be a non-negative integer")
        cur_len = len(ls)
        if cur_len == max_seq_length:
            return list(ls)
        if cur_len > max_seq_length:
            if check:
                raise ValueError("Sequence length is greater than max_seq_length")
            else:
                # when not checking, return truncated sequence to fit max_seq_length
                return list(ls[:max_seq_length])
        # need padding
        pad_count = max_seq_length - cur_len
        pads = [pad_idx] * pad_count
        if pad_right:
            return list(ls) + pads
        else:
            return pads + list(ls)
