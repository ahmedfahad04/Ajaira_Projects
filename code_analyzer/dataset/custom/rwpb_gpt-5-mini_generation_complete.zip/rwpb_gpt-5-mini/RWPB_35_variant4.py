
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        def gen_items(mapping, base):
            for k, v in mapping.items():
                key_s = str(k)
                full = key_s if base == "" else base + sep + key_s
                if isinstance(v, dict):
                    if v:
                        yield from gen_items(v, full)
                    # skip empty dict
                else:
                    yield full, v
        return dict(gen_items(d, parent_key))
