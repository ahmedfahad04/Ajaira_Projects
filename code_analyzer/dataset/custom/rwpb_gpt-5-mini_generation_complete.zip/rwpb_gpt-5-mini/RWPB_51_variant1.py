
def _ssim(img1, img2, window, window_size, channel, size_average=True):
    import torch
    import torch.nn.functional as F
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        if img1.shape != img2.shape:
            raise ValueError("Input images must have the same dimensions.")
        # ensure 4D: (N, C, H, W)
        original_ndim = img1.dim()
        if img1.dim() == 3:
            img1 = img1.unsqueeze(0)
            img2 = img2.unsqueeze(0)
        N, C, H, W = img1.shape
        assert C == channel, "channel mismatch"
        pad = window_size // 2
        # prepare window for depthwise conv
        if window.dim() == 4 and window.size(0) == 1 and window.size(1) == 1:
            _w = window.to(img1.device, dtype=img1.dtype)
        else:
            _w = window.view(1, 1, window_size, window_size).to(img1.device, dtype=img1.dtype)
        weight = _w.repeat(channel, 1, 1, 1)
        # compute means
        mu1 = F.conv2d(img1, weight, groups=channel, padding=pad)
        mu2 = F.conv2d(img2, weight, groups=channel, padding=pad)
        mu1_sq = mu1.pow(2)
        mu2_sq = mu2.pow(2)
        mu1_mu2 = mu1 * mu2
        # compute variances and covariance
        sigma1_sq = F.conv2d(img1 * img1, weight, groups=channel, padding=pad) - mu1_sq
        sigma2_sq = F.conv2d(img2 * img2, weight, groups=channel, padding=pad) - mu2_sq
        sigma12 = F.conv2d(img1 * img2, weight, groups=channel, padding=pad) - mu1_mu2
        # constants (assume image range [0,1])
        C1 = (0.01) ** 2
        C2 = (0.03) ** 2
        # ssim map
        numerator = (2 * mu1_mu2 + C1) * (2 * sigma12 + C2)
        denominator = (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)
        ssim_map = numerator / (denominator + 1e-12)
        if size_average:
            return ssim_map.mean()
        else:
            # mean across batch and spatial dims, keep per-channel
            s = ssim_map.view(N, C, -1).mean(dim=0).mean(dim=1)
            return s
