
def rotate_x(a, device=None):
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        # Build rotation block and embed into 4x4
        dev = torch.device(device) if device is not None else None
        # compute sin/cos with numpy for scalars, torch for tensors
        if isinstance(a, torch.Tensor):
            ang = a.to(dev) if dev is not None else a
            c = torch.cos(ang)
            s = torch.sin(ang)
            rot3 = torch.tensor([[1.0, 0.0, 0.0],
                                 [0.0, c.item() if isinstance(c, torch.Tensor) and c.dim()==0 else float(c), 
                                  - (s.item() if isinstance(s, torch.Tensor) and s.dim()==0 else float(s))],
                                 [0.0, (s.item() if isinstance(s, torch.Tensor) and s.dim()==0 else float(s)),
                                  (c.item() if isinstance(c, torch.Tensor) and c.dim()==0 else float(c))]],
                                dtype=torch.get_default_dtype(), device=dev)
        else:
            c = np.cos(float(a))
            s = np.sin(float(a))
            rot3 = torch.tensor([[1.0, 0.0, 0.0],
                                 [0.0, c, -s],
                                 [0.0, s,  c]], dtype=torch.get_default_dtype(), device=dev)
        M = torch.eye(4, dtype=rot3.dtype, device=rot3.device)
        M[:3,:3] = rot3
        return M
