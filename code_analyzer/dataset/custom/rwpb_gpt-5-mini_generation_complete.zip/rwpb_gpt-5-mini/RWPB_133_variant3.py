
def divide_to_patches(image, patch_size):
    from PIL import Image
    def divide_to_patches(image, patch_size):
        if not isinstance(patch_size, int) or patch_size <= 0:
            raise ValueError("patch_size must be a positive integer")
        w, h = image.size
        pad_w = (-w) % patch_size
        pad_h = (-h) % patch_size
        if pad_w == 0 and pad_h == 0:
            padded = image
        else:
            mode = image.mode
            if "A" in mode:
                fill = (0, 0, 0, 0)
            elif mode == "RGB":
                fill = (0, 0, 0)
            elif mode == "L":
                fill = 0
            else:
                fill = 0
            padded = Image.new(mode, (w + pad_w, h + pad_h), fill)
            padded.paste(image, (0, 0))
        patches = []
        pw, ph = padded.size
        for y in range(0, ph, patch_size):
            for x in range(0, pw, patch_size):
                patches.append(padded.crop((x, y, x + patch_size, y + patch_size)))
        return patches
