
def check_all_columns_numeric(df):
    import pandas as pd
    from pandas.api.types import is_numeric_dtype
    def check_all_columns_numeric(df):
        """
        Return True if every column in the DataFrame has a numeric dtype.
        """
        if df is None:
            return False
        # If no columns, treat as True
        if getattr(df, "shape", (0, 0))[1] == 0:
            return True
        return all(is_numeric_dtype(dt) for dt in df.dtypes)
