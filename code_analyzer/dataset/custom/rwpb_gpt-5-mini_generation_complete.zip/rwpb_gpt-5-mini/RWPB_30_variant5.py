
def get_confusion_matrix(gt_label, pred_label, num_classes):
    import numpy as np
    from collections import Counter
    def get_confusion_matrix(gt_label, pred_label, num_classes):
        gt = np.asarray(gt_label).ravel()
        pred = np.asarray(pred_label).ravel()
        if gt.shape != pred.shape:
            raise ValueError("gt_label and pred_label must have the same length")
        if num_classes <= 0:
            return np.zeros((0, 0), dtype=np.int64)
        cm = np.zeros((num_classes, num_classes), dtype=np.int64)
        pairs = ((int(t), int(p)) for t, p in zip(gt, pred))
        cnt = Counter()
        for t, p in pairs:
            if 0 <= t < num_classes and 0 <= p < num_classes:
                cnt[(t, p)] += 1
        for (t, p), c in cnt.items():
            cm[t, p] = c
        return cm
