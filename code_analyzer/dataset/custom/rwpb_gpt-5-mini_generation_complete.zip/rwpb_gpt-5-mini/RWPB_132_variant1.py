
def B_batch(x, grid, k=0, extend=True, device="cpu"):
    import torch
    def B_batch(x, grid, k=0, extend=True, device="cpu"):
        x = x.to(device)
        grid = grid.to(device)
        S, N = x.shape
        assert grid.shape[0] == S, "grid must match number of splines"
        out_list = []
        for s in range(S):
            xs = x[s]  # (N,)
            knots_inner = grid[s]
            m = knots_inner.numel()
            if k > 0 and extend:
                # pad k copies at ends
                knots = torch.cat([knots_inner[0].repeat(k), knots_inner, knots_inner[-1].repeat(k)])
            else:
                knots = knots_inner.clone()
            p = max(k - 1, 0)
            K = knots.numel()
            n_bases = K - p - 1
            if n_bases <= 0:
                out_list.append(torch.zeros((0, N), device=device, dtype=xs.dtype))
                continue
            # initialize zeroth-degree basis
            # N_i^0(u) indicator for knots[i] <= u < knots[i+1], last includes equality
            left = knots[:-1].unsqueeze(1)  # (K-1,1)
            right = knots[1:].unsqueeze(1)  # (K-1,1)
            u = xs.unsqueeze(0)  # (1,N)
            # handle potential non-monotonic or duplicate knots; use >= for left, < for right, last include ==
            Nmat = ((u >= left) & (u < right)).to(xs.dtype)
            if K >= 2:
                # ensure the very last knot equality goes to last interval
                last_right = right[-1].squeeze()
                mask_last = (xs == last_right)
                if mask_last.any():
                    Nmat[-1, mask_last] = 1.0
            # Now iterate degrees
            for d in range(1, p + 1):
                out = torch.zeros((K - d - 1, N), device=device, dtype=xs.dtype)
                for i in range(0, K - d - 1):
                    denom1 = knots[i + d] - knots[i]
                    denom2 = knots[i + d + 1] - knots[i + 1]
                    term1 = 0.0
                    term2 = 0.0
                    if denom1 != 0:
                        term1 = ((u - knots[i]) / denom1) * Nmat[i]
                    if denom2 != 0:
                        term2 = ((knots[i + d + 1] - u) / denom2) * Nmat[i + 1]
                    out[i] = term1 + term2
                Nmat = out
            # Nmat now shape (n_bases, N)
            out_list.append(Nmat)
        # stack into (S, n_bases, N) but n_bases may vary if extend False -> pad to max
        max_b = max(mb.shape[0] for mb in out_list) if out_list else 0
        res = torch.zeros((S, max_b, N), device=device, dtype=x.dtype)
        for s in range(S):
            nb = out_list[s].shape[0]
            if nb > 0:
                res[s, :nb, :] = out_list[s]
        return res
