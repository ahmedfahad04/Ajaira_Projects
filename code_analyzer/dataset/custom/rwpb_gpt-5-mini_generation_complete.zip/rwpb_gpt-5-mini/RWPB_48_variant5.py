
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return original_size
        ow, oh = original_size
        best = None
        best_dist = None
        for w, h in possible_resolutions:
            # compute relative difference in each dimension (so different scales are comparable)
            rx = (w / ow - 1) if ow != 0 else float('inf')
            ry = (h / oh - 1) if oh != 0 else float('inf')
            dist = (rx * rx + ry * ry) ** 0.5
            # prefer not to upscale if distances similar: penalize positive relative change a bit
            penalty = 0.0
            if w > ow or h > oh:
                penalty = 0.1
            total = dist + penalty
            if best is None or total < best_dist:
                best = (w, h)
                best_dist = total
        return best
