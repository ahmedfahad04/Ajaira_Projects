
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        if not isinstance(image, np.ndarray):
            raise ValueError("Input is not a NumPy array and not a valid image")
        if image.ndim == 2:
            # grayscale H, W -> 1, H, W
            arr = image.astype(np.float32) / 255.0
            arr = arr[np.newaxis, ...]
        elif image.ndim == 3:
            # color H, W, C -> C, H, W
            if image.shape[2] <= 0:
                raise ValueError("Not a valid image")
            arr = image.transpose(2, 0, 1).astype(np.float32) / 255.0
        else:
            raise ValueError("Not a valid image")
        return torch.from_numpy(arr).float()
