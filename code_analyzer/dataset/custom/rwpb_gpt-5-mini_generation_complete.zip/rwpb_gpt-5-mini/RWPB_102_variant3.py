
def rotate_about_z_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_z_axis(vector, theta):
        vec = np.asarray(vector, dtype=float)
        x = float(vec[0])
        y = float(vec[1])
        z = float(vec[2])
        cos_t = math.cos(theta)
        sin_t = math.sin(theta)
        new_x = x * cos_t - y * sin_t
        new_y = x * sin_t + y * cos_t
        new_z = z
        return np.array([new_x, new_y, new_z], dtype=float)
