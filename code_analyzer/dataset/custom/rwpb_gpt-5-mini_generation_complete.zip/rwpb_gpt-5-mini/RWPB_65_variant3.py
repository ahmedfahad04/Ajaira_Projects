
def merge_dicts_recursively(*dicts):
    def merge_dicts_recursively(*dicts):
        if not dicts:
            return {}
        dicts = [d for d in dicts if isinstance(d, dict)]
        keys = set()
        for d in dicts:
            keys.update(d.keys())
        result = {}
        for k in keys:
            val = None
            for d in reversed(dicts):
                if k in d:
                    val = d[k]
                    break
            if isinstance(val, dict):
                subdicts = [d[k] for d in dicts if k in d and isinstance(d[k], dict)]
                result[k] = merge_dicts_recursively(*subdicts)
            else:
                result[k] = val
        return result
