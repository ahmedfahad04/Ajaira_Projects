
def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
    import torch
    def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
        import torch
        t_tensor = v0.new_tensor(t)
        v0 = v0.clone().to(torch.get_default_dtype())
        v1 = v1.clone().to(v0.dtype)
        v0_norm = torch.norm(v0, dim=-1, keepdim=True)
        v1_norm = torch.norm(v1, dim=-1, keepdim=True)
        v0_u = v0 / (v0_norm + 1e-12)
        v1_u = v1 / (v1_norm + 1e-12)
        dot = torch.sum(v0_u * v1_u, dim=-1, keepdim=True)
        dot_clamped = torch.clamp(dot, -1.0, 1.0)
        acos_theta = torch.acos(dot_clamped)
        small_angle = torch.abs(dot_clamped) > DOT_THRESHOLD
        # linear interpolation for small angle
        lerp = (1.0 - t_tensor) * v0_u + t_tensor * v1_u
        lerp = lerp / (torch.norm(lerp, dim=-1, keepdim=True) + 1e-12)
        sin_theta = torch.sin(acos_theta)
        s0 = torch.sin((1.0 - t_tensor) * acos_theta) / (sin_theta + 1e-12)
        s1 = torch.sin(t_tensor * acos_theta) / (sin_theta + 1e-12)
        s0 = s0.expand_as(v0_u)
        s1 = s1.expand_as(v0_u)
        out = s0 * v0_u + s1 * v1_u
        out = torch.where(small_angle.expand_as(out), lerp, out)
        norm_interp = (1.0 - t_tensor) * v0_norm + t_tensor * v1_norm
        return out * norm_interp
