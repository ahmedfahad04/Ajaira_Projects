
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        if a.ndim != 1:
            return KeyError("a must be 1-D")
        if b.ndim == 1:
            if a.shape[0] != b.shape[0]:
                return KeyError("length mismatch")
            # use einsum
            dot = np.einsum('i,i->', a, b)
            na = np.sqrt(np.einsum('i,i->', a, a))
            nb = np.sqrt(np.einsum('i,i->', b, b))
            if na == 0 or nb == 0:
                return KeyError("zero vector encountered")
            cos = dot / (na * nb)
            cos = float(np.clip(cos, -1.0, 1.0))
            return 1.0 - cos
        elif b.ndim == 2:
            if a.shape[0] != b.shape[1]:
                return KeyError("length mismatch")
            dots = np.einsum('i,ji->j', a, b)
            na = np.sqrt(np.einsum('i,i->', a, a))
            b_norms = np.sqrt(np.einsum('ji,ji->j', b, b))
            denom = na * b_norms
            if np.any(denom == 0):
                return KeyError("zero vector encountered")
            cos = dots / denom
            cos = np.clip(cos, -1.0, 1.0)
            return 1.0 - cos
        else:
            return KeyError("b must be 1-D or 2-D")
