
def merge_dicts_recursively(*dicts):
    import copy
    def merge_dicts_recursively(*dicts):
        dicts = [d for d in dicts if isinstance(d, dict)]
        def helper(idx_start, idx_end):
            if idx_start >= idx_end:
                return {}
            if idx_end - idx_start == 1:
                return copy.deepcopy(dicts[idx_start])
            mid = (idx_start + idx_end) // 2
            left = helper(idx_start, mid)
            right = helper(mid, idx_end)
            merged = copy.deepcopy(left)
            for k, v in right.items():
                if k in merged and isinstance(merged[k], dict) and isinstance(v, dict):
                    merged[k] = merge_dicts_recursively(merged[k], v)
                else:
                    merged[k] = copy.deepcopy(v)
            return merged
        if not dicts:
            return {}
        return helper(0, len(dicts))
