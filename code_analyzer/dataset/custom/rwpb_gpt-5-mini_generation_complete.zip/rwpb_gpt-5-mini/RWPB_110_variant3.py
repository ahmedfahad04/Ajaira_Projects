
def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
    import numpy as np
    def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
        # Use einsum for dot products and robust zero checks
        n = np.asarray(plane_normal, dtype=float).reshape(-1)
        p = np.asarray(plane_point, dtype=float).reshape(-1)
        d = np.asarray(ray_direction, dtype=float).reshape(-1)
        r = np.asarray(ray_point, dtype=float).reshape(-1)
        if np.linalg.norm(n) == 0:
            return None
        if np.linalg.norm(d) == 0:
            return None
        num = np.einsum('i,i->', n, p - r)
        den = np.einsum('i,i->', n, d)
        if abs(den) <= 1e-12:
            return None
        t = num / den
        return r + t * d
