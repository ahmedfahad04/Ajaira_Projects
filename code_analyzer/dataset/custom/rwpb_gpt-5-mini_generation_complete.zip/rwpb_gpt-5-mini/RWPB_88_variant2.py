
def rotate_y(a, device=None):
    import torch
    import numpy as np
    def rotate_y(a, device=None):
        angle = float(np.asarray(a).item())
        c = np.cos(angle)
        s = np.sin(angle)
        mat = np.array([[c, 0.0, s, 0.0],
                        [0.0, 1.0, 0.0, 0.0],
                        [-s, 0.0, c, 0.0],
                        [0.0, 0.0, 0.0, 1.0]], dtype=np.float32)
        t = torch.from_numpy(mat)
        if device is not None:
            t = t.to(device)
        return t
