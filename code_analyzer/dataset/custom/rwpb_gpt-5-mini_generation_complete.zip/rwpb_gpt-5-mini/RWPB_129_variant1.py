
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        """
        Rescale segment masks to shape.
        masks: (N, C, H, W)
        shape: (height, width)
        padding: if True, assume masks were produced on a letterboxed square (max(shape)) and should be center-cropped
        """
        if not isinstance(masks, torch.Tensor):
            masks = torch.tensor(masks)
        if masks.ndim != 4:
            raise ValueError("masks must be a 4D tensor (N, C, H, W)")
        N, C, H, W = masks.shape
        target_h, target_w = shape
        if H == target_h and W == target_w and not padding:
            return masks
        # If no padding assumed, simply interpolate to target shape
        if not padding:
            return F.interpolate(masks, size=(target_h, target_w), mode='bilinear', align_corners=False)
        # When padding=True, assume masks correspond to a square image of size s = max(shape).
        s = max(target_h, target_w)
        # Upsample to square then center-crop to (target_h, target_w)
        masks_up = F.interpolate(masks, size=(s, s), mode='bilinear', align_corners=False)
        y1 = (s - target_h) // 2
        x1 = (s - target_w) // 2
        cropped = masks_up[:, :, y1:y1 + target_h, x1:x1 + target_w]
        return cropped
