
def round_nearest_multiple(number, a, direction='standard'):
    from decimal import Decimal, getcontext, ROUND_HALF_UP, ROUND_FLOOR, ROUND_CEILING
    def round_nearest_multiple(number, a, direction='standard'):
        if a == 0:
            raise ValueError("a must be non-zero")
        # Use Decimal for precise control and to derive precision from 'a'
        getcontext().prec = 50
        da = Decimal(str(a))
        dn = Decimal(str(number))
        # quotient of how many 'a' fit into number
        q = dn / da
        dir_lower = (direction or 'standard').lower()
        if dir_lower == 'standard':
            rounding_mode = ROUND_HALF_UP
        elif dir_lower == 'down':
            # floor: toward -infinity
            rounding_mode = ROUND_FLOOR
        elif dir_lower == 'up':
            # ceiling: toward +infinity
            rounding_mode = ROUND_CEILING
        else:
            raise ValueError("direction must be 'standard', 'down', or 'up'")
        # round quotient to integer according to mode
        q_int = q.quantize(Decimal('1'), rounding=rounding_mode)
        result = q_int * da
        # quantize result to the same scale as 'a'
        exp = da.as_tuple().exponent
        quant = Decimal(1).scaleb(exp)
        result = result.quantize(quant, rounding=ROUND_HALF_UP)
        return float(result)
