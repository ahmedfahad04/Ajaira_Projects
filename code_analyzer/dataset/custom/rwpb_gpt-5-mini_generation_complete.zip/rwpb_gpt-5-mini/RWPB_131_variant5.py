
def box_iou(box1, box2, eps=1e-7):
    import torch
    import numpy as np
    def box_iou(box1, box2, eps=1e-7):
        if box1.numel() == 0 or box2.numel() == 0:
            return torch.zeros((box1.shape[0], box2.shape[0]), dtype=box1.dtype, device=box1.device)
        # compute widths/heights
        w1 = (box1[:,2] - box1[:,0]).clamp(min=0)
        h1 = (box1[:,3] - box1[:,1]).clamp(min=0)
        w2 = (box2[:,2] - box2[:,0]).clamp(min=0)
        h2 = (box2[:,3] - box2[:,1]).clamp(min=0)
        area1 = w1 * h1
        area2 = w2 * h2
        x1 = box1[:,0].unsqueeze(1).expand(-1, box2.size(0))
        y1 = box1[:,1].unsqueeze(1).expand(-1, box2.size(0))
        x2 = box1[:,2].unsqueeze(1).expand(-1, box2.size(0))
        y2 = box1[:,3].unsqueeze(1).expand(-1, box2.size(0))
        xx1 = torch.maximum(x1, box2[:,0].unsqueeze(0))
        yy1 = torch.maximum(y1, box2[:,1].unsqueeze(0))
        xx2 = torch.minimum(x2, box2[:,2].unsqueeze(0))
        yy2 = torch.minimum(y2, box2[:,3].unsqueeze(0))
        inter_w = (xx2 - xx1).clamp(min=0)
        inter_h = (yy2 - yy1).clamp(min=0)
        inter = inter_w * inter_h
        union = area1.unsqueeze(1) + area2.unsqueeze(0) - inter
        return inter / (union + eps)
