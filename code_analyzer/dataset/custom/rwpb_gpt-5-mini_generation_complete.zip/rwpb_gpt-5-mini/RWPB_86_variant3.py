
def inverse_sigmoid(x):
    import torch
    def inverse_sigmoid(x):
        x = torch.as_tensor(x)
        if not x.is_floating_point():
            x = x.float()
        eps = 1e-12
        x_clamped = torch.clamp(x, eps, 1 - eps)
        return torch.log(x_clamped) - torch.log1p(-x_clamped)
