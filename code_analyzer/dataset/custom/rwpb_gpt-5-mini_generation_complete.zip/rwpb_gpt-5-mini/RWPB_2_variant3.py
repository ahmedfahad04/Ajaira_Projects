
def logbessel_I_scipy(nu, z, check = True):
    import numpy as np
    import torch
    from scipy import special
    from math import pi
    def logbessel_I_scipy(nu, z, check = True):
        # Hybrid approach: use asymptotic expansion for large z, scipy otherwise
        is_torch = isinstance(z, torch.Tensor)
        if is_torch:
            device = z.device
            dtype = z.dtype
            z_np = z.detach().cpu().numpy()
        else:
            z_np = np.array(z, copy=False)
            device = None
            dtype = None
        orig_shape = z_np.shape
        z_flat = np.atleast_1d(z_np).ravel().astype(np.float64)
        log_iv = np.empty_like(z_flat, dtype=np.float64)
        # threshold for large z where asymptotic is OK
        threshold = 50.0
        large_mask = np.abs(z_flat) > threshold
        small_mask = ~large_mask
        tiny = np.finfo(np.float64).tiny
        # small z: directly compute
        if np.any(small_mask):
            iv_small = special.iv(nu, z_flat[small_mask])
            if check and np.any(iv_small == 0):
                raise ValueError("Bessel I evaluated to zero for some entries; log undefined.")
            iv_small_safe = np.maximum(iv_small, tiny)
            log_iv[small_mask] = np.log(iv_small_safe)
        # large z: asymptotic expansion
        if np.any(large_mask):
            z_l = z_flat[large_mask]
            # leading term: z - 0.5*ln(2*pi*z)
            leading = z_l - 0.5 * np.log(2.0 * pi * z_l)
            # first correction: 1 - (4*nu^2 - 1)/(8*z)
            corr = (4.0 * (nu ** 2) - 1.0) / (8.0 * z_l)
            # compute log(1 - corr) safely
            with np.errstate(divide='ignore', invalid='ignore'):
                log_correction = np.log1p(-corr)
            # if correction invalid (e.g. >=1), fallback to scipy
            invalid = ~np.isfinite(log_correction)
            log_iv_large = leading + log_correction
            if np.any(invalid):
                iv_fallback = special.iv(nu, z_l[invalid])
                iv_fallback_safe = np.maximum(iv_fallback, tiny)
                log_iv_large[invalid] = np.log(iv_fallback_safe)
            log_iv[large_mask] = log_iv_large
        log_iv = log_iv.reshape(orig_shape)
        if is_torch:
            return torch.tensor(log_iv, dtype=dtype, device=device)
        else:
            return torch.tensor(log_iv)
