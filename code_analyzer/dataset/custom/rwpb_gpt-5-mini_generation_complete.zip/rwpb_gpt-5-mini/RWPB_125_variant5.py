
def resample_segments(segments, n=1000):
    import numpy as np
    def resample_segments(segments, n=1000):
        resampled = []
        for seg in segments:
            seg = np.asarray(seg, dtype=float)
            if seg.ndim != 2 or seg.shape[1] != 2:
                raise ValueError("Each segment must be an array of shape (m, 2)")
            m = seg.shape[0]
            if m == 0:
                resampled.append(np.zeros((n,2), dtype=float))
                continue
            if m == 1:
                resampled.append(np.tile(seg[0], (n,1)))
                continue
            dif = seg[1:] - seg[:-1]
            d = np.hypot(dif[:,0], dif[:,1])
            cum = np.concatenate(([0.0], np.cumsum(d)))
            L = cum[-1]
            if L == 0.0:
                resampled.append(np.tile(seg[0], (n,1)))
                continue
            s = np.linspace(0.0, L, n)
            # build linear combinations using matrix of intervals
            idx = np.searchsorted(cum, s, side='right') - 1
            idx = np.clip(idx, 0, m-2)
            left = seg[idx]
            right = seg[idx+1]
            left_s = cum[idx]
            right_s = cum[idx+1]
            denom = right_s - left_s
            denom[denom==0] = 1.0
            w = ((s - left_s) / denom).reshape(-1,1)
            pts = left*(1-w) + right*w
            resampled.append(pts)
        return resampled
