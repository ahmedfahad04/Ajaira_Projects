
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        x = torch.linspace(0.0, float(W - 1), steps=W, dtype=torch.float32)
        y = torch.linspace(0.0, float(H - 1), steps=H, dtype=torch.float32)
        yv = y.view(H, 1).expand(H, W)
        xv = x.view(1, W).expand(H, W)
        grid = torch.stack([xv, yv], dim=0)
        return grid.unsqueeze(0).expand(B, -1, -1, -1)
