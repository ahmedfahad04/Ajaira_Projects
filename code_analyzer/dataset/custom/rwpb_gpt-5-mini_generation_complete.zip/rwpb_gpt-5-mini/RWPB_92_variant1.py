
def round(number, num_decimal_places, leave_int=False):
    from decimal import Decimal, ROUND_HALF_UP
    def round(number, num_decimal_places, leave_int=False):
        # Handle special types quickly
        if isinstance(number, Decimal):
            dec = number
        else:
            # Convert to string first to avoid binary float issues
            dec = Decimal(str(number))
        # Build exponent for quantize: '1e-<num>' for positive, '1e<abs(num)>' for negative
        exp = Decimal('1e{}'.format(-int(num_decimal_places)))
        # Quantize with ROUND_HALF_UP (common "away from .5" behavior)
        rounded = dec.quantize(exp, rounding=ROUND_HALF_UP)
        # If leave_int True and result is whole integer, return int; otherwise float
        if leave_int and rounded == rounded.to_integral_value():
            return int(rounded)
        return float(rounded)
