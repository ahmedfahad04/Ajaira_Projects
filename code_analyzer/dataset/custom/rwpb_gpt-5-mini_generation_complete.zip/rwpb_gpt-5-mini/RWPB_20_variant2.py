
def get_line_angle(x1, y1, x2, y2):
    import math
    def get_line_angle(x1, y1, x2, y2):
        dx = x2 - x1
        dy = y2 - y1
        if dx == 0 and dy == 0:
            return 0.0
        if dx == 0:
            return 90.0 if dy > 0 else -90.0
        slope = dy / dx
        angle_rad = math.atan(slope)
        if dx < 0:
            angle_rad += math.pi
        angle_deg = math.degrees(angle_rad)
        if angle_deg > 180:
            angle_deg -= 360
        return angle_deg
