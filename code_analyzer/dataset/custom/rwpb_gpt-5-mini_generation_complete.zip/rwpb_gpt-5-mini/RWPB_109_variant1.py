
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        """
        Applies rotation and translation to geometry.
        geometry: [B, N, 3]
        rot: [B, 3, 3] or [3,3]
        trans: [B, 3] or [3]
        """
        if not isinstance(geometry, torch.Tensor):
            geometry = torch.tensor(geometry)
        if not isinstance(rot, torch.Tensor):
            rot = torch.tensor(rot)
        if not isinstance(trans, torch.Tensor):
            trans = torch.tensor(trans)
        B = geometry.shape[0]
        # Ensure rot and trans have batch dim
        if rot.dim() == 2:
            rot = rot.unsqueeze(0).expand(B, -1, -1)
        if trans.dim() == 1:
            trans = trans.unsqueeze(0).expand(B, -1)
        # rotate: multiply points by rot^T when points are row vectors
        rotated = torch.matmul(geometry, rot.transpose(-2, -1))
        transformed = rotated + trans.unsqueeze(1)
        return transformed
