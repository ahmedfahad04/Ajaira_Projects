
def focal2fov(focal, pixels):
    import math
    def focal2fov(focal, pixels):
        # use atan2 to compute arctan safely; explicit check for focal zero requested
        if focal == 0:
            return KeyError
        return 2.0 * math.atan2(float(pixels), 2.0 * float(focal))
