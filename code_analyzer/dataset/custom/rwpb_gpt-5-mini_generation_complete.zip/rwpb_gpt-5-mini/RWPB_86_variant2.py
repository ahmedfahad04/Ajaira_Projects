
def inverse_sigmoid(x):
    import torch
    def inverse_sigmoid(x):
        x = torch.as_tensor(x)
        if not x.is_floating_point():
            x = x.float()
        try:
            return torch.logit(x, eps=1e-6)
        except Exception:
            eps = 1e-6
            x = x.clamp(eps, 1 - eps)
            return torch.log(x) - torch.log1p(-x)
