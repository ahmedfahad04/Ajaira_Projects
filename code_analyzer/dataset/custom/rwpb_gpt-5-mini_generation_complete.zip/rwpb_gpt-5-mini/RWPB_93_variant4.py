
def unsafeSub(x, y):
    MAX_VAL = (1 << 256) - 1
    def unsafeSub(x, y):
        return (((x & MAX_VAL) + (1 << 256) - (y & MAX_VAL)) & MAX_VAL)
