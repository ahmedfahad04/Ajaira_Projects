
def merge_short_sentences_en(sens):
    def merge_short_sentences_en(sens):
        """Punctuation-aware merge: remove end punctuation of a short sentence before merging and lowercase
        the start of the following sentence to make a natural continuation.
        Short defined as <=3 words.
        """
        if not sens:
            return []
        def strip_end_punct(s):
            s = s.rstrip()
            if s and s[-1] in '.!?':
                return s[:-1].rstrip()
            return s
        def lower_start(s):
            if not s:
                return s
            # preserve leading quotes/brackets
            i = 0
            while i < len(s) and s[i] in '\'"([{':
                i += 1
            if i < len(s):
                return s[:i] + s[i].lower() + s[i+1:]
            return s
        out = []
        i = 0
        n = len(sens)
        while i < n:
            cur = sens[i].strip()
            if len(cur.split()) <= 3 and i + 1 < n:
                # merge with next, stripping trailing punctuation from current
                a = strip_end_punct(cur)
                b = sens[i+1].strip()
                b = lower_start(b)
                merged = (a + ' ' + b).strip()
                out.append(merged)
                i += 2
            else:
                out.append(cur)
                i += 1
        # if last is short and there is a previous, attach to previous
        if len(out) >= 2 and len(out[-1].split()) <= 3:
            out[-2] = out[-2].rstrip() + ' ' + out[-1]
            out.pop()
        return out
