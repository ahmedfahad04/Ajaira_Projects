
def rot6d_to_rotmat(x):
    import torch
    import numpy as np
    def rot6d_to_rotmat(x):
        if isinstance(x, np.ndarray):
            x = torch.from_numpy(x)
        if not isinstance(x, torch.Tensor):
            raise ValueError("Input must be a torch.Tensor or numpy.ndarray")
        if x.dim() != 2 or x.shape[1] != 6:
            raise ValueError("Input must have shape (B,6)")
        x = x.float()
        a1 = x[:, :3]
        a2 = x[:, 3:6]
        # QR-based approach: orthonormalize first two columns via reduced QR
        A = torch.stack([a1, a2], dim=2)  # (B,3,2) columns are a1,a2
        # torch.linalg.qr with mode='reduced' returns Q (B,3,2)
        Q, Rtri = torch.linalg.qr(A, mode='reduced')
        q1 = Q[:, :, 0]
        q2 = Q[:, :, 1]
        q3 = torch.cross(q1, q2, dim=1)
        R = torch.stack([q1, q2, q3], dim=2)
        # ensure right-handed (determinant positive)
        dets = torch.linalg.det(R)
        if (dets < 0).any():
            mask = (dets < 0)
            R[mask, :, 2] = -R[mask, :, 2]
        return R
