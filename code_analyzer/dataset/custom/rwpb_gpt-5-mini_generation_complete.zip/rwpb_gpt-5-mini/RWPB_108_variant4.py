
def norm_grid(v_grid):
    import torch
    def norm_grid(v_grid):
        """Use arithmetic with reshaping and safe denominators, preserving dtype/device."""
        v = v_grid
        if not isinstance(v, torch.Tensor):
            v = torch.tensor(v)
        B, C, H, W = v.shape
        assert C == 2
        device = v.device
        dtype = v.dtype if v.dtype.is_floating_point else torch.float32
        v = v.to(dtype=dtype)
        v = v.permute(0, 2, 3, 1).contiguous()  # (B,H,W,2)
        denom_w = float(max(W - 1, 1))
        denom_h = float(max(H - 1, 1))
        # create scale and bias tensors
        scale = torch.tensor([2.0 / denom_w, 2.0 / denom_h], dtype=dtype, device=device).view(1, 1, 1, 2)
        bias = torch.tensor([-1.0, -1.0], dtype=dtype, device=device).view(1, 1, 1, 2)
        return v * scale + bias
