
def focal2fov(focal, pixels):
    import math
    from fractions import Fraction
    def focal2fov(focal, pixels):
        try:
            # use Fraction to form exact ratio, then convert to float for atan
            ratio = Fraction(pixels, 2 * focal)
        except ZeroDivisionError:
            return KeyError
        return 2.0 * math.atan(float(ratio))
