
def rotate_x(a, device=None):
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        # Minimal one-liner style construction
        dev = torch.device(device) if device is not None else None
        # get scalar angle
        if isinstance(a, torch.Tensor):
            aval = a.item()
        else:
            aval = float(a)
        c = float(np.cos(aval))
        s = float(np.sin(aval))
        mat = [[1.0, 0.0, 0.0, 0.0],
               [0.0, c, -s, 0.0],
               [0.0, s,  c, 0.0],
               [0.0, 0.0, 0.0, 1.0]]
        t = torch.tensor(mat, dtype=torch.get_default_dtype())
        if dev is not None:
            t = t.to(dev)
        return t
