
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    import math
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        # keep original input for prenorm
        orig_x = x
        orig_dtype = x.dtype
        if upcast:
            x = x.to(torch.float32)
            weight = weight.to(torch.float32)
            if bias is not None:
                bias = bias.to(torch.float32)
            if residual is not None:
                residual = residual.to(torch.float32)
        # use linalg.norm to compute sqrt(sum(x^2)) then divide by sqrt(n) to get RMS
        n = x.size(-1)
        sum_sq = torch.linalg.norm(x, ord=2, dim=-1, keepdim=True)  # sqrt(sum(x^2))
        rms = sum_sq / math.sqrt(n)
        inv_rms = 1.0 / torch.sqrt((rms * rms) / (rms * rms) + eps)  # fallback to stable expr
        # The above is a trick but simpler: compute inv_rms directly from mean squares
        mean_sq = (x * x).mean(dim=-1, keepdim=True)
        inv_rms = torch.rsqrt(mean_sq + eps)
        shape = [1] * (x.dim() - 1) + [-1]
        w = weight.view(*shape)
        out = (x * inv_rms) * w
        if bias is not None:
            b = bias.view(*shape)
            out = out + b
        if residual is not None:
            out = out + residual
        if upcast:
            out = out.to(orig_dtype)
        if prenorm:
            return out, orig_x
        return out
