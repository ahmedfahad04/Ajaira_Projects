
def rotate_about_z_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_z_axis(vector, theta):
        v = np.asarray(vector, dtype=float)
        # Rodrigues' rotation formula for axis k = (0,0,1)
        k = np.array([0.0, 0.0, 1.0], dtype=float)
        cos_t = math.cos(theta)
        sin_t = math.sin(theta)
        v_cos = v * cos_t
        k_cross_v = np.array([k[1]*v[2] - k[2]*v[1],
                              k[2]*v[0] - k[0]*v[2],
                              k[0]*v[1] - k[1]*v[0]], dtype=float)
        term_cross = k_cross_v * sin_t
        k_dot_v = k[0]*v[0] + k[1]*v[1] + k[2]*v[2]
        term_k = k * (k_dot_v * (1.0 - cos_t))
        rotated = v_cos + term_cross + term_k
        return rotated.astype(float)
