
def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        # Loop over planes (clear and simple)
        if planes.ndim != 3 or planes.size(2) != 3:
            raise ValueError("planes must be (P,3,3)")
        if coordinates.ndim != 3 or coordinates.size(2) != 3:
            raise ValueError("coordinates must be (N,M,3)")
        P = planes.shape[0]
        N, M, _ = coordinates.shape
        out_list = []
        for p in range(P):
            # take first two axis vectors as plane basis (shape (2,3))
            axes = planes[p, :2, :]  # (2,3)
            # project: (N,M,3) @ (3,2) -> (N,M,2)
            projected = torch.matmul(coordinates, axes.t())
            out_list.append(projected)
        # stack along plane dimension -> (P, N, M, 2)
        stacked = torch.stack(out_list, dim=0)
        # reorder to (N*P, M, 2)
        stacked = stacked.permute(1, 0, 2, 3).reshape(N * P, M, 2)
        return stacked
