
def getLambertCoefs(numOfLambertCoefs):
    from decimal import Decimal, getcontext
    from math import factorial
    def getLambertCoefs(numOfLambertCoefs):
        if not isinstance(numOfLambertCoefs, int) or numOfLambertCoefs <= 0:
            return []
        # set precision proportional to required number of terms
        getcontext().prec = max(28, min(80, 10 + numOfLambertCoefs * 2))
        dec_coefs = []
        for n in range(1, numOfLambertCoefs + 1):
            numer = Decimal((-n) ** (n - 1))
            den = Decimal(factorial(n))
            dec_coefs.append(numer / den)
        return dec_coefs
