
def rotate_y(a, device=None):
    import torch
    def rotate_y(a, device=None):
        dev = torch.device(device) if device is not None else None
        if dev is None:
            zero = torch.zeros(1)
        else:
            zero = torch.zeros(1, device=dev)
        angle = float(a) if not isinstance(a, torch.Tensor) else float(a.item())
        c = torch.tensor(angle).cos() if isinstance(angle, float) else angle.cos()
        c = torch.tensor([torch.cos(torch.tensor(angle))])[0] if isinstance(angle, float) else c
        s = torch.tensor([torch.sin(torch.tensor(angle))])[0] if isinstance(angle, float) else torch.sin(angle)
        if dev is None:
            R = torch.zeros((4,4), dtype=torch.get_default_dtype())
        else:
            R = torch.zeros((4,4), dtype=torch.get_default_dtype(), device=dev)
        R[0,0] = float(torch.cos(torch.tensor(angle)))
        R[0,2] = float(torch.sin(torch.tensor(angle)))
        R[1,1] = 1.0
        R[2,0] = -float(torch.sin(torch.tensor(angle)))
        R[2,2] = float(torch.cos(torch.tensor(angle)))
        R[3,3] = 1.0
        return R
