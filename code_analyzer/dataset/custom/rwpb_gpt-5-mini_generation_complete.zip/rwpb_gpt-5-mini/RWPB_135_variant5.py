
def mask_iou(mask1, mask2, eps=1e-7):
    import torch
    def mask_iou(mask1, mask2, eps=1e-7):
        """
        Brute-force nested loops computing dot products per pair (simple and explicit).
        """
        if not isinstance(mask1, torch.Tensor) or not isinstance(mask2, torch.Tensor):
            raise TypeError("mask1 and mask2 must be torch.Tensors")
        if mask1.ndim != 2 or mask2.ndim != 2:
            raise ValueError("mask1 and mask2 must be 2-D tensors")
        N, n1 = mask1.shape
        M, n2 = mask2.shape
        if n1 != n2:
            raise ValueError("mask1 and mask2 must have the same number of columns")
        device = mask1.device
        dtype = mask1.dtype
        out = torch.zeros((N, M), device=device, dtype=torch.float32)
        m1 = mask1.float()
        m2 = mask2.float()
        area1 = m1.sum(dim=1)
        area2 = m2.sum(dim=1)
        for i in range(N):
            vi = m1[i]
            for j in range(M):
                vj = m2[j]
                inter = torch.dot(vi, vj)
                union = area1[i] + area2[j] - inter
                if union > 0:
                    out[i, j] = inter / (union + eps)
                else:
                    out[i, j] = 0.0
        return out.to(dtype=dtype)
