
def interpolate_features(features,:
    import numpy as np
    def interpolate_features(features, input_rate, output_rate, output_len):
        features = np.asarray(features)
        try:
            from scipy.interpolate import interp1d
        except Exception:
            interp1d = None
        if output_len <= 0:
            if features.ndim == 1:
                return np.zeros((0,), dtype=features.dtype)
            else:
                return np.zeros((0, features.shape[1]), dtype=features.dtype)
        if features.ndim == 1:
            T = features.shape[0]
            if T == 0:
                return np.zeros((output_len,), dtype=features.dtype)
            x_out = np.arange(output_len) * (input_rate / float(output_rate))
            x_out = np.clip(x_out, 0, T - 1)
            if interp1d is not None and T > 1:
                f = interp1d(np.arange(T), features, kind='linear', bounds_error=False, fill_value=(features[0], features[-1]))
                return f(x_out).astype(features.dtype, copy=False)
            else:
                return np.interp(x_out, np.arange(T), features).astype(features.dtype, copy=False)
        T, D = features.shape
        if T == 0:
            return np.zeros((output_len, D), dtype=features.dtype)
        x_out = np.arange(output_len) * (input_rate / float(output_rate))
        x_out = np.clip(x_out, 0, T - 1)
        if interp1d is not None and T > 1:
            f = interp1d(np.arange(T), features, axis=0, kind='linear', bounds_error=False,
                         fill_value=(features[0], features[-1]))
            return f(x_out).astype(features.dtype, copy=False)
        else:
            out = np.vstack([np.interp(x_out, np.arange(T), features[:, i]) for i in range(D)]).T
            return out.astype(features.dtype, copy=False)
