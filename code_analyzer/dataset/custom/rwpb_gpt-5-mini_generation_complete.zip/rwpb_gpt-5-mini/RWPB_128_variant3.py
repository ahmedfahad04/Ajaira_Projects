
def xywh2xyxy(x):
    import numpy as np
    import torch
    def xywh2xyxy(x):
        if torch.is_tensor(x):
            if x.shape[-1] != 4:
                raise ValueError("Last dimension must be 4")
            xy = x[..., :2]
            wh = x[..., 2:]
            return torch.cat((xy, xy + wh), dim=-1)
        else:
            arr = np.asarray(x)
            if arr.shape[-1] != 4:
                raise ValueError("Last dimension must be 4")
            xy = arr[..., :2]
            wh = arr[..., 2:]
            return np.concatenate((xy, xy + wh), axis=-1)
