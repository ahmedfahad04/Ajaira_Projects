
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return original_size
        ow, oh = original_size
        # Prefer resolutions that fit within original (no upscaling), choose the largest area among those.
        fit_candidates = []
        not_fit = []
        for w, h in possible_resolutions:
            if w <= ow and h <= oh:
                fit_candidates.append((w, h, w * h))
            else:
                not_fit.append((w, h, w * h))
        if fit_candidates:
            # choose largest area; tie-break by aspect ratio closeness
            orig_ratio = ow / oh if oh != 0 else float('inf')
            fit_candidates.sort(key=lambda t: (-t[2], abs((t[0] / t[1] if t[1] != 0 else float('inf')) - orig_ratio)))
            return (fit_candidates[0][0], fit_candidates[0][1])
        else:
            # no fit: choose smallest area to minimize upscaling
            not_fit.sort(key=lambda t: (t[2], abs((t[0] / t[1] if t[1] != 0 else float('inf')) - (ow / oh if oh != 0 else float('inf')))))
            return (not_fit[0][0], not_fit[0][1])
