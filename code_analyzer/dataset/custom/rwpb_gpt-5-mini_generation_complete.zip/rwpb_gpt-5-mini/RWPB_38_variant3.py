
def extract_imports_from_lines(lines: List[str]) -> str:
    from typing import List
    import ast
    def _alias_str(alias):
        if alias.asname:
            return f"{alias.name} as {alias.asname}"
        return alias.name
    def extract_imports_from_lines(lines: List[str]) -> str:
        """
        AST-based extractor: parse the source and reconstruct import/from-import statements.
        This returns normalized import lines (not preserving original spacing).
        """
        src = ''.join(line if line.endswith('\n') else line + '\n' for line in lines)
        try:
            tree = ast.parse(src)
        except Exception:
            # Fallback: if parsing fails, return nothing
            return ''
        imports = []
        for node in tree.body:
            if isinstance(node, ast.Import):
                parts = ', '.join(_alias_str(a) for a in node.names)
                imports.append((node.lineno, f"import {parts}"))
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ''
                dots = '.' * node.level if node.level else ''
                parts = ', '.join(_alias_str(a) for a in node.names)
                imports.append((node.lineno, f"from {dots}{module} import {parts}"))
        imports.sort(key=lambda x: x[0])
        return '\n'.join(line for _, line in imports)
