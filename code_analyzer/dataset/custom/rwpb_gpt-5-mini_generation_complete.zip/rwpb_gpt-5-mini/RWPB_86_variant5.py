
def inverse_sigmoid(x):
    import torch
    def inverse_sigmoid(x):
        x = torch.as_tensor(x)
        if not x.is_floating_point():
            x = x.float()
        eps = 1e-9
        x = x.clamp(eps, 1 - eps)
        return -torch.log((1.0 / x) - 1.0)
