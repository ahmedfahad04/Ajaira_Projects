
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        orig_x = x
        orig_dtype = x.dtype
        if upcast:
            x = x.to(torch.float32)
            weight = weight.to(torch.float32)
            if bias is not None:
                bias = bias.to(torch.float32)
            if residual is not None:
                residual = residual.to(torch.float32)
        # compute mean of squares along last dim
        mean_sq = (x * x).mean(dim=-1, keepdim=True)
        inv_rms = torch.rsqrt(mean_sq + eps)
        # prepare weight/bias to broadcast over leading dims
        shape = [1] * (x.dim() - 1) + [-1]
        w = weight.view(*shape)
        out = x * inv_rms
        out = out * w
        if bias is not None:
            b = bias.view(*shape)
            out = out + b
        if residual is not None:
            out = out + residual
        if upcast:
            out = out.to(orig_dtype)
        if prenorm:
            return out, orig_x
        return out
