
def arccos2(vector, value):
    import math
    import cmath
    def arccos2(vector, value):
        try:
            x = float(vector[0])
            y = float(vector[1])
        except Exception:
            x = 0.0
            y = 0.0
        if value != value:
            return float('nan')
        val = value
        if val > 1.0:
            val = 1.0
        elif val < -1.0:
            val = -1.0
        angle = math.acos(val)
        phase = cmath.phase(complex(x, y))
        if phase < 0:
            return -angle
        return angle
