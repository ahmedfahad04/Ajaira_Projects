
def merge_short_sentences_en(sens):
    def merge_short_sentences_en(sens):
        """Use a deque-style processing. Merge any sentence with fewer than threshold tokens into the following
        sentence; if it's the last element, merge into the previous output sentence.
        """
        if not sens:
            return []
        from collections import deque
        dq = deque(s.strip() for s in sens)
        out = []
        THRESH = 4
        while dq:
            s = dq.popleft()
            if len(s.split()) < THRESH:
                if dq:
                    nxt = dq.popleft()
                    # Avoid duplicate punctuation when joining
                    s_join = s.rstrip()
                    if s_join and s_join[-1] in '.!?':
                        s_join = s_join[:-1].rstrip()
                    # if next starts capitalized, lowercase it to flow
                    nxt_str = nxt
                    if nxt_str and nxt_str[0].isupper():
                        nxt_str = nxt_str[0].lower() + nxt_str[1:]
                    merged = (s_join + ' ' + nxt_str).strip()
                    # Put merged back to front to possibly merge further
                    dq.appendleft(merged)
                else:
                    # last short sentence: attach to previous output if any
                    if out:
                        out[-1] = out[-1].rstrip() + ' ' + s
                    else:
                        out.append(s)
            else:
                out.append(s)
        return out
