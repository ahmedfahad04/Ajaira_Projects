
def apply_colormap(:
    import torch
    from matplotlib import cm
    from torchtyping import TensorType
    from typing import Any
    def apply_colormap(
        image: TensorType["bs":..., 1],
        cmap="viridis",
    ) -> TensorType["bs":..., "rgb":3]:
        if not isinstance(image, torch.Tensor):
            image = torch.tensor(image)
        device = image.device
        # require float for normalization
        img = image.detach().to(torch.float32)
        if img.shape[-1] != 1:
            raise ValueError("Expected last dimension to be channel=1")
        # build palette of 256 entries on CPU
        cmap_obj = cm.get_cmap(cmap, 256)
        palette = torch.from_numpy((cmap_obj(np.linspace(0.0, 1.0, 256))[:, :3].astype("float32")))
        # global min/max normalization
        vals = img[..., 0]
        vmin = float(vals.min().cpu().item())
        vmax = float(vals.max().cpu().item())
        if vmin == vmax:
            indices = torch.zeros_like(vals, dtype=torch.long, device=device)
        else:
            norm = (vals - vmin) / (vmax - vmin)
            norm = torch.clamp(norm, 0.0, 1.0)
            indices = (norm * 255.0).round().to(torch.long).to(device)
        # move palette to same device
        palette = palette.to(device=device)
        # index palette
        rgb = palette[indices.view(-1)].view(list(vals.shape) + [3])
        # ensure dtype matches input float type (promote to float32)
        return rgb.to(dtype=torch.float32)
