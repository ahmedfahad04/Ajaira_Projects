
def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
    import torch
    def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
        if num <= 0:
            return torch.empty(*torch.broadcast_shapes(start.shape, stop.shape), 0, device=start.device, dtype=torch.promote_types(start.dtype, stop.dtype))
        dtype = torch.promote_types(start.dtype, stop.dtype)
        start = start.to(dtype)
        stop = stop.to(dtype)
        device = start.device
        if num == 1:
            return start.unsqueeze(-1)
        # Use torch.lerp which linearly interpolates: lerp(start, end, weight)
        weights = torch.linspace(0.0, 1.0, steps=num, dtype=dtype, device=device)
        nd = max(start.dim(), stop.dim())
        if nd > 0:
            weights = weights.view((1,)*nd + (num,))
        # Ensure start and stop broadcast last dim by having a trailing singleton if necessary
        return torch.lerp(start, stop, weights)
