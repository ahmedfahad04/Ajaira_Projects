
def check(x, checksum_token):
    import re
    import hashlib
    def check(x, checksum_token):
        pattern = re.compile(r'(?:(?:sha256|checksum)\s*[:=]\s*([0-9A-Fa-f]{64}))')
        m = pattern.search(x)
        if m:
            orig = m.group(1)
            start, end = m.start(1), m.end(1)
        else:
            m2 = re.search(r'[0-9A-Fa-f]{64}', x)
            if not m2:
                return False
            orig = m2.group(0)
            start, end = m2.start(), m2.end()
        replaced = x[:start] + checksum_token + x[end:]
        digest = hashlib.sha256(replaced.encode()).hexdigest()
        return digest.lower() == orig.lower()
