
def rotate_x(a, device=None):
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        # Use numpy for trig then convert to torch
        if isinstance(a, torch.Tensor):
            a_val = a.item()
        else:
            a_val = float(a)
        c = np.cos(a_val)
        s = np.sin(a_val)
        mat = np.array([
            [1.0, 0.0, 0.0, 0.0],
            [0.0, c,   -s,  0.0],
            [0.0, s,    c,  0.0],
            [0.0, 0.0, 0.0, 1.0]
        ], dtype=np.float64)
        t = torch.from_numpy(mat)
        if device is not None:
            t = t.to(device)
        return t
