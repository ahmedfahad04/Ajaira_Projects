
def dynamic_import_function(function_path):
    def dynamic_import_function(function_path):
        from importlib import import_module
        if not isinstance(function_path, str):
            return ModuleNotFoundError("path must be a string")
        tokens = function_path.split('.')
        if len(tokens) < 2:
            return ModuleNotFoundError(f"Bad path: {function_path}")
        left = len(tokens) - 1
        while left > 0:
            module_name = '.'.join(tokens[:left])
            attrs = tokens[left:]
            try:
                module = import_module(module_name)
            except Exception:
                left -= 1
                continue
            target = module
            success = True
            for a in attrs:
                try:
                    target = getattr(target, a)
                except Exception:
                    success = False
                    break
            if success:
                return target
            left -= 1
        return ModuleNotFoundError(f"Unable to import function from '{function_path}'")
