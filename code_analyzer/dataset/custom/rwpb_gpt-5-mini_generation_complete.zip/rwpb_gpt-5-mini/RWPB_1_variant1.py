
def apply_colormap(:
    import torch
    import numpy as np
    from matplotlib import cm
    from typing import Any
    from torchtyping import TensorType
    def apply_colormap(
        image: TensorType["bs":..., 1],
        cmap="viridis",
    ) -> TensorType["bs":..., "rgb":3]:
        # Convert to tensor and move to CPU for matplotlib
        if not isinstance(image, torch.Tensor):
            image = torch.tensor(image)
        device = image.device
        dtype = image.dtype if torch.is_floating_point(image) else torch.float32
        img = image.detach().to(torch.float32).cpu().numpy()
        if img.shape[-1] != 1:
            raise ValueError("Expected last dimension to be channel=1")
        flat = img[..., 0].ravel()
        # global normalization
        vmin = flat.min() if flat.size > 0 else 0.0
        vmax = flat.max() if flat.size > 0 else 1.0
        if vmin == vmax:
            normed = np.zeros_like(flat, dtype=np.float32)
        else:
            normed = (flat - vmin) / (vmax - vmin)
            normed = np.clip(normed, 0.0, 1.0).astype(np.float32)
        cmap_fn = cm.get_cmap(cmap)
        rgba = cmap_fn(normed)[:, :3]  # Nx3
        out_shape = list(img.shape[:-1]) + [3]
        rgb = rgba.reshape(out_shape).astype(np.float32)
        t = torch.from_numpy(rgb).to(device=device, dtype=dtype)
        return t
