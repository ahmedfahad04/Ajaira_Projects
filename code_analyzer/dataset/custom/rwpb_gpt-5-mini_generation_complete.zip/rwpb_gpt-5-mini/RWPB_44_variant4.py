
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        if tensor1.shape[0] != tensor2.shape[0]:
            raise ValueError("First dimension sizes must match")
        N = tensor1.shape[0]
        rest = tensor1.shape[1:]
        stacked = torch.stack((tensor1, tensor2), dim=1)
        idx = torch.arange(2 * N, device=stacked.device)
        base = idx // 2
        parity = idx % 2
        out1 = stacked[base, parity].reshape(-1, *rest)
        out2 = stacked[base, 1 - parity].reshape(-1, *rest)
        return out1, out2
