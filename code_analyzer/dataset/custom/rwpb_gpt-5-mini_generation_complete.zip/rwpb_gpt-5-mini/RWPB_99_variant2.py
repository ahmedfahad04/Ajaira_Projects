
def focal2fov(focal, pixels):
    import math
    def focal2fov(focal, pixels):
        try:
            f = float(focal)
            p = float(pixels)
            # This will raise ZeroDivisionError if f == 0.0
            return 2.0 * math.atan(p / (2.0 * f))
        except ZeroDivisionError:
            return KeyError
