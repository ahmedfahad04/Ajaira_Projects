
def format_ratio(ratio):
    def format_ratio(ratio):
        try:
            r = float(ratio)
        except Exception:
            r = 0.0
        # int() truncates toward zero
        truncated = int(r * 1000) / 1000.0
        # ensure three decimal places
        return "percentage:" + ("{:.3f}".format(truncated))
