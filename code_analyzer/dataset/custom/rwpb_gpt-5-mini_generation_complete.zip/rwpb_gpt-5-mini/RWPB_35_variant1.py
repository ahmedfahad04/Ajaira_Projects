
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        result = {}
        for key, value in d.items():
            k = str(key)
            new_key = k if parent_key == "" else parent_key + sep + k
            if isinstance(value, dict):
                if value:
                    result.update(flatten_dict(value, new_key, sep=sep))
                # skip empty dicts (no leaf value)
            else:
                result[new_key] = value
        return result
