
def format_seconds(seconds: float) -> str:
    def format_seconds(seconds: float) -> str:
        if not isinstance(seconds, (int, float)):
            raise TypeError("seconds must be a number")
        if not (seconds == seconds) or seconds == float('inf') or seconds == float('-inf'):
            raise ValueError("seconds must be a finite number")
        neg = seconds < 0
        s = abs(seconds)
        hours = int(s // 3600)
        s = s - hours * 3600
        minutes = int(s // 60)
        s = s - minutes * 60
        # Use formatted string for seconds then detect rollover (e.g., 59.9996 -> 60.000)
        sec_str = f"{s:06.3f}"  # ensures at least 2 digits before decimal and 3 decimals
        if sec_str.startswith("60."):
            # handle carry to minutes
            sec_str = "00.000"
            minutes += 1
            if minutes >= 60:
                minutes -= 60
                hours += 1
        sign = "-" if neg else ""
        if hours >= 1:
            return f"{sign}{hours:02d}:{minutes:02d}:{sec_str}"
        else:
            return f"{sign}{minutes:02d}:{sec_str}"
