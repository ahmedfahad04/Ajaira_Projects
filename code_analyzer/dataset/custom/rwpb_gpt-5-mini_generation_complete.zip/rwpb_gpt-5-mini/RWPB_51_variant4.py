
def _ssim(img1, img2, window, window_size, channel, size_average=True):
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        if img1.shape != img2.shape:
            raise ValueError("Input images must have the same dimensions.")
        if img1.dim() == 3:
            img1 = img1.unsqueeze(0)
            img2 = img2.unsqueeze(0)
        N, C, H, W = img1.shape
        assert C == channel
        pad = window_size // 2
        # Build a depthwise Conv2d module to reuse for all convs
        conv = nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=window_size, groups=channel, bias=False)
        # set weights
        with torch.no_grad():
            w = window.view(1,1,window_size,window_size).to(img1.device, dtype=img1.dtype)
            w = w.repeat(channel, 1, 1, 1)
            conv.weight.data = w
        conv = conv.to(img1.device, dtype=img1.dtype)
        mu1 = conv(F.pad(img1, (pad,pad,pad,pad)))
        mu2 = conv(F.pad(img2, (pad,pad,pad,pad)))
        mu1_sq = mu1 * mu1
        mu2_sq = mu2 * mu2
        mu1_mu2 = mu1 * mu2
        sigma1_sq = conv(F.pad(img1 * img1, (pad,pad,pad,pad))) - mu1_sq
        sigma2_sq = conv(F.pad(img2 * img2, (pad,pad,pad,pad))) - mu2_sq
        sigma12 = conv(F.pad(img1 * img2, (pad,pad,pad,pad))) - mu1_mu2
        C1 = (0.01) ** 2
        C2 = (0.03) ** 2
        num = (2 * mu1_mu2 + C1) * (2 * sigma12 + C2)
        den = (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)
        ssim_map = num / (den + 1e-12)
        if size_average:
            return ssim_map.mean()
        else:
            return ssim_map.view(N, C, -1).mean(dim=0).mean(dim=1)
