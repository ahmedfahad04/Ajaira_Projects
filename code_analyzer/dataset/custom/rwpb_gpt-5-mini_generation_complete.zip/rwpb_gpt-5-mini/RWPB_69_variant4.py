
def fovx_to_fovy(fovx, aspect):
    import math
    def fovx_to_fovy(fovx, aspect):
        sh = math.sin(0.5 * fovx)
        ch = math.cos(0.5 * fovx)
        return 2.0 * math.atan2(sh, aspect * ch)
