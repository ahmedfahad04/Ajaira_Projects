
def fovx_to_fovy(fovx, aspect):
    import math
    def fovx_to_fovy(fovx, aspect):
        if aspect == 0:
            raise ZeroDivisionError("aspect must be non-zero")
        tan_half = math.tan(fovx * 0.5)
        return 2.0 * math.atan2(tan_half, aspect)
