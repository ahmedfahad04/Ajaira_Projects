
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        arr = np.asarray(arr, dtype=float).ravel()
        n = arr.size
        if window_size <= 0:
            raise ValueError("window_size must be positive")
        if n == 0:
            return np.array([]), np.array([])
        k = window_size
        # Valid moving average (no padding). If window is larger than array, return empty arrays.
        if k > n:
            return np.array([]), np.array([])
        sums = np.convolve(arr, np.ones(k, dtype=float), mode='valid')
        moving = sums / float(k)
        # Residuals aligned to the end of each window: arr[k-1:] - moving
        residuals = arr[k-1:] - moving
        return np.asarray(moving), np.asarray(residuals)
