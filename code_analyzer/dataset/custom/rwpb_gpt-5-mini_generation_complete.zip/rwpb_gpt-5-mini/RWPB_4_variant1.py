
def rot6d_to_rotmat(x):
    import torch
    import torch.nn.functional as F
    import numpy as np
    def rot6d_to_rotmat(x):
        if isinstance(x, np.ndarray):
            x = torch.from_numpy(x)
        if not isinstance(x, torch.Tensor):
            raise ValueError("Input must be a torch.Tensor or numpy.ndarray")
        if x.dim() != 2 or x.shape[1] != 6:
            raise ValueError("Input must have shape (B,6)")
        a1 = x[:, 0:3].to(dtype=torch.float32)
        a2 = x[:, 3:6].to(dtype=torch.float32)
        b1 = F.normalize(a1, p=2, dim=1, eps=1e-8)
        # subtract projection of a2 onto b1
        proj = (b1 * a2).sum(dim=1, keepdim=True) * b1
        b2 = a2 - proj
        b2 = F.normalize(b2, p=2, dim=1, eps=1e-8)
        b3 = torch.cross(b1, b2, dim=1)
        # stack as columns -> shape (B,3,3)
        R = torch.stack((b1, b2, b3), dim=2)
        return R
