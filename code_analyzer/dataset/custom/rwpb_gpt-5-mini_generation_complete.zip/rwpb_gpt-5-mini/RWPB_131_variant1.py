
def box_iou(box1, box2, eps=1e-7):
    import torch
    import numpy as np
    def box_iou(box1, box2, eps=1e-7):
        if box1.numel() == 0 or box2.numel() == 0:
            return torch.zeros((box1.shape[0], box2.shape[0]), dtype=box1.dtype, device=box1.device)
        x1 = torch.max(box1[:, None, 0], box2[None, :, 0])
        y1 = torch.max(box1[:, None, 1], box2[None, :, 1])
        x2 = torch.min(box1[:, None, 2], box2[None, :, 2])
        y2 = torch.min(box1[:, None, 3], box2[None, :, 3])
        inter_w = (x2 - x1).clamp(min=0)
        inter_h = (y2 - y1).clamp(min=0)
        inter = inter_w * inter_h
        area1 = (box1[:, 2] - box1[:, 0]).clamp(min=0) * (box1[:, 3] - box1[:, 1]).clamp(min=0)
        area2 = (box2[:, 2] - box2[:, 0]).clamp(min=0) * (box2[:, 3] - box2[:, 1]).clamp(min=0)
        union = area1[:, None] + area2[None, :] - inter
        return inter / (union + eps)
