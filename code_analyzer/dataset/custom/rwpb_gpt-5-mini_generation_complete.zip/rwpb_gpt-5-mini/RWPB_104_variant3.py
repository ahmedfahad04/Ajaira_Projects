
def mulMod(x, y, z):
    def mulMod(x, y, z):
        if z == 0:
            raise ValueError("modulus must be non-zero")
        x %= z
        y %= z
        if x == 0 or y == 0:
            return 0
        mask = (1 << 128) - 1
        a0 = x & mask
        a1 = x >> 128
        b0 = y & mask
        b1 = y >> 128
        pow128 = pow(2, 128, z)
        pow256 = pow(pow128, 2, z)
        part0 = (a0 * b0) % z
        part1 = ((a1 * b0 + a0 * b1) % z) * pow128 % z
        part2 = (a1 * b1) % z * pow256 % z
        return (part0 + part1 + part2) % z
