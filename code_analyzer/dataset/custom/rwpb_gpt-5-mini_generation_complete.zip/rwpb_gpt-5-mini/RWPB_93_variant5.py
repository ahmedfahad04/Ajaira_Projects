
def unsafeSub(x, y):
    MOD = 1 << 256
    def unsafeSub(x, y):
        ax = (x % MOD).to_bytes(32, 'big')
        ay = (y % MOD).to_bytes(32, 'big')
        ai = int.from_bytes(ax, 'big')
        bi = int.from_bytes(ay, 'big')
        return (ai - bi) % MOD
