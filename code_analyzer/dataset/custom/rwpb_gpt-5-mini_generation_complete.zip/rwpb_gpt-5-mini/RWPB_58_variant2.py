
def unpad_image_shape(current_height, current_width, original_size):
    def unpad_image_shape(current_height, current_width, original_size):
        orig_w, orig_h = original_size
        if orig_w <= 0 or orig_h <= 0:
            return (current_height, current_width)
        # compare aspect ratios without floating point precision issues
        # orig_ratio > current_ratio  <=> orig_w * current_height > current_width * orig_h
        left = orig_w * current_height
        right = current_width * orig_h
        if left > right:
            # width was scaled to fit current_width
            new_w = current_width
            new_h = int(round(orig_h * (current_width / orig_w)))
        elif left < right:
            # height was scaled to fit current_height
            new_h = current_height
            new_w = int(round(orig_w * (current_height / orig_h)))
        else:
            # exact match
            new_w = current_width
            new_h = current_height
        # clamp to valid range
        new_w = max(1, min(new_w, current_width))
        new_h = max(1, min(new_h, current_height))
        return (new_h, new_w)
