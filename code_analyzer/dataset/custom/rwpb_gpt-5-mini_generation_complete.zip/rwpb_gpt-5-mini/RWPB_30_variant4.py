
def get_confusion_matrix(gt_label, pred_label, num_classes):
    import numpy as np
    def get_confusion_matrix(gt_label, pred_label, num_classes):
        gt = np.asarray(gt_label).ravel()
        pred = np.asarray(pred_label).ravel()
        if gt.shape != pred.shape:
            raise ValueError("gt_label and pred_label must have the same length")
        if num_classes <= 0:
            return np.zeros((0, 0), dtype=np.int64)
        valid = (gt >= 0) & (gt < num_classes) & (pred >= 0) & (pred < num_classes)
        if not valid.any():
            return np.zeros((num_classes, num_classes), dtype=np.int64)
        H, xedges, yedges = np.histogram2d(gt[valid], pred[valid], bins=[num_classes, num_classes], range=[[0, num_classes], [0, num_classes]])
        return H.astype(np.int64)
