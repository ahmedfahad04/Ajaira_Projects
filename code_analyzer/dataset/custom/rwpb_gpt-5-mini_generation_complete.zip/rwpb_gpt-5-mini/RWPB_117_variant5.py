
def path_spliter(path: str):
    import os
    import re
    def path_spliter(path: str):
        if path is None:
            return []
        s = str(path)
        if s == '':
            return []
        drive, rest = os.path.splitdrive(s)
        # Normalize separators to forward slash for easier recursion
        tmp = re.sub(r'[\\/]+', '/', rest)
        def _rec(r):
            if r == '':
                return []
            head, tail = os.path.split(r)
            if tail == '':
                # head might be '/' or '' or 'some'
                return [head] if head else []
            else:
                res = _rec(head)
                res.append(tail)
                return res
        parts = _rec(tmp)
        # Convert single '/' back to os.sep
        parts = [p if p != '/' else os.sep for p in parts]
        # Remove any empty strings
        parts = [p for p in parts if p != '']
        if drive:
            # If first part is root sep, combine with drive
            if parts and parts[0] == os.sep:
                parts[0] = drive + parts[0]
            else:
                parts.insert(0, drive)
        return parts
