
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    from itertools import chain, repeat
    def pad_to_max_seq_length(ls: list, max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be a non-negative integer")
        cur_len = len(ls)
        if cur_len > max_seq_length:
            if check:
                raise ValueError("Result length would exceed max_seq_length")
            # if not checking, return the original truncated to max_seq_length
            return list(ls[:max_seq_length])
        if cur_len == max_seq_length:
            return list(ls)
        pad_count = max_seq_length - cur_len
        pad_iter = repeat(pad_idx, pad_count)
        if pad_right:
            return list(chain(ls, pad_iter))
        else:
            return list(chain(pad_iter, ls))
