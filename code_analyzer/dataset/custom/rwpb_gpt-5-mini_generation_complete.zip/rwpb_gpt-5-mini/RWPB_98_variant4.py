
def exp_smooth(vals, alpha):
    import numpy as np
    from functools import reduce
    def exp_smooth(vals, alpha):
        arr = np.asarray(vals, dtype=float)
        if arr.size == 0:
            raise KeyError("Input array is empty")
        if arr.size == 1:
            return arr.copy()
        res = reduce(lambda acc, x: acc + [alpha * x + (1.0 - alpha) * acc[-1]], arr[1:], [arr[0]])
        return np.array(res, dtype=float)
