
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        n = tensor.shape[0]
        if n == batch_size:
            return tensor
        device = tensor.device
        dtype = tensor.dtype
        if n == 0:
            raise ValueError("tensor has zero batch dimension")
        # Iterative up/down sampling using midpoint insertion/averaging then final linear resample
        def insert_midpoints(x):
            # x shape (N, ...)
            N = x.shape[0]
            if N == 1:
                return x.repeat(2, *([1] * (x.dim() - 1)))
            left = x[:-1]
            right = x[1:]
            mids = (left.to(torch.float32) + right.to(torch.float32)) / 2.0
            parts = []
            for i in range(N - 1):
                parts.append(left[i].unsqueeze(0))
                parts.append(mids[i].unsqueeze(0))
            parts.append(x[-1].unsqueeze(0))
            return torch.cat(parts, dim=0).to(dtype)
        def average_pairs(x):
            N = x.shape[0]
            if N <= 1:
                return x
            pairs = []
            i = 0
            while i + 1 < N:
                avg = (x[i].to(torch.float32) + x[i+1].to(torch.float32)) / 2.0
                pairs.append(avg.unsqueeze(0))
                i += 2
            if i < N:
                pairs.append(x[-1].unsqueeze(0))
            return torch.cat(pairs, dim=0).to(dtype)
        current = tensor
        # Grow until at least batch_size (if we need to increase)
        if batch_size > n:
            while current.shape[0] < batch_size:
                current = insert_midpoints(current)
                if current.shape[0] >= batch_size:
                    break
            # final linear resample to exact size
            positions = torch.linspace(0, current.shape[0] - 1, steps=batch_size, device=device)
            floor_idx = positions.floor().long().clamp(min=0, max=current.shape[0] - 1)
            ceil_idx = positions.ceil().long().clamp(min=0, max=current.shape[0] - 1)
            weights = (positions - floor_idx.to(device)).to(dtype)
            front = current[floor_idx].to(dtype)
            back = current[ceil_idx].to(dtype)
            shape = [batch_size] + [1] * (tensor.dim() - 1)
            w = weights.view(*shape)
            out = front * (1 - w) + back * w
            return out.to(dtype).to(device)
        else:
            # Shrink by averaging pairs until <= desired, then final linear
            while current.shape[0] > batch_size:
                next_c = average_pairs(current)
                if next_c.shape[0] == current.shape[0]:
                    # can't reduce further by pairing -> break
                    break
                current = next_c
                if current.shape[0] <= batch_size:
                    break
            positions = torch.linspace(0, current.shape[0] - 1, steps=batch_size, device=device)
            floor_idx = positions.floor().long().clamp(min=0, max=current.shape[0] - 1)
            ceil_idx = positions.ceil().long().clamp(min=0, max=current.shape[0] - 1)
            weights = (positions - floor_idx.to(device)).to(dtype)
            front = current[floor_idx].to(dtype)
            back = current[ceil_idx].to(dtype)
            shape = [batch_size] + [1] * (tensor.dim() - 1)
            w = weights.view(*shape)
            out = front * (1 - w) + back * w
            return out.to(dtype).to(device)
