
def extract_code_from_funct(funct: Callable) -> List[str]:
    from typing import Callable, List
    import inspect
    import textwrap
    def extract_code_from_funct(funct: Callable) -> List[str]:
        src = inspect.getsource(funct)
        lines = src.splitlines(keepends=False)
        # find the line that starts the function definition (skip decorators)
        def_index = None
        for i, ln in enumerate(lines):
            if ln.lstrip().startswith("def ") or ln.lstrip().startswith("async def "):
                def_index = i
                break
        if def_index is None:
            return []
        # determine end of signature (handle multi-line signatures by tracking parentheses)
        sig_end = def_index
        paren = 0
        while sig_end < len(lines):
            line = lines[sig_end]
            paren += line.count("(") - line.count(")")
            if line.rstrip().endswith(":") and paren <= 0:
                break
            sig_end += 1
        body_lines = lines[sig_end+1:]
        if not body_lines:
            return []
        body_src = "\n".join(body_lines)
        dedented = textwrap.dedent(body_src).splitlines()
        # strip leading/trailing blank lines
        while dedented and dedented[0].strip() == "":
            dedented.pop(0)
        while dedented and dedented[-1].strip() == "":
            dedented.pop()
        # remove trailing return if present
        if dedented:
            last = dedented[-1].lstrip()
            if last.startswith("return") and (last == "return" or last[6:7] == " " or last[6:7] == "(" or last[6:7] == ""):
                dedented.pop()
                # remove possible trailing blank lines again
                while dedented and dedented[-1].strip() == "":
                    dedented.pop()
        return dedented
