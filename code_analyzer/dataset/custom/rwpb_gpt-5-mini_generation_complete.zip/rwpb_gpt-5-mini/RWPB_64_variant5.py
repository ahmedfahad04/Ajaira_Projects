
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        arr = np.asarray(arr, dtype=float).ravel()
        n = arr.size
        if window_size <= 0:
            raise ValueError("window_size must be positive")
        if n == 0:
            return np.array([]), np.array([])
        k = window_size
        # Use sliding_window_view when available to compute valid windows efficiently
        try:
            from numpy.lib.stride_tricks import sliding_window_view
            if k > n:
                return np.array([]), np.array([])
            windows = sliding_window_view(arr, window_shape=k)
            moving = windows.mean(axis=1)
            residuals = arr[k-1:] - moving
            return moving, residuals
        except Exception:
            # Fallback: simple list comprehension for valid windows
            if k > n:
                return np.array([]), np.array([])
            moving = np.array([arr[i:i+k].mean() for i in range(n - k + 1)], dtype=float)
            residuals = arr[k-1:] - moving
            return moving, residuals
