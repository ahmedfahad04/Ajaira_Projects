
def _ssim(img1, img2, window, window_size, channel, size_average=True):
    import torch
    import torch.nn.functional as F
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        if img1.shape != img2.shape:
            raise ValueError("Input images must have the same dimensions.")
        # normalize dims
        added_batch = False
        if img1.dim() == 3:
            img1 = img1.unsqueeze(0)
            img2 = img2.unsqueeze(0)
            added_batch = True
        N, C, H, W = img1.shape
        assert C == channel
        pad = window_size // 2
        # Use unfold (im2col) to compute local statistics
        if window.dim() == 4:
            kernel = window.view(-1)
        else:
            kernel = window.view(-1)
        kernel = kernel.to(img1.device, dtype=img1.dtype)
        # unfold returns patches flattened: (N, C*ws*ws, L) where L=H*W
        patches1 = F.unfold(F.pad(img1, (pad, pad, pad, pad)), kernel_size=window_size)
        patches2 = F.unfold(F.pad(img2, (pad, pad, pad, pad)), kernel_size=window_size)
        # reshape to (N, C, ws*ws, H*W)
        patches1 = patches1.view(N, C, window_size*window_size, H*W)
        patches2 = patches2.view(N, C, window_size*window_size, H*W)
        # apply kernel weights
        kernel = kernel.view(1,1,window_size*window_size,1)
        mu1 = (patches1 * kernel).sum(dim=2).view(N, C, H, W)
        mu2 = (patches2 * kernel).sum(dim=2).view(N, C, H, W)
        mu1_sq = mu1 * mu1
        mu2_sq = mu2 * mu2
        mu1_mu2 = mu1 * mu2
        # variances
        sigma1_sq = ((patches1 * patches1) * kernel).sum(dim=2).view(N, C, H, W) - mu1_sq
        sigma2_sq = ((patches2 * patches2) * kernel).sum(dim=2).view(N, C, H, W) - mu2_sq
        sigma12 = ((patches1 * patches2) * kernel).sum(dim=2).view(N, C, H, W) - mu1_mu2
        C1 = (0.01) ** 2
        C2 = (0.03) ** 2
        num = (2 * mu1_mu2 + C1) * (2 * sigma12 + C2)
        den = (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)
        ssim_map = num / (den + 1e-12)
        if size_average:
            return ssim_map.mean()
        else:
            return ssim_map.view(N, C, -1).mean(dim=0).mean(dim=1)
