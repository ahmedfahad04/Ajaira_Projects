
def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        x_orig = x
        if upcast:
            dtype = torch.float32
            x = x.to(dtype)
            if weight is not None:
                weight = weight.to(dtype)
            if bias is not None:
                bias = bias.to(dtype)
            if residual is not None:
                residual = residual.to(dtype)
        keepdim = True
        mean = x.mean(dim=-1, keepdim=keepdim)
        xm = x - mean
        var = (xm * xm).mean(dim=-1, keepdim=keepdim)
        denom = torch.sqrt(var + eps)
        normalized = xm / denom
        if weight is not None:
            w = weight
            if w.dim() == 1:
                w = w.view(*([1] * (x.dim() - 1)), -1)
            normalized = normalized * w
        if bias is not None:
            b = bias
            if b.dim() == 1:
                b = b.view(*([1] * (x.dim() - 1)), -1)
            normalized = normalized + b
        if residual is not None:
            normalized = normalized + residual
        if upcast:
            normalized = normalized.to(x_orig.dtype)
        if prenorm:
            return normalized, x_orig
        return normalized
