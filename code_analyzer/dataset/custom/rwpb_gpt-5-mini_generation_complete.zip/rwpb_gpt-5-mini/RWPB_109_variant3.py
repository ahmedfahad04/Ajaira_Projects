
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        # Ensure tensors
        geometry = geometry if isinstance(geometry, torch.Tensor) else torch.tensor(geometry)
        rot = rot if isinstance(rot, torch.Tensor) else torch.tensor(rot)
        trans = trans if isinstance(trans, torch.Tensor) else torch.tensor(trans)
        B, N, C = geometry.shape
        if C != 3:
            raise ValueError("Last dimension of geometry must be 3")
        # Expand rot and trans to batch if needed
        if rot.dim() == 2:
            rot = rot.unsqueeze(0).expand(B, -1, -1)
        if trans.dim() == 1:
            trans = trans.unsqueeze(0).expand(B, -1)
        # Use batch matrix multiplication by transposing geometry to [B,3,N]
        geom_t = geometry.transpose(1, 2)  # [B,3,N]
        rotated_t = torch.bmm(rot, geom_t)  # [B,3,N]
        rotated = rotated_t.transpose(1, 2)  # [B,N,3]
        return rotated + trans.unsqueeze(1)
