
def box_iou(box1, box2, eps=1e-7):
    import torch
    import numpy as np
    def box_iou(box1, box2, eps=1e-7):
        if box1.numel() == 0 or box2.numel() == 0:
            return torch.zeros((box1.shape[0], box2.shape[0]), dtype=box1.dtype, device=box1.device)
        cpu1 = box1.detach().cpu().numpy()
        cpu2 = box2.detach().cpu().numpy()
        x1 = np.maximum(cpu1[:, None, 0], cpu2[None, :, 0])
        y1 = np.maximum(cpu1[:, None, 1], cpu2[None, :, 1])
        x2 = np.minimum(cpu1[:, None, 2], cpu2[None, :, 2])
        y2 = np.minimum(cpu1[:, None, 3], cpu2[None, :, 3])
        inter_w = np.clip(x2 - x1, a_min=0, a_max=None)
        inter_h = np.clip(y2 - y1, a_min=0, a_max=None)
        inter = inter_w * inter_h
        area1 = np.clip((cpu1[:, 2] - cpu1[:, 0]), a_min=0, a_max=None) * np.clip((cpu1[:, 3] - cpu1[:, 1]), a_min=0, a_max=None)
        area2 = np.clip((cpu2[:, 2] - cpu2[:, 0]), a_min=0, a_max=None) * np.clip((cpu2[:, 3] - cpu2[:, 1]), a_min=0, a_max=None)
        union = area1[:, None] + area2[None, :] - inter
        iou = inter / (union + eps)
        return torch.from_numpy(iou).to(device=box1.device, dtype=box1.dtype)
