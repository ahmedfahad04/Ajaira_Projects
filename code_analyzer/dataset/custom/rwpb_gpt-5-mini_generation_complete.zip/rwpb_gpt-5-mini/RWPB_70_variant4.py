
def psnr_to_mse(psnr):
    import numpy as np
    def psnr_to_mse(psnr):
        scalar = np.isscalar(psnr)
        arr = np.asarray(psnr, dtype=float)
        res = np.power(10.0, -arr / 10.0)
        if scalar:
            return float(res)
        return res
