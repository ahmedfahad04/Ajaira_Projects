
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        if torch.is_tensor(divisor):
            d = float(divisor.max().item())
        else:
            d = float(divisor)
        if d == 0:
            raise ValueError("divisor must be non-zero")
        d = abs(d)
        q = float(x) / d
        # custom rounding that handles negatives predictably
        if q >= 0:
            n = math.floor(q + 0.5)
        else:
            n = math.ceil(q - 0.5)
        return int(n * d)
