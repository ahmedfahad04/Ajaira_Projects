
def B_batch(x, grid, k=0, extend=True, device="cpu"):
    import torch
    def B_batch(x, grid, k=0, extend=True, device="cpu"):
        x = x.to(device)
        grid = grid.to(device)
        S, N = x.shape
        assert grid.shape[0] == S
        dtype = x.dtype
        outputs = []
        for s in range(S):
            xs = x[s].unsqueeze(0)  # (1,N)
            knots_inner = grid[s]
            if k > 0 and extend:
                knots = torch.cat([knots_inner[0].repeat(k), knots_inner, knots_inner[-1].repeat(k)])
            else:
                knots = knots_inner.clone()
            p = max(k - 1, 0)
            K = knots.numel()
            n_bases = max(K - p - 1, 0)
            if n_bases == 0:
                outputs.append(torch.zeros((0, N), device=device, dtype=dtype))
                continue
            # Use DP with fully-tensorized arithmetic avoiding python loops over samples
            # Build matrix of shape (K-1, N) for zeroth degree
            left = knots[:-1].unsqueeze(1)
            right = knots[1:].unsqueeze(1)
            Nmat = ((xs >= left) & (xs < right)).to(dtype)
            if (xs == right[-1]).any():
                Nmat[-1, xs.squeeze(0) == right[-1]] = 1.0
            # Precompute denominators in a tensor for all i and d
            for d in range(1, p + 1):
                rows = K - d - 1
                A = torch.zeros((rows, N), device=device, dtype=dtype)
                i_idx = torch.arange(rows, device=device)
                denom1 = (knots[i_idx + d] - knots[i_idx]).unsqueeze(1)
                denom2 = (knots[i_idx + d + 1] - knots[i_idx + 1]).unsqueeze(1)
                # compute left part in vectorized manner
                # avoid division by zero
                mask1 = denom1 != 0
                if mask1.any():
                    left_num = (xs - knots[i_idx].unsqueeze(1))
                    left_part = torch.zeros_like(A)
                    left_part[mask1.squeeze(1)] = (left_num[mask1.squeeze(1)] / denom1[mask1]).squeeze(0) * Nmat[:rows][mask1.squeeze(1)]
                    A += left_part
                mask2 = denom2 != 0
                if mask2.any():
                    right_num = (knots[i_idx + d + 1].unsqueeze(1) - xs)
                    right_part = torch.zeros_like(A)
                    right_part[mask2.squeeze(1)] = (right_num[mask2.squeeze(1)] / denom2[mask2]).squeeze(0) * Nmat[1:rows+1][mask2.squeeze(1)]
                    A += right_part
                Nmat = A
            outputs.append(Nmat[:n_bases])
        max_b = max((o.shape[0] for o in outputs), default=0)
        out = torch.zeros((S, max_b, N), device=device, dtype=dtype)
        for s in range(S):
            nb = outputs[s].shape[0]
            if nb > 0:
                out[s, :nb, :] = outputs[s]
        return out
