
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float).ravel()
        b = np.asarray(b, dtype=float).ravel()
        eps = 1e-12
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na < eps or nb < eps:
            return None, None
        ua = a / na
        ub = b / nb
        # compute robust angle using atan2(norm(cross), dot)
        cross = np.cross(ua, ub)
        cross_norm = np.linalg.norm(cross)
        dot = np.dot(ua, ub)
        dot = float(np.clip(dot, -1.0, 1.0))
        if cross_norm < eps:
            # either same or opposite
            if dot > 0.9999999999:
                return None, None
            else:
                # opposite: construct axis via Gram-Schmidt: take any vector not collinear and orthogonalize
                if abs(ua[0]) < 0.6:
                    candidate = np.array([1.0, 0.0, 0.0])
                else:
                    candidate = np.array([0.0, 1.0, 0.0])
                axis = candidate - ua * np.dot(candidate, ua)
                axis_norm = np.linalg.norm(axis)
                if axis_norm < eps:
                    # fallback
                    axis = np.array([0.0, 0.0, 1.0])
                else:
                    axis = axis / axis_norm
                return axis, np.pi
        else:
            axis = cross / cross_norm
            angle = np.arctan2(cross_norm, dot)
            return axis, angle
