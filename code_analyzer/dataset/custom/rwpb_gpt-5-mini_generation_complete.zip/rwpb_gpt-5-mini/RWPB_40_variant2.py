
def extract_code_from_funct(funct: Callable) -> List[str]:
    from typing import Callable, List
    import inspect
    import ast
    import textwrap
    def extract_code_from_funct(funct: Callable) -> List[str]:
        src = inspect.getsource(funct)
        # Parse the source and find the function node
        try:
            tree = ast.parse(src)
        except SyntaxError:
            # fallback to simple dedent of everything after first def
            parts = src.splitlines()
            for i, ln in enumerate(parts):
                if ln.lstrip().startswith("def ") or ln.lstrip().startswith("async def "):
                    body = "\n".join(parts[i+1:])
                    return [ln for ln in textwrap.dedent(body).splitlines() if ln.strip()]
        func_node = None
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                func_node = node
                break
        if func_node is None:
            return []
        # collect source segments for each body node except final Return if present
        body_nodes = list(func_node.body)
        if body_nodes and isinstance(body_nodes[-1], ast.Return):
            body_nodes = body_nodes[:-1]
        segments = []
        for n in body_nodes:
            seg = ast.get_source_segment(src, n)
            if seg is None:
                # fallback: use lineno/end_lineno
                if hasattr(n, "lineno") and hasattr(n, "end_lineno"):
                    seg_lines = src.splitlines()
                    seg = "\n".join(seg_lines[n.lineno-1:n.end_lineno])
                else:
                    seg = ""
            segments.append(seg)
        combined = "\n".join(segments)
        dedented = textwrap.dedent(combined).splitlines()
        # strip leading/trailing blank lines
        while dedented and dedented[0].strip() == "":
            dedented.pop(0)
        while dedented and dedented[-1].strip() == "":
            dedented.pop()
        return dedented
