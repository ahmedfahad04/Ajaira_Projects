
def bbox_ioa(box1, box2, iou=False, eps=1e-7):
    import numpy as np
    def bbox_ioa(box1, box2, iou=False, eps=1e-7):
        a = np.array(box1, dtype=float)
        b = np.array(box2, dtype=float)
        if a.ndim == 1:
            a = a[np.newaxis, :]
        if b.ndim == 1:
            b = b[np.newaxis, :]
        n, m = a.shape[0], b.shape[0]
        if n == 0 or m == 0:
            return np.zeros((n, m), dtype=float)
        A = a[:, None, :]  # shape (n,1,4)
        B = b[None, :, :]  # shape (1,m,4)
        max_xy1 = np.maximum(A[..., :2], B[..., :2])
        min_xy2 = np.minimum(A[..., 2:], B[..., 2:])
        diff = min_xy2 - max_xy1
        diff = np.maximum(diff, 0.0)
        inter = diff[..., 0] * diff[..., 1]
        wA = np.maximum(a[:, 2] - a[:, 0], 0.0)
        hA = np.maximum(a[:, 3] - a[:, 1], 0.0)
        areaA = wA * hA
        wB = np.maximum(b[:, 2] - b[:, 0], 0.0)
        hB = np.maximum(b[:, 3] - b[:, 1], 0.0)
        areaB = wB * hB
        if iou:
            union = areaA[:, None] + areaB[None, :] - inter
            return inter / (union + eps)
        return inter / (areaB[None, :] + eps)
