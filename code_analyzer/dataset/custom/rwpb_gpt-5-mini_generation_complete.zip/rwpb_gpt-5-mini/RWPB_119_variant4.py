
def rotate_about_x_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        """
        Rotate using quaternion algebra for an explicit axis-angle rotation about x-axis.
        """
        v = np.asarray(vector, dtype=float).ravel()
        if v.size < 3:
            raise ValueError("Input vector must have at least 3 components")
        # quaternion q = [w, xi, yj, zk] with axis [1,0,0]
        w = math.cos(theta / 2.0)
        s = math.sin(theta / 2.0)
        q = np.array([w, s, 0.0, 0.0], dtype=float)
        # conjugate
        q_conj = np.array([w, -s, 0.0, 0.0], dtype=float)
        # vector as quaternion
        vq = np.array([0.0, float(v[0]), float(v[1]), float(v[2])], dtype=float)
        def qmul(a, b):
            aw, ax, ay, az = a
            bw, bx, by, bz = b
            return np.array([
                aw*bw - ax*bx - ay*by - az*bz,
                aw*bx + ax*bw + ay*bz - az*by,
                aw*by - ax*bz + ay*bw + az*bx,
                aw*bz + ax*by - ay*bx + az*bw
            ], dtype=float)
        temp = qmul(q, vq)
        rotated = qmul(temp, q_conj)
        return rotated[1:4]
