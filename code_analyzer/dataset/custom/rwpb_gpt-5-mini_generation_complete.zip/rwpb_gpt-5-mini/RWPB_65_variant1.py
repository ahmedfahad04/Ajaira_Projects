
def merge_dicts_recursively(*dicts):
    import copy
    def merge_dicts_recursively(*dicts):
        if not dicts:
            return {}
        result = {}
        for d in dicts:
            if not isinstance(d, dict):
                continue
            for k, v in d.items():
                if k in result and isinstance(result[k], dict) and isinstance(v, dict):
                    result[k] = merge_dicts_recursively(result[k], v)
                else:
                    result[k] = copy.deepcopy(v)
        return result
