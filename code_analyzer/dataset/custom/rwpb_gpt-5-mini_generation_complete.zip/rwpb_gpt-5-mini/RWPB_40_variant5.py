
def extract_code_from_funct(funct: Callable) -> List[str]:
    from typing import Callable, List
    import inspect
    import textwrap
    def extract_code_from_funct(funct: Callable) -> List[str]:
        src = inspect.getsource(funct)
        parts = src.splitlines()
        # locate def (skip decorators)
        start = None
        for i, ln in enumerate(parts):
            s = ln.lstrip()
            if s.startswith("def ") or s.startswith("async def "):
                start = i
                break
        if start is None:
            return []
        # find end of signature by scanning until a line ending with ':' with balanced parentheses
        i = start
        depth = 0
        while i < len(parts):
            ln = parts[i]
            depth += ln.count("(") - ln.count(")")
            if ln.rstrip().endswith(":") and depth <= 0:
                break
            i += 1
        body_lines = parts[i+1:]
        if not body_lines:
            return []
        dedented = textwrap.dedent("\n".join(body_lines)).splitlines()
        # remove leading/trailing blanks
        while dedented and dedented[0].strip() == "":
            dedented.pop(0)
        while dedented and dedented[-1].strip() == "":
            dedented.pop()
        # remove trailing return statement if it is the last meaningful line
        if dedented:
            # find last non-empty line
            j = len(dedented) - 1
            while j >= 0 and dedented[j].strip() == "":
                j -= 1
            if j >= 0 and dedented[j].lstrip().startswith("return"):
                # remove that line
                dedented.pop(j)
                # cleanup trailing blanks again
                while dedented and dedented[-1].strip() == "":
                    dedented.pop()
        return dedented
