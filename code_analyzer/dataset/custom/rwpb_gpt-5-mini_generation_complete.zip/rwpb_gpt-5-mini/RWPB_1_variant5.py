
def apply_colormap(:
    import torch
    import numpy as np
    from matplotlib import cm
    from torchtyping import TensorType
    def apply_colormap(
        image: TensorType["bs":..., 1],
        cmap="viridis",
    ) -> TensorType["bs":..., "rgb":3]:
        if not isinstance(image, torch.Tensor):
            image = torch.tensor(image)
        img = image.detach().to(torch.float32)
        device = img.device
        if img.shape[-1] != 1:
            raise ValueError("Expected last dimension to be channel=1")
        vals = img[..., 0]
        vmin = float(vals.min().cpu().item())
        vmax = float(vals.max().cpu().item())
        if vmin == vmax:
            norm = torch.zeros_like(vals)
        else:
            norm = (vals - vmin) / (vmax - vmin)
            norm = torch.clamp(norm, 0.0, 1.0)
        # make integer indices 0..255
        indices = (norm * 255.0).round().to(torch.long)
        # one-hot encode and matrix-multiply with palette to get rgb (keeps on device)
        num_classes = 256
        # build palette on CPU then move to device
        cmap_obj = cm.get_cmap(cmap, num_classes)
        palette_np = (cmap_obj(np.linspace(0.0, 1.0, num_classes))[:, :3].astype(np.float32))
        palette = torch.from_numpy(palette_np).to(device=device)
        # one-hot
        flat_idx = indices.view(-1)
        one_hot = torch.nn.functional.one_hot(flat_idx, num_classes=num_classes).to(dtype=torch.float32, device=device)
        rgb_flat = one_hot @ palette  # (N,256) @ (256,3) -> (N,3)
        rgb = rgb_flat.view(list(indices.shape) + [3])
        return rgb.to(dtype=torch.float32)
