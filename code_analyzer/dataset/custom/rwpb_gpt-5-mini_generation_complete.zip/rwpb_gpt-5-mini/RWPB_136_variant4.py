
def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
    import torch
    def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
        import torch
        t_val = v0.new_tensor(t)
        v0 = v0.to(v0.dtype)
        v1 = v1.to(v0.dtype)
        v0_norm = torch.norm(v0, dim=-1, keepdim=True)
        v1_norm = torch.norm(v1, dim=-1, keepdim=True)
        u0 = v0 / (v0_norm + 1e-12)
        u1 = v1 / (v1_norm + 1e-12)
        dot = torch.sum(u0 * u1, dim=-1, keepdim=True)
        dot = torch.clamp(dot, -1.0, 1.0)
        theta = torch.acos(dot)
        perp = u1 - dot * u0
        perp_norm = torch.norm(perp, dim=-1, keepdim=True)
        small = perp_norm < 1e-6
        perp_unit = perp / (perp_norm + 1e-12)
        cos_term = torch.cos(theta * t_val).expand_as(u0) * u0
        sin_term = torch.sin(theta * t_val).expand_as(perp_unit) * perp_unit
        res_unit = cos_term + sin_term
        res_unit = torch.where(small.expand_as(res_unit), ((1.0 - t_val) * u0 + t_val * u1) / (torch.norm((1.0 - t_val) * u0 + t_val * u1, dim=-1, keepdim=True) + 1e-12), res_unit)
        norm_interp = (1.0 - t_val) * v0_norm + t_val * v1_norm
        return res_unit * norm_interp
