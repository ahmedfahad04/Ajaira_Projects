
def unsafeAdd(x, y):
    MAX_VAL = (1 << 256) - 1
    MASK64 = (1 << 64) - 1
    def unsafeAdd(x, y):
        res = 0
        carry = 0
        for i in range(4):
            shift = i * 64
            a = (x >> shift) & MASK64
            b = (y >> shift) & MASK64
            s = a + b + carry
            part = s & MASK64
            carry = s >> 64
            res |= (part << shift)
        return res & MAX_VAL
