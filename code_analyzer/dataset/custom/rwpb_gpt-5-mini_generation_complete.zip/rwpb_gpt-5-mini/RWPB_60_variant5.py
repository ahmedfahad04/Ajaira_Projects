
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        orig_x = x
        orig_dtype = x.dtype
        # upcast for computation
        if upcast:
            x = x.to(torch.float32)
            weight = weight.to(torch.float32)
            if bias is not None:
                bias = bias.to(torch.float32)
            if residual is not None:
                residual = residual.to(torch.float32)
        # compute RMS via sqrt(mean(square)) using in-place ops when possible
        sq = x * x
        mean_sq = sq.mean(dim=-1, keepdim=True)
        inv_rms = torch.rsqrt(mean_sq + eps)
        # broadcast parameters
        if weight.dim() == 1:
            w = weight
            for _ in range(x.dim() - 2):
                w = w.unsqueeze(0)
            w = w.unsqueeze(0) if x.dim() == 1 else weight.view(*([1] * (x.dim() - 1) + [-1]))
        else:
            w = weight
        w = weight.view(*([1] * (x.dim() - 1) + [-1]))
        out = x * inv_rms
        out = out * w
        if bias is not None:
            b = bias.view(*([1] * (x.dim() - 1) + [-1]))
            out = out + b
        if residual is not None:
            out = out + residual
        if upcast:
            out = out.to(orig_dtype)
        if prenorm:
            return out, orig_x
        return out
