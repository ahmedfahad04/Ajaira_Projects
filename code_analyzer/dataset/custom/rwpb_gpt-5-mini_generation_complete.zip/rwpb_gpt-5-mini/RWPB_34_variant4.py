
def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
    import numpy as np
    def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
        tokens = np.asarray(tokens)
        target = max(0, int(context_window) + 1)
        if tokens.ndim == 0:
            tokens = tokens.reshape(1)
        def _pad_one(arr):
            arr = arr[:target]
            if arr.shape[0] < target:
                pad = np.full((target - arr.shape[0],), pad_token, dtype=arr.dtype)
                return np.concatenate([arr, pad])
            return arr
        out = np.apply_along_axis(_pad_one, -1, tokens)
        return out if tokens.ndim > 1 else out.reshape((target,))
