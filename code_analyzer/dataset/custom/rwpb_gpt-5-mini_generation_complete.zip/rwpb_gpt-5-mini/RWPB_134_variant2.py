
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return original_size
        ow, oh = original_size
        if ow == 0 or oh == 0:
            return min(possible_resolutions, key=lambda x: x[0]*x[1])
        orig_ar = ow / oh
        best = None
        best_key = None
        for w, h in possible_resolutions:
            ar = w / h if h != 0 else float('inf')
            ar_diff = abs(ar - orig_ar)
            size_diff = abs(w - ow) + abs(h - oh)
            key = (ar_diff, size_diff, abs(w*h - ow*oh))
            if best is None or key < best_key:
                best = (w, h)
                best_key = key
        return best
