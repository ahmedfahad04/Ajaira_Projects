
def is_tensor(x):
    import numpy as np
    try:
        import torch
    except Exception:
        torch = None
    def is_tensor(x):
        if torch is not None:
            return isinstance(x, torch.Tensor) or isinstance(x, np.ndarray)
        return isinstance(x, np.ndarray)
