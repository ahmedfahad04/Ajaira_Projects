
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        # brute-force per-vector implementation (flatten leading dims)
        orig_x = x
        orig_dtype = x.dtype
        if upcast:
            x = x.to(torch.float32)
            weight = weight.to(torch.float32)
            if bias is not None:
                bias = bias.to(torch.float32)
            if residual is not None:
                residual = residual.to(torch.float32)
        D = x.size(-1)
        flat = x.reshape(-1, D)
        out_flat = torch.empty_like(flat)
        w_flat = weight.view(1, -1).expand(flat.size(0), -1)
        b_flat = None if bias is None else bias.view(1, -1).expand(flat.size(0), -1)
        if residual is not None:
            res_flat = residual.reshape(-1, D)
        else:
            res_flat = None
        for i in range(flat.size(0)):
            vec = flat[i]
            mean_sq = (vec * vec).mean()
            inv = 1.0 / torch.sqrt(mean_sq + eps)
            v = vec * inv
            v = v * w_flat[i]
            if b_flat is not None:
                v = v + b_flat[i]
            if res_flat is not None:
                v = v + res_flat[i]
            out_flat[i] = v
        out = out_flat.reshape_as(x)
        if upcast:
            out = out.to(orig_dtype)
        if prenorm:
            return out, orig_x
        return out
