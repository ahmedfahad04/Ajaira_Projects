
def exp_smooth(vals, alpha):
    import numpy as np
    def exp_smooth(vals, alpha):
        arr = np.asarray(vals, dtype=float)
        if arr.size == 0:
            raise KeyError("Input array is empty")
        n = arr.size
        out = np.empty(n, dtype=float)
        out[0] = arr[0]
        for i in range(1, n):
            out[i] = alpha * arr[i] + (1.0 - alpha) * out[i - 1]
        return out
