
def unpad_image_shape(current_height, current_width, original_size):
    import math
    def unpad_image_shape(current_height, current_width, original_size):
        orig_w, orig_h = original_size
        if orig_w <= 0 or orig_h <= 0:
            return (current_height, current_width)
        # Determine which side was scaled to the target by comparing ratios with cross multiply
        if orig_w * current_height > current_width * orig_h:
            # width scaled to current_width, use floor to avoid exceeding current_height
            new_w = current_width
            new_h = max(1, (orig_h * current_width) // orig_w)
        elif orig_w * current_height < current_width * orig_h:
            # height scaled to current_height
            new_h = current_height
            new_w = max(1, (orig_w * current_height) // orig_h)
        else:
            new_h, new_w = current_height, current_width
        # ensure not larger than current
        new_w = min(new_w, current_width)
        new_h = min(new_h, current_height)
        return (new_h, new_w)
