
def extract_imports_from_lines(lines: List[str]) -> str:
    from typing import List
    import io
    import tokenize
    def extract_imports_from_lines(lines: List[str]) -> str:
        """
        Tokenize-based extractor: uses Python tokenizer to find logical import statements
        and reconstruct them using untokenize, which handles continuations and parentheses.
        """
        text = ''.join(line if line.endswith('\n') else line + '\n' for line in lines)
        readline = io.StringIO(text).readline
        tok_iter = tokenize.generate_tokens(readline)
        collected = []
        it = iter(tok_iter)
        try:
            for tok in it:
                ttype = tok.type
                tstr = tok.string
                # consider start of a logical statement when previous was NEWLINE/INDENT or at file start
                if ttype == tokenize.NAME and tstr in ('import', 'from'):
                    # We need to check previous token on the same line to ensure this is statement-start.
                    # Use the token's start column: if col == 0 or the only preceding tokens are INDENT
                    col = tok.start[1]
                    if col == 0 or col == 1:  # approximate: start of line (allow small indent)
                        # collect tokens until NL or NEWLINE or ENDMARKER
                        stmt_tokens = [tok]
                        for tok2 in it:
                            stmt_tokens.append(tok2)
                            if tok2.type in (tokenize.NEWLINE, tokenize.NL, tokenize.ENDMARKER):
                                break
                        stmt = tokenize.untokenize(stmt_tokens).strip()
                        if stmt:
                            # ensure it really starts with import/from
                            sstripped = stmt.lstrip()
                            if sstripped.startswith('import ') or sstripped.startswith('from '):
                                collected.append(stmt)
                # otherwise continue
        except tokenize.TokenError:
            pass
        return '\n'.join(collected)
