
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    from collections import deque
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        q = deque()
        q.append((d, parent_key))
        out = {}
        while q:
            curr, base = q.popleft()
            for k, v in curr.items():
                ks = str(k)
                nk = ks if base == "" else base + sep + ks
                if isinstance(v, dict):
                    if v:
                        q.append((v, nk))
                    # skip empty dicts
                else:
                    out[nk] = v
        return out
