
def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        """
        Project coordinates using the first two axis vectors of each plane.
        planes: (P, 3, 3)  -> use planes[:, :2, :] as two 3D axes
        coordinates: (N, M, 3)
        Returns: (N*P, M, 2)
        """
        if planes.ndim != 3 or planes.size(1) < 2 or planes.size(2) != 3:
            raise ValueError("planes must have shape (P,3,3) or at least have 2 axes of length 3")
        if coordinates.ndim != 3 or coordinates.size(2) != 3:
            raise ValueError("coordinates must have shape (N,M,3)")
        P = planes.size(0)
        N, M, _ = coordinates.shape
        # pick first two axes (assumed to be plane axes)
        axes = planes[:, :2, :]  # (P,2,3)
        # einsum to compute dot products: result shape (P, N, M, 2)
        proj = torch.einsum('pka,nma->pnmk', axes, coordinates)
        # bring to (N*P, M, 2)
        proj = proj.permute(1,0,2,3).reshape(N * P, M, 2)
        return proj
