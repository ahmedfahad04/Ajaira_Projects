
def pr_from_grav(grav):
    import numpy as np
    def pr_from_grav(grav):
        grav = np.asarray(grav, dtype=float)
        # Ensure shape (n,3)
        if grav.ndim == 1:
            if grav.size != 3:
                raise ValueError("grav must be shape (n,3) or (3,)")
            grav = grav.reshape(1, 3)
        if grav.ndim != 2 or grav.shape[1] != 3:
            raise ValueError("grav must have shape (n,3)")
        gx = grav[:, 0]
        gy = grav[:, 1]
        gz = grav[:, 2]
        # pitch: rotation about y axis (positive nose up) from gravity vector
        pitches = np.arctan2(-gx, np.sqrt(gy * gy + gz * gz))
        # roll: rotation about x axis (positive right wing down)
        rolls = np.arctan2(gy, gz)
        return pitches, rolls
