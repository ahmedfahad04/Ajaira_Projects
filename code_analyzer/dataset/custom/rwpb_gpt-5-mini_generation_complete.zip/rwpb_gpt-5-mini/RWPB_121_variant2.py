
def isprime(n):
    import math
    def isprime(n):
        if not isinstance(n, int):
            return False
        if n <= 1:
            return False
        if n <= 3:
            return True
        if n % 2 == 0:
            return False
        limit = math.isqrt(n)
        i = 3
        while i <= limit:
            if n % i == 0:
                return False
            i += 2
        return True
