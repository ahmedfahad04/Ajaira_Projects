
def movmean(arr, n_avg):
    import numpy as np
    def movmean(arr, n_avg):
        a = np.asarray(arr, dtype=float).ravel()
        if n_avg <= 0:
            return np.array([], dtype=float)
        N = a.size
        if n_avg > N:
            return np.array([], dtype=float)
        try:
            from numpy.lib.stride_tricks import sliding_window_view
            windows = sliding_window_view(a, window_shape=n_avg)
            return windows.mean(axis=1)
        except Exception:
            # fallback to simple loop
            out = np.empty(N - n_avg + 1, dtype=float)
            for i in range(N - n_avg + 1):
                out[i] = a[i:i + n_avg].sum() / float(n_avg)
            return out
