
def fit_params(:
    def fit_params(
        x,
        y,
        fun,
        a_range=(-10, 10),
        b_range=(-10, 10),
        grid_number=101,
        iteration=3,
        verbose=True,
    ):
        import numpy as np
        import torch
        import random
        # Randomized search then zoom-in grid
        if torch.is_tensor(x):
            x_np = x.detach().cpu().numpy()
        else:
            x_np = np.asarray(x)
        if torch.is_tensor(y):
            y_np = y.detach().cpu().numpy()
        else:
            y_np = np.asarray(y)
        n = x_np.size
        a_min, a_max = float(a_range[0]), float(a_range[1])
        b_min, b_max = float(b_range[0]), float(b_range[1])
        best = {"r2": -np.inf, "a": None, "b": None, "c": None, "d": None}
        # Random search phase
        random_trials = max(200, grid_number * 2)
        for _ in range(random_trials):
            a = random.uniform(a_min, a_max)
            b = random.uniform(b_min, b_max)
            z = np.asarray(fun(a * x_np + b)).reshape(-1)
            S_z = z.sum()
            S_zz = (z * z).sum()
            S_y = y_np.sum()
            S_zy = (z * y_np).sum()
            denom = n * S_zz - S_z * S_z
            if abs(denom) < 1e-12:
                c = 0.0
                d = S_y / n
            else:
                c = (n * S_zy - S_z * S_y) / denom
                d = (S_y - c * S_z) / n
            y_pred = c * z + d
            ss_res = ((y_np - y_pred) ** 2).sum()
            ss_tot = ((y_np - y_np.mean()) ** 2).sum()
            r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else (1.0 if ss_res == 0 else -np.inf)
            if r2 > best["r2"]:
                best.update({"r2": r2, "a": a, "b": b, "c": c, "d": d})
        if verbose:
            print(f"After random phase best r2={best['r2']:.6f}, a={best['a']}, b={best['b']}")
        # Zoom-in grid iterations
        for it in range(iteration):
            a_center = best["a"]
            b_center = best["b"]
            a_min = a_center - (a_max - a_min) / (10.0 * (it + 1))
            a_max = a_center + (a_max - a_min) / (10.0 * (it + 1))
            b_min = b_center - (b_max - b_min) / (10.0 * (it + 1))
            b_max = b_center + (b_max - b_min) / (10.0 * (it + 1))
            a_vals = np.linspace(a_min, a_max, grid_number)
            b_vals = np.linspace(b_min, b_max, grid_number)
            for a in a_vals:
                z_base = a * x_np
                for b in b_vals:
                    z = np.asarray(fun(z_base + b)).reshape(-1)
                    S_z = z.sum()
                    S_zz = (z * z).sum()
                    S_y = y_np.sum()
                    S_zy = (z * y_np).sum()
                    denom = n * S_zz - S_z * S_z
                    if abs(denom) < 1e-12:
                        c = 0.0
                        d = S_y / n
                    else:
                        c = (n * S_zy - S_z * S_y) / denom
                        d = (S_y - c * S_z) / n
                    y_pred = c * z + d
                    ss_res = ((y_np - y_pred) ** 2).sum()
                    ss_tot = ((y_np - y_np.mean()) ** 2).sum()
                    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else (1.0 if ss_res == 0 else -np.inf)
                    if r2 > best["r2"]:
                        best.update({"r2": r2, "a": a, "b": b, "c": c, "d": d})
            if verbose:
                print(f"Zoom iter {it+1}/{iteration}, best r2={best['r2']:.6f}, a={best['a']}, b={best['b']}")
        return torch.tensor([best["a"], best["b"], best["c"], best["d"]], dtype=torch.float64), torch.tensor(best["r2"], dtype=torch.float64)
