
def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
    import torch
    def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        ndim = x.dim()
        if ndim == 0:
            return x.contiguous() if make_contiguous else x
        src = src_dim if src_dim >= 0 else src_dim + ndim
        dest = dest_dim if dest_dim >= 0 else dest_dim + ndim
        if not (0 <= src < ndim) or not (0 <= dest < ndim):
            raise IndexError("src_dim or dest_dim out of range")
        if src == dest:
            return x.contiguous() if make_contiguous else x
        # Unbind along src to get a list of tensors without that dim, then stack at dest
        slices = list(torch.unbind(x, dim=src))
        # After unbind each tensor has ndim-1 dims. We can stack them at position 'dest' to re-create the moved axis.
        stacked = torch.stack(slices, dim=dest)
        return stacked.contiguous() if make_contiguous else stacked
