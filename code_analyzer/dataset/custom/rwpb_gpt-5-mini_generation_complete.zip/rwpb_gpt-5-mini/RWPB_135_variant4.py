
def mask_iou(mask1, mask2, eps=1e-7):
    import torch
    def mask_iou(mask1, mask2, eps=1e-7):
        """
        Loop over the smaller outer dimension using boolean logical_and to compute intersections.
        """
        if not isinstance(mask1, torch.Tensor) or not isinstance(mask2, torch.Tensor):
            raise TypeError("mask1 and mask2 must be torch.Tensors")
        if mask1.ndim != 2 or mask2.ndim != 2:
            raise ValueError("mask1 and mask2 must be 2-D tensors")
        N, n1 = mask1.shape
        M, n2 = mask2.shape
        if n1 != n2:
            raise ValueError("mask1 and mask2 must have the same number of columns")
        if N == 0 or M == 0:
            return torch.zeros((N, M), dtype=mask1.dtype, device=mask1.device)
        # Work with boolean masks for logical operations
        b1 = mask1 != 0
        b2 = mask2 != 0
        device = mask1.device
        out = torch.zeros((N, M), dtype=torch.float32, device=device)
        # iterate over the smaller outer dimension for efficiency
        if N <= M:
            for i in range(N):
                row = b1[i].unsqueeze(0)  # (1, n)
                inter = (b2 & row).sum(dim=1).float()  # (M,)
                area1 = row.sum().float()
                area2 = b2.sum(dim=1).float()
                union = area1 + area2 - inter
                iou_row = inter / (union + eps)
                iou_row = torch.where(union > 0, iou_row, torch.zeros_like(iou_row))
                out[i] = iou_row
        else:
            # iterate over predictions and fill transposed
            for j in range(M):
                col = b2[j].unsqueeze(0)  # (1, n)
                inter = (b1 & col).sum(dim=1).float()  # (N,)
                area2 = col.sum().float()
                area1 = b1.sum(dim=1).float()
                union = area1 + area2 - inter
                iou_col = inter / (union + eps)
                iou_col = torch.where(union > 0, iou_col, torch.zeros_like(iou_col))
                out[:, j] = iou_col
        return out.to(dtype=mask1.dtype)
