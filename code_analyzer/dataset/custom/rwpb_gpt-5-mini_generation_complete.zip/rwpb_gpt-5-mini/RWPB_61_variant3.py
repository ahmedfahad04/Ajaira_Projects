
def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        x_orig = x
        if upcast:
            target_dtype = torch.float32
            x = x.to(target_dtype)
            if weight is not None:
                weight = weight.to(target_dtype)
            if bias is not None:
                bias = bias.to(target_dtype)
            if residual is not None:
                residual = residual.to(target_dtype)
        N = x.size(-1)
        sum_x = x.sum(dim=-1, keepdim=True)
        sum_x2 = (x * x).sum(dim=-1, keepdim=True)
        mean = sum_x / N
        var = (sum_x2 / N) - (mean * mean)
        var = torch.clamp(var, min=0.0)
        invstd = torch.rsqrt(var + eps)
        normalized = (x - mean) * invstd
        if weight is not None:
            w = weight
            if w.ndim == 1:
                shape = [1] * (x.dim() - 1) + [-1]
                w = w.view(*shape)
            normalized = normalized * w
        if bias is not None:
            b = bias
            if b.ndim == 1:
                shape = [1] * (x.dim() - 1) + [-1]
                b = b.view(*shape)
            normalized = normalized + b
        if residual is not None:
            normalized = normalized + residual
        if upcast:
            normalized = normalized.to(x_orig.dtype)
        if prenorm:
            return normalized, x_orig
        return normalized
