
def moving_average(arr, window_size):
    import numpy as np
    from collections import deque
    def moving_average(arr, window_size):
        arr = np.asarray(arr, dtype=float).ravel()
        n = arr.size
        if window_size <= 0:
            raise ValueError("window_size must be positive")
        if n == 0:
            return np.array([]), np.array([])
        k = min(window_size, n)
        # We'll compute a centered moving average using a sliding deque maintaining sums
        left = (k - 1) // 2
        right = k - 1 - left
        moving = np.empty(n, dtype=float)
        # For each index, build window [start:end) and compute sum by maintaining deque for efficiency
        # We'll slide the right end forward and pop left as index increases
        # Initialize for i=0
        start0 = max(0, 0 - left)
        end0 = min(n, 0 + right + 1)
        dq = deque()
        cur_sum = 0.0
        for j in range(start0, end0):
            dq.append(j)
            cur_sum += arr[j]
        moving[0] = cur_sum / (end0 - start0)
        # Now iterate i=1..n-1
        for i in range(1, n):
            new_start = max(0, i - left)
            new_end = min(n, i + right + 1)
            # remove indices < new_start
            while dq and dq[0] < new_start:
                idx = dq.popleft()
                cur_sum -= arr[idx]
            # add indices up to new_end-1
            last = dq[-1] if dq else (new_start - 1)
            j = last + 1
            while j < new_end:
                dq.append(j)
                cur_sum += arr[j]
                j += 1
            moving[i] = cur_sum / (new_end - new_start)
        residuals = arr - moving
        return moving, residuals
