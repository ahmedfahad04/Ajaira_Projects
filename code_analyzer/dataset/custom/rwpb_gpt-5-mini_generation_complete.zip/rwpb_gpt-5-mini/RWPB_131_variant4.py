
def box_iou(box1, box2, eps=1e-7):
    import torch
    import numpy as np
    def box_iou(box1, box2, eps=1e-7):
        if box1.ndim != 2 or box2.ndim != 2:
            raise ValueError("box1 and box2 must be of shape (N,4) and (M,4)")
        n = box1.shape[0]
        m = box2.shape[0]
        if n == 0 or m == 0:
            return torch.zeros((n, m), dtype=box1.dtype, device=box1.device)
        b1x1, b1y1, b1x2, b1y2 = box1[:,0], box1[:,1], box1[:,2], box1[:,3]
        b2x1, b2y1, b2x2, b2y2 = box2[:,0], box2[:,1], box2[:,2], box2[:,3]
        inter_x1 = torch.max(b1x1[:, None], b2x1[None, :])
        inter_y1 = torch.max(b1y1[:, None], b2y1[None, :])
        inter_x2 = torch.min(b1x2[:, None], b2x2[None, :])
        inter_y2 = torch.min(b1y2[:, None], b2y2[None, :])
        inter = (inter_x2 - inter_x1).clamp(min=0) * (inter_y2 - inter_y1).clamp(min=0)
        a1 = (b1x2 - b1x1).clamp(min=0) * (b1y2 - b1y1).clamp(min=0)
        a2 = (b2x2 - b2x1).clamp(min=0) * (b2y2 - b2y1).clamp(min=0)
        union = a1[:, None] + a2[None, :] - inter
        return inter.div(union + eps)
