
def round(number, num_decimal_places, leave_int=False):
    from decimal import Decimal, ROUND_HALF_DOWN
    def round(number, num_decimal_places, leave_int=False):
        # Use ROUND_HALF_DOWN behavior (ties go down)
        if isinstance(number, Decimal):
            dec = number
        else:
            dec = Decimal(str(number))
        exp = Decimal('1e{}'.format(-int(num_decimal_places)))
        rounded = dec.quantize(exp, rounding=ROUND_HALF_DOWN)
        if leave_int and rounded == rounded.to_integral_value():
            return int(rounded)
        return float(rounded)
