
def pad_camera_extrinsics_4x4(extrinsics):
    import torch
    def pad_camera_extrinsics_4x4(extrinsics):
        if not isinstance(extrinsics, torch.Tensor):
            raise TypeError("extrinsics must be a torch.Tensor")
        if extrinsics.shape[-2:] == (4, 4):
            return extrinsics
        if extrinsics.shape[-2:] != (3, 4):
            raise ValueError("Expected (...,3,4) or (...,4,4) input")
        device = extrinsics.device
        dtype = extrinsics.dtype
        out_shape = tuple(extrinsics.shape[:-2]) + (4, 4)
        out = torch.zeros(out_shape, dtype=dtype, device=device)
        out[..., :3, :] = extrinsics
        out[..., 3, 3] = 1
        return out
