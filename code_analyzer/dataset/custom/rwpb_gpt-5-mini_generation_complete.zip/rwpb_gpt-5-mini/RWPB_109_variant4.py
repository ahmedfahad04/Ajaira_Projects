
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        # Support inputs as arrays or tensors
        if not isinstance(geometry, torch.Tensor):
            geometry = torch.tensor(geometry)
        if not isinstance(rot, torch.Tensor):
            rot = torch.tensor(rot)
        if not isinstance(trans, torch.Tensor):
            trans = torch.tensor(trans)
        B = geometry.shape[0]
        # Normalize shapes
        if rot.dim() == 2:
            rot = rot.unsqueeze(0).expand(B, -1, -1)
        if trans.dim() == 1:
            trans = trans.unsqueeze(0).expand(B, -1)
        out = torch.empty_like(geometry)
        # Loop per batch (simple, explicit)
        for b in range(B):
            out[b] = geometry[b].matmul(rot[b].t()) + trans[b].unsqueeze(0)
        return out
