
def clean_html(:
    from typing import List
    from html import escape
    def clean_html(
            html_to_clean: str,
            tags_to_remove: List[str] = ["style", "svg", "script"],
            attributes_to_keep: List[str] = ["id", "href"],
    ) -> str:
        remove = set(t.lower() for t in tags_to_remove)
        keep = set(a.lower() for a in attributes_to_keep)
        i = 0
        n = len(html_to_clean)
        out = []
        skip_stack = []
        def read_while(cond):
            nonlocal i
            start = i
            while i < n and cond(html_to_clean[i]):
                i += 1
            return html_to_clean[start:i]
        while i < n:
            ch = html_to_clean[i]
            if ch == '<':
                if html_to_clean.startswith('<!--', i):
                    # comment
                    end = html_to_clean.find('-->', i+4)
                    if end == -1:
                        # consume rest
                        if not skip_stack:
                            out.append(html_to_clean[i:])
                        break
                    if not skip_stack:
                        out.append(html_to_clean[i:end+3])
                    i = end + 3
                    continue
                # parse tag
                j = i + 1
                closing = False
                if j < n and html_to_clean[j] == '/':
                    closing = True
                    j += 1
                # read tag name
                start_name = j
                while j < n and html_to_clean[j].isalnum() or (j < n and html_to_clean[j] in ':-'):
                    j += 1
                tagname = html_to_clean[start_name:j].strip()
                lower_tag = tagname.lower()
                # find end of tag
                # naive attribute parsing
                k = j
                in_quote = None
                while k < n:
                    ch2 = html_to_clean[k]
                    if in_quote:
                        if ch2 == in_quote:
                            in_quote = None
                    else:
                        if ch2 in ('"', "'"):
                            in_quote = ch2
                        elif ch2 == '>':
                            break
                    k += 1
                if k >= n:
                    # malformed, append rest
                    if not skip_stack:
                        out.append(html_to_clean[i:])
                    break
                tag_text = html_to_clean[i:k+1]
                # handle closing tags
                if closing:
                    if skip_stack:
                        if skip_stack[-1] == lower_tag:
                            skip_stack.pop()
                    else:
                        out.append(tag_text)
                    i = k+1
                    continue
                # determine if self-closing
                selfclose = tag_text.rstrip().endswith('/>')
                if lower_tag in remove:
                    if not selfclose:
                        skip_stack.append(lower_tag)
                    i = k+1
                    continue
                if skip_stack:
                    i = k+1
                    continue
                # parse attributes manually between j and k
                attr_region = html_to_clean[j:k]
                attrs = []
                p = 0
                L = len(attr_region)
                while p < L:
                    # skip whitespace
                    while p < L and attr_region[p].isspace():
                        p += 1
                    if p >= L:
                        break
                    # read name
                    start_n = p
                    while p < L and not attr_region[p].isspace() and attr_region[p] not in "=/>":
                        p += 1
                    name = attr_region[start_n:p]
                    if not name:
                        p += 1
                        continue
                    # skip spaces
                    while p < L and attr_region[p].isspace():
                        p += 1
                    val = None
                    if p < L and attr_region[p] == '=':
                        p += 1
                        while p < L and attr_region[p].isspace():
                            p += 1
                        if p < L and attr_region[p] in "\"'":
                            q = p+1
                            quote = attr_region[p]
                            while q < L and attr_region[q] != quote:
                                q += 1
                            val = attr_region[p+1:q] if q < L else attr_region[p+1:q]
                            p = q+1 if q < L else q
                        else:
                            q = p
                            while q < L and not attr_region[q].isspace():
                                q += 1
                            val = attr_region[p:q]
                            p = q
                    if name.lower() in keep:
                        if val is None:
                            attrs.append(name)
                        else:
                            attrs.append(f'{name}="{escape(val, quote=True)}"')
                attr_text = (" " + " ".join(attrs)) if attrs else ""
                if selfclose:
                    out.append(f"<{tagname}{attr_text}/>")
                else:
                    out.append(f"<{tagname}{attr_text}>")
                i = k+1
            else:
                # text node
                start = i
                nxt = html_to_clean.find('<', i)
                if nxt == -1:
                    nxt = n
                text = html_to_clean[start:nxt]
                if not skip_stack:
                    out.append(text)
                i = nxt
        return "".join(out)
