
def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        # Interpret each plane as a 3x3 linear mapping from plane coords to world coords:
        # invert the mapping and take first two components as plane coordinates.
        if planes.ndim != 3 or planes.size(1) != 3 or planes.size(2) != 3:
            raise ValueError("planes must be (P,3,3)")
        if coordinates.ndim != 3 or coordinates.size(2) != 3:
            raise ValueError("coordinates must be (N,M,3)")
        P = planes.shape[0]
        N, M, _ = coordinates.shape
        # invert each plane matrix (assumes invertible)
        inv = torch.inverse(planes)  # (P,3,3)
        # apply inverse to coordinates: inv (P,3,3) and coords (N,M,3) -> (P,N,M,3)
        transformed = torch.einsum('pab,nma->pnmb', inv, coordinates)  # (P,N,M,3)
        # take first two components (u,v) as plane coordinates
        uv = transformed[:, :, :, :2]  # (P,N,M,2)
        # reorder to (N*P, M, 2)
        uv = uv.permute(1, 0, 2, 3).reshape(N * P, M, 2)
        return uv
