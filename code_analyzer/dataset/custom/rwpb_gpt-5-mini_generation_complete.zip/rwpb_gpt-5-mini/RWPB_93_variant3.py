
def unsafeSub(x, y):
    MAX_VAL = (1 << 256) - 1
    MOD = 1 << 256
    def unsafeSub(x, y):
        xu = x & MAX_VAL
        yu = y & MAX_VAL
        if xu >= yu:
            return xu - yu
        return MOD - (yu - xu)
