
def mask_iou(mask1, mask2, eps=1e-7):
    import torch
    def mask_iou(mask1, mask2, eps=1e-7):
        """
        Using einsum to compute pairwise intersections.
        """
        if not isinstance(mask1, torch.Tensor) or not isinstance(mask2, torch.Tensor):
            raise TypeError("mask1 and mask2 must be torch.Tensors")
        if mask1.ndim != 2 or mask2.ndim != 2:
            raise ValueError("mask1 and mask2 must be 2-D tensors")
        N, n1 = mask1.shape
        M, n2 = mask2.shape
        if n1 != n2:
            raise ValueError("mask1 and mask2 must have the same number of columns")
        if N == 0 or M == 0:
            return torch.zeros((N, M), dtype=mask1.dtype, device=mask1.device)
        m1 = mask1.float()
        m2 = mask2.float()
        inter = torch.einsum('ik,jk->ij', m1, m2)
        area1 = m1.sum(dim=1).unsqueeze(1)
        area2 = m2.sum(dim=1).unsqueeze(0)
        union = area1 + area2 - inter
        iou = inter / (union + eps)
        # zero out invalid unions
        iou = torch.where(union > 0, iou, torch.zeros_like(iou))
        return iou
