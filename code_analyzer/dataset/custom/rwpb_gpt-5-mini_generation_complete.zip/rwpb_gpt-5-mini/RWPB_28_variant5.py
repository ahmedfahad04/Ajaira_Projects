
def mean(l, ignore_nan=False, empty=0):
    import math
    from functools import reduce
    def mean(l, ignore_nan=False, empty=0):
        """
        Use functools.reduce to compute running sum and count in a functional style.
        """
        def reducer(acc, x):
            s, n = acc
            try:
                if ignore_nan and math.isnan(x):
                    return (s, n)
            except Exception:
                pass
            return (s + float(x), n + 1)
        s, n = reduce(reducer, l, (0.0, 0))
        if n == 0:
            if empty == 'raise':
                raise ValueError("mean of empty iterable")
            return empty
        return s / n
