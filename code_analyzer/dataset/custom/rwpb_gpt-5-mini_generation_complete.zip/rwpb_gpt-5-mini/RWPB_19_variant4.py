
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        try:
            import numpy as _np
        except Exception:
            return 0.0
        a = _np.asarray(preds, dtype=float)
        b = _np.asarray(references, dtype=float)
        n = a.shape[0]
        if n < 2:
            return 0.0
        dp = a[:, None] - a[None, :]
        dr = b[:, None] - b[None, :]
        triu = _np.triu_indices(n, k=1)
        mask = dp[triu] != 0
        if mask.sum() == 0:
            return 0.0
        concordant = _np.sum((_np.sign(dp[triu]) * _np.sign(dr[triu])) > 0)
        total = int(mask.sum())
        return float(concordant) / float(total)
