
def rotate_normalmap_by_angle_torch(normal_map, angle):
    import torch, math
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        """
        Rotate normals about the y-axis by angle (degrees).
        Supports tensor of shape (..., 3).
        """
        if not isinstance(normal_map, torch.Tensor):
            raise TypeError("normal_map must be a torch.Tensor")
        # convert angle to tensor on same device/dtype
        device = normal_map.device
        dtype = normal_map.dtype
        theta = torch.tensor(math.radians(angle), device=device, dtype=dtype)
        c = torch.cos(theta)
        s = torch.sin(theta)
        # split channels
        x = normal_map[..., 0]
        y = normal_map[..., 1]
        z = normal_map[..., 2]
        # apply rotation R_y(theta): x' = c*x + s*z, y' = y, z' = -s*x + c*z
        xr = c * x + s * z
        yr = y
        zr = -s * x + c * z
        rotated = torch.stack((xr, yr, zr), dim=-1)
        # renormalize to unit length to correct tiny numerical drift
        norms = rotated.norm(dim=-1, keepdim=True).clamp(min=1e-8)
        rotated = rotated / norms
        return rotated
