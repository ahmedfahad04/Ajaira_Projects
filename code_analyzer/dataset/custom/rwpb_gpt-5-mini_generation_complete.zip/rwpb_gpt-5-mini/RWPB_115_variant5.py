
def compute_tri_normal(geometry, tris):
    import torch
    def compute_tri_normal(geometry, tris):
        """
        Minimal iterative approach: compute normals per triangle then broadcast across batch.
        Returns unit normals.
        """
        B, N, _ = geometry.shape
        M = tris.shape[0]
        if M == 0 or B == 0:
            return torch.empty(B, M, 3, device=geometry.device, dtype=geometry.dtype)
        tris = tris.to(geometry.device)
        # Compute vertex positions for a single batch shape (M,3,3) by indexing geometry[0] shape (N,3)
        # Then compute normals for those relative indices for each batch by subtracting per-batch v0
        # First compute per-triangle vertex indices -> gather from a dummy to get shape
        v_idx = tris  # (M,3)
        normals_per_tri = []
        for i in range(M):
            i0, i1, i2 = int(v_idx[i,0].item()), int(v_idx[i,1].item()), int(v_idx[i,2].item())
            # gather across batch for the three vertices: (B,3)
            p0 = geometry[:, i0, :]
            p1 = geometry[:, i1, :]
            p2 = geometry[:, i2, :]
            n = torch.cross(p1 - p0, p2 - p0, dim=-1)
            n = n / (n.norm(p=2, dim=-1, keepdim=True).clamp(min=1e-8))
            normals_per_tri.append(n.unsqueeze(1))  # (B,1,3)
        return torch.cat(normals_per_tri, dim=1)
