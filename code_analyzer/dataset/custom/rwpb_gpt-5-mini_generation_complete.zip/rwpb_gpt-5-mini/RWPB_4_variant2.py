
def rot6d_to_rotmat(x):
    import torch
    import numpy as np
    def rot6d_to_rotmat(x):
        if isinstance(x, np.ndarray):
            x = torch.tensor(x)
        if not isinstance(x, torch.Tensor):
            raise ValueError("Input must be torch.Tensor or numpy.ndarray")
        if x.dim() != 2 or x.size(1) != 6:
            raise ValueError("Input must have shape (B,6)")
        x = x.float()
        eps = 1e-8
        a1 = x[:, :3]
        a2 = x[:, 3:6]
        # manual normalization
        n1 = torch.norm(a1, p=2, dim=1, keepdim=True).clamp(min=eps)
        b1 = a1 / n1
        # orthogonalize a2 against b1
        dot12 = (b1 * a2).sum(dim=1, keepdim=True)
        u2 = a2 - dot12 * b1
        n2 = torch.norm(u2, p=2, dim=1, keepdim=True).clamp(min=eps)
        b2 = u2 / n2
        b3 = torch.cross(b1, b2, dim=1)
        R = torch.zeros((x.size(0), 3, 3), dtype=x.dtype, device=x.device)
        R[:, :, 0] = b1
        R[:, :, 1] = b2
        R[:, :, 2] = b3
        return R
