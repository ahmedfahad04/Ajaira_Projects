
def check_all_columns_numeric(df):
    import pandas as pd
    def check_all_columns_numeric(df):
        """
        Use pandas select_dtypes to identify numeric columns and compare count.
        """
        if df is None:
            return False
        # If no columns, consider it True
        if df.shape[1] == 0:
            return True
        numeric_cols = df.select_dtypes(include='number').columns
        return len(numeric_cols) == len(df.columns)
