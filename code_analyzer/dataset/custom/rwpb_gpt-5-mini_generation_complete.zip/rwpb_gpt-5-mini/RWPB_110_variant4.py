
def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
    import numpy as np
    import math
    def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
        n = np.array(plane_normal, dtype=float)
        p = np.array(plane_point, dtype=float)
        d = np.array(ray_direction, dtype=float)
        r = np.array(ray_point, dtype=float)
        # Flatten inputs
        n = n.flatten()
        p = p.flatten()
        d = d.flatten()
        r = r.flatten()
        # If normal or direction degenerate, no unique intersection
        if np.allclose(n, 0) or np.allclose(d, 0):
            return None
        denom = float(np.dot(n, d))
        if math.isclose(denom, 0.0, rel_tol=1e-9, abs_tol=1e-12):
            return None
        t = float(np.dot(n, p - r)) / denom
        inter = r + t * d
        return np.array(inter, dtype=float)
