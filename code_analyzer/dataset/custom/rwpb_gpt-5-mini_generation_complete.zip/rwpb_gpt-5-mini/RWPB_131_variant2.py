
def box_iou(box1, box2, eps=1e-7):
    import torch
    import numpy as np
    def box_iou(box1, box2, eps=1e-7):
        n = box1.shape[0]
        m = box2.shape[0]
        if n == 0 or m == 0:
            return torch.zeros((n, m), dtype=box1.dtype, device=box1.device)
        x1_b2 = box2[:, 0]
        y1_b2 = box2[:, 1]
        x2_b2 = box2[:, 2]
        y2_b2 = box2[:, 3]
        area2 = (x2_b2 - x1_b2).clamp(min=0) * (y2_b2 - y1_b2).clamp(min=0)
        out = []
        for i in range(n):
            x1 = torch.maximum(box1[i, 0], x1_b2)
            y1 = torch.maximum(box1[i, 1], y1_b2)
            x2 = torch.minimum(box1[i, 2], x2_b2)
            y2 = torch.minimum(box1[i, 3], y2_b2)
            inter = (x2 - x1).clamp(min=0) * (y2 - y1).clamp(min=0)
            area1 = (box1[i, 2] - box1[i, 0]).clamp(min=0) * (box1[i, 3] - box1[i, 1]).clamp(min=0)
            union = area1 + area2 - inter
            out.append(inter / (union + eps))
        return torch.stack(out, dim=0)
