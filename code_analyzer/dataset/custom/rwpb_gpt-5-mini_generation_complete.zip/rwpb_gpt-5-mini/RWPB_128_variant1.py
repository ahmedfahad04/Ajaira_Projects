
def xywh2xyxy(x):
    import numpy as np
    import torch
    def xywh2xyxy(x):
        if isinstance(x, np.ndarray):
            if x.size == 0:
                return x.copy()
            if x.shape[-1] != 4:
                raise ValueError("Last dimension must be 4")
            y = x.copy()
            y[..., 2] = x[..., 0] + x[..., 2]
            y[..., 3] = x[..., 1] + x[..., 3]
            return y
        if torch.is_tensor(x):
            if x.numel() == 0:
                return x.clone()
            if x.shape[-1] != 4:
                raise ValueError("Last dimension must be 4")
            y = x.clone()
            y[..., 2] = x[..., 0] + x[..., 2]
            y[..., 3] = x[..., 1] + x[..., 3]
            return y
        arr = np.asarray(x)
        if arr.shape[-1] != 4:
            raise ValueError("Last dimension must be 4")
        y = arr.copy()
        y[..., 2] = arr[..., 0] + arr[..., 2]
        y[..., 3] = arr[..., 1] + arr[..., 3]
        return y
