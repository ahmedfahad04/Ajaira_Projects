
def movmean(arr, n_avg):
    import numpy as np
    def movmean(arr, n_avg):
        a = np.asarray(arr, dtype=float).ravel()
        if n_avg <= 0:
            return np.array([], dtype=float)
        N = a.size
        if n_avg > N:
            return np.array([], dtype=float)
        # incremental sliding window sum (O(N))
        out_len = N - n_avg + 1
        out = np.empty(out_len, dtype=float)
        # initial sum
        s = 0.0
        for i in range(n_avg):
            s += a[i]
        out[0] = s / float(n_avg)
        for i in range(1, out_len):
            s += a[i + n_avg - 1] - a[i - 1]
            out[i] = s / float(n_avg)
        return out
