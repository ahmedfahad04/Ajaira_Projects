
def validate_user_id(user_id):
    import string
    def validate_user_id(user_id):
        if not isinstance(user_id, str) or len(user_id) == 0:
            return False
        if user_id[0] not in string.ascii_letters:
            return False
        for ch in user_id[1:]:
            if not (ch.isalnum() or ch == '_'):
                return False
        return True
