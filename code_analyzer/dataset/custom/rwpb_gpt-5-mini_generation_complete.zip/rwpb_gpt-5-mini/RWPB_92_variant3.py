
def round(number, num_decimal_places, leave_int=False):
    from decimal import Decimal, ROUND_HALF_EVEN
    def round(number, num_decimal_places, leave_int=False):
        # Use banker's rounding (ROUND_HALF_EVEN) via Decimal
        if isinstance(number, Decimal):
            dec = number
        else:
            dec = Decimal(str(number))
        exp = Decimal('1e{}'.format(-int(num_decimal_places)))
        rounded = dec.quantize(exp, rounding=ROUND_HALF_EVEN)
        if leave_int and rounded == rounded.to_integral_value():
            return int(rounded)
        return float(rounded)
