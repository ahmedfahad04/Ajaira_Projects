
def cvimg2torch(img):
    import numpy as np
    import torch
    def cvimg2torch(img):
        """
        Convert a img to tensor
        input:
            img -> ndarray uint8 HxWxC or HxW
        return
            tensor -> torch.tensor BxCxHxW (preserve dtype, usually uint8)
        """
        arr = np.asarray(img)
        if arr.ndim == 2:
            arr = arr[:, :, None]
        # make contiguous in memory as HxWxC
        arr = np.ascontiguousarray(arr)
        t = torch.from_numpy(arr)  # HxWxC
        # move channel to front: CxHxW
        t = t.permute(2, 0, 1).contiguous()
        # add batch dimension
        t = t.unsqueeze(0)
        return t
