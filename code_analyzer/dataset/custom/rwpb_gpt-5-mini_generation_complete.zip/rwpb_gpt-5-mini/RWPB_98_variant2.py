
def exp_smooth(vals, alpha):
    import numpy as np
    def exp_smooth(vals, alpha):
        arr = np.asarray(vals, dtype=float)
        if arr.size == 0:
            raise KeyError("Input array is empty")
        n = arr.size
        ex = np.arange(n)
        diff = ex[:, None] - ex[None, :]
        mask = diff >= 0
        M = np.zeros((n, n), dtype=float)
        M[mask] = alpha * ((1.0 - alpha) ** diff[mask])
        M[:, 0] = (1.0 - alpha) ** ex
        return M.dot(arr)
