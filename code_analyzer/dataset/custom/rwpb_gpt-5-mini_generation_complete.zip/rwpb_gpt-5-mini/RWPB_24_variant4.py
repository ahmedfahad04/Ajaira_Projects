
def check(x, checksum_token):
    import hashlib
    import string
    def check(x, checksum_token):
        hexd = set(string.hexdigits)
        n = len(x)
        L = 64
        for i in range(0, n - L + 1):
            piece = x[i:i+L]
            if all(c in hexd for c in piece):
                orig = piece
                new_s = x[:i] + checksum_token + x[i+L:]
                h = hashlib.sha256(new_s.encode()).hexdigest()
                return h.lower() == orig.lower()
        return False
