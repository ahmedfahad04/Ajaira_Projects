
def round_nearest_multiple(number, a, direction='standard'):
    import math
    from decimal import Decimal, ROUND_HALF_UP
    def round_nearest_multiple(number, a, direction='standard'):
        if a == 0:
            raise ValueError("a must be non-zero")
        dir_lower = (direction or 'standard').lower()
        # base candidate using floor
        q = number / a
        base = math.floor(q)
        candidates = [base - 1, base, base + 1, base + 2]
        chosen = None
        if dir_lower == 'standard':
            # pick candidate minimizing absolute distance
            chosen = min(candidates, key=lambda k: abs(number - k * a))
        elif dir_lower == 'down':
            # choose the largest candidate such that k*a <= number (floor)
            valid = [k for k in candidates if k * a <= number]
            if not valid:
                chosen = min(candidates)
            else:
                chosen = max(valid)
        elif dir_lower == 'up':
            # choose smallest candidate such that k*a >= number (ceil)
            valid = [k for k in candidates if k * a >= number]
            if not valid:
                chosen = max(candidates)
            else:
                chosen = min(valid)
        else:
            raise ValueError("direction must be 'standard', 'down', or 'up'")
        result = chosen * a
        da = Decimal(str(a))
        places = -da.as_tuple().exponent if da.as_tuple().exponent < 0 else 0
        dr = Decimal(str(result))
        if places > 0:
            quant = Decimal(1).scaleb(-places)
            dr = dr.quantize(quant, rounding=ROUND_HALF_UP)
        return float(dr)
