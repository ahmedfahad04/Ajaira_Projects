
def path_spliter(path: str):
    def path_spliter(path: str):
        if path is None:
            return []
        s = str(path)
        if s == '':
            return []
        n = len(s)
        i = 0
        parts = []
        # Drive letter
        if n >= 2 and s[1] == ':' and s[0].isalpha():
            parts.append(s[:2])
            i = 2
        # Detect leading separators (one or more)
        if i < n and s[i] in ('/', '\\'):
            # UNC if two backslashes at start
            if s.startswith('\\\\') or s.startswith('//'):
                # treat the initial double separator as a single UNC root marker
                parts.append('\\\\')
                # skip all leading slashes/backslashes
                while i < n and s[i] in ('/', '\\'):
                    i += 1
            else:
                parts.append(s[i])  # single separator (will be '/' or '\')
                while i < n and s[i] in ('/', '\\'):
                    i += 1
        cur = []
        while i < n:
            ch = s[i]
            if ch in ('/', '\\'):
                if cur:
                    parts.append(''.join(cur))
                    cur = []
                # skip consecutive separators
                while i < n and s[i] in ('/', '\\'):
                    i += 1
                continue
            cur.append(ch)
            i += 1
        if cur:
            parts.append(''.join(cur))
        return parts
