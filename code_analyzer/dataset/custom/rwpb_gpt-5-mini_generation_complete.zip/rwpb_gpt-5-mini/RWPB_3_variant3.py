
def get_focalLength_from_fieldOfView(fov=60, img_size=512):
    import math
    def get_focalLength_from_fieldOfView(fov=60, img_size=512):
        """
        Strict version using math: validates fov in (0,180) degrees and returns focal in pixels.
        """
        if not (0.0 < fov < 180.0):
            raise ValueError("fov must be between 0 and 180 degrees (exclusive)")
        rad = math.radians(fov)
        return (float(img_size) / 2.0) / math.tan(rad / 2.0)
