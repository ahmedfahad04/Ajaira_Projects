
def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
    import torch
    def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
        # Validate num
        if num <= 0:
            return torch.empty(*torch.broadcast_shapes(start.shape, stop.shape), 0, device=start.device, dtype=torch.promote_types(start.dtype, stop.dtype))
        dtype = torch.promote_types(start.dtype, stop.dtype)
        start = start.to(dtype)
        stop = stop.to(dtype)
        # If single sample, return start (as first point)
        if num == 1:
            return start.unsqueeze(-1)
        # Build list of interpolated tensors and stack
        out_list = []
        for i in range(num):
            t = float(i) / float(num - 1)
            # compute weighted sum using Python float (will be converted to tensor op)
            out_list.append(start * (1.0 - t) + stop * t)
        return torch.stack(out_list, dim=-1)
