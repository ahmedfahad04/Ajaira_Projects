
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.array(a, dtype=float)
        b = np.array(b, dtype=float)
        eps = 1e-10
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na < eps or nb < eps:
            return None, None
        ua = a / na
        ub = b / nb
        cross = np.cross(ua, ub)
        cross_norm = np.linalg.norm(cross)
        dot = np.dot(ua, ub)
        dot = np.clip(dot, -1.0, 1.0)
        if cross_norm <= eps:
            # Parallel or anti-parallel
            if dot > 0:
                return None, None
            else:
                # 180 degree rotation; find any orthogonal axis
                # choose basis axis that is least aligned with ua
                absua = np.abs(ua)
                if absua[0] <= absua[1] and absua[0] <= absua[2]:
                    v = np.array([1.0, 0.0, 0.0])
                elif absua[1] <= absua[2]:
                    v = np.array([0.0, 1.0, 0.0])
                else:
                    v = np.array([0.0, 0.0, 1.0])
                axis = np.cross(ua, v)
                axis /= np.linalg.norm(axis)
                return axis, np.pi
        else:
            axis = cross / cross_norm
            # angle via arccos
            angle = np.arccos(dot)
            return axis, angle
