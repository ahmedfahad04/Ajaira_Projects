
def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
    from typing import Callable, Dict, Tuple, Any
    import inspect
    from functools import partial
    def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
        if not callable(func):
            raise TypeError("func must be callable")
        try:
            if isinstance(func, partial):
                sig = inspect.signature(func)
            else:
                sig = inspect.signature(func)
        except (TypeError, ValueError):
            return partial(func), {}
        names = []
        for name, p in sig.parameters.items():
            if p.kind == inspect.Parameter.POSITIONAL_ONLY:
                continue
            if p.kind == inspect.Parameter.VAR_POSITIONAL:
                continue
            names.append(name)
        has_varkw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
        applicable = {}
        for k, v in params.items():
            if not isinstance(k, str):
                continue
            if has_varkw or k in names:
                applicable[k] = v
        return partial(func, **applicable), applicable
