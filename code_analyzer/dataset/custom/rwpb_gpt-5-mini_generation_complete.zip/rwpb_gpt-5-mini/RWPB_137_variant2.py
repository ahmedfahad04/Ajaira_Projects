
def fit_params(:
    def fit_params(
        x,
        y,
        fun,
        a_range=(-10, 10),
        b_range=(-10, 10),
        grid_number=101,
        iteration=3,
        verbose=True,
    ):
        import numpy as np
        import torch
        # Vectorized grid approach using sum formulas to compute c,d for all grid points at once
        # Convert to numpy
        if torch.is_tensor(x):
            x_np = x.detach().cpu().numpy()
        else:
            x_np = np.asarray(x)
        if torch.is_tensor(y):
            y_np = y.detach().cpu().numpy()
        else:
            y_np = np.asarray(y)
        n = x_np.size
        a_min, a_max = float(a_range[0]), float(a_range[1])
        b_min, b_max = float(b_range[0]), float(b_range[1])
        best_r2 = -np.inf
        best_params = None
        for it in range(iteration):
            G = grid_number
            a_vals = np.linspace(a_min, a_max, G)
            b_vals = np.linspace(b_min, b_max, G)
            # broadcast to compute z for all (a,b)
            A = a_vals.reshape(G, 1, 1)
            B = b_vals.reshape(1, G, 1)
            X = x_np.reshape(1, 1, n)
            ABX = A * X + B  # shape (G, G, n)
            # apply fun elementwise; fun might be numpy or torch function
            Z = np.asarray(fun(ABX))
            # compute sums over axis=2 (over x)
            S_z = Z.sum(axis=2)
            S_zz = (Z * Z).sum(axis=2)
            S_y = y_np.sum()
            S_zy = (Z * y_np.reshape(1, 1, n)).sum(axis=2)
            denom = n * S_zz - S_z * S_z
            eps = 1e-12
            denom_safe = np.where(np.abs(denom) < eps, eps, denom)
            c = (n * S_zy - S_z * S_y) / denom_safe
            d = (S_y - c * S_z) / n
            # if denom was near zero, set c=0,d=mean(y)
            mean_y = S_y / n
            mask_const = np.abs(denom) < eps
            c[mask_const] = 0.0
            d[mask_const] = mean_y
            # compute predictions and r2
            y_pred = c[..., None] * Z + d[..., None]
            ss_res = ((y_np.reshape(1, 1, n) - y_pred) ** 2).sum(axis=2)
            ss_tot = ((y_np - y_np.mean()) ** 2).sum()
            r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else np.where(ss_res == 0, 1.0, -np.inf)
            # find best
            idx = np.unravel_index(np.nanargmax(r2), r2.shape)
            val = r2[idx]
            if val > best_r2:
                best_r2 = float(val)
                best_params = (float(a_vals[idx[0]]), float(b_vals[idx[1]]), float(c[idx]), float(d[idx]))
            # refine ranges
            a_center, b_center = best_params[0], best_params[1]
            span_a = (a_max - a_min) / 10.0
            span_b = (b_max - b_min) / 10.0
            a_min = a_center - span_a
            a_max = a_center + span_a
            b_min = b_center - span_b
            b_max = b_center + span_b
            if verbose:
                print(f"Iter {it+1}/{iteration}, best r2={best_r2:.6f}, a={best_params[0]}, b={best_params[1]}")
        import torch as _torch
        a_best, b_best, c_best, d_best = best_params
        return _torch.tensor([a_best, b_best, c_best, d_best], dtype=_torch.float64), _torch.tensor(best_r2, dtype=_torch.float64)
