
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        if normal_map.ndim != 3 or normal_map.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        theta = np.deg2rad(angle)
        c = np.cos(theta)
        s = np.sin(theta)
        h, w, _ = normal_map.shape
        out = np.empty((h, w, 3), dtype=np.float64)
        src = np.asarray(normal_map, dtype=np.float64)
        for i in range(h):
            for j in range(w):
                x, y, z = src[i, j]
                xr = c * x + s * z
                yr = y
                zr = -s * x + c * z
                out[i, j, 0] = xr
                out[i, j, 1] = yr
                out[i, j, 2] = zr
        # normalize
        norm = np.sqrt((out ** 2).sum(axis=2))
        eps = 1e-12
        for i in range(h):
            for j in range(w):
                n = norm[i, j]
                if n > eps:
                    out[i, j] /= n
        return out.astype(normal_map.dtype)
