
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        # convert to arrays and coerce shapes
        a = np.array(a, dtype=float)
        b = np.array(b, dtype=float)
        if a.ndim != 1:
            return KeyError("a must be a vector")
        def _single_cos(x, y):
            ax = np.linalg.norm(x)
            ay = np.linalg.norm(y)
            if ax == 0 or ay == 0:
                return float('nan')
            sim = np.dot(x, y) / (ax * ay)
            sim = np.clip(sim, -1.0, 1.0)
            return 1.0 - sim
        if b.ndim == 1:
            if b.shape[0] != a.shape[0]:
                return KeyError("length mismatch")
            return float(_single_cos(a, b))
        elif b.ndim == 2:
            if b.shape[1] != a.shape[0]:
                return KeyError("length mismatch")
            # normalize first to speed up dot products
            a_norm = np.linalg.norm(a)
            if a_norm == 0:
                return KeyError("zero vector a")
            a_unit = a / a_norm
            b_norms = np.linalg.norm(b, axis=1)
            # avoid division by zero; produce nan for zero rows
            b_unit = np.divide(b, b_norms[:, None], out=np.zeros_like(b), where=b_norms[:, None] != 0)
            cos_sims = b_unit.dot(a_unit)
            cos_sims = np.clip(cos_sims, -1.0, 1.0)
            dists = 1.0 - cos_sims
            # set nan where b_norms == 0
            dists = np.where(b_norms == 0, np.nan, dists)
            return dists
        else:
            return KeyError("unsupported b dimensionality")
