
def getLambertCoefs(numOfLambertCoefs):
    from math import factorial
    def getLambertCoefs(numOfLambertCoefs):
        if not isinstance(numOfLambertCoefs, int) or numOfLambertCoefs <= 0:
            return []
        coefs = []
        for n in range(1, numOfLambertCoefs + 1):
            # a_n = (-n)^(n-1) / n!
            num = (-n) ** (n - 1)
            den = factorial(n)
            coefs.append(num / den)
        return coefs
