
def extract_code_from_funct(funct: Callable) -> List[str]:
    from typing import Callable, List
    import inspect
    def extract_code_from_funct(funct: Callable) -> List[str]:
        lines, _ = inspect.getsourcelines(funct)
        # find def line index (skip decorators)
        def_idx = None
        for i, ln in enumerate(lines):
            if ln.lstrip().startswith("def ") or ln.lstrip().startswith("async def "):
                def_idx = i
                break
        if def_idx is None:
            return []
        # find end of signature by tracking parentheses depth and colon
        idx = def_idx
        depth = 0
        while idx < len(lines):
            ln = lines[idx]
            depth += ln.count("(") - ln.count(")")
            if ln.rstrip().endswith(":") and depth <= 0:
                break
            idx += 1
        body = lines[idx+1:]
        if not body:
            return []
        # compute minimum indentation of non-blank body lines
        min_indent = None
        for ln in body:
            stripped = ln.lstrip("\r\n")
            if stripped.strip() == "":
                continue
            leading = len(ln) - len(ln.lstrip(" \t"))
            if min_indent is None or leading < min_indent:
                min_indent = leading
        if min_indent is None:
            return []
        cleaned = []
        for ln in body:
            # remove min_indent spaces/tabs if present
            if ln.strip() == "":
                cleaned.append("")
            else:
                # remove up to min_indent chars from left
                i = 0
                removed = 0
                while removed < min_indent and i < len(ln) and ln[i] in (" ", "\t"):
                    i += 1
                    removed += 1
                cleaned.append(ln[i:].rstrip("\n"))
        # strip leading/trailing blank lines
        while cleaned and cleaned[0].strip() == "":
            cleaned.pop(0)
        while cleaned and cleaned[-1].strip() == "":
            cleaned.pop()
        # remove trailing return statement if present
        if cleaned:
            last = cleaned[-1].lstrip()
            if last.startswith("return"):
                cleaned.pop()
                while cleaned and cleaned[-1].strip() == "":
                    cleaned.pop()
        return cleaned
