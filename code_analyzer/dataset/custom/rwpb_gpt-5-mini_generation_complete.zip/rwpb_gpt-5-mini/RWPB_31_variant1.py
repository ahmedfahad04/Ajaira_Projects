
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        n = tensor.shape[0]
        if n == batch_size:
            return tensor
        device = tensor.device
        dtype = tensor.dtype
        # positions in source space
        positions = torch.linspace(0, n - 1, steps=batch_size, device=device)
        floor_idx = positions.floor().long().clamp(min=0, max=max(n - 1, 0))
        ceil_idx = positions.ceil().long().clamp(min=0, max=max(n - 1, 0))
        weights = (positions - floor_idx.to(positions)).to(dtype)
        # gather
        front = tensor[floor_idx]
        back = tensor[ceil_idx]
        # reshape weights to broadcast across remaining dims
        if weights.dim() == 1:
            shape = [batch_size] + [1] * (tensor.dim() - 1)
            w = weights.view(*shape).to(dtype)
        else:
            w = weights.to(dtype)
        # if indices are equal, back==front; formula still works
        out = front.to(dtype) * (1 - w) + back.to(dtype) * w
        # cast back to original dtype if necessary
        if out.dtype != dtype:
            out = out.to(dtype)
        return out
