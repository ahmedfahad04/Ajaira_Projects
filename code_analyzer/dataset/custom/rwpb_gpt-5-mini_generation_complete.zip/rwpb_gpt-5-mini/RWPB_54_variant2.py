
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        # sanitize input and allow x>x1 or y>y1
        x, y, x1, y1 = box
        x, y, x1, y1 = float(x), float(y), float(x1), float(y1)
        if x1 < x:
            x, x1 = x1, x
        if y1 < y:
            y, y1 = y1, y
        if expand is None:
            expand = 1.0
        expand = float(expand)
        if expand <= 0:
            # degenerate: return original box and half-size based on original
            w = x1 - x
            h = y1 - y
            s = max(w, h) / 2.0
            return [x, y, x1, y1], s
        cx = (x + x1) / 2.0
        cy = (y + y1) / 2.0
        w = x1 - x
        h = y1 - y
        new_w = w * expand
        new_h = h * expand
        # return integer pixel box (rounded) for practical usage
        new_x = int(round(cx - new_w / 2.0))
        new_y = int(round(cy - new_h / 2.0))
        new_x1 = int(round(cx + new_w / 2.0))
        new_y1 = int(round(cy + new_h / 2.0))
        s = max(new_w, new_h) / 2.0
        return [new_x, new_y, new_x1, new_y1], s
