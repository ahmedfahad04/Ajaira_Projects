
def rotate_normalmap_by_angle_torch(normal_map, angle):
    import torch, math
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        # Accept (H,W,3) or (...,3)
        if not isinstance(normal_map, torch.Tensor):
            raise TypeError("normal_map must be a torch.Tensor")
        device = normal_map.device
        dtype = normal_map.dtype
        # Build rotation matrix R (3x3) on same device and dtype
        theta = math.radians(angle)
        c = float(math.cos(theta))
        s = float(math.sin(theta))
        R = torch.tensor([[c, 0.0, s],
                          [0.0, 1.0, 0.0],
                          [-s, 0.0, c]], device=device, dtype=dtype)
        # Flatten vectors, matrix multiply, then reshape back
        orig_shape = normal_map.shape
        if orig_shape[-1] != 3:
            raise ValueError("last dimension must be 3")
        flat = normal_map.reshape(-1, 3)
        # row-vector multiply: v' = v @ R.T  (equivalent to R @ v_col)
        rotated_flat = torch.matmul(flat, R.t())
        rotated = rotated_flat.reshape(orig_shape)
        # Ensure numerical stability: normalize
        norms = rotated.norm(dim=-1, keepdim=True).clamp(min=1e-8)
        rotated = rotated / norms
        return rotated
