
def euler2rot(euler_angle):
    import torch
    def euler2rot(euler_angle):
        if not torch.is_tensor(euler_angle):
            euler_angle = torch.tensor(euler_angle)
        a = euler_angle
        if a.dim() == 1:
            a = a.unsqueeze(0)
        x = a[:,0]; y = a[:,1]; z = a[:,2]
        cx = torch.cos(x); sx = torch.sin(x)
        cy = torch.cos(y); sy = torch.sin(y)
        cz = torch.cos(z); sz = torch.sin(z)
        batch = a.shape[0]
        Rx = torch.zeros(batch,3,3, dtype=a.dtype, device=a.device)
        Ry = torch.zeros_like(Rx); Rz = torch.zeros_like(Rx)
        Rx[:,0,0] = 1; Rx[:,1,1] = cx; Rx[:,1,2] = -sx; Rx[:,2,1] = sx; Rx[:,2,2] = cx
        Ry[:,0,0] = cy; Ry[:,0,2] = sy; Ry[:,1,1] = 1; Ry[:,2,0] = -sy; Ry[:,2,2] = cy
        Rz[:,0,0] = cz; Rz[:,0,1] = -sz; Rz[:,1,0] = sz; Rz[:,1,1] = cz; Rz[:,2,2] = 1
        R = torch.bmm(Rz, torch.bmm(Ry, Rx))
        return R
