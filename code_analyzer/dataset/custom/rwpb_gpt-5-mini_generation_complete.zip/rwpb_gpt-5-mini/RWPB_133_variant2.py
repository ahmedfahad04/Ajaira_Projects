
def divide_to_patches(image, patch_size):
    from PIL import Image
    def divide_to_patches(image, patch_size):
        if not isinstance(patch_size, int) or patch_size <= 0:
            raise ValueError("patch_size must be a positive integer")
        w, h = image.size
        patches = []
        for y in range(0, h, patch_size):
            y2 = min(y + patch_size, h)
            for x in range(0, w, patch_size):
                x2 = min(x + patch_size, w)
                patches.append(image.crop((x, y, x2, y2)))
        return patches
