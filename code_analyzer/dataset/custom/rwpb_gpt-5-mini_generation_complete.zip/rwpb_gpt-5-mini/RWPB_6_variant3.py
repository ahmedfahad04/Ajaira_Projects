
def format_seconds(seconds: float) -> str:
    def format_seconds(seconds: float) -> str:
        from datetime import timedelta
        import math
        if not isinstance(seconds, (int, float)):
            raise TypeError("seconds must be a number")
        if not (seconds == seconds) or seconds == float('inf') or seconds == float('-inf'):
            raise ValueError("seconds must be a finite number")
        neg = seconds < 0
        td = timedelta(seconds=abs(seconds))
        # Use total seconds with rounding to milliseconds to avoid float precision issues
        total_millis = int(round(td.total_seconds() * 1000))
        hours = total_millis // 3600000
        rem = total_millis % 3600000
        minutes = rem // 60000
        rem = rem % 60000
        secs = rem // 1000
        millis = rem % 1000
        sign = "-" if neg else ""
        if hours >= 1:
            return f"{sign}{hours:02d}:{minutes:02d}:{secs:02d}.{millis:03d}"
        else:
            return f"{sign}{minutes:02d}:{secs:02d}.{millis:03d}"
