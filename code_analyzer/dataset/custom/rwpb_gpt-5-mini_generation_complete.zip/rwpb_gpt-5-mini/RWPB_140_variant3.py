
def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
    from typing import Callable, Dict, Tuple, Any
    import inspect
    from functools import partial
    def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
        try:
            sig = inspect.signature(func)
        except (TypeError, ValueError):
            return partial(func), {}
        applicable = {}
        for name, param in sig.parameters.items():
            if param.kind == inspect.Parameter.VAR_KEYWORD:
                for k, v in params.items():
                    if isinstance(k, str):
                        applicable[k] = v
                break
        else:
            for k, v in params.items():
                if not isinstance(k, str):
                    continue
                p = sig.parameters.get(k)
                if p is None:
                    continue
                if p.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.VAR_POSITIONAL):
                    continue
                applicable[k] = v
        return partial(func, **applicable), applicable
