
def path_spliter(path: str):
    import re
    def path_spliter(path: str):
        if path is None:
            return []
        s = str(path)
        if s == '':
            return []
        # Detect UNC
        unc = False
        if s.startswith('\\\\') or s.startswith('//'):
            unc = True
        # Detect drive letter
        m = re.match(r'^([A-Za-z]:)', s)
        drive = m.group(1) if m else None
        # Split by any number of slashes or backslashes
        tokens = re.split(r'[\\/]+', s)
        # Filter out empty tokens produced by split
        tokens = [t for t in tokens if t != '']
        parts = []
        idx = 0
        if drive:
            parts.append(drive)
            # If drive is followed by a separator in original, convert to drive+sep
            after = s[len(drive):len(drive)+1]
            if after in ('/', '\\'):
                parts[-1] = drive + after
        elif unc:
            parts.append('\\\\')
        # Append the rest tokens skipping drive token if it was included in tokens
        if drive:
            # remove leading token that equals drive without sep if present in tokens
            if tokens and tokens[0].upper().startswith(drive.upper()):
                tokens = tokens[1:]
        parts.extend(tokens)
        return parts
