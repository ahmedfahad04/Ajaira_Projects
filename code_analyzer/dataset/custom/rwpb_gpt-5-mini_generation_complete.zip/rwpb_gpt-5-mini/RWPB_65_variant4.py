
def merge_dicts_recursively(*dicts):
    import copy
    def merge_dicts_recursively(*dicts):
        result = {}
        for d in dicts:
            if not isinstance(d, dict):
                continue
            stack = [(result, d)]
            while stack:
                target, src = stack.pop()
                for k, v in src.items():
                    if k in target and isinstance(target[k], dict) and isinstance(v, dict):
                        stack.append((target[k], v))
                    else:
                        target[k] = copy.deepcopy(v)
        return result
