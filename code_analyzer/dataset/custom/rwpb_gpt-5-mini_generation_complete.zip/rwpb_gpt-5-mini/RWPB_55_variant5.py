
def numpy_to_pytorch(x):
    import numpy as np
    import torch
    def numpy_to_pytorch(x):
        x = np.asarray(x)
        x = (x.astype(np.float32) / 255.0)
        x = np.ascontiguousarray(np.expand_dims(x, axis=0))
        return torch.from_numpy(x).type(torch.float32)
