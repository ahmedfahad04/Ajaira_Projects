
def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
    import numpy as np
    def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
        plane_normal = np.asarray(plane_normal, dtype=float).reshape(-1)
        plane_point = np.asarray(plane_point, dtype=float).reshape(-1)
        ray_direction = np.asarray(ray_direction, dtype=float).reshape(-1)
        ray_point = np.asarray(ray_point, dtype=float).reshape(-1)
        if np.allclose(ray_direction, 0):
            return None
        denom = np.dot(plane_normal, ray_direction)
        if abs(denom) < 1e-12:
            return None
        t = np.dot(plane_normal, (plane_point - ray_point)) / denom
        intersection = ray_point + t * ray_direction
        return np.asarray(intersection, dtype=float)
