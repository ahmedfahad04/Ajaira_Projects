
def xywh2xyxy(x):
    import numpy as np
    import torch
    def xywh2xyxy(x):
        if torch.is_tensor(x):
            if x.shape[-1] != 4:
                raise ValueError("Last dimension must be 4")
            x0 = x[..., 0]
            y0 = x[..., 1]
            x2 = x[..., 0] + x[..., 2]
            y2 = x[..., 1] + x[..., 3]
            return torch.stack((x0, y0, x2, y2), dim=-1)
        else:
            x = np.asarray(x)
            if x.shape[-1] != 4:
                raise ValueError("Last dimension must be 4")
            x0 = x[..., 0]
            y0 = x[..., 1]
            x2 = x[..., 0] + x[..., 2]
            y2 = x[..., 1] + x[..., 3]
            return np.stack((x0, y0, x2, y2), axis=-1)
