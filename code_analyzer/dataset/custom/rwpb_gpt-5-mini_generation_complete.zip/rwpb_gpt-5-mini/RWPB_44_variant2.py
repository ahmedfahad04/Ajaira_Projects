
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        if tensor1.shape[0] != tensor2.shape[0]:
            raise ValueError("First dimension sizes must match")
        N = tensor1.shape[0]
        rest = tensor1.shape[1:]
        out_shape = (2 * N,) + rest
        out1 = torch.empty(out_shape, dtype=tensor1.dtype, device=tensor1.device)
        out2 = torch.empty(out_shape, dtype=tensor1.dtype, device=tensor1.device)
        out1[0::2] = tensor1
        out1[1::2] = tensor2
        out2[0::2] = tensor2
        out2[1::2] = tensor1
        return out1, out2
