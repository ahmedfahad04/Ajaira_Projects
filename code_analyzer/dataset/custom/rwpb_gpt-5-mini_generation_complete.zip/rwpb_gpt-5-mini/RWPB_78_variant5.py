
def check_all_columns_numeric(df):
    import pandas as pd
    def check_all_columns_numeric(df):
        """
        Attempt to cast the entire DataFrame to float. If casting fails,
        at least one column is non-numeric.
        """
        if df is None:
            return False
        if df.shape[1] == 0:
            return True
        try:
            df.astype(float)
            return True
        except (ValueError, TypeError):
            return False
