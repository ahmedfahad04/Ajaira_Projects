
def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        """
        Uses grid_sample but assumes input grid might already be in (N, C, D, H, W) form or (1, C, H, W, D).
        Also accepts coordinates either in voxel indices or normalized [-1,1]; attempts to auto-detect and handle both.
        Coordinates ordering: (x, y, z).
        """
        if grid.ndim != 5:
            raise ValueError("Grid must be 5D")
        B, P, _ = coordinates.shape
        coords = coordinates.clone()
        # Determine if grid is (N, C, D, H, W) or (1, C, H, W, D)
        # Heuristic: if the third dim equals the last dim, treat as (N,C,D,H,W)
        if grid.shape[2] == grid.shape[4]:
            # Ambiguous but assume (N, C, D, H, W)
            grid_perm = grid
            _, _, D, H, W = grid_perm.shape
        else:
            # assume provided spec (1, C, H, W, D) -> permute to (N, C, D, H, W)
            grid_perm = grid.permute(0, 1, 4, 2, 3).contiguous()
            _, _, D, H, W = grid_perm.shape
        # Decide if coords are normalized: if all in [-1,1], treat as normalized
        if coords.min() >= -1.0 and coords.max() <= 1.0:
            # normalized already, but ensure order is (x,y,z)
            x = coords[..., 0]
            y = coords[..., 1]
            z = coords[..., 2]
            x_norm = x
            y_norm = y
            z_norm = z
        else:
            # assume voxel indices, convert to normalized [-1,1] with align_corners=True
            coords = coords.to(dtype=grid.dtype, device=grid.device)
            def norm(coord, size):
                if size == 1:
                    return torch.zeros_like(coord)
                return 2.0 * coord / (size - 1) - 1.0
            x_norm = norm(coords[..., 0], W)
            y_norm = norm(coords[..., 1], H)
            z_norm = norm(coords[..., 2], D)
        sample_grid = torch.stack((x_norm, y_norm, z_norm), dim=-1).view(B, P, 1, 1, 3)
        # Expand grid to batch if necessary
        if grid_perm.shape[0] == 1 and B > 1:
            grid_in = grid_perm.expand(B, -1, -1, -1, -1).contiguous()
        else:
            grid_in = grid_perm
        sampled = F.grid_sample(grid_in, sample_grid, mode='bilinear', padding_mode='border', align_corners=True)
        sampled = sampled.view(sampled.shape[0], sampled.shape[1], -1).permute(0, 2, 1).contiguous()
        return sampled
