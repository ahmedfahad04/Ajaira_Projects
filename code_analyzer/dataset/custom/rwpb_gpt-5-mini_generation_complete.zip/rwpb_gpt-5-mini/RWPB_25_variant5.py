
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        arr = np.asarray(img)
        if arr.ndim != 2:
            raise ValueError("Input must be grayscale")
        img_u8 = (arr.copy()).astype(np.uint8)
        # Binary mask of foreground
        _, bin_img = cv2.threshold(img_u8, 0, 255, cv2.THRESH_BINARY)
        # Pad to ensure floodfill from border works for objects touching edges
        pad = 1
        padded = cv2.copyMakeBorder(bin_img, pad, pad, pad, pad, cv2.BORDER_CONSTANT, value=0)
        # Invert padded image and floodfill from (0,0)
        inv = cv2.bitwise_not(padded)
        flood = inv.copy()
        h, w = flood.shape
        mask = np.zeros((h + 2, w + 2), np.uint8)
        cv2.floodFill(flood, mask, (0, 0), 255)
        # Flood now contains external background filled white. Invert to get holes.
        holes = cv2.bitwise_not(flood)
        # Remove padding from holes
        holes = holes[pad:pad + bin_img.shape[0], pad:pad + bin_img.shape[1]]
        # Combine original with holes
        filled = cv2.bitwise_or(bin_img, holes)
        return filled.astype(np.uint8)
