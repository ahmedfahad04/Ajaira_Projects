
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return original_size
        ow, oh = original_size
        best = None
        best_metric = None
        for w, h in possible_resolutions:
            if ow == 0 or oh == 0:
                metric = float('inf')
            else:
                required_scale = max(w / ow if ow else float('inf'), h / oh if oh else float('inf'))
                metric = required_scale
            if best is None or metric < best_metric:
                best = (w, h)
                best_metric = metric
            elif metric == best_metric:
                if w * h > best[0] * best[1]:
                    best = (w, h)
        return best
