
def dynamic_import_function(function_path):
    def dynamic_import_function(function_path):
        from importlib import import_module
        from functools import reduce
        if not isinstance(function_path, str) or not function_path:
            return ModuleNotFoundError("Invalid function path")
        parts = function_path.split('.')
        for split_point in range(len(parts) - 1, 0, -1):
            module_name = '.'.join(parts[:split_point])
            attrs = parts[split_point:]
            try:
                mod = import_module(module_name)
            except Exception:
                continue
            try:
                obj = reduce(getattr, attrs, mod)
                return obj
            except Exception:
                continue
        return ModuleNotFoundError(f"Module or attribute not found for '{function_path}'")
