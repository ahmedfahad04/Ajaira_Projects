
def isprime(n):
    import math
    def isprime(n):
        if not isinstance(n, int):
            return False
        if n <= 1:
            return False
        if n <= 3:
            return True
        if n % 2 == 0:
            return False
        limit = math.isqrt(n)
        sieve = bytearray(b'\x01') * (limit + 1)
        sieve[0:2] = b'\x00\x00'
        p = 2
        while p * p <= limit:
            if sieve[p]:
                step = p
                start = p * p
                sieve[start:limit+1:step] = b'\x00' * (((limit - start) // step) + 1)
            p += 1
        for p in range(2, limit + 1):
            if sieve[p] and n % p == 0:
                return False
        return True
