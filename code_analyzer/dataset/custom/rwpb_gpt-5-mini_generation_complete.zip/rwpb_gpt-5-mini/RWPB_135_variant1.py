
def mask_iou(mask1, mask2, eps=1e-7):
    import torch
    def mask_iou(mask1, mask2, eps=1e-7):
        """
        Vectorized using matrix multiplication.
        """
        if not isinstance(mask1, torch.Tensor) or not isinstance(mask2, torch.Tensor):
            raise TypeError("mask1 and mask2 must be torch.Tensors")
        if mask1.ndim != 2 or mask2.ndim != 2:
            raise ValueError("mask1 and mask2 must be 2-D tensors")
        N, n1 = mask1.shape
        M, n2 = mask2.shape
        if n1 != n2:
            raise ValueError("mask1 and mask2 must have the same number of columns")
        if N == 0 or M == 0:
            return torch.zeros((N, M), dtype=mask1.dtype, device=mask1.device)
        # Convert to float for matmul
        m1 = mask1.float()
        m2 = mask2.float()
        # intersection via matrix multiplication
        inter = m1 @ m2.t()
        area1 = m1.sum(dim=1)  # (N,)
        area2 = m2.sum(dim=1)  # (M,)
        union = area1.unsqueeze(1) + area2.unsqueeze(0) - inter
        # Avoid division by zero
        iou = inter / (union + eps)
        # where union is zero set IoU to zero
        mask_zero = union <= 0
        if mask_zero.any():
            iou = iou.masked_fill(mask_zero, 0.0)
        return iou
