
def interpolate_features(features,:
    import numpy as np
    def interpolate_features(features, input_rate, output_rate, output_len):
        features = np.asarray(features)
        if output_len <= 0:
            if features.ndim == 1:
                return np.zeros((0,), dtype=features.dtype)
            return np.zeros((0, features.shape[1]), dtype=features.dtype)
        if features.ndim == 1:
            features = features[:, None]
            squeeze = True
        else:
            squeeze = False
        T, D = features.shape
        if T == 0:
            out = np.zeros((output_len, D), dtype=features.dtype)
            return out.ravel() if squeeze else out
        if T == 1:
            out = np.tile(features[0:1, :], (output_len, 1))
            return out.ravel() if squeeze else out
        positions = np.arange(output_len) * (input_rate / float(output_rate))
        positions = np.clip(positions, 0.0, T - 1.0)
        def interp_col(col):
            return np.interp(positions, np.arange(T), col)
        out = np.apply_along_axis(interp_col, 0, features).T
        out = out.astype(features.dtype, copy=False)
        return out.ravel() if squeeze else out
