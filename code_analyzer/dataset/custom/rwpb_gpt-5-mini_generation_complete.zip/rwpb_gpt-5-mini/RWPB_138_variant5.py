
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        if normal_map.ndim != 3 or normal_map.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        theta = np.deg2rad(angle)
        k = np.array([0.0, 1.0, 0.0], dtype=np.float64)  # rotation axis (y)
        nm = np.asarray(normal_map, dtype=np.float64)
        cos_t = np.cos(theta)
        sin_t = np.sin(theta)
        # Rodrigues' rotation: v*cos + (k x v)*sin + k*(k·v)*(1-cos)
        v = nm
        k_dot_v = (v * k).sum(axis=-1, keepdims=True)
        # cross product k x v
        cross = np.empty_like(v)
        cross[..., 0] = k[1] * v[..., 2] - k[2] * v[..., 1]
        cross[..., 1] = k[2] * v[..., 0] - k[0] * v[..., 2]
        cross[..., 2] = k[0] * v[..., 1] - k[1] * v[..., 0]
        rotated = v * cos_t + cross * sin_t + k * (k_dot_v * (1.0 - cos_t))
        norm = np.linalg.norm(rotated, axis=-1, keepdims=True)
        eps = 1e-12
        rotated = rotated / np.where(norm > eps, norm, 1.0)
        return rotated.astype(normal_map.dtype)
