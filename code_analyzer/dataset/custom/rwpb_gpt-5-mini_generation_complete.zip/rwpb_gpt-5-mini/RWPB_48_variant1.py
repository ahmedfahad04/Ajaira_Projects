
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return original_size
        ow, oh = original_size
        orig_area = ow * oh
        best = None
        best_key = None
        for w, h in possible_resolutions:
            area = w * h
            area_diff = abs(area - orig_area)
            dim_diff = max(abs(w - ow), abs(h - oh))
            key = (area_diff, dim_diff)
            if best is None or key < best_key:
                best = (w, h)
                best_key = key
        return best
