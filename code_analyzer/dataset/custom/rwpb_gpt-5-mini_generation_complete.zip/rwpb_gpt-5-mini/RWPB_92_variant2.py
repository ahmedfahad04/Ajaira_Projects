
def round(number, num_decimal_places, leave_int=False):
    import math
    def round(number, num_decimal_places, leave_int=False):
        # Work with Python floats/ints directly, implement "half away from zero"
        if not isinstance(number, (int, float)):
            # Try to coerce
            number = float(number)
        n = int(num_decimal_places)
        if n >= 0:
            scale = 10 ** n
            scaled = number * scale
            # Handle rounding half away from zero robustly
            if scaled >= 0:
                rounded_scaled = math.floor(scaled + 0.5)
            else:
                rounded_scaled = math.ceil(scaled - 0.5)
            result = rounded_scaled / scale
        else:
            # For negative decimal places, round to tens/hundreds/etc.
            scale = 10 ** (-n)
            scaled = number / scale
            if scaled >= 0:
                rounded_scaled = math.floor(scaled + 0.5)
            else:
                rounded_scaled = math.ceil(scaled - 0.5)
            result = rounded_scaled * scale
        # Return int if requested and result is integral
        if leave_int and float(result).is_integer():
            return int(result)
        return float(result)
