
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        if a.shape != (3,) or b.shape != (3,):
            a = a.ravel()[:3]
            b = b.ravel()[:3]
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na == 0 or nb == 0:
            return (None, None)
        u = a / na
        v = b / nb
        if np.allclose(u, v):
            return (None, None)
        # cross product gives axis direction
        cross = np.cross(u, v)
        s = np.linalg.norm(cross)
        dot = np.dot(u, v)
        # opposite vectors
        if s < 1e-12 and dot < 0:
            # find any vector orthogonal to u
            idx = np.argmin(np.abs(u))
            tmp = np.zeros(3)
            tmp[idx] = 1.0
            axis = np.cross(u, tmp)
            axis = axis / np.linalg.norm(axis)
            angle = np.pi
            return (axis, angle)
        axis = cross / s
        # angle via arccos (clipped)
        angle = np.arccos(np.clip(dot, -1.0, 1.0))
        return (axis, angle)
