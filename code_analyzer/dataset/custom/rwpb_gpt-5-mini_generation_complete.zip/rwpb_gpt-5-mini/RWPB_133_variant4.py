
def divide_to_patches(image, patch_size):
    from PIL import Image
    import numpy as np
    def divide_to_patches(image, patch_size):
        if not isinstance(patch_size, int) or patch_size <= 0:
            raise ValueError("patch_size must be a positive integer")
        arr = np.array(image)
        if arr.ndim == 2:
            h, w = arr.shape
            channels = 1
        else:
            h, w, channels = arr.shape
        pad_h = (-h) % patch_size
        pad_w = (-w) % patch_size
        if pad_h != 0 or pad_w != 0:
            if channels == 1:
                arr = np.pad(arr, ((0, pad_h), (0, pad_w)), mode='constant', constant_values=0)
            else:
                arr = np.pad(arr, ((0, pad_h), (0, pad_w), (0, 0)), mode='constant', constant_values=0)
            h += pad_h
            w += pad_w
        patches = []
        for y in range(0, h, patch_size):
            for x in range(0, w, patch_size):
                tile = arr[y:y + patch_size, x:x + patch_size] if channels == 1 else arr[y:y + patch_size, x:x + patch_size, :]
                if channels == 1:
                    img = Image.fromarray(tile.astype('uint8'), mode='L')
                else:
                    mode = image.mode if image.mode in ('RGB', 'RGBA') else 'RGB'
                    img = Image.fromarray(tile.astype('uint8'), mode=mode)
                patches.append(img)
        return patches
