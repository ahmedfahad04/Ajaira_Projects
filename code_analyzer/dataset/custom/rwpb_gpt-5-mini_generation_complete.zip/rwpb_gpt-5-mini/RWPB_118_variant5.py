
def filter_nan(ts, vs):
    import numpy as np
    def filter_nan(ts, vs):
        ts = np.asarray(ts)
        vs = np.asarray(vs)
        if ts.shape[0] != vs.shape[0]:
            raise ValueError("ts and vs must have the same length along axis 0")
        # use masked arrays and compressed to remove invalid entries
        m_ts = np.ma.masked_invalid(ts)
        m_vs = np.ma.masked_invalid(vs)
        # combine masks: True where either is invalid
        combined_mask = np.logical_or(m_ts.mask, m_vs.mask)
        if combined_mask is np.ma.nomask:
            return ts.copy(), vs.copy()
        valid_mask = ~combined_mask
        return np.asarray(ts)[valid_mask], np.asarray(vs)[valid_mask]
