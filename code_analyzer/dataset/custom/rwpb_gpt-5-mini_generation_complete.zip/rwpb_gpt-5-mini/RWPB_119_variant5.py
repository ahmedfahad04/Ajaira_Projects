
def rotate_about_x_axis(vector, theta):
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        """
        Rotate by treating the (y,z) pair as a complex number and rotating in the plane.
        """
        v = np.asarray(vector, dtype=float).ravel()
        if v.size < 3:
            raise ValueError("Input vector must have at least 3 components")
        x = float(v[0])
        y = float(v[1])
        z = float(v[2])
        # complex rotation: (y + i z) * exp(i theta)
        rot = np.exp(1j * float(theta))
        yz = complex(y, z) * rot
        return np.array([x, yz.real, yz.imag], dtype=float)
