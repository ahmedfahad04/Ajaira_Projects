
def get_confusion_matrix(gt_label, pred_label, num_classes):
    import numpy as np
    def get_confusion_matrix(gt_label, pred_label, num_classes):
        gt = np.asarray(gt_label).ravel()
        pred = np.asarray(pred_label).ravel()
        if gt.shape != pred.shape:
            raise ValueError("gt_label and pred_label must have the same length")
        if num_classes <= 0:
            return np.zeros((0, 0), dtype=np.int64)
        valid = (gt >= 0) & (gt < num_classes) & (pred >= 0) & (pred < num_classes)
        gt_valid = gt[valid].astype(np.int64)
        pred_valid = pred[valid].astype(np.int64)
        indices = gt_valid * num_classes + pred_valid
        counts = np.bincount(indices, minlength=num_classes * num_classes)
        cm = counts.reshape((num_classes, num_classes)).astype(np.int64)
        return cm
