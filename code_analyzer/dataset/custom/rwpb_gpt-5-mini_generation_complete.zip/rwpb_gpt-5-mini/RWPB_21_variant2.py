
def validate_user_id(user_id):
    import re
    _pattern = re.compile(r'^[A-Za-z][A-Za-z0-9_]*$')
    def validate_user_id(user_id):
        if type(user_id) is not str:
            return False
        return _pattern.match(user_id) is not None
