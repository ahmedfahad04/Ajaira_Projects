
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        # Force a square crop centered at the original box center, typical for many crop routines
        x, y, x1, y1 = box
        x, y, x1, y1 = float(x), float(y), float(x1), float(y1)
        cx = (x + x1) / 2.0
        cy = (y + y1) / 2.0
        w = abs(x1 - x)
        h = abs(y1 - y)
        # choose side as the max dimension, then expand it
        side = max(w, h) * float(expand)
        half = side / 2.0
        new_x = cx - half
        new_y = cy - half
        new_x1 = cx + half
        new_y1 = cy + half
        s = half
        return [new_x, new_y, new_x1, new_y1], s
