
def rotate_normalmap_by_angle_torch(normal_map, angle):
    import torch, math
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        """
        Use einsum to apply rotation matrix R to normals (vectorized).
        """
        if not isinstance(normal_map, torch.Tensor):
            raise TypeError("normal_map must be a torch.Tensor")
        if normal_map.shape[-1] != 3:
            raise ValueError("last dimension must be 3")
        device = normal_map.device
        dtype = normal_map.dtype
        theta = torch.tensor(math.radians(angle), device=device, dtype=dtype)
        c = torch.cos(theta)
        s = torch.sin(theta)
        R = torch.stack([
            torch.stack([c, torch.tensor(0.0, device=device, dtype=dtype), s]),
            torch.stack([torch.tensor(0.0, device=device, dtype=dtype), torch.tensor(1.0, device=device, dtype=dtype), torch.tensor(0.0, device=device, dtype=dtype)]),
            torch.stack([-s, torch.tensor(0.0, device=device, dtype=dtype), c])
        ], dim=0)  # shape (3,3)
        # einsum computes R @ v for last dim v
        rotated = torch.einsum('ij,...j->...i', R, normal_map)
        # optional normalization
        norms = rotated.norm(dim=-1, keepdim=True).clamp(min=1e-8)
        rotated = rotated / norms
        return rotated
