
def seconds_to_hh_mm_ss(seconds):
    def seconds_to_hh_mm_ss(seconds):
        try:
            seconds = int(seconds)
        except Exception:
            return "00:00:00"
        if seconds < 0:
            return "00:00:00"
        h, rem = divmod(seconds, 3600)
        m, s = divmod(rem, 60)
        return ":".join((str(h).zfill(2), str(m).zfill(2), str(s).zfill(2)))
