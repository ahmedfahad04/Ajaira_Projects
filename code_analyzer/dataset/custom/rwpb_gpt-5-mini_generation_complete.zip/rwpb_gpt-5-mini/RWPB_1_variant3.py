
def apply_colormap(:
    import torch
    import numpy as np
    from matplotlib import cm
    from torchtyping import TensorType
    def apply_colormap(
        image: TensorType["bs":..., 1],
        cmap="viridis",
    ) -> TensorType["bs":..., "rgb":3]:
        if not isinstance(image, torch.Tensor):
            image = torch.tensor(image)
        device = image.device
        img = image.detach().to(torch.float32).cpu().numpy()
        if img.shape[-1] != 1:
            raise ValueError("Expected last dimension to be channel=1")
        # treat first axis as batch if present; else operate on single image
        leading = img.shape[:-1]
        if len(leading) == 0:
            # scalar case
            arr = img[..., 0]
            cmap_fn = cm.get_cmap(cmap)
            rgba = cmap_fn(0.0)[:3]
            out = torch.tensor(rgba, device=device, dtype=torch.float32)
            return out
        # If batch-like: iterate over first axis
        if len(leading) == 1:
            count = leading[0]
            outs = []
            cmap_fn = cm.get_cmap(cmap)
            for i in range(count):
                img_i = img[i, ..., 0]
                vmin = img_i.min()
                vmax = img_i.max()
                if vmin == vmax:
                    norm = np.zeros_like(img_i, dtype=np.float32)
                else:
                    norm = ((img_i - vmin) / (vmax - vmin)).astype(np.float32)
                    norm = np.clip(norm, 0.0, 1.0)
                rgba = cmap_fn(norm)[:, :, :3] if norm.ndim == 2 else cmap_fn(norm)[:,:3]
                outs.append(torch.from_numpy(rgba.astype(np.float32)).to(device))
            return torch.stack(outs, dim=0)
        else:
            # generic: collapse all leading dims into a pseudo-batch
            flat_leading = int(np.prod(leading))
            reshaped = img.reshape((flat_leading,) + (1,))
            outs = []
            cmap_fn = cm.get_cmap(cmap)
            for i in range(flat_leading):
                arr = reshaped[i, 0]
                vmin = arr.min()
                vmax = arr.max()
                norm = np.zeros_like(arr, dtype=np.float32) if vmin == vmax else ((arr - vmin) / (vmax - vmin)).astype(np.float32)
                rgba = cmap_fn(norm)[:,:3]
                outs.append(rgba.astype(np.float32))
            result = np.stack(outs, axis=0).reshape(list(leading) + [3])
            return torch.from_numpy(result).to(device)
