
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        orig_x = x
        orig_dtype = x.dtype
        if upcast:
            x = x.float()
            weight = weight.float()
            if bias is not None:
                bias = bias.float()
            if residual is not None:
                residual = residual.float()
        # compute mean squares using einsum for variety
        denom = x.size(-1)
        mean_sq = torch.einsum('...i,...i->...', x, x).unsqueeze(-1) / float(denom)
        inv_rms = torch.rsqrt(mean_sq + eps)
        view_shape = [1] * (x.dim() - 1) + [-1]
        w = weight.view(*view_shape)
        out = x * inv_rms
        out = out * w
        if bias is not None:
            b = bias.view(*view_shape)
            out = out + b
        if residual is not None:
            out = out + residual
        if upcast:
            out = out.to(orig_dtype)
        if prenorm:
            return out, orig_x
        return out
