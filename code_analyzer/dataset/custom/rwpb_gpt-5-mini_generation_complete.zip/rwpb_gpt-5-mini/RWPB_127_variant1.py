
def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
    import torch
    def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        ndim = x.dim()
        if ndim == 0:
            return x.contiguous() if make_contiguous else x
        # normalize indices
        src = src_dim if src_dim >= 0 else src_dim + ndim
        dest = dest_dim if dest_dim >= 0 else dest_dim + ndim
        if not (0 <= src < ndim) or not (0 <= dest < ndim):
            raise IndexError("src_dim or dest_dim out of range")
        if src == dest:
            return x.contiguous() if make_contiguous else x
        # use torch.movedim when available
        try:
            out = torch.movedim(x, src, dest)
        except AttributeError:
            # fallback to permute
            dims = list(range(ndim))
            dims.pop(src)
            dims.insert(dest, src)
            out = x.permute(*dims)
        return out.contiguous() if make_contiguous else out
