
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return original_size
        ow, oh = original_size
        fits = []
        for w, h in possible_resolutions:
            if w <= ow and h <= oh:
                fits.append((w * h, (w, h)))
        if fits:
            fits.sort(reverse=True)
            return fits[0][1]
        areas = [(w * h, (w, h)) for w, h in possible_resolutions]
        areas.sort()
        return areas[0][1]
