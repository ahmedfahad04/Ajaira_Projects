
def numpy_to_pytorch(x):
    import numpy as np
    import torch
    def numpy_to_pytorch(x):
        x = np.array(x, dtype=np.float32, copy=False)
        # normalize in-place if possible
        try:
            x /= 255.0
        except Exception:
            x = x / 255.0
        x = np.expand_dims(x, 0)
        x = np.ascontiguousarray(x)
        return torch.from_numpy(x).float()
