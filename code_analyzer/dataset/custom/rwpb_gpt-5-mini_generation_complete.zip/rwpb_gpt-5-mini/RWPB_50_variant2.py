
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    import math
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        if not isinstance(tensor, torch.Tensor):
            tensor = torch.tensor(tensor)
        if tensor.dim() != 3:
            raise ValueError("Expected CxHxW tensor")
        C, H, W = tensor.shape
        oh, ow = map(int, original_size)
        # If exactly right
        if H == oh and W == ow:
            return tensor.contiguous()
        # If tensor is larger, remove symmetric padding
        if H >= oh and W >= ow:
            top = (H - oh) // 2
            left = (W - ow) // 2
            return tensor[:, top:top + oh, left:left + ow].contiguous()
        # If tensor is smaller in some dimension, pad symmetrically with zeros
        pad_h = max(0, oh - H)
        pad_w = max(0, ow - W)
        left = pad_w // 2
        right = pad_w - left
        top = pad_h // 2
        bottom = pad_h - top
        if pad_h > 0 or pad_w > 0:
            # F.pad expects (left,right,top,bottom) for 2D
            padded = F.pad(tensor, (left, right, top, bottom), mode='constant', value=0)
            return padded.contiguous()
        # Fallback: resize if something else
        resized = F.interpolate(tensor.unsqueeze(0), size=(oh, ow), mode='bilinear', align_corners=False)
        return resized.squeeze(0).contiguous()
