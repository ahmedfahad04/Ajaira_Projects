
def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        # Use torch.tensordot to compute projections
        if planes.ndim != 3 or planes.size(2) != 3:
            raise ValueError("planes must be (P,3,3)")
        if coordinates.ndim != 3 or coordinates.size(2) != 3:
            raise ValueError("coordinates must be (N,M,3)")
        P = planes.shape[0]
        N, M, _ = coordinates.shape
        axes = planes[:, :2, :]  # (P,2,3)
        # tensordot over last axis of coordinates and last axis of axes -> (N,M,P,2)
        proj = torch.tensordot(coordinates, axes, dims=([2], [2]))
        # transpose to (N,P,M,2) then reshape to (N*P, M, 2)
        proj = proj.permute(0, 2, 1, 3).reshape(N * P, M, 2)
        return proj
