
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        # Torch-only implementation using safe division and broadcasting
        if not torch.is_tensor(preds) or not torch.is_tensor(labels):
            preds = torch.tensor(preds)
            labels = torch.tensor(labels)
        # accept channel dimension
        if preds.ndim == 4 and preds.size(1) == 1:
            preds = preds.squeeze(1)
        if labels.ndim == 4 and labels.size(1) == 1:
            labels = labels.squeeze(1)
        if preds.shape != labels.shape:
            raise ValueError("preds and labels must have the same shape")
        # boolean masks
        preds_bool = (preds > 0.5)
        labels_bool = (labels > 0.5)
        # apply ignore by constructing a valid mask
        if ignore is not None:
            valid = (labels != ignore)
            preds_bool = preds_bool & valid
            labels_bool = labels_bool & valid
        # flatten to (N, P)
        if preds_bool.ndim == 3:
            N = preds_bool.size(0)
            P = preds_bool.numel() // N
            preds_flat = preds_bool.view(N, P).to(torch.bool)
            labels_flat = labels_bool.view(N, P).to(torch.bool)
            inter = (preds_flat & labels_flat).sum(1).float()
            union = (preds_flat | labels_flat).sum(1).float()
            # safe division with where
            ious = torch.zeros_like(inter)
            # union == 0 -> EMPTY
            zero_union = (union == 0)
            if zero_union.any():
                ious[zero_union] = float(EMPTY)
            nonzero = ~zero_union
            if nonzero.any():
                ious[nonzero] = inter[nonzero] / union[nonzero]
            if per_image:
                return float(ious.mean().item() * 100.0)
            else:
                total_inter = inter.sum()
                total_union = union.sum()
                if total_union == 0:
                    return float(EMPTY * 100.0)
                return float((total_inter / total_union).item() * 100.0)
        else:
            # single image
            inter = int((preds_bool & labels_bool).sum().item())
            union = int((preds_bool | labels_bool).sum().item())
            if union == 0:
                return float(EMPTY * 100.0)
            return float(inter / union * 100.0)
