
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return original_size
        ow, oh = original_size
        orig_area = max(1, ow * oh)
        orig_ar = ow / oh if oh != 0 else None
        best = None
        best_score = None
        for w, h in possible_resolutions:
            area = w * h
            area_diff_ratio = abs(area - orig_area) / orig_area
            ar = w / h if h != 0 else None
            ar_diff = abs(ar - orig_ar) if ar is not None and orig_ar is not None else 1.0
            score = (area_diff_ratio, ar_diff, abs(w - ow) + abs(h - oh))
            if best is None or score < best_score:
                best = (w, h)
                best_score = score
        return best
