
def pr_from_grav(grav):
    import numpy as np
    def pr_from_grav(grav):
        arr = np.asarray(grav, dtype=float)
        if arr.ndim == 1:
            if arr.size != 3:
                raise ValueError("grav must be shape (n,3) or (3,)")
            arr = arr.reshape(1, 3)
        if arr.ndim != 2 or arr.shape[1] != 3:
            raise ValueError("grav must have shape (n,3)")
        # Alternative sign convention variant: compute pitch using arcsin of x component
        # and roll with negative y to flip roll sign convention
        norms = np.linalg.norm(arr, axis=1)
        eps = np.finfo(float).eps
        norms_safe = np.where(norms == 0, eps, norms)
        nx = arr[:, 0] / norms_safe
        ny = arr[:, 1] / norms_safe
        nz = arr[:, 2] / norms_safe
        # pitch: asin(-nx)
        pitches = np.arcsin(np.clip(-nx, -1.0, 1.0))
        # roll: atan2(-ny, nz) -> flipped roll sign convention
        rolls = np.arctan2(-ny, nz)
        return pitches, rolls
