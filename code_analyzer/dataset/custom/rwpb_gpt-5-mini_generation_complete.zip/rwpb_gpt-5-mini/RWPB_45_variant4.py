
def invalid_to_zeros(arr, valid_mask, ndim=999):
    import torch
    def invalid_to_zeros(arr, valid_mask, ndim=999):
        if not isinstance(arr, torch.Tensor):
            arr = torch.tensor(arr)
        # Flatten if requested
        if ndim != 999 and arr.dim() > ndim:
            arr = arr.view(*arr.shape[:ndim - 1], -1)
        # Handle no-mask case
        if valid_mask is None:
            nnz = arr.numel() // arr.shape[0] if arr.dim() >= 1 else arr.numel()
            return arr, nnz
        mask = valid_mask.bool()
        # Loop per-batch to be robust for many mask shapes
        if arr.dim() >= 1 and mask.numel() >= arr.shape[0]:
            B = arr.shape[0]
            # If mask is exactly (B,) treat as per-image validity flags
            if mask.numel() == B:
                nnz = mask.to(torch.long)
                return arr, nnz
            per_image_counts = []
            for i in range(B):
                # Try to extract i-th mask slice in a variety of plausible shapes
                try:
                    # If mask is at least 1D and first dim equals B
                    if mask.dim() >= 1 and mask.shape[0] == B:
                        m = mask[i]
                    else:
                        # else use flattened mask chunk
                        flat = mask.view(-1)
                        chunk_size = flat.numel() // B
                        m = flat[i * chunk_size:(i + 1) * chunk_size]
                    # reshape m to match arr[i] if possible
                    try:
                        m_view = m.view_as(arr[i])
                    except Exception:
                        m_view = m.view(-1)
                        if m_view.numel() == arr[i].numel():
                            m_view = m_view.view_as(arr[i])
                        else:
                            # fallback: assume all valid for this image
                            m_view = torch.ones_like(arr[i], dtype=torch.bool)
                    # zero invalid entries
                    arr_i = arr[i]
                    arr_i[~m_view] = 0
                    per_image_counts.append(int(m_view.view(-1).sum().item()))
                except Exception:
                    # If anything fails, assume all valid
                    per_image_counts.append(arr[i].numel())
            nnz = torch.tensor(per_image_counts, device=arr.device)
            return arr, nnz
        else:
            # Fallback: try direct element-wise masking
            if mask.numel() == arr.numel():
                mask_view = mask.view_as(arr)
                arr[~mask_view] = 0
                nnz = mask_view.view(arr.shape[0], -1).sum(dim=1) if arr.dim() >= 1 else mask_view.sum()
                return arr, nnz
            # Can't align mask; return arr unchanged and scalar 0
            return arr, 0
