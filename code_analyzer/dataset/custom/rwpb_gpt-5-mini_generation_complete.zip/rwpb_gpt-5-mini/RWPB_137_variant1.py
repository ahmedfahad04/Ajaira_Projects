
def fit_params(:
    def fit_params(
        x,
        y,
        fun,
        a_range=(-10, 10),
        b_range=(-10, 10),
        grid_number=101,
        iteration=3,
        verbose=True,
    ):
        import numpy as np
        import torch
        # Convert inputs to numpy arrays for this implementation
        if torch.is_tensor(x):
            x_np = x.detach().cpu().numpy()
        else:
            x_np = np.asarray(x)
        if torch.is_tensor(y):
            y_np = y.detach().cpu().numpy()
        else:
            y_np = np.asarray(y)
        n = x_np.size
        # initial ranges
        a_min, a_max = float(a_range[0]), float(a_range[1])
        b_min, b_max = float(b_range[0]), float(b_range[1])
        best = {"r2": -np.inf, "a": None, "b": None, "c": None, "d": None}
        for it in range(iteration):
            a_vals = np.linspace(a_min, a_max, grid_number)
            b_vals = np.linspace(b_min, b_max, grid_number)
            for a in a_vals:
                axb = a * x_np  # shape (n,)
                for b in b_vals:
                    z = np.asarray(fun(axb + b))
                    # ensure shapes
                    z = z.reshape(-1)
                    # Solve for c and d via closed form sums
                    S_z = z.sum()
                    S_zz = (z * z).sum()
                    S_y = y_np.sum()
                    S_zy = (z * y_np).sum()
                    denom = n * S_zz - S_z * S_z
                    if abs(denom) < 1e-12:
                        # degenerate: z is constant, set c=0 and d=mean(y)
                        c = 0.0
                        d = S_y / n
                    else:
                        c = (n * S_zy - S_z * S_y) / denom
                        d = (S_y - c * S_z) / n
                    y_pred = c * z + d
                    ss_res = ((y_np - y_pred) ** 2).sum()
                    ss_tot = ((y_np - y_np.mean()) ** 2).sum()
                    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else (1.0 if ss_res == 0 else -np.inf)
                    if r2 > best["r2"]:
                        best.update({"r2": r2, "a": a, "b": b, "c": c, "d": d})
            # refine ranges around best
            span_a = (a_max - a_min) / 10.0
            span_b = (b_max - b_min) / 10.0
            a_min = best["a"] - span_a
            a_max = best["a"] + span_a
            b_min = best["b"] - span_b
            b_max = best["b"] + span_b
            if verbose:
                print(f"Iter {it+1}/{iteration}, best r2={best['r2']:.6f}, a={best['a']}, b={best['b']}")
        # return as torch tensors: first tensor [a,b,c,d], second scalar r2
        a_best = torch.tensor(best["a"], dtype=torch.float64)
        b_best = torch.tensor(best["b"], dtype=torch.float64)
        c_best = torch.tensor(best["c"], dtype=torch.float64)
        d_best = torch.tensor(best["d"], dtype=torch.float64)
        r2_best = torch.tensor(best["r2"], dtype=torch.float64)
        return torch.stack([a_best, b_best, c_best, d_best]), r2_best
