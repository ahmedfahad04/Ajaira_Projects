
def submatrix(matrix, col):
    def submatrix(matrix, col):
        if not matrix:
            return []
        # require rectangular matrix
        m = len(matrix)
        n = len(matrix[0])
        for row in matrix:
            if len(row) != n:
                raise ValueError("matrix must be rectangular")
        # normalize negative index
        if col < 0:
            col = n + col
        if not (0 <= col < n):
            raise IndexError("column index out of range")
        out = []
        for i in range(m):
            new_row = []
            for j in range(n):
                if j != col:
                    new_row.append(matrix[i][j])
            out.append(new_row)
        return out
