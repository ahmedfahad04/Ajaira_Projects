
def check(x, checksum_token):
    import re
    import hashlib
    def check(x, checksum_token):
        m = re.search(r'([0-9A-Fa-f]{64})', x)
        if not m:
            return False
        orig = m.group(1)
        new_s = x.replace(orig, checksum_token, 1)
        digest = hashlib.sha256(new_s.encode()).hexdigest()
        return digest.lower() == orig.lower()
