
def is_tensor(x):
    import importlib
    import importlib.util
    import numpy as np
    _torch_checked = False
    _torch_module = None
    def is_tensor(x):
        global _torch_checked, _torch_module
        if not _torch_checked:
            _torch_checked = True
            if importlib.util.find_spec("torch") is not None:
                try:
                    _torch_module = importlib.import_module("torch")
                except Exception:
                    _torch_module = None
        if _torch_module is not None:
            return isinstance(x, _torch_module.Tensor) or isinstance(x, np.ndarray)
        return isinstance(x, np.ndarray)
