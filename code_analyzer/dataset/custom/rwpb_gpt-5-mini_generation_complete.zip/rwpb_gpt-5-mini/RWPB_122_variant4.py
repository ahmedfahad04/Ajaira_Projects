
def view_range(x, i, j, shape):
    import torch
    def view_range(x, i, j, shape):
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        ndim = x.dim()
        if j is None:
            j = ndim
        if i < 0:
            i += ndim
        if j < 0:
            j += ndim
        if not (0 <= i <= j <= ndim):
            raise IndexError("Invalid range")
        # Use contiguous view when possible
        # Compute product of dims in range
        orig = list(x.shape[i:j])
        prod = 1
        for d in orig:
            prod *= d
        target = list(shape)
        if -1 in target:
            if target.count(-1) > 1:
                raise ValueError("Only one -1 allowed")
            known = 1
            for v in target:
                if v != -1:
                    known *= v
            if known == 0 or prod % known != 0:
                raise ValueError("Cannot infer -1")
            target[target.index(-1)] = prod // known
        tprod = 1
        for v in target:
            tprod *= v
        if tprod != prod:
            raise ValueError("Shape mismatch")
        pre = tuple(x.shape[:i])
        post = tuple(x.shape[j:])
        # bring the span into a single dimension, then expand into the new shape
        y = x.contiguous().view(*pre, prod, *post)
        # now reshape the prod dimension into the target
        newshape = pre + tuple(target) + post
        return y.view(*newshape)
