
def rotate_x(a, device=None):
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        # create zero matrix and fill entries
        dev = torch.device(device) if device is not None else None
        dtype = torch.get_default_dtype()
        M = torch.zeros((4,4), dtype=dtype, device=dev)
        M[0,0] = 1.0
        M[3,3] = 1.0
        # compute sin/cos using torch if possible
        if isinstance(a, torch.Tensor):
            ang = a.to(dev) if dev is not None else a
            c = torch.cos(ang).item()
            s = torch.sin(ang).item()
        else:
            a_f = float(a)
            c = np.cos(a_f)
            s = np.sin(a_f)
        M[1,1] = c
        M[1,2] = -s
        M[2,1] = s
        M[2,2] = c
        return M
