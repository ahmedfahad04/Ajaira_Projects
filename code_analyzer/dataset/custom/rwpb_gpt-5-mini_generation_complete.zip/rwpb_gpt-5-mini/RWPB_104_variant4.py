
def mulMod(x, y, z):
    def mulMod(x, y, z):
        if z == 0:
            raise ValueError("modulus must be non-zero")
        x %= z
        y_abs = y if y >= 0 else -y
        base = 1 << 64
        res = 0
        power = 1
        while y_abs:
            y_abs, digit = divmod(y_abs, base)
            if digit:
                res = (res + (x * digit % z) * power) % z
            power = (power * (base % z)) % z
        if y < 0:
            # handle negative multiplier
            res = (-res) % z
        return res
