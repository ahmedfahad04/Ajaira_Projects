
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        if normal_map.ndim != 3 or normal_map.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        theta = np.deg2rad(angle)
        w = np.cos(theta / 2.0)
        sin_half = np.sin(theta / 2.0)
        qv = np.array([0.0, sin_half, 0.0], dtype=np.float64)  # quaternion vector part for axis (0,1,0)
        nm = np.asarray(normal_map, dtype=np.float64)
        v = nm
        # compute v' = v*(w*w - qv·qv) + 2*qv*(qv·v) + 2*w*(qv x v)
        qv_dot_qv = (qv * qv).sum()
        scalar = w * w - qv_dot_qv
        # term1
        term1 = v * scalar
        # term2
        qv_dot_v = (v * qv).sum(axis=-1, keepdims=True)
        term2 = 2.0 * qv * qv_dot_v
        # term3
        cross = np.empty_like(v)
        cross[..., 0] = qv[1] * v[..., 2] - qv[2] * v[..., 1]
        cross[..., 1] = qv[2] * v[..., 0] - qv[0] * v[..., 2]
        cross[..., 2] = qv[0] * v[..., 1] - qv[1] * v[..., 0]
        term3 = 2.0 * w * cross
        rotated = term1 + term2 + term3
        norm = np.linalg.norm(rotated, axis=-1, keepdims=True)
        eps = 1e-12
        rotated = rotated / np.where(norm > eps, norm, 1.0)
        return rotated.astype(normal_map.dtype)
