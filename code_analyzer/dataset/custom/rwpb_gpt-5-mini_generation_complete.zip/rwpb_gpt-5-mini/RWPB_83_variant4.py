
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        min_h, min_w = size
        img = sample.get("image")
        if img is None:
            return None
        h, w = img.shape[:2]
        # Compute minimum scale but snap to integer pixel sizes to avoid fractional sizes
        need_h = max(0, min_h - h)
        need_w = max(0, min_w - w)
        if need_h == 0 and need_w == 0:
            return (h, w)
        scale = max(float(min_h) / h if need_h > 0 else 1.0,
                    float(min_w) / w if need_w > 0 else 1.0)
        # compute target using integer arithmetic ensuring at least min
        new_h = int(math.floor(h * scale + 0.9999))
        new_w = int(math.floor(w * scale + 0.9999))
        new_h = max(new_h, min_h)
        new_w = max(new_w, min_w)
        # Use fx, fy parameters for cv2.resize
        fx = new_w / float(w)
        fy = new_h / float(h)
        sample["image"] = cv2.resize(img, None, fx=fx, fy=fy, interpolation=image_interpolation_method)
        # disparity scaling: use fy (they should be equal or nearly equal)
        if "disparity" in sample and sample["disparity"] is not None:
            d = np.asarray(sample["disparity"]).astype(np.float32)
            d_resized = cv2.resize(d, None, fx=fx, fy=fy, interpolation=cv2.INTER_LINEAR)
            d_resized = d_resized * fx
            sample["disparity"] = d_resized.astype(np.asarray(sample["disparity"]).dtype)
        if "mask" in sample and sample["mask"] is not None:
            m = np.asarray(sample["mask"])
            m_resized = cv2.resize(m, None, fx=fx, fy=fy, interpolation=cv2.INTER_NEAREST)
            sample["mask"] = (m_resized > 0.5).astype(m.dtype)
        return (new_h, new_w)
