
def inverse_sigmoid(x):
    import torch
    def inverse_sigmoid(x):
        x = torch.as_tensor(x)
        if not x.is_floating_point():
            x = x.float()
        zero = torch.tensor(0., dtype=x.dtype, device=x.device)
        one = torch.tensor(1., dtype=x.dtype, device=x.device)
        is_zero = x == zero
        is_one = x == one
        eps = 1e-12
        safe_x = torch.where(is_zero, torch.full_like(x, eps), x)
        safe_x = torch.where(is_one, torch.full_like(x, 1 - eps), safe_x)
        out = torch.log(safe_x) - torch.log1p(-safe_x)
        out = torch.where(is_zero, torch.full_like(out, float('-inf')), out)
        out = torch.where(is_one, torch.full_like(out, float('inf')), out)
        return out
