
def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        x_orig = x
        if upcast:
            dtype = torch.float32
            x = x.to(dtype)
            if weight is not None:
                weight = weight.to(dtype)
            if bias is not None:
                bias = bias.to(dtype)
            if residual is not None:
                residual = residual.to(dtype)
        batch_shape = x.shape[:-1]
        feat = x.shape[-1]
        flat = x.contiguous().view(-1, feat)
        mean = flat.mean(dim=1, keepdim=True)
        var = flat.var(dim=1, keepdim=True, unbiased=False)
        invstd = torch.rsqrt(var + eps)
        normalized_flat = (flat - mean) * invstd
        normalized = normalized_flat.view(*batch_shape, feat)
        if weight is not None:
            w = weight.view(*([1] * len(batch_shape)), -1) if weight.ndim == 1 else weight
            normalized = normalized * w
        if bias is not None:
            b = bias.view(*([1] * len(batch_shape)), -1) if bias.ndim == 1 else bias
            normalized = normalized + b
        if residual is not None:
            normalized = normalized + residual
        if upcast:
            normalized = normalized.to(x_orig.dtype)
        if prenorm:
            return normalized, x_orig
        return normalized
