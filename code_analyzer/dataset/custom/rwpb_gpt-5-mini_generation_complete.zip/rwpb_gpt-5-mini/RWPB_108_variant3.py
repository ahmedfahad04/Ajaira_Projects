
def norm_grid(v_grid):
    import torch
    def norm_grid(v_grid):
        """Batch-loop normalization (explicit loop over batch)."""
        if not isinstance(v_grid, torch.Tensor):
            v_grid = torch.tensor(v_grid)
        B, C, H, W = v_grid.shape
        assert C == 2
        denom_w = max(W - 1, 1)
        denom_h = max(H - 1, 1)
        out_list = []
        for b in range(B):
            sample = v_grid[b]  # (2,H,W)
            x = sample[0].to(dtype=torch.float32)
            y = sample[1].to(dtype=torch.float32)
            x_n = (x / denom_w) * 2.0 - 1.0
            y_n = (y / denom_h) * 2.0 - 1.0
            out_list.append(torch.stack([x_n, y_n], dim=-1))  # (H,W,2)
        out = torch.stack(out_list, dim=0)  # (B,H,W,2)
        return out
