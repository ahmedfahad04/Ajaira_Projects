
def cvimg2torch(img):
    import numpy as np
    import torch
    def cvimg2torch(img):
        """
        Convert a img to tensor
        input:
            img -> ndarray uint8 HxWxC or HxW
        return
            tensor -> torch.tensor BxCxHxW (float32 normalized to [0,1])
        """
        arr = np.asarray(img)
        if arr.ndim == 2:
            # Gray image HxW -> HxWx1
            arr = arr[:, :, None]
        # ensure HxWxC
        if arr.shape[2] == 0:
            raise ValueError("Image has zero channels")
        # convert to float and normalize
        arr = arr.astype(np.float32) / 255.0
        # HxWxC -> CxHxW
        arr = np.transpose(arr, (2, 0, 1))
        # to torch tensor and add batch dim
        tensor = torch.from_numpy(arr).contiguous()
        tensor = tensor.unsqueeze(0)  # 1xCxHxW
        return tensor
