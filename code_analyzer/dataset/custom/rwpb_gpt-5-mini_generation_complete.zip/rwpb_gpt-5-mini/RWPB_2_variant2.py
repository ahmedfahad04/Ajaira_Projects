
def logbessel_I_scipy(nu, z, check = True):
    import numpy as np
    import torch
    from scipy import special
    def logbessel_I_scipy(nu, z, check = True):
        # Use scaled ive to improve stability: I_nu(z) = exp(z) * ive(nu,z) for real positive z
        is_torch = isinstance(z, torch.Tensor)
        if is_torch:
            device = z.device
            dtype = z.dtype
            z_np = z.detach().cpu().numpy()
        else:
            z_np = np.array(z, copy=False)
            device = None
            dtype = None
        orig_shape = z_np.shape
        z_flat = np.atleast_1d(z_np).ravel()
        # compute ive (scaled by exp(-|z|) in scipy for real inputs)
        ive = special.ive(nu, z_flat)
        # For real positive z, ive = exp(-z) * iv, so log(iv) = z + log(ive)
        # For negative or complex z, fall back to iv
        log_iv = np.empty_like(z_flat, dtype=np.float64)
        pos_mask = z_flat >= 0
        neg_mask = ~pos_mask
        tiny = np.finfo(np.float64).tiny
        if np.any(pos_mask):
            ive_pos = ive[pos_mask]
            # avoid log(0)
            if check and np.any(ive_pos == 0):
                raise ValueError("Scaled Bessel ive returned zero for some positive z; log undefined.")
            ive_pos_safe = np.maximum(ive_pos, tiny)
            log_iv[pos_mask] = z_flat[pos_mask] + np.log(ive_pos_safe)
        if np.any(neg_mask):
            # use direct iv for negative z
            iv_neg = special.iv(nu, z_flat[neg_mask])
            if check and np.any(iv_neg == 0):
                raise ValueError("Bessel I evaluated to zero for some entries; log undefined.")
            iv_neg_safe = np.maximum(iv_neg, tiny)
            log_iv[neg_mask] = np.log(iv_neg_safe)
        log_iv = log_iv.reshape(orig_shape)
        if is_torch:
            return torch.tensor(log_iv, dtype=dtype, device=device)
        else:
            return torch.tensor(log_iv)
