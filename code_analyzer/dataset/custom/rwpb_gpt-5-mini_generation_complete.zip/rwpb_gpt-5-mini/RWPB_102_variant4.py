
def rotate_about_z_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_z_axis(vector, theta):
        v = np.asarray(vector, dtype=float)
        x, y, z = float(v[0]), float(v[1]), float(v[2])
        c = math.cos(theta)
        s = math.sin(theta)
        # homogeneous 4x4 transform (w=0 for a pure vector)
        R4 = np.eye(4, dtype=float)
        R4[0,0] = c;  R4[0,1] = -s
        R4[1,0] = s;  R4[1,1] = c
        vec4 = np.array([x, y, z, 0.0], dtype=float)
        rx, ry, rz, _ = R4.dot(vec4)
        return np.array([rx, ry, rz], dtype=float)
