
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        # Loose conversion and explicit python-loop per image
        if not torch.is_tensor(preds):
            preds = torch.tensor(preds)
        if not torch.is_tensor(labels):
            labels = torch.tensor(labels)
        # handle channel dim
        if preds.ndim == 4 and preds.size(1) == 1:
            preds = preds.squeeze(1)
        if labels.ndim == 4 and labels.size(1) == 1:
            labels = labels.squeeze(1)
        if preds.shape != labels.shape:
            raise ValueError("preds and labels must have the same shape")
        # convert to bool masks
        preds_bool = (preds > 0.5)
        labels_bool = (labels > 0.5)
        n_images = 1
        if preds_bool.ndim == 3:
            n_images = preds_bool.size(0)
        else:
            preds_bool = preds_bool.unsqueeze(0)
            labels_bool = labels_bool.unsqueeze(0)
            n_images = 1
        ious = []
        for i in range(n_images):
            p = preds_bool[i].clone()
            l = labels_bool[i].clone()
            if ignore is not None:
                imask = (labels[i] == ignore)
                if imask.any():
                    p[imask] = False
                    l[imask] = False
            inter = int((p & l).sum().item())
            union = int((p | l).sum().item())
            if union == 0:
                ious.append(float(EMPTY))
            else:
                ious.append(inter / union)
        if per_image:
            return float((sum(ious) / len(ious)) * 100.0)
        else:
            # compute global intersection/union
            if preds_bool.size(0) == 1:
                total_iou = ious[0]
                return float(total_iou * 100.0)
            # recompute totals
            total_p = preds_bool.clone()
            total_l = labels_bool.clone()
            if ignore is not None:
                for i in range(total_p.size(0)):
                    total_p[i][labels[i] == ignore] = False
                    total_l[i][labels[i] == ignore] = False
            total_inter = int((total_p & total_l).sum().item())
            total_union = int((total_p | total_l).sum().item())
            if total_union == 0:
                return float(EMPTY * 100.0)
            return float((total_inter / total_union) * 100.0)
