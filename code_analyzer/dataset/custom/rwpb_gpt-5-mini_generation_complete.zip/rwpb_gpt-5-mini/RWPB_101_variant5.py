
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    import numpy as np
    def generate_grids(lower_limit, upper_limit, grid_size):
        lower = torch.as_tensor(lower_limit)
        upper = torch.as_tensor(upper_limit)
        gs = torch.as_tensor(grid_size)
        lower = lower.flatten()
        upper = upper.flatten()
        gs = gs.flatten()
        D = lower.numel()
        if gs.numel() == 1 and D > 1:
            gs = gs.expand(D)
        gs = gs.to(dtype=torch.long)
        edge_low_list = []
        edge_high_list = []
        for i in range(D):
            n = int(gs[i].item())
            if n < 1:
                raise ValueError("grid_size must be >=1")
            # use numpy for linspace then convert back
            arr = np.linspace(float(lower[i].item()), float(upper[i].item()), num=n + 1)
            edge_low_list.append(arr[:-1])
            edge_high_list.append(arr[1:])
        if D == 0:
            return torch.empty((0, 0), dtype=lower.dtype), torch.empty((0, 0), dtype=lower.dtype)
        # build meshgrid via numpy
        low_mesh = np.meshgrid(*edge_low_list, indexing='ij')
        high_mesh = np.meshgrid(*edge_high_list, indexing='ij')
        flat_low = [m.reshape(-1) for m in low_mesh]
        flat_high = [m.reshape(-1) for m in high_mesh]
        low_arr = np.stack(flat_low, axis=1) if flat_low else np.empty((0, D))
        high_arr = np.stack(flat_high, axis=1) if flat_high else np.empty((0, D))
        device = lower.device
        dtype = lower.dtype
        low_t = torch.from_numpy(low_arr).to(device=device, dtype=dtype)
        high_t = torch.from_numpy(high_arr).to(device=device, dtype=dtype)
        return low_t, high_t
