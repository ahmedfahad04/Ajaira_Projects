
def divide_to_patches(image, patch_size):
    from PIL import Image
    def divide_to_patches(image, patch_size):
        if not isinstance(patch_size, int) or patch_size <= 0:
            raise ValueError("patch_size must be a positive integer")
        w, h = image.size
        def pad_to(img, tw, th):
            if img.size == (tw, th):
                return img.copy()
            mode = img.mode
            if "A" in mode:
                fill = (0, 0, 0, 0)
            elif mode == "RGB":
                fill = (0, 0, 0)
            elif mode == "L":
                fill = 0
            else:
                fill = 0
            canvas = Image.new(mode, (tw, th), fill)
            canvas.paste(img, (0, 0))
            return canvas
        def recurse(img):
            iw, ih = img.size
            if iw <= patch_size and ih <= patch_size:
                return [pad_to(img, patch_size, patch_size)]
            if iw > patch_size:
                mid = iw // 2
                left = img.crop((0, 0, mid, ih))
                right = img.crop((mid, 0, iw, ih))
                return recurse(left) + recurse(right)
            else:
                mid = ih // 2
                top = img.crop((0, 0, iw, mid))
                bottom = img.crop((0, mid, iw, ih))
                return recurse(top) + recurse(bottom)
        return recurse(image)
