
def B_batch(x, grid, k=0, extend=True, device="cpu"):
    import torch
    def B_batch(x, grid, k=0, extend=True, device="cpu"):
        x = x.to(device)
        grid = grid.to(device)
        S, N = x.shape
        assert grid.shape[0] == S
        dtype = x.dtype
        res = []
        for s in range(S):
            xs = x[s]
            knots_inner = grid[s]
            if k > 0 and extend:
                knots = torch.cat([knots_inner[0].repeat(k), knots_inner, knots_inner[-1].repeat(k)])
            else:
                knots = knots_inner.clone()
            p = max(k - 1, 0)
            K = knots.numel()
            n_bases = max(K - p - 1, 0)
            if n_bases == 0:
                res.append(torch.zeros((0, N), device=device, dtype=dtype))
                continue
            # Efficient local support computation: each B-spline of degree p has support on knots[i]..knots[i+p+1]
            basis = torch.zeros((n_bases, N), device=device, dtype=dtype)
            # compute interval indices for each sample: find rightmost knot <= x
            # torch.searchsorted expects ascending knots
            idx = torch.searchsorted(knots, xs, right=False)
            # Clamp indices
            idx = torch.clamp(idx, 1, K-1)
            # For each basis i, only samples with idx in [i, i+p+1] can be nonzero
            for i in range(n_bases):
                # samples potentially nonzero:
                lo = i
                hi = i + p + 1
                mask = (idx >= lo) & (idx <= hi)
                if not mask.any():
                    continue
                us = xs[mask]
                # Compute basis values for these us via small DP local to span
                local_knots = knots[i:hi+1]  # length p+2
                # build local Nmat for these samples
                spans = local_knots.numel() - 1
                Nmat = (((us.unsqueeze(0) >= local_knots[:-1].unsqueeze(1)) & (us.unsqueeze(0) < local_knots[1:].unsqueeze(1))).to(dtype))
                if spans >= 1:
                    if (us == local_knots[-1]).any():
                        # include endpoint equality to last
                        eq_mask = (us == local_knots[-1])
                        Nmat[-1, eq_mask] = 1.0
                for d in range(1, p + 1):
                    new_spans = spans - d
                    newN = torch.zeros((new_spans, us.numel()), device=device, dtype=dtype)
                    for j in range(new_spans):
                        denom1 = local_knots[j + d] - local_knots[j]
                        denom2 = local_knots[j + d + 1] - local_knots[j + 1]
                        term1 = 0.0
                        term2 = 0.0
                        if denom1 != 0:
                            term1 = ((us - local_knots[j]) / denom1) * Nmat[j]
                        if denom2 != 0:
                            term2 = ((local_knots[j + d + 1] - us) / denom2) * Nmat[j + 1]
                        newN[j] = term1 + term2
                    Nmat = newN
                basis[i, mask] = Nmat[0]
            res.append(basis)
        max_b = max((r.shape[0] for r in res), default=0)
        out = torch.zeros((S, max_b, N), device=device, dtype=dtype)
        for s in range(S):
            nb = res[s].shape[0]
            if nb > 0:
                out[s, :nb, :] = res[s]
        return out
