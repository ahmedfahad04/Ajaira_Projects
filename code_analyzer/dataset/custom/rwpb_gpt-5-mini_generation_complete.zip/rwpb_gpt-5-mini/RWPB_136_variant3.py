
def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
    import torch
    def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
        import torch
        t_tensor = v0.new_tensor(t)
        v0 = v0.to(v0.dtype)
        v1 = v1.to(v0.dtype)
        v0n = torch.norm(v0, dim=-1, keepdim=True)
        v1n = torch.norm(v1, dim=-1, keepdim=True)
        u0 = v0 / (v0n + 1e-12)
        u1 = v1 / (v1n + 1e-12)
        dot = torch.sum(u0 * u1, dim=-1, keepdim=True)
        dot = torch.clamp(dot, -1.0, 1.0)
        theta = torch.acos(dot)
        sin_theta = torch.sin(theta)
        small = (sin_theta.abs() < 1e-6) | (torch.abs(dot) > DOT_THRESHOLD)
        s0 = torch.where(small, 1.0 - t_tensor, torch.sin((1.0 - t_tensor) * theta) / (sin_theta + 1e-12))
        s1 = torch.where(small, t_tensor, torch.sin(t_tensor * theta) / (sin_theta + 1e-12))
        s0 = s0.expand_as(u0)
        s1 = s1.expand_as(u0)
        out = s0 * u0 + s1 * u1
        out = out / (torch.norm(out, dim=-1, keepdim=True) + 1e-12)
        norm_interp = (1.0 - t_tensor) * v0n + t_tensor * v1n
        return out * norm_interp
