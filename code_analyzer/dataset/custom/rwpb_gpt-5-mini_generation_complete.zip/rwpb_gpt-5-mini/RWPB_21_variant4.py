
def validate_user_id(user_id):
    def validate_user_id(user_id):
        try:
            if not isinstance(user_id, str) or user_id == '':
                return False
            first = user_id[0]
            if not ('A' <= first <= 'Z' or 'a' <= first <= 'z'):
                return False
            for c in user_id[1:]:
                if not (('0' <= c <= '9') or ('A' <= c <= 'Z') or ('a' <= c <= 'z') or c == '_'):
                    return False
            return True
        except Exception:
            return False
