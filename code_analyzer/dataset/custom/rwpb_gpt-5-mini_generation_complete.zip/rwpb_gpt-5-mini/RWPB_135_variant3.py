
def mask_iou(mask1, mask2, eps=1e-7):
    import torch
    def mask_iou(mask1, mask2, eps=1e-7):
        """
        Chunked computation to reduce peak memory using matrix multiplication on chunks of mask1.
        """
        if not isinstance(mask1, torch.Tensor) or not isinstance(mask2, torch.Tensor):
            raise TypeError("mask1 and mask2 must be torch.Tensors")
        if mask1.ndim != 2 or mask2.ndim != 2:
            raise ValueError("mask1 and mask2 must be 2-D tensors")
        N, n1 = mask1.shape
        M, n2 = mask2.shape
        if n1 != n2:
            raise ValueError("mask1 and mask2 must have the same number of columns")
        if N == 0 or M == 0:
            return torch.zeros((N, M), dtype=mask1.dtype, device=mask1.device)
        device = mask1.device
        dtype = mask1.dtype
        m2 = mask2.float()
        area2 = m2.sum(dim=1)
        result = []
        # choose chunk size adaptively
        # aim for chunk*N*M memory roughly; use a moderate chunk
        chunk = max(1, min(N, 256))
        for start in range(0, N, chunk):
            end = min(N, start + chunk)
            chunk_m1 = mask1[start:end].float()  # (chunk, n)
            inter_chunk = chunk_m1 @ m2.t()  # (chunk, M)
            area1_chunk = chunk_m1.sum(dim=1, keepdim=True)  # (chunk,1)
            union_chunk = area1_chunk + area2.unsqueeze(0) - inter_chunk
            iou_chunk = inter_chunk / (union_chunk + eps)
            iou_chunk = torch.where(union_chunk > 0, iou_chunk, torch.zeros_like(iou_chunk))
            result.append(iou_chunk)
        return torch.cat(result, dim=0).to(device=device, dtype=dtype)
