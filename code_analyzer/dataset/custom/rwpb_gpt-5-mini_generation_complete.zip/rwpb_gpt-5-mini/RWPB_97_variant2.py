
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        if not isinstance(image, np.ndarray):
            raise ValueError("not a valid image")
        ndim = image.ndim
        if ndim == 2:
            arr = np.asarray(image, dtype=np.float32) / 255.0
            arr = np.expand_dims(arr, 0)  # (1, H, W)
        elif ndim == 3:
            if image.shape[2] <= 0:
                raise ValueError("not a valid image")
            arr = np.moveaxis(image, 2, 0).astype(np.float32) / 255.0  # (C, H, W)
        else:
            raise ValueError("not a valid image")
        arr = np.ascontiguousarray(arr)
        return torch.from_numpy(arr).float()
