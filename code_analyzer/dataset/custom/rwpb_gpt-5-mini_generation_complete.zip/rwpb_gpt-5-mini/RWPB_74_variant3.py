
def arccos2(vector, value):
    import math
    def arccos2(vector, value):
        try:
            x = float(vector[0])
            y = float(vector[1])
        except Exception:
            x = 0.0
            y = 0.0
        if value != value:
            return float('nan')
        v = value
        if v > 1.0:
            v = 1.0
        elif v < -1.0:
            v = -1.0
        mag = math.acos(v)
        dir_angle = math.atan2(y, x)
        if dir_angle < 0:
            return -mag
        return mag
