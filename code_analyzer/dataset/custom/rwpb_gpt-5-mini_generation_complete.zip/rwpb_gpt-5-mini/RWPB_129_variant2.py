
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        """
        Variant: use nearest interpolation for crisp masks and return float masks in [0,1].
        """
        if not isinstance(masks, torch.Tensor):
            masks = torch.tensor(masks)
        if masks.ndim != 4:
            raise ValueError("masks must be (N, C, H, W)")
        N, C, H, W = masks.shape
        target_h, target_w = shape
        # convert logits to probabilities if necessary (large dynamic range)
        if masks.dtype.is_floating_point:
            if masks.max() > 1.0 or masks.min() < 0.0:
                # apply sigmoid to bring into [0,1]
                masks = masks.sigmoid()
        else:
            masks = masks.float().clamp(0.0, 1.0)
        if not padding:
            out = F.interpolate(masks, size=(target_h, target_w), mode='nearest')
            return out
        # padding True: upsample to square then crop center
        s = max(target_h, target_w)
        up = F.interpolate(masks, size=(s, s), mode='nearest')
        y0 = (s - target_h) // 2
        x0 = (s - target_w) // 2
        cropped = up[:, :, y0:y0 + target_h, x0:x0 + target_w]
        return cropped
