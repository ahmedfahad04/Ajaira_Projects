
def round_nearest_multiple(number, a, direction='standard'):
    import numpy as np
    from decimal import Decimal, ROUND_HALF_UP
    def round_nearest_multiple(number, a, direction='standard'):
        if a == 0:
            raise ValueError("a must be non-zero")
        dir_lower = (direction or 'standard').lower()
        q = np.array(number) / a
        if dir_lower == 'standard':
            # numpy.rint uses round-to-even; emulate half-away-from-zero
            if q >= 0:
                k = int(np.floor(q + 0.5))
            else:
                k = int(np.ceil(q - 0.5))
        elif dir_lower == 'down':
            k = int(np.floor(q))
        elif dir_lower == 'up':
            k = int(np.ceil(q))
        else:
            raise ValueError("direction must be 'standard', 'down', or 'up'")
        result = float(k * a)
        # Match precision of 'a'
        da = Decimal(str(a))
        places = -da.as_tuple().exponent if da.as_tuple().exponent < 0 else 0
        dr = Decimal(str(result))
        if places > 0:
            quant = Decimal(1).scaleb(-places)
            dr = dr.quantize(quant, rounding=ROUND_HALF_UP)
        return float(dr)
