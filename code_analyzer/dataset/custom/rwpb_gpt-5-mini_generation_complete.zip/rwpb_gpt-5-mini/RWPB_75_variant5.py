
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.array(a, dtype=float)
        b = np.array(b, dtype=float)
        eps = 1e-12
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na <= eps or nb <= eps:
            return None, None
        ua = a / na
        ub = b / nb
        # use stable computation of angle using atan2 and handle degenerate cross
        cross = np.cross(ua, ub)
        s = np.linalg.norm(cross)
        c = np.dot(ua, ub)
        c = float(np.clip(c, -1.0, 1.0))
        if s <= eps:
            # parallel or anti-parallel
            if c > 0:
                return None, None
            else:
                # find a perpendicular axis by selecting the smallest component to swap
                if abs(ua[0]) < abs(ua[1]) and abs(ua[0]) < abs(ua[2]):
                    perp = np.array([0.0, -ua[2], ua[1]])
                elif abs(ua[1]) < abs(ua[2]):
                    perp = np.array([-ua[2], 0.0, ua[0]])
                else:
                    perp = np.array([-ua[1], ua[0], 0.0])
                pn = np.linalg.norm(perp)
                if pn <= eps:
                    return None, None
                axis = perp / pn
                return axis, np.pi
        axis = cross / s
        angle = np.arctan2(s, c)
        return axis, angle
