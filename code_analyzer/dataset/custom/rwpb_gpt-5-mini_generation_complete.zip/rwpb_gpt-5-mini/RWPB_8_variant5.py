
def cvimg2torch(img):
    import numpy as np
    import torch
    def cvimg2torch(img):
        """
        Convert OpenCV-like BGR uint8 HxWx3 or HxWxC (or grayscale HxW) to torch tensor 1xCxHxW.
        This variant assumes BGR and converts to RGB when C==3. Returns float32 normalized to [0,1].
        """
        arr = np.asarray(img)
        if arr.ndim == 2:
            arr = arr[:, :, None]
        if arr.shape[2] == 3:
            # assume BGR -> convert to RGB
            arr = arr[..., ::-1]
        arr = arr.astype(np.float32) / 255.0
        # transpose to CxHxW
        arr = arr.transpose(2, 0, 1).copy()
        tensor = torch.tensor(arr, dtype=torch.float32)
        tensor = tensor.unsqueeze(0)
        return tensor
