
def hole_fill(img):
    import numpy as np
    import cv2
    from collections import deque
    def hole_fill(img):
        arr = np.asarray(img)
        if arr.ndim != 2:
            raise ValueError("Input must be grayscale")
        img_u8 = (arr.copy()).astype(np.uint8)
        # Binary image
        _, bin_img = cv2.threshold(img_u8, 0, 255, cv2.THRESH_BINARY)
        # Inverted: background=1, foreground=0
        inv = (bin_img == 0).astype(np.uint8)
        h, w = inv.shape
        visited = np.zeros_like(inv, dtype=bool)
        dq = deque()
        # Seed queue with border background pixels
        for x in range(w):
            if inv[0, x]:
                dq.append((0, x)); visited[0, x] = True
            if inv[h-1, x]:
                dq.append((h-1, x)); visited[h-1, x] = True
        for y in range(h):
            if inv[y, 0]:
                dq.append((y, 0)); visited[y, 0] = True
            if inv[y, w-1]:
                dq.append((y, w-1)); visited[y, w-1] = True
        # 4-neighborhood flood
        while dq:
            y, x = dq.popleft()
            for ny, nx in ((y-1,x),(y+1,x),(y,x-1),(y,x+1)):
                if 0 <= ny < h and 0 <= nx < w and not visited[ny, nx] and inv[ny, nx]:
                    visited[ny, nx] = True
                    dq.append((ny, nx))
        # Holes are background pixels not visited
        holes = (inv == 1) & (~visited)
        filled = bin_img.copy()
        filled[holes] = 255
        return filled.astype(np.uint8)
