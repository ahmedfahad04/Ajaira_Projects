
def fuse_deconv_and_bn(deconv, bn):
    import torch
    import torch.nn as nn
    def fuse_deconv_and_bn(deconv, bn):
        # Another variant using advanced indexing to build a scaling tensor then broadcasting
        if not isinstance(deconv, nn.ConvTranspose2d) or not isinstance(bn, nn.BatchNorm2d):
            raise ValueError("Expected ConvTranspose2d and BatchNorm2d")
        if bn.num_features != deconv.out_channels:
            raise ValueError("BatchNorm num_features must match deconv out_channels")
        W = deconv.weight.detach().clone()
        device = W.device
        dtype = W.dtype
        running_mean = bn.running_mean.to(device=device, dtype=dtype)
        running_var = bn.running_var.to(device=device, dtype=dtype)
        gamma = bn.weight.to(device=device, dtype=dtype) if bn.weight is not None else torch.ones_like(running_mean)
        beta = bn.bias.to(device=device, dtype=dtype) if bn.bias is not None else torch.zeros_like(running_mean)
        eps = bn.eps
        scale = (gamma / torch.sqrt(running_var + eps)).contiguous()  # [out_channels]
        out_channels = deconv.out_channels
        groups = deconv.groups
        in_channels = deconv.in_channels
        out_per_group = out_channels // groups
        in_per_group = in_channels // groups
        kH, kW = W.shape[2], W.shape[3]
        # Build an index tensor that maps each weight element to an output channel index
        # We create a scale_map of shape (in_channels, out_per_group) where each [ic, j] maps to oc = g*out_per_group + j
        # ic belongs to group g = ic // in_per_group
        ic_indices = torch.arange(in_channels, device=device) // in_per_group  # group index per input channel
        j_indices = torch.arange(out_per_group, device=device).unsqueeze(0).expand(in_channels, out_per_group)
        g_indices = ic_indices.unsqueeze(1).expand(in_channels, out_per_group)
        oc_indices = (g_indices * out_per_group + j_indices).view(in_channels, out_per_group)  # maps to 0..out_channels-1
        scale_map = scale[oc_indices]  # shape (in_channels, out_per_group)
        scale_map = scale_map.view(in_channels, out_per_group, 1, 1)
        W_fused = W * scale_map
        b_conv = deconv.bias.detach().clone() if deconv.bias is not None else torch.zeros(out_channels, device=device, dtype=dtype)
        b_fused = (b_conv - running_mean) * scale + beta
        fused = nn.ConvTranspose2d(
            in_channels=deconv.in_channels,
            out_channels=deconv.out_channels,
            kernel_size=deconv.kernel_size,
            stride=deconv.stride,
            padding=deconv.padding,
            output_padding=deconv.output_padding,
            groups=deconv.groups,
            bias=True,
            dilation=deconv.dilation,
            padding_mode=deconv.padding_mode
        )
        fused.weight.data.copy_(W_fused)
        fused.bias.data.copy_(b_fused)
        return fused
