
def arccos2(vector, value):
    import math
    def arccos2(vector, value):
        try:
            x = float(vector[0])
            y = float(vector[1])
        except Exception:
            x = 0.0
            y = 0.0
        if value != value:
            return float('nan')
        v = value
        if v > 1.0:
            v = 1.0
        elif v < -1.0:
            v = -1.0
        ang = math.acos(v)
        mag = math.hypot(x, y)
        if mag == 0.0:
            return ang
        cross = y
        if cross < 0.0:
            return -ang
        return ang
