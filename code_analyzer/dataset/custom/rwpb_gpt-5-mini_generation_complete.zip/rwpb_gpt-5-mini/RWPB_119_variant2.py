
def rotate_about_x_axis(vector, theta):
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        """
        Rotate using a 3x3 rotation matrix generated with numpy.
        """
        v = np.asarray(vector, dtype=float)
        v = v.flatten()
        if v.size < 3:
            raise ValueError("Input vector must have at least 3 components")
        # rotation matrix about x-axis
        c = np.cos(theta)
        s = np.sin(theta)
        R = np.array([[1.0, 0.0, 0.0],
                      [0.0, c, -s],
                      [0.0, s,  c]], dtype=float)
        res = R.dot(v[:3])
        return np.asarray(res, dtype=float)
