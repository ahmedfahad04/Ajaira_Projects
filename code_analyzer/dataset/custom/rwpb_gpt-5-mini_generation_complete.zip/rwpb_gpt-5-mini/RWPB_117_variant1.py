
def path_spliter(path: str):
    import os
    import re
    def path_spliter(path: str):
        if path is None:
            return []
        path = str(path)
        if path == '':
            return []
        drive, rest = os.path.splitdrive(path)
        # Normalize all separators to the current os.sep for consistent splitting
        rest_norm = re.sub(r'[\\/]+', os.sep, rest)
        parts = []
        p = rest_norm
        while True:
            head, tail = os.path.split(p)
            if tail:
                parts.append(tail)
                p = head
            else:
                if head:
                    parts.append(head)
                break
        parts = list(reversed(parts))
        # Remove empty pieces
        parts = [pt for pt in parts if pt != '']
        if drive:
            if parts and parts[0] == os.sep:
                parts[0] = drive + os.sep
            else:
                parts.insert(0, drive)
        return parts
