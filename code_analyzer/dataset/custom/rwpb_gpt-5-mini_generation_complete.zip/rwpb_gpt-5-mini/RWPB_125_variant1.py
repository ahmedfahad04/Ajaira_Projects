
def resample_segments(segments, n=1000):
    import numpy as np
    def resample_segments(segments, n=1000):
        out = []
        for seg in segments:
            seg = np.asarray(seg, dtype=float)
            if seg.ndim != 2 or seg.shape[1] != 2:
                raise ValueError("Each segment must be an array of shape (m, 2)")
            m = seg.shape[0]
            if m == 0:
                out.append(np.zeros((n, 2), dtype=float))
                continue
            if m == 1:
                out.append(np.tile(seg[0], (n, 1)))
                continue
            deltas = np.diff(seg, axis=0)
            dists = np.sqrt((deltas**2).sum(axis=1))
            cum = np.concatenate(([0.0], np.cumsum(dists)))
            total = cum[-1]
            if total == 0.0:
                out.append(np.tile(seg[0], (n, 1)))
                continue
            target = np.linspace(0.0, total, n)
            x = np.interp(target, cum, seg[:, 0])
            y = np.interp(target, cum, seg[:, 1])
            res = np.vstack((x, y)).T
            out.append(res)
        return out
