
def psnr_to_mse(psnr):
    import math
    import numpy as np
    def psnr_to_mse(psnr):
        if np.isscalar(psnr):
            return math.exp(-0.1 * math.log(10.0) * float(psnr))
        fn = np.vectorize(lambda x: math.exp(-0.1 * math.log(10.0) * float(x)))
        return fn(psnr)
