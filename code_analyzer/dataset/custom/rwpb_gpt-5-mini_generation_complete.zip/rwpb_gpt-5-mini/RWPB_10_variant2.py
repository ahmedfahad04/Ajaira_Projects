
def euler2rot(euler_angle):
    import torch
    def euler2rot(euler_angle):
        if not torch.is_tensor(euler_angle):
            euler_angle = torch.tensor(euler_angle)
        a = euler_angle
        if a.dim() == 1:
            a = a.unsqueeze(0)
        alpha = a[:, 0]; beta = a[:, 1]; gamma = a[:, 2]
        ca = torch.cos(alpha); sa = torch.sin(alpha)
        cb = torch.cos(beta); sb = torch.sin(beta)
        cc = torch.cos(gamma); sc = torch.sin(gamma)
        r00 = cc * cb
        r01 = cc * sb * sa - sc * ca
        r02 = cc * sb * ca + sc * sa
        r10 = sc * cb
        r11 = sc * sb * sa + cc * ca
        r12 = sc * sb * ca - cc * sa
        r20 = -sb
        r21 = cb * sa
        r22 = cb * ca
        R = torch.stack([
            torch.stack([r00, r01, r02], dim=1),
            torch.stack([r10, r11, r12], dim=1),
            torch.stack([r20, r21, r22], dim=1),
        ], dim=1)
        R = R.permute(0,2,1)
        return R
