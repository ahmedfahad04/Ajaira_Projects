
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        x = torch.arange(W, dtype=torch.float32).unsqueeze(0).expand(H, W)
        y = torch.arange(H, dtype=torch.float32).unsqueeze(1).expand(H, W)
        grid = torch.stack((x, y), dim=0)  # (2, H, W)
        return grid.unsqueeze(0).repeat(B, 1, 1, 1)
