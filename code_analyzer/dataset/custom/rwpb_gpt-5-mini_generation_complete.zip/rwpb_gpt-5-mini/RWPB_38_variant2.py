
def extract_imports_from_lines(lines: List[str]) -> str:
    from typing import List
    import re
    def extract_imports_from_lines(lines: List[str]) -> str:
        """
        Regex-based extractor that also handles multi-line imports using parentheses
        or backslash continuations.
        """
        out = []
        i = 0
        n = len(lines)
        start_re = re.compile(r'^\s*(?:from\b.*\bimport\b|import\b)')
        while i < n:
            line = lines[i]
            if start_re.match(line):
                group = [line.rstrip('\n')]
                # track parentheses balance and backslash continuation
                text = line
                paren = text.count('(') - text.count(')')
                cont = text.rstrip().endswith('\\')
                i += 1
                while (paren > 0 or cont) and i < n:
                    nxt = lines[i]
                    group.append(nxt.rstrip('\n'))
                    paren += nxt.count('(') - nxt.count(')')
                    cont = nxt.rstrip().endswith('\\')
                    i += 1
                out.append('\n'.join(g.rstrip() for g in group))
                continue
            i += 1
        return '\n'.join(out)
