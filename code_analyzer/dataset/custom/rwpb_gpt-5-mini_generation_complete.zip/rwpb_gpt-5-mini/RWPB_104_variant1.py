
def mulMod(x, y, z):
    def mulMod(x, y, z):
        if z == 0:
            raise ValueError("modulus must be non-zero")
        x %= z
        y %= z
        result = 0
        while y:
            if y & 1:
                result = (result + x) % z
            x = (x << 1) % z
            y >>= 1
        return result
