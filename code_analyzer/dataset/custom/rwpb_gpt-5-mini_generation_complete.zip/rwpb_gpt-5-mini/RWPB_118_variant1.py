
def filter_nan(ts, vs):
    import numpy as np
    def filter_nan(ts, vs):
        ts = np.asarray(ts)
        vs = np.asarray(vs)
        if ts.shape[0] != vs.shape[0]:
            raise ValueError("ts and vs must have the same length along axis 0")
        # remove entries where either ts or vs is NaN
        mask = ~np.isnan(ts) & ~np.isnan(vs)
        return ts[mask], vs[mask]
