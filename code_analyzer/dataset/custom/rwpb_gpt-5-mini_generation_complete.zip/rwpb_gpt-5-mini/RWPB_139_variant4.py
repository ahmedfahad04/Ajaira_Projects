
def rotate_normalmap_by_angle_torch(normal_map, angle):
    import torch, math
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        """
        Rotate using quaternion conjugation q * v * q_conj for axis = (0,1,0).
        Works for (...,3) tensors.
        """
        if not isinstance(normal_map, torch.Tensor):
            raise TypeError("normal_map must be a torch.Tensor")
        if normal_map.shape[-1] != 3:
            raise ValueError("last dimension must be 3")
        device = normal_map.device
        dtype = normal_map.dtype
        # quaternion representing rotation about y by theta: q = [w, x, y, z]
        theta = math.radians(angle)
        w = math.cos(theta / 2.0)
        sin_half = math.sin(theta / 2.0)
        q = torch.tensor([w, 0.0, sin_half, 0.0], device=device, dtype=dtype)  # axis y
        # q * v * q_conj where v is (0, vx, vy, vz)
        # compute q * v
        v = normal_map
        # Broadcast to (...,4)
        zeros = torch.zeros_like(v[..., :1])
        vq = torch.cat([zeros, v], dim=-1)  # (...,4)
        # quaternion multiplication function
        def qmul(a, b):
            # a,b are (...,4) in order [w,x,y,z]
            aw, ax, ay, az = a.unbind(-1)
            bw, bx, by, bz = b.unbind(-1)
            rw = aw * bw - ax * bx - ay * by - az * bz
            rx = aw * bx + ax * bw + ay * bz - az * by
            ry = aw * by - ax * bz + ay * bw + az * bx
            rz = aw * bz + ax * by - ay * bx + az * bw
            return torch.stack([rw, rx, ry, rz], dim=-1)
        q_expand = q.view(*([1] * (v.dim() - 1)), 4).expand(*v.shape[:-1], 4)
        q_conj = q_expand * torch.tensor([1.0, -1.0, -1.0, -1.0], device=device, dtype=dtype)
        tmp = qmul(q_expand, vq)
        outq = qmul(tmp, q_conj)
        rotated = outq[..., 1:4]
        # Normalize
        norms = rotated.norm(dim=-1, keepdim=True).clamp(min=1e-8)
        return rotated / norms
