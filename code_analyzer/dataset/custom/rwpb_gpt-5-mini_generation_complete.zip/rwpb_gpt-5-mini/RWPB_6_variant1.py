
def format_seconds(seconds: float) -> str:
    def format_seconds(seconds: float) -> str:
        import math
        if not isinstance(seconds, (int, float)):
            raise TypeError("seconds must be a number")
        if not (seconds == seconds) or seconds == float('inf') or seconds == float('-inf'):
            raise ValueError("seconds must be a finite number")
        sign = "-" if seconds < 0 else ""
        total_millis = int(round(abs(seconds) * 1000))
        hours = total_millis // 3_600_000
        rem = total_millis % 3_600_000
        minutes = rem // 60_000
        rem = rem % 60_000
        secs = rem // 1000
        millis = rem % 1000
        if hours >= 1:
            return f"{sign}{hours:02d}:{minutes:02d}:{secs:02d}.{millis:03d}"
        else:
            return f"{sign}{minutes:02d}:{secs:02d}.{millis:03d}"
