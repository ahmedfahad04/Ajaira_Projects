
def numpy_to_pytorch(x):
    import numpy as np
    import torch
    def numpy_to_pytorch(x):
        x = np.asarray(x, dtype=np.float32)
        x = x / 255.0
        x = x[np.newaxis, ...]
        x = np.ascontiguousarray(x)
        return torch.from_numpy(x).float()
