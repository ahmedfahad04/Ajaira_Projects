
def format_seconds(seconds: float) -> str:
    def format_seconds(seconds: float) -> str:
        import math
        if not isinstance(seconds, (int, float)):
            raise TypeError("seconds must be a number")
        if not (seconds == seconds) or seconds == float('inf') or seconds == float('-inf'):
            raise ValueError("seconds must be a finite number")
        neg = seconds < 0
        s = abs(seconds)
        hours = int(s // 3600)
        s -= hours * 3600
        minutes = int(s // 60)
        s -= minutes * 60
        # Round the remaining seconds to 3 decimals and handle carry
        secs_rounded = round(s, 3)
        if secs_rounded >= 60.0:
            secs_rounded -= 60.0
            minutes += 1
        if minutes >= 60:
            hours += minutes // 60
            minutes = minutes % 60
        secs_int = int(math.floor(secs_rounded))
        millis = int(round((secs_rounded - secs_int) * 1000))
        # rounding of millis might produce 1000
        if millis >= 1000:
            millis -= 1000
            secs_int += 1
            if secs_int >= 60:
                secs_int -= 60
                minutes += 1
                if minutes >= 60:
                    minutes -= 60
                    hours += 1
        sign = "-" if neg else ""
        if hours >= 1:
            return f"{sign}{hours:02d}:{minutes:02d}:{secs_int:02d}.{millis:03d}"
        else:
            return f"{sign}{minutes:02d}:{secs_int:02d}.{millis:03d}"
