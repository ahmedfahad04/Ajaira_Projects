
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        if not isinstance(image, np.ndarray):
            raise ValueError("Input must be a numpy.ndarray")
        if image.ndim == 2:
            t = torch.from_numpy(image).unsqueeze(0).float() / 255.0
            return t
        if image.ndim == 3:
            if image.shape[2] < 1:
                raise ValueError("Invalid image shape")
            t = torch.from_numpy(image).float().permute(2, 0, 1) / 255.0
            return t
        raise ValueError("Not a valid image")
