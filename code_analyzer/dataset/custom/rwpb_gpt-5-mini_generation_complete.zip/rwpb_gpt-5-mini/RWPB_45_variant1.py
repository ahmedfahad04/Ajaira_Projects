
def invalid_to_zeros(arr, valid_mask, ndim=999):
    import torch
    def invalid_to_zeros(arr, valid_mask, ndim=999):
        # Ensure tensor
        if not isinstance(arr, torch.Tensor):
            arr = torch.tensor(arr)
        # Optionally flatten trailing dims if arr has more dims than ndim
        if ndim != 999 and arr.dim() > ndim:
            new_shape = list(arr.shape[:ndim - 1]) + [-1]
            arr = arr.view(*new_shape)
        # If no mask provided, assume all valid and compute nnz per-image as described
        if valid_mask is None:
            if arr.dim() >= 1:
                nnz = arr.numel() // arr.shape[0]
            else:
                nnz = arr.numel()
            return arr, nnz
        mask = valid_mask.bool()
        # If mask has exactly same number of elements, reshape to arr shape
        if mask.numel() == arr.numel():
            mask = mask.view_as(arr)
            # In-place zeroing of invalid entries
            arr[~mask] = 0
            # Compute nnz per image if possible (first dim as batch)
            if arr.dim() >= 1:
                nnz = mask.view(arr.shape[0], -1).sum(dim=1)
            else:
                nnz = mask.sum()
            return arr, nnz
        # If mask has same leading batch dimension: treat as per-point mask
        if arr.dim() >= 1 and mask.numel() == arr.shape[0]:
            # per-image boolean (all valid or not)
            nnz = mask.to(torch.long)
            # nothing to zero (no finer mask), return arr unchanged
            return arr, nnz
        # Try to broadcast mask to arr shape
        try:
            mask = mask.view(arr.shape[0], -1)
            # expand to arr dims by adding singleton dims
            extra_dims = arr.dim() - 2
            if extra_dims > 0:
                shape = list(mask.shape) + [1] * extra_dims
                mask = mask.view(*shape).expand_as(arr).contiguous()
            else:
                mask = mask.view_as(arr)
            arr[~mask] = 0
            nnz = mask.view(arr.shape[0], -1).sum(dim=1)
            return arr, nnz
        except Exception:
            # fallback: compute scalar nnz if nothing fits
            scalar_nnz = int(mask.sum().item()) if mask.numel() > 0 else 0
            # Try to broadcast mask to arr and zero where False if possible
            try:
                mask_exp = mask.reshape(-1).to(dtype=torch.bool)
                if mask_exp.numel() == arr.numel():
                    mask_exp = mask_exp.view_as(arr)
                    arr[~mask_exp] = 0
            except Exception:
                pass
            return arr, scalar_nnz
