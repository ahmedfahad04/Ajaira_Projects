
def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
    import numpy as np
    def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
        tokens = np.asarray(tokens)
        target = max(0, int(context_window) + 1)
        if tokens.ndim == 0:
            tokens = tokens.reshape(1)
        seq_len = tokens.shape[-1]
        out_shape = tokens.shape[:-1] + (target,)
        out = np.full(out_shape, pad_token, dtype=tokens.dtype)
        copy_len = min(seq_len, target)
        if copy_len > 0:
            in_slices = tuple([slice(None)] * (tokens.ndim - 1) + [slice(0, copy_len)])
            out[in_slices] = tokens[in_slices]
        return out if tokens.ndim > 1 else out.reshape((target,))
