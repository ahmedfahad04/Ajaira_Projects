
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        arr = np.asarray(arr, dtype=float).ravel()
        n = arr.size
        if window_size <= 0:
            raise ValueError("window_size must be positive")
        if n == 0:
            return np.array([]), np.array([])
        k = min(window_size, n)
        # Convolution-based 'same' moving average with correct edge counts
        conv_sum = np.convolve(arr, np.ones(k, dtype=float), mode='same')
        counts = np.convolve(np.ones(n, dtype=float), np.ones(k, dtype=float), mode='same')
        moving = conv_sum / counts
        residuals = arr - moving
        return np.asarray(moving), np.asarray(residuals)
