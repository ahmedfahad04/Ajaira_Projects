
def clean_html(:
    import re
    from typing import List
    from html import escape
    def clean_html(
            html_to_clean: str,
            tags_to_remove: List[str] = ["style", "svg", "script"],
            attributes_to_keep: List[str] = ["id", "href"],
    ) -> str:
        s = html_to_clean
        # Remove tags_to_remove (both contentful and self-closing)
        for tag in tags_to_remove:
            s = re.sub(rf'(?is)<{re.escape(tag)}\b[^>]*?>.*?</{re.escape(tag)}\s*>', '', s)
            s = re.sub(rf'(?is)<{re.escape(tag)}\b[^>]*?/>', '', s)
        keep = set(a.lower() for a in attributes_to_keep)
        # Parse tags and attributes with a simple regex and reconstruct tags keeping only allowed attributes
        def process_tag(match):
            full = match.group(0)
            if full.startswith("</"):
                return full  # end tag unchanged
            if full.startswith("<!--") or full.startswith("<!"):
                return full  # keep comments/decl
            # get tag name
            m = re.match(r'<\s*([^\s>/]+)(.*?)(/?)\s*>', full, re.S)
            if not m:
                return full
            tagname = m.group(1)
            attrstr = m.group(2) or ""
            selfclose = m.group(3)
            # find attributes
            attrs = []
            for am in re.finditer(r'([^\s=<>/]+)(\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^>\s]+)))?', attrstr, re.S):
                name = am.group(1)
                if name.lower() in keep:
                    if am.group(3) is not None:
                        val = am.group(3)
                    elif am.group(4) is not None:
                        val = am.group(4)
                    elif am.group(5) is not None:
                        val = am.group(5)
                    else:
                        val = None
                    if val is None:
                        attrs.append(name)
                    else:
                        attrs.append(f'{name}="{escape(val, quote=True)}"')
            attr_text = (" " + " ".join(attrs)) if attrs else ""
            return f"<{tagname}{attr_text}{('/' if selfclose else '')}>"
        out = re.sub(r'(?s)<[^>]+>', process_tag, s)
        return out
