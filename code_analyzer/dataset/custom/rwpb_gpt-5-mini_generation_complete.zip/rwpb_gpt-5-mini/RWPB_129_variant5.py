
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        """
        Simple, robust implementation:
        - If padding=False: straightforward bilinear resize.
        - If padding=True: determine scale factor between original mask spatial dims and the letterbox square,
          perform resize by factor then center-crop. This handles non-square input masks sensibly.
        """
        if not isinstance(masks, torch.Tensor):
            masks = torch.tensor(masks)
        if masks.ndim != 4:
            raise ValueError("masks must be 4D (N,C,H,W)")
        N, C, H, W = masks.shape
        th, tw = shape
        # If no change needed
        if not padding and (H == th and W == tw):
            return masks
        if not padding:
            return F.interpolate(masks, size=(th, tw), mode='bilinear', align_corners=False)
        # padding=True:
        s = max(th, tw)
        # Compute a scale that maps the current masks spatial size to the letterboxed square.
        # We choose the larger scale so we don't downsample below square size unexpectedly.
        scale_h = s / H
        scale_w = s / W
        scale = max(scale_h, scale_w)
        new_h = max(1, int(round(H * scale)))
        new_w = max(1, int(round(W * scale)))
        up = F.interpolate(masks, size=(new_h, new_w), mode='bilinear', align_corners=False)
        # center-crop to exactly s x s if needed, otherwise pad
        pad_h = max(0, s - new_h)
        pad_w = max(0, s - new_w)
        if pad_h > 0 or pad_w > 0:
            pad_top = pad_h // 2
            pad_bottom = pad_h - pad_top
            pad_left = pad_w // 2
            pad_right = pad_w - pad_left
            up = F.pad(up, (pad_left, pad_right, pad_top, pad_bottom))
        # Now up is at least s x s; crop center s x s
        start_y = (up.shape[2] - s) // 2
        start_x = (up.shape[3] - s) // 2
        square = up[:, :, start_y:start_y + s, start_x:start_x + s]
        # Finally center-crop to target (th, tw)
        y0 = (s - th) // 2
        x0 = (s - tw) // 2
        out = square[:, :, y0:y0 + th, x0:x0 + tw]
        return out
