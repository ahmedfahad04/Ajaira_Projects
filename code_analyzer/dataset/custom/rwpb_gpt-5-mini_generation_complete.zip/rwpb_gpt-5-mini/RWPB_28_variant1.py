
def mean(l, ignore_nan=False, empty=0):
    import math
    def mean(l, ignore_nan=False, empty=0):
        """
        Simple single-pass implementation that collects non-NaN values and uses math.fsum for accuracy.
        """
        it = iter(l)
        vals = []
        for x in it:
            try:
                is_nan = math.isnan(x)
            except Exception:
                is_nan = False
            if ignore_nan and is_nan:
                continue
            try:
                vals.append(float(x))
            except Exception:
                vals.append(x)
        if not vals:
            if empty == 'raise':
                raise ValueError("mean of empty iterable")
            return empty
        total = math.fsum(vals)
        return total / len(vals)
