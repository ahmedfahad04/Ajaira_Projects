
def interpolate_features(features,:
    import numpy as np
    def interpolate_features(features, input_rate, output_rate, output_len):
        features = np.asarray(features)
        if output_len <= 0:
            if features.ndim == 1:
                return np.zeros((0,), dtype=features.dtype)
            else:
                return np.zeros((0, features.shape[1]), dtype=features.dtype)
        if features.ndim == 1:
            xp = np.arange(features.shape[0])
            x = np.arange(output_len) * (input_rate / float(output_rate))
            x = np.clip(x, xp[0], xp[-1])
            return np.interp(x, xp, features).astype(features.dtype, copy=False)
        T, D = features.shape
        xp = np.arange(T)
        x = np.arange(output_len) * (input_rate / float(output_rate))
        x = np.clip(x, xp[0], xp[-1])
        out_cols = []
        for d in range(D):
            col = features[:, d]
            out_col = np.interp(x, xp, col)
            out_cols.append(out_col)
        out = np.vstack(out_cols).T
        return out.astype(features.dtype, copy=False)
