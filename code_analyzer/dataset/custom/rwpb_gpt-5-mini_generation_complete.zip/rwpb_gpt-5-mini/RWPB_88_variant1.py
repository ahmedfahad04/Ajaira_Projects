
def rotate_y(a, device=None):
    import torch
    def rotate_y(a, device=None):
        dev = torch.device(device) if device is not None else None
        a_t = torch.as_tensor(a, device=dev, dtype=torch.get_default_dtype())
        c = torch.cos(a_t)
        s = torch.sin(a_t)
        dtype = a_t.dtype
        if dev is None:
            M = torch.eye(4, dtype=dtype)
        else:
            M = torch.eye(4, dtype=dtype, device=dev)
        M[0,0] = c
        M[0,2] = s
        M[1,1] = 1.0
        M[2,0] = -s
        M[2,2] = c
        return M
