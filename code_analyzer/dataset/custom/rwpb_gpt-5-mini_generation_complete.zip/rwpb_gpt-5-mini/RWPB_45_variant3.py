
def invalid_to_zeros(arr, valid_mask, ndim=999):
    import torch
    def invalid_to_zeros(arr, valid_mask, ndim=999):
        if not isinstance(arr, torch.Tensor):
            arr = torch.tensor(arr)
        # If need to flatten dimensions beyond ndim, collapse trailing dims
        if ndim != 999 and arr.dim() > ndim:
            target = list(arr.shape[:ndim - 1]) + [-1]
            arr = arr.view(*target)
        if valid_mask is None:
            nnz = arr.numel() // arr.shape[0] if arr.dim() >= 1 else arr.numel()
            return arr, nnz
        mask = valid_mask.bool()
        # Prefer using masked_fill_ (in-place) with broadcasting
        # Try to make mask broadcastable to arr
        if mask.numel() == arr.numel():
            mask_shaped = mask.view_as(arr)
        else:
            # Try batch-wise mask (B, M) -> expand to B, M, 1, 1...
            if arr.dim() >= 2 and mask.numel() == arr.shape[0] * (mask.numel() // arr.shape[0]):
                mask_shaped = mask.view(arr.shape[0], -1)
            else:
                try:
                    mask_shaped = mask.view(arr.shape[0], -1)
                except Exception:
                    # Last resort: flatten mask to match flattened arr
                    flat_mask = mask.reshape(-1)
                    if flat_mask.numel() == arr.numel():
                        mask_shaped = flat_mask.view_as(arr)
                    else:
                        # can't align; assume mask is per-batch boolean
                        if mask.numel() == arr.shape[0]:
                            nnz = mask.to(torch.long)
                            return arr, nnz
                        raise ValueError("valid_mask cannot be aligned with arr")
        # If mask_shaped is 2D but arr has more dims, unsqueeze and expand
        if mask_shaped.dim() == 2 and arr.dim() > 2:
            shape = list(mask_shaped.shape) + [1] * (arr.dim() - 2)
            mask_shaped = mask_shaped.view(*shape).expand_as(arr)
        else:
            mask_shaped = mask_shaped.expand_as(arr) if mask_shaped.shape != arr.shape else mask_shaped
        # Use masked_fill_ to zero invalids in-place
        arr.masked_fill_(~mask_shaped, 0)
        # Compute nnz per image if possible
        if arr.dim() >= 1:
            nnz = mask_shaped.view(arr.shape[0], -1).sum(dim=1)
        else:
            nnz = mask_shaped.sum()
        return arr, nnz
