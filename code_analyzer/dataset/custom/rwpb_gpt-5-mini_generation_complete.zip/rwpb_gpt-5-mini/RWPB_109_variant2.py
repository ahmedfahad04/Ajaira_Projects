
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        # Convert inputs to tensors if needed
        if not isinstance(geometry, torch.Tensor):
            geometry = torch.tensor(geometry)
        if not isinstance(rot, torch.Tensor):
            rot = torch.tensor(rot)
        if not isinstance(trans, torch.Tensor):
            trans = torch.tensor(trans)
        B = geometry.shape[0]
        # Broadcast rot and trans to batch if necessary
        if rot.dim() == 2:
            rot = rot.unsqueeze(0).expand(B, -1, -1)
        if trans.dim() == 1:
            trans = trans.unsqueeze(0).expand(B, -1)
        # Use einsum to perform batched multiplication: sum over k
        rotated = torch.einsum('bnk,bkd->bnd', geometry, rot)
        return rotated + trans.unsqueeze(1)
