
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    import numpy as np
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        # Convert to numpy for calculation (works on CPU - will move tensors)
        if torch.is_tensor(preds):
            preds_np = preds.detach().cpu().numpy()
        else:
            preds_np = np.array(preds)
        if torch.is_tensor(labels):
            labels_np = labels.detach().cpu().numpy()
        else:
            labels_np = np.array(labels)
        # Squeeze channel dim if present
        if preds_np.ndim == 4 and preds_np.shape[1] == 1:
            preds_np = preds_np.squeeze(1)
        if labels_np.ndim == 4 and labels_np.shape[1] == 1:
            labels_np = labels_np.squeeze(1)
        if preds_np.shape != labels_np.shape:
            raise ValueError("preds and labels must have the same shape")
        preds_bool = preds_np > 0.5
        labels_bool = labels_np > 0.5
        if preds_bool.ndim == 2:
            preds_bool = preds_bool[np.newaxis, ...]
            labels_bool = labels_bool[np.newaxis, ...]
        n = preds_bool.shape[0]
        ious = []
        for i in range(n):
            p = preds_bool[i].copy()
            l = labels_bool[i].copy()
            if ignore is not None:
                mask = (labels_np[i] == ignore)
                if mask.any():
                    p[mask] = False
                    l[mask] = False
            inter = int((p & l).sum())
            union = int((p | l).sum())
            if union == 0:
                ious.append(float(EMPTY))
            else:
                ious.append(inter / union)
        if per_image:
            return float(np.mean(ious) * 100.0)
        else:
            # global
            all_p = preds_bool.copy()
            all_l = labels_bool.copy()
            if ignore is not None:
                for i in range(n):
                    mask = (labels_np[i] == ignore)
                    if mask.any():
                        all_p[i][mask] = False
                        all_l[i][mask] = False
            inter = int((all_p & all_l).sum())
            union = int((all_p | all_l).sum())
            if union == 0:
                return float(EMPTY * 100.0)
            return float((inter / union) * 100.0)
