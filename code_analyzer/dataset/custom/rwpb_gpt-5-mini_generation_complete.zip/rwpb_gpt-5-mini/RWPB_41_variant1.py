
def merge_short_sentences_en(sens):
    def merge_short_sentences_en(sens):
        """Simple greedy merge: if a sentence has <=3 words, merge it with the following sentence.
        If the last sentence is short and has no following sentence, merge it with the previous one.
        """
        if not sens:
            return []
        res = []
        i = 0
        n = len(sens)
        while i < n:
            curr = sens[i].strip()
            words = curr.split()
            if len(words) <= 3 and i + 1 < n:
                # merge with next
                nxt = sens[i + 1].strip()
                merged = curr
                if merged and merged[-1] not in '.!?':
                    # keep punctuation of next; just join
                    merged = merged + ' ' + nxt
                else:
                    merged = merged + ' ' + nxt
                res.append(merged)
                i += 2
            else:
                # if last short and no next, attach to previous result if exists
                if len(words) <= 3 and i == n - 1 and res:
                    prev = res.pop()
                    combined = prev.rstrip() + ' ' + curr
                    res.append(combined)
                    i += 1
                else:
                    res.append(curr)
                    i += 1
        return res
