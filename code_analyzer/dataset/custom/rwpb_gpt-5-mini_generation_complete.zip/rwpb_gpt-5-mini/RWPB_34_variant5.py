
def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
    import numpy as np
    def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
        arr = np.asarray(tokens)
        target = max(0, int(context_window) + 1)
        if arr.ndim == 0:
            arr = arr.reshape(1)
        seq_len = arr.shape[-1]
        lead_shape = arr.shape[:-1]
        flat = arr.reshape(-1, seq_len)
        rows = []
        for row in flat:
            row_trunc = row[:target].tolist()
            if len(row_trunc) < target:
                row_trunc.extend([pad_token] * (target - len(row_trunc)))
            rows.append(row_trunc)
        out = np.array(rows, dtype=arr.dtype).reshape(lead_shape + (target,))
        if arr.ndim == 1:
            return out.reshape((target,))
        return out
