
def round_nearest_multiple(number, a, direction='standard'):
    import math
    from decimal import Decimal
    def round_nearest_multiple(number, a, direction='standard'):
        if a == 0:
            raise ValueError("a must be non-zero")
        # Determine decimal places from a using Decimal for robust parsing
        da = Decimal(str(a))
        places = -da.as_tuple().exponent if da.as_tuple().exponent < 0 else 0
        # Work with float quotient
        q = number / a
        dir_lower = (direction or 'standard').lower()
        if dir_lower == 'standard':
            # nearest with halves away from zero
            if q >= 0:
                k = int(math.floor(q + 0.5))
            else:
                k = int(math.ceil(q - 0.5))
        elif dir_lower == 'down':
            k = int(math.floor(q))
        elif dir_lower == 'up':
            k = int(math.ceil(q))
        else:
            raise ValueError("direction must be 'standard', 'down', or 'up'")
        result = k * a
        # Format to same number of decimal places as 'a'
        if places > 0:
            fmt = "{:." + str(places) + "f}"
            return float(fmt.format(result))
        else:
            return float(round(result))
