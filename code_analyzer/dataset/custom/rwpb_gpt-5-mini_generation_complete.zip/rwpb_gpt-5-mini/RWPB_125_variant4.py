
def resample_segments(segments, n=1000):
    import numpy as np
    def resample_segments(segments, n=1000):
        outputs = []
        for seg in segments:
            seg = np.asarray(seg, dtype=float)
            if seg.size == 0:
                outputs.append(np.zeros((n, 2), dtype=float))
                continue
            if seg.ndim != 2 or seg.shape[1] != 2:
                raise ValueError("Each segment must be an array of shape (m, 2)")
            m = seg.shape[0]
            if m == 1:
                outputs.append(np.tile(seg[0], (n, 1)))
                continue
            # parametrize by normalized cumulative length t in [0,1]
            dif = np.diff(seg, axis=0)
            lens = np.sqrt((dif**2).sum(axis=1))
            cum = np.concatenate(([0.0], np.cumsum(lens)))
            total = cum[-1]
            if total == 0.0:
                outputs.append(np.tile(seg[0], (n, 1)))
                continue
            t = cum / total
            tnew = np.linspace(0.0, 1.0, n)
            x = np.interp(tnew, t, seg[:, 0])
            y = np.interp(tnew, t, seg[:, 1])
            outputs.append(np.column_stack((x, y)))
        return outputs
