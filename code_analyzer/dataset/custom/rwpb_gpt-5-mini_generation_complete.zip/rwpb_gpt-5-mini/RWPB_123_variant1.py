
def fuse_deconv_and_bn(deconv, bn):
    import torch
    import torch.nn as nn
    def fuse_deconv_and_bn(deconv, bn):
        if not isinstance(deconv, nn.ConvTranspose2d) or not isinstance(bn, nn.BatchNorm2d):
            raise ValueError("Expected ConvTranspose2d and BatchNorm2d")
        if bn.num_features != deconv.out_channels:
            raise ValueError("BatchNorm num_features must match deconv out_channels")
        # Prepare tensors
        W = deconv.weight.detach().clone()
        device = W.device
        dtype = W.dtype
        running_mean = bn.running_mean.to(device=device, dtype=dtype)
        running_var = bn.running_var.to(device=device, dtype=dtype)
        gamma = bn.weight.to(device=device, dtype=dtype) if bn.weight is not None else torch.ones_like(running_mean)
        beta = bn.bias.to(device=device, dtype=dtype) if bn.bias is not None else torch.zeros_like(running_mean)
        eps = bn.eps
        scale = gamma / torch.sqrt(running_var + eps)  # shape [out_channels]
        out_channels = deconv.out_channels
        groups = deconv.groups
        in_channels = deconv.in_channels
        # Reshape weight to group layout: (groups, in_per_group, out_per_group, kH, kW)
        out_per_group = out_channels // groups
        in_per_group = in_channels // groups
        kH, kW = W.shape[2], W.shape[3]
        # W shape is (in_channels, out_per_group, kH, kW)
        Wg = W.view(groups, in_per_group, out_per_group, kH, kW)
        scale_g = scale.view(groups, out_per_group)  # (groups, out_per_group)
        scale_g = scale_g.view(groups, 1, out_per_group, 1, 1)  # broadcastable
        Wg = Wg * scale_g
        W_fused = Wg.view_as(W)
        # Bias
        b_conv = deconv.bias.detach().clone() if deconv.bias is not None else torch.zeros(out_channels, device=device, dtype=dtype)
        b_fused = (b_conv - running_mean) * scale + beta
        # Create new layer
        fused = nn.ConvTranspose2d(
            in_channels=deconv.in_channels,
            out_channels=deconv.out_channels,
            kernel_size=deconv.kernel_size,
            stride=deconv.stride,
            padding=deconv.padding,
            output_padding=deconv.output_padding,
            groups=deconv.groups,
            bias=True,
            dilation=deconv.dilation,
            padding_mode=deconv.padding_mode
        )
        fused.weight.data.copy_(W_fused)
        fused.bias.data.copy_(b_fused)
        return fused
