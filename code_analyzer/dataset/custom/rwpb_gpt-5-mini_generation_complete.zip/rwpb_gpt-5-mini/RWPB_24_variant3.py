
def check(x, checksum_token):
    import re
    import hashlib
    def check(x, checksum_token):
        matches = list(re.finditer(r'[0-9A-Fa-f]{64}', x))
        if not matches:
            return False
        m = matches[-1]
        orig = m.group(0)
        new_s = x[:m.start()] + checksum_token + x[m.end():]
        computed = hashlib.sha256(new_s.encode()).hexdigest()
        return computed.lower() == orig.lower()
