
def dynamic_import_function(function_path):
    def dynamic_import_function(function_path):
        from importlib import import_module
        if not isinstance(function_path, str) or '.' not in function_path:
            return ModuleNotFoundError(f"Invalid function path: {function_path}")
        module_path, _, attr = function_path.rpartition('.')
        try:
            module = import_module(module_path)
        except Exception as e:
            return ModuleNotFoundError(f"Module import failed: {e}")
        try:
            return getattr(module, attr)
        except Exception:
            return ModuleNotFoundError(f"Attribute '{attr}' not found in module '{module_path}'")
