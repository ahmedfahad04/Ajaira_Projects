
def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
    import torch
    def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
        import torch
        t_val = v0.new_tensor(t)
        v0d = v0.to(v0.dtype)
        v1d = v1.to(v0.dtype)
        def _unit(x):
            n = torch.norm(x, dim=-1, keepdim=True)
            return x / (n + 1e-12), n
        u0, n0 = _unit(v0d)
        u1, n1 = _unit(v1d)
        dot = torch.sum(u0 * u1, dim=-1, keepdim=True)
        dot = torch.clamp(dot, -1.0, 1.0)
        if torch.all(torch.abs(dot) > DOT_THRESHOLD):
            res_unit = (1.0 - t_val) * u0 + t_val * u1
            res_unit = res_unit / (torch.norm(res_unit, dim=-1, keepdim=True) + 1e-12)
        else:
            theta = torch.acos(dot)
            sin_theta = torch.sin(theta)
            s0 = torch.sin((1.0 - t_val) * theta) / (sin_theta + 1e-12)
            s1 = torch.sin(t_val * theta) / (sin_theta + 1e-12)
            res_unit = s0 * u0 + s1 * u1
        res = res_unit * ((1.0 - t_val) * n0 + t_val * n1)
        return res
