
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        arr = np.asarray(img)
        if arr.ndim != 2:
            raise ValueError("Input must be grayscale")
        img_u8 = (arr.copy()).astype(np.uint8)
        # Binary: foreground = 255, background = 0
        _, bin_img = cv2.threshold(img_u8, 0, 255, cv2.THRESH_BINARY)
        # Background mask (1 where background)
        background = (bin_img == 0).astype(np.uint8)
        # Connected components on background
        num_labels, labels = cv2.connectedComponents(background, connectivity=4)
        if num_labels <= 1:
            return bin_img
        # Find label of border-connected background (take pixel at (0,0))
        border_label = int(labels[0, 0])
        # Any background pixel not connected to border is a hole
        holes_mask = (background == 1) & (labels != border_label)
        # Fill holes (set to foreground)
        filled = bin_img.copy()
        filled[holes_mask] = 255
        return filled.astype(np.uint8)
