
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        if repetition_penalty == 1.0 or repetition_penalty == 0:
            return logits
        logits = logits.clone()
        batch_size = logits.size(0)
        device = logits.device
        dtype = logits.dtype
        for b in range(batch_size):
            prev = prev_output_tokens[b]
            # use torch.unique to avoid applying penalty multiple times
            unique_tokens = torch.unique(prev)
            # ignore negative/padding tokens
            unique_tokens = unique_tokens[unique_tokens >= 0]
            if unique_tokens.numel() == 0:
                continue
            # gather current scores
            scores = logits[b, unique_tokens]
            # build multipliers
            pos_mask = scores > 0
            multipliers = torch.ones_like(scores, dtype=dtype, device=device)
            multipliers = torch.where(pos_mask, multipliers / repetition_penalty, multipliers * repetition_penalty)
            logits[b, unique_tokens] = scores * multipliers
        return logits
