
def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
    from typing import Callable, Dict, Tuple, Any
    import inspect
    from functools import partial
    def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
        target = func
        try:
            sig = inspect.signature(target)
        except (TypeError, ValueError):
            if hasattr(func, "__call__") and not inspect.isroutine(func):
                try:
                    sig = inspect.signature(func.__call__)
                    target = func.__call__
                except (TypeError, ValueError):
                    return partial(func), {}
            else:
                return partial(func), {}
        applicable = {}
        has_varkw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
        for k, v in params.items():
            if not isinstance(k, str):
                continue
            if has_varkw:
                applicable[k] = v
            else:
                p = sig.parameters.get(k)
                if p is None:
                    continue
                if p.kind == inspect.Parameter.POSITIONAL_ONLY or p.kind == inspect.Parameter.VAR_POSITIONAL:
                    continue
                applicable[k] = v
        return partial(func, **applicable), applicable
