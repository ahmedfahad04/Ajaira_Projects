
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        # Ensure grayscale uint8
        arr = np.asarray(img)
        if arr.ndim != 2:
            raise ValueError("Input must be a grayscale image")
        img_u8 = (arr.copy()).astype(np.uint8)
        # Binary foreground mask (non-zero is foreground)
        _, bin_img = cv2.threshold(img_u8, 0, 255, cv2.THRESH_BINARY)
        # Invert binary image
        inv = cv2.bitwise_not(bin_img)
        # Flood fill from (0,0) on inverted image to get external background
        im_floodfill = inv.copy()
        h, w = bin_img.shape[:2]
        mask = np.zeros((h + 2, w + 2), np.uint8)
        cv2.floodFill(im_floodfill, mask, (0, 0), 255)
        # Invert floodfilled image -> this gives holes as white
        im_floodfill_inv = cv2.bitwise_not(im_floodfill)
        # Combine original binary with the holes mask
        filled = cv2.bitwise_or(bin_img, im_floodfill_inv)
        return filled.astype(np.uint8)
