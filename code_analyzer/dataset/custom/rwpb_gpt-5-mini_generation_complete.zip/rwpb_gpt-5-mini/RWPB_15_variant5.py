
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        # tolerant wrapper that accepts lists/tuples as well
        a = np.asarray(a, dtype=float).flatten()
        b = np.asarray(b, dtype=float)
        if a.ndim != 1:
            return KeyError("a must be 1-D")
        # helper to ensure matching lengths
        def _check_len(vec):
            return vec.shape[0] == a.shape[0]
        if b.ndim == 1:
            if not _check_len(b):
                return KeyError("length mismatch")
            na = np.sqrt((a * a).sum())
            nb = np.sqrt((b * b).sum())
            if na == 0 or nb == 0:
                # undefined cosine; return nan
                return float('nan')
            cos = (a * b).sum() / (na * nb)
            cos = float(np.clip(cos, -1.0, 1.0))
            return 1.0 - cos
        elif b.ndim == 2:
            if b.shape[1] != a.shape[0]:
                return KeyError("length mismatch")
            # compute matrix of similarities by treating rows as vectors
            # use transpose for efficient broadcasting
            a_col = a[:, None]  # (m,1)
            # compute dot products: rows dot a = (b * a) sum axis=1
            dots = (b * a_col.T).sum(axis=1)
            na = np.sqrt((a * a).sum())
            b_norms = np.sqrt((b * b).sum(axis=1))
            denom = na * b_norms
            # where denom==0 produce nan
            with np.errstate(invalid='ignore', divide='ignore'):
                cos = dots / denom
            cos = np.clip(cos, -1.0, 1.0)
            d = 1.0 - cos
            d = np.where(denom == 0, np.nan, d)
            return d
        else:
            return KeyError("b must be vector or matrix")
