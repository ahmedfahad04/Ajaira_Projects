
def pr_from_grav(grav):
    import numpy as np
    def pr_from_grav(grav):
        grav = np.asarray(grav, dtype=float)
        if grav.ndim == 1:
            if grav.size != 3:
                raise ValueError("grav must be shape (n,3) or (3,)")
            grav = grav.reshape(1, 3)
        if grav.ndim != 2 or grav.shape[1] != 3:
            raise ValueError("grav must have shape (n,3)")
        # Normalize gravity vectors to unit length
        norms = np.linalg.norm(grav, axis=1, keepdims=True)
        # Avoid division by zero
        eps = np.finfo(float).eps
        norms = np.maximum(norms, eps)
        gnorm = grav / norms
        gx = gnorm[:, 0]
        gy = gnorm[:, 1]
        gz = gnorm[:, 2]
        # pitch from arcsin of x component (negative because gravity points down)
        pitches = np.arcsin(np.clip(-gx, -1.0, 1.0))
        # roll from atan2 of y and z
        rolls = np.arctan2(gy, gz)
        return pitches, rolls
