
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        if tensor1.shape[0] != tensor2.shape[0]:
            raise ValueError("First dimension sizes must match")
        rest = tensor1.shape[1:]
        stacked = torch.stack((tensor1, tensor2), dim=1)
        out1 = stacked.reshape(-1, *rest)
        swapped = stacked[:, [1, 0]].reshape(-1, *rest)
        out2 = swapped
        return out1, out2
