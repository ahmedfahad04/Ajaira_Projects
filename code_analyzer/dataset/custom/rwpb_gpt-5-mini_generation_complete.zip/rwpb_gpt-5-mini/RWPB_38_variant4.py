
def extract_imports_from_lines(lines: List[str]) -> str:
    from typing import List
    def extract_imports_from_lines(lines: List[str]) -> str:
        """
        State-machine extractor that skips content inside triple-quoted strings (docstrings)
        and collects import statements, handling multi-line imports with parentheses or backslash.
        """
        out = []
        i = 0
        n = len(lines)
        in_triple = False
        triple_delim = None
        while i < n:
            line = lines[i]
            s = line
            # manage triple quotes toggling
            if not in_triple:
                # look for start of triple quotes
                if "'''" in s or '"""' in s:
                    # determine first occurrence
                    idx1 = s.find("'''") if "'''" in s else -1
                    idx2 = s.find('"""') if '"""' in s else -1
                    candidates = [(idx1, "'''"), (idx2, '"""')]
                    candidates = [(idx, d) for idx, d in candidates if idx != -1]
                    idxs = sorted(candidates, key=lambda x: x[0])
                    if idxs:
                        idx, delim = idxs[0]
                        # if triple quote starts before any import, we enter triple mode
                        # but still check if import starts before the triple quote
                        prefix = s[:idx].lstrip()
                        if prefix.startswith('import ') or prefix.startswith('from '):
                            # treat as import line before docstring start
                            pass
                        # if triple quote opens, enter skip mode
                        in_triple = True
                        triple_delim = delim
            else:
                # we are inside triple quoted block; look for close
                if triple_delim in s:
                    in_triple = False
                    triple_delim = None
                i += 1
                continue
            stripped = s.lstrip()
            if stripped.startswith('#'):
                i += 1
                continue
            if stripped.startswith('import ') or stripped.startswith('from '):
                group = [s.rstrip('\n')]
                paren = s.count('(') - s.count(')')
                cont = s.rstrip().endswith('\\')
                i += 1
                while (paren > 0 or cont) and i < n:
                    nxt = lines[i]
                    group.append(nxt.rstrip('\n'))
                    paren += nxt.count('(') - nxt.count(')')
                    cont = nxt.rstrip().endswith('\\')
                    i += 1
                out.append('\n'.join(g.rstrip() for g in group))
                continue
            i += 1
        return '\n'.join(out)
