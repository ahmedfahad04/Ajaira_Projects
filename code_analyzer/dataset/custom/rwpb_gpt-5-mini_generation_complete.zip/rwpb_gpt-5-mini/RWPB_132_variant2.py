
def B_batch(x, grid, k=0, extend=True, device="cpu"):
    import torch
    def B_batch(x, grid, k=0, extend=True, device="cpu"):
        x = x.to(device)
        grid = grid.to(device)
        S, N = x.shape
        assert grid.shape[0] == S
        dtype = x.dtype
        results = []
        for s in range(S):
            u = x[s].unsqueeze(0)  # (1,N)
            knots_inner = grid[s]
            m = knots_inner.numel()
            if k > 0 and extend:
                knots = torch.cat([knots_inner[0].repeat(k), knots_inner, knots_inner[-1].repeat(k)])
            else:
                knots = knots_inner.clone()
            p = max(k - 1, 0)
            K = knots.numel()
            n_bases = max(K - p - 1, 0)
            if n_bases == 0:
                results.append(torch.zeros((0, N), device=device, dtype=dtype))
                continue
            # Memoized recursive evaluation (vectorized in samples)
            memo = {}
            def Nfunc(i, d):
                key = (i, d)
                if key in memo:
                    return memo[key]
                if d == 0:
                    left = knots[i]
                    right = knots[i + 1]
                    val = (((u >= left) & (u < right)).to(dtype))
                    # include equality on right-most knot
                    if i + 1 == K - 1:
                        val = (((u >= left) & (u <= right)).to(dtype))
                    memo[key] = val.squeeze(0)
                    return memo[key]
                a_denom = knots[i + d] - knots[i]
                b_denom = knots[i + d + 1] - knots[i + 1]
                left_term = torch.zeros(N, device=device, dtype=dtype)
                right_term = torch.zeros(N, device=device, dtype=dtype)
                if a_denom != 0:
                    left_term = ((u - knots[i]) / a_denom).squeeze(0) * Nfunc(i, d - 1)
                if b_denom != 0:
                    right_term = ((knots[i + d + 1] - u) / b_denom).squeeze(0) * Nfunc(i + 1, d - 1)
                memo[key] = left_term + right_term
                return memo[key]
            basis = torch.zeros((n_bases, N), device=device, dtype=dtype)
            for i in range(n_bases):
                basis[i] = Nfunc(i, p)
            results.append(basis)
        max_b = max((b.shape[0] for b in results), default=0)
        out = torch.zeros((S, max_b, N), device=device, dtype=dtype)
        for s in range(S):
            nb = results[s].shape[0]
            if nb > 0:
                out[s, :nb, :] = results[s]
        return out
