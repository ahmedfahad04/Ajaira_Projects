
def norm_grid(v_grid):
    import torch
    def norm_grid(v_grid):
        """Permute then normalize using broadcasted scales."""
        v = v_grid.permute(0, 2, 3, 1).to(dtype=torch.float32)  # (B,H,W,2)
        B, H, W, C = v.shape
        assert C == 2
        # scale for x uses width, for y uses height
        denom_w = float(max(W - 1, 1))
        denom_h = float(max(H - 1, 1))
        scale = torch.tensor([2.0 / denom_w, 2.0 / denom_h], dtype=v.dtype, device=v.device).view(1, 1, 1, 2)
        normalized = v * scale - 1.0
        return normalized
