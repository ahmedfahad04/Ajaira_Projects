
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        from itertools import combinations
        n = len(preds)
        if n < 2:
            return 0.0
        concordant = 0
        total = 0
        for i, j in combinations(range(n), 2):
            dp = preds[i] - preds[j]
            if dp == 0:
                continue
            dr = references[i] - references[j]
            total += 1
            if (dp > 0 and dr > 0) or (dp < 0 and dr < 0):
                concordant += 1
        return concordant / total if total > 0 else 0.0
