
def crop_mask(masks, boxes):
    import torch
    def crop_mask(masks, boxes):
        """
        Flatten-based vectorized cropping. Compute flattened coordinates then reshape.
        """
        if masks.dim() != 3:
            raise ValueError("masks must be [n, h, w]")
        n, h, w = masks.shape
        if boxes.shape[0] != n or boxes.shape[1] != 4:
            raise ValueError("boxes must be [n, 4] and match masks batch size")
        device = masks.device
        bx = boxes.to(device=device, dtype=torch.float32)
        # create flattened coordinate arrays
        ys = torch.arange(h, device=device).unsqueeze(1).expand(h, w).reshape(-1)  # (h*w,)
        xs = torch.arange(w, device=device).unsqueeze(0).expand(h, w).reshape(-1)  # (h*w,)
        xs = xs.unsqueeze(0)  # (1, h*w)
        ys = ys.unsqueeze(0)  # (1, h*w)
        x1 = torch.floor(bx[:, 0]).unsqueeze(1)
        y1 = torch.floor(bx[:, 1]).unsqueeze(1)
        x2 = torch.ceil(bx[:, 2]).unsqueeze(1)
        y2 = torch.ceil(bx[:, 3]).unsqueeze(1)
        mask_flat = (xs >= x1) & (xs <= x2) & (ys >= y1) & (ys <= y2)  # (n, h*w)
        mask = mask_flat.view(n, h, w).to(masks.dtype)
        return masks * mask
