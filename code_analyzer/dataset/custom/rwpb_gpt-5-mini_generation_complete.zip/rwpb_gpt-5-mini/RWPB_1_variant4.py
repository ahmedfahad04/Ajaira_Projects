
def apply_colormap(:
    import torch
    import numpy as np
    from matplotlib import cm
    from torchtyping import TensorType
    def apply_colormap(
        image: TensorType["bs":..., 1],
        cmap="viridis",
    ) -> TensorType["bs":..., "rgb":3]:
        if not isinstance(image, torch.Tensor):
            image = torch.tensor(image)
        img = image.detach().to(torch.float32)
        device = img.device
        if img.shape[-1] != 1:
            raise ValueError("Expected last dimension to be channel=1")
        vals = img[..., 0]
        vmin = vals.min()
        vmax = vals.max()
        if (vmax - vmin).abs() < 1e-12:
            norm = torch.zeros_like(vals)
        else:
            norm = (vals - vmin) / (vmax - vmin)
            norm = torch.clamp(norm, 0.0, 1.0)
        # create torch palette (256) on same device
        cmap_obj = cm.get_cmap(cmap, 256)
        pal_np = (cmap_obj(np.linspace(0.0, 1.0, 256))[:, :3].astype(np.float32))
        palette = torch.from_numpy(pal_np).to(device=device)
        # fractional indices and linear interpolation in torch (keeps on GPU)
        idx_f = norm * 255.0
        idx0 = torch.floor(idx_f).long()
        idx1 = torch.clamp(idx0 + 1, 0, 255)
        w = (idx_f - idx0.float()).unsqueeze(-1)
        p0 = palette[idx0.view(-1)].view(list(idx0.shape) + [3])
        p1 = palette[idx1.view(-1)].view(list(idx1.shape) + [3])
        rgb = p0 * (1.0 - w) + p1 * w
        return rgb.to(dtype=torch.float32)
