
def rot6d_to_rotmat(x):
    import torch
    import numpy as np
    def rot6d_to_rotmat(x):
        if isinstance(x, np.ndarray):
            arr = x
            if arr.ndim != 2 or arr.shape[1] != 6:
                raise ValueError("Input must have shape (B,6)")
            x = torch.from_numpy(arr).float()
        elif isinstance(x, torch.Tensor):
            if x.dim() != 2 or x.size(1) != 6:
                raise ValueError("Input must have shape (B,6)")
            x = x.float()
        else:
            raise ValueError("Input must be a numpy array or torch tensor")
        a = x.view(-1, 6)
        v1 = a[:, :3]
        v2 = a[:, 3:6]
        # numpy-style gram-schmidt but in torch
        v1_norm = torch.sqrt((v1 * v1).sum(dim=1, keepdim=True)).clamp(min=1e-8)
        e1 = v1 / v1_norm
        proj = (e1 * v2).sum(dim=1, keepdim=True) * e1
        u2 = v2 - proj
        u2_norm = torch.sqrt((u2 * u2).sum(dim=1, keepdim=True)).clamp(min=1e-8)
        e2 = u2 / u2_norm
        e3 = torch.cross(e1, e2, dim=1)
        R = torch.cat([e1.unsqueeze(2), e2.unsqueeze(2), e3.unsqueeze(2)], dim=2)
        return R
