
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        # allow list-like inputs
        a = np.array(a, dtype=float)
        b = np.array(b, dtype=float)
        eps = 1e-9
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na < eps or nb < eps:
            return None, None
        ua = a / na
        ub = b / nb
        # if already (nearly) identical
        if np.allclose(ua, ub, atol=1e-9):
            return None, None
        # cross product
        axis = np.cross(ua, ub)
        axis_norm = np.linalg.norm(axis)
        dot = np.dot(ua, ub)
        dot = float(np.clip(dot, -1.0, 1.0))
        if axis_norm < eps:
            # anti-parallel case
            if dot < 0:
                # find axis perpendicular to ua
                # pick axis that minimizes numeric cancellation
                cand = np.array([1.0, 0.0, 0.0])
                if abs(np.dot(cand, ua)) > 0.9:
                    cand = np.array([0.0, 1.0, 0.0])
                axis = np.cross(ua, cand)
                axis = axis / np.linalg.norm(axis)
                return axis, np.pi
            else:
                return None, None
        axis = axis / axis_norm
        # angle via arccos (stable here because dot is clipped)
        angle = np.arccos(dot)
        return axis, angle
