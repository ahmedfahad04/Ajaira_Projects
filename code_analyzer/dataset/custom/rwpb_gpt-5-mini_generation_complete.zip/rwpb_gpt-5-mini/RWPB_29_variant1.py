
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        """
        Vectorized per-image IoU using torch operations.
        """
        if not torch.is_tensor(preds) or not torch.is_tensor(labels):
            preds = torch.tensor(preds)
            labels = torch.tensor(labels)
        # Normalize shapes: allow (N,1,H,W) or (N,H,W)
        if preds.ndim == 4 and preds.size(1) == 1:
            preds = preds.squeeze(1)
        if labels.ndim == 4 and labels.size(1) == 1:
            labels = labels.squeeze(1)
        if preds.shape != labels.shape:
            raise ValueError("preds and labels must have the same shape")
        # Convert to boolean foreground masks using threshold 0.5
        pred_mask = (preds > 0.5)
        label_mask = (labels > 0.5)
        # Apply ignore: remove those pixels from both pred and label by setting False
        if ignore is not None:
            ignore_mask = (labels == ignore)
            if ignore_mask.dtype != torch.bool:
                ignore_mask = ignore_mask.bool()
            pred_mask = pred_mask & (~ignore_mask)
            label_mask = label_mask & (~ignore_mask)
        # Flatten per image
        if pred_mask.ndim == 3:  # (N,H,W)
            N = pred_mask.size(0)
            pred_flat = pred_mask.view(N, -1).to(torch.uint8)
            label_flat = label_mask.view(N, -1).to(torch.uint8)
            intersection = (pred_flat & label_flat).sum(dim=1).float()
            union = (pred_flat | label_flat).sum(dim=1).float()
            # Handle per_image or batch
            if per_image:
                # For images with union==0 assign EMPTY
                ious = torch.where(union == 0, torch.tensor(float(EMPTY), device=union.device), (intersection / union))
                # Average across images
                mean_iou = ious.mean().item()
                return float(mean_iou * 100.0)
            else:
                total_inter = intersection.sum()
                total_union = union.sum()
                if total_union == 0:
                    return float(EMPTY * 100.0)
                return float((total_inter / total_union).item() * 100.0)
        else:
            # Single image (H,W)
            pred_flat = pred_mask.view(-1).to(torch.uint8)
            label_flat = label_mask.view(-1).to(torch.uint8)
            intersection = int((pred_flat & label_flat).sum().item())
            union = int((pred_flat | label_flat).sum().item())
            if union == 0:
                return float(EMPTY * 100.0)
            return float(intersection / union * 100.0)
