
def rotate_y(a, device=None):
    import torch
    def rotate_y(a, device=None):
        dev = torch.device(device) if device is not None else None
        if torch.is_tensor(a) and a.dim() > 0:
            angles = a.to(dev) if dev is not None else a
            c = torch.cos(angles)
            s = torch.sin(angles)
            n = angles.shape[0]
            dtype = angles.dtype
            if dev is None:
                M = torch.zeros((n,4,4), dtype=dtype)
            else:
                M = torch.zeros((n,4,4), dtype=dtype, device=dev)
            M[:,0,0] = c
            M[:,0,2] = s
            M[:,1,1] = 1.0
            M[:,2,0] = -s
            M[:,2,2] = c
            M[:,3,3] = 1.0
            return M
        else:
            ang = torch.as_tensor(a, device=dev, dtype=torch.get_default_dtype())
            c = torch.cos(ang)
            s = torch.sin(ang)
            if dev is None:
                M = torch.zeros((4,4), dtype=ang.dtype)
            else:
                M = torch.zeros((4,4), dtype=ang.dtype, device=dev)
            M[0,0] = c
            M[0,2] = s
            M[1,1] = 1.0
            M[2,0] = -s
            M[2,2] = c
            M[3,3] = 1.0
            return M
