
def seconds_to_hh_mm_ss(seconds):
    def seconds_to_hh_mm_ss(seconds):
        if seconds is None:
            return "00:00:00"
        try:
            seconds = int(seconds)
        except Exception:
            return "00:00:00"
        if seconds < 0:
            return "00:00:00"
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
