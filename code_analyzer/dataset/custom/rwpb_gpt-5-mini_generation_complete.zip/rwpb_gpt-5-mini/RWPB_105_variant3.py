
def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        """
        Brute-force Python loop per-point trilinear interpolation.
        Works for grid shape (1, C, H, W, D) and coordinates (x,y,z) in voxel indices.
        This is straightforward but not optimized.
        """
        if grid.ndim != 5:
            raise ValueError("Grid must be 5D: (1, C, H, W, D)")
        device = grid.device
        dtype = grid.dtype
        # Convert to (C, D, H, W)
        vol = grid.permute(1, 4, 2, 3).squeeze(0)  # (C, D, H, W)
        C_ch, D, H, W = vol.shape
        B, P, _ = coordinates.shape
        coords = coordinates.to(device=device, dtype=dtype)
        out = torch.zeros((B, P, C_ch), dtype=dtype, device=device)
        for b in range(B):
            for p in range(P):
                x = float(coords[b, p, 0].item())
                y = float(coords[b, p, 1].item())
                z = float(coords[b, p, 2].item())
                # clamp
                x = max(0.0, min(W - 1, x))
                y = max(0.0, min(H - 1, y))
                z = max(0.0, min(D - 1, z))
                x0 = int(torch.floor(torch.tensor(x)).item())
                y0 = int(torch.floor(torch.tensor(y)).item())
                z0 = int(torch.floor(torch.tensor(z)).item())
                x1 = min(x0 + 1, W - 1)
                y1 = min(y0 + 1, H - 1)
                z1 = min(z0 + 1, D - 1)
                xd = x - x0
                yd = y - y0
                zd = z - z0
                # gather 8 values and compute weights
                def val(ix, iy, iz):
                    return vol[:, iz, iy, ix]  # (C,)
                c000 = val(x0, y0, z0)
                c100 = val(x1, y0, z0)
                c010 = val(x0, y1, z0)
                c110 = val(x1, y1, z0)
                c001 = val(x0, y0, z1)
                c101 = val(x1, y0, z1)
                c011 = val(x0, y1, z1)
                c111 = val(x1, y1, z1)
                c00 = c000 * (1 - xd) + c100 * xd
                c01 = c001 * (1 - xd) + c101 * xd
                c10 = c010 * (1 - xd) + c110 * xd
                c11 = c011 * (1 - xd) + c111 * xd
                c0 = c00 * (1 - yd) + c10 * yd
                c1 = c01 * (1 - yd) + c11 * yd
                c = c0 * (1 - zd) + c1 * zd  # (C,)
                out[b, p, :] = c
        return out
