
def resample_segments(segments, n=1000):
    import numpy as np
    def resample_segments(segments, n=1000):
        result = []
        for seg in segments:
            seg = np.asarray(seg, dtype=float)
            if seg.size == 0:
                result.append(np.zeros((n, 2), dtype=float))
                continue
            if seg.ndim != 2 or seg.shape[1] != 2:
                raise ValueError("Each segment must be an array of shape (m, 2)")
            m = seg.shape[0]
            if m == 1:
                result.append(np.tile(seg[0], (n, 1)))
                continue
            dif = seg[1:] - seg[:-1]
            lens = np.hypot(dif[:, 0], dif[:, 1])
            cum = np.empty(m, dtype=float)
            cum[0] = 0.0
            cum[1:] = np.cumsum(lens)
            total = cum[-1]
            if total == 0.0:
                result.append(np.tile(seg[0], (n, 1)))
                continue
            targets = np.linspace(0.0, total, n)
            idx = np.searchsorted(cum, targets, side='right') - 1
            idx = np.clip(idx, 0, m - 2)
            left = seg[idx]
            right = seg[idx + 1]
            leftc = cum[idx]
            rightc = cum[idx + 1]
            denom = (rightc - leftc)
            denom[denom == 0] = 1.0
            alpha = (targets - leftc) / denom
            alpha = alpha.reshape(-1, 1)
            pts = left * (1.0 - alpha) + right * alpha
            result.append(pts)
        return result
