
def last_before(val, arr):
    def last_before(val, arr):
        # Iterative binary search on sorted array
        n = len(arr)
        left, right = 0, n - 1
        res = -1
        while left <= right:
            mid = (left + right) // 2
            if arr[mid] <= val:
                res = mid
                left = mid + 1
            else:
                right = mid - 1
        return res
