
def movmean(arr, n_avg):
    import numpy as np
    from numpy.lib.stride_tricks import as_strided
    def movmean(arr, n_avg):
        a = np.asarray(arr, dtype=float).ravel()
        if n_avg <= 0:
            return np.array([], dtype=float)
        N = a.size
        if n_avg > N:
            return np.array([], dtype=float)
        # create a view of sliding windows using strides
        itemsize = a.strides[0]
        shape = (N - n_avg + 1, n_avg)
        strides = (itemsize, itemsize)
        windows = as_strided(a, shape=shape, strides=strides)
        # compute mean along axis 1
        return windows.mean(axis=1)
