
def format_ratio(ratio):
    def format_ratio(ratio):
        import math
        try:
            r = float(ratio)
        except Exception:
            r = 0.0
        # truncate toward zero by using math.trunc on scaled value
        truncated = math.trunc(r * 1000) / 1000.0
        return "percentage:{:.3f}".format(truncated)
