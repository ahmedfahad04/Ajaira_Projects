
def check_all_columns_numeric(df):
    import pandas as pd
    def check_all_columns_numeric(df):
        """
        Try to coerce each non-null entry to numeric. If any non-null value
        cannot be converted to numeric, the column is non-numeric.
        """
        if df is None:
            return False
        if df.shape[1] == 0:
            return True
        for col in df.columns:
            s = df[col]
            nonnull_mask = s.notna()
            if nonnull_mask.any():
                coerced = pd.to_numeric(s, errors='coerce')
                # If any originally-non-null value becomes NaN after coercion, it's non-numeric
                if coerced[nonnull_mask].isna().any():
                    return False
        return True
