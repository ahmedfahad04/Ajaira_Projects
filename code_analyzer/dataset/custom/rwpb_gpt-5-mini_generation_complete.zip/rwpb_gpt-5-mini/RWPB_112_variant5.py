
def submatrix(matrix, col):
    def submatrix(matrix, col):
        # create shallow copies of rows and delete the requested column
        new = [list(row) for row in matrix]
        for row in new:
            try:
                del row[col]
            except Exception:
                raise IndexError("column index out of range")
        return new
