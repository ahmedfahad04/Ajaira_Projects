
def round(number, num_decimal_places, leave_int=False):
    from fractions import Fraction
    def round(number, num_decimal_places, leave_int=False):
        # Exact rational rounding using Fraction, implement HALF_UP
        # Coerce to Fraction for exact arithmetic
        if isinstance(number, Fraction):
            frac = number
        elif isinstance(number, int):
            frac = Fraction(number, 1)
        else:
            # For floats, convert via str to reduce binary artifacts
            frac = Fraction(str(number))
        n = int(num_decimal_places)
        if n >= 0:
            scale = 10 ** n
            scaled = frac * scale
            # split into integer and remainder
            whole = scaled.numerator // scaled.denominator
            rem = scaled.numerator % scaled.denominator
            # Decide rounding by comparing 2*rem and denom
            if 2 * rem >= scaled.denominator:
                # tie and greater -> round up (half up)
                if scaled >= 0:
                    whole += 1
                else:
                    whole -= 1
            result_frac = Fraction(whole, 1) / scale
        else:
            scale = 10 ** (-n)
            scaled = frac / scale
            whole = scaled.numerator // scaled.denominator
            rem = scaled.numerator % scaled.denominator
            if 2 * rem >= scaled.denominator:
                if scaled >= 0:
                    whole += 1
                else:
                    whole -= 1
            result_frac = Fraction(whole, 1) * scale
        # Convert to int or float as requested
        if leave_int and result_frac.denominator == 1:
            return result_frac.numerator
        return float(result_frac)
