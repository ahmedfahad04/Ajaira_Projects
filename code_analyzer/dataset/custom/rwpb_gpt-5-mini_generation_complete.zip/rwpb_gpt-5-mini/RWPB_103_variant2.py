
def unsafeAdd(x, y):
    MAX_VAL = (1 << 256) - 1
    MOD = 1 << 256
    def unsafeAdd(x, y):
        return (x + y) % MOD
