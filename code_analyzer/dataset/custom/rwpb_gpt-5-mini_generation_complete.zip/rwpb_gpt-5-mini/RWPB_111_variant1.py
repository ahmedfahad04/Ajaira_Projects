
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        x = torch.arange(W, dtype=torch.float32)
        y = torch.arange(H, dtype=torch.float32)
        gy, gx = torch.meshgrid(y, x, indexing='ij')
        grid = torch.stack((gx, gy), dim=0)  # (2, H, W)
        return grid.unsqueeze(0).expand(B, -1, -1, -1).contiguous()
