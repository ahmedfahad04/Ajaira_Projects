
def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        """
        Uses torch.nn.functional.grid_sample to trilinearly sample points.
        Assumes input grid shape (1, C, H, W, D) (as specified) and coordinates in voxel index order (x, y, z),
        where x in [0, W-1], y in [0, H-1], z in [0, D-1].
        """
        if not isinstance(grid, torch.Tensor) or not isinstance(coordinates, torch.Tensor):
            raise TypeError("Inputs must be torch.Tensors")
        # Ensure dims
        if grid.ndim != 5:
            raise ValueError("Grid must be 5D: (1, C, H, W, D)")
        N_grid, C = grid.shape[0], grid.shape[1]
        if N_grid != 1:
            # accept N>1 but we'll sample from each batch using the first volume (or broadcast)
            pass
        # Permute (1, C, H, W, D) -> (1, C, D, H, W) to match grid_sample expected input (N,C,D,H,W)
        grid_perm = grid.permute(0, 1, 4, 2, 3).contiguous()  # now (1, C, D, H, W)
        _, _, D, H, W = grid_perm.shape  # D-depth, H-height, W-width
        B, P, three = coordinates.shape
        if three != 3:
            raise ValueError("Coordinates last dimension must be 3")
        # Coordinates expected in (x, y, z) index order -> normalize to [-1,1] per axis where x->W, y->H, z->D
        coords = coordinates.to(dtype=grid.dtype, device=grid.device)
        # Avoid division by zero when dimension size is 1
        def norm(coord, size):
            if size == 1:
                return torch.zeros_like(coord)
            return 2.0 * coord / (size - 1) - 1.0
        x = norm(coords[..., 0], W)
        y = norm(coords[..., 1], H)
        z = norm(coords[..., 2], D)
        # Build grid for grid_sample in shape (B, D_out, H_out, W_out, 3) -> we set D_out = P, H_out = 1, W_out = 1
        sample_grid = torch.stack((x, y, z), dim=-1).view(B, P, 1, 1, 3)
        # Expand volume to batch size so grid_sample accepts matching N
        if grid_perm.shape[0] == 1 and B > 1:
            grid_batch = grid_perm.expand(B, -1, -1, -1, -1).contiguous()
        else:
            grid_batch = grid_perm
        # grid_sample expects grid coords ordering (x, y, z) and input shape (N, C, D, H, W)
        sampled = F.grid_sample(grid_batch, sample_grid, mode='bilinear', padding_mode='zeros', align_corners=True)
        # sampled shape: (B, C, P, 1, 1) -> squeeze and permute to (B, P, C)
        sampled = sampled.view(B, C, P).permute(0, 2, 1).contiguous()
        return sampled
