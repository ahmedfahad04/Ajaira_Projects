
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return original_size
        ow, oh = original_size
        orig_area = ow * oh if ow is not None and oh is not None else 0
        orig_ratio = ow / oh if oh != 0 else float('inf')
        best = None
        best_score = None
        for w, h in possible_resolutions:
            area = w * h
            area_norm = abs(area - orig_area) / orig_area if orig_area != 0 else abs(area - orig_area)
            ratio = w / h if h != 0 else float('inf')
            ratio_diff = abs(ratio - orig_ratio)
            # weighted combination: prioritize aspect ratio somewhat and area closeness
            score = 0.5 * area_norm + 0.5 * ratio_diff
            if best is None or score < best_score:
                best = (w, h)
                best_score = score
        return best
