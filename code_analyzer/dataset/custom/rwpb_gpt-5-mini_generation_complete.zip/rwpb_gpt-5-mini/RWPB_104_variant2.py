
def mulMod(x, y, z):
    MAX_VAL = (1 << 256) - 1
    def mulMod(x, y, z):
        if z == 0:
            raise ValueError("modulus must be non-zero")
        x %= z
        y %= z
        if x == 0 or y == 0:
            return 0
        # try safe direct multiplication if it won't overflow a 256-bit word
        try_safe = False
        if 0 <= x <= MAX_VAL and 0 <= y <= MAX_VAL:
            if y == 0 or x <= MAX_VAL // y:
                try_safe = True
        if try_safe:
            return (x * y) % z
        # fallback to binary doubling
        res = 0
        while y:
            if y & 1:
                res = (res + x) % z
            x = (x << 1) % z
            y >>= 1
        return res
