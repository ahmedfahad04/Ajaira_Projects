
def bbox_ioa(box1, box2, iou=False, eps=1e-7):
    import numpy as np
    def bbox_ioa(box1, box2, iou=False, eps=1e-7):
        b1 = np.asarray(box1, dtype=float)
        b2 = np.asarray(box2, dtype=float)
        if b1.ndim == 1:
            b1 = b1.reshape(1, 4)
        if b2.ndim == 1:
            b2 = b2.reshape(1, 4)
        n = b1.shape[0]
        m = b2.shape[0]
        out = np.zeros((n, m), dtype=float)
        area2 = np.clip(b2[:, 2] - b2[:, 0], 0, None) * np.clip(b2[:, 3] - b2[:, 1], 0, None)
        for i in range(n):
            x1 = np.maximum(b1[i, 0], b2[:, 0])
            y1 = np.maximum(b1[i, 1], b2[:, 1])
            x2 = np.minimum(b1[i, 2], b2[:, 2])
            y2 = np.minimum(b1[i, 3], b2[:, 3])
            w = np.clip(x2 - x1, 0, None)
            h = np.clip(y2 - y1, 0, None)
            inter = w * h
            if iou:
                a1 = max(0.0, b1[i, 2] - b1[i, 0]) * max(0.0, b1[i, 3] - b1[i, 1])
                union = a1 + area2 - inter
                out[i, :] = inter / (union + eps)
            else:
                out[i, :] = inter / (area2 + eps)
        return out
