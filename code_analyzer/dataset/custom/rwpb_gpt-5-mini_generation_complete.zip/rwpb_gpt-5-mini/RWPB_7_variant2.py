
def dynamic_import_function(function_path):
    def dynamic_import_function(function_path):
        from importlib import import_module
        if not isinstance(function_path, str):
            return ModuleNotFoundError("function_path must be a string")
        parts = function_path.split('.')
        if len(parts) < 2:
            return ModuleNotFoundError(f"No module part in '{function_path}'")
        for i in range(len(parts) - 1, 0, -1):
            module_name = '.'.join(parts[:i])
            attr_parts = parts[i:]
            try:
                module = import_module(module_name)
            except Exception:
                continue
            obj = module
            ok = True
            for a in attr_parts:
                try:
                    obj = getattr(obj, a)
                except Exception:
                    ok = False
                    break
            if ok:
                return obj
        return ModuleNotFoundError(f"Could not resolve function from '{function_path}'")
