
def pr_from_grav(grav):
    import numpy as np
    import math
    def pr_from_grav(grav):
        arr = np.asarray(grav, dtype=float)
        if arr.ndim == 1:
            if arr.size != 3:
                raise ValueError("grav must be shape (n,3) or (3,)")
            arr = arr.reshape(1, 3)
        if arr.ndim != 2 or arr.shape[1] != 3:
            raise ValueError("grav must have shape (n,3)")
        pitches = []
        rolls = []
        for gx, gy, gz in arr:
            denom = math.hypot(gy, gz)  # sqrt(gy^2 + gz^2)
            # pitch: atan2(-gx, denom)
            pitch = math.atan2(-gx, denom)
            # roll: atan2(gy, gz)
            roll = math.atan2(gy, gz)
            pitches.append(pitch)
            rolls.append(roll)
        return np.array(pitches), np.array(rolls)
