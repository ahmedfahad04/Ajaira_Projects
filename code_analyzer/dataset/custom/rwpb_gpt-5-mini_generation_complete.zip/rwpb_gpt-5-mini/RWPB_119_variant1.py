
def rotate_about_x_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        """
        Rotate a 3D vector about the x-axis by angle theta (radians).
        Simple direct formula implementation.
        """
        v = np.asarray(vector, dtype=float).ravel()
        if v.size < 3:
            raise ValueError("Input vector must have at least 3 components")
        x, y, z = float(v[0]), float(v[1]), float(v[2])
        c = math.cos(theta)
        s = math.sin(theta)
        y_new = y * c - z * s
        z_new = y * s + z * c
        return np.array([x, y_new, z_new], dtype=float)
