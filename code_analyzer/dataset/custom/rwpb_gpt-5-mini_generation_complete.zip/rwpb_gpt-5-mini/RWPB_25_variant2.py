
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        arr = np.asarray(img)
        if arr.ndim != 2:
            raise ValueError("Input must be grayscale")
        img_u8 = (arr.copy()).astype(np.uint8)
        # Binary foreground (treat any non-zero as foreground)
        _, bin_img = cv2.threshold(img_u8, 0, 255, cv2.THRESH_BINARY)
        # Use morphological closing with a kernel sized proportional to image
        h, w = bin_img.shape
        ksize = max(3, (min(h, w) // 50) | 1)  # odd and at least 3
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ksize, ksize))
        closed = cv2.morphologyEx(bin_img, cv2.MORPH_CLOSE, kernel, iterations=2)
        # Ensure we only add pixels (don't remove original foreground)
        filled = cv2.bitwise_or(bin_img, closed)
        return filled.astype(np.uint8)
