
def isprime(n):
    def isprime(n):
        if not isinstance(n, int):
            return False
        if n < 2:
            return False
        small_primes = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29)
        for p in small_primes:
            if n == p:
                return True
            if n % p == 0:
                return False
        # Deterministic Miller-Rabin for 64-bit integers
        d = n - 1
        s = 0
        while d % 2 == 0:
            d //= 2
            s += 1
        def check(a, s, d, n):
            x = pow(a, d, n)
            if x == 1 or x == n - 1:
                return True
            for _ in range(s - 1):
                x = (x * x) % n
                if x == n - 1:
                    return True
            return False
        # Bases sufficient for testing 64-bit integers
        bases = (2, 325, 9375, 28178, 450775, 9780504, 1795265022)
        for a in bases:
            if a % n == 0:
                return True
            if not check(a, s, d, n):
                return False
        return True
