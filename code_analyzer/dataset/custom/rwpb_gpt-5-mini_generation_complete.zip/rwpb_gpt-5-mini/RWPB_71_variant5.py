
def getLambertCoefs(numOfLambertCoefs):
    from fractions import Fraction
    from math import factorial
    def getLambertCoefs(numOfLambertCoefs):
        if not isinstance(numOfLambertCoefs, int) or numOfLambertCoefs <= 0:
            return []
        fracs = []
        for n in range(1, numOfLambertCoefs + 1):
            numer = (-n) ** (n - 1)
            den = factorial(n)
            fracs.append(Fraction(numer, den))
        return fracs
