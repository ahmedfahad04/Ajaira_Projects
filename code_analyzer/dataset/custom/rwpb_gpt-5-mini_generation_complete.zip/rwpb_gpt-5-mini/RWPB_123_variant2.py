
def fuse_deconv_and_bn(deconv, bn):
    import torch
    import torch.nn as nn
    def fuse_deconv_and_bn(deconv, bn):
        if not isinstance(deconv, nn.ConvTranspose2d) or not isinstance(bn, nn.BatchNorm2d):
            raise ValueError("Expected ConvTranspose2d and BatchNorm2d")
        if bn.num_features != deconv.out_channels:
            raise ValueError("BatchNorm num_features must match deconv out_channels")
        W = deconv.weight.detach().clone()
        device = W.device
        dtype = W.dtype
        running_mean = bn.running_mean.to(device=device, dtype=dtype)
        running_var = bn.running_var.to(device=device, dtype=dtype)
        gamma = bn.weight.to(device=device, dtype=dtype) if bn.weight is not None else torch.ones_like(running_mean)
        beta = bn.bias.to(device=device, dtype=dtype) if bn.bias is not None else torch.zeros_like(running_mean)
        eps = bn.eps
        scale = (gamma / torch.sqrt(running_var + eps)).contiguous()  # shape [out_channels]
        out_channels = deconv.out_channels
        groups = deconv.groups
        in_channels = deconv.in_channels
        # Create output weight buffer
        W_fused = torch.empty_like(W)
        out_per_group = out_channels // groups
        in_per_group = in_channels // groups
        # Explicitly loop over output channels and apply scale to the corresponding slices
        for oc in range(out_channels):
            g = oc // out_per_group
            idx = oc % out_per_group
            start = g * in_per_group
            end = (g + 1) * in_per_group
            W_fused[start:end, idx, :, :] = W[start:end, idx, :, :] * scale[oc]
        # Compute fused bias
        b_conv = deconv.bias.detach().clone() if deconv.bias is not None else torch.zeros(out_channels, device=device, dtype=dtype)
        b_fused = (b_conv - running_mean) * scale + beta
        fused = nn.ConvTranspose2d(
            in_channels=deconv.in_channels,
            out_channels=deconv.out_channels,
            kernel_size=deconv.kernel_size,
            stride=deconv.stride,
            padding=deconv.padding,
            output_padding=deconv.output_padding,
            groups=deconv.groups,
            bias=True,
            dilation=deconv.dilation,
            padding_mode=deconv.padding_mode
        )
        fused.weight.data.copy_(W_fused)
        fused.bias.data.copy_(b_fused)
        return fused
