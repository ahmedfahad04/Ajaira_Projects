
def inverse_sigmoid(x):
    import torch
    def inverse_sigmoid(x):
        x = torch.as_tensor(x)
        if not x.is_floating_point():
            x = x.float()
        eps = 1e-6
        x = x.clamp(min=eps, max=1 - eps)
        return torch.log(x / (1 - x))
