
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        a = np.array(a, dtype=float).ravel()
        b = np.array(b, dtype=float)
        if a.size == 0:
            raise ValueError("a is empty")
        if b.ndim == 1:
            if b.size != a.size:
                return KeyError("length mismatch")
            # manual computation
            dot = 0.0
            for i in range(a.size):
                dot += a[i] * b[i]
            na = np.sqrt((a * a).sum())
            nb = np.sqrt((b * b).sum())
            if na == 0 or nb == 0:
                return float('nan')
            cos = dot / (na * nb)
            cos = min(1.0, max(-1.0, cos))
            return 1.0 - float(cos)
        elif b.ndim == 2:
            if b.shape[1] != a.size:
                return KeyError("length mismatch")
            results = []
            na = np.sqrt((a * a).sum())
            for row in b:
                dot = 0.0
                for i in range(a.size):
                    dot += a[i] * row[i]
                nb = np.sqrt((row * row).sum())
                if na == 0 or nb == 0:
                    results.append(float('nan'))
                else:
                    cos = dot / (na * nb)
                    cos = min(1.0, max(-1.0, cos))
                    results.append(1.0 - cos)
            return np.array(results)
        else:
            return KeyError("b must be vector or matrix")
