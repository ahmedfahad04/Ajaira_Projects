
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        if repetition_penalty == 1.0 or repetition_penalty == 0:
            return logits
        logits = logits.clone()
        batch_size, vocab_size = logits.shape
        device = logits.device
        dtype = logits.dtype
        # Use torch.isin for each batch row to build presence mask
        for b in range(batch_size):
            prev = prev_output_tokens[b]
            # filter negative tokens
            valid_prev = prev[prev >= 0]
            if valid_prev.numel() == 0:
                continue
            # create boolean mask of vocabulary tokens present in prev
            vocab_idx = torch.arange(vocab_size, device=device)
            present = torch.isin(vocab_idx, valid_prev.to(device))
            # apply penalty only where present
            row = logits[b]
            pos_mask = row > 0
            # for present & positive: divide; for present & negative: multiply
            row = torch.where(present & pos_mask, row / repetition_penalty, row)
            row = torch.where(present & (~pos_mask), row * repetition_penalty, row)
            logits[b] = row
        return logits
