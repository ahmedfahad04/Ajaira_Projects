
def filter_nan(ts, vs):
    import numpy as np
    def filter_nan(ts, vs):
        ts = np.asarray(ts)
        vs = np.asarray(vs)
        if ts.shape[0] != vs.shape[0]:
            raise ValueError("ts and vs must have the same length along axis 0")
        # support multivariate vs: drop rows where any element is NaN
        if vs.ndim == 1:
            mask = ~np.isnan(vs) & ~np.isnan(ts)
        else:
            mask = ~np.isnan(ts) & ~np.any(np.isnan(vs), axis=1)
        return ts[mask], vs[mask]
