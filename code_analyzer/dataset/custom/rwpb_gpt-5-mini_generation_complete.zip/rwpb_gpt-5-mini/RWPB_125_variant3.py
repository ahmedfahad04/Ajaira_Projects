
def resample_segments(segments, n=1000):
    import numpy as np
    def resample_segments(segments, n=1000):
        out = []
        for seg in segments:
            seg = np.asarray(seg, dtype=float)
            if seg.ndim != 2 or seg.shape[1] != 2:
                raise ValueError("Each segment must be an array of shape (m, 2)")
            if seg.shape[0] == 0:
                out.append(np.zeros((n, 2), dtype=float))
                continue
            # remove consecutive identical points
            dif = np.vstack(([True], np.any(np.diff(seg, axis=0) != 0, axis=1)))
            uniq = seg[dif]
            if uniq.shape[0] == 1:
                out.append(np.tile(uniq[0], (n, 1)))
                continue
            deltas = np.diff(uniq, axis=0)
            dists = np.sqrt((deltas**2).sum(axis=1))
            cum = np.concatenate(([0.0], np.cumsum(dists)))
            total = cum[-1]
            if total == 0.0:
                out.append(np.tile(uniq[0], (n, 1)))
                continue
            t_new = np.linspace(0.0, total, n)
            x = np.interp(t_new, cum, uniq[:, 0])
            y = np.interp(t_new, cum, uniq[:, 1])
            out.append(np.column_stack((x, y)))
        return out
