
def pad_camera_extrinsics_4x4(extrinsics):
    import torch
    def pad_camera_extrinsics_4x4(extrinsics):
        if not isinstance(extrinsics, torch.Tensor):
            raise TypeError("extrinsics must be a torch.Tensor")
        if extrinsics.dim() < 2:
            raise ValueError("extrinsics must have at least 2 dimensions")
        if extrinsics.shape[-2:] == (4, 4):
            return extrinsics
        if extrinsics.shape[-2:] != (3, 4):
            raise ValueError("extrinsics must have shape (..., 3, 4) or (..., 4, 4)")
        dtype = extrinsics.dtype
        device = extrinsics.device
        batch_shape = extrinsics.shape[:-2]
        last_row = torch.tensor([0, 0, 0, 1], dtype=dtype, device=device)
        new_row = last_row.view(*(1,)*len(batch_shape), 1, 4).expand(*batch_shape, 1, 4)
        return torch.cat((extrinsics, new_row), dim=-2)
