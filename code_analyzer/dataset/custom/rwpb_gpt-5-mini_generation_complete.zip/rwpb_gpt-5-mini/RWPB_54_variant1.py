
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        x, y, x1, y1 = box
        # ensure floats
        x, y, x1, y1 = float(x), float(y), float(x1), float(y1)
        # compute center and size
        cx = (x + x1) / 2.0
        cy = (y + y1) / 2.0
        w = abs(x1 - x)
        h = abs(y1 - y)
        # expand sizes
        new_w = w * float(expand)
        new_h = h * float(expand)
        # build new box keeping center
        new_x = cx - new_w / 2.0
        new_y = cy - new_h / 2.0
        new_x1 = cx + new_w / 2.0
        new_y1 = cy + new_h / 2.0
        # s as half of the (square) side chosen as max dimension
        s = max(new_w, new_h) / 2.0
        return [new_x, new_y, new_x1, new_y1], s
