
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        if tensor1.shape[0] != tensor2.shape[0]:
            raise ValueError("First dimension sizes must match")
        pairs1 = [torch.cat((tensor1[i:i+1], tensor2[i:i+1]), dim=0) for i in range(tensor1.shape[0])]
        pairs2 = [torch.cat((tensor2[i:i+1], tensor1[i:i+1]), dim=0) for i in range(tensor1.shape[0])]
        out1 = torch.cat(pairs1, dim=0) if pairs1 else tensor1.new_empty((0,) + tensor1.shape[1:])
        out2 = torch.cat(pairs2, dim=0) if pairs2 else tensor1.new_empty((0,) + tensor1.shape[1:])
        return out1, out2
