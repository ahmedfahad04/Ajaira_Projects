
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return original_size
        ow, oh = original_size
        best = None
        best_score = None
        for w, h in possible_resolutions:
            # scaling factor required (target / original). We want to minimize the maximum scale (prefer <=1).
            sx = w / ow if ow != 0 else float('inf')
            sy = h / oh if oh != 0 else float('inf')
            max_scale = max(sx, sy)
            area_diff = abs((w * h) - (ow * oh))
            # primary: minimize max_scale; secondary: minimize area_diff
            score = (max_scale, area_diff)
            if best is None or score < best_score:
                best = (w, h)
                best_score = score
        return best
