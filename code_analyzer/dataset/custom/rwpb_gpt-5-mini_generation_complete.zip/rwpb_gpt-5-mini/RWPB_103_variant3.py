
def unsafeAdd(x, y):
    MAX_VAL = (1 << 256) - 1
    MOD = 1 << 256
    def unsafeAdd(x, y):
        s = x + y
        _, r = divmod(s, MOD)
        return r
