
def extract_imports_from_lines(lines: List[str]) -> str:
    from typing import List
    def extract_imports_from_lines(lines: List[str]) -> str:
        """
        Simple line-based extractor: selects lines that start with 'import' or 'from'
        after leading whitespace, ignoring pure-comment lines.
        """
        extracted = []
        for line in lines:
            if not line:
                continue
            stripped = line.lstrip()
            if not stripped:
                continue
            if stripped.startswith('#'):
                continue
            if stripped.startswith('import ') or stripped.startswith('from '):
                extracted.append(line.rstrip())
        return '\n'.join(extracted)
