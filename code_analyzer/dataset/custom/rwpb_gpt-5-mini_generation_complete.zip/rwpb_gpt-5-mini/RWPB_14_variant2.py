
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        if a.size != 3 or b.size != 3:
            a = a.ravel()[:3]
            b = b.ravel()[:3]
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na == 0 or nb == 0:
            return (None, None)
        u = a / na
        v = b / nb
        if np.allclose(u, v, atol=1e-12):
            return (None, None)
        cross = np.cross(u, v)
        norm_cross = np.linalg.norm(cross)
        dot = np.dot(u, v)
        # angle more stable via atan2
        angle = np.arctan2(norm_cross, np.clip(dot, -1.0, 1.0))
        if norm_cross < 1e-12:
            # parallel or antiparallel
            if dot > 0:
                return (None, None)
            else:
                # antiparallel: choose deterministic orthogonal axis
                min_idx = int(np.argmin(np.abs(u)))
                basis = np.zeros(3)
                basis[min_idx] = 1.0
                axis = np.cross(u, basis)
                axis = axis / np.linalg.norm(axis)
                return (axis, np.pi)
        axis = cross / norm_cross
        return (axis, angle)
