
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    import itertools
    def generate_grids(lower_limit, upper_limit, grid_size):
        lower = torch.as_tensor(lower_limit)
        upper = torch.as_tensor(upper_limit)
        gs = torch.as_tensor(grid_size)
        lower = lower.flatten().to(dtype=torch.float64, device=lower.device)
        upper = upper.flatten().to(dtype=torch.float64, device=lower.device)
        gs = gs.flatten()
        D = lower.numel()
        if gs.numel() == 1 and D > 1:
            gs = gs.expand(D)
        gs = gs.to(dtype=torch.long)
        edge_lists_low = []
        edge_lists_high = []
        for i in range(D):
            n = int(gs[i].item())
            if n < 1:
                raise ValueError("grid_size must be >= 1")
            edges = torch.linspace(lower[i], upper[i], steps=n + 1, device=lower.device, dtype=lower.dtype)
            edge_lists_low.append(edges[:-1].cpu().tolist())
            edge_lists_high.append(edges[1:].cpu().tolist())
        # use itertools.product to enumerate all cells
        if D == 0:
            return torch.empty((0, 0), dtype=lower.dtype), torch.empty((0, 0), dtype=lower.dtype)
        low_rows = []
        high_rows = []
        for low_combo, high_combo in zip(itertools.product(*edge_lists_low), itertools.product(*edge_lists_high)):
            low_rows.append(list(low_combo))
            high_rows.append(list(high_combo))
        low_tensor = torch.tensor(low_rows, dtype=lower.dtype, device=lower.device) if low_rows else torch.empty((0, D), dtype=lower.dtype, device=lower.device)
        high_tensor = torch.tensor(high_rows, dtype=lower.dtype, device=lower.device) if high_rows else torch.empty((0, D), dtype=lower.dtype, device=lower.device)
        return low_tensor, high_tensor
