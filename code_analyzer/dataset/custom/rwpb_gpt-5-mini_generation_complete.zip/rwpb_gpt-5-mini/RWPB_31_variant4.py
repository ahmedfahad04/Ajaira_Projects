
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        n = tensor.shape[0]
        if n == batch_size:
            return tensor
        device = tensor.device
        dtype = tensor.dtype
        # Ensure every original element is represented when increasing
        if n == 0:
            raise ValueError("tensor has zero batch dimension")
        if n == 1:
            # repeat single element
            out = tensor.expand(batch_size, *tensor.shape[1:]).clone()
            return out
        if batch_size > n:
            # Start with each original included once, distribute the extra slots across the n-1 intervals
            extras = batch_size - n
            segments = n - 1
            # compute allocation per segment proportional to segment index fairness (evenly)
            alloc = []
            for i in range(segments):
                # allocate using floor of proportional distribution
                a = (extras * (i + 1)) // segments - (extras * i) // segments
                alloc.append(int(a))
            parts = []
            for i in range(segments):
                parts.append(tensor[i].unsqueeze(0))
                k = alloc[i]
                if k > 0:
                    # generate k interpolated elements between i and i+1
                    a = tensor[i].to(dtype)
                    b = tensor[i + 1].to(dtype)
                    for j in range(k):
                        t = float(j + 1) / (k + 1)
                        parts.append((1 - t) * a + t * b)
            parts.append(tensor[-1].unsqueeze(0))
            out = torch.cat([p.unsqueeze(0) if p.dim() == tensor.dim() else p for p in parts], dim=0)
            # if rounding made length off by one, trim or pad by repeating last
            cur = out.shape[0]
            if cur > batch_size:
                out = out[:batch_size]
            elif cur < batch_size:
                pad_count = batch_size - cur
                pad = out[-1].unsqueeze(0).expand(pad_count, *out.shape[1:]).clone()
                out = torch.cat([out, pad], dim=0)
            return out.to(dtype).to(device)
        else:
            # batch_size < n -> pick indices evenly but prefer to cover ends
            positions = torch.linspace(0, n - 1, steps=batch_size, device=device)
            floor_idx = positions.floor().long().clamp(min=0, max=n - 1)
            ceil_idx = positions.ceil().long().clamp(min=0, max=n - 1)
            weights = (positions - floor_idx.to(device)).to(dtype)
            front = tensor[floor_idx].to(dtype)
            back = tensor[ceil_idx].to(dtype)
            shape = [batch_size] + [1] * (tensor.dim() - 1)
            w = weights.view(*shape)
            out = front * (1 - w) + back * w
            return out.to(dtype).to(device)
