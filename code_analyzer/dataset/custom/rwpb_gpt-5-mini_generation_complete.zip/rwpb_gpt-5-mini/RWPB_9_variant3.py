
def is_byte_token(s: str) -> bool:
    def is_byte_token(s: str) -> bool:
        if not isinstance(s, str):
            return False
        if len(s) != 6:
            return False
        if s[0] != '<' or s[-1] != '>':
            return False
        body = s[1:-1]
        if not (body.startswith('0x') or body.startswith('0X')):
            return False
        hexpart = body[2:]
        if len(hexpart) != 2:
            return False
        try:
            val = int(hexpart, 16)
        except ValueError:
            return False
        return 0 <= val <= 0xFF
