
def check(x, checksum_token):
    import re
    import hashlib
    def check(x, checksum_token):
        m = re.search(r'\b[0-9a-fA-F]{64}\b', x)
        if not m:
            return False
        orig = m.group(0)
        new_s = x[:m.start()] + checksum_token + x[m.end():]
        h = hashlib.sha256(new_s.encode('utf-8')).hexdigest()
        return h.lower() == orig.lower()
