
def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
    import numpy as np
    def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
        tokens = np.asarray(tokens)
        target = max(0, int(context_window) + 1)
        if tokens.ndim == 0:
            tokens = tokens.reshape(1)
        seq_len = tokens.shape[-1]
        if seq_len >= target:
            res = tokens[..., :target]
            return res if tokens.ndim > 1 else res.reshape((target,))
        extra = target - seq_len
        pad_width = [(0, 0)] * tokens.ndim
        pad_width[-1] = (0, extra)
        res = np.pad(tokens, pad_width, mode='constant', constant_values=pad_token)
        return res if tokens.ndim > 1 else res.reshape((target,))
