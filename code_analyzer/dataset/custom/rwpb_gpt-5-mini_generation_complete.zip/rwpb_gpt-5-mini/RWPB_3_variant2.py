
def get_focalLength_from_fieldOfView(fov=60, img_size=512):
    import numpy as np
    def get_focalLength_from_fieldOfView(fov=60, img_size=512):
        """
        Vectorized: supports scalar or (w,h) img_size. Returns focal (scalar) or tuple.
        """
        rad = np.deg2rad(np.asarray(fov, dtype=float))
        if hasattr(img_size, "__iter__") and not isinstance(img_size, (str, bytes)):
            sizes = np.asarray(img_size, dtype=float)
            return tuple((sizes / 2.0) / np.tan(rad / 2.0))
        else:
            img = float(img_size)
            return (img / 2.0) / np.tan(rad / 2.0)
