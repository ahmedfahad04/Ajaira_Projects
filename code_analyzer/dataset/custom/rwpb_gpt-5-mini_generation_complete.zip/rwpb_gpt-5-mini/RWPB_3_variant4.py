
def get_focalLength_from_fieldOfView(fov=60, img_size=512):
    import numpy as np
    def get_focalLength_from_fieldOfView(fov=60, img_size=512):
        """
        Solve for focal length using Newton-Raphson on equation:
        2*atan((img_size/2)/f) = fov (radians)
        """
        fov = float(fov)
        if fov == 0:
            return np.inf
        rad = np.deg2rad(fov)
        a = float(img_size) / 2.0
        # initial guess: approximate analytic solution
        f = max(1.0, a / np.tan(rad / 2.0))
        for _ in range(100):
            g = 2.0 * np.arctan(a / f) - rad
            if abs(g) < 1e-12:
                break
            dg = 2.0 * (-a) / (f * f + a * a)
            if dg == 0:
                break
            f_new = f - g / dg
            if f_new <= 0:
                f_new = f * 0.5
            if abs(f_new - f) < 1e-12:
                f = f_new
                break
            f = f_new
        return float(f)
