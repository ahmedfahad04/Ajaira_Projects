
def get_confusion_matrix(gt_label, pred_label, num_classes):
    import numpy as np
    def get_confusion_matrix(gt_label, pred_label, num_classes):
        gt = np.asarray(gt_label)
        pred = np.asarray(pred_label)
        if gt.shape != pred.shape:
            raise ValueError("gt_label and pred_label must have the same length")
        if num_classes <= 0:
            return np.zeros((0, 0), dtype=np.int64)
        gt_flat = gt.ravel().astype(np.int64)
        pred_flat = pred.ravel().astype(np.int64)
        valid = (gt_flat >= 0) & (gt_flat < num_classes) & (pred_flat >= 0) & (pred_flat < num_classes)
        cm = np.zeros((num_classes, num_classes), dtype=np.int64)
        if valid.any():
            np.add.at(cm, (gt_flat[valid], pred_flat[valid]), 1)
        return cm
