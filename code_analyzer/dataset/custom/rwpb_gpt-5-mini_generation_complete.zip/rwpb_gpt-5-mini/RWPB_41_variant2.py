
def merge_short_sentences_en(sens):
    def merge_short_sentences_en(sens):
        """Merge sentences until each output sentence has at least threshold words or chars.
        Uses an iterative greedy approach: grow current sentence by appending next until it is long enough.
        """
        if not sens:
            return []
        # thresholds
        MIN_WORDS = 5
        MIN_CHARS = 40
        out = []
        i = 0
        n = len(sens)
        while i < n:
            cur = sens[i].strip()
            # keep appending next sentences while still short
            while True:
                words = len(cur.split())
                if (words >= MIN_WORDS) or (len(cur) >= MIN_CHARS):
                    break
                if i + 1 >= n:
                    break
                i += 1
                nxt = sens[i].strip()
                # join with a space, avoid double spaces
                if cur.endswith(('?', '!', '.', ':', ';')):
                    # remove trailing spaces and don't add extra punctuation
                    cur = cur.rstrip()
                cur = cur + ' ' + nxt
            out.append(cur)
            i += 1
        # If last element still too short and there is a previous, merge backwards
        if len(out) >= 2:
            last = out[-1]
            if len(last.split()) <= 2:
                out[-2] = out[-2].rstrip() + ' ' + last
                out.pop()
        return out
