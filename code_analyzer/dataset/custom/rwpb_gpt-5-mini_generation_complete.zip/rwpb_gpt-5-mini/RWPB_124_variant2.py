
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        if torch.is_tensor(divisor):
            d = float(divisor.max().item())
        else:
            d = float(divisor)
        if d == 0:
            raise ValueError("divisor must be non-zero")
        d = abs(d)
        q = float(x) / d
        low_q = math.floor(q)
        high_q = math.ceil(q)
        low = low_q * d
        high = high_q * d
        # choose the closest; on ties prefer the higher one
        if abs(x - low) < abs(high - x):
            return int(low)
        else:
            return int(high)
