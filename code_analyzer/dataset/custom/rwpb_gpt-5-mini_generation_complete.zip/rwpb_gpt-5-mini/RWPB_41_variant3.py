
def merge_short_sentences_en(sens):
    def merge_short_sentences_en(sens):
        """Recursive approach: check head, if short merge with next and recurse on remaining.
        Shortness defined as <=4 words or <=30 characters.
        """
        if not sens:
            return []
        def is_short(s):
            s = s.strip()
            return len(s.split()) <= 4 or len(s) <= 30
        def helper(lst):
            if not lst:
                return []
            if len(lst) == 1:
                return lst[:]  # single item, return as is
            first = lst[0].strip()
            if is_short(first):
                # merge first with second
                second = lst[1].strip()
                merged = first.rstrip()
                if merged and merged[-1] in '.!?':
                    merged = merged[:-1].rstrip()
                # lower-case second's starting letter if appropriate
                if second:
                    merged = merged + ' ' + second[0].lower() + second[1:] if second[0].isupper() else merged + ' ' + second
                else:
                    merged = merged + ' ' + second
                new_list = [merged] + lst[2:]
                return helper(new_list)
            else:
                return [first] + helper(lst[1:])
        result = helper([s.strip() for s in sens])
        # If final sentence is very short and there is a previous, attach to previous
        if len(result) >= 2 and is_short(result[-1]):
            result[-2] = result[-2].rstrip() + ' ' + result[-1]
            result.pop()
        return result
