
def rot6d_to_rotmat(x):
    import torch
    import numpy as np
    def rot6d_to_rotmat(x):
        if isinstance(x, np.ndarray):
            x = torch.from_numpy(x)
        if not isinstance(x, torch.Tensor):
            raise ValueError("Input must be torch.Tensor or numpy.ndarray")
        if x.dim() != 2 or x.shape[1] != 6:
            raise ValueError("Input must have shape (B,6)")
        x = x.float()
        a1 = x[:, :3]
        a2 = x[:, 3:6]
        # build a stable 3x3 by using cross for third column
        c3 = torch.cross(a1, a2, dim=1)
        M = torch.stack([a1, a2, c3], dim=2)  # (B,3,3) columns are a1,a2,cross
        # polar decomposition via SVD to get rotation closest to M
        U, S, Vh = torch.linalg.svd(M, full_matrices=False)
        R = U @ Vh
        # ensure determinant positive
        det = torch.det(R)
        neg_mask = (det < 0)
        if neg_mask.any():
            # flip last column of U where necessary
            U[neg_mask, :, -1] = -U[neg_mask, :, -1]
            R = U @ Vh
        return R
