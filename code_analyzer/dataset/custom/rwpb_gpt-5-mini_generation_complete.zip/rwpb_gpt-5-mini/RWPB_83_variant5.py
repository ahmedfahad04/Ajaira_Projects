
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        min_h, min_w = size
        img = sample.get("image")
        if img is None:
            return None
        h, w = img.shape[:2]
        # If either dimension is below minimum, compute scale factor
        scale_h = float(min_h) / h if h < min_h else 1.0
        scale_w = float(min_w) / w if w < min_w else 1.0
        scale = max(scale_h, scale_w)
        if scale <= 1.0:
            return (h, w)
        # compute exact new size using ceil to ensure minimums
        new_h = int(math.ceil(h * scale))
        new_w = int(math.ceil(w * scale))
        # perform resize
        resized_image = cv2.resize(img, (new_w, new_h), interpolation=image_interpolation_method)
        sample["image"] = resized_image
        # handle disparity: resize and scale values by average scale (robust to rounding)
        if "disparity" in sample and sample["disparity"] is not None:
            d = np.asarray(sample["disparity"]).astype(np.float32)
            d_resized = cv2.resize(d, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            # compute effective scales
            eff_scale_y = new_h / float(h)
            eff_scale_x = new_w / float(w)
            eff_scale = (eff_scale_x + eff_scale_y) / 2.0
            d_resized = d_resized * eff_scale
            sample["disparity"] = d_resized.astype(np.asarray(sample["disparity"]).dtype)
        # handle mask: nearest neighbor and enforce binary mask
        if "mask" in sample and sample["mask"] is not None:
            m = np.asarray(sample["mask"])
            m_resized = cv2.resize(m, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            # Ensure binary values 0/1 matching original dtype
            if m.dtype == np.bool_:
                m_resized = m_resized.astype(bool)
            else:
                m_resized = (m_resized > 0).astype(m.dtype)
            sample["mask"] = m_resized
        return (new_h, new_w)
