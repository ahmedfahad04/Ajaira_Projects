
def fovx_to_fovy(fovx, aspect):
    import numpy as np
    def fovx_to_fovy(fovx, aspect):
        fovx_arr = np.asarray(fovx, dtype=float)
        aspect_arr = np.asarray(aspect, dtype=float)
        half_tan = np.tan(0.5 * fovx_arr) / aspect_arr
        result = 2.0 * np.arctan(half_tan)
        if np.isscalar(fovx) and np.isscalar(aspect):
            return float(result)
        return result
