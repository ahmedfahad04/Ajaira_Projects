
def crop_mask(masks, boxes):
    import torch
    def crop_mask(masks, boxes):
        """
        Vectorized cropping using boolean mask from grid coordinates.
        Keeps pixels inside [x1,y1,x2,y2] (inclusive) and zeros outside.
        """
        if masks.dim() != 3:
            raise ValueError("masks must be [n, h, w]")
        n, h, w = masks.shape
        if boxes.shape[0] != n or boxes.shape[1] != 4:
            raise ValueError("boxes must be [n, 4] and match masks batch size")
        device = masks.device
        dtype = masks.dtype
        # Prepare coordinate grids
        x = torch.arange(w, device=device, dtype=boxes.dtype).view(1, 1, w)
        y = torch.arange(h, device=device, dtype=boxes.dtype).view(1, h, 1)
        bx = boxes.to(device=device, dtype=boxes.dtype)
        x1 = bx[:, 0].view(n, 1, 1)
        y1 = bx[:, 1].view(n, 1, 1)
        x2 = bx[:, 2].view(n, 1, 1)
        y2 = bx[:, 3].view(n, 1, 1)
        inside = (x >= x1) & (x <= x2) & (y >= y1) & (y <= y2)
        inside = inside.to(dtype)
        return masks * inside
