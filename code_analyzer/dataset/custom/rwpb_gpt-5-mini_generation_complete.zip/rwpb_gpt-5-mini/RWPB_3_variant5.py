
def get_focalLength_from_fieldOfView(fov=60, img_size=512):
    import numpy as np
    def get_focalLength_from_fieldOfView(fov=60, img_size=512):
        """
        Flexible: accepts fov in degrees or radians (auto-detect) and supports array-like inputs.
        If any fov magnitude > 2*pi, interprets as degrees.
        """
        fov_arr = np.asarray(fov, dtype=float)
        if np.any(np.abs(fov_arr) > 2 * np.pi):
            rad = np.deg2rad(fov_arr)
        else:
            rad = fov_arr
        img = np.asarray(img_size, dtype=float)
        return (img / 2.0) / np.tan(rad / 2.0)
