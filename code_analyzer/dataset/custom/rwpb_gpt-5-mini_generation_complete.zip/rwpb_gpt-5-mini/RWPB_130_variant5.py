
def bbox_ioa(box1, box2, iou=False, eps=1e-7):
    import numpy as np
    def bbox_ioa(box1, box2, iou=False, eps=1e-7):
        A = np.asarray(box1, dtype=float)
        B = np.asarray(box2, dtype=float)
        if A.ndim == 1:
            A = A.reshape(1, 4)
        if B.ndim == 1:
            B = B.reshape(1, 4)
        n, m = A.shape[0], B.shape[0]
        if n == 0 or m == 0:
            return np.zeros((n, m), dtype=float)
        A_rep = np.repeat(A, m, axis=0)
        B_tile = np.tile(B, (n, 1))
        x1 = np.maximum(A_rep[:, 0], B_tile[:, 0])
        y1 = np.maximum(A_rep[:, 1], B_tile[:, 1])
        x2 = np.minimum(A_rep[:, 2], B_tile[:, 2])
        y2 = np.minimum(A_rep[:, 3], B_tile[:, 3])
        w = np.clip(x2 - x1, 0, None)
        h = np.clip(y2 - y1, 0, None)
        inter = (w * h).reshape(n, m)
        areaA = np.clip(A[:, 2] - A[:, 0], 0, None) * np.clip(A[:, 3] - A[:, 1], 0, None)
        areaB = np.clip(B[:, 2] - B[:, 0], 0, None) * np.clip(B[:, 3] - B[:, 1], 0, None)
        if iou:
            union = areaA[:, None] + areaB[None, :] - inter
            return inter / (union + eps)
        return inter / (areaB[None, :] + eps)
