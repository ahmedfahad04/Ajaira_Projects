
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        if not isinstance(tensor, torch.Tensor):
            tensor = torch.tensor(tensor)
        if tensor.ndim != 3:
            raise ValueError("Expected tensor with shape CxHxW")
        C, H, W = tensor.shape
        oh, ow = int(original_size[0]), int(original_size[1])
        # If already correct size
        if H == oh and W == ow:
            return tensor.contiguous()
        # Compute aspect ratios
        orig_ar = ow / oh
        cur_ar = W / H
        # If aspect ratios match, simply center-crop/resize to exact size
        if abs(orig_ar - cur_ar) < 1e-6:
            if H >= oh and W >= ow:
                top = (H - oh) // 2
                left = (W - ow) // 2
                return tensor[:, top:top + oh, left:left + ow].contiguous()
            else:
                return F.interpolate(tensor.unsqueeze(0), size=(oh, ow), mode='bilinear', align_corners=False).squeeze(0).contiguous()
        # Crop the dimension that exceeds the target aspect ratio to match original aspect ratio
        if cur_ar > orig_ar:
            # too wide -> reduce width
            target_w = max(1, int(round(H * orig_ar)))
            left = (W - target_w) // 2
            cropped = tensor[:, :, left:left + target_w]
        else:
            # too tall -> reduce height
            target_h = max(1, int(round(W / orig_ar)))
            top = (H - target_h) // 2
            cropped = tensor[:, top:top + target_h, :]
        # After cropping to the right aspect, resize to exact original size if needed
        if cropped.shape[1] == oh and cropped.shape[2] == ow:
            return cropped.contiguous()
        return F.interpolate(cropped.unsqueeze(0), size=(oh, ow), mode='bilinear', align_corners=False).squeeze(0).contiguous()
