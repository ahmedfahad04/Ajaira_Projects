
def numpy_to_pytorch(x):
    import numpy as np
    import torch
    def numpy_to_pytorch(x):
        arr = np.ascontiguousarray(np.asarray(x, dtype=np.float32))
        t = torch.from_numpy(arr)
        t = t.unsqueeze(0)
        t = t / 255.0
        return t.float()
