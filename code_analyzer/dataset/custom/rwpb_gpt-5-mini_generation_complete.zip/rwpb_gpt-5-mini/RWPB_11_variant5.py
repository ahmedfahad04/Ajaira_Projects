
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    def pad_to_max_seq_length(ls: list, max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be a non-negative integer")
        n = len(ls)
        if n == max_seq_length:
            return list(ls)
        if n > max_seq_length:
            if check:
                raise ValueError("Input longer than max_seq_length")
            # if not checking, keep original (no truncation)
            return list(ls)
        pads = [pad_idx] * (max_seq_length - n)
        return (list(ls) + pads) if pad_right else (pads + list(ls))
