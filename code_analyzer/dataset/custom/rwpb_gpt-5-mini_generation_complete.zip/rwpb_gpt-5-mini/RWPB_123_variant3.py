
def fuse_deconv_and_bn(deconv, bn):
    import torch
    import torch.nn as nn
    def fuse_deconv_and_bn(deconv, bn):
        # This variant modifies the given deconv in-place and returns it.
        if not isinstance(deconv, nn.ConvTranspose2d) or not isinstance(bn, nn.BatchNorm2d):
            raise ValueError("Expected ConvTranspose2d and BatchNorm2d")
        if bn.num_features != deconv.out_channels:
            raise ValueError("BatchNorm num_features must match deconv out_channels")
        W = deconv.weight.data
        device = W.device
        dtype = W.dtype
        running_mean = bn.running_mean.to(device=device, dtype=dtype)
        running_var = bn.running_var.to(device=device, dtype=dtype)
        gamma = bn.weight.to(device=device, dtype=dtype) if bn.weight is not None else torch.ones_like(running_mean)
        beta = bn.bias.to(device=device, dtype=dtype) if bn.bias is not None else torch.zeros_like(running_mean)
        eps = bn.eps
        scale = gamma / torch.sqrt(running_var + eps)
        out_channels = deconv.out_channels
        groups = deconv.groups
        in_channels = deconv.in_channels
        # If groups == 1 we can broadcast easily, otherwise handle per-group using reshape trick
        if groups == 1:
            W.mul_(scale.view(1, out_channels, 1, 1))
        else:
            out_per_group = out_channels // groups
            in_per_group = in_channels // groups
            # reshape to (groups, in_per_group, out_per_group, kH, kW)
            kH, kW = W.shape[2], W.shape[3]
            Wg = W.view(groups, in_per_group, out_per_group, kH, kW)
            scale_g = scale.view(groups, out_per_group).view(groups, 1, out_per_group, 1, 1)
            Wg.mul_(scale_g)
            W.copy_(Wg.view_as(W))
        b_conv = deconv.bias.data if deconv.bias is not None else torch.zeros(out_channels, device=device, dtype=dtype)
        b_fused = (b_conv - running_mean) * scale + beta
        if deconv.bias is None:
            deconv.bias = nn.Parameter(b_fused)
        else:
            deconv.bias.data.copy_(b_fused)
        return deconv
