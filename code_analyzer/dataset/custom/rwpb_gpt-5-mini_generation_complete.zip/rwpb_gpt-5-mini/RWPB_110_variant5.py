
def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
    import numpy as np
    def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
        # Alternative: compute with projection and handle edge cases explicitly
        n = np.asarray(plane_normal, dtype=float)
        p0 = np.asarray(plane_point, dtype=float)
        d = np.asarray(ray_direction, dtype=float)
        r0 = np.asarray(ray_point, dtype=float)
        n = n.reshape(-1)
        p0 = p0.reshape(-1)
        d = d.reshape(-1)
        r0 = r0.reshape(-1)
        # zero direction or zero normal -> undefined
        if np.linalg.norm(d) < 1e-15 or np.linalg.norm(n) < 1e-15:
            return None
        # distance from ray_point to plane along the normal
        dist = np.dot(n, p0 - r0)
        dir_along_normal = np.dot(n, d)
        if abs(dir_along_normal) < 1e-12:
            return None
        t = dist / dir_along_normal
        return r0 + t * d
