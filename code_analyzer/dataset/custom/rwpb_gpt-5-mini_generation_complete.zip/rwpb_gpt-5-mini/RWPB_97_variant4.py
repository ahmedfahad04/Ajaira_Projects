
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        if not isinstance(image, np.ndarray):
            raise ValueError("not a valid image")
        # Ensure numeric array
        arr = np.asarray(image)
        if arr.ndim == 2:
            h, w = arr.shape
            out = torch.empty((1, h, w), dtype=torch.float32)
            out[0].copy_(torch.from_numpy(arr.astype(np.float32) / 255.0))
            return out
        elif arr.ndim == 3:
            h, w, c = arr.shape
            if c <= 0:
                raise ValueError("not a valid image")
            out = torch.empty((c, h, w), dtype=torch.float32)
            np_reorder = np.moveaxis(arr, 2, 0).astype(np.float32) / 255.0
            out.copy_(torch.from_numpy(np_reorder))
            return out
        else:
            raise ValueError("not a valid image")
