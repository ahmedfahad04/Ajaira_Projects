
def euler2rot(euler_angle):
    import torch
    def euler2rot(euler_angle):
        if not torch.is_tensor(euler_angle):
            euler_angle = torch.tensor(euler_angle)
        a = euler_angle
        if a.dim() == 1:
            a = a.unsqueeze(0)
        roll = a[:,0]; pitch = a[:,1]; yaw = a[:,2]
        hr = roll * 0.5; hp = pitch * 0.5; hy = yaw * 0.5
        cr = torch.cos(hr); sr = torch.sin(hr)
        cp = torch.cos(hp); sp = torch.sin(hp)
        cy = torch.cos(hy); sy = torch.sin(hy)
        w = cr * cp * cy + sr * sp * sy
        x = sr * cp * cy - cr * sp * sy
        y = cr * sp * cy + sr * cp * sy
        z = cr * cp * sy - sr * sp * cy
        wx = w * x; wy = w * y; wz = w * z
        xx = x * x; xy = x * y; xz = x * z
        yy = y * y; yz = y * z; zz = z * z
        r00 = 1 - 2 * (yy + zz)
        r01 = 2 * (xy - wz)
        r02 = 2 * (xz + wy)
        r10 = 2 * (xy + wz)
        r11 = 1 - 2 * (xx + zz)
        r12 = 2 * (yz - wx)
        r20 = 2 * (xz - wy)
        r21 = 2 * (yz + wx)
        r22 = 1 - 2 * (xx + yy)
        R = torch.stack([
            torch.stack([r00, r01, r02], dim=1),
            torch.stack([r10, r11, r12], dim=1),
            torch.stack([r20, r21, r22], dim=1),
        ], dim=1)
        R = R.permute(0,2,1)
        return R
