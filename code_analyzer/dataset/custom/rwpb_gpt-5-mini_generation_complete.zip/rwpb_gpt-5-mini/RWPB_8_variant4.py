
def cvimg2torch(img):
    import numpy as np
    import torch
    def cvimg2torch(img):
        """
        Convert image to tensor 1xCxHxW by manually copying into a preallocated tensor.
        Produces float32 in [0,1].
        """
        arr = np.asarray(img)
        if arr.ndim == 2:
            arr = arr[:, :, None]
        H, W, C = arr.shape
        out = torch.empty((1, C, H, W), dtype=torch.float32)
        # copy per channel to avoid intermediate large transposes (explicit loop)
        for c in range(C):
            channel = arr[:, :, c].astype(np.float32) / 255.0
            out[0, c] = torch.from_numpy(channel)
        return out
