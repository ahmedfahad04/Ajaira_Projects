
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        # Convert to tensors if needed
        if not isinstance(geometry, torch.Tensor):
            geometry = torch.tensor(geometry)
        if not isinstance(rot, torch.Tensor):
            rot = torch.tensor(rot)
        if not isinstance(trans, torch.Tensor):
            trans = torch.tensor(trans)
        B, N, C = geometry.shape
        if rot.dim() == 2:
            rot = rot.unsqueeze(0).expand(B, -1, -1)
        if trans.dim() == 1:
            trans = trans.unsqueeze(0).expand(B, -1)
        # Flatten batch and points into one dimension and use a single matmul
        flat = geometry.reshape(B * N, 3)           # [B*N, 3]
        rot_block = rot.repeat_interleave(N, dim=0)  # [B*N, 3, 3]
        # For each flat point multiply with corresponding rotation: use bmm with vectors as [B*N,3,1]
        vec = flat.unsqueeze(-1)  # [B*N,3,1]
        rotated_vec = torch.bmm(rot_block, vec).squeeze(-1)  # [B*N,3]
        rotated = rotated_vec.view(B, N, 3)
        translated = rotated + trans.unsqueeze(1)
        return translated
