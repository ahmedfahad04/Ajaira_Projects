
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        if torch.is_tensor(divisor):
            d = float(divisor.max().item())
        else:
            d = float(divisor)
        if d == 0:
            raise ValueError("divisor must be non-zero")
        d = abs(d)
        x_f = float(x)
        # brute-force search around the integer quotient for the nearest multiple
        base = math.floor(x_f / d)
        best_k = base
        best_val = best_k * d
        best_dist = abs(x_f - best_val)
        # check neighbors up to a small range (should be enough: only next neighbors needed)
        for k in (base - 1, base + 1):
            val = k * d
            dist = abs(x_f - val)
            if dist < best_dist:
                best_dist = dist
                best_val = val
                best_k = k
            elif dist == best_dist:
                # tie-breaker: choose the higher multiple
                if val > best_val:
                    best_val = val
                    best_k = k
        return int(best_val)
