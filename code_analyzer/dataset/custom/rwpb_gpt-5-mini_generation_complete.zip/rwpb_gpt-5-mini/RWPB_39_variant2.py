
def clean_html(:
    import re
    from typing import List
    from html import escape
    def clean_html(
            html_to_clean: str,
            tags_to_remove: List[str] = ["style", "svg", "script"],
            attributes_to_keep: List[str] = ["id", "href"],
    ) -> str:
        text = html_to_clean
        # Remove specified tags and their content (including nested ones naively)
        for tag in tags_to_remove:
            # remove content tags with content
            pattern = re.compile(rf'(?is)<{re.escape(tag)}\b[^>]*?>.*?</{re.escape(tag)}\s*>')
            text = pattern.sub('', text)
            # remove self-closing forms
            pattern2 = re.compile(rf'(?is)<{re.escape(tag)}\b[^>]*?/>')
            text = pattern2.sub('', text)
        keep = set(a.lower() for a in attributes_to_keep)
        # Callback to rebuild tag keeping only allowed attributes
        attr_re = re.compile(r'([^\s=<>/]+)(\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^"\'>\s]+))?', re.S)
        def repl_tag(m):
            whole = m.group(0)
            closing = m.group(1)
            tag = m.group(2)
            rest = m.group(3) or ''
            if closing:
                return whole  # keep closing tags unchanged
            # preserve self-closing slash if present at end before >
            self_closing = '/' if whole.rstrip().endswith('/>') else ''
            attrs = []
            for am in attr_re.finditer(rest):
                name = am.group(1)
                val = am.group(2)
                if name and name.lower() in keep:
                    if val is None:
                        attrs.append(name)
                    else:
                        # normalize value quotes
                        raw = val.split('=', 1)[1].strip()
                        if raw[0] in "\"'":
                            raw_val = raw.strip()
                        else:
                            raw_val = '"' + raw.strip() + '"'
                        # strip surrounding quotes to escape properly
                        if raw_val[0] in "\"'":
                            stripped = raw_val[1:-1]
                        else:
                            stripped = raw_val
                        attrs.append(f'{name}="{escape(stripped, quote=True)}"')
            attr_text = (" " + " ".join(attrs)) if attrs else ""
            return f"<{tag}{attr_text}{self_closing}>"
        tag_pattern = re.compile(r'(<\s*(/)?\s*([a-zA-Z0-9:_-]+)([^>]*)>)', re.S)
        result = tag_pattern.sub(lambda m: repl_tag((m.group(1), m.group(2), m.group(3), m.group(4))) if False else repl_tag(m), text)
        return result
