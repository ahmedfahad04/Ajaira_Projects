
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    def generate_grids(lower_limit, upper_limit, grid_size):
        # ensure tensors
        lower = torch.as_tensor(lower_limit)
        upper = torch.as_tensor(upper_limit)
        gs = torch.as_tensor(grid_size)
        # flatten to 1D
        lower = lower.flatten().to(dtype=torch.float32, device=lower.device)
        upper = upper.flatten().to(dtype=torch.float32, device=upper.device)
        gs = gs.flatten()
        D = lower.numel()
        if gs.numel() == 1 and D > 1:
            gs = gs.expand(D)
        gs = gs.to(dtype=torch.long)
        # build edge vectors for each dimension
        lower_edges = []
        upper_edges = []
        for i in range(D):
            n_cells = int(gs[i].item())
            if n_cells < 1:
                raise ValueError("grid_size must be >= 1 for each dimension")
            edges = torch.linspace(lower[i].item(), upper[i].item(), steps=n_cells + 1,
                                   device=lower.device, dtype=lower.dtype)
            lower_edges.append(edges[:-1])
            upper_edges.append(edges[1:])
        # use torch.cartesian_prod for combinations
        if len(lower_edges) == 0:
            return torch.empty((0, 0), dtype=lower.dtype), torch.empty((0, 0), dtype=lower.dtype)
        lower_grid = torch.cartesian_prod(*lower_edges)
        upper_grid = torch.cartesian_prod(*upper_edges)
        return lower_grid, upper_grid
