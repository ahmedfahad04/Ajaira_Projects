
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        # Alternative interpretation: return s as the average half-size (mean of half width and half height)
        x, y, x1, y1 = box
        x, y, x1, y1 = float(x), float(y), float(x1), float(y1)
        # center
        cx = (x + x1) / 2.0
        cy = (y + y1) / 2.0
        w = abs(x1 - x)
        h = abs(y1 - y)
        new_w = w * float(expand)
        new_h = h * float(expand)
        new_x = cx - new_w / 2.0
        new_y = cy - new_h / 2.0
        new_x1 = cx + new_w / 2.0
        new_y1 = cy + new_h / 2.0
        # use average half-size
        s = (new_w / 2.0 + new_h / 2.0) / 2.0
        return [new_x, new_y, new_x1, new_y1], s
