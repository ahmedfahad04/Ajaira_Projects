
def crop_mask(masks, boxes):
    import torch
    def crop_mask(masks, boxes):
        """
        Build row and column masks separately and combine (outer product style).
        """
        if masks.dim() != 3:
            raise ValueError("masks must be [n, h, w]")
        n, h, w = masks.shape
        if boxes.shape[0] != n or boxes.shape[1] != 4:
            raise ValueError("boxes must be [n, 4] and match masks batch size")
        device = masks.device
        bx = boxes.to(device=device, dtype=torch.float32)
        ys = torch.arange(h, device=device, dtype=torch.float32).view(1, h, 1)  # (1,h,1)
        xs = torch.arange(w, device=device, dtype=torch.float32).view(1, 1, w)  # (1,1,w)
        y1 = bx[:, 1].view(n, 1, 1)
        y2 = bx[:, 3].view(n, 1, 1)
        x1 = bx[:, 0].view(n, 1, 1)
        x2 = bx[:, 2].view(n, 1, 1)
        row_mask = (ys >= y1) & (ys <= y2)   # (n,h,1)
        col_mask = (xs >= x1) & (xs <= x2)   # (n,1,w)
        crop = (row_mask & col_mask).to(masks.dtype)  # broadcast to (n,h,w)
        return masks * crop
