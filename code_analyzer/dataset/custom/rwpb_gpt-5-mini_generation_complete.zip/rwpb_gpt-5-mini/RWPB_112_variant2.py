
def submatrix(matrix, col):
    def submatrix(matrix, col):
        if not matrix:
            return []
        # ensure all rows have equal length
        n = len(matrix[0])
        for row in matrix:
            if len(row) != n:
                raise ValueError("All rows must have the same length for transpose-based removal")
        if not (-n <= col < n):
            raise IndexError("column index out of range")
        # If removing the only column, return rows of empty lists
        if n == 1:
            return [[] for _ in matrix]
        # transpose, remove column, transpose back
        transposed = [list(c) for c in zip(*matrix)]
        del transposed[col]
        result = [list(r) for r in zip(*transposed)]
        return result
