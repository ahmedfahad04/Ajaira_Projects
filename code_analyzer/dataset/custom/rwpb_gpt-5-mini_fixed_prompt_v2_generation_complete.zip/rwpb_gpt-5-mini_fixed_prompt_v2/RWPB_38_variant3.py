
def extract_imports_from_lines(lines: List[str]) -> str:
    from typing import List
    import ast
    def extract_imports_from_lines(lines: List[str]) -> str:
        src = "\n".join(line.rstrip("\n") for line in lines)
        try:
            tree = ast.parse(src)
        except Exception:
            # fall back to simple line scan if source can't be parsed
            out = []
            for line in lines:
                s = line.lstrip()
                if s.startswith("import ") or s.startswith("from "):
                    out.append(line.rstrip())
            return "\n".join(out)
        results = []
        for node in tree.body:
            if isinstance(node, ast.Import):
                parts = []
                for alias in node.names:
                    if alias.asname:
                        parts.append(f"{alias.name} as {alias.asname}")
                    else:
                        parts.append(alias.name)
                results.append("import " + ", ".join(parts))
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                # handle relative level
                if node.level:
                    module = "." * node.level + module
                parts = []
                for alias in node.names:
                    if alias.asname:
                        parts.append(f"{alias.name} as {alias.asname}")
                    else:
                        parts.append(alias.name)
                results.append(f"from {module} import " + ", ".join(parts))
        return "\n".join(results)
