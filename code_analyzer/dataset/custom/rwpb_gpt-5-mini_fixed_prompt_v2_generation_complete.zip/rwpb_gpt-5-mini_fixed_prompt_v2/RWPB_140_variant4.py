
def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
    from typing import Callable, Dict, Tuple, Any
    import inspect
    from functools import partial
    def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
        params = dict(params or {})
        # If it's a functools.partial, preserve its already bound keywords first
        if isinstance(func, partial):
            base_bound = dict(func.keywords or {})
        else:
            base_bound = {}
        try:
            spec = inspect.getfullargspec(func)
        except (TypeError, ValueError):
            # no spec, return partial preserving existing bound keywords only
            return partial(func, **base_bound), dict(base_bound)
        # If accepts **kwargs, combine everything (but do not overwrite existing bound keys)
        if spec.varkw:
            combined = dict(params)
            combined.update(base_bound)
            return partial(func, **combined), combined
        allowed = set()
        if spec.args:
            allowed.update(spec.args)
        if hasattr(spec, "posonlyargs") and spec.posonlyargs:
            # posonly can't be keyword
            allowed -= set(spec.posonlyargs)
        if spec.kwonlyargs:
            allowed.update(spec.kwonlyargs)
        # Do not override already bound keys; merge with existing bound keys
        matched = {k: v for k, v in params.items() if k in allowed and k not in base_bound}
        merged = dict(base_bound)
        merged.update(matched)
        return partial(func, **merged), merged
