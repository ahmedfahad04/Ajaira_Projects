
def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        original_x = x
        if upcast:
            x = x.to(torch.float32)
            if weight is not None:
                weight = weight.to(torch.float32)
            if bias is not None:
                bias = bias.to(torch.float32)
            if residual is not None:
                residual = residual.to(torch.float32)
        # collapse leading dims to perform matrix-style normalization
        feat = x.size(-1)
        leading = int(x.numel() // feat)
        flat = x.contiguous().view(leading, feat)
        mean = flat.mean(dim=1, keepdim=True)
        var = ((flat - mean) ** 2).mean(dim=1, keepdim=True)
        inv_std = torch.rsqrt(var + eps)
        norm_flat = (flat - mean) * inv_std
        norm = norm_flat.view_as(x)
        if weight is not None:
            w = weight.view(*([1] * (x.dim() - 1)), -1)
            norm = norm * w
        if bias is not None:
            b = bias.view(*([1] * (x.dim() - 1)), -1)
            norm = norm + b
        if residual is not None:
            norm = norm + residual
        if prenorm:
            return norm, original_x
        return norm
