
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    from collections import deque
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        out = {}
        q = deque()
        q.append((parent_key, d))
        while q:
            prefix, cur = q.popleft()
            for k, v in cur.items():
                key = prefix + sep + str(k) if prefix else str(k)
                if isinstance(v, dict):
                    q.append((key, v))
                else:
                    out[key] = v
        return out
