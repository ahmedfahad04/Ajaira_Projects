
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        # Build interleaved tensors using Python-level loop and torch.cat
        if not isinstance(tensor1, torch.Tensor) or not isinstance(tensor2, torch.Tensor):
            raise TypeError("Inputs must be torch.Tensor")
        if tensor1.shape != tensor2.shape:
            raise ValueError("Input tensors must have the same shape")
        n = tensor1.shape[0] if tensor1.dim() > 0 else 0
        if n == 0:
            return tensor1.clone(), tensor2.clone()
        parts1 = []
        parts2 = []
        for i in range(n):
            parts1.append(tensor1[i:i+1])
            parts1.append(tensor2[i:i+1])
            parts2.append(tensor2[i:i+1])
            parts2.append(tensor1[i:i+1])
        out1 = torch.cat(parts1, dim=0)
        out2 = torch.cat(parts2, dim=0)
        return out1, out2
