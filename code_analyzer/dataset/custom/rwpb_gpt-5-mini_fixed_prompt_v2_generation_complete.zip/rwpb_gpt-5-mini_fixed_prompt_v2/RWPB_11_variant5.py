
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    from typing import List
    def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        if not isinstance(max_seq_length, int):
            raise ValueError("max_seq_length must be int")
        if max_seq_length < 0:
            raise ValueError("max_seq_length must be non-negative")
        orig_len = len(ls)
        if orig_len == max_seq_length:
            return list(ls)
        if orig_len > max_seq_length:
            # prefer simple slicing
            if pad_right:
                out = ls[:max_seq_length]
            else:
                out = ls[orig_len - max_seq_length:]
        else:
            pad_count = max_seq_length - orig_len
            pads = [pad_idx] * pad_count
            out = ls + pads if pad_right else pads + ls
        if check and len(out) != max_seq_length:
            raise ValueError("Result length does not equal max_seq_length")
        return list(out)
