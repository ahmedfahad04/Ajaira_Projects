
def get_focalLength_from_fieldOfView(fov=60, img_size=512):
    import math
    def get_focalLength_from_fieldOfView(fov=60, img_size=512):
        if fov <= 0 or fov >= 180:
            raise ValueError("fov must be between 0 and 180 degrees (exclusive).")
        half_rad = math.radians(fov) / 2.0
        # Use Taylor series approximation for tan(x) when x is small to improve numerical stability
        x = half_rad
        if abs(x) < 1e-3:
            # tan(x) ~ x + x^3/3 + 2*x^5/15
            tan_approx = x + (x**3) / 3.0 + (2.0 * x**5) / 15.0
            focal = (img_size / 2.0) / tan_approx
        else:
            focal = (img_size / 2.0) / math.tan(x)
        return float(focal)
