
def crop_mask(masks, boxes):
    import torch
    def crop_mask(masks, boxes):
        """
        Loop using boolean indexing per-sample (different style).
        """
        if masks.ndim != 3:
            raise ValueError("masks must be [n, h, w]")
        n, H, W = masks.shape
        if boxes.shape[0] != n or boxes.shape[1] != 4:
            raise ValueError("boxes must be [n, 4]")
        device = masks.device
        out = masks.clone()  # we'll zero outside regions
        # Make integer bounds
        x1 = torch.floor(boxes[:, 0]).long().to(device)
        y1 = torch.floor(boxes[:, 1]).long().to(device)
        x2 = torch.ceil(boxes[:, 2]).long().to(device)
        y2 = torch.ceil(boxes[:, 3]).long().to(device)
        x1 = x1.clamp(0, W-1)
        y1 = y1.clamp(0, H-1)
        x2 = x2.clamp(0, W-1)
        y2 = y2.clamp(0, H-1)
        # For each sample, zero rows above/below and columns left/right
        for i in range(n):
            xi1, yi1, xi2, yi2 = x1[i].item(), y1[i].item(), x2[i].item(), y2[i].item()
            if yi1 > 0:
                out[i, :yi1, :] = 0
            if yi2 < H-1:
                out[i, yi2+1:, :] = 0
            if xi1 > 0:
                out[i, :, :xi1] = 0
            if xi2 < W-1:
                out[i, :, xi2+1:] = 0
        return out
