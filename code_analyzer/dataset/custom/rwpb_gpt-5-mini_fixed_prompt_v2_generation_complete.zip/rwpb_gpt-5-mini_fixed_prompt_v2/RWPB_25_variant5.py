
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        arr = np.array(img)
        if arr.size == 0:
            return arr.copy()
        orig_dtype = arr.dtype
        max_val = int(arr.max())
        if max_val == 0:
            return arr.copy()
        bin_img = (arr == 0).astype('uint8')  # background mask: 1 for background
        # connected components on background mask
        num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(bin_img, connectivity=8)
        h, w = bin_img.shape[:2]
        filled = (arr > 0).astype('uint8') * 255
        # For each background component, if it does NOT touch border, it's a hole -> fill it
        for label in range(1, num_labels):
            x, y, width, height, area = stats[label]
            # check if component touches border
            touches_border = False
            if x == 0 or y == 0 or (x + width) == w or (y + height) == h:
                touches_border = True
            if not touches_border:
                mask = (labels == label)
                filled[mask] = 255
        result = (filled // 255 * max_val).astype(orig_dtype)
        return result
