
def is_tensor(x):
    import importlib.util
    import numpy as np
    def is_tensor(x):
        if importlib.util.find_spec("torch") is None:
            return isinstance(x, np.ndarray)
        try:
            import torch as _torch
        except Exception:
            return isinstance(x, np.ndarray)
        tx = type(x)
        if tx is getattr(_torch, "Tensor", None):
            return True
        if hasattr(tx, "__module__") and getattr(tx, "__module__", "").startswith("torch"):
            if getattr(tx, "__name__", "") == "Tensor" or "Tensor" in getattr(tx, "__name__", ""):
                return True
        return isinstance(x, np.ndarray)
