
def round(number, num_decimal_places, leave_int=False):
    import math
    def round(number, num_decimal_places, leave_int=False):
        """
        Math-based rounding: half away from zero by shifting and using floor/ceil.
        """
        n = int(num_decimal_places)
        # handle special floats
        if isinstance(number, float) and (math.isnan(number) or math.isinf(number)):
            return float(number)
        # compute scale
        if n >= 0:
            scale = 10 ** n
            scaled = number * scale
            if scaled >= 0:
                rounded_scaled = math.floor(scaled + 0.5)
            else:
                rounded_scaled = math.ceil(scaled - 0.5)
            result = rounded_scaled / scale
        else:
            # negative places: rounding to tens/hundreds etc.
            scale = 10 ** (-n)
            scaled = number / scale
            if scaled >= 0:
                rounded_scaled = math.floor(scaled + 0.5)
            else:
                rounded_scaled = math.ceil(scaled - 0.5)
            result = rounded_scaled * scale
        # decide whether to return int
        if leave_int:
            try:
                if result == int(result):
                    return int(result)
            except Exception:
                pass
        return float(result)
