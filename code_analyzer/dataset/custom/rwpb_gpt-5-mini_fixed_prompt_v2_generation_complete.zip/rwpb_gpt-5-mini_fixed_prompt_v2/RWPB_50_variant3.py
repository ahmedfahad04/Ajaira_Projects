
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        original_h, original_w = original_size
        if not isinstance(tensor, torch.Tensor):
            tensor = torch.as_tensor(tensor)
        # handle batch and single image
        if tensor.ndim == 3:
            C, H, W = tensor.shape
            batch = False
            t = tensor.unsqueeze(0)
        elif tensor.ndim == 4:
            N, C, H, W = tensor.shape
            batch = True
            t = tensor
        else:
            raise ValueError("Expected 3D (C,H,W) or 4D (N,C,H,W) tensor")
        out = []
        for i in range(t.shape[0]):
            img = t[i]
            Hc, Wc = img.shape[1], img.shape[2]
            if Hc == 0 or Wc == 0:
                out.append(img)
                continue
            desired_h = int((original_h * Wc) / original_w)
            desired_w = int((original_w * Hc) / original_h)
            if desired_h < Hc:
                top = (Hc - desired_h) // 2
                cropped = img[:, top:top + desired_h, :]
            elif desired_w < Wc:
                left = (Wc - desired_w) // 2
                cropped = img[:, :, left:left + desired_w]
            else:
                cropped = img
            out.append(cropped)
        stacked = torch.stack(out, dim=0)
        return stacked[0] if not batch else stacked
