
def norm_grid(v_grid):
    import torch
    def norm_grid(v_grid):
        if not isinstance(v_grid, torch.Tensor):
            v_grid = torch.tensor(v_grid)
        B, C, H, W = v_grid.shape
        v = v_grid
        v_min = v.amin(dim=(0,2,3), keepdim=True)
        v_max = v.amax(dim=(0,2,3), keepdim=True)
        denom = v_max - v_min
        denom = torch.where(denom == 0, torch.ones_like(denom), denom)
        v_norm = (v - v_min) / denom * 2.0 - 1.0
        return v_norm.permute(0, 2, 3, 1)
