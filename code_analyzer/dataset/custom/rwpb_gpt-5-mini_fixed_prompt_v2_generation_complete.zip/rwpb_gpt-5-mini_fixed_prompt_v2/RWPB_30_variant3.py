
def get_confusion_matrix(gt_label, pred_label, num_classes):
    import numpy as np
    def get_confusion_matrix(gt_label, pred_label, num_classes):
        if not isinstance(num_classes, int) or num_classes <= 0:
            raise ValueError("num_classes must be a positive integer")
        gt = np.asarray(gt_label)
        pred = np.asarray(pred_label)
        if gt.shape != pred.shape:
            raise ValueError("gt_label and pred_label must have the same length")
        n = gt.size
        cm = np.zeros((num_classes, num_classes), dtype=int)
        if n == 0:
            return cm
        # iterate in Python
        for i in range(n):
            g = int(gt.flat[i])
            p = int(pred.flat[i])
            if g < 0 or p < 0 or g >= num_classes or p >= num_classes:
                raise ValueError("Labels must be in the range [0, num_classes-1]")
            cm[g, p] += 1
        return cm
