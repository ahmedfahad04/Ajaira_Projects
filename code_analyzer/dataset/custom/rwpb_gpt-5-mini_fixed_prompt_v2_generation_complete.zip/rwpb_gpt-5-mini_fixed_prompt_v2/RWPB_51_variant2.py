
def _ssim(img1, img2, window, window_size, channel, size_average=True):
    import torch
    import torch.nn.functional as F
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        if img1.shape != img2.shape:
            raise ValueError("Images must have the same size")
        N, C, H, W = img1.shape
        if window.dim() == 2:
            kernel = window.view(1, 1, window_size, window_size).to(img1.device).to(img1.dtype)
        else:
            kernel = window.clone().to(img1.device).to(img1.dtype)
        pad = window_size // 2
        C1 = (0.01)**2
        C2 = (0.03)**2
        # compute per-channel using a Python loop (explicit)
        ssim_per_channel = []
        for ch in range(channel):
            k = kernel if kernel.size(0) == channel else kernel.expand(channel,1,kernel.size(2),kernel.size(3))
            kc = k[ch:ch+1]
            mu1 = F.conv2d(img1[:, ch:ch+1, :, :], kc, padding=pad)
            mu2 = F.conv2d(img2[:, ch:ch+1, :, :], kc, padding=pad)
            mu1_sq = mu1 * mu1
            mu2_sq = mu2 * mu2
            mu1_mu2 = mu1 * mu2
            sigma1_sq = F.conv2d(img1[:, ch:ch+1, :, :] * img1[:, ch:ch+1, :, :], kc, padding=pad) - mu1_sq
            sigma2_sq = F.conv2d(img2[:, ch:ch+1, :, :] * img2[:, ch:ch+1, :, :], kc, padding=pad) - mu2_sq
            sigma12 = F.conv2d(img1[:, ch:ch+1, :, :] * img2[:, ch:ch+1, :, :], kc, padding=pad) - mu1_mu2
            num = (2 * mu1_mu2 + C1) * (2 * sigma12 + C2)
            den = (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)
            s_map = num / den
            # average over spatial dims and batch to get single number per channel
            s_val = s_map.mean(dim=(0,2,3))
            ssim_per_channel.append(s_val)
        ssim_per_channel = torch.cat(ssim_per_channel, dim=0)
        if size_average:
            return ssim_per_channel.mean()
        else:
            return ssim_per_channel
