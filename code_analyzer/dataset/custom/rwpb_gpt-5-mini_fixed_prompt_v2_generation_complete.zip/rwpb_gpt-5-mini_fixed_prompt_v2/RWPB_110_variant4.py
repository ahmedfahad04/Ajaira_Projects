
def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
    import numpy as np
    def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
        n = np.array(plane_normal, dtype=float)
        pp = np.array(plane_point, dtype=float)
        rd = np.array(ray_direction, dtype=float)
        rp = np.array(ray_point, dtype=float)
        nn = np.linalg.norm(n)
        if nn == 0:
            return None
        n_unit = n / nn
        distance = np.dot(n_unit, pp - rp)
        proj = np.dot(n_unit, rd)
        eps = 1e-12
        if abs(proj) < eps:
            if abs(distance) < eps:
                return rp.copy()
            return None
        t = distance / proj
        return rp + rd * t
