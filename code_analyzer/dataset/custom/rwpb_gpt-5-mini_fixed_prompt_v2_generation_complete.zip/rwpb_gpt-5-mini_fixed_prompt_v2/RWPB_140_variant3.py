
def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
    from typing import Callable, Dict, Tuple, Any
    import inspect
    from functools import partial
    def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
        params = dict(params or {})
        try:
            sig = inspect.signature(func)
        except (ValueError, TypeError):
            return partial(func), {}
        parameters = sig.parameters
        # If function accepts **kwargs -> accept all
        if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in parameters.values()):
            return partial(func, **params), dict(params)
        accepted = {}
        # Try incremental binding: add keys only if they don't cause bind errors
        for key, val in params.items():
            trial = dict(accepted)
            trial[key] = val
            try:
                # Attempt to bind these keywords (no positional args)
                sig.bind_partial(**trial)
                accepted[key] = val
            except TypeError:
                # not accepted as keyword argument (positional-only or unknown)
                continue
        return partial(func, **accepted), accepted
