
def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        original_x = x
        if upcast:
            x = x.to(torch.float32)
            if weight is not None:
                weight = weight.to(torch.float32)
            if bias is not None:
                bias = bias.to(torch.float32)
            if residual is not None:
                residual = residual.to(torch.float32)
        dim = x.dim()
        last = x.size(-1)
        mean = x.mean(dim=-1, keepdim=True)
        var = x.var(dim=-1, unbiased=False, keepdim=True)
        inv_std = torch.rsqrt(var + eps)
        normalized = (x - mean) * inv_std
        if weight is not None:
            shape = [1] * (dim - 1) + [last]
            w = weight.view(*shape)
            normalized = normalized * w
        if bias is not None:
            shape = [1] * (dim - 1) + [last]
            b = bias.view(*shape)
            normalized = normalized + b
        if residual is not None:
            normalized = normalized + residual
        if prenorm:
            return normalized, original_x
        return normalized
