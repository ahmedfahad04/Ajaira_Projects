
def fuse_deconv_and_bn(deconv, bn):
    import torch
    import torch.nn as nn
    def fuse_deconv_and_bn(deconv, bn):
        # validation
        if not isinstance(deconv, nn.ConvTranspose2d) or not isinstance(bn, nn.BatchNorm2d):
            raise TypeError("deconv must be ConvTranspose2d and bn must be BatchNorm2d")
        device = deconv.weight.device
        dtype = deconv.weight.dtype
        out_channels = deconv.out_channels
        in_channels = deconv.in_channels
        groups = deconv.groups
        # BN params (handle non-affine)
        if bn.affine:
            gamma = bn.weight.detach().to(device=device, dtype=dtype)
            beta = bn.bias.detach().to(device=device, dtype=dtype)
        else:
            gamma = torch.ones(out_channels, device=device, dtype=dtype)
            beta = torch.zeros(out_channels, device=device, dtype=dtype)
        running_mean = bn.running_mean.detach().to(device=device, dtype=dtype)
        running_var = bn.running_var.detach().to(device=device, dtype=dtype)
        eps = bn.eps
        sigma = torch.sqrt(running_var + eps)
        a = gamma / sigma
        b = beta - (gamma * running_mean) / sigma
        # create fused layer
        fused = nn.ConvTranspose2d(
            in_channels=deconv.in_channels,
            out_channels=deconv.out_channels,
            kernel_size=deconv.kernel_size,
            stride=deconv.stride,
            padding=deconv.padding,
            output_padding=deconv.output_padding,
            groups=deconv.groups,
            dilation=deconv.dilation,
            bias=True
        ).to(device=device, dtype=dtype)
        old_bias = deconv.bias.detach() if deconv.bias is not None else torch.zeros(out_channels, device=device, dtype=dtype)
        # new bias
        new_bias = a * old_bias + b
        # brute-force multiply each weight element by corresponding a[o]
        w_old = deconv.weight.detach()
        w_new = torch.empty_like(w_old)
        in_per_group = in_channels // groups
        out_per_group = out_channels // groups
        kh, kw = w_old.shape[2], w_old.shape[3]
        for o in range(out_channels):
            g = o // out_per_group
            local_o = o - g * out_per_group
            for i in range(g * in_per_group, (g + 1) * in_per_group):
                for y in range(kh):
                    for x in range(kw):
                        w_new[i, local_o, y, x] = w_old[i, local_o, y, x] * a[o]
        fused.weight.data.copy_(w_new)
        fused.bias.data.copy_(new_bias)
        return fused
