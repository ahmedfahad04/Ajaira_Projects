
def round_nearest_multiple(number, a, direction='standard'):
    import math
    def round_nearest_multiple(number, a, direction='standard'):
        if a == 0:
            raise ValueError("a must be non-zero")
        dir_lower = (direction or 'standard').lower()
        ratio = number / a
        k_floor = math.floor(ratio)
        if dir_lower == 'down':
            k = k_floor
        elif dir_lower == 'up':
            k = math.ceil(ratio)
        elif dir_lower == 'standard':
            candidates = [k_floor - 1, k_floor, k_floor + 1, k_floor + 2]
            best_k = candidates[0]
            best_diff = float('inf')
            for cand in candidates:
                diff = abs(number - cand * a)
                if diff < best_diff - 1e-15:
                    best_diff = diff
                    best_k = cand
                elif abs(diff - best_diff) <= 1e-15:
                    best_k = max(best_k, cand)
            k = best_k
        else:
            raise ValueError("direction must be 'standard', 'down' or 'up'")
        result = k * a
        s = format(a, 'f')
        if '.' in s:
            dec = len(s.split('.')[1].rstrip('0'))
        else:
            dec = 0
        fmt = f"{{0:.{dec}f}}"
        return float(fmt.format(result))
