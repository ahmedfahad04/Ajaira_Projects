
def euler2rot(euler_angle):
    import torch
    def euler2rot(euler_angle):
        if not isinstance(euler_angle, torch.Tensor):
            euler_angle = torch.tensor(euler_angle)
        if euler_angle.dim() == 1:
            euler_angle = euler_angle.unsqueeze(0)
        rx = euler_angle[:, 0]
        ry = euler_angle[:, 1]
        rz = euler_angle[:, 2]
        cx = torch.cos(rx); sx = torch.sin(rx)
        cy = torch.cos(ry); sy = torch.sin(ry)
        cz = torch.cos(rz); sz = torch.sin(rz)
        B = euler_angle.shape[0]
        device = euler_angle.device
        dtype = euler_angle.dtype
        # Rx
        Rx = torch.zeros((B, 3, 3), device=device, dtype=dtype)
        Rx[:, 0, 0] = 1; Rx[:, 1, 1] = cx; Rx[:, 1, 2] = -sx
        Rx[:, 2, 1] = sx; Rx[:, 2, 2] = cx
        # Ry
        Ry = torch.zeros((B, 3, 3), device=device, dtype=dtype)
        Ry[:, 0, 0] = cy; Ry[:, 0, 2] = sy
        Ry[:, 1, 1] = 1
        Ry[:, 2, 0] = -sy; Ry[:, 2, 2] = cy
        # Rz
        Rz = torch.zeros((B, 3, 3), device=device, dtype=dtype)
        Rz[:, 0, 0] = cz; Rz[:, 0, 1] = -sz
        Rz[:, 1, 0] = sz; Rz[:, 1, 1] = cz
        Rz[:, 2, 2] = 1
        # Combined rotation R = Rz * Ry * Rx
        R = torch.matmul(Rz, torch.matmul(Ry, Rx))
        return R
