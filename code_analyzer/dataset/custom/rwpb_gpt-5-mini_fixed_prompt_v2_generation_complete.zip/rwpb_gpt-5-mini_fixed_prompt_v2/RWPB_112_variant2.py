
def submatrix(matrix, col):
    def submatrix(matrix, col):
        """
        Transpose-based approach: transpose, remove the column as a list,
        then transpose back. Works for rectangular matrices.
        """
        if not matrix:
            return []
        # number of columns (assume rectangular)
        ncols = len(matrix[0])
        idx = col if col >= 0 else ncols + col
        if idx < 0 or idx >= ncols:
            raise IndexError("col index out of range")
        # transpose
        transposed = [list(c) for c in zip(*matrix)]
        # remove the requested column
        new_transposed = [c for i, c in enumerate(transposed) if i != idx]
        if not new_transposed:
            # no columns left -> return rows of empty lists
            return [[] for _ in matrix]
        # transpose back
        return [list(r) for r in zip(*new_transposed)]
