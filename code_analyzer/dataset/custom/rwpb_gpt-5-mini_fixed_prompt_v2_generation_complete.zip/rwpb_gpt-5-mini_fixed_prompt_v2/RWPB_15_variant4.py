
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        a = np.asarray(a)
        b = np.asarray(b)
        a = a.ravel()
        if b.ndim == 1:
            if b.shape[0] != a.shape[0]:
                raise KeyError("length mismatch")
            norm_a = np.sqrt(np.dot(a, a))
            norm_b = np.sqrt(np.dot(b, b))
            if norm_a == 0 or norm_b == 0:
                return 1.0
            cos = np.dot(a, b) / (norm_a * norm_b)
            return float(1.0 - cos)
        elif b.ndim == 2:
            # use einsum for efficiency
            if b.shape[1] == a.shape[0]:
                dots = np.einsum('i,ji->j', a, b)
                norm_a = np.sqrt(np.einsum('i,i->', a, a))
                norm_bs = np.sqrt(np.einsum('ji,ji->j', b, b))
                sims = np.zeros_like(dots, dtype=float)
                denom = norm_a * norm_bs
                nz = denom != 0
                sims[nz] = dots[nz] / denom[nz]
                return 1.0 - sims
            elif b.shape[0] == a.shape[0]:
                dots = np.einsum('i,ij->j', a, b)
                norm_a = np.sqrt(np.einsum('i,i->', a, a))
                norm_bs = np.sqrt(np.einsum('ij,ij->j', b, b))
                sims = np.zeros_like(dots, dtype=float)
                denom = norm_a * norm_bs
                nz = denom != 0
                sims[nz] = dots[nz] / denom[nz]
                return 1.0 - sims
            else:
                raise KeyError("length mismatch")
        else:
            raise KeyError("b must be 1D or 2D")
