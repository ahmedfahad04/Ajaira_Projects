
def get_line_angle(x1, y1, x2, y2):
    import cmath
    import math
    def get_line_angle(x1, y1, x2, y2):
        dx = x2 - x1
        dy = y2 - y1
        if dx == 0 and dy == 0:
            return 0.0
        angle = math.degrees(cmath.phase(complex(dx, dy)))
        if angle < 0:
            angle += 360.0
        return angle
