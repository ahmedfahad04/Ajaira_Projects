
def movmean(arr, n_avg):
    import numpy as np
    from numpy.lib.stride_tricks import as_strided
    def movmean(arr, n_avg):
        a = np.asarray(arr).ravel().astype(float)
        if n_avg <= 0 or a.size == 0 or n_avg > a.size:
            return np.array([])
        m = a.size - n_avg + 1
        stride = a.strides[0]
        windows = as_strided(a, shape=(m, n_avg), strides=(stride, stride))
        return windows.mean(axis=1)
