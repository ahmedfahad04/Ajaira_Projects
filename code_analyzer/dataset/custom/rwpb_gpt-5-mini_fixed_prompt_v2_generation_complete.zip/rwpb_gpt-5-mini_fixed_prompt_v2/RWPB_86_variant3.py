
def inverse_sigmoid(x):
    import torch
    def inverse_sigmoid(x):
        x = torch.as_tensor(x)
        if not torch.is_floating_point(x):
            x = x.float()
        eps = torch.finfo(x.dtype).eps
        y = 2.0 * x - 1.0
        y = torch.clamp(y, min=-1 + eps, max=1 - eps)
        # logit(x) = 2 * atanh(2x-1); compute atanh via log for compatibility
        return 2.0 * (0.5 * torch.log((1.0 + y) / (1.0 - y)))
