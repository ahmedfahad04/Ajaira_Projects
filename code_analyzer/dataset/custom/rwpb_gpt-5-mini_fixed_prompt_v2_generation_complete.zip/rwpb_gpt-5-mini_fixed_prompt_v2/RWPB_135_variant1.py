
def mask_iou(mask1, mask2, eps=1e-7):
    import torch
    def mask_iou(mask1, mask2, eps=1e-7):
        mask1 = mask1.float()
        mask2 = mask2.float()
        if mask1.numel() == 0 or mask2.numel() == 0:
            return torch.zeros((mask1.shape[0], mask2.shape[0]), dtype=mask1.dtype, device=mask1.device)
        # intersection via matrix multiplication
        intersection = torch.mm(mask1, mask2.t())  # (N, M)
        area1 = mask1.sum(dim=1, keepdim=True)    # (N, 1)
        area2 = mask2.sum(dim=1, keepdim=True)    # (M, 1)
        union = area1 + area2.t() - intersection
        return intersection / (union.clamp(min=eps))
