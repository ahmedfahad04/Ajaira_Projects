
def view_range(x, i, j, shape):
    import torch
    import math
    def view_range(x, i, j, shape):
        ndim = x.dim()
        if j is None:
            j = ndim
        if i < 0:
            i = ndim + i
        if j < 0:
            j = ndim + j
        i = max(0, min(i, ndim))
        j = max(0, min(j, ndim))
        if i > j:
            raise ValueError("i must be <= j")
        # calculate products of the selected range
        mid_sizes = x.shape[i:j]
        mid_prod = 1
        for s in mid_sizes:
            mid_prod *= s
        # support -1 in target shape
        target = list(shape)
        if -1 in target:
            if target.count(-1) > 1:
                raise ValueError("Only one -1 allowed")
            known = 1
            for s in target:
                if s != -1:
                    known *= s
            if known == 0 or mid_prod % known != 0:
                raise ValueError("Cannot infer -1 dimension")
            for idx, s in enumerate(target):
                if s == -1:
                    target[idx] = mid_prod // known
                    break
        # validate product
        prod = 1
        for s in target:
            prod *= s
        if prod != mid_prod:
            raise ValueError("Target shape product must equal product of selected dims")
        # Iteratively expand the flattened middle axis into the new shape dimensions
        # Start by collapsing the middle to a single axis
        left = list(x.shape[:i])
        right = list(x.shape[j:])
        collapsed = x.reshape(*left, mid_prod, *right)
        # now expand the single axis into the requested multi-dimensions by successive reshapes
        current = collapsed
        # index where the single axis lives is i
        for dim in reversed(target):
            # current shape before: left + [accum] + right
            # We split accum into (dim, accum//dim)
            # Compute accum
            accum = 1
            for s in current.shape[i:i+1]:
                accum *= s
            # reshape to left + [dim, accum//dim] + right
            other = accum // dim
            new_shape = tuple(current.shape[:i]) + (dim, other) + tuple(current.shape[i+1:])
            current = current.reshape(new_shape)
        # after loop we have left + target + right
        return current
