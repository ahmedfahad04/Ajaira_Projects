
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        if not isinstance(image, np.ndarray):
            raise ValueError("Input must be a numpy array.")
        if image.ndim == 2:
            t = torch.from_numpy(image).unsqueeze(0).float() / 255.0
            return t
        elif image.ndim == 3:
            t = torch.from_numpy(image).float().permute(2, 0, 1) / 255.0
            return t
        else:
            raise ValueError("Input is not a valid image. Expected 2D (H,W) or 3D (H,W,C).")
