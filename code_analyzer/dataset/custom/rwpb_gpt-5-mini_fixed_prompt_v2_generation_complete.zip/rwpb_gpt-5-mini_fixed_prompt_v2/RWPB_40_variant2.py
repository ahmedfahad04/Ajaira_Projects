
def extract_code_from_funct(funct: Callable) -> List[str]:
    import inspect
    import ast
    import textwrap
    from typing import Callable, List
    def extract_code_from_funct(funct: Callable) -> List[str]:
        lines, _ = inspect.getsourcelines(funct)
        src = "".join(lines)
        # parse to get accurate lineno info relative to this snippet
        tree = ast.parse(src)
        func_node = None
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                func_node = node
                break
        if func_node is None or not func_node.body:
            return []
        # compute slice indices using lineno and end_lineno of body nodes
        first_body_lineno = func_node.body[0].lineno - 1  # zero-based
        last_end_lineno = max(getattr(n, "end_lineno", n.lineno) for n in func_node.body) - 1
        slice_lines = lines[first_body_lineno:last_end_lineno + 1]
        ded = textwrap.dedent("".join(slice_lines))
        out_lines = ded.splitlines()
        # remove leading/trailing empty lines
        while out_lines and out_lines[0].strip() == "":
            out_lines.pop(0)
        while out_lines and out_lines[-1].strip() == "":
            out_lines.pop()
        # remove trailing return statement
        if out_lines:
            if out_lines[-1].lstrip().startswith("return"):
                out_lines.pop()
                while out_lines and out_lines[-1].strip() == "":
                    out_lines.pop()
        return out_lines
