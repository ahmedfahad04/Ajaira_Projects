
def seconds_to_hh_mm_ss(seconds):
    def seconds_to_hh_mm_ss(seconds):
        try:
            total = int(seconds)
        except Exception:
            return "00:00:00"
        if total < 0:
            return "00:00:00"
        secs = total % 60
        total //= 60
        mins = total % 60
        hours = total // 60
        hh = str(hours)
        mm = str(mins).zfill(2)
        ss = str(secs).zfill(2)
        if len(hh) < 2:
            hh = hh.zfill(2)
        return hh + ":" + mm + ":" + ss
