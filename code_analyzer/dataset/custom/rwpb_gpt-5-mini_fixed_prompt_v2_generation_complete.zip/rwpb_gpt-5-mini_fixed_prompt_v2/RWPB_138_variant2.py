
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        nm = np.asarray(normal_map).astype(np.float64)
        if nm.ndim != 3 or nm.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        theta = np.deg2rad(angle)
        c = np.cos(theta)
        s = np.sin(theta)
        # Use tensordot for broadcasting multiplication
        R = np.array([[c, 0.0, s],
                      [0.0, 1.0, 0.0],
                      [-s, 0.0, c]], dtype=nm.dtype)
        rotated = np.tensordot(nm, R.T, axes=([2], [0]))
        # tensordot might return shape (H, W, 3); ensure ordering preserved
        # Normalize per-pixel
        norms = np.linalg.norm(rotated, axis=2, keepdims=True)
        eps = 1e-12
        rotated = rotated / np.maximum(norms, eps)
        return rotated.astype(normal_map.dtype if np.issubdtype(normal_map.dtype, np.floating) else rotated.dtype)
