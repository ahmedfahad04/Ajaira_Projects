
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        if divisor is None:
            raise ValueError("divisor must be provided")
        if torch.is_tensor(divisor):
            d_val = divisor.max().item()
        else:
            d_val = divisor
        if d_val == 0:
            raise ValueError("divisor must be non-zero")
        d = abs(int(d_val))
        # brute-force search around nearest quotient
        q = float(x) / d
        k0 = int(math.floor(q))
        best_k = k0
        best_diff = abs(x - k0 * d)
        # search a small window
        for k in range(k0 - 3, k0 + 4):
            val = k * d
            diff = abs(x - val)
            if diff < best_diff:
                best_diff = diff
                best_k = k
            # tie-break: prefer larger value
            elif diff == best_diff and val > best_k * d:
                best_k = k
        return int(best_k * d)
