
def format_seconds(seconds: float) -> str:
    def format_seconds(seconds: float) -> str:
        """Compute components from total milliseconds using divmod."""
        neg = seconds < 0
        total_ms = int(round(abs(seconds) * 1000))
        hours, rem = divmod(total_ms, 3_600_000)
        minutes, rem = divmod(rem, 60_000)
        secs, ms = divmod(rem, 1000)
        sign = "-" if neg else ""
        if hours:
            return "{}{:02d}:{:02d}:{:02d}.{:03d}".format(sign, hours, minutes, secs, ms)
        return "{}{:02d}:{:02d}.{:03d}".format(sign, minutes, secs, ms)
