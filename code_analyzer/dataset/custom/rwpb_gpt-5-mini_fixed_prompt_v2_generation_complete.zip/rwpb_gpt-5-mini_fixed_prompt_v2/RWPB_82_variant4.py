
def is_tensor(x):
    import importlib.util
    import numpy as np
    def is_tensor(x):
        if isinstance(x, np.ndarray):
            return True
        if importlib.util.find_spec("torch") is None:
            return False
        try:
            import torch
        except Exception:
            return False
        return isinstance(x, torch.Tensor)
