
def unsafeSub(x, y):
    WORD = 1 << 256
    MAX_VAL = WORD - 1
    def unsafeSub(x, y):
        # use divmod to obtain positive remainder in 0..2^256-1
        diff = (x & MAX_VAL) - (y & MAX_VAL)
        return divmod(diff, WORD)[1]
