
def check_all_columns_numeric(df):
    import pandas as pd
    import numpy as np
    def check_all_columns_numeric(df):
        if df is None:
            return False
        for dtype in getattr(df, "dtypes", []):
            try:
                kind = dtype.kind
            except Exception:
                return False
            if kind not in ('i', 'u', 'f', 'c'):  # int, unsigned int, float, complex
                return False
        return True
