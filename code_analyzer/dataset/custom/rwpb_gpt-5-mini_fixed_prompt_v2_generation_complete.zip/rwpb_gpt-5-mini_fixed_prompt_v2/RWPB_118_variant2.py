
def filter_nan(ts, vs):
    import numpy as np
    def filter_nan(ts, vs):
        ts = np.asarray(ts)
        vs = np.asarray(vs)
        bad = np.isnan(ts) | np.isnan(vs)
        if bad.size == 0:
            return ts, vs
        idx = np.where(~bad)[0]
        return ts[idx], vs[idx]
