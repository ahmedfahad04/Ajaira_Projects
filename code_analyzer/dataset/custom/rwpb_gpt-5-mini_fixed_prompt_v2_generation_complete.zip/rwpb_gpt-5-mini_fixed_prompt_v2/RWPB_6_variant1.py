
def format_seconds(seconds: float) -> str:
    def format_seconds(seconds: float) -> str:
        """Round to milliseconds using integer millisecond arithmetic."""
        # Handle sign
        sign = "-" if seconds < 0 else ""
        total_ms = int(round(abs(seconds) * 1000))
        hours = total_ms // 3_600_000
        rem = total_ms % 3_600_000
        minutes = rem // 60_000
        rem = rem % 60_000
        secs = rem // 1000
        ms = rem % 1000
        if hours >= 1:
            return f"{sign}{hours:02d}:{minutes:02d}:{secs:02d}.{ms:03d}"
        else:
            return f"{sign}{minutes:02d}:{secs:02d}.{ms:03d}"
