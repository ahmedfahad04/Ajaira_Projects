
def view_range(x, i, j, shape):
    import torch
    def view_range(x, i, j, shape):
        # handle j None and negatives
        ndim = x.dim()
        if j is None:
            j = ndim
        if i < 0:
            i = ndim + i
        if j < 0:
            j = ndim + j
        i = max(0, min(i, ndim))
        j = max(0, min(j, ndim))
        if i > j:
            raise ValueError("i must be <= j")
        left = tuple(x.shape[:i])
        right = tuple(x.shape[j:])
        # flatten the middle range into one dim, then reshape into the requested shape
        x_flat = x.flatten(start_dim=i, end_dim=j-1)
        # support inferred -1 in shape
        shape = list(shape)
        if any(s == -1 for s in shape):
            mid_prod = 1
            for d in x.shape[i:j]:
                mid_prod *= d
            known = 1
            for s in shape:
                if s != -1:
                    known *= s
            if known == 0:
                raise ValueError("Cannot infer -1 with zero known product")
            if mid_prod % known != 0:
                raise ValueError("Cannot infer shape dimension; not divisible")
            for idx, s in enumerate(shape):
                if s == -1:
                    shape[idx] = mid_prod // known
                    break
        return x_flat.reshape(*left, *shape, *right)
