
def compute_tri_normal(geometry, tris):
    import torch
    def compute_tri_normal(geometry, tris):
        """
        Loop over batches (good when batch size is small or when clarity is preferred).
        Produces unit normals.
        """
        B = geometry.shape[0]
        if tris.numel() == 0:
            return geometry.new_empty((B, 0, 3))
        tris = tris.long().to(geometry.device)
        outs = []
        for b in range(B):
            pts = geometry[b]  # (N,3)
            v0 = pts[tris[:, 0]]
            v1 = pts[tris[:, 1]]
            v2 = pts[tris[:, 2]]
            n = torch.cross(v1 - v0, v2 - v0, dim=1)  # (T,3)
            n = n / (n.norm(dim=1, keepdim=True) + 1e-9)
            outs.append(n)
        return torch.stack(outs, dim=0)
