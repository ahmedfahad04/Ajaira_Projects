
def rotate_about_x_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        """
        Rotate by embedding into homogeneous coordinates and using a 4x4 rotation matrix.
        """
        v = np.asarray(vector, dtype=float)
        if v.size != 3:
            raise ValueError("vector must have exactly 3 elements")
        v = v.reshape(3,)
        c = math.cos(theta)
        s = math.sin(theta)
        R4 = np.array([
            [1.0, 0.0, 0.0, 0.0],
            [0.0,   c,  -s, 0.0],
            [0.0,   s,   c, 0.0],
            [0.0, 0.0, 0.0, 1.0]
        ], dtype=float)
        vh = np.array([v[0], v[1], v[2], 1.0], dtype=float)
        result_h = R4.dot(vh)
        return result_h[:3]
