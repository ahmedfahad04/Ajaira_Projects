
def dynamic_import_function(function_path):
    from importlib import import_module
    def dynamic_import_function(function_path):
        """
        Robust approach: try different splits to locate the module portion.
        For parts = [p0, p1, ..., pn], try module = p0..pi and attributes = p(i+1)..pn
        """
        if not isinstance(function_path, str):
            return ModuleNotFoundError
        parts = function_path.split('.')
        if len(parts) < 2:
            return ModuleNotFoundError
        # Try longest possible module path first (all but last), then shorten
        for i in range(len(parts)-1, 0, -1):
            module_name = '.'.join(parts[:i])
            attr_parts = parts[i:]
            try:
                module = import_module(module_name)
            except ModuleNotFoundError:
                continue
            except Exception:
                continue
            # traverse attribute chain
            obj = module
            ok = True
            for a in attr_parts:
                try:
                    obj = getattr(obj, a)
                except Exception:
                    ok = False
                    break
            if ok:
                return obj
        return ModuleNotFoundError
