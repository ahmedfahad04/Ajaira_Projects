
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        if not torch.is_tensor(preds):
            preds = torch.tensor(preds)
        if not torch.is_tensor(labels):
            labels = torch.tensor(labels)
        p = preds.clone()
        l = labels.clone()
        if p.dtype.is_floating_point:
            p = p > 0.5
        else:
            p = p != 0
        l_fg = l == 1
        if p.dim() == l_fg.dim() + 1 and p.size(1) == 1:
            p = p.squeeze(1)
        if l_fg.dim() + 1 == p.dim() and p.size(0) == 1:
            p = p.squeeze(0)
        if l.dim() == p.dim() and p.dim() == 2:
            p = p.unsqueeze(0)
            l_fg = l_fg.unsqueeze(0)
        if ignore is not None:
            mask = (labels != ignore)
            if mask.dim() == 2:
                mask = mask.unsqueeze(0)
            mask = mask.expand_as(p)
        else:
            mask = torch.ones_like(p, dtype=torch.bool)
        if per_image:
            ious = []
            for i in range(p.size(0)):
                pm = p[i] & mask[i]
                lm = l_fg[i] & mask[i]
                inter = (pm & lm).sum().float()
                union = (pm | lm).sum().float()
                if union.item() == 0:
                    ious.append(float(EMPTY))
                else:
                    ious.append((inter / union).item())
            return float((sum(ious) / len(ious)) * 100.0)
        else:
            pm = p & mask
            lm = l_fg & mask
            inter = (pm & lm).sum().float()
            union = (pm | lm).sum().float()
            if union.item() == 0:
                return float(EMPTY * 100.0)
            return float((inter / union).item() * 100.0)
