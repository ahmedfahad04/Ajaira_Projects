
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.array(a, dtype=float)
        b = np.array(b, dtype=float)
        la = np.linalg.norm(a)
        lb = np.linalg.norm(b)
        if la == 0 or lb == 0:
            return (None, None)
        ua = a / la
        ub = b / lb
        dot = np.dot(ua, ub)
        dot = max(-1.0, min(1.0, dot))
        eps = 1e-9
        if dot > 1 - eps:
            return (None, None)
        if dot < -1 + eps:
            # choose an orthogonal axis by picking the smallest component index
            idx = int(np.argmin(np.abs(ua)))
            e = np.zeros(3)
            e[idx] = 1.0
            axis = np.cross(ua, e)
            axis = axis / np.linalg.norm(axis)
            return (axis, float(np.pi))
        cross = np.cross(ua, ub)
        axis = cross / np.linalg.norm(cross)
        angle = float(np.arccos(dot))
        return (axis, angle)
