
def rotate_y(a, device=None):
    import torch
    import numpy as np
    def rotate_y(a, device=None):
        if torch.is_tensor(a):
            a_val = float(a.cpu().numpy())
        else:
            a_val = float(a)
        c = np.cos(a_val)
        s = np.sin(a_val)
        mat_list = [
            [c, 0.0, s, 0.0],
            [0.0, 1.0, 0.0, 0.0],
            [-s, 0.0, c, 0.0],
            [0.0, 0.0, 0.0, 1.0],
        ]
        t = torch.tensor(mat_list, dtype=torch.float32)
        if device is not None:
            t = t.to(device)
        return t
