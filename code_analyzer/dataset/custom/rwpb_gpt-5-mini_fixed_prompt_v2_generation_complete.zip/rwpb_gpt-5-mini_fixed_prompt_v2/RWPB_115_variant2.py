
def compute_tri_normal(geometry, tris):
    import torch
    def compute_tri_normal(geometry, tris):
        """
        Gather-based batched indexing. Returns unit normals.
        """
        B = geometry.shape[0]
        if tris.numel() == 0:
            return geometry.new_empty((B, 0, 3))
        tris = tris.long().to(geometry.device)
        T = tris.shape[0]
        # prepare gather indices of shape (B, T, 3) for each vertex column
        i0 = tris[:, 0].unsqueeze(0).unsqueeze(-1).expand(B, T, 3)
        i1 = tris[:, 1].unsqueeze(0).unsqueeze(-1).expand(B, T, 3)
        i2 = tris[:, 2].unsqueeze(0).unsqueeze(-1).expand(B, T, 3)
        v0 = geometry.gather(1, i0)
        v1 = geometry.gather(1, i1)
        v2 = geometry.gather(1, i2)
        e1 = v1 - v0
        e2 = v2 - v0
        normals = torch.cross(e1, e2, dim=2)
        denom = normals.norm(dim=2, keepdim=True)
        normals = normals / (denom + 1e-9)
        return normals
