
def xywh2xyxy(x):
    import numpy as np
    import torch
    def xywh2xyxy(x):
        if isinstance(x, torch.Tensor):
            if x.dim() == 0:
                return x
            s = x.shape
            assert s[-1] == 4, "last dimension must be 4"
            flat = x.reshape(-1, 4)
            x0 = flat[:, 0]
            y0 = flat[:, 1]
            w = flat[:, 2]
            h = flat[:, 3]
            out_flat = torch.stack((x0, y0, x0 + w, y0 + h), dim=1)
            return out_flat.reshape(s)
        else:
            arr = np.asarray(x)
            if arr.size == 0:
                return arr.copy()
            shape = arr.shape
            assert shape[-1] == 4, "last dimension must be 4"
            flat = arr.reshape(-1, 4)
            x0 = flat[:, 0]
            y0 = flat[:, 1]
            w = flat[:, 2]
            h = flat[:, 3]
            out_flat = np.stack((x0, y0, x0 + w, y0 + h), axis=1)
            return out_flat.reshape(shape)
