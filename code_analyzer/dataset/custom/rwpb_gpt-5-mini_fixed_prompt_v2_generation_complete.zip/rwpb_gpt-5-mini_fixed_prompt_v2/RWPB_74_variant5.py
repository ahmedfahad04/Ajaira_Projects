
def arccos2(vector, value):
    import math
    def arccos2(vector, value):
        x = float(vector[0])
        y = float(vector[1])
        v = float(value)
        if v != v:
            return float('nan')
        v = max(-1.0, min(1.0, v))
        ang_from_vec = math.atan2(y, x)
        cos_from_vec = math.cos(ang_from_vec)
        if abs(cos_from_vec - v) <= 1e-6:
            angle = ang_from_vec
        else:
            angle = math.acos(v)
            if y < 0.0:
                angle = 2.0 * math.pi - angle
        if angle < 0.0:
            angle += 2.0 * math.pi
        return angle
