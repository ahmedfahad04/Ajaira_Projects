
def view_range(x, i, j, shape):
    import torch
    from functools import reduce
    import operator
    def view_range(x, i, j, shape):
        ndim = x.dim()
        # normalize indices
        if j is None:
            j = ndim
        if i < 0:
            i = ndim + i
        if j < 0:
            j = ndim + j
        i = max(0, min(i, ndim))
        j = max(0, min(j, ndim))
        if i > j:
            raise ValueError("i must be <= j")
        left_sizes = list(x.shape[:i])
        mid_sizes = list(x.shape[i:j])
        right_sizes = list(x.shape[j:])
        mid_prod = 1
        for s in mid_sizes:
            mid_prod *= s
        # Convert shape and handle -1
        shape = list(shape)
        if any(s == -1 for s in shape):
            known = 1
            minus_count = 0
            for s in shape:
                if s == -1:
                    minus_count += 1
                else:
                    known *= s
            if minus_count != 1:
                raise ValueError("Only a single -1 is allowed in shape")
            if mid_prod % known != 0:
                raise ValueError("Cannot infer -1 dimension")
            for idx, s in enumerate(shape):
                if s == -1:
                    shape[idx] = mid_prod // known
                    break
        # validate product
        shape_prod = 1
        for s in shape:
            shape_prod *= s
        if shape_prod != mid_prod:
            raise ValueError("Requested shape does not match the product of the selected dimensions")
        # do two-step reshape: first collapse mid dims, then expand
        collapsed = x.reshape(*left_sizes, mid_prod, *right_sizes)
        return collapsed.reshape(*left_sizes, *shape, *right_sizes)
