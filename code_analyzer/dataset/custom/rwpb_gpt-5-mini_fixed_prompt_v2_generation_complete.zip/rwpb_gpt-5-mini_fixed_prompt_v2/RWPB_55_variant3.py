
def numpy_to_pytorch(x):
    import numpy as np
    import torch
    def numpy_to_pytorch(x):
        # Robust handling of shapes: if single image HxW or HxWxC, convert to batch
        arr = np.asarray(x)
        # Ensure float32 and normalize
        arr = arr.astype(np.float32, copy=False) / 255.0
        # If 2D (H,W) -> add channel dim then batch: (1,1,H,W)
        if arr.ndim == 2:
            arr = arr[np.newaxis, np.newaxis, ...]
        # If 3D and likely HWC (H,W,C) convert to CHW then add batch -> (1,C,H,W)
        elif arr.ndim == 3:
            # Heuristic: if last dim is small (1 or 3) treat as channels
            if arr.shape[-1] in (1, 3):
                arr = np.moveaxis(arr, -1, 0)  # C,H,W
            else:
                # treat as already channel-first
                pass
            arr = np.expand_dims(arr, 0)
        else:
            # For 1D or 4D+, just ensure batch dim exists
            arr = np.expand_dims(arr, 0)
        arr = np.ascontiguousarray(arr)
        return torch.from_numpy(arr).float()
