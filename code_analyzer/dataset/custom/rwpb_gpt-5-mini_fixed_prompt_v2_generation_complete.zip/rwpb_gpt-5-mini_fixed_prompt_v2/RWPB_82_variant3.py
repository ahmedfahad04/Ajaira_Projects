
def is_tensor(x):
    import importlib.util
    import numpy as np
    import sys
    def is_tensor(x):
        if importlib.util.find_spec("torch") is not None:
            if "torch" in sys.modules:
                torch = sys.modules["torch"]
            else:
                torch = __import__("torch")
            if isinstance(x, getattr(torch, "Tensor", type(None))):
                return True
        return isinstance(x, np.ndarray)
