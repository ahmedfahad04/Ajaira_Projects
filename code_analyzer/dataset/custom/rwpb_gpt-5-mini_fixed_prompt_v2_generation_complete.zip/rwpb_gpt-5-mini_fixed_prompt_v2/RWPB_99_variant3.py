
def focal2fov(focal, pixels):
    import math
    def focal2fov(focal, pixels):
        if focal == 0:
            return KeyError
        # use atan2 for numerical stability: atan2(y, x) where y = pixels, x = 2*focal
        return 2.0 * math.atan2(float(pixels), 2.0 * float(focal))
