
def path_spliter(path: str):
    from pathlib import Path
    def path_spliter(path: str):
        if not path:
            return []
        # pathlib.Path.parts gives a reliable decomposition of the path
        try:
            parts = list(Path(path).parts)
        except Exception:
            # fallback in unlikely error cases
            if path == '':
                return []
            return [path]
        return parts
