
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        if preds is None or references is None:
            raise ValueError("preds and references must be provided")
        if len(preds) != len(references):
            raise ValueError("preds and references must have the same length")
        n = len(preds)
        if n < 2:
            return 0.0
        def sgn(x):
            if x > 0:
                return 1
            if x < 0:
                return -1
            return 0
        correct = 0
        total = 0
        for i in range(n):
            for j in range(i+1, n):
                sp = sgn(preds[i] - preds[j])
                sr = sgn(references[i] - references[j])
                if sp == sr:
                    correct += 1
                total += 1
        return correct / total if total > 0 else 0.0
