
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return None
        ow, oh = original_size
        # Euclidean distance in (width, height) space
        def dist(r):
            rw, rh = r
            return ((rw - ow) ** 2 + (rh - oh) ** 2) ** 0.5
        return min(possible_resolutions, key=dist)
