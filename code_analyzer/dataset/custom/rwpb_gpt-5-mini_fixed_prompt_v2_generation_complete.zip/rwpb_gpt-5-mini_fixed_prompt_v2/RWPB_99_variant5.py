
def focal2fov(focal, pixels):
    import math
    def focal2fov(focal, pixels):
        # handle trivial case
        if focal == 0:
            return KeyError
        # if there are no pixels, fov is zero
        if pixels == 0:
            return 0.0
        # compute using standard formula
        return 2 * math.atan(float(pixels) / (2 * float(focal)))
