
def mean(l, ignore_nan=False, empty=0):
    import math
    from decimal import Decimal, InvalidOperation
    def mean(l, ignore_nan=False, empty=0):
        total = Decimal(0)
        count = 0
        def isnan_safe(x):
            try:
                return math.isnan(x)
            except Exception:
                return False
        for x in l:
            if isnan_safe(x):
                if ignore_nan:
                    continue
                else:
                    return float('nan')
            # Use Decimal for accumulation for a different numeric approach
            try:
                total += Decimal(x)
            except (InvalidOperation, TypeError):
                # Fallback to float addition if Decimal conversion fails
                total = Decimal(float(total)) + Decimal(float(x))
            count += 1
        if count == 0:
            if empty == 'raise':
                raise ValueError("mean of empty sequence")
            return empty
        # Convert back to float
        return float(total / count)
