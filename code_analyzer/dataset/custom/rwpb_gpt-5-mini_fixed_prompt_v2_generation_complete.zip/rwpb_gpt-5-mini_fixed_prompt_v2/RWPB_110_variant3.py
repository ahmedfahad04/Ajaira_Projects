
def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
    import numpy as np
    def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
        n = np.asarray(plane_normal, dtype=float)
        p = np.asarray(plane_point, dtype=float)
        d = np.asarray(ray_direction, dtype=float)
        r = np.asarray(ray_point, dtype=float)
        n_norm = np.linalg.norm(n)
        if n_norm == 0:
            return None
        denom = np.dot(n, d)
        tol = 1e-9
        if abs(denom) < tol:
            if abs(np.dot(n, r - p)) < tol:
                return r.copy()
            return None
        t = np.dot(n, p - r) / denom
        intersection = r + d * t
        return intersection
