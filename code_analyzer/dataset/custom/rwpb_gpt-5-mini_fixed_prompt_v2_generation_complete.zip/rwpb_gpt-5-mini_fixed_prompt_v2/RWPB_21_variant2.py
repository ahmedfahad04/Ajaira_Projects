
def validate_user_id(user_id):
    import re
    _pattern = re.compile(r'^[A-Za-z][A-Za-z0-9_]*$')
    def validate_user_id(user_id):
        if not isinstance(user_id, str):
            return False
        return bool(_pattern.match(user_id))
