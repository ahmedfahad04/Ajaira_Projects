
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        nm = np.array(normal_map, dtype=np.float32, copy=True)
        if nm.ndim != 3 or nm.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        theta = np.deg2rad(angle)
        c = float(np.cos(theta))
        s = float(np.sin(theta))
        H, W, _ = nm.shape
        out = np.empty_like(nm)
        eps = 1e-8
        for i in range(H):
            for j in range(W):
                x, y, z = nm[i, j]
                xr = c * x + s * z
                yr = y
                zr = -s * x + c * z
                nrm = np.sqrt(xr * xr + yr * yr + zr * zr)
                if nrm > eps:
                    out[i, j, 0] = xr / nrm
                    out[i, j, 1] = yr / nrm
                    out[i, j, 2] = zr / nrm
                else:
                    # preserve original if zero-length
                    out[i, j] = nm[i, j]
        return out
