
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.array(a, dtype=float)
        b = np.array(b, dtype=float)
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na == 0 or nb == 0:
            return (None, None)
        ua = a / na
        ub = b / nb
        if np.allclose(ua, ub):
            return (None, None)
        dot = np.clip(np.dot(ua, ub), -1.0, 1.0)
        # Quaternion-based construction
        if dot < -0.999999:
            # opposite
            abs_ua = np.abs(ua)
            idx = int(np.argmin(abs_ua))
            tmp = np.zeros(3)
            tmp[idx] = 1.0
            axis = np.cross(ua, tmp)
            axis /= np.linalg.norm(axis)
            return (axis, np.pi)
        # compute quaternion components
        s = np.sqrt((1.0 + dot) * 0.5)
        v = np.cross(ua, ub)
        v = v / (2.0 * s)
        # quaternion q = [s, v]
        angle = 2.0 * np.arccos(np.clip(s, -1.0, 1.0))
        if np.linalg.norm(v) == 0:
            return (None, None)
        axis = v / np.linalg.norm(v)
        return (axis, float(angle))
