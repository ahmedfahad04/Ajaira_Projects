
def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        """
        Projects 3D coordinates onto a batch of 2D planes using tensor einsum.
        """
        n_planes = planes.shape[0]
        N, M, _ = coordinates.shape
        axes = planes[..., :2]  # (n_planes, 3, 2) : first two columns are plane axes
        proj = torch.einsum('nka,ijk->inja', axes, coordinates)  # (N, n_planes, M, 2)
        return proj.reshape(N * n_planes, M, 2)
