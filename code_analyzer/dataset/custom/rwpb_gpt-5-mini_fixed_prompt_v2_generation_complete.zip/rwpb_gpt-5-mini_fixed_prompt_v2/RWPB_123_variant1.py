
def fuse_deconv_and_bn(deconv, bn):
    import torch
    import torch.nn as nn
    def fuse_deconv_and_bn(deconv, bn):
        if not isinstance(deconv, nn.ConvTranspose2d) or not isinstance(bn, nn.BatchNorm2d):
            raise TypeError("Expected ConvTranspose2d and BatchNorm2d")
        # parameters
        device = deconv.weight.device
        dtype = deconv.weight.dtype
        out_channels = deconv.out_channels
        in_channels = deconv.in_channels
        groups = deconv.groups
        # get bn params
        if bn.affine:
            gamma = bn.weight.detach().to(device=device, dtype=dtype)
            beta = bn.bias.detach().to(device=device, dtype=dtype)
        else:
            gamma = torch.ones(out_channels, device=device, dtype=dtype)
            beta = torch.zeros(out_channels, device=device, dtype=dtype)
        running_mean = bn.running_mean.detach().to(device=device, dtype=dtype)
        running_var = bn.running_var.detach().to(device=device, dtype=dtype)
        eps = bn.eps
        # compute scale
        scale = gamma / torch.sqrt(running_var + eps)
        # prepare new conv transpose
        fused = nn.ConvTranspose2d(
            in_channels=deconv.in_channels,
            out_channels=deconv.out_channels,
            kernel_size=deconv.kernel_size,
            stride=deconv.stride,
            padding=deconv.padding,
            output_padding=deconv.output_padding,
            groups=deconv.groups,
            dilation=deconv.dilation,
            bias=True
        )
        fused = fused.to(device=device, dtype=dtype)
        # bias
        old_bias = deconv.bias.detach() if deconv.bias is not None else torch.zeros(out_channels, device=device, dtype=dtype)
        new_bias = beta + scale * (old_bias - running_mean)
        # weights: weight shape (in_channels, out_channels//groups, kh, kw)
        w = deconv.weight.detach().clone()
        in_per_group = in_channels // groups
        out_per_group = out_channels // groups
        # Multiply slices corresponding to each output channel
        for o in range(out_channels):
            g = o // out_per_group
            local_o = o - g * out_per_group
            i_start = g * in_per_group
            i_end = (g + 1) * in_per_group
            w[i_start:i_end, local_o, :, :] *= scale[o]
        fused.weight.data.copy_(w)
        fused.bias.data.copy_(new_bias)
        return fused
