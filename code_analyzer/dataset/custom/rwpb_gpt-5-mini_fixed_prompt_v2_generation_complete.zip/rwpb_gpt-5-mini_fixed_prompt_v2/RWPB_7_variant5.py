
def dynamic_import_function(function_path):
    from importlib import import_module
    def dynamic_import_function(function_path):
        """
        Iterative attribute resolution: import module progressively and attempt to resolve
        attributes even if some middle part is a class or object rather than a module.
        """
        if not isinstance(function_path, str):
            return ModuleNotFoundError
        parts = function_path.split('.')
        if len(parts) < 2:
            return ModuleNotFoundError
        # progressively import increasing module prefix until failure, then resolve remaining attrs
        # Start with the shortest module prefix (first part) and extend
        imported = None
        last_success_idx = 0
        for i in range(1, len(parts)):
            prefix = '.'.join(parts[:i+1])
            try:
                imported = import_module(prefix)
                last_success_idx = i
            except ModuleNotFoundError:
                break
            except Exception:
                break
        # If we imported something, try to resolve the rest as attributes
        if imported is None:
            # fallback: try the module formed by all but last
            try:
                imported = import_module('.'.join(parts[:-1]))
                last_success_idx = len(parts)-2
            except Exception:
                return ModuleNotFoundError
        obj = imported
        # attributes to resolve are parts[last_success_idx+1:]
        for a in parts[last_success_idx+1:]:
            try:
                obj = getattr(obj, a)
            except Exception:
                return ModuleNotFoundError
        return obj
