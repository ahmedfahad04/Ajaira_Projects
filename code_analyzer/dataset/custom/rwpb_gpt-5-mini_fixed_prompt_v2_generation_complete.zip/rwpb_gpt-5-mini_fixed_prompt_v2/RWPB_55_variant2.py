
def numpy_to_pytorch(x):
    import numpy as np
    import torch
    def numpy_to_pytorch(x):
        # Convert input to numpy array (no copy if possible)
        arr = np.asarray(x)
        # Cast to float32, normalize
        arr = arr.astype(np.float32, copy=False) / 255.0
        # Prepend batch dim
        if arr.ndim == 0:
            arr = arr.reshape((1, 1))
        arr = np.expand_dims(arr, 0)
        # Make contiguous and create tensor via as_tensor
        arr = np.ascontiguousarray(arr)
        return torch.as_tensor(arr, dtype=torch.float32)
