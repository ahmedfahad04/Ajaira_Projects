
def inverse_sigmoid(x):
    import torch
    def inverse_sigmoid(x):
        x = torch.as_tensor(x)
        if not torch.is_floating_point(x):
            x = x.double()
        dtype = x.dtype
        eps = torch.tensor(torch.finfo(dtype).eps, dtype=dtype, device=x.device)
        xp = torch.clamp(x, eps, 1 - eps)
        # use numerically stable log1p for 1 - x
        return torch.log(xp) - torch.log1p(-xp)
