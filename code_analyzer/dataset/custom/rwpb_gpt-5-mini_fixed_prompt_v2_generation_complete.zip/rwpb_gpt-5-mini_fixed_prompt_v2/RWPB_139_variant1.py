
def rotate_normalmap_by_angle_torch(normal_map, angle):
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        import torch
        device = normal_map.device
        dtype = normal_map.dtype
        theta = angle * 3.141592653589793 / 180.0
        cos = float(torch.cos(torch.tensor(theta)))
        sin = float(torch.sin(torch.tensor(theta)))
        x = normal_map[..., 0]
        y = normal_map[..., 1]
        z = normal_map[..., 2]
        x_r = cos * x + sin * z
        z_r = -sin * x + cos * z
        out = torch.stack((x_r, y, z_r), dim=-1)
        norm = torch.sqrt((out * out).sum(dim=-1, keepdim=True))
        eps = torch.tensor(1e-8, device=device, dtype=dtype)
        out = out / (norm + eps)
        return out
