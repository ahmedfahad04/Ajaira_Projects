
def numpy_to_pytorch(x):
    import numpy as np
    import torch
    def numpy_to_pytorch(x):
        # Use np.require to ensure C-contiguous and dtype
        arr = np.require(np.asarray(x), dtype=np.float32, requirements=['C'])
        # Normalize in-place if possible
        arr = arr / 255.0
        # Prepend batch dimension
        arr = arr.reshape((1,) + arr.shape)
        # Guarantee contiguous layout (np.require already ensures C, but be safe)
        arr = np.ascontiguousarray(arr, dtype=np.float32)
        # Use torch.from_numpy for zero-copy conversion
        t = torch.from_numpy(arr)
        return t.to(torch.float32)
