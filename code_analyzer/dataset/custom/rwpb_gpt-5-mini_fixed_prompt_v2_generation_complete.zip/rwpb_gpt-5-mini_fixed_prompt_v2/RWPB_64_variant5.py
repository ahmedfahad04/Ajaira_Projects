
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        arr = np.asarray(arr, dtype=float)
        if window_size <= 0 or int(window_size) != window_size:
            raise ValueError("window_size must be a positive integer")
        w = int(window_size)
        n = arr.size
        if n == 0:
            return [np.array([]), np.array([])]
        csum = np.cumsum(arr, dtype=float)
        ma = np.empty(n, dtype=float)
        for i in range(n):
            if i + 1 < w:
                ma[i] = csum[i] / float(i + 1)
            else:
                ma[i] = (csum[i] - (csum[i - w] if i - w >= 0 else 0.0)) / float(w)
        residuals = arr - ma
        return [ma, residuals]
