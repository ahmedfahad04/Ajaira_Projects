
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        nm = np.asarray(normal_map, dtype=np.float64)
        if nm.ndim != 3 or nm.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        theta = np.deg2rad(angle)
        half = theta / 2.0
        qw = np.cos(half)
        qy = np.sin(half)  # quaternion for axis (0,1,0): q = [qw, 0, qy, 0]
        # Vector part of quaternion
        qv = np.array([0.0, qy, 0.0], dtype=np.float64)
        v = nm.reshape(-1, 3)
        # cross products vectorized
        cross1 = np.cross(qv, v)
        term = cross1 + qw * v
        cross2 = np.cross(qv, term)
        rotated = v + 2.0 * cross2
        # normalize
        norms = np.linalg.norm(rotated, axis=1, keepdims=True)
        eps = 1e-12
        rotated = rotated / np.maximum(norms, eps)
        return rotated.reshape(nm.shape).astype(normal_map.dtype if np.issubdtype(normal_map.dtype, np.floating) else rotated.dtype)
