
def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
    import numpy as np
    def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
        target = context_window + 1
        tokens = np.asarray(tokens)
        if tokens.ndim == 0:
            out = np.full(target, pad_token, dtype=tokens.dtype)
            return out
        if tokens.ndim == 1:
            out = np.full(target, pad_token, dtype=tokens.dtype)
            n = min(tokens.shape[0], target)
            if n > 0:
                out[:n] = tokens[:n]
            return out
        # ndim >= 2: treat first dim as batch, last dim as sequence
        batch = tokens.shape[0]
        out = np.full((batch, target), pad_token, dtype=tokens.dtype)
        if tokens.shape[1] > 0:
            n = min(tokens.shape[1], target)
            out[:, :n] = tokens[:, :n]
        return out
