
def extract_code_from_funct(funct: Callable) -> List[str]:
    import inspect
    import io
    import tokenize
    import textwrap
    from typing import Callable, List
    def extract_code_from_funct(funct: Callable) -> List[str]:
        src = inspect.getsource(funct)
        src_lines = src.splitlines(keepends=True)
        # tokenize to find the INDENT that follows the function signature
        tokens = tokenize.generate_tokens(io.StringIO(src).readline)
        collecting = False
        indent_depth = 0
        body_start_line = None
        body_end_line = None
        for tok_type, tok_string, start, end, _ in tokens:
            if not collecting:
                # look for the INDENT that begins the function body
                if tok_type == tokenize.INDENT:
                    # the first INDENT after a def will be the function body indent
                    collecting = True
                    indent_depth = 1
                    body_start_line = start[0]
            else:
                if tok_type == tokenize.INDENT:
                    indent_depth += 1
                elif tok_type == tokenize.DEDENT:
                    indent_depth -= 1
                    if indent_depth == 0:
                        # DEDENT that closes the function body; end just before this token
                        body_end_line = start[0] - 1
                        break
        # If we never saw a DEDENT to close, assume rest of snippet is body
        if collecting and body_start_line is not None and body_end_line is None:
            body_end_line = len(src_lines)
        if not collecting or body_start_line is None:
            return []
        # slice lines (1-based to 0-based)
        body_chunk = "".join(src_lines[body_start_line - 1:body_end_line])
        ded = textwrap.dedent(body_chunk)
        out_lines = ded.splitlines()
        # trim empty lines
        while out_lines and out_lines[0].strip() == "":
            out_lines.pop(0)
        while out_lines and out_lines[-1].strip() == "":
            out_lines.pop()
        if out_lines and out_lines[-1].lstrip().startswith("return"):
            out_lines.pop()
            while out_lines and out_lines[-1].strip() == "":
                out_lines.pop()
        return out_lines
