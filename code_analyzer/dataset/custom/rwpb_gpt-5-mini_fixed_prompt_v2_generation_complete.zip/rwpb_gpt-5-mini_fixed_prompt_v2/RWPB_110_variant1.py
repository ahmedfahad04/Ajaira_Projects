
def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
    import numpy as np
    def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
        plane_normal = np.asarray(plane_normal, dtype=float)
        plane_point = np.asarray(plane_point, dtype=float)
        ray_direction = np.asarray(ray_direction, dtype=float)
        ray_point = np.asarray(ray_point, dtype=float)
        denom = np.dot(plane_normal, ray_direction)
        num = np.dot(plane_normal, plane_point - ray_point)
        eps = 1e-12
        if abs(denom) < eps:
            if abs(num) < eps:
                return ray_point.copy()
            else:
                return None
        t = num / denom
        return ray_point + t * ray_direction
