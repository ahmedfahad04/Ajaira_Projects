
def crop_mask(masks, boxes):
    import torch
    import torch.nn.functional as F
    def crop_mask(masks, boxes):
        """
        Use grid_sample to zero-out coordinates outside boxes by mapping them out-of-range.
        Keeps values inside boxes intact.
        """
        if masks.ndim != 3:
            raise ValueError("masks must be [n, h, w]")
        n, H, W = masks.shape
        if boxes.shape[0] != n or boxes.shape[1] != 4:
            raise ValueError("boxes must be [n, 4]")
        device = masks.device
        # base normalized grid for all pixel centers
        xs = torch.linspace(-1.0, 1.0, W, device=device)
        ys = torch.linspace(-1.0, 1.0, H, device=device)
        gy, gx = torch.meshgrid(ys, xs, indexing='ij')  # [H, W]
        base_grid = torch.stack((gx, gy), dim=-1)  # [H, W, 2]
        base_grid = base_grid.unsqueeze(0).expand(n, H, W, 2).clone()  # [n, H, W, 2]
        # Compute pixel coords bounds and create inside mask
        x1 = torch.floor(boxes[:, 0]).to(device)
        y1 = torch.floor(boxes[:, 1]).to(device)
        x2 = torch.ceil(boxes[:, 2]).to(device)
        y2 = torch.ceil(boxes[:, 3]).to(device)
        x1 = x1.clamp(0, W-1)
        y1 = y1.clamp(0, H-1)
        x2 = x2.clamp(0, W-1)
        y2 = y2.clamp(0, H-1)
        # Pixel coordinate grid
        ys_pix = torch.arange(H, device=device).view(1, H, 1).expand(n, H, W)
        xs_pix = torch.arange(W, device=device).view(1, 1, W).expand(n, H, W)
        inside = (xs_pix >= x1.view(n,1,1)) & (xs_pix <= x2.view(n,1,1)) & (ys_pix >= y1.view(n,1,1)) & (ys_pix <= y2.view(n,1,1))
        # Set out-of-box grid coords to an out-of-range value (e.g., 2.0) so grid_sample yields 0
        out_grid = base_grid.clone()
        mask_expand = inside.unsqueeze(-1).expand(n, H, W, 2)
        out_grid[~mask_expand] = 2.0  # out of [-1,1] range
        inp = masks.unsqueeze(1)  # [n,1,H,W]
        sampled = F.grid_sample(inp, out_grid, mode='bilinear', padding_mode='zeros', align_corners=True)
        # sampled keeps values inside boxes and zeros outside (bilinear may slightly blur edges, but retains content)
        # If we want hard crop without interpolation, round sampled values by threshold when masks are binary; here return sampled squeezed
        return sampled.squeeze(1)
