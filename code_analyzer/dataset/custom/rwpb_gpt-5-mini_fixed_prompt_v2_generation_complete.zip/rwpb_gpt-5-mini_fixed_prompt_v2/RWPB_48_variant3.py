
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return None
        ow, oh = original_size
        if ow == 0 or oh == 0:
            # fallback to smallest difference in width+height
            return min(possible_resolutions, key=lambda r: abs(r[0]-ow)+abs(r[1]-oh))
        # Choose resolution whose scale (avg of width and height scale) is closest to 1
        def avg_scale_dist(r):
            rw, rh = r
            sx = rw / ow
            sy = rh / oh
            avg = (sx + sy) / 2.0
            return abs(avg - 1.0)
        # tie-breaker: choose closer aspect ratio
        def aspect_diff(r):
            rw, rh = r
            ar_orig = ow / oh if oh != 0 else float('inf')
            ar_r = rw / rh if rh != 0 else float('inf')
            return abs(ar_orig - ar_r)
        best = min(possible_resolutions, key=lambda r: (avg_scale_dist(r), aspect_diff(r), abs(r[0]*r[1]-ow*oh)))
        return best
