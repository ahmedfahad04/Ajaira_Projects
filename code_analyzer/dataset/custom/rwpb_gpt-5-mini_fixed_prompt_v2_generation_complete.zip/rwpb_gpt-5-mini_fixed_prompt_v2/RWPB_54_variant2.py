
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        # Numpy-based implementation; returns square crop and half-size s.
        try:
            import numpy as np
        except Exception:
            # Fallback to pure python math if numpy not available
            x, y, x1, y1 = map(float, box)
            w = x1 - x
            h = y1 - y
            cx = x + w / 2.0
            cy = y + h / 2.0
            new_w = w * float(expand)
            new_h = h * float(expand)
            side = max(new_w, new_h)
            s = side / 2.0
            return [cx - s, cy - s, cx + s, cy + s], s
        arr = np.asarray(box, dtype=float).reshape(4)
        x, y, x1, y1 = arr
        w = x1 - x
        h = y1 - y
        center = np.array([x + w / 2.0, y + h / 2.0])
        new_wh = np.array([w, h]) * float(expand)
        side = float(np.max(new_wh))
        s = side / 2.0
        tl = center - s
        br = center + s
        new_box = [float(tl[0]), float(tl[1]), float(br[0]), float(br[1])]
        return new_box, s
