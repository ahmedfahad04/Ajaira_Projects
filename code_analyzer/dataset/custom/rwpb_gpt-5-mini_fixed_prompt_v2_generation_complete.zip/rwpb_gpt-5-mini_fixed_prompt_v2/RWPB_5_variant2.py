
def seconds_to_hh_mm_ss(seconds):
    def seconds_to_hh_mm_ss(seconds):
        try:
            total = int(seconds)
        except Exception:
            return "00:00:00"
        if total < 0:
            return "00:00:00"
        minutes, secs = divmod(total, 60)
        hours, minutes = divmod(minutes, 60)
        return "{:02d}:{:02d}:{:02d}".format(hours, minutes, secs)
