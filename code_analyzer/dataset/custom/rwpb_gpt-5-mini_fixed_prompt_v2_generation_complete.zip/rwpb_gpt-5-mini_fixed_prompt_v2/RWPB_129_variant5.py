
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        if not isinstance(masks, torch.Tensor):
            masks = torch.tensor(masks)
        if masks.ndim != 4:
            raise ValueError("masks must be 4D (N, C, H, W)")
        N, C, Hm, Wm = masks.shape
        h, w = shape
        device = masks.device
        dtype = masks.dtype
        x = masks.view(N * C, 1, Hm, Wm).float().to(device)
        if padding:
            s = max(h, w)
            try:
                x_large = F.interpolate(x, size=(s, s), mode='bicubic', align_corners=False)
            except Exception:
                x_large = F.interpolate(x, size=(s, s), mode='bilinear', align_corners=False)
            x_large = x_large.view(N, C, s, s)
            top = (s - h) // 2
            left = (s - w) // 2
            out = x_large[:, :, top:top + h, left:left + w]
        else:
            try:
                out = F.interpolate(x, size=(h, w), mode='bicubic', align_corners=False)
            except Exception:
                out = F.interpolate(x, size=(h, w), mode='bilinear', align_corners=False)
            out = out.view(N, C, h, w)
        out = out.to(dtype)
        return out
