
def unsafeAdd(x, y):
    MAX_VAL = (1 << 256) - 1
    def unsafeAdd(x, y):
        x &= MAX_VAL
        y &= MAX_VAL
        while y:
            carry = x & y
            x = x ^ y
            y = (carry << 1) & MAX_VAL
        return x
