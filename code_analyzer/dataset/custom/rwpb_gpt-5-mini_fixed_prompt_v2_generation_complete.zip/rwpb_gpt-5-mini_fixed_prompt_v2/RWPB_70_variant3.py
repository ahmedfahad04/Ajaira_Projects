
def psnr_to_mse(psnr):
    def psnr_to_mse(psnr):
        return 10.0 ** (-psnr / 10.0)
