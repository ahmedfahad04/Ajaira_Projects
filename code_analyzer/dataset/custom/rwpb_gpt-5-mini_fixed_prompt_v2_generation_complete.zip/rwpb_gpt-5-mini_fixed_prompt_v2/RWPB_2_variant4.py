
def logbessel_I_scipy(nu, z, check = True):
    import torch
    import numpy as _np
    from scipy import special as _special
    def logbessel_I_scipy(nu, z, check = True):
        # Try high-precision fallback with mpmath when available for problematic elements
        was_tensor = isinstance(z, torch.Tensor)
        device = z.device if was_tensor else None
        dtype = z.dtype if was_tensor else None
        z_np = z.detach().cpu().numpy() if was_tensor else _np.asarray(z)
        # Primary attempt using ive for stability
        abs_z = _np.abs(z_np)
        with _np.errstate(divide='ignore', invalid='ignore', over='ignore'):
            ive_vals = _special.ive(nu, z_np)
            log_iv = _np.log(_np.abs(ive_vals)) + abs_z
        # For any non-finite, attempt high-precision mpmath evaluation elementwise
        mask = ~_np.isfinite(log_iv)
        if _np.any(mask):
            try:
                import mpmath as _mp
                _mp.mp.dps = 50
                it = _np.ndindex(*z_np.shape) if z_np.shape != () else [((),)]
                # Flatten indices
                flat_idx = _np.argwhere(mask)
                for idx in flat_idx:
                    idx_tup = tuple(idx)
                    val = z_np[idx_tup]
                    # use mpmath besseli
                    mval = _mp.besseli(nu, val)
                    if mval == 0:
                        log_iv[idx_tup] = -_np.inf
                    else:
                        # mpmath returns mpf; convert to float
                        log_iv[idx_tup] = float(_mp.log(_mp.mpf(mval)))
            except Exception:
                # Last resort: use direct iv (may be inf)
                with _np.errstate(divide='ignore', invalid='ignore'):
                    direct = _special.iv(nu, z_np[mask])
                    log_iv[mask] = _np.log(direct)
        if check:
            if _np.any(~_np.isfinite(log_iv)):
                raise ValueError("log(I_nu(z)) contains non-finite values after attempts.")
        result = torch.as_tensor(log_iv)
        if was_tensor:
            result = result.to(device=device, dtype=dtype)
        return result
