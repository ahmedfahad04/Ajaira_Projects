
def extract_code_from_funct(funct: Callable) -> List[str]:
    import inspect
    import textwrap
    from typing import Callable, List
    def extract_code_from_funct(funct: Callable) -> List[str]:
        src = inspect.getsource(funct)
        # locate the 'def' or 'async def' keyword position
        keyword_pos = None
        for k in ("def ", "async def "):
            p = src.find(k)
            if p != -1:
                keyword_pos = p
                break
        if keyword_pos is None:
            return []
        # scan forward to find the colon that ends the signature while tracking parentheses
        i = keyword_pos
        depth = 0
        sig_end = None
        while i < len(src):
            ch = src[i]
            if ch == "(":
                depth += 1
            elif ch == ")":
                if depth > 0:
                    depth -= 1
            elif ch == ":" and depth == 0:
                sig_end = i
                break
            i += 1
        if sig_end is None:
            # fallback: try to find first newline after def
            nl = src.find("\n", keyword_pos)
            if nl == -1:
                return []
            sig_end = nl
        # body begins after the colon; typically after a newline
        body_src = src[sig_end + 1:]
        ded = textwrap.dedent(body_src)
        lines = ded.splitlines()
        # strip leading/trailing empty lines
        while lines and lines[0].strip() == "":
            lines.pop(0)
        while lines and lines[-1].strip() == "":
            lines.pop()
        # drop trailing return statement if present
        if lines and lines[-1].lstrip().startswith("return"):
            lines.pop()
            while lines and lines[-1].strip() == "":
                lines.pop()
        return lines
