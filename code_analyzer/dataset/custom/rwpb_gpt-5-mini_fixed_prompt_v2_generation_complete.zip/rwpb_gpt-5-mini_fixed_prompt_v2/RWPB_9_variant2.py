
def is_byte_token(s: str) -> bool:
    import string
    _hexdigits = set(string.hexdigits)
    def is_byte_token(s: str) -> bool:
        if not isinstance(s, str):
            return False
        if len(s) != 6:
            return False
        if s[0] != '<' or s[-1] != '>':
            return False
        if s[1] != '0' or s[2].lower() != 'x':
            return False
        return s[3] in _hexdigits and s[4] in _hexdigits
