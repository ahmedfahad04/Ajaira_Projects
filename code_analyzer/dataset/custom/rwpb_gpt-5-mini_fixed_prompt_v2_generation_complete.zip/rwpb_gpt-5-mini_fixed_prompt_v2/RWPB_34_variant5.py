
def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
    import numpy as np
    def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
        target = context_window + 1
        toks = tokens
        if not isinstance(toks, np.ndarray):
            toks = np.asarray(toks)
        if toks.ndim == 0:
            out = np.full(target, pad_token)
            return out
        if toks.ndim == 1:
            L = toks.shape[0]
            if L >= target:
                return toks[:target].astype(toks.dtype)
            out = np.full(target, pad_token, dtype=toks.dtype)
            if L > 0:
                out[:L] = toks
            return out
        # if toks is 2D
        if toks.shape[0] == 0:
            return np.empty((0, target), dtype=toks.dtype)
        # build output filled with pad_token then fill
        out = np.full((toks.shape[0], target), pad_token, dtype=toks.dtype)
        for i in range(toks.shape[0]):
            row = toks[i]
            take = min(row.shape[0], target)
            if take > 0:
                out[i, :take] = row[:take]
        return out
