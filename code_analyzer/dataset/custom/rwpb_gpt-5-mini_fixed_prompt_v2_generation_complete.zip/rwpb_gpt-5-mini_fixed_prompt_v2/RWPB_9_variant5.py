
def is_byte_token(s: str) -> bool:
    def _is_hex_char(c: str) -> bool:
        if len(c) != 1:
            return False
        o = ord(c)
        return (48 <= o <= 57) or (65 <= o <= 70) or (97 <= o <= 102)
    def is_byte_token(s: str) -> bool:
        if not isinstance(s, str):
            return False
        if len(s) != 6:
            return False
        if s[0] != '<' or s[-1] != '>':
            return False
        if s[1] != '0' or s[2] not in ('x', 'X'):
            return False
        return _is_hex_char(s[3]) and _is_hex_char(s[4])
