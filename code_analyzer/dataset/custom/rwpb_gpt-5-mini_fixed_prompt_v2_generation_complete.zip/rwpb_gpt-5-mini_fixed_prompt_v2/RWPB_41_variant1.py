
def merge_short_sentences_en(sens):
    def merge_short_sentences_en(sens):
        """Merge sentences that are short (<=3 words) with the following sentence.
        If the last sentence is short, merge it with the previous sentence.
        """
        if not sens:
            return []
        s = [s.strip() for s in sens]
        out = []
        i = 0
        n = len(s)
        while i < n:
            cur = s[i]
            wc = len(cur.split())
            if wc <= 3 and i + 1 < n:
                # merge into next sentence
                s[i + 1] = (cur + ' ' + s[i + 1]).strip()
                i += 1
            else:
                out.append(cur)
                i += 1
        # If the last sentence is short and there is a previous, merge it backwards
        if len(out) >= 2 and len(out[-1].split()) <= 3:
            out[-2] = (out[-2] + ' ' + out[-1]).strip()
            out.pop()
        return out
