
def extract_imports_from_lines(lines: List[str]) -> str:
    from typing import List
    import re
    def extract_imports_from_lines(lines: List[str]) -> str:
        n = len(lines)
        i = 0
        collected = []
        while i < n:
            line = lines[i]
            if not isinstance(line, str):
                i += 1
                continue
            s = line.lstrip()
            if not s or s.startswith("#"):
                i += 1
                continue
            # check beginning token using regex to allow tabs etc.
            m = re.match(r'^(?P<kw>from|import)\b', s)
            if not m:
                i += 1
                continue
            # collect continuation lines (backslash or unbalanced parentheses)
            stmt_lines = [line.rstrip()]
            # track parentheses balance
            paren = line.count('(') - line.count(')')
            # if the line ends with backslash, continue; or parentheses unbalanced
            while (stmt_lines[-1].rstrip().endswith("\\") or paren > 0) and i + 1 < n:
                i += 1
                next_line = lines[i]
                stmt_lines.append(next_line.rstrip())
                paren += next_line.count('(') - next_line.count(')')
            collected.append("\n".join(stmt_lines))
            i += 1
        return "\n".join(collected)
