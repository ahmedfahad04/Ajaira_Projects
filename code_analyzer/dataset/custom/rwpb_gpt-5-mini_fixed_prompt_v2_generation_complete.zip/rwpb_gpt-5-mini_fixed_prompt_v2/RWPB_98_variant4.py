
def exp_smooth(vals, alpha):
    import numpy as np
    from functools import lru_cache
    def exp_smooth(vals, alpha):
        vals = np.asarray(vals)
        if vals.size == 0:
            raise KeyError
        vals = vals.astype(float)
        n = vals.size
        @lru_cache(maxsize=None)
        def s(i):
            if i == 0:
                return float(vals[0])
            return alpha * float(vals[i]) + (1.0 - alpha) * s(i - 1)
        return np.array([s(i) for i in range(n)], dtype=float)
