
def is_tensor(x):
    import importlib.util
    import importlib
    import numpy as np
    def is_tensor(x):
        spec = importlib.util.find_spec("torch")
        if spec is not None:
            try:
                torch = importlib.import_module("torch")
                if isinstance(x, getattr(torch, "Tensor", ())) :
                    return True
            except Exception:
                pass
        return isinstance(x, np.ndarray)
