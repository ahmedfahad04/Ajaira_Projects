
def resample_segments(segments, n=1000):
    import numpy as np
    def resample_segments(segments, n=1000):
        out = []
        for seg in segments:
            seg = np.asarray(seg, dtype=float)
            if seg.size == 0:
                out.append(np.empty((0,2)))
                continue
            if seg.ndim == 1:
                seg = seg.reshape(-1,2)
            m = seg.shape[0]
            if m == 1 or np.allclose(seg - seg[0], 0):
                out.append(np.repeat(seg[:1,:], n, axis=0))
                continue
            diffs = seg[1:] - seg[:-1]
            lens = np.hypot(diffs[:,0], diffs[:,1])
            cum = np.concatenate(([0.0], np.cumsum(lens)))
            total = cum[-1]
            if total == 0:
                out.append(np.repeat(seg[:1,:], n, axis=0))
                continue
            newd = np.linspace(0.0, total, n)
            idx = np.searchsorted(cum, newd, side='right') - 1
            idx = np.clip(idx, 0, m-2)
            left_pts = seg[idx]
            right_pts = seg[idx+1]
            left_cum = cum[idx]
            right_cum = cum[idx+1]
            span = right_cum - left_cum
            span[span == 0] = 1.0
            alpha = ((newd - left_cum) / span).reshape(-1,1)
            pts = left_pts * (1 - alpha) + right_pts * alpha
            out.append(pts)
        return out
