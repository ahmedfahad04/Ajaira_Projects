
def norm_grid(v_grid):
    import torch
    def norm_grid(v_grid):
        if not isinstance(v_grid, torch.Tensor):
            v_grid = torch.tensor(v_grid)
        B, C, H, W = v_grid.shape
        if C != 2:
            v = v_grid
            v_min = v.amin(dim=(1,2,3), keepdim=True)
            v_max = v.amax(dim=(1,2,3), keepdim=True)
            denom = torch.where((v_max - v_min) == 0, torch.ones_like(v_max - v_min), v_max - v_min)
            v_norm = (v - v_min) / denom * 2.0 - 1.0
            return v_norm.permute(0,2,3,1)
        x = v_grid[:, 0, :, :].float()
        y = v_grid[:, 1, :, :].float()
        denom_x = (W - 1) if W > 1 else 1
        denom_y = (H - 1) if H > 1 else 1
        x_norm = (x / denom_x) * 2.0 - 1.0
        y_norm = (y / denom_y) * 2.0 - 1.0
        out = torch.stack((x_norm, y_norm), dim=-1)
        return out
