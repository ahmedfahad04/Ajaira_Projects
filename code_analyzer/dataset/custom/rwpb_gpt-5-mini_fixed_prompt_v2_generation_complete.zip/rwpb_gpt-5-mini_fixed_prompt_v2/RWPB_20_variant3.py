
def get_line_angle(x1, y1, x2, y2):
    import math
    def get_line_angle(x1, y1, x2, y2):
        dx = x2 - x1
        dy = y2 - y1
        if dx == 0 and dy == 0:
            return 0.0
        return math.degrees(math.atan2(dy, dx))
