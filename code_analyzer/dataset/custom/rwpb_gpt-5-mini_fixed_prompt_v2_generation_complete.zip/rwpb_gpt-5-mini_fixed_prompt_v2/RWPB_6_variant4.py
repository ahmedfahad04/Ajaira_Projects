
def format_seconds(seconds: float) -> str:
    def format_seconds(seconds: float) -> str:
        """Use math.modf style but avoid fractional carry errors by using ms rounding first."""
        import math
        negative = seconds < 0
        abs_sec = abs(seconds)
        total_ms = int(round(abs_sec * 1000))
        h = total_ms // (3600 * 1000)
        total_ms -= h * 3600 * 1000
        m = total_ms // (60 * 1000)
        total_ms -= m * 60 * 1000
        s = total_ms // 1000
        ms = total_ms % 1000
        sign = "-" if negative else ""
        if h >= 1:
            return f"{sign}{h:02d}:{m:02d}:{s:02d}.{ms:03d}"
        else:
            return f"{sign}{m:02d}:{s:02d}.{ms:03d}"
