
def xywh2xyxy(x):
    import numpy as np
    import torch
    def xywh2xyxy(x):
        if isinstance(x, torch.Tensor):
            if x.is_floating_point():
                out = x.clone()
                out[..., 2] = out[..., 0] + out[..., 2]
                out[..., 3] = out[..., 1] + out[..., 3]
                return out
            else:
                y = x.to(dtype=x.dtype)
                return torch.stack((y[...,0], y[...,1], y[...,0]+y[...,2], y[...,1]+y[...,3]), dim=-1)
        else:
            arr = np.asarray(x)
            if arr.dtype.kind in 'iub':
                x0 = arr[..., 0].astype(arr.dtype)
                y0 = arr[..., 1].astype(arr.dtype)
                x2 = x0 + arr[..., 2]
                y2 = y0 + arr[..., 3]
                return np.stack((x0, y0, x2, y2), axis=-1)
            else:
                return np.stack((arr[...,0], arr[...,1], arr[...,0]+arr[...,2], arr[...,1]+arr[...,3]), axis=-1)
