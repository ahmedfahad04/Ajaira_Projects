
def pad_camera_extrinsics_4x4(extrinsics):
    import torch
    import torch.nn.functional as F
    def pad_camera_extrinsics_4x4(extrinsics):
        if not isinstance(extrinsics, torch.Tensor):
            raise TypeError("extrinsics must be a torch.Tensor")
        if extrinsics.dim() < 2:
            raise ValueError("extrinsics must have at least 2 dimensions")
        h, w = extrinsics.shape[-2], extrinsics.shape[-1]
        if (h, w) == (4, 4):
            return extrinsics.clone()
        if (h, w) != (3, 4):
            raise ValueError(f"Unsupported extrinsics shape {extrinsics.shape}; expected (...,3,4) or (...,4,4).")
        # Pad a row of zeros at the bottom, then set bottom-right to 1
        padded = F.pad(extrinsics, (0, 0, 0, 1), mode='constant', value=0)
        # Set the bottom-right element to 1 for every batch
        padded_index = (..., -1, -1)
        padded[padded_index] = extrinsics.new_tensor(1)
        return padded
