
def format_seconds(seconds: float) -> str:
    def format_seconds(seconds: float) -> str:
        """Alternative: format by building strings and handling carry from rounding explicitly."""
        neg = seconds < 0
        s = abs(seconds)
        # Round to milliseconds as float but handle carry
        total_ms = int(round(s * 1000))
        ms = total_ms % 1000
        total_seconds = total_ms // 1000
        secs = total_seconds % 60
        total_minutes = total_seconds // 60
        mins = total_minutes % 60
        hrs = total_minutes // 60
        sign = "-" if neg else ""
        if hrs > 0:
            return sign + f"{hrs:02d}:{mins:02d}:{secs:02d}.{ms:03d}"
        else:
            return sign + f"{mins:02d}:{secs:02d}.{ms:03d}"
