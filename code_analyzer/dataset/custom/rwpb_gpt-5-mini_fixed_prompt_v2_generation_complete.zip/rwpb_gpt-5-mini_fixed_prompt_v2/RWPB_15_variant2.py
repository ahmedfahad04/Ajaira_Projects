
def cosine_distance(a, b):
    import numpy as np
    import math
    def cosine_distance(a, b):
        a = np.asarray(a).flatten()
        b = np.asarray(b)
        if b.ndim == 0:
            raise KeyError("b must be vector or matrix")
        dim = a.shape[0]
        def _single_distance(x):
            x = np.asarray(x).flatten()
            if x.shape[0] != dim:
                raise KeyError("length mismatch")
            da = math.sqrt(float((a * a).sum()))
            db = math.sqrt(float((x * x).sum()))
            if da == 0 or db == 0:
                return 1.0
            dot = float((a * x).sum())
            return 1.0 - dot / (da * db)
        if b.ndim == 1:
            return _single_distance(b)
        elif b.ndim == 2:
            # decide orientation: rows or columns
            if b.shape[1] == dim:
                results = []
                for row in b:
                    results.append(_single_distance(row))
                return np.array(results)
            elif b.shape[0] == dim:
                results = []
                for i in range(b.shape[1]):
                    col = b[:, i]
                    results.append(_single_distance(col))
                return np.array(results)
            else:
                raise KeyError("length mismatch")
        else:
            raise KeyError("b must be 1D or 2D")
