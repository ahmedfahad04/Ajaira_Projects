
def pad_camera_extrinsics_4x4(extrinsics):
    import torch
    def pad_camera_extrinsics_4x4(extrinsics):
        if not isinstance(extrinsics, torch.Tensor):
            raise TypeError("extrinsics must be a torch.Tensor")
        if extrinsics.dim() < 2:
            raise ValueError("extrinsics must have at least 2 dimensions")
        h, w = extrinsics.shape[-2], extrinsics.shape[-1]
        if (h, w) == (4, 4):
            return extrinsics.clone()
        if (h, w) != (3, 4):
            raise ValueError(f"Unsupported extrinsics shape {extrinsics.shape}; expected (...,3,4) or (...,4,4).")
        # Create an identity 4x4 and copy the 3x4 into the top part
        batch_shape = extrinsics.shape[:-2]
        eye4 = torch.eye(4, dtype=extrinsics.dtype, device=extrinsics.device).view((1, 4, 4))
        eye4 = eye4.expand(batch_shape + (4, 4)).clone()
        eye4[..., :3, :] = extrinsics
        return eye4
