
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        if upcast:
            orig_dtype = x.dtype
            x = x.to(torch.float32)
            weight = weight.to(torch.float32) if weight is not None else None
            bias = bias.to(torch.float32) if bias is not None else None
            residual = residual.to(torch.float32) if residual is not None else None
        # ensure weight/bias broadcastable to last dim
        if weight is not None and weight.ndim == 1 and x.dim() >= 1:
            weight_b = weight.view(*([1] * (x.dim() - 1)), -1)
        else:
            weight_b = weight
        if bias is not None and bias.ndim == 1 and x.dim() >= 1:
            bias_b = bias.view(*([1] * (x.dim() - 1)), -1)
        else:
            bias_b = bias
        # compute mean of squares along last dim
        mean_sq = x.pow(2).mean(dim=-1, keepdim=True)
        denom = (mean_sq + eps).sqrt()
        normed = x / denom
        out = normed * weight_b if weight_b is not None else normed
        if bias_b is not None:
            out = out + bias_b
        if residual is not None:
            out = out + residual
        if upcast:
            out = out.to(orig_dtype)
        if prenorm:
            return out, x
        return out
