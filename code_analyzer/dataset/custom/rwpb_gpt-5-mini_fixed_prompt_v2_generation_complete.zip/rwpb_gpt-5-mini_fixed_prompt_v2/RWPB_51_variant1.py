
def _ssim(img1, img2, window, window_size, channel, size_average=True):
    import torch
    import torch.nn.functional as F
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        if not (img1.shape == img2.shape):
            raise ValueError("Input images must have the same dimensions.")
        # ensure window has shape [channel,1,ws,ws] for group conv
        if window.dim() == 2:
            ws = window_size
            w = window.view(1, 1, ws, ws)
        elif window.dim() == 4:
            w = window
        else:
            w = window.view(1, 1, window_size, window_size)
        w = w.to(img1.dtype).to(img1.device)
        # expand to per-channel kernels
        if w.size(0) == 1:
            w = w.expand(channel, 1, w.size(2), w.size(3)).contiguous()
        # padding
        pad = window_size // 2
        mu1 = F.conv2d(img1, w, padding=pad, groups=channel)
        mu2 = F.conv2d(img2, w, padding=pad, groups=channel)
        mu1_sq = mu1.pow(2)
        mu2_sq = mu2.pow(2)
        mu1_mu2 = mu1 * mu2
        sigma1_sq = F.conv2d(img1 * img1, w, padding=pad, groups=channel) - mu1_sq
        sigma2_sq = F.conv2d(img2 * img2, w, padding=pad, groups=channel) - mu2_sq
        sigma12 = F.conv2d(img1 * img2, w, padding=pad, groups=channel) - mu1_mu2
        # constants (assume images in [0,1])
        C1 = (0.01) ** 2
        C2 = (0.03) ** 2
        numerator = (2 * mu1_mu2 + C1) * (2 * sigma12 + C2)
        denominator = (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)
        ssim_map = numerator / denominator
        if size_average:
            return ssim_map.mean()
        else:
            # return mean SSIM per channel aggregated over batch and spatial dims
            # shape [channel]
            return ssim_map.mean(dim=(0, 2, 3))
