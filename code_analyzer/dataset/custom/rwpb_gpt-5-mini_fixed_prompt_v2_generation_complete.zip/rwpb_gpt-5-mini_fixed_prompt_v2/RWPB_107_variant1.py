
def pad_camera_extrinsics_4x4(extrinsics):
    import torch
    def pad_camera_extrinsics_4x4(extrinsics):
        """
        Pads a given extrinsics matrix to a 4x4 matrix if it is not already.
        Args:
            extrinsics (torch.Tensor): Input extrinsics matrix of shape (..., 3, 4) or (..., 4, 4).
        Returns:
            torch.Tensor: Padded extrinsics matrix of shape (..., 4, 4).
        """
        if not isinstance(extrinsics, torch.Tensor):
            raise TypeError("extrinsics must be a torch.Tensor")
        if extrinsics.dim() < 2:
            raise ValueError("extrinsics must have at least 2 dimensions")
        h, w = extrinsics.shape[-2], extrinsics.shape[-1]
        if (h, w) == (4, 4):
            return extrinsics.clone()
        if (h, w) != (3, 4):
            raise ValueError(f"Unsupported extrinsics shape {extrinsics.shape}; expected (...,3,4) or (...,4,4).")
        # Create last row [0,0,0,1] with correct dtype/device and broadcast to batch shape
        batch_shape = extrinsics.shape[:-2]
        last_row = extrinsics.new_tensor([0, 0, 0, 1]).view((1, 4)).expand(batch_shape + (1, 4))
        return torch.cat([extrinsics, last_row], dim=-2)
