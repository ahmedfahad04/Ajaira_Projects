
def divide_to_patches(image, patch_size):
    from PIL import Image
    def divide_to_patches(image, patch_size):
        w, h = image.size
        new_w = ((w + patch_size - 1) // patch_size) * patch_size
        new_h = ((h + patch_size - 1) // patch_size) * patch_size
        padded = Image.new(image.mode, (new_w, new_h))
        padded.paste(image, (0, 0))
        patches = []
        for y in range(0, new_h, patch_size):
            for x in range(0, new_w, patch_size):
                patches.append(padded.crop((x, y, x + patch_size, y + patch_size)))
        return patches
