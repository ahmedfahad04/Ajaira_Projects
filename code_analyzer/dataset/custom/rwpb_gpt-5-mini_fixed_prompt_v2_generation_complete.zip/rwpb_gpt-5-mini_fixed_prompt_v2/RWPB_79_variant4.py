
def pr_from_grav(grav):
    import numpy as np
    def pr_from_grav(grav):
        g = np.asarray(grav, dtype=float)
        def single_pr(v):
            gx, gy, gz = v
            # use hypot for stability
            denom = np.hypot(gy, gz)
            pitch = np.arctan2(-gx, denom)
            roll = np.arctan2(gy, gz)
            return pitch, roll
        if g.ndim == 1:
            p, r = single_pr(g)
            return np.array([p]), np.array([r])
        # apply along axis
        prs = np.apply_along_axis(lambda row: np.array(single_pr(row)), 1, g)
        pitches = prs[:, 0]
        rolls = prs[:, 1]
        return pitches, rolls
