
def mean(l, ignore_nan=False, empty=0):
    import math
    def mean(l, ignore_nan=False, empty=0):
        total = 0.0
        count = 0
        # Helper to safely detect NaN
        def _isnan(x):
            try:
                return math.isnan(x)
            except Exception:
                return False
        for x in l:
            if _isnan(x):
                if ignore_nan:
                    continue
                else:
                    return float('nan')
            # If not NaN (or we ignore NaNs), accumulate
            total += x
            count += 1
        if count == 0:
            if empty == 'raise':
                raise ValueError("mean of empty sequence")
            return empty
        return total / count
