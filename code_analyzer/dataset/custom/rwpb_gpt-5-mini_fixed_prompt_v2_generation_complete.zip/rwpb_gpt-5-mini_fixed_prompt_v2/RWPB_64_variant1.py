
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        arr = np.asarray(arr, dtype=float)
        if window_size <= 0 or int(window_size) != window_size:
            raise ValueError("window_size must be a positive integer")
        w = int(window_size)
        n = arr.size
        if n == 0:
            return [np.array([]), np.array([])]
        kernel = np.ones(w, dtype=float)
        sums = np.convolve(arr, kernel, mode='same')
        counts = np.convolve(np.ones(n, dtype=float), kernel, mode='same')
        ma = sums / counts
        residuals = arr - ma
        return [ma, residuals]
