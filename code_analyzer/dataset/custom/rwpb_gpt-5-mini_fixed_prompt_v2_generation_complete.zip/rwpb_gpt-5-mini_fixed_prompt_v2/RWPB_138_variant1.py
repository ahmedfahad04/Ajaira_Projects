
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        nm = np.array(normal_map, dtype=np.float32, copy=True)
        if nm.ndim != 3 or nm.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        theta = np.deg2rad(angle)
        c = np.cos(theta)
        s = np.sin(theta)
        # Rotation matrix around Y: x' = c*x + s*z, y' = y, z' = -s*x + c*z
        R = np.array([[c, 0.0, s],
                      [0.0, 1.0, 0.0],
                      [-s, 0.0, c]], dtype=np.float32)
        H, W, _ = nm.shape
        flat = nm.reshape(-1, 3)
        rotated_flat = flat.dot(R.T)
        # Normalize to unit vectors (avoid division by zero)
        norms = np.linalg.norm(rotated_flat, axis=1, keepdims=True)
        eps = 1e-8
        rotated_flat = rotated_flat / np.maximum(norms, eps)
        return rotated_flat.reshape(H, W, 3)
