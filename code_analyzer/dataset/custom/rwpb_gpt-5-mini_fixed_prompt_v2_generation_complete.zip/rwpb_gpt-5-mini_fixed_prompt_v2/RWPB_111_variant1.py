
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        """Create a mesh grid with normalized coordinates in range [-1, 1].
        Returns tensor of shape (B, 2, H, W) where channel 0 is x (width) and channel 1 is y (height).
        """
        if H <= 0 or W <= 0 or B <= 0:
            return torch.empty((B, 2, H, W))
        # safe denominators to avoid division by zero when H==1 or W==1
        den_w = W - 1 if W > 1 else 1
        den_h = H - 1 if H > 1 else 1
        ys = torch.linspace(-1.0, 1.0, H, dtype=torch.float32)
        xs = torch.linspace(-1.0, 1.0, W, dtype=torch.float32)
        # meshgrid with indexing='ij' so shapes are (H, W)
        yy, xx = torch.meshgrid(ys, xs, indexing='ij')
        grid = torch.stack((xx, yy), dim=0)  # (2, H, W)
        grid = grid.unsqueeze(0).expand(B, -1, -1, -1).contiguous()
        return grid
