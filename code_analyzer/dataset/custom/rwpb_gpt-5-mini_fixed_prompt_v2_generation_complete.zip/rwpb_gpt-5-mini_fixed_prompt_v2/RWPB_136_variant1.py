
def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
    import torch
    def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
        if not torch.is_tensor(v0):
            v0 = torch.tensor(v0)
        if not torch.is_tensor(v1):
            v1 = torch.tensor(v1)
        eps = 1e-8
        v0_norm = v0.norm(dim=-1, keepdim=True).clamp_min(eps)
        v1_norm = v1.norm(dim=-1, keepdim=True).clamp_min(eps)
        u0 = v0 / v0_norm
        u1 = v1 / v1_norm
        dot = (u0 * u1).sum(dim=-1, keepdim=True).clamp(-1.0, 1.0)
        if dot.item() > DOT_THRESHOLD:
            out = (1.0 - t) * v0 + t * v1
            out_norm = out.norm(dim=-1, keepdim=True).clamp_min(eps)
            return out / out_norm * ((1 - t) * v0_norm + t * v1_norm)
        theta = torch.acos(dot)
        sin_theta = torch.sin(theta)
        s0 = torch.sin((1.0 - t) * theta) / sin_theta
        s1 = torch.sin(t * theta) / sin_theta
        return (s0 * u0 * v0_norm) + (s1 * u1 * v1_norm)
