
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na == 0 or nb == 0:
            return (None, None)
        an = a / na
        bn = b / nb
        dot = np.dot(an, bn)
        dot = np.clip(dot, -1.0, 1.0)
        eps = 1e-12
        if dot > 1 - eps:
            return (None, None)
        # Use quaternion-derived formula for angle: angle = 2*atan2(|cross|, 1+dot)
        cross = np.cross(an, bn)
        cross_norm = np.linalg.norm(cross)
        if cross_norm < eps:
            # opposite
            arb = np.array([1.0, 0.0, 0.0])
            if abs(np.dot(arb, an)) > 0.9:
                arb = np.array([0.0, 1.0, 0.0])
            axis = np.cross(an, arb)
            axis = axis / np.linalg.norm(axis)
            return (axis, float(np.pi))
        angle = float(2.0 * np.arctan2(cross_norm, 1.0 + dot))
        axis = cross / cross_norm
        return (axis, angle)
