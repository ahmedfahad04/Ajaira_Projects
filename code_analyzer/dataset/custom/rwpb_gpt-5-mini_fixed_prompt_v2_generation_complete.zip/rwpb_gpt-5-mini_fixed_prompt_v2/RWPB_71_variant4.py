
def getLambertCoefs(numOfLambertCoefs):
    from math import factorial
    from decimal import Decimal, getcontext
    def getLambertCoefs(numOfLambertCoefs):
        if numOfLambertCoefs <= 0:
            return []
        # set precision higher for larger n
        getcontext().prec = max(28, numOfLambertCoefs * 4)
        coefs = [Decimal(0)]
        for n in range(1, numOfLambertCoefs):
            # compute as Decimal to preserve precision
            num = Decimal(n) ** Decimal(n - 1)
            if (n % 2) == 1:
                num = -num
            den = Decimal(factorial(n))
            coefs.append(num / den)
        if numOfLambertCoefs == 1:
            return coefs[:1]
        return coefs
