
def compute_tri_normal(geometry, tris):
    import torch
    def compute_tri_normal(geometry, tris):
        """
        Vectorized implementation using index_select and unit-normalization.
        geometry: (B, N, 3)
        tris: (T, 3)
        returns: (B, T, 3)
        """
        if tris.numel() == 0:
            return geometry.new_empty((geometry.shape[0], 0, 3))
        tris = tris.long().to(geometry.device)
        v0 = geometry.index_select(1, tris[:, 0])
        v1 = geometry.index_select(1, tris[:, 1])
        v2 = geometry.index_select(1, tris[:, 2])
        e1 = v1 - v0
        e2 = v2 - v0
        normals = torch.cross(e1, e2, dim=2)
        denom = normals.norm(dim=2, keepdim=True).clamp_min(1e-12)
        normals = normals / denom
        return normals
