
def get_focalLength_from_fieldOfView(fov=60, img_size=512):
    import numpy as np
    def get_focalLength_from_fieldOfView(fov=60, img_size=512):
        """
        Compute focal length assuming FOV (degrees) spans the full image width.
        Uses direct analytic formula: f = (img_size/2) / tan(fov/2)
        """
        if fov <= 0 or fov >= 180:
            raise ValueError("fov must be in (0, 180) degrees")
        half_rad = np.deg2rad(fov) / 2.0
        focal = (img_size / 2.0) / np.tan(half_rad)
        return float(focal)
