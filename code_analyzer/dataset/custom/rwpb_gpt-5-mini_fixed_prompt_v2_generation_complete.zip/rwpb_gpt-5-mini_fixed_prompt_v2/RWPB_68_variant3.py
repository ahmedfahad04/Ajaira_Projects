
def last_before(val, arr):
    import numpy as np
    def last_before(val, arr):
        arr = np.asarray(arr)
        if arr.size == 0:
            return -1
        idxs = np.where(arr <= val)[0]
        if idxs.size == 0:
            return -1
        return int(idxs[-1])
