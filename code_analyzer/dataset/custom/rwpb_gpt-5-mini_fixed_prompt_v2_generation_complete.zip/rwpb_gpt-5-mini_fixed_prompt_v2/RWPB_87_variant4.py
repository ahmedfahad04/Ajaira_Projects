
def rotate_x(a, device=None):
    import numpy as np
    import torch
    def rotate_x(a, device=None):
        # Use numpy to form array then convert to torch
        # Allow torch tensor input by converting to numpy scalar
        if isinstance(a, torch.Tensor):
            a_val = float(a.detach().cpu().numpy())
        else:
            a_val = float(a)
        c = np.cos(a_val)
        s = np.sin(a_val)
        arr = np.zeros((4,4), dtype=np.float32)
        arr[0,0] = 1.0
        arr[3,3] = 1.0
        arr[1,1] = c
        arr[1,2] = -s
        arr[2,1] = s
        arr[2,2] = c
        t = torch.from_numpy(arr)
        if device is not None:
            t = t.to(device)
        return t
