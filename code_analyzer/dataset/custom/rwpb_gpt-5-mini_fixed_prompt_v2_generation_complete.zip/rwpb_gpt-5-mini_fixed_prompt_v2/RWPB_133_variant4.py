
def divide_to_patches(image, patch_size):
    from PIL import Image
    def divide_to_patches(image, patch_size):
        w, h = image.size
        patches = []
        def crop_x(x, y):
            if x >= w:
                return
            rx = min(x + patch_size, w)
            ry = min(y + patch_size, h)
            patches.append(image.crop((x, y, rx, ry)))
            crop_x(x + patch_size, y)
        def crop_y(y):
            if y >= h:
                return
            crop_x(0, y)
            crop_y(y + patch_size)
        crop_y(0)
        return patches
