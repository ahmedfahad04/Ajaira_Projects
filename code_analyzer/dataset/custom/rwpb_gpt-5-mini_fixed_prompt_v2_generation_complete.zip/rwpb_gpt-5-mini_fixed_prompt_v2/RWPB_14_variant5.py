
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na == 0 or nb == 0:
            return (None, None)
        ua = a / na
        ub = b / nb
        if np.allclose(ua, ub):
            return (None, None)
        dot = np.clip(np.dot(ua, ub), -1.0, 1.0)
        # Use quaternion-style compact formula q = [w, x] with w = 1+dot, x = cross
        cross = np.cross(ua, ub)
        w = 1.0 + dot
        if w < 1e-12:
            # opposite vectors
            abs_ua = np.abs(ua)
            idx = int(np.argmin(abs_ua))
            tmp = np.zeros(3)
            tmp[idx] = 1.0
            axis = np.cross(ua, tmp)
            axis /= np.linalg.norm(axis)
            return (axis, np.pi)
        q = np.empty(4, dtype=float)
        q[0] = w
        q[1:] = cross
        q /= np.linalg.norm(q)
        qw = np.clip(q[0], -1.0, 1.0)
        angle = 2.0 * np.arccos(qw)
        s = np.sqrt(1.0 - qw*qw)
        if s < 1e-12:
            return (None, None)
        axis = q[1:] / s
        axis /= np.linalg.norm(axis)
        return (axis, float(angle))
