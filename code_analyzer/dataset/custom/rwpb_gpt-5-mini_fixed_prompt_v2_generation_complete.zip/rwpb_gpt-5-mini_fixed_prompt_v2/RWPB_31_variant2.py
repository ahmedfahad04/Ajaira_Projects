
def resize_to_batch_size(tensor, batch_size):
    import torch
    import torch.nn.functional as F
    import math
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        old = tensor.size(0)
        if batch_size == old:
            return tensor
        if old == 1:
            return tensor.expand(batch_size, *tensor.shape[1:]).clone()
        # For reduction: pick evenly spaced indices (rounding)
        if batch_size < old:
            idx = torch.linspace(0, old - 1, steps=batch_size, device=tensor.device)
            idx = torch.clamp(idx.round().long(), 0, old - 1)
            return tensor[idx]
        # For expansion: use torch.interpolate by treating the batch axis as the temporal axis.
        # Flatten remaining dims into channels and interpolate along the length (old -> batch_size).
        rest_shape = tensor.shape[1:]
        channels = 1
        for s in rest_shape:
            channels *= s
        # reshape to (1, channels, old)
        flat = tensor.reshape(old, channels).permute(1, 0).unsqueeze(0)  # (1, channels, old)
        resized = F.interpolate(flat, size=batch_size, mode='linear', align_corners=True)
        # back to (batch_size, *rest_shape)
        resized = resized.squeeze(0).permute(1, 0).reshape((batch_size,) + rest_shape)
        return resized
