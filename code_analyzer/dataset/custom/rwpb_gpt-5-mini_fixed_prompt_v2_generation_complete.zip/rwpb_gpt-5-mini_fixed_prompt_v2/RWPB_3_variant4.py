
def get_focalLength_from_fieldOfView(fov=60, img_size=512):
    import numpy as np
    def get_focalLength_from_fieldOfView(fov=60, img_size=512):
        # Accept scalar or array-like fov; compute focal for each element
        fov_arr = np.asarray(fov)
        if np.any(fov_arr <= 0) or np.any(fov_arr >= 180):
            raise ValueError("fov must be in (0, 180) degrees")
        half_rad = np.deg2rad(fov_arr) / 2.0
        focal_arr = (img_size / 2.0) / np.tan(half_rad)
        if np.isscalar(fov):
            return float(focal_arr)
        return focal_arr
