
def euler2rot(euler_angle):
    import torch
    def euler2rot(euler_angle):
        if not isinstance(euler_angle, torch.Tensor):
            euler_angle = torch.tensor(euler_angle)
        if euler_angle.dim() == 1:
            euler_angle = euler_angle.unsqueeze(0)
        roll = euler_angle[:, 0]   # rotation about x
        pitch = euler_angle[:, 1]  # rotation about y
        yaw = euler_angle[:, 2]    # rotation about z
        half_roll = roll * 0.5
        half_pitch = pitch * 0.5
        half_yaw = yaw * 0.5
        cr = torch.cos(half_roll); sr = torch.sin(half_roll)
        cp = torch.cos(half_pitch); sp = torch.sin(half_pitch)
        cy = torch.cos(half_yaw); sy = torch.sin(half_yaw)
        qw = cr * cp * cy + sr * sp * sy
        qx = sr * cp * cy - cr * sp * sy
        qy = cr * sp * cy + sr * cp * sy
        qz = cr * cp * sy - sr * sp * cy
        # normalize quaternion
        norm = torch.sqrt(qw*qw + qx*qx + qy*qy + qz*qz)
        qw = qw / norm; qx = qx / norm; qy = qy / norm; qz = qz / norm
        B = euler_angle.shape[0]
        device = euler_angle.device
        dtype = euler_angle.dtype
        R = torch.zeros((B, 3, 3), device=device, dtype=dtype)
        R[:, 0, 0] = 1 - 2*(qy*qy + qz*qz)
        R[:, 0, 1] = 2*(qx*qy - qz*qw)
        R[:, 0, 2] = 2*(qx*qz + qy*qw)
        R[:, 1, 0] = 2*(qx*qy + qz*qw)
        R[:, 1, 1] = 1 - 2*(qx*qx + qz*qz)
        R[:, 1, 2] = 2*(qy*qz - qx*qw)
        R[:, 2, 0] = 2*(qx*qz - qy*qw)
        R[:, 2, 1] = 2*(qy*qz + qx*qw)
        R[:, 2, 2] = 1 - 2*(qx*qx + qy*qy)
        return R
