
def box_iou(box1, box2, eps=1e-7):
    import torch
    import numpy as np
    def box_iou(box1, box2, eps=1e-7):
        if not torch.is_tensor(box1):
            box1 = torch.as_tensor(box1)
        if not torch.is_tensor(box2):
            box2 = torch.as_tensor(box2)
        box1 = box1.float()
        box2 = box2.float()
        N = box1.shape[0]
        M = box2.shape[0]
        if N == 0 or M == 0:
            return torch.zeros((N, M), dtype=box1.dtype, device=box1.device)
        ious = []
        if N <= M:
            for i in range(N):
                b1 = box1[i:i+1]
                x1 = torch.max(b1[:, 0], box2[:, 0])
                y1 = torch.max(b1[:, 1], box2[:, 1])
                x2 = torch.min(b1[:, 2], box2[:, 2])
                y2 = torch.min(b1[:, 3], box2[:, 3])
                inter = (x2 - x1).clamp(min=0) * (y2 - y1).clamp(min=0)
                area1 = ((b1[:, 2] - b1[:, 0]).clamp(min=0) * (b1[:, 3] - b1[:, 1]).clamp(min=0)).item()
                area2 = (box2[:, 2] - box2[:, 0]).clamp(min=0) * (box2[:, 3] - box2[:, 1]).clamp(min=0)
                union = area1 + area2 - inter
                ious.append((inter / (union + eps)).squeeze(0))
            return torch.stack(ious, dim=0)
        else:
            for j in range(M):
                b2 = box2[j:j+1]
                x1 = torch.max(box1[:, 0], b2[:, 0])
                y1 = torch.max(box1[:, 1], b2[:, 1])
                x2 = torch.min(box1[:, 2], b2[:, 2])
                y2 = torch.min(box1[:, 3], b2[:, 3])
                inter = (x2 - x1).clamp(min=0) * (y2 - y1).clamp(min=0)
                area1 = (box1[:, 2] - box1[:, 0]).clamp(min=0) * (box1[:, 3] - box1[:, 1]).clamp(min=0)
                area2 = ((b2[:, 2] - b2[:, 0]).clamp(min=0) * (b2[:, 3] - b2[:, 1]).clamp(min=0)).item()
                union = area1 + area2 - inter
                col = (inter / (union + eps)).unsqueeze(1)
                ious.append(col)
            return torch.cat(ious, dim=1)
