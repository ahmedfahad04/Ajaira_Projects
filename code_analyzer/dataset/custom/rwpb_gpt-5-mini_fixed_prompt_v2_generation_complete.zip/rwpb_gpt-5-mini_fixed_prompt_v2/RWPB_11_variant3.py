
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    from typing import List
    from collections import deque
    def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be a non-negative integer")
        dq = deque(ls)
        # truncate if too long
        while len(dq) > max_seq_length:
            if pad_right:
                dq.pop()  # remove from right keep leftmost
            else:
                dq.popleft()  # remove from left keep rightmost
        # pad if too short
        while len(dq) < max_seq_length:
            if pad_right:
                dq.append(pad_idx)
            else:
                dq.appendleft(pad_idx)
        result = list(dq)
        if check and len(result) != max_seq_length:
            raise ValueError("Result length does not equal max_seq_length")
        return result
