
def bbox_ioa(box1, box2, iou=False, eps=1e-7):
    import numpy as np
    def bbox_ioa(box1, box2, iou=False, eps=1e-7):
        b1 = np.asarray(box1, dtype=float)
        b2 = np.asarray(box2, dtype=float)
        if b1.ndim == 1:
            b1 = b1.reshape(1, 4)
        if b2.ndim == 1:
            b2 = b2.reshape(1, 4)
        n = b1.shape[0]
        m = b2.shape[0]
        if n == 0 or m == 0:
            return np.zeros((n, m), dtype=float)
        res = []
        area1 = np.clip((b1[:, 2] - b1[:, 0]) * (b1[:, 3] - b1[:, 1]), 0, None)
        area2 = np.clip((b2[:, 2] - b2[:, 0]) * (b2[:, 3] - b2[:, 1]), 0, None)
        for i in range(n):
            row = []
            x1i, y1i, x2i, y2i = b1[i]
            for j in range(m):
                x1j, y1j, x2j, y2j = b2[j]
                ix1 = x1i if x1i > x1j else x1j
                iy1 = y1i if y1i > y1j else y1j
                ix2 = x2i if x2i < x2j else x2j
                iy2 = y2i if y2i < y2j else y2j
                w = ix2 - ix1
                h = iy2 - iy1
                if w <= 0 or h <= 0:
                    inter = 0.0
                else:
                    inter = w * h
                if iou:
                    denom = area1[i] + area2[j] - inter + eps
                    row.append(inter / denom)
                else:
                    row.append(inter / (area2[j] + eps))
            res.append(row)
        return np.array(res, dtype=float)
