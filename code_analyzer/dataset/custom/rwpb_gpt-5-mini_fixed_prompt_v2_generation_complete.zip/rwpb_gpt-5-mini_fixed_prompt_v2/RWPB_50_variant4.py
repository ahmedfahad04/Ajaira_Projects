
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        original_h, original_w = original_size
        if not isinstance(tensor, torch.Tensor):
            tensor = torch.tensor(tensor)
        single = False
        if tensor.ndim == 3:
            single = True
            tensor_in = tensor.unsqueeze(0)
        elif tensor.ndim == 4:
            tensor_in = tensor
        else:
            raise ValueError("expect 3D (C,H,W) or 4D (N,C,H,W)")
        device = tensor_in.device
        dtype = tensor_in.dtype
        out_list = []
        for i in range(tensor_in.shape[0]):
            img = tensor_in[i].cpu().numpy()
            C, H, W = img.shape
            if H == 0 or W == 0:
                out_list.append(torch.from_numpy(img).to(device).to(dtype))
                continue
            target_aspect = original_h / original_w
            cur_aspect = H / W
            if abs(cur_aspect - target_aspect) < 1e-6:
                cropped = img
            elif cur_aspect > target_aspect:
                new_h = int(round(W * target_aspect))
                new_h = max(1, min(new_h, H))
                top = (H - new_h) // 2
                cropped = img[:, top:top + new_h, :]
            else:
                new_w = int(round(H / target_aspect))
                new_w = max(1, min(new_w, W))
                left = (W - new_w) // 2
                cropped = img[:, :, left:left + new_w]
            out_list.append(torch.from_numpy(cropped).to(device).to(dtype))
        out = torch.stack(out_list, dim=0)
        if single:
            return out[0]
        return out
