
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        preds = torch.as_tensor(preds)
        labels = torch.as_tensor(labels)
        if preds.dim() == 4 and preds.size(1) == 1:
            preds = preds.squeeze(1)
        if preds.dim() == labels.dim() - 1:
            preds = preds.unsqueeze(1)
        if preds.dtype.is_floating_point:
            preds = (preds > 0.5)
        else:
            preds = preds == 1
        labels_fg = labels == 1
        if labels_fg.dim() == 2:
            labels_fg = labels_fg.unsqueeze(0)
        if preds.dim() == 2:
            preds = preds.unsqueeze(0)
        if ignore is not None:
            mask = labels != ignore
            if mask.dim() == 2:
                mask = mask.unsqueeze(0)
            mask = mask.expand_as(labels_fg)
        else:
            mask = torch.ones_like(labels_fg, dtype=torch.bool)
        if per_image:
            total = 0.0
            count = preds.size(0)
            for i in range(count):
                pm = preds[i] & mask[i]
                lm = labels_fg[i] & mask[i]
                inter = (pm & lm).sum().float()
                union = (pm | lm).sum().float()
                if union == 0:
                    total += float(EMPTY)
                else:
                    total += (inter / union).item()
            return float((total / count) * 100.0)
        else:
            pm = preds & mask
            lm = labels_fg & mask
            inter = (pm & lm).sum().float()
            union = (pm | lm).sum().float()
            if union == 0:
                return float(EMPTY * 100.0)
            return float((inter / union).item() * 100.0)
