
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        # Basic float implementation producing a square crop centered on original box center.
        if box is None:
            raise ValueError("box must be provided")
        if expand <= 0:
            raise ValueError("expand must be positive")
        x, y, x1, y1 = map(float, box)
        w = x1 - x
        h = y1 - y
        cx = x + w / 2.0
        cy = y + h / 2.0
        new_w = w * float(expand)
        new_h = h * float(expand)
        # Make square by taking the larger side
        side = max(new_w, new_h)
        s = side / 2.0
        new_x = cx - s
        new_y = cy - s
        new_x1 = cx + s
        new_y1 = cy + s
        return [new_x, new_y, new_x1, new_y1], s
