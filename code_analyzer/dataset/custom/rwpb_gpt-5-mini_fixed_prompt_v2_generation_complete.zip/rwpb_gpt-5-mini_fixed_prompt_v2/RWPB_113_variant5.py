
def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
    import torch
    def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
        start = torch.as_tensor(start)
        stop = torch.as_tensor(stop)
        if num <= 0:
            return torch.empty((0,) + tuple(start.shape), dtype=start.dtype, device=start.device)
        s_b, t_b = torch.broadcast_tensors(start, stop)
        dtype = torch.result_type(s_b, t_b, torch.tensor(0.0))
        device = s_b.device
        s_b = s_b.to(dtype=dtype, device=device)
        t_b = t_b.to(dtype=dtype, device=device)
        if num == 1:
            return s_b.unsqueeze(0)
        # use multiplication by a column vector of fractions
        positions = torch.linspace(0.0, 1.0, steps=num, device=device, dtype=dtype).unsqueeze(-1)
        # create view shape that will broadcast correctly by adding leading dim
        expand_shape = (num,) + (1,) * s_b.dim()
        positions = positions.view(expand_shape)
        return s_b.unsqueeze(0) * (1.0 - positions) + t_b.unsqueeze(0) * positions
