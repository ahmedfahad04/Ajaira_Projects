
def format_ratio(ratio):
    from decimal import Decimal, ROUND_DOWN, InvalidOperation
    def format_ratio(ratio):
        try:
            d = Decimal(str(ratio))
        except (InvalidOperation, ValueError):
            d = Decimal(float(ratio))
        if d.is_nan():
            return "percentage:NaN"
        if d == Decimal('Infinity') or d == Decimal('-Infinity'):
            return "percentage:" + str(d)
        q = d.quantize(Decimal('0.000'), rounding=ROUND_DOWN)
        return "percentage:" + format(q, 'f')
