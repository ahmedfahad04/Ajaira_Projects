
def B_batch(x, grid, k=0, extend=True, device="cpu"):
    import torch
    def B_batch(x, grid, k=0, extend=True, device="cpu"):
        x = x.to(device)
        grid = grid.to(device)
        S, N = x.shape
        _, m = grid.shape
        p = int(k)
        if m < 2:
            n_bases = max(0, m + p - 1)
            return torch.zeros((S, n_bases, N), device=device, dtype=x.dtype)
        # Build T per-spline (same shapes)
        if extend:
            left_diff = (grid[:,1] - grid[:,0]).unsqueeze(1)
            right_diff = (grid[:,-1] - grid[:,-2]).unsqueeze(1)
            pre_offsets = torch.arange(p,0,-1,device=device,dtype=grid.dtype).unsqueeze(0)
            post_offsets = torch.arange(1,p+1,device=device,dtype=grid.dtype).unsqueeze(0)
            pre = grid[:,:1] - pre_offsets * left_diff
            post = grid[:,-1:] + post_offsets * right_diff
        else:
            pre = grid[:,:1].repeat(1,p)
            post = grid[:,-1:].repeat(1,p)
        T = torch.cat([pre, grid, post], dim=1)  # (S, m+2p)
        n_T = T.shape[1]
        n_bases = m + p - 1
        # Prepare arrays
        xs = x.unsqueeze(1)  # (S,1,N)
        # Compute all intervals left and right
        lefts = T[:,:-1].unsqueeze(2)  # (S,n_T-1,1)
        rights = T[:,1:].unsqueeze(2)
        B = ((xs >= lefts) & (xs < rights)).to(dtype=x.dtype)  # (S,n_T-1,N)
        # include last endpoint equality
        lastk = T[:,-1].unsqueeze(1).unsqueeze(2)
        eq = (xs == lastk).squeeze(1)
        if eq.any():
            B[:, -1, :][eq] = 1.0
        # Precompute denominators for all r and i
        for r in range(1, p+1):
            new_len = n_T - 1 - r
            denom1 = (T[:, r:n_T-1] - T[:, :n_T-1-r]).unsqueeze(2)  # (S,new_len,1)
            denom2 = (T[:, r+1:n_T] - T[:, 1:n_T-r]).unsqueeze(2)
            left_coeff = torch.zeros((S,new_len,N), device=device, dtype=x.dtype)
            right_coeff = torch.zeros_like(left_coeff)
            # avoid divisions by zero
            nz1 = denom1 != 0
            if nz1.any():
                left_coeff[nz1.expand_as(left_coeff)] = ((xs - T[:, :n_T-1-r].unsqueeze(2))[nz1.expand_as(xs)]) / denom1[nz1]
                # vectorization above uses masking - simplify by full division with safe fill
                coeff1 = (xs - T[:, :n_T-1-r].unsqueeze(2)) / (denom1 + (~nz1).to(dtype=denom1.dtype))
                left_coeff = coeff1 * B[:, :new_len, :]
                left_coeff = left_coeff * nz1.to(dtype=left_coeff.dtype)
            nz2 = denom2 != 0
            if nz2.any():
                coeff2 = (T[:, r+1:n_T].unsqueeze(2) - xs) / (denom2 + (~nz2).to(dtype=denom2.dtype))
                right_coeff = coeff2 * B[:, 1:new_len+1, :]
                right_coeff = right_coeff * nz2.to(dtype=right_coeff.dtype)
            B = left_coeff + right_coeff
        return B[:, :n_bases, :]
