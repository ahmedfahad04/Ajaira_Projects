
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        # Create coordinate tensors using arithmetic on arange and broadcast
        if H <= 0 or W <= 0 or B <= 0:
            return torch.empty((B, 2, H, W))
        # pixel coordinates normalized to [-1,1]
        if W > 1:
            x = (2.0 * torch.arange(W, dtype=torch.float32) / (W - 1)) - 1.0
        else:
            x = torch.tensor([0.0], dtype=torch.float32)
        if H > 1:
            y = (2.0 * torch.arange(H, dtype=torch.float32) / (H - 1)) - 1.0
        else:
            y = torch.tensor([0.0], dtype=torch.float32)
        # broadcast to grid
        x_grid = x.unsqueeze(0).expand(H, W)  # will broadcast along rows
        y_grid = y.unsqueeze(1).expand(H, W)  # will broadcast along cols
        grid = torch.stack([x_grid, y_grid], dim=0)  # (2, H, W)
        return grid.unsqueeze(0).repeat(B, 1, 1, 1)
