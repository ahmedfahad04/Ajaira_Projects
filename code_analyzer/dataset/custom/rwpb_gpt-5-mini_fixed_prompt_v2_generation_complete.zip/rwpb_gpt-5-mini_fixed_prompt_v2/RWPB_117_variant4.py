
def path_spliter(path: str):
    import os
    def path_spliter(path: str):
        if not path:
            return []
        drive, remainder = os.path.splitdrive(path)
        def helper(p):
            head, tail = os.path.split(p)
            # if split returns same string as head, it's either root or unchanged
            if head == p:
                return [head] if head else []
            if tail == '':
                return [head] if head else []
            return helper(head) + [tail] if head else [tail]
        parts = helper(remainder)
        if drive:
            return [drive] + parts if parts else [drive]
        return parts
