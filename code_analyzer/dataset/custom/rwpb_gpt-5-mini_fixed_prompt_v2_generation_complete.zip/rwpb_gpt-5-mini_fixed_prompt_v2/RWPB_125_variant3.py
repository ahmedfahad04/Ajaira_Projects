
def resample_segments(segments, n=1000):
    import numpy as np
    def resample_segments(segments, n=1000):
        resampled = []
        for seg in segments:
            seg = np.asarray(seg, float)
            if seg.size == 0:
                resampled.append(np.empty((0, 2)))
                continue
            if seg.ndim == 1:
                seg = seg.reshape(-1, 2)
            if seg.shape[0] == 1:
                resampled.append(np.repeat(seg[:1, :], n, axis=0))
                continue
            d = np.sqrt(((seg[1:] - seg[:-1]) ** 2).sum(axis=1))
            s = np.concatenate(([0.0], np.cumsum(d)))
            length = s[-1]
            if length == 0.0:
                resampled.append(np.repeat(seg[:1, :], n, axis=0))
                continue
            t = s / length
            new_t = np.linspace(0.0, 1.0, n)
            x = np.interp(new_t, t, seg[:, 0])
            y = np.interp(new_t, t, seg[:, 1])
            resampled.append(np.stack((x, y), axis=1))
        return resampled
