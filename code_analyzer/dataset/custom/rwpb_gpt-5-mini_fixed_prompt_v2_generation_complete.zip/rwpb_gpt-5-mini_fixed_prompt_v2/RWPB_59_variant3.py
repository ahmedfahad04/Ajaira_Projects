
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        if repetition_penalty == 1.0:
            return logits
        rp = float(repetition_penalty)
        logits = logits.clone()
        batch_size, vocab_size = logits.shape
        if prev_output_tokens.numel() == 0:
            return logits
        # Create global flat indices for all (batch, token) occurrences
        batch_indices = (torch.arange(batch_size, device=prev_output_tokens.device, dtype=prev_output_tokens.dtype)
                         .unsqueeze(1) * vocab_size)
        flat_indices = (batch_indices + prev_output_tokens).view(-1)
        # unique global indices
        flat_indices = flat_indices[flat_indices >= 0]
        if flat_indices.numel() == 0:
            return logits
        unique_flat = torch.unique(flat_indices)
        flat_logits = logits.view(-1)
        vals = flat_logits[unique_flat]
        pos_mask = vals > 0
        if pos_mask.any():
            flat_logits[unique_flat[pos_mask]] = vals[pos_mask] / rp
        if (~pos_mask).any():
            flat_logits[unique_flat[~pos_mask]] = vals[~pos_mask] * rp
        return logits
