
def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
    import torch
    def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
        """
        Uses torch.movedim if available (clean and efficient).
        """
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        nd = x.dim()
        if nd == 0:
            return x.contiguous() if make_contiguous else x
        # normalize negative dims
        src = src_dim + nd if src_dim < 0 else src_dim
        dest = dest_dim + nd if dest_dim < 0 else dest_dim
        if not (0 <= src < nd) or not (0 <= dest < nd):
            raise IndexError("src_dim or dest_dim out of range")
        if src == dest:
            return x.contiguous() if make_contiguous else x
        try:
            out = torch.movedim(x, src, dest)
        except Exception:
            # fallback to manual permutation
            dims = list(range(nd))
            dims.pop(src)
            dims.insert(dest, src)
            out = x.permute(*dims)
        return out.contiguous() if make_contiguous else out
