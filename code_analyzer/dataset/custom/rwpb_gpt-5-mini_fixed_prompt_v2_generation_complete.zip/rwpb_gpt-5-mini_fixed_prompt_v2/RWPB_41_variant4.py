
def merge_short_sentences_en(sens):
    def merge_short_sentences_en(sens):
        """Recursive approach. Short sentences are those with <=3 words."""
        def helper(idx, acc):
            if idx >= n:
                return acc
            cur = s[idx]
            if len(cur.split()) <= 3 and idx + 1 < n:
                s[idx + 1] = (cur + ' ' + s[idx + 1]).strip()
                return helper(idx + 1, acc)
            else:
                acc.append(cur)
                return helper(idx + 1, acc)
        if not sens:
            return []
        s = [x.strip() for x in sens]
        n = len(s)
        result = helper(0, [])
        if len(result) >= 2 and len(result[-1].split()) <= 3:
            result[-2] = (result[-2] + ' ' + result[-1]).strip()
            result.pop()
        return result
