
def compute_tri_normal(geometry, tris):
    import torch
    def compute_tri_normal(geometry, tris):
        """
        Manual component-wise cross product using broadcasting and index_select.
        Returns normalized normals.
        """
        if tris.numel() == 0:
            return geometry.new_empty((geometry.shape[0], 0, 3))
        tris = tris.long().to(geometry.device)
        v0 = geometry.index_select(1, tris[:, 0])
        v1 = geometry.index_select(1, tris[:, 1])
        v2 = geometry.index_select(1, tris[:, 2])
        e1 = v1 - v0
        e2 = v2 - v0
        ex = e1[..., 1] * e2[..., 2] - e1[..., 2] * e2[..., 1]
        ey = e1[..., 2] * e2[..., 0] - e1[..., 0] * e2[..., 2]
        ez = e1[..., 0] * e2[..., 1] - e1[..., 1] * e2[..., 0]
        normals = torch.stack((ex, ey, ez), dim=-1)
        normals = normals / (normals.norm(dim=-1, keepdim=True) + 1e-12)
        return normals
