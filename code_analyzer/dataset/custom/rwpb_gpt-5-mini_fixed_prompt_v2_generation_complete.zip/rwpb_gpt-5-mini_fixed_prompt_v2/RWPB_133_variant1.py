
def divide_to_patches(image, patch_size):
    from PIL import Image
    def divide_to_patches(image, patch_size):
        w, h = image.size
        patches = []
        for y in range(0, h, patch_size):
            for x in range(0, w, patch_size):
                right = min(x + patch_size, w)
                lower = min(y + patch_size, h)
                patches.append(image.crop((x, y, right, lower)))
        return patches
