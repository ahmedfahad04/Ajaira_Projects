
def view_range(x, i, j, shape):
    import torch
    import math
    def view_range(x, i, j, shape):
        ndim = x.dim()
        if j is None:
            j = ndim
        # normalize negatives
        if i < 0:
            i = ndim + i
        if j < 0:
            j = ndim + j
        i = max(0, min(i, ndim))
        j = max(0, min(j, ndim))
        if i > j:
            raise ValueError("Start dimension i must be <= end dimension j.")
        left = tuple(x.shape[:i])
        mid = tuple(x.shape[i:j])
        right = tuple(x.shape[j:])
        mid_prod = 1
        for v in mid:
            mid_prod *= v
        # handle -1 in shape
        shape = tuple(int(s) for s in shape)
        if -1 in shape:
            known = 1
            cnt = 0
            for s in shape:
                if s == -1:
                    cnt += 1
                else:
                    known *= s
            if cnt != 1:
                raise ValueError("Only one -1 is allowed in shape")
            if known == 0:
                raise ValueError("Cannot infer shape with zero product")
            inferred = mid_prod // known
            if inferred * known != mid_prod:
                raise ValueError("Inferred dimension does not divide the product of the target range")
            shape = tuple(inferred if s == -1 else s for s in shape)
        shape_prod = 1
        for s in shape:
            shape_prod *= s
        if shape_prod != mid_prod:
            raise ValueError(f"Target shape product {shape_prod} does not match product of dimensions in range {mid_prod}")
        new_shape = tuple(left) + tuple(shape) + tuple(right)
        return x.reshape(new_shape)
