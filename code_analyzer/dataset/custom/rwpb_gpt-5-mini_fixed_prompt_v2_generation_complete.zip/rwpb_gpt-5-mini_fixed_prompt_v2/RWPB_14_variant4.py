
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na == 0 or nb == 0:
            return (None, None)
        ua = a / na
        ub = b / nb
        if np.allclose(ua, ub):
            return (None, None)
        v = np.cross(ua, ub)
        s = np.linalg.norm(v)
        c = np.dot(ua, ub)
        if s < 1e-12:
            # opposite
            abs_ua = np.abs(ua)
            idx = int(np.argmin(abs_ua))
            tmp = np.zeros(3)
            tmp[idx] = 1.0
            axis = np.cross(ua, tmp)
            axis = axis / np.linalg.norm(axis)
            return (axis, np.pi)
        K = np.array([[0, -v[2], v[1]],
                      [v[2], 0, -v[0]],
                      [-v[1], v[0], 0]], dtype=float)
        R = np.eye(3) + K + (K @ K) * ((1.0) / (1.0 + c))
        # Extract axis-angle from R
        trace = np.trace(R)
        angle = np.arccos(np.clip((trace - 1.0) / 2.0, -1.0, 1.0))
        if abs(angle) < 1e-12:
            return (None, None)
        denom = 2.0 * np.sin(angle)
        axis = np.array([R[2,1] - R[1,2], R[0,2] - R[2,0], R[1,0] - R[0,1]]) / denom
        axis = axis / np.linalg.norm(axis)
        return (axis, float(angle))
