
def clean_html(:
    import re
    from typing import List
    def clean_html(
            html_to_clean: str,
            tags_to_remove: List[str] = ["style", "svg", "script"],
            attributes_to_keep: List[str] = ["id", "href"],
    ) -> str:
        html = html_to_clean or ""
        if tags_to_remove:
            for tag in tags_to_remove:
                name = re.escape(tag)
                html = re.sub(fr'(?is)<{name}\b[^>]*?>.*?</{name}>', '', html)
                html = re.sub(fr'(?is)<{name}\b[^>]*?/>', '', html)
        keep = set([a.lower() for a in (attributes_to_keep or [])])
        tag_re = re.compile(r'<[^>]+>')
        attr_re = re.compile(r'([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+)))?')
        def process_tag(tag):
            if tag.startswith("<!--") or tag.startswith("<!"):
                return tag
            m = re.match(r'^<\s*(/)?\s*([^\s>/]+)', tag)
            if not m:
                return tag
            closing = bool(m.group(1))
            tagname = m.group(2)
            if closing:
                return f"</{tagname}>"
            if tag.endswith("/>"):
                end_slash = True
            else:
                end_slash = False
            body = tag[len(m.group(0)):- (2 if end_slash else 1)]
            attrs = []
            for am in attr_re.finditer(body):
                an = am.group(1)
                av = am.group(2) if am.group(2) is not None else (am.group(3) if am.group(3) is not None else am.group(4))
                if an.lower() in keep:
                    if av is None:
                        attrs.append(an)
                    else:
                        v = av.replace('"', '&quot;')
                        attrs.append(f'{an}="{v}"')
            if attrs:
                inner = " " + " ".join(attrs)
            else:
                inner = ""
            if end_slash:
                return f"<{tagname}{inner} />"
            else:
                return f"<{tagname}{inner}>"
        parts = []
        last = 0
        for m in tag_re.finditer(html):
            parts.append(html[last:m.start()])
            parts.append(process_tag(m.group(0)))
            last = m.end()
        parts.append(html[last:])
        return "".join(parts)
