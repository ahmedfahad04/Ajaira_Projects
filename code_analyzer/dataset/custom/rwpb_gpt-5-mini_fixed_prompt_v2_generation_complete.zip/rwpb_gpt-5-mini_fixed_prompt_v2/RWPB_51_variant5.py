
def _ssim(img1, img2, window, window_size, channel, size_average=True):
    import torch
    import torch.nn.functional as F
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        if img1.size() != img2.size():
            raise ValueError("Input images must have the same size")
        device = img1.device
        dtype = img1.dtype
        # Normalize kernel to sum to 1
        if window.dim() == 2:
            w = window.view(1,1,window_size,window_size).to(device).to(dtype)
        elif window.dim() == 4:
            w = window.to(device).to(dtype)
        else:
            w = window.view(1,1,window_size,window_size).to(device).to(dtype)
        w = w / w.sum()
        if w.size(0) == 1:
            w = w.expand(channel,1,w.size(2),w.size(3)).contiguous()
        pad = window_size // 2
        # compute local statistics
        mu1 = F.conv2d(img1, w, padding=pad, groups=channel)
        mu2 = F.conv2d(img2, w, padding=pad, groups=channel)
        mu1_sq = mu1.pow(2)
        mu2_sq = mu2.pow(2)
        mu1_mu2 = mu1 * mu2
        sigma1_sq = F.conv2d(img1 * img1, w, padding=pad, groups=channel) - mu1_sq
        sigma2_sq = F.conv2d(img2 * img2, w, padding=pad, groups=channel) - mu2_sq
        sigma12 = F.conv2d(img1 * img2, w, padding=pad, groups=channel) - mu1_mu2
        # determine dynamic range L from data
        max_val = max(img1.max().item(), img2.max().item())
        if max_val > 1.0:
            L = max_val
        else:
            L = 1.0
        C1 = (0.01 * L) ** 2
        C2 = (0.03 * L) ** 2
        numerator = (2 * mu1_mu2 + C1) * (2 * sigma12 + C2)
        denominator = (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)
        ssim_map = numerator / denominator
        if size_average:
            return ssim_map.mean()
        else:
            return ssim_map.mean(dim=(0,2,3))
