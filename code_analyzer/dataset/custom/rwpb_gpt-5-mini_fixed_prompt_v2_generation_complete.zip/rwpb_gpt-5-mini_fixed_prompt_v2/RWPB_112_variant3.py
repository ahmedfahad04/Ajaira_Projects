
def submatrix(matrix, col):
    from copy import deepcopy
    def submatrix(matrix, col):
        """
        Use a deep copy and pop the specified column index from each row.
        pop supports negative indices naturally.
        """
        copied = deepcopy(matrix)
        for row in copied:
            # let pop handle index checking and negative indices
            row.pop(col)
        return copied
