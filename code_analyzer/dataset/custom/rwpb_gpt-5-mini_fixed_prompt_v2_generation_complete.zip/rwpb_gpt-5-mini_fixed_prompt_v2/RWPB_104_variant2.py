
def mulMod(x, y, z):
    def mulMod(x, y, z):
        if z == 0:
            raise ZeroDivisionError("integer modulo by zero")
        if z < 0:
            z = -z
        a = x % z
        b = y % z
        res = 0
        while b:
            if b & 1:
                res += a
                if res >= z:
                    res %= z
            a <<= 1
            if a >= z:
                a %= z
            b >>= 1
        return res % z
