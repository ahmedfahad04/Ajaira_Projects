
def get_confusion_matrix(gt_label, pred_label, num_classes):
    import numpy as np
    def get_confusion_matrix(gt_label, pred_label, num_classes):
        if not isinstance(num_classes, int) or num_classes <= 0:
            raise ValueError("num_classes must be a positive integer")
        gt = np.asarray(gt_label)
        pred = np.asarray(pred_label)
        if gt.shape[0] != pred.shape[0]:
            raise ValueError("gt_label and pred_label must have the same length")
        if gt.size == 0:
            return np.zeros((num_classes, num_classes), dtype=int)
        # Validate labels
        if not (np.issubdtype(gt.dtype, np.integer) and np.issubdtype(pred.dtype, np.integer)):
            # try casting to integers but check if values change
            gt_cast = gt.astype(int)
            pred_cast = pred.astype(int)
            if not (np.all(gt_cast == gt) and np.all(pred_cast == pred)):
                raise ValueError("Labels must be integer-valued in range [0, num_classes-1]")
            gt = gt_cast
            pred = pred_cast
        if gt.min() < 0 or pred.min() < 0 or gt.max() >= num_classes or pred.max() >= num_classes:
            raise ValueError("Labels must be in the range [0, num_classes-1]")
        # vectorized via ravel index + bincount
        indices = gt.astype(int) * num_classes + pred.astype(int)
        counts = np.bincount(indices, minlength=num_classes * num_classes)
        cm = counts.reshape((num_classes, num_classes))
        return cm.astype(int)
