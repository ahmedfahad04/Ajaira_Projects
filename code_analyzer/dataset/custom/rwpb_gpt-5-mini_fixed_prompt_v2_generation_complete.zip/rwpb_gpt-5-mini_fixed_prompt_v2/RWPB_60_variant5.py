
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        # compute mean of squares via sum and use rsqrt for efficiency
        if upcast:
            orig_dtype = x.dtype
            x = x.to(torch.float32)
            weight = weight.to(torch.float32) if weight is not None else None
            bias = bias.to(torch.float32) if bias is not None else None
            residual = residual.to(torch.float32) if residual is not None else None
        D = x.size(-1)
        if weight is not None and weight.dim() == 1:
            weight = weight.view(*([1] * (x.dim() - 1)), -1)
        if bias is not None and bias.dim() == 1:
            bias = bias.view(*([1] * (x.dim() - 1)), -1)
        sum_sq = (x * x).sum(dim=-1, keepdim=True)
        mean_sq = sum_sq / float(D)
        inv_denom = torch.rsqrt(mean_sq + eps)
        normed = x * inv_denom
        if weight is not None:
            out = normed * weight
        else:
            out = normed
        if bias is not None:
            out = out + bias
        if residual is not None:
            out = out + residual
        if upcast:
            out = out.to(orig_dtype)
        if prenorm:
            return out, x
        return out
