
def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
    import numpy as np
    def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
        n = np.array(plane_normal, dtype=float)
        p0 = np.array(plane_point, dtype=float)
        v = np.array(ray_direction, dtype=float)
        r0 = np.array(ray_point, dtype=float)
        if np.linalg.norm(v) == 0:
            return None
        d = np.dot(n, p0)
        denom = np.dot(n, v)
        tol = 1e-10
        if abs(denom) < tol:
            if abs(np.dot(n, r0) - d) < tol:
                return None
            return None
        t = (d - np.dot(n, r0)) / denom
        return r0 + t * v
