
def rotate_normalmap_by_angle_torch(normal_map, angle):
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        import torch
        device = normal_map.device
        dtype = normal_map.dtype
        theta = angle * 3.141592653589793 / 180.0
        cos = torch.cos(torch.tensor(theta, device=device, dtype=dtype))
        sin = torch.sin(torch.tensor(theta, device=device, dtype=dtype))
        R = torch.stack([
            torch.stack([cos, torch.tensor(0.0, device=device, dtype=dtype), sin]),
            torch.stack([torch.tensor(0.0, device=device, dtype=dtype), torch.tensor(1.0, device=device, dtype=dtype), torch.tensor(0.0, device=device, dtype=dtype)]),
            torch.stack([-sin, torch.tensor(0.0, device=device, dtype=dtype), cos])
        ], dim=0)
        rotated = torch.einsum('ij,...j->...i', R, normal_map)
        norm = torch.sqrt((rotated * rotated).sum(dim=-1, keepdim=True))
        rotated = rotated / (norm + 1e-8)
        return rotated
