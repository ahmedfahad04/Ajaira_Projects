
def euler2rot(euler_angle):
    import torch
    def euler2rot(euler_angle):
        if not isinstance(euler_angle, torch.Tensor):
            euler_angle = torch.tensor(euler_angle)
        if euler_angle.dim() == 1:
            euler_angle = euler_angle.unsqueeze(0)
        rx = euler_angle[:, 0]
        ry = euler_angle[:, 1]
        rz = euler_angle[:, 2]
        cx = torch.cos(rx); sx = torch.sin(rx)
        cy = torch.cos(ry); sy = torch.sin(ry)
        cz = torch.cos(rz); sz = torch.sin(rz)
        r00 = cz * cy
        r01 = cz * sy * sx - sz * cx
        r02 = cz * sy * cx + sz * sx
        r10 = sz * cy
        r11 = sz * sy * sx + cz * cx
        r12 = sz * sy * cx - cz * sx
        r20 = -sy
        r21 = cy * sx
        r22 = cy * cx
        R = torch.stack([
            torch.stack([r00, r01, r02], dim=1),
            torch.stack([r10, r11, r12], dim=1),
            torch.stack([r20, r21, r22], dim=1)
        ], dim=1)
        # permute to (B,3,3)
        R = R.permute(0, 2, 1)
        return R
