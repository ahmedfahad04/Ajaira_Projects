
def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
    import torch
    def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
        start = torch.as_tensor(start)
        stop = torch.as_tensor(stop)
        if num <= 0:
            return torch.empty((0,) + tuple(start.shape), dtype=start.dtype, device=start.device)
        # flatten approach: compute sequences per-element then reshape
        s_b, t_b = torch.broadcast_tensors(start, stop)
        orig_shape = s_b.shape
        s_flat = s_b.contiguous().view(-1)
        t_flat = t_b.contiguous().view(-1)
        dtype = torch.result_type(s_flat, t_flat, torch.tensor(0.0))
        device = s_flat.device
        s_flat = s_flat.to(dtype=dtype, device=device)
        t_flat = t_flat.to(dtype=dtype, device=device)
        if num == 1:
            return s_flat.view((1,) + orig_shape)
        denom = float(num - 1)
        steps = torch.arange(num, dtype=dtype, device=device).unsqueeze(1)  # (num,1)
        fracs = steps / denom  # (num,1)
        dif = (t_flat - s_flat).unsqueeze(0)  # (1, N)
        res_flat = s_flat.unsqueeze(0) + fracs * dif  # (num, N)
        res = res_flat.view((num,) + orig_shape)
        return res
