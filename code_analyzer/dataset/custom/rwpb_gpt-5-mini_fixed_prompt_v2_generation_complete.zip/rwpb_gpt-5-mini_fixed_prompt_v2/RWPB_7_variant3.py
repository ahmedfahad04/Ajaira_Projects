
def dynamic_import_function(function_path):
    from importlib import import_module
    def dynamic_import_function(function_path):
        """
        Use __import__ with fromlist to import attribute directly.
        If there are multiple attribute parts, import the deepest possible module
        and then getattr the remainder.
        """
        if not isinstance(function_path, str):
            return ModuleNotFoundError
        parts = function_path.split('.')
        if len(parts) < 2:
            return ModuleNotFoundError
        # try to import with fromlist of the immediate next name
        for i in range(len(parts)-1, 0, -1):
            module_name = '.'.join(parts[:i])
            attrs = parts[i:]
            try:
                # __import__ will return the module when using fromlist
                module = __import__(module_name, fromlist=['*'])
            except ModuleNotFoundError:
                continue
            except Exception:
                continue
            obj = module
            ok = True
            for a in attrs:
                try:
                    obj = getattr(obj, a)
                except Exception:
                    ok = False
                    break
            if ok:
                return obj
        return ModuleNotFoundError
