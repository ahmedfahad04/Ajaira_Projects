
def pr_from_grav(grav):
    import numpy as np
    def pr_from_grav(grav):
        g = np.asarray(grav, dtype=float)
        if g.ndim == 1:
            g = g.reshape(1,3)
        gx = g[:,0]
        gy = g[:,1]
        gz = g[:,2]
        # robust computation that avoids overflow: scale components
        abs_max = np.maximum.reduce([np.abs(gx), np.abs(gy), np.abs(gz), np.ones_like(gx)])
        gx_s = gx / abs_max
        gy_s = gy / abs_max
        gz_s = gz / abs_max
        denom_s = np.hypot(gy_s, gz_s)
        # map back scaling for angle computation using same ratio
        pitches = np.arctan2(-gx_s, denom_s)
        rolls = np.arctan2(gy_s, gz_s)
        return pitches.reshape(-1,), rolls.reshape(-1,)
