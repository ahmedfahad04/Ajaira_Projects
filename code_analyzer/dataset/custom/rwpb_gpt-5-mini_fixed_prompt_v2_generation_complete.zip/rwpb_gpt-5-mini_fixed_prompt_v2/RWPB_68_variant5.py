
def last_before(val, arr):
    import numpy as np
    def last_before(val, arr):
        arr = np.asarray(arr)
        if arr.size == 0:
            return -1
        mask = arr <= val
        if not mask.any():
            return -1
        rev_arg = mask[::-1].argmax()
        return int(len(arr) - 1 - rev_arg)
