
def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
    import torch
    def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
        start = torch.as_tensor(start)
        stop = torch.as_tensor(stop)
        if num <= 0:
            return torch.empty((0,) + tuple(start.shape), dtype=start.dtype, device=start.device)
        if num == 1:
            # return broadcasted start
            s, _ = torch.broadcast_tensors(start, stop)
            return s.clone().unsqueeze(0)
        # promote to a floating result type
        dtype = torch.result_type(start, stop, torch.tensor(0.0))
        device = start.device
        start_b, stop_b = torch.broadcast_tensors(start, stop)
        start_b = start_b.to(dtype=dtype, device=device)
        stop_b = stop_b.to(dtype=dtype, device=device)
        weights = torch.linspace(0.0, 1.0, steps=num, dtype=dtype, device=device)
        # reshape weights to broadcast across start shape
        view_shape = (num,) + (1,) * start_b.dim()
        weights = weights.view(view_shape)
        # use torch.lerp on unsqueezed start/stop
        return torch.lerp(start_b.unsqueeze(0), stop_b.unsqueeze(0), weights)
