
def extract_imports_from_lines(lines: List[str]) -> str:
    from typing import List
    def extract_imports_from_lines(lines: List[str]) -> str:
        collected = []
        n = len(lines)
        i = 0
        in_triple = False
        triple_types = ('"""', "'''")
        while i < n:
            line = lines[i]
            if not isinstance(line, str):
                i += 1
                continue
            # update triple-quote state
            for t in triple_types:
                cnt = line.count(t)
                if cnt % 2 == 1:
                    in_triple = not in_triple
            if in_triple:
                i += 1
                continue
            stripped = line.lstrip()
            if not stripped or stripped.startswith("#"):
                i += 1
                continue
            if stripped.startswith("import ") or stripped.startswith("from "):
                stmt = [line.rstrip()]
                # handle backslash continuation or unbalanced parentheses
                paren = line.count("(") - line.count(")")
                while stmt[-1].rstrip().endswith("\\") or paren > 0:
                    i += 1
                    if i >= n:
                        break
                    nxt = lines[i]
                    # update triple quote inside continuation
                    for t in triple_types:
                        cnt2 = nxt.count(t)
                        if cnt2 % 2 == 1:
                            in_triple = not in_triple
                    stmt.append(nxt.rstrip())
                    paren += nxt.count("(") - nxt.count(")")
                collected.append("\n".join(stmt))
            i += 1
        return "\n".join(collected)
