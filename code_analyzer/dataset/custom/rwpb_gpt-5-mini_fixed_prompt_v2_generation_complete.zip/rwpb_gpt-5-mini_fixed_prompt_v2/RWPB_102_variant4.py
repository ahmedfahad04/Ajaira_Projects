
def rotate_about_z_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_z_axis(vector, theta):
        """
        Element-wise computation without constructing full matrix explicitly.
        """
        arr = np.asarray(vector, dtype=float).reshape(3,)
        x = arr[0]
        y = arr[1]
        z = arr[2]
        cos_t = math.cos(theta)
        sin_t = math.sin(theta)
        return np.array([x * cos_t - y * sin_t,
                         x * sin_t + y * cos_t,
                         z], dtype=float)
