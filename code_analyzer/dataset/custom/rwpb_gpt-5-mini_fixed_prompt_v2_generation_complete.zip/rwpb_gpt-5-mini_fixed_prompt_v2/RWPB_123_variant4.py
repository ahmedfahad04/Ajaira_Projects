
def fuse_deconv_and_bn(deconv, bn):
    import torch
    import torch.nn as nn
    def fuse_deconv_and_bn(deconv, bn):
        if not isinstance(deconv, nn.ConvTranspose2d) or not isinstance(bn, nn.BatchNorm2d):
            raise TypeError("Expected ConvTranspose2d and BatchNorm2d")
        device = deconv.weight.device
        dtype = deconv.weight.dtype
        out_ch = deconv.out_channels
        in_ch = deconv.in_channels
        groups = deconv.groups
        if bn.affine:
            gamma = bn.weight.detach().to(device=device, dtype=dtype)
            beta = bn.bias.detach().to(device=device, dtype=dtype)
        else:
            gamma = torch.ones(out_ch, device=device, dtype=dtype)
            beta = torch.zeros(out_ch, device=device, dtype=dtype)
        rm = bn.running_mean.detach().to(device=device, dtype=dtype)
        rv = bn.running_var.detach().to(device=device, dtype=dtype)
        eps = bn.eps
        a = gamma / torch.sqrt(rv + eps)
        b = beta - a * rm
        bias_old = deconv.bias.detach() if deconv.bias is not None else torch.zeros(out_ch, device=device, dtype=dtype)
        bias_new = a * bias_old + b
        w_old = deconv.weight.detach().clone()  # (in_ch, out_ch//groups, kh, kw)
        kh, kw = w_old.shape[2], w_old.shape[3]
        # vectorized using kron: build a matrix mapping each (i, local_o) to a global output index
        out_per_group = out_ch // groups
        in_per_group = in_ch // groups
        # construct a tensor of shape (in_ch, out_per_group) containing corresponding global out index
        # For input channel i, group g_i = i // in_per_group
        g_idx = (torch.arange(in_ch, device=device) // in_per_group).unsqueeze(1)  # (in_ch,1)
        local_o_idx = torch.arange(out_per_group, device=device).unsqueeze(0)  # (1,out_per_group)
        global_out_idx = (g_idx * out_per_group) + local_o_idx  # (in_ch, out_per_group)
        # map a values per position
        a_expand = a[global_out_idx]  # (in_ch, out_per_group)
        a_expand = a_expand.view(in_ch, out_per_group, 1, 1)
        w_new = w_old * a_expand
        fused = nn.ConvTranspose2d(
            in_channels=deconv.in_channels,
            out_channels=deconv.out_channels,
            kernel_size=deconv.kernel_size,
            stride=deconv.stride,
            padding=deconv.padding,
            output_padding=deconv.output_padding,
            groups=deconv.groups,
            dilation=deconv.dilation,
            bias=True
        ).to(device=device, dtype=dtype)
        fused.weight.data.copy_(w_new)
        fused.bias.data.copy_(bias_new)
        return fused
