
def validate_user_id(user_id):
    from string import ascii_letters, digits
    _allowed_rest = set(ascii_letters + digits + '_')
    _letters = set(ascii_letters)
    def validate_user_id(user_id):
        if not isinstance(user_id, str) or not user_id:
            return False
        if user_id[0] not in _letters:
            return False
        return set(user_id[1:]).issubset(_allowed_rest)
