
def bbox_ioa(box1, box2, iou=False, eps=1e-7):
    import numpy as np
    def bbox_ioa(box1, box2, iou=False, eps=1e-7):
        b1 = np.asarray(box1, dtype=float)
        b2 = np.asarray(box2, dtype=float)
        if b1.ndim == 1:
            b1 = b1.reshape(1, 4)
        if b2.ndim == 1:
            b2 = b2.reshape(1, 4)
        n = b1.shape[0]
        m = b2.shape[0]
        if n == 0 or m == 0:
            return np.zeros((n, m), dtype=float)
        x1 = np.maximum.outer(b1[:, 0], b2[:, 0])
        y1 = np.maximum.outer(b1[:, 1], b2[:, 1])
        x2 = np.minimum.outer(b1[:, 2], b2[:, 2])
        y2 = np.minimum.outer(b1[:, 3], b2[:, 3])
        w = np.clip(x2 - x1, 0, None)
        h = np.clip(y2 - y1, 0, None)
        inter = w * h
        area1 = np.clip((b1[:, 2] - b1[:, 0]) * (b1[:, 3] - b1[:, 1]), 0, None)
        area2 = np.clip((b2[:, 2] - b2[:, 0]) * (b2[:, 3] - b2[:, 1]), 0, None)
        if iou:
            denom = area1[:, None] + area2[None, :] - inter + eps
        else:
            denom = area2[None, :] + eps
        return inter / denom
