
def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        """
        Projects 3D coordinates onto planes by iterating planes (vectorized per-plane mm).
        """
        N, M, _ = coordinates.shape
        coords_flat = coordinates.reshape(-1, 3)  # (N*M, 3)
        projs = []
        for i in range(planes.shape[0]):
            axis2 = planes[i, :, :2]  # (3,2)
            p = coords_flat @ axis2  # (N*M, 2)
            projs.append(p.view(N, M, 2))
        stacked = torch.stack(projs, dim=1)  # (N, n_planes, M, 2)
        n_planes = planes.shape[0]
        return stacked.reshape(N * n_planes, M, 2)
