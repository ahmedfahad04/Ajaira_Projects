
def hole_fill(img):
    import numpy as np
    import cv2
    from collections import deque
    def hole_fill(img):
        arr = np.array(img)
        if arr.size == 0:
            return arr.copy()
        orig_dtype = arr.dtype
        max_val = int(arr.max())
        if max_val == 0:
            return arr.copy()
        bin_img = (arr > 0).astype('uint8')
        h, w = bin_img.shape[:2]
        visited = np.zeros((h, w), dtype=bool)
        q = deque()
        # enqueue all border background pixels
        for x in range(w):
            if bin_img[0, x] == 0:
                visited[0, x] = True
                q.append((0, x))
            if bin_img[h-1, x] == 0:
                visited[h-1, x] = True
                q.append((h-1, x))
        for y in range(h):
            if bin_img[y, 0] == 0:
                visited[y, 0] = True
                q.append((y, 0))
            if bin_img[y, w-1] == 0:
                visited[y, w-1] = True
                q.append((y, w-1))
        # 4-connected BFS to mark external background
        while q:
            y, x = q.popleft()
            for dy, dx in ((1,0),(-1,0),(0,1),(0,-1)):
                ny, nx = y+dy, x+dx
                if 0 <= ny < h and 0 <= nx < w and not visited[ny, nx] and bin_img[ny, nx] == 0:
                    visited[ny, nx] = True
                    q.append((ny, nx))
        # visited==True are external background; zeros with visited==False are holes -> fill them
        filled = bin_img.copy()
        holes_mask = (bin_img == 0) & (~visited)
        filled[holes_mask] = 1
        result = (filled * max_val).astype(orig_dtype)
        return result
