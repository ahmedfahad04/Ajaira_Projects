
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        if divisor is None:
            raise ValueError("divisor must be provided")
        if torch.is_tensor(divisor):
            d_val = divisor.max().item()
        else:
            d_val = divisor
        if d_val == 0:
            raise ValueError("divisor must be non-zero")
        d = abs(int(d_val))
        q = float(x) / d
        floor_k = math.floor(q)
        ceil_k = math.ceil(q)
        floor_mult = floor_k * d
        ceil_mult = ceil_k * d
        # choose the closer one; if tie choose the higher (ceil)
        if abs(x - ceil_mult) <= abs(x - floor_mult):
            return int(ceil_mult)
        else:
            return int(floor_mult)
