
def check_all_columns_numeric(df):
    import pandas as pd
    import numpy as np
    def check_all_columns_numeric(df):
        if df is None:
            return False
        try:
            return df.select_dtypes(include=[np.number]).shape[1] == df.shape[1]
        except Exception:
            return False
