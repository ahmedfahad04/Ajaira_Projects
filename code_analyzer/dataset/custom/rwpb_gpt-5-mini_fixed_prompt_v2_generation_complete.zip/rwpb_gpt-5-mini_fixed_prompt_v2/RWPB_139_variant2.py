
def rotate_normalmap_by_angle_torch(normal_map, angle):
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        import torch
        device = normal_map.device
        dtype = normal_map.dtype
        theta = angle * 3.141592653589793 / 180.0
        c = torch.tensor([[torch.cos(torch.tensor(theta)), 0.0, torch.sin(torch.tensor(theta))],
                          [0.0, 1.0, 0.0],
                          [-torch.sin(torch.tensor(theta)), 0.0, torch.cos(torch.tensor(theta))]],
                         device=device, dtype=dtype)
        flat = normal_map.contiguous().view(-1, 3)
        rotated = flat @ c.t()
        rotated = rotated.view(normal_map.shape)
        norm = torch.sqrt((rotated * rotated).sum(dim=-1, keepdim=True))
        eps = torch.tensor(1e-8, device=device, dtype=dtype)
        rotated = rotated / (norm + eps)
        return rotated
