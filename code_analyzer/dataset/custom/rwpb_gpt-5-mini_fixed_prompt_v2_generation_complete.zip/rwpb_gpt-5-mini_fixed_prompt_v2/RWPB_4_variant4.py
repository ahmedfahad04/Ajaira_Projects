
def rot6d_to_rotmat(x):
    def rot6d_to_rotmat(x):
        import torch
        import numpy as np
        if not torch.is_tensor(x):
            x = torch.tensor(x)
        if x.dim() != 2 or x.shape[1] != 6:
            raise ValueError("Input must have shape (B,6)")
        device = x.device
        dtype = x.dtype
        x_np = x.detach().cpu().numpy()
        B = x_np.shape[0]
        R_np = np.zeros((B, 3, 3), dtype=np.float64)
        for i in range(B):
            a1 = x_np[i, 0:3]
            a2 = x_np[i, 3:6]
            n1 = np.linalg.norm(a1)
            if n1 == 0:
                b1 = a1
            else:
                b1 = a1 / n1
            proj = np.dot(b1, a2)
            a2_orth = a2 - proj * b1
            n2 = np.linalg.norm(a2_orth)
            if n2 == 0:
                b2 = a2_orth
            else:
                b2 = a2_orth / n2
            b3 = np.cross(b1, b2)
            R_np[i] = np.column_stack((b1, b2, b3))
        return torch.from_numpy(R_np).to(device=device, dtype=dtype)
