
def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        # Manual trilinear interpolation, vectorized
        if grid.ndim != 5:
            raise ValueError("grid must be 5D tensor (1, C, H, W, D)")
        Ng, C, H, W, D = grid.shape
        if Ng != 1:
            raise ValueError("grid first dim must be 1")
        batch_size, num_points, dim3 = coordinates.shape
        if dim3 != 3:
            raise ValueError("coordinates last dim must be 3")
        device = grid.device
        grid_tensor = grid[0].permute(0, 3, 1, 2).contiguous()  # -> (C, D, H, W) from (C,H,W,D)
        # grid_tensor: (C, D, H, W)
        coords = coordinates.clone().to(torch.float32).to(device)
        minc, maxc = coords.min().item(), coords.max().item()
        # interpret coords: normalized (-1..1) or absolute (x in [0,W-1], y in [0,H-1], z in [0,D-1])
        if minc >= -1.0 - 1e-6 and maxc <= 1.0 + 1e-6:
            # normalized
            x = (coords[..., 0] + 1.0) / 2.0 * (W - 1)
            y = (coords[..., 1] + 1.0) / 2.0 * (H - 1)
            z = (coords[..., 2] + 1.0) / 2.0 * (D - 1)
        else:
            x = coords[..., 0]
            y = coords[..., 1]
            z = coords[..., 2]
        # Flatten points
        x = x.reshape(-1)
        y = y.reshape(-1)
        z = z.reshape(-1)
        # Get integer corners
        x0 = torch.floor(x).long().clamp(0, W - 1)
        x1 = (x0 + 1).clamp(0, W - 1)
        y0 = torch.floor(y).long().clamp(0, H - 1)
        y1 = (y0 + 1).clamp(0, H - 1)
        z0 = torch.floor(z).long().clamp(0, D - 1)
        z1 = (z0 + 1).clamp(0, D - 1)
        # Fractional parts
        xd = (x - x0.float()).unsqueeze(0)  # (1, M)
        yd = (y - y0.float()).unsqueeze(0)
        zd = (z - z0.float()).unsqueeze(0)
        # For advanced indexing, grid_tensor shape (C, D, H, W)
        def vals_at(ix, iy, iz):
            # ix,iy,iz are (M,) long tensors
            return grid_tensor[:, iz, iy, ix]  # returns (C, M)
        v000 = vals_at(x0, y0, z0)
        v100 = vals_at(x1, y0, z0)
        v010 = vals_at(x0, y1, z0)
        v110 = vals_at(x1, y1, z0)
        v001 = vals_at(x0, y0, z1)
        v101 = vals_at(x1, y0, z1)
        v011 = vals_at(x0, y1, z1)
        v111 = vals_at(x1, y1, z1)
        # Trilinear interpolation
        c00 = v000 * (1 - xd) + v100 * xd
        c01 = v001 * (1 - xd) + v101 * xd
        c10 = v010 * (1 - xd) + v110 * xd
        c11 = v011 * (1 - xd) + v111 * xd
        c0 = c00 * (1 - yd) + c10 * yd
        c1 = c01 * (1 - yd) + c11 * yd
        c = c0 * (1 - zd) + c1 * zd  # (C, M)
        # Reshape to (batch, num_points, C)
        M = batch_size * num_points
        c = c.permute(1, 0).contiguous().view(batch_size, num_points, C)
        return c
