
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        # Rectangular expansion preserving original aspect ratio; s returned as half of the larger side.
        if box is None:
            raise ValueError("box cannot be None")
        if expand <= 0:
            raise ValueError("expand must be positive")
        x, y, x1, y1 = box
        x = float(x); y = float(y); x1 = float(x1); y1 = float(y1)
        w = x1 - x
        h = y1 - y
        cx = x + w / 2.0
        cy = y + h / 2.0
        new_w = w * float(expand)
        new_h = h * float(expand)
        s = max(new_w, new_h) / 2.0
        # Use the expanded widths/heights directly (rectangular)
        new_x = cx - new_w / 2.0
        new_y = cy - new_h / 2.0
        new_x1 = cx + new_w / 2.0
        new_y1 = cy + new_h / 2.0
        return [new_x, new_y, new_x1, new_y1], s
