
def check(x, checksum_token):
    import re
    import hashlib
    def check(x, checksum_token):
        pattern = re.compile(r'(?<![0-9a-fA-F])([0-9a-fA-F]{64})(?![0-9a-fA-F])')
        m = None
        for mm in pattern.finditer(x):
            m = mm
        if m is None:
            return False
        original = m.group(1)
        start, end = m.start(1), m.end(1)
        replaced = x[:start] + checksum_token + x[end:]
        digest = hashlib.sha256(replaced.encode()).hexdigest()
        return digest.lower() == original.lower()
