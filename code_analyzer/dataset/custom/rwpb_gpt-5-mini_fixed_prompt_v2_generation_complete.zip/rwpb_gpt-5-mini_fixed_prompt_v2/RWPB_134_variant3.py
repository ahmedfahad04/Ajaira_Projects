
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return None
        try:
            ow, oh = original_size
        except Exception:
            return None
        # choose resolution with minimal scaling factor required: max(w/ow, h/oh)
        # prefer scale <= 1 (downscale) and larger area among them
        best = None
        best_score = None
        for w, h in possible_resolutions:
            # handle zero original dims
            if ow == 0 or oh == 0:
                scale = float('inf')
            else:
                scale = max(w / ow, h / oh)
            area = w * h
            # primary: scale (smaller better). secondary: if scale<=1 prefer larger area, else prefer smaller area
            if scale <= 1:
                key = (scale, -area, abs(w - ow) + abs(h - oh))
            else:
                key = (scale, area, abs(w - ow) + abs(h - oh))
            if best_score is None or key < best_score:
                best_score = key
                best = (w, h)
        return best
