
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        if not isinstance(image, np.ndarray):
            raise ValueError("Input must be a numpy array.")
        if image.ndim == 2:
            h, w = image.shape
            out = np.empty((1, h, w), dtype=np.float32)
            out[0] = image.astype(np.float32)
        elif image.ndim == 3:
            h, w, c = image.shape
            out = np.empty((c, h, w), dtype=np.float32)
            for i in range(c):
                out[i] = image[:, :, i].astype(np.float32)
        else:
            raise ValueError("Input is not a valid image (expected 2D or 3D).")
        out /= 255.0
        return torch.from_numpy(out)
