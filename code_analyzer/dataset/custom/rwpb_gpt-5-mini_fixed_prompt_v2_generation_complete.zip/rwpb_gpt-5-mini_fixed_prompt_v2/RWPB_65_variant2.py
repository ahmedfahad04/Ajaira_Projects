
def merge_dicts_recursively(*dicts):
    from functools import reduce
    from collections.abc import Mapping
    def _merge_two(a, b):
        res = dict(a) if isinstance(a, Mapping) else {}
        for k, v in (b.items() if isinstance(b, Mapping) else []):
            if k in res and isinstance(res[k], Mapping) and isinstance(v, Mapping):
                res[k] = _merge_two(res[k], v)
            else:
                res[k] = v
        return res
    def merge_dicts_recursively(*dicts):
        dicts = [d for d in dicts if isinstance(d, Mapping)]
        return reduce(_merge_two, dicts, {})
