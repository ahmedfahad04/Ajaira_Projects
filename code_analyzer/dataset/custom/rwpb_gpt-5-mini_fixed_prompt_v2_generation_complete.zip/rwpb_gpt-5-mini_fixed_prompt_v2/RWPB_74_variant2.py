
def arccos2(vector, value):
    import math
    import numpy as np
    def arccos2(vector, value):
        vec = np.asarray(vector, dtype=float)
        v = float(value)
        v = np.clip(v, -1.0, 1.0)
        angle = float(np.arccos(v))
        if np.linalg.norm(vec) < 1e-12:
            return angle
        if vec[1] < 0.0:
            angle = 2.0 * math.pi - angle
        return float(angle)
