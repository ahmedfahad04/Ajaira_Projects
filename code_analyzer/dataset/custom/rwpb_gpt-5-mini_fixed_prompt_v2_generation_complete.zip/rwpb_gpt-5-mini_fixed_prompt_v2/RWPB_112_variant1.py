
def submatrix(matrix, col):
    def submatrix(matrix, col):
        """
        Removes the column at index col from each row of matrix.
        Handles negative indices per-row (like Python indexing).
        """
        result = []
        for row in matrix:
            # normalize col for this row length
            if col >= 0:
                idx = col
            else:
                idx = len(row) + col
            if idx < 0 or idx >= len(row):
                raise IndexError("col index out of range")
            result.append(row[:idx] + row[idx+1:])
        return result
