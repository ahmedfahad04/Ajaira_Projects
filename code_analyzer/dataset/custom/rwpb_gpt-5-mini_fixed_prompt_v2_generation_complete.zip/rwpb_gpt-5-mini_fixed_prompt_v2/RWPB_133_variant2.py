
def divide_to_patches(image, patch_size):
    from PIL import Image
    import numpy as np
    def divide_to_patches(image, patch_size):
        arr = np.array(image)
        h, w = arr.shape[0], arr.shape[1]
        patches = []
        for y in range(0, h, patch_size):
            for x in range(0, w, patch_size):
                sub = arr[y:y+patch_size, x:x+patch_size].copy()
                patches.append(Image.fromarray(sub))
        return patches
