
def round_nearest_multiple(number, a, direction='standard'):
    from fractions import Fraction
    def round_nearest_multiple(number, a, direction='standard'):
        if a == 0:
            raise ValueError("a must be non-zero")
        dir_lower = (direction or 'standard').lower()
        frac_num = Fraction(str(number))
        frac_a = Fraction(str(a))
        ratio = frac_num / frac_a
        num = ratio.numerator
        den = ratio.denominator
        if dir_lower == 'down':
            n = num // den
        elif dir_lower == 'up':
            n = -((-num) // den)
        elif dir_lower == 'standard':
            base = num // den
            rem = abs(num - base * den)
            if rem * 2 >= den:
                if num >= 0:
                    n = base + 1
                else:
                    n = base - 1
            else:
                n = base
        else:
            raise ValueError("direction must be 'standard', 'down' or 'up'")
        result_frac = frac_a * n
        result = float(result_frac)
        s = str(a)
        if 'e' in s or 'E' in s:
            s = format(float(a), 'f')
        if '.' in s:
            dec = len(s.split('.')[1].rstrip('0'))
        else:
            dec = 0
        fmt = f"{{0:.{dec}f}}"
        return float(fmt.format(result))
