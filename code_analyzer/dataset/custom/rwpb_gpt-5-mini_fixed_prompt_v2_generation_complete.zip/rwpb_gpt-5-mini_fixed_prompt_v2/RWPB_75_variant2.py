
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na == 0 or nb == 0:
            return (None, None)
        a = a / na
        b = b / nb
        cross = np.cross(a, b)
        cross_norm = np.linalg.norm(cross)
        dot = np.dot(a, b)
        dot = np.clip(dot, -1.0, 1.0)
        eps = 1e-10
        # angle using atan2 for stability
        angle = float(np.arctan2(cross_norm, dot))
        if cross_norm < eps:
            if dot > 0:
                return (None, None)
            else:
                # anti-parallel: construct orthogonal axis via Gram-Schmidt
                basis = np.array([1.0, 0.0, 0.0])
                proj = basis - np.dot(basis, a) * a
                if np.linalg.norm(proj) < 1e-8:
                    basis = np.array([0.0, 1.0, 0.0])
                    proj = basis - np.dot(basis, a) * a
                axis = proj / np.linalg.norm(proj)
                return (axis, float(np.pi))
        axis = cross / cross_norm
        return (axis, angle)
