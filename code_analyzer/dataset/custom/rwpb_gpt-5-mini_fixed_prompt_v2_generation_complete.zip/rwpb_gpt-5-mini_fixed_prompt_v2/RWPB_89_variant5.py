
def format_ratio(ratio):
    from fractions import Fraction
    import math
    def format_ratio(ratio):
        r = float(ratio)
        if math.isnan(r):
            return "percentage:NaN"
        if math.isinf(r):
            return f"percentage:{r}"
        frac = Fraction(r).limit_denominator()
        truncated = math.trunc(frac * 1000) / 1000.0
        return "percentage:" + f"{truncated:.3f}"
