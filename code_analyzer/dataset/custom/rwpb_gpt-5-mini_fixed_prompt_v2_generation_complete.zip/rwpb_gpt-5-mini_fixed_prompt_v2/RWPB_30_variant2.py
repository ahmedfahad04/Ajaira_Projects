
def get_confusion_matrix(gt_label, pred_label, num_classes):
    import numpy as np
    def get_confusion_matrix(gt_label, pred_label, num_classes):
        if not isinstance(num_classes, int) or num_classes <= 0:
            raise ValueError("num_classes must be a positive integer")
        gt = np.asarray(gt_label)
        pred = np.asarray(pred_label)
        if gt.shape[0] != pred.shape[0]:
            raise ValueError("gt_label and pred_label must have the same length")
        if gt.size == 0:
            return np.zeros((num_classes, num_classes), dtype=int)
        # ensure integer arrays
        try:
            gt_i = gt.astype(int)
            pred_i = pred.astype(int)
        except Exception:
            raise ValueError("Labels must be integer-valued")
        if np.any(gt_i != gt) or np.any(pred_i != pred):
            raise ValueError("Labels must be integer-valued")
        if gt_i.min() < 0 or pred_i.min() < 0 or gt_i.max() >= num_classes or pred_i.max() >= num_classes:
            raise ValueError("Labels must be in the range [0, num_classes-1]")
        cm = np.zeros((num_classes, num_classes), dtype=int)
        # use numpy advanced indexing accumulator
        np.add.at(cm, (gt_i, pred_i), 1)
        return cm
