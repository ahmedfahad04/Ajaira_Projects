
def fit_params(:
    def fit_params(
        x,
        y,
        fun,
        a_range=(-10, 10),
        b_range=(-10, 10),
        grid_number=101,
        iteration=3,
        verbose=True,
    ):
        import torch as _torch
        import numpy as _np
        # Use gradient-based optimization on torch tensors for a,b,c,d
        is_torch = _torch.is_tensor(x) or _torch.is_tensor(y)
        if not is_torch:
            x_t = _torch.tensor(_np.asarray(x).astype(float))
            y_t = _torch.tensor(_np.asarray(y).astype(float))
        else:
            x_t = x.clone().detach()
            y_t = y.clone().detach()
        device = x_t.device
        dtype = x_t.dtype
        a_lo, a_hi = float(a_range[0]), float(a_range[1])
        b_lo, b_hi = float(b_range[0]), float(b_range[1])
        best_params = None
        best_r2 = -1e9
        for it in range(iteration):
            # random restarts in this window
            for restart in range(3):
                a0 = _torch.tensor((a_lo + a_hi) / 2.0, dtype=dtype, device=device) + 0.1 * _torch.randn(1, dtype=dtype, device=device)
                b0 = _torch.tensor((b_lo + b_hi) / 2.0, dtype=dtype, device=device) + 0.1 * _torch.randn(1, dtype=dtype, device=device)
                c0 = _torch.tensor(1.0, dtype=dtype, device=device) + 0.1 * _torch.randn(1, dtype=dtype, device=device)
                d0 = _torch.tensor(0.0, dtype=dtype, device=device) + 0.1 * _torch.randn(1, dtype=dtype, device=device)
                a = a0.clone().detach().requires_grad_(True)
                b = b0.clone().detach().requires_grad_(True)
                c = c0.clone().detach().requires_grad_(True)
                d = d0.clone().detach().requires_grad_(True)
                opt = _torch.optim.Adam([a, b, c, d], lr=0.05)
                for step in range(300):
                    opt.zero_grad()
                    try:
                        out = fun(a * x_t + b)
                    except Exception:
                        out = _torch.tensor([fun(v.item()) for v in (a * x_t + b)], dtype=dtype, device=device)
                    pred = c * out + d
                    loss = ((pred - y_t) ** 2).mean()
                    loss.backward()
                    opt.step()
                    # simple clamping to stay in window
                    with _torch.no_grad():
                        a.clamp_(a_lo - 2 * abs(a_lo - a_hi), a_hi + 2 * abs(a_lo - a_hi))
                        b.clamp_(b_lo - 2 * abs(b_lo - b_hi), b_hi + 2 * abs(b_lo - b_hi))
                # evaluate r2
                with _torch.no_grad():
                    out = fun(a * x_t + b)
                    pred = c * out + d
                    ss_res = ((y_t - pred) ** 2).sum().item()
                    ss_tot = ((y_t - y_t.mean()) ** 2).sum().item()
                    if ss_tot == 0:
                        r2 = 1.0 if ss_res == 0 else 0.0
                    else:
                        r2 = 1.0 - ss_res / ss_tot
                    if r2 > best_r2:
                        best_r2 = r2
                        best_params = (a.detach().item(), b.detach().item(), c.detach().item(), d.detach().item())
            # refine search window around best
            if best_params is not None:
                a_best, b_best, _, _ = best_params
                a_span = (a_hi - a_lo) / max(10.0, grid_number - 1)
                b_span = (b_hi - b_lo) / max(10.0, grid_number - 1)
                a_lo = a_best - a_span
                a_hi = a_best + a_span
                b_lo = b_best - b_span
                b_hi = b_best + b_span
        if verbose:
            print("r2 is", best_r2)
        if is_torch:
            return (_torch.tensor(best_params[0]), _torch.tensor(best_params[1]), _torch.tensor(best_params[2]), _torch.tensor(best_params[3]), _torch.tensor(best_r2))
        else:
            return best_params[0], best_params[1], best_params[2], best_params[3], best_r2
