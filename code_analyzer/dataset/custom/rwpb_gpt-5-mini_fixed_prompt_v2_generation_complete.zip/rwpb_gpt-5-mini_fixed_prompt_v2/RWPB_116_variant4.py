
def round_nearest_multiple(number, a, direction='standard'):
    import numpy as np
    def round_nearest_multiple(number, a, direction='standard'):
        if a == 0:
            raise ValueError("a must be non-zero")
        dir_lower = (direction or 'standard').lower()
        ratio = number / a
        if dir_lower == 'standard':
            k = int(np.rint(ratio))
        elif dir_lower == 'down':
            k = int(np.floor(ratio))
        elif dir_lower == 'up':
            k = int(np.ceil(ratio))
        else:
            raise ValueError("direction must be 'standard', 'down' or 'up'")
        result = k * a
        s = format(a, 'f')
        if '.' in s:
            dec = len(s.split('.')[1].rstrip('0'))
        else:
            dec = 0
        fmt = f"{{0:.{dec}f}}"
        return float(fmt.format(result))
