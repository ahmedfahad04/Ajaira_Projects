
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        if geometry.size(-1) != 3 or rot.size(-1) != 3 or rot.size(-2) != 3 or trans.size(-1) != 3:
            raise ValueError("Input must have last dim 3")
        rot_t = rot.transpose(1, 2)
        out = torch.einsum('bnk,bkj->bnj', geometry, rot_t)
        out = out + trans.unsqueeze(1)
        return out
