
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        old = tensor.size(0)
        if batch_size == old:
            return tensor
        if old == 1:
            return tensor.expand(batch_size, *tensor.shape[1:]).clone()
        device = tensor.device
        pos = torch.linspace(0.0, float(old - 1), steps=batch_size, device=device)
        out_list = []
        for p in pos:
            # For a reduction, choose nearest integer index; for expansion, interpolate
            if batch_size < old:
                idx = int(math.floor(p.item() + 0.5))
                idx = max(0, min(old - 1, idx))
                out_list.append(tensor[idx])
            else:
                # interpolate between floor and ceil
                low_i = int(math.floor(p.item()))
                high_i = int(math.ceil(p.item()))
                low_i = max(0, min(old - 1, low_i))
                high_i = max(0, min(old - 1, high_i))
                w = p.item() - math.floor(p.item())
                if low_i == high_i or w == 0.0:
                    out_list.append(tensor[low_i])
                else:
                    out_list.append((1.0 - w) * tensor[low_i] + w * tensor[high_i])
        return torch.stack(out_list, dim=0)
