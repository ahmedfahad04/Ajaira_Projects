
def merge_dicts_recursively(*dicts):
    from copy import deepcopy
    from collections.abc import Mapping
    def merge_dicts_recursively(*dicts):
        result = {}
        for d in dicts:
            if not isinstance(d, Mapping):
                continue
            for k, v in d.items():
                if k in result and isinstance(result[k], Mapping) and isinstance(v, Mapping):
                    result[k] = merge_dicts_recursively(result[k], v)
                else:
                    result[k] = deepcopy(v)
        return result
