
def get_line_angle(x1, y1, x2, y2):
    import math
    def get_line_angle(x1, y1, x2, y2):
        dx = x2 - x1
        dy = y2 - y1
        if dx == 0:
            if dy > 0:
                return 90.0
            if dy < 0:
                return 270.0
            return 0.0
        slope = dy / dx
        angle = math.degrees(math.atan(slope))
        if dx < 0:
            angle += 180.0
        angle %= 360.0
        return angle
