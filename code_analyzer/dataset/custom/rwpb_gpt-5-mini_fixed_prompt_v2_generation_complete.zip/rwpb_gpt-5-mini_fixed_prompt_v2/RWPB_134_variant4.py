
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return None
        try:
            ow, oh = original_size
        except Exception:
            return None
        # choose based on normalized Euclidean distance in width/height space
        # normalize by original to get relative error; handle zero original dims
        def dist(wh):
            w, h = wh
            if ow == 0 or oh == 0:
                # fallback to area difference
                return abs(w * h - ow * oh), abs(w - ow) + abs(h - oh)
            dx = (w - ow) / ow
            dy = (h - oh) / oh
            d = dx * dx + dy * dy
            # prefer downscales slightly when distances tie
            scale = max(w / ow if ow else float('inf'), h / oh if oh else float('inf'))
            return (d, 0 if scale <= 1 else 1, abs(w - ow) + abs(h - oh))
        return min(possible_resolutions, key=dist)
