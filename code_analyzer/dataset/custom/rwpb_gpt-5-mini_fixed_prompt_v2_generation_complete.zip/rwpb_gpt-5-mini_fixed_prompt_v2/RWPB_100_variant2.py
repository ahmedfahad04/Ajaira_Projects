
def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        """
        Projects 3D coordinates onto planes using torch.tensordot.
        """
        N, M, _ = coordinates.shape
        axes = planes[..., :2]  # (n_planes, 3, 2)
        tens = torch.tensordot(coordinates, axes, dims=([2], [1]))  # (N, M, n_planes, 2)
        tens = tens.permute(0, 2, 1, 3)  # (N, n_planes, M, 2)
        n_planes = axes.shape[0]
        return tens.reshape(N * n_planes, M, 2)
