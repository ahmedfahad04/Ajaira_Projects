
def fit_params(:
    def fit_params(
        x,
        y,
        fun,
        a_range=(-10, 10),
        b_range=(-10, 10),
        grid_number=101,
        iteration=3,
        verbose=True,
    ):
        import numpy as _np
        import torch as _torch
        import math as _math
        is_torch = _torch.is_tensor(x) or _torch.is_tensor(y)
        if is_torch:
            x_arr = _torch.flatten(x).detach().cpu().numpy() if _torch.is_tensor(x) else _np.asarray(x)
            y_arr = _torch.flatten(y).detach().cpu().numpy() if _torch.is_tensor(y) else _np.asarray(y)
        else:
            x_arr = _np.asarray(x).astype(float)
            y_arr = _np.asarray(y).astype(float)
        # Monte Carlo random sampling then local grid refinement
        a_lo, a_hi = float(a_range[0]), float(a_range[1])
        b_lo, b_hi = float(b_range[0]), float(b_range[1])
        def fit_cd(yv, fv):
            ym = yv.mean()
            fm = fv.mean()
            num = ((yv - ym) * (fv - fm)).sum()
            den = ((fv - fm) ** 2).sum()
            if abs(den) < 1e-12:
                c = 0.0
                d = ym
            else:
                c = num / den
                d = ym - c * fm
            ss_res = ((yv - (c * fv + d)) ** 2).sum()
            ss_tot = ((yv - ym) ** 2).sum()
            if ss_tot == 0:
                r2 = 1.0 if ss_res == 0 else 0.0
            else:
                r2 = 1.0 - ss_res / ss_tot
            return c, d, r2
        best = (None, None, None, None, -1e9)
        rng = _np.random.RandomState(12345)
        for it in range(iteration):
            # random sample M points
            M = max(200, grid_number * grid_number // 3)
            a_s = rng.uniform(a_lo, a_hi, size=M)
            b_s = rng.uniform(b_lo, b_hi, size=M)
            for a, b in zip(a_s, b_s):
                z = a * x_arr + b
                try:
                    F = fun(z)
                    if _torch.is_tensor(F):
                        F = F.detach().cpu().numpy()
                except Exception:
                    F = _np.array([fun(v) for v in z])
                c, d, r2 = fit_cd(y_arr, F)
                if r2 > best[4]:
                    best = (a, b, c, d, r2)
            # local grid around best
            a_best, b_best, _, _, _ = best
            span_a = max(1e-6, (a_hi - a_lo) / 10.0)
            span_b = max(1e-6, (b_hi - b_lo) / 10.0)
            a_lo = a_best - span_a
            a_hi = a_best + span_a
            b_lo = b_best - span_b
            b_hi = b_best + span_b
        if verbose:
            print("r2 is", best[4])
        if is_torch:
            import torch as _t
            return (_t.tensor(best[0]), _t.tensor(best[1]), _t.tensor(best[2]), _t.tensor(best[3]), _t.tensor(best[4]))
        else:
            return best[0], best[1], best[2], best[3], best[4]
