
def B_batch(x, grid, k=0, extend=True, device="cpu"):
    import torch
    def B_batch(x, grid, k=0, extend=True, device="cpu"):
        x = x.to(device)
        grid = grid.to(device)
        num_spline, num_sample = x.shape
        _, m = grid.shape
        p = int(k)
        results = []
        for s in range(num_spline):
            g = grid[s]
            if m < 2:
                # degenerate: no intervals
                n_bases = max(0, m + p - 1)
                results.append(torch.zeros((n_bases, num_sample), device=device, dtype=x.dtype))
                continue
            if extend:
                left_diff = (g[1] - g[0])
                right_diff = (g[-1] - g[-2])
                if left_diff == 0:
                    pre = g[0] - torch.arange(p, 0, -1, device=device, dtype=g.dtype) * 1.0
                else:
                    pre = g[0] - torch.arange(p, 0, -1, device=device, dtype=g.dtype) * left_diff
                if right_diff == 0:
                    post = g[-1] + torch.arange(1, p+1, device=device, dtype=g.dtype) * 1.0
                else:
                    post = g[-1] + torch.arange(1, p+1, device=device, dtype=g.dtype) * right_diff
                T = torch.cat([pre, g, post])
            else:
                pre = g[0].repeat(p)
                post = g[-1].repeat(p)
                T = torch.cat([pre, g, post])
            n_T = T.shape[0]
            n_bases = m + p - 1
            S = num_sample
            # initial B (degree 0) for i in 0..n_T-2
            B = torch.zeros((n_T - 1, S), device=device, dtype=x.dtype)
            xs = x[s].unsqueeze(0)  # (1, S)
            # indicator: T[i] <= x < T[i+1], except for the very last knot
            lefts = T[:-1].unsqueeze(1)  # (n_T-1,1)
            rights = T[1:].unsqueeze(1)
            # use left <= x < right, with special case include rightmost endpoint
            mask = (xs >= lefts) & (xs < rights)
            B[:,:] = mask.type_as(B)
            # include equality at last knot
            last_knot = T[-1]
            if torch.any(xs == last_knot):
                idxs = (xs == last_knot).squeeze(0)
                B[n_T - 2, idxs] = 1.0
            # Cox-de Boor recursion
            for r in range(1, p+1):
                B_new = torch.zeros((n_T - 1 - r, S), device=device, dtype=x.dtype)
                for i in range(0, n_T - 1 - r):
                    denom1 = T[i + r] - T[i]
                    denom2 = T[i + r + 1] - T[i + 1]
                    # compute left term
                    if denom1 == 0:
                        left_term = 0.0
                    else:
                        coeff1 = (xs - T[i]) / denom1
                        left_term = coeff1 * B[i]
                    if denom2 == 0:
                        right_term = 0.0
                    else:
                        coeff2 = (T[i + r + 1] - xs) / denom2
                        right_term = coeff2 * B[i + 1]
                    B_new[i] = left_term + right_term
                B = B_new
            # after loop, B has shape (n_bases, S)
            results.append(B[:n_bases])
        return torch.stack(results, dim=0)
