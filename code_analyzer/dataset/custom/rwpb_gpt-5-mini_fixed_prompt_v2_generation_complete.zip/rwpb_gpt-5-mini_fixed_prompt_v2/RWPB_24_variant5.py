
def check(x, checksum_token):
    import re
    import hashlib
    def check(x, checksum_token):
        pat = r'[0-9a-fA-F]{64}'
        m = re.search(pat, x)
        if not m:
            return False
        original = m.group(0)
        # replace only the first occurrence
        replaced = re.sub(pat, checksum_token, x, count=1)
        digest = hashlib.sha256(replaced.encode('utf-8')).hexdigest()
        return digest.lower() == original.lower()
