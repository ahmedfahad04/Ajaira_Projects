
def crop_mask(masks, boxes):
    import torch
    def crop_mask(masks, boxes):
        """
        Simple per-sample slicing approach. Sets values outside each box to zero.
        masks: [n, h, w]
        boxes: [n, 4] (x1, y1, x2, y2)
        """
        if masks.ndim != 3:
            raise ValueError("masks must be [n, h, w]")
        n, H, W = masks.shape
        if boxes.shape[0] != n or boxes.shape[1] != 4:
            raise ValueError("boxes must be [n, 4]")
        device = masks.device
        out = torch.zeros_like(masks, device=device)
        boxes_clamped = boxes.clone()
        # Convert to integers (inclusive bounds)
        x1 = torch.floor(boxes_clamped[:, 0]).long()
        y1 = torch.floor(boxes_clamped[:, 1]).long()
        x2 = torch.ceil(boxes_clamped[:, 2]).long()
        y2 = torch.ceil(boxes_clamped[:, 3]).long()
        x1 = x1.clamp(min=0, max=W-1)
        y1 = y1.clamp(min=0, max=H-1)
        x2 = x2.clamp(min=0, max=W-1)
        y2 = y2.clamp(min=0, max=H-1)
        for i in range(n):
            if x2[i] < x1[i] or y2[i] < y1[i]:
                # empty box -> keep zeros
                continue
            out[i, y1[i]:y2[i]+1, x1[i]:x2[i]+1] = masks[i, y1[i]:y2[i]+1, x1[i]:x2[i]+1]
        return out
