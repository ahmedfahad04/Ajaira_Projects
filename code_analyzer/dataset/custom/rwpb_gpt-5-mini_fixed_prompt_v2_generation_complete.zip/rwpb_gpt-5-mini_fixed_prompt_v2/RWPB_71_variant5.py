
def getLambertCoefs(numOfLambertCoefs):
    from math import factorial
    def getLambertCoefs(numOfLambertCoefs):
        if numOfLambertCoefs <= 0:
            return []
        # produce coefficients using pow for integer exponentiation
        coefs = [0.0]
        for n in range(1, numOfLambertCoefs):
            # use built-in pow for exact integer power, then divide
            coef = pow(-n, n - 1) / factorial(n)
            coefs.append(coef)
        if numOfLambertCoefs == 1:
            return coefs[:1]
        return coefs
