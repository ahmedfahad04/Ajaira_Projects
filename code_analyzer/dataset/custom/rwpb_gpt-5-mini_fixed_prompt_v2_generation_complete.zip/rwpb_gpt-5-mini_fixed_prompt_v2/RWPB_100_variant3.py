
def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        """
        Projects 3D coordinates onto planes using batch matrix multiplication.
        """
        N, M, _ = coordinates.shape
        n_planes = planes.shape[0]
        axes = planes[..., :2]  # (n_planes, 3, 2)
        coords_flat = coordinates.reshape(-1, 3)  # (N*M, 3)
        mat = axes.permute(0, 2, 1)  # (n_planes, 2, 3)
        out = torch.matmul(mat, coords_flat.T)  # (n_planes, 2, N*M)
        out = out.permute(2, 0, 1)  # (N*M, n_planes, 2)
        out = out.view(N, M, n_planes, 2)  # (N, M, n_planes, 2)
        out = out.permute(0, 2, 1, 3)  # (N, n_planes, M, 2)
        return out.reshape(N * n_planes, M, 2)
