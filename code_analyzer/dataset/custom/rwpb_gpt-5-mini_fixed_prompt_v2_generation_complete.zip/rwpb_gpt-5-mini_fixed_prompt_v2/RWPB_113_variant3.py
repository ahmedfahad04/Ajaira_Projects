
def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
    import torch
    def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
        start = torch.as_tensor(start)
        stop = torch.as_tensor(stop)
        if num <= 0:
            return torch.empty((0,) + tuple(start.shape), dtype=start.dtype, device=start.device)
        # broadcast shapes
        s_b, t_b = torch.broadcast_tensors(start, stop)
        # ensure float dtype for interpolation
        dtype = torch.result_type(s_b, t_b, torch.tensor(0.0))
        device = s_b.device
        s_b = s_b.to(dtype=dtype, device=device)
        t_b = t_b.to(dtype=dtype, device=device)
        if num == 1:
            return s_b.unsqueeze(0)
        # construct via stacking individual slices
        out_slices = []
        if num == 2:
            fracs = [0.0, 1.0]
        else:
            fracs = [i / (num - 1) for i in range(num)]
        for f in fracs:
            out_slices.append(s_b + (t_b - s_b) * dtype.type(f))
        return torch.stack(out_slices, dim=0)
