
def seconds_to_hh_mm_ss(seconds):
    def seconds_to_hh_mm_ss(seconds):
        from datetime import timedelta
        try:
            total = int(seconds)
        except Exception:
            return "00:00:00"
        if total < 0:
            return "00:00:00"
        td = timedelta(seconds=total)
        hours = td.days * 24 + td.seconds // 3600
        minutes = (td.seconds % 3600) // 60
        secs = td.seconds % 60
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
