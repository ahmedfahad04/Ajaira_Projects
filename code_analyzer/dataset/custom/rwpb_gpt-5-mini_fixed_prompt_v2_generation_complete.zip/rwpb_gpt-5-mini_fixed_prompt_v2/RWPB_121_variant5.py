
def isprime(n):
    import math
    def isprime(n):
        if not isinstance(n, int):
            return False
        if n <= 1:
            return False
        if n % 2 == 0:
            return n == 2
        r = math.isqrt(n)
        return all(n % i for i in range(3, r + 1, 2))
