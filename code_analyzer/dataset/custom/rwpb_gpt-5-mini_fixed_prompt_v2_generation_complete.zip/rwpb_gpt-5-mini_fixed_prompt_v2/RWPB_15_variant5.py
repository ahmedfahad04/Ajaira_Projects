
def cosine_distance(a, b):
    import numpy as np
    import math
    def cosine_distance(a, b):
        a = np.asarray(a).flatten()
        b = np.asarray(b)
        dim = a.shape[0]
        def _dot_norm(x):
            x = np.asarray(x).flatten()
            if x.shape[0] != dim:
                raise KeyError("length mismatch")
            dot = 0.0
            suma = 0.0
            sumb = 0.0
            for ai, bi in zip(a, x):
                dot += float(ai) * float(bi)
                suma += float(ai) * float(ai)
                sumb += float(bi) * float(bi)
            na = math.sqrt(suma)
            nb = math.sqrt(sumb)
            if na == 0 or nb == 0:
                return 1.0
            return 1.0 - (dot / (na * nb))
        if b.ndim == 1:
            return _dot_norm(b)
        elif b.ndim == 2:
            if b.shape[1] == dim:
                res = [ _dot_norm(row) for row in b ]
                return np.array(res)
            elif b.shape[0] == dim:
                res = [ _dot_norm(b[:, i]) for i in range(b.shape[1]) ]
                return np.array(res)
            else:
                raise KeyError("length mismatch")
        else:
            raise KeyError("b must be 1D or 2D")
