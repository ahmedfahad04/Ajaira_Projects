
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        img_arr = np.array(img)
        if img_arr.size == 0:
            return img_arr.copy()
        orig_dtype = img_arr.dtype
        max_val = int(img_arr.max())
        if max_val == 0:
            return img_arr.copy()
        # create binary
        bin_img = (img_arr > 0).astype('uint8') * 255
        # choose kernel size based on image dimensions
        ksize = max(3, min(img_arr.shape[:2]) // 50 * 2 + 1)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ksize, ksize))
        # apply morphological closing to fill holes
        closed = cv2.morphologyEx(bin_img, cv2.MORPH_CLOSE, kernel, iterations=2)
        # optionally combine with original to preserve structures
        filled = cv2.bitwise_or(bin_img, closed)
        result = (filled // 255 * max_val).astype(orig_dtype)
        return result
