
def exp_smooth(vals, alpha):
    import numpy as np
    def exp_smooth(vals, alpha):
        vals = np.asarray(vals)
        if vals.size == 0:
            raise KeyError
        vals = vals.astype(float)
        n = vals.size
        if n == 1:
            return vals.copy()
        # Using convolution for the summation part while keeping initial value as vals[0]
        g = (1.0 - alpha) ** np.arange(n)
        conv = np.convolve(vals[1:], g, mode='full')
        out = np.empty(n, dtype=float)
        out[0] = vals[0]
        powers = (1.0 - alpha) ** np.arange(1, n)
        out[1:] = powers * vals[0] + alpha * conv[:n - 1]
        return out
