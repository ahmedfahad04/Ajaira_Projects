
def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def project_onto_planes(planes: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        """
        Projects 3D coordinates onto planes using broadcasting and summation.
        """
        N, M, _ = coordinates.shape
        axes = planes[..., :2]  # (n_planes, 3, 2)
        axes_t = axes.permute(0, 2, 1)  # (n_planes, 2, 3)
        coords_exp = coordinates.unsqueeze(2)  # (N, M, 1, 3)
        axes_exp = axes_t.unsqueeze(0)  # (1, n_planes, 2, 3)
        prod = coords_exp.unsqueeze(3) * axes_exp.unsqueeze(2)  # (N, M, n_planes, 2, 3)
        summed = prod.sum(-1)  # (N, M, n_planes, 2)
        perm = summed.permute(0, 2, 1, 3)  # (N, n_planes, M, 2)
        n_planes = axes.shape[0]
        return perm.reshape(N * n_planes, M, 2)
