
def mask_iou(mask1, mask2, eps=1e-7):
    import torch
    def mask_iou(mask1, mask2, eps=1e-7):
        # assume binary masks; use logical operations and loop over smaller dimension
        if mask1.numel() == 0 or mask2.numel() == 0:
            return torch.zeros((mask1.shape[0], mask2.shape[0]), device=mask1.device, dtype=torch.float32)
        m1_bool = mask1.bool()
        m2_bool = mask2.bool()
        N = m1_bool.shape[0]
        M = m2_bool.shape[0]
        out = []
        # iterate over the smaller side for memory efficiency
        if N <= M:
            for i in range(N):
                inter = (m1_bool[i].unsqueeze(0) & m2_bool).sum(dim=1).float()  # (M,)
                a1 = m1_bool[i].sum().float()
                a2 = m2_bool.sum(dim=1).float()
                union = a1 + a2 - inter
                out.append(inter / (union.clamp(min=eps)))
            return torch.stack(out, dim=0)
        else:
            # iterate over M and transpose at the end
            rows = []
            for j in range(M):
                inter = (m2_bool[j].unsqueeze(0) & m1_bool).sum(dim=1).float()  # (N,)
                a2 = m2_bool[j].sum().float()
                a1 = m1_bool.sum(dim=1).float()
                union = a1 + a2 - inter
                rows.append(inter / (union.clamp(min=eps)))
            return torch.stack(rows, dim=1)
