
def inverse_sigmoid(x):
    import torch
    def inverse_sigmoid(x):
        x = torch.as_tensor(x)
        if not torch.is_floating_point(x):
            x = x.float()
        dtype = x.dtype
        eps = torch.finfo(dtype).eps
        left_inf = torch.full_like(x, float("-inf"))
        right_inf = torch.full_like(x, float("inf"))
        mid = torch.clamp(x, min=eps, max=1 - eps)
        logit_mid = torch.log(mid / (1 - mid))
        return torch.where(x <= 0, left_inf, torch.where(x >= 1, right_inf, logit_mid))
