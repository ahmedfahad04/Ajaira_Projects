
def getLambertCoefs(numOfLambertCoefs):
    from math import factorial
    def getLambertCoefs(numOfLambertCoefs):
        if numOfLambertCoefs <= 0:
            return []
        result = []
        # include constant term 0
        for n in range(0, numOfLambertCoefs):
            if n == 0:
                result.append(0.0)
            else:
                # compute numerator and denominator using integers, convert to float
                num = (-1 if n % 2 == 1 else 1) * (n ** (n - 1))
                den = factorial(n)
                result.append(num / den)
        return result
