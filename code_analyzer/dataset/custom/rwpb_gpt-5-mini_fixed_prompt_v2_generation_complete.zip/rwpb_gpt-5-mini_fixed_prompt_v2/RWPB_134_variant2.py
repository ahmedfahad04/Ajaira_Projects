
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return None
        try:
            ow, oh = original_size
            if ow == 0 or oh == 0:
                # fallback to area closest
                return min(possible_resolutions, key=lambda wh: abs(wh[0]*wh[1]))
        except Exception:
            return None
        orig_ar = ow / oh
        # prefer candidates that fit inside original (no upscaling)
        fitting = [(w, h) for (w, h) in possible_resolutions if w <= ow and h <= oh]
        candidates = fitting if fitting else possible_resolutions
        # score by aspect ratio difference primarily, then larger area
        def score(wh):
            w, h = wh
            ar_diff = abs((w / h) - orig_ar)
            area = w * h
            # smaller ar_diff better, larger area better -> use negative area
            return (ar_diff, -area, abs(w - ow) + abs(h - oh))
        return min(candidates, key=score)
