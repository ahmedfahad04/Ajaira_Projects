
def resample_segments(segments, n=1000):
    import numpy as np
    def resample_segments(segments, n=1000):
        out = []
        for seg in segments:
            seg = np.asarray(seg, dtype=float)
            if seg.size == 0:
                out.append(np.empty((0,2)))
                continue
            if seg.ndim == 1:
                seg = seg.reshape(-1,2)
            if seg.shape[0] == 1 or np.allclose(seg - seg[0], 0):
                out.append(np.repeat(seg[:1,:], n, axis=0))
                continue
            diffs = np.diff(seg, axis=0)
            dists = np.sqrt((diffs**2).sum(axis=1))
            cum = np.concatenate(([0.0], np.cumsum(dists)))
            total = cum[-1]
            if total == 0.0:
                out.append(np.repeat(seg[:1,:], n, axis=0))
                continue
            newd = np.linspace(0.0, total, n)
            try:
                from scipy.interpolate import interp1d
                fx = interp1d(cum, seg[:,0], kind='linear', bounds_error=False, fill_value=(seg[0,0], seg[-1,0]))
                fy = interp1d(cum, seg[:,1], kind='linear', bounds_error=False, fill_value=(seg[0,1], seg[-1,1]))
                x = fx(newd)
                y = fy(newd)
                out.append(np.column_stack((x,y)))
            except Exception:
                x = np.interp(newd, cum, seg[:,0])
                y = np.interp(newd, cum, seg[:,1])
                out.append(np.column_stack((x,y)))
        return out
