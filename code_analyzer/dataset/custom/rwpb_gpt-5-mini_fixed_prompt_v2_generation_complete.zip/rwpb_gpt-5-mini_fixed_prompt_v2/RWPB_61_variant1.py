
def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    import torch.nn.functional as F
    def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        original_x = x
        if upcast:
            x = x.float()
            if weight is not None:
                weight = weight.float()
            if bias is not None:
                bias = bias.float()
            if residual is not None:
                residual = residual.float()
        normalized_shape = weight.shape if weight is not None else x.shape[-1:]
        out = F.layer_norm(x, normalized_shape, weight=weight, bias=bias, eps=eps)
        if residual is not None:
            out = out + residual
        if prenorm:
            return out, original_x
        return out
