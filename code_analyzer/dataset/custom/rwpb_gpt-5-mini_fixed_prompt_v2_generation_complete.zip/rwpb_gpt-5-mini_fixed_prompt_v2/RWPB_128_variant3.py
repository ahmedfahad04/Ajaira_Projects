
def xywh2xyxy(x):
    import numpy as np
    import torch
    def xywh2xyxy(x):
        if isinstance(x, torch.Tensor):
            a = x[..., :2]
            b = x[..., 2:]
            return torch.cat((a, a + b), dim=-1)
        else:
            arr = np.asarray(x)
            a = arr[..., :2]
            b = arr[..., 2:]
            return np.concatenate((a, a + b), axis=-1)
