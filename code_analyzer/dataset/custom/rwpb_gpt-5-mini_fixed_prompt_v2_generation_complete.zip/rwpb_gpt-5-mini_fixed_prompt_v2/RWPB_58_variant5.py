
def unpad_image_shape(current_height, current_width, original_size):
    import math
    def unpad_image_shape(current_height, current_width, original_size):
        ow, oh = original_size
        # defensive
        try:
            ow = int(ow); oh = int(oh)
        except Exception:
            return (current_height, current_width)
        if ow <= 0 or oh <= 0 or current_width <= 0 or current_height <= 0:
            return (current_height, current_width)
        orig_ar = ow / oh
        cur_ar = current_width / current_height
        if orig_ar > cur_ar:
            # original wider: compute height by scaling width, use ceil then cap
            scale = current_width / ow
            new_h = math.ceil(oh * scale)
            if new_h > current_height:
                new_h = current_height
            new_h = max(1, new_h)
            return (new_h, current_width)
        elif orig_ar < cur_ar:
            scale = current_height / oh
            new_w = math.ceil(ow * scale)
            if new_w > current_width:
                new_w = current_width
            new_w = max(1, new_w)
            return (current_height, new_w)
        else:
            return (current_height, current_width)
