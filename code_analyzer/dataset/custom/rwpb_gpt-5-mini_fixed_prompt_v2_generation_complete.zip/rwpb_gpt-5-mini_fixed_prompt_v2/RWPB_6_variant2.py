
def format_seconds(seconds: float) -> str:
    def format_seconds(seconds: float) -> str:
        """Use Decimal for exact rounding to milliseconds."""
        from decimal import Decimal, ROUND_HALF_UP
        neg = seconds < 0
        d = Decimal(str(abs(seconds))).quantize(Decimal('0.001'), rounding=ROUND_HALF_UP)
        total_ms = int((d * 1000).to_integral_value())
        hours = total_ms // 3_600_000
        total_ms -= hours * 3_600_000
        minutes = total_ms // 60_000
        total_ms -= minutes * 60_000
        secs = total_ms // 1000
        ms = total_ms % 1000
        sign = "-" if neg else ""
        if hours >= 1:
            return f"{sign}{hours:02d}:{minutes:02d}:{secs:02d}.{ms:03d}"
        return f"{sign}{minutes:02d}:{secs:02d}.{ms:03d}"
