
def norm_grid(v_grid):
    import torch
    def norm_grid(v_grid):
        if not isinstance(v_grid, torch.Tensor):
            v_grid = torch.tensor(v_grid)
        B, C, H, W = v_grid.shape
        v = v_grid.float()
        mean = v.mean(dim=(2,3), keepdim=True)
        centered = v - mean
        max_abs = centered.abs().amax(dim=(2,3), keepdim=True)
        denom = torch.where(max_abs == 0, torch.ones_like(max_abs), max_abs)
        v_norm = centered / denom
        v_norm = torch.clamp(v_norm, -1.0, 1.0)
        return v_norm.permute(0, 2, 3, 1)
