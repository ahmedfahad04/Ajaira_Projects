
def getLambertCoefs(numOfLambertCoefs):
    from math import factorial
    def getLambertCoefs(numOfLambertCoefs):
        if numOfLambertCoefs <= 0:
            return []
        # Coefficients of W(x) = sum_{n>=1} (-n)^{n-1} / n! x^n, include 0 for constant term
        coefs = [0.0]  # coefficient for x^0
        for n in range(1, numOfLambertCoefs):
            coefs.append(((-n) ** (n - 1)) / factorial(n))
        # If user asked for exactly 1 coef, return just [0.0]
        if numOfLambertCoefs == 1:
            return coefs[:1]
        return coefs
