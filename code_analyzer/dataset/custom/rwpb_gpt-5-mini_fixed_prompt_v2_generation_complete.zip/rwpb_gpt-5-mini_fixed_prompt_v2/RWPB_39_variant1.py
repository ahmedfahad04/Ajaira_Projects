
def clean_html(:
    import re
    from typing import List
    from html import escape
    from html.parser import HTMLParser
    def clean_html(
            html_to_clean: str,
            tags_to_remove: List[str] = ["style", "svg", "script"],
            attributes_to_keep: List[str] = ["id", "href"],
    ) -> str:
        class Cleaner(HTMLParser):
            def __init__(self, remove_set, keep_set):
                super().__init__(convert_charrefs=False)
                self.remove_set = remove_set
                self.keep_set = keep_set
                self._ignore_stack = []
                self.parts = []
            def handle_starttag(self, tag, attrs):
                lt = tag.lower()
                if lt in self.remove_set:
                    self._ignore_stack.append(lt)
                    return
                if self._ignore_stack:
                    return
                kept = []
                for k, v in attrs:
                    if k.lower() in self.keep_set:
                        if v is None:
                            kept.append(k)
                        else:
                            kept.append(f'{k}="{escape(v, quote=True)}"')
                if kept:
                    self.parts.append(f"<{tag} " + " ".join(kept) + ">")
                else:
                    self.parts.append(f"<{tag}>")
            def handle_startendtag(self, tag, attrs):
                lt = tag.lower()
                if lt in self.remove_set:
                    return
                if self._ignore_stack:
                    return
                kept = []
                for k, v in attrs:
                    if k.lower() in self.keep_set:
                        if v is None:
                            kept.append(k)
                        else:
                            kept.append(f'{k}="{escape(v, quote=True)}"')
                if kept:
                    self.parts.append(f"<{tag} " + " ".join(kept) + " />")
                else:
                    self.parts.append(f"<{tag} />")
            def handle_endtag(self, tag):
                lt = tag.lower()
                if self._ignore_stack:
                    if self._ignore_stack[-1] == lt:
                        self._ignore_stack.pop()
                    return
                self.parts.append(f"</{tag}>")
            def handle_data(self, data):
                if self._ignore_stack:
                    return
                self.parts.append(data)
            def handle_entityref(self, name):
                if self._ignore_stack:
                    return
                self.parts.append(f"&{name};")
            def handle_charref(self, name):
                if self._ignore_stack:
                    return
                self.parts.append(f"&#{name};")
            def handle_comment(self, data):
                if self._ignore_stack:
                    return
                self.parts.append(f"<!--{data}-->")
        remove_set = set([t.lower() for t in tags_to_remove or []])
        keep_set = set([a.lower() for a in attributes_to_keep or []])
        parser = Cleaner(remove_set, keep_set)
        parser.feed(html_to_clean or "")
        parser.close()
        return "".join(parser.parts)
