
def pr_from_grav(grav):
    import numpy as np
    def pr_from_grav(grav):
        g = np.asarray(grav, dtype=float)
        if g.ndim == 1:
            g = g.reshape(1, 3)
        # normalize gravity vectors to avoid scale issues
        norms = np.linalg.norm(g, axis=1)
        # avoid division by zero
        norms = np.where(norms == 0, 1.0, norms)
        gn = g / norms[:, None]
        gx = gn[:, 0]
        gy = gn[:, 1]
        gz = gn[:, 2]
        # pitch via arcsin of -gx (since gn magnitude = 1)
        pitches = np.arcsin(np.clip(-gx, -1.0, 1.0))
        # roll via atan2(gy, gz)
        rolls = np.arctan2(gy, gz)
        return pitches.reshape(-1,), rolls.reshape(-1,)
