
def rotate_y(a, device=None):
    import torch
    import math
    def rotate_y(a, device=None):
        c = math.cos(a)
        s = math.sin(a)
        dev = None if device is None else torch.device(device)
        mat = torch.zeros((4,4), dtype=torch.float64, device=dev)
        mat[0,0] = c
        mat[0,2] = s
        mat[1,1] = 1.0
        mat[2,0] = -s
        mat[2,2] = c
        mat[3,3] = 1.0
        return mat
