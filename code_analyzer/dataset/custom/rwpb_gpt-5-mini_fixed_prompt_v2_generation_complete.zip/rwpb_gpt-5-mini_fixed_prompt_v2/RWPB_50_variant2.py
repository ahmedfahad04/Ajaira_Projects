
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        original_h, original_w = original_size
        if not isinstance(tensor, torch.Tensor):
            tensor = torch.as_tensor(tensor)
        # support batch or single
        is_batched = tensor.ndim == 4
        if not is_batched and tensor.ndim == 3:
            batched = tensor.unsqueeze(0)
        elif is_batched:
            batched = tensor
        else:
            # single-channel 2D
            batched = tensor.unsqueeze(0).unsqueeze(0)
        N, C, H, W = batched.shape
        result = []
        for i in range(N):
            img = batched[i]
            target_aspect = original_h / original_w
            cur_aspect = float(img.shape[1]) / float(img.shape[2])
            if abs(cur_aspect - target_aspect) > 1e-6:
                if cur_aspect > target_aspect:
                    new_h = int(round(img.shape[2] * target_aspect))
                    new_h = max(1, min(new_h, img.shape[1]))
                    top = (img.shape[1] - new_h) // 2
                    cropped = img[:, top:top + new_h, :]
                else:
                    new_w = int(round(img.shape[1] / target_aspect))
                    new_w = max(1, min(new_w, img.shape[2]))
                    left = (img.shape[2] - new_w) // 2
                    cropped = img[:, :, left:left + new_w]
            else:
                cropped = img
            dtype = cropped.dtype
            device = cropped.device
            inp = cropped.unsqueeze(0).float()
            resized = F.interpolate(inp, size=(original_h, original_w), mode='bilinear', align_corners=False)
            resized = resized.squeeze(0).to(dtype).to(device)
            result.append(resized)
        out = torch.stack(result, dim=0)
        if not is_batched and tensor.ndim == 3:
            return out.squeeze(0)
        if not is_batched and tensor.ndim == 2:
            return out.squeeze(0).squeeze(0)
        return out
