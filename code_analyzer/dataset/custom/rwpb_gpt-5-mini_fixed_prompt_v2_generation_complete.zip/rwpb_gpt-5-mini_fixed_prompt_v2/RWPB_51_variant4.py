
def _ssim(img1, img2, window, window_size, channel, size_average=True):
    import torch
    import torch.nn.functional as F
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        if img1.shape != img2.shape:
            raise ValueError("Input tensors must have the same shape.")
        # create separable kernels if window provided as 2D gaussian
        if window.dim() == 2:
            ws = window_size
            w2d = window.view(1,1,ws,ws).to(img1.device).to(img1.dtype)
        elif window.dim() == 4:
            w2d = window.to(img1.device).to(img1.dtype)
        else:
            w2d = window.view(1,1,window_size,window_size).to(img1.device).to(img1.dtype)
        # attempt separable: compute horizontal and vertical kernels by SVD-like approximation
        # fallback to using w2d directly
        try:
            flat = w2d.view(-1, w2d.size(-1))
            # compute marginal sums to get separable approximations
            col = w2d.sum(dim=3).view(1,1,-1,1)
            row = w2d.sum(dim=2).view(1,1,1,-1)
            # normalize
            col = col / col.sum()
            row = row / row.sum()
            kh = row.view(1,1,1,-1).to(img1.device).to(img1.dtype)
            kv = col.view(1,1,-1,1).to(img1.device).to(img1.dtype)
            use_sep = True
        except Exception:
            use_sep = False
        pad = window_size // 2
        if use_sep:
            # convolve vertical then horizontal with groups
            kh = kh.expand(channel,1,1,kh.size(-1)).contiguous()
            kv = kv.expand(channel,1,kv.size(2),1).contiguous()
            mu1 = F.conv2d(F.conv2d(img1, kv, padding=(pad,0), groups=channel), kh, padding=(0,pad), groups=channel)
            mu2 = F.conv2d(F.conv2d(img2, kv, padding=(pad,0), groups=channel), kh, padding=(0,pad), groups=channel)
            mu1_sq = mu1 * mu1
            mu2_sq = mu2 * mu2
            mu1_mu2 = mu1 * mu2
            sigma1_sq = F.conv2d(F.conv2d(img1*img1, kv, padding=(pad,0), groups=channel), kh, padding=(0,pad), groups=channel) - mu1_sq
            sigma2_sq = F.conv2d(F.conv2d(img2*img2, kv, padding=(pad,0), groups=channel), kh, padding=(0,pad), groups=channel) - mu2_sq
            sigma12 = F.conv2d(F.conv2d(img1*img2, kv, padding=(pad,0), groups=channel), kh, padding=(0,pad), groups=channel) - mu1_mu2
        else:
            w = w2d.expand(channel,1,w2d.size(2),w2d.size(3)).contiguous()
            mu1 = F.conv2d(img1, w, padding=pad, groups=channel)
            mu2 = F.conv2d(img2, w, padding=pad, groups=channel)
            mu1_sq = mu1 * mu1
            mu2_sq = mu2 * mu2
            mu1_mu2 = mu1 * mu2
            sigma1_sq = F.conv2d(img1*img1, w, padding=pad, groups=channel) - mu1_sq
            sigma2_sq = F.conv2d(img2*img2, w, padding=pad, groups=channel) - mu2_sq
            sigma12 = F.conv2d(img1*img2, w, padding=pad, groups=channel) - mu1_mu2
        C1 = (0.01)**2
        C2 = (0.03)**2
        num = (2 * mu1_mu2 + C1) * (2 * sigma12 + C2)
        den = (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)
        ssim_map = num / den
        if size_average:
            return ssim_map.mean()
        else:
            return ssim_map.mean(dim=(0,2,3))
