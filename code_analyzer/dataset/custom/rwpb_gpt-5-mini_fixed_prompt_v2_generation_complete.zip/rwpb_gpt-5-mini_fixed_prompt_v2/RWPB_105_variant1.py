
def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        # Expect grid: (1, C, H, W, D) as described
        if grid.ndim != 5:
            raise ValueError("grid must be 5D tensor (1, C, H, W, D)")
        batch_size, num_points, coords_dim = coordinates.shape
        if coords_dim != 3:
            raise ValueError("coordinates must have last dim == 3")
        # Permute grid to (N, C, D, H, W) which grid_sample expects
        grid_perm = grid.permute(0, 1, 4, 2, 3).contiguous()  # (1, C, D, H, W)
        _, C, D, H, W = grid_perm.shape
        coords = coordinates.clone().to(grid.dtype)
        # Determine if coords are normalized (-1..1) or absolute indices
        minc, maxc = coords.min().item(), coords.max().item()
        if minc >= -1.0 - 1e-6 and maxc <= 1.0 + 1e-6:
            # Already normalized in [-1,1], assume order (x, y, z) meaning x->W, y->H, z->D
            norm_coords = coords
        else:
            # Treat as absolute indices in [0..W-1], [0..H-1], [0..D-1] with order (x,y,z)
            x = coords[..., 0]
            y = coords[..., 1]
            z = coords[..., 2]
            # avoid division by zero
            den_w = (W - 1) if (W - 1) != 0 else 1
            den_h = (H - 1) if (H - 1) != 0 else 1
            den_d = (D - 1) if (D - 1) != 0 else 1
            x_n = x / den_w * 2.0 - 1.0
            y_n = y / den_h * 2.0 - 1.0
            z_n = z / den_d * 2.0 - 1.0
            norm_coords = torch.stack([x_n, y_n, z_n], dim=-1)
        # grid_sample expects grid in shape (N, D_out, H_out, W_out, 3)
        # We'll sample each point as a depth slice: D_out = num_points, H_out = 1, W_out = 1
        grid_for_sample = norm_coords.view(batch_size, num_points, 1, 1, 3)
        # Expand the grid to batch_size
        grid_expanded = grid_perm.expand(batch_size, -1, -1, -1, -1)
        sampled = F.grid_sample(grid_expanded, grid_for_sample, mode='bilinear', padding_mode='border', align_corners=True)
        # sampled shape: (batch_size, C, D_out=num_points, 1, 1)
        sampled = sampled[:, :, :, 0, 0].permute(0, 2, 1).contiguous()  # (batch_size, num_points, C)
        return sampled
