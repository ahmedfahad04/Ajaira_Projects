
def fovx_to_fovy(fovx, aspect):
    import math
    def fovx_to_fovy(fovx, aspect):
        """
        Convert horizontal FoV to vertical FoV (radians).
        """
        if aspect <= 0:
            raise ValueError("aspect must be positive")
        # tangent of half horizontal FoV
        half_tx = math.tan(0.5 * float(fovx))
        # tangent of half vertical FoV
        half_ty = half_tx / float(aspect)
        # full vertical FoV
        return 2.0 * math.atan(half_ty)
