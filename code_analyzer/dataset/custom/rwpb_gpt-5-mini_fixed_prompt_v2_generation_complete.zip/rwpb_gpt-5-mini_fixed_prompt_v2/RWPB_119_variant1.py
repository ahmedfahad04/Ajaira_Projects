
def rotate_about_x_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        """
        Rotate a single 3D vector about the x-axis using a 3x3 rotation matrix.
        """
        v = np.asarray(vector, dtype=float)
        if v.shape != (3,):
            # allow flat iterables of length 3
            try:
                v = v.reshape(3,)
            except Exception:
                raise ValueError("Input vector must be length 3")
        c = math.cos(theta)
        s = math.sin(theta)
        R = np.array([[1.0, 0.0, 0.0],
                      [0.0, c,   -s  ],
                      [0.0, s,    c  ]], dtype=float)
        return R.dot(v)
