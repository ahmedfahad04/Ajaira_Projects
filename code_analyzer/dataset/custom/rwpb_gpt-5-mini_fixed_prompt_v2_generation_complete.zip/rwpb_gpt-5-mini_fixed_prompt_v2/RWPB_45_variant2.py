
def invalid_to_zeros(arr, valid_mask, ndim=999):
    import torch
    def invalid_to_zeros(arr, valid_mask, ndim=999):
        if not isinstance(arr, torch.Tensor):
            raise TypeError("arr must be a torch.Tensor")
        orig_shape = arr.shape
        if ndim != 999 and arr.dim() > ndim:
            head = list(arr.shape[:ndim-1])
            tail = 1
            for s in arr.shape[ndim-1:]:
                tail *= s
            new_shape = tuple(head + [tail])
            arr = arr.view(*new_shape)
        if valid_mask is None:
            if arr.dim() >= 1:
                nnz = torch.tensor(arr.numel() // arr.shape[0], dtype=torch.long)
            else:
                nnz = torch.tensor(arr.numel(), dtype=torch.long)
            return arr, nnz
        mask = valid_mask
        if not isinstance(mask, torch.Tensor):
            mask = torch.tensor(mask, dtype=torch.bool, device=arr.device)
        mask = mask.bool().to(arr.device)
        if arr.dim() == 1:
            if mask.numel() == arr.numel():
                arr = arr.clone()
                arr[~mask] = 0
                nnz = torch.tensor(int(mask.sum().item()))
                return arr, nnz
        if arr.dim() >= 2:
            B = arr.shape[0]
            flat = arr.view(B, -1)
            if mask.numel() == flat.numel():
                m = mask.view(B, -1)
                flat = flat.clone()
                flat[~m] = 0
                arr = flat.view(*arr.shape)
                nnz = m.sum(dim=1)
                return arr, nnz
            if mask.numel() == B and mask.numel() != flat.numel():
                m = mask.view(B, 1).expand(B, flat.shape[1])
                flat = flat.clone()
                flat[~m] = 0
                arr = flat.view(*arr.shape)
                nnz = m.sum(dim=1)
                return arr, nnz
            if mask.dim() == arr.dim()-1 and mask.shape == arr.shape[:-1]:
                m = mask.unsqueeze(-1).expand_as(arr)
                arr = arr.clone()
                arr[~m] = 0
                nnz = mask.view(B, -1).sum(dim=1)
                return arr, nnz
        # fallback: try broadcasting
        try:
            m = mask.view(*mask.shape, *([1] * (arr.dim() - mask.dim())))
            arr = arr.clone()
            arr[~m.expand_as(arr)] = 0
            if m.shape[0] == arr.shape[0]:
                nnz = m.view(arr.shape[0], -1).sum(dim=1)
            else:
                nnz = torch.tensor(int(m.expand_as(arr).sum().item()))
            return arr, nnz
        except Exception:
            raise ValueError("Could not broadcast valid_mask to arr shape")
