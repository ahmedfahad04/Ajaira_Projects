
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        # Recursive construction (simple, demonstrative)
        if not isinstance(tensor1, torch.Tensor) or not isinstance(tensor2, torch.Tensor):
            raise TypeError("Inputs must be torch.Tensor")
        if tensor1.shape != tensor2.shape:
            raise ValueError("Input tensors must have the same shape")
        n = tensor1.shape[0] if tensor1.dim() > 0 else 0
        rest = tensor1.shape[1:]
        if n == 0:
            return tensor1.new_empty((0,)+rest), tensor2.new_empty((0,)+rest)
        if n == 1:
            a = tensor1.clone()
            b = tensor2.clone()
            out1 = torch.cat((a, b), dim=0)
            out2 = torch.cat((b, a), dim=0)
            return out1, out2
        # split in two halves to reduce recursion depth
        mid = n // 2
        t1_left, t1_right = tensor1[:mid], tensor1[mid:]
        t2_left, t2_right = tensor2[:mid], tensor2[mid:]
        left1, left2 = interleave(t1_left, t2_left)
        right1, right2 = interleave(t1_right, t2_right)
        out1 = torch.cat((left1, right1), dim=0)
        out2 = torch.cat((left2, right2), dim=0)
        return out1, out2
