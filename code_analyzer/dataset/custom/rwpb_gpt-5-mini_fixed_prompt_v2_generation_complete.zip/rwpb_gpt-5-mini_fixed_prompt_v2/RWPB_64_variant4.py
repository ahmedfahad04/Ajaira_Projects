
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        arr = np.asarray(arr, dtype=float)
        if window_size <= 0 or int(window_size) != window_size:
            raise ValueError("window_size must be a positive integer")
        w = int(window_size)
        n = arr.size
        if n == 0 or w > n:
            return [np.array([]), np.array([])]
        try:
            from numpy.lib.stride_tricks import sliding_window_view
            windows = sliding_window_view(arr, window_shape=w)
            ma = windows.mean(axis=1)
            residuals = arr[w-1:] - ma
            return [ma, residuals]
        except Exception:
            csum = np.cumsum(np.insert(arr, 0, 0.0))
            ma = (csum[w:] - csum[:-w]) / float(w)
            residuals = arr[w-1:] - ma
            return [ma, residuals]
