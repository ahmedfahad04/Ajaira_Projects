
def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
    import torch
    import numpy as np
    def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
        """
        Convert to numpy, use np.moveaxis, convert back.
        Note: this will move data to CPU and detach gradients.
        """
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        nd = x.dim()
        if nd == 0:
            return x.contiguous() if make_contiguous else x
        src = src_dim + nd if src_dim < 0 else src_dim
        dest = dest_dim + nd if dest_dim < 0 else dest_dim
        if not (0 <= src < nd) or not (0 <= dest < nd):
            raise IndexError("src_dim or dest_dim out of range")
        if src == dest:
            return x.contiguous() if make_contiguous else x
        # Move to numpy on CPU
        arr = x.detach().cpu().numpy()
        moved = np.moveaxis(arr, src, dest)
        out = torch.as_tensor(moved, device=x.device, dtype=x.dtype)
        if make_contiguous:
            out = out.contiguous()
        return out
