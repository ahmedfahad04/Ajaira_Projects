
def path_spliter(path: str):
    import os
    import re
    def path_spliter(path: str):
        if not path:
            return []
        drive, rest = os.path.splitdrive(path)
        # normalize alternate separator to primary separator
        sep = os.path.sep
        alt = os.path.altsep or ('/' if sep != '/' else None)
        if alt:
            rest = rest.replace(alt, sep)
        # detect leading separator (root)
        leading_root = rest.startswith(sep)
        # split on one-or-more separators, filter empties
        parts = [p for p in re.split(re.escape(sep) + r'+', rest) if p != '']
        result = []
        if drive:
            result.append(drive)
        if leading_root:
            result.append(sep)
        result.extend(parts)
        return result
