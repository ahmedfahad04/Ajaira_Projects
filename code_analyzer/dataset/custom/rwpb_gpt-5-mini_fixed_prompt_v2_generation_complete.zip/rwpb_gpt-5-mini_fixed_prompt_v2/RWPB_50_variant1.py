
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        original_h, original_w = original_size
        if not isinstance(tensor, torch.Tensor):
            tensor = torch.as_tensor(tensor)
        if tensor.ndim == 2:
            tensor = tensor.unsqueeze(0)
        if tensor.ndim == 4:
            # handle batch by processing each item independently
            out_list = []
            for i in range(tensor.shape[0]):
                out_list.append(unpad_image(tensor[i], original_size))
            return torch.stack(out_list, dim=0)
        # now tensor is C x H x W
        C, H, W = tensor.shape
        if H == 0 or W == 0:
            return tensor
        target_aspect = original_h / original_w
        current_aspect = H / W
        if abs(current_aspect - target_aspect) < 1e-6:
            return tensor
        if current_aspect > target_aspect:
            # need to crop height
            new_h = int(round(W * target_aspect))
            new_h = max(1, min(new_h, H))
            top = (H - new_h) // 2
            return tensor[:, top:top + new_h, :]
        else:
            # need to crop width
            new_w = int(round(H / target_aspect))
            new_w = max(1, min(new_w, W))
            left = (W - new_w) // 2
            return tensor[:, :, left:left + new_w]
