
def rotate_normalmap_by_angle_torch(normal_map, angle):
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        import torch
        device = normal_map.device
        dtype = normal_map.dtype
        theta = angle * 3.141592653589793 / 180.0
        half = theta / 2.0
        w = torch.cos(torch.tensor(half, device=device, dtype=dtype))
        s = torch.sin(torch.tensor(half, device=device, dtype=dtype))
        q_vec = torch.tensor([0.0, s.item(), 0.0], device=device, dtype=dtype)
        v = normal_map
        qv = q_vec
        cross1 = torch.cross(qv, v, dim=-1)
        t = cross1 + w * v
        cross2 = torch.cross(qv, t, dim=-1)
        out = v + 2.0 * cross2
        norm = torch.sqrt((out * out).sum(dim=-1, keepdim=True))
        out = out / (norm + 1e-8)
        return out
