
def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
    import torch
    def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
        eps = 1e-8
        v0 = v0.clone()
        v1 = v1.clone()
        n0 = v0.norm(dim=-1, keepdim=True).clamp_min(eps)
        n1 = v1.norm(dim=-1, keepdim=True).clamp_min(eps)
        u0 = v0 / n0
        u1 = v1 / n1
        dot = (u0 * u1).sum(dim=-1, keepdim=True)
        dot_clamped = dot.clamp(-1.0, 1.0)
        theta = torch.acos(dot_clamped)
        sin_theta = torch.sin(theta)
        t_tensor = torch.tensor(t, dtype=theta.dtype, device=theta.device)
        small_angle = sin_theta.abs() < (1.0 - DOT_THRESHOLD)
        s0 = torch.sin((1.0 - t_tensor) * theta) / (sin_theta + eps)
        s1 = torch.sin(t_tensor * theta) / (sin_theta + eps)
        s0 = torch.where(small_angle, s0, 1.0 - t_tensor)
        s1 = torch.where(small_angle, s1, t_tensor)
        result = (s0 * u0 * n0) + (s1 * u1 * n1)
        return result
