
def rotate_normalmap_by_angle_torch(normal_map, angle):
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        import torch
        from torch.nn.functional import normalize
        device = normal_map.device
        dtype = normal_map.dtype
        theta = angle * 3.141592653589793 / 180.0
        cos = float(torch.cos(torch.tensor(theta)))
        sin = float(torch.sin(torch.tensor(theta)))
        xz = normal_map[..., [0, 2]]
        x = xz[..., 0]
        z = xz[..., 1]
        x_r = cos * x + sin * z
        z_r = -sin * x + cos * z
        out = torch.empty_like(normal_map)
        out[..., 0] = x_r
        out[..., 1] = normal_map[..., 1]
        out[..., 2] = z_r
        out = normalize(out, p=2, dim=-1, eps=1e-8)
        return out
