
def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
    import torch
    def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
        eps = 1e-8
        v0 = v0.float()
        v1 = v1.float()
        n0 = v0.norm(dim=-1, keepdim=True)
        n1 = v1.norm(dim=-1, keepdim=True)
        n0 = n0.clamp_min(eps)
        n1 = n1.clamp_min(eps)
        u0 = v0 / n0
        u1 = v1 / n1
        dot = (u0 * u1).sum(dim=-1, keepdim=True).clamp(-1.0, 1.0)
        if (dot > DOT_THRESHOLD).all():
            out = (1.0 - t) * v0 + t * v1
            out_norm = out.norm(dim=-1, keepdim=True).clamp_min(eps)
            return out / out_norm * ((1 - t) * n0 + t * n1)
        theta = torch.acos(dot)
        sin_theta = torch.sin(theta)
        t_tensor = torch.tensor(t, dtype=v0.dtype, device=v0.device)
        s0 = torch.sin((1.0 - t_tensor) * theta) / (sin_theta + eps)
        s1 = torch.sin(t_tensor * theta) / (sin_theta + eps)
        return (s0 * u0 * n0) + (s1 * u1 * n1)
