
def invalid_to_zeros(arr, valid_mask, ndim=999):
    import torch
    def invalid_to_zeros(arr, valid_mask, ndim=999):
        if not isinstance(arr, torch.Tensor):
            raise TypeError("arr must be a torch.Tensor")
        if ndim != 999 and arr.dim() > ndim:
            front = tuple(arr.shape[:ndim-1])
            prod = 1
            for s in arr.shape[ndim-1:]:
                prod *= s
            arr = arr.view(*front, prod)
        if valid_mask is None:
            if arr.dim() >= 1:
                nnz = torch.tensor(arr.numel() // arr.shape[0], dtype=torch.long)
            else:
                nnz = torch.tensor(arr.numel(), dtype=torch.long)
            return arr, nnz
        mask = valid_mask
        if not isinstance(mask, torch.Tensor):
            mask = torch.tensor(mask, dtype=torch.bool, device=arr.device)
        mask = mask.bool().to(arr.device)
        if mask.numel() == arr.numel():
            arr = arr.clone()
            arr.view(-1)[~mask.view(-1)] = 0
            nnz = torch.tensor(int(mask.view(-1).sum().item()))
            return arr, nnz
        if arr.dim() >= 2:
            B = arr.shape[0]
            flat = arr.view(B, -1).clone()
            if mask.dim() == 1 and mask.numel() == flat.shape[1]:
                m = mask.view(1, -1).expand_as(flat)
                flat[~m] = 0
                arr = flat.view(*arr.shape)
                nnz = m.sum(dim=1)
                return arr, nnz
            if mask.dim() == 2 and mask.shape == (B, flat.shape[1]):
                flat[~mask] = 0
                arr = flat.view(*arr.shape)
                nnz = mask.sum(dim=1)
                return arr, nnz
            if mask.dim() == 1 and mask.numel() == B:
                for i in range(B):
                    if not bool(mask[i]):
                        flat[i].zero_()
                arr = flat.view(*arr.shape)
                nnz = mask.to(torch.long)
                return arr, nnz
        # final attempt: broadcast with torch.where
        try:
            m = mask.view(*mask.shape, *([1] * (arr.dim() - mask.dim())))
            a = torch.where(m.expand_as(arr), arr, torch.zeros_like(arr))
            if m.shape[0] == arr.shape[0]:
                nnz = m.view(arr.shape[0], -1).sum(dim=1)
            else:
                nnz = torch.tensor(int(m.expand_as(arr).sum().item()))
            return a, nnz
        except Exception:
            raise ValueError("Unable to apply validity mask to arr")
