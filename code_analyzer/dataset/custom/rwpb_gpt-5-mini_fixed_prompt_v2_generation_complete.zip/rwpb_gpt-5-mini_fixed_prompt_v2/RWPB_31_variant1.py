
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        old = tensor.size(0)
        if batch_size == old:
            return tensor
        if old == 1:
            # Just repeat the single example
            return tensor.expand(batch_size, *tensor.shape[1:]).clone()
        device = tensor.device
        dtype = tensor.dtype
        # positions in the original batch for each new sample
        pos = torch.linspace(0.0, float(old - 1), steps=batch_size, device=device, dtype=torch.float32)
        if batch_size < old:
            # reduction: pick nearest original indices evenly distributed
            idx = torch.clamp((pos + 0.5).floor().long(), 0, old - 1)
            return tensor[idx]
        else:
            # expansion: linear interpolation between nearest neighbors (no extrapolation)
            low = torch.clamp(pos.floor().long(), 0, old - 1)
            high = torch.clamp(pos.ceil().long(), 0, old - 1)
            w = (pos - pos.floor()).to(dtype).to(device)  # weight for high
            # expand w to broadcast across remaining dimensions
            expand_shape = (batch_size,) + (1,) * (tensor.dim() - 1)
            w = w.view(expand_shape)
            low_vals = tensor[low]
            high_vals = tensor[high]
            return (1.0 - w) * low_vals + w * high_vals
