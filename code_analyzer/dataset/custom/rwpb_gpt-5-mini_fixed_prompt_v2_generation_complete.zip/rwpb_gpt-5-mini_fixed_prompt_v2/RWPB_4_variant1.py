
def rot6d_to_rotmat(x):
    def rot6d_to_rotmat(x):
        import torch
        import torch.nn.functional as F
        if not torch.is_tensor(x):
            x = torch.tensor(x)
        if x.dim() != 2 or x.shape[1] != 6:
            raise ValueError("Input must have shape (B,6)")
        a1 = x[:, 0:3]
        a2 = x[:, 3:6]
        b1 = F.normalize(a1, p=2, dim=1)
        proj = (b1 * a2).sum(dim=1, keepdim=True)
        a2_orth = a2 - proj * b1
        b2 = F.normalize(a2_orth, p=2, dim=1)
        b3 = torch.cross(b1, b2, dim=1)
        R = torch.stack((b1, b2, b3), dim=2)
        return R
