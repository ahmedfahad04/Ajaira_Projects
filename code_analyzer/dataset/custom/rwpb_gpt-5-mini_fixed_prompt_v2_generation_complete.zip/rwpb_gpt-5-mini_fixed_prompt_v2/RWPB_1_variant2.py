
def apply_colormap(:
    import torch
    import numpy as np
    from matplotlib import cm
    def apply_colormap(image, cmap="viridis"):
        """
        Pure torch-based interpolation using a sampled colormap (256 entries).
        Supports both channel-last (...,1) and channel-first (with C==1 at dim 1).
        """
        if not isinstance(image, torch.Tensor):
            raise TypeError("image must be a torch.Tensor")
        x = image
        if x.ndim >= 2 and x.shape[1] == 1 and x.ndim >= 3:
            dims = list(range(x.ndim))
            dims.pop(1)
            dims.append(1)
            x = x.permute(*dims)
        if x.shape[-1] != 1:
            raise ValueError("Expected channel dimension of size 1 at the last axis")
        device = x.device
        dtype = torch.float32
        vals = x.squeeze(-1).to(dtype=dtype)
        # Normalize per-tensor
        vmin = torch.min(vals)
        vmax = torch.max(vals)
        if torch.isfinite(vmin) and torch.isfinite(vmax) and (vmax > vmin):
            normed = (vals - vmin) / (vmax - vmin)
        else:
            normed = torch.zeros_like(vals)
        # prepare colormap lookup table
        cmap_arr = cm.get_cmap(cmap)(np.linspace(0.0, 1.0, 256))[:, :3].astype(np.float32)
        lut = torch.from_numpy(cmap_arr).to(device=device, dtype=dtype)  # (256,3)
        # scale normed to [0,255]
        scaled = (normed.clamp(0.0, 1.0) * 255.0)
        idx = torch.floor(scaled).to(torch.long).clamp(0, 254)
        frac = (scaled - idx.to(dtype))[:, ...]  # same shape as vals
        # gather low and high
        flat_idx = idx.reshape(-1)
        low = lut[flat_idx].reshape(*idx.shape, 3)
        high = lut[(flat_idx + 1).clamp(0, 255)].reshape(*idx.shape, 3)
        frac = frac.unsqueeze(-1)
        out = low * (1.0 - frac) + high * frac
        return out.to(device=device, dtype=dtype)
