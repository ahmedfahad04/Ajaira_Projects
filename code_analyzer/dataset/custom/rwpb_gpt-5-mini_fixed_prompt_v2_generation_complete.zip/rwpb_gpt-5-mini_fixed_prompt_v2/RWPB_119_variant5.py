
def rotate_about_x_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        """
        Rotate a single 3D vector or an array of shape (N,3) using broadcasting.
        """
        arr = np.asarray(vector, dtype=float)
        c = math.cos(theta)
        s = math.sin(theta)
        R = np.array([[1.0, 0.0, 0.0],
                      [0.0,   c,  -s  ],
                      [0.0,   s,   c  ]], dtype=float)
        if arr.ndim == 1:
            if arr.size != 3:
                raise ValueError("vector must have exactly 3 elements")
            return R.dot(arr)
        elif arr.ndim == 2 and arr.shape[1] == 3:
            # apply to each row
            return (arr @ R.T)
        else:
            raise ValueError("Input must be a 1D length-3 array or 2D array with shape (N,3)")
