
def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        # Use grid_sample but process one batch at a time (loop) - simple and robust
        if grid.ndim != 5:
            raise ValueError("grid must be 5D tensor (1, C, H, W, D)")
        _, C, H, W, D = grid.shape
        B, P, d3 = coordinates.shape
        if d3 != 3:
            raise ValueError("coordinates last dimension must be 3")
        # permute grid to (1, C, D, H, W)
        grid_perm = grid.permute(0, 1, 4, 2, 3).contiguous()
        out_list = []
        for b in range(B):
            coords = coordinates[b].unsqueeze(0).clone().to(grid.dtype)  # (1, P, 3)
            minc, maxc = coords.min().item(), coords.max().item()
            if minc >= -1.0 - 1e-6 and maxc <= 1.0 + 1e-6:
                norm_coords = coords
            else:
                x = coords[..., 0]
                y = coords[..., 1]
                z = coords[..., 2]
                den_w = (W - 1) if (W - 1) != 0 else 1
                den_h = (H - 1) if (H - 1) != 0 else 1
                den_d = (D - 1) if (D - 1) != 0 else 1
                x_n = x / den_w * 2.0 - 1.0
                y_n = y / den_h * 2.0 - 1.0
                z_n = z / den_d * 2.0 - 1.0
                norm_coords = torch.stack([x_n.squeeze(0), y_n.squeeze(0), z_n.squeeze(0)], dim=-1).unsqueeze(0)
            # make grid for grid_sample: (1, P, 1, 1, 3)
            gs = norm_coords.view(1, P, 1, 1, 3)
            sampled = F.grid_sample(grid_perm.expand(1, -1, -1, -1, -1), gs, mode='bilinear', padding_mode='border', align_corners=True)
            sampled = sampled[:, :, :, 0, 0].permute(0, 2, 1).squeeze(0)  # (P, C)
            out_list.append(sampled)
        out = torch.stack(out_list, dim=0)  # (B, P, C)
        return out
