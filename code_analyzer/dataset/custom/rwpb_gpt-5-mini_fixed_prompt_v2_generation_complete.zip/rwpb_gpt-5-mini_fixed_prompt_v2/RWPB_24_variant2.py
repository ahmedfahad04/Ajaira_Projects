
def check(x, checksum_token):
    import re
    import hashlib
    def check(x, checksum_token):
        matches = list(re.finditer(r'[0-9a-fA-F]{64}', x))
        if len(matches) != 1:
            return False
        m = matches[0]
        original = m.group(0)
        replaced = x[:m.start()] + checksum_token + x[m.end():]
        digest = hashlib.sha256(replaced.encode('utf-8')).hexdigest()
        return digest.lower() == original.lower()
