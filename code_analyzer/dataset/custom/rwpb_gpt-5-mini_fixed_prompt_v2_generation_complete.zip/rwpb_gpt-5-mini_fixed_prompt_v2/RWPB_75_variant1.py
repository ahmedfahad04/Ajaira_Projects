
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a == 0 or norm_b == 0:
            return (None, None)
        an = a / norm_a
        bn = b / norm_b
        cross = np.cross(an, bn)
        norm_cross = np.linalg.norm(cross)
        dot = np.dot(an, bn)
        dot = np.clip(dot, -1.0, 1.0)
        eps = 1e-8
        if norm_cross < eps:
            if dot > 0:
                return (None, None)
            else:
                # opposite direction: choose any orthogonal axis
                arb = np.array([1.0, 0.0, 0.0])
                if abs(np.dot(arb, an)) > 0.9:
                    arb = np.array([0.0, 1.0, 0.0])
                axis = np.cross(an, arb)
                axis = axis / np.linalg.norm(axis)
                return (axis, float(np.pi))
        axis = cross / norm_cross
        angle = float(np.arccos(dot))
        return (axis, angle)
