
def pad_camera_extrinsics_4x4(extrinsics):
    import torch
    def pad_camera_extrinsics_4x4(extrinsics):
        if not isinstance(extrinsics, torch.Tensor):
            raise TypeError("extrinsics must be a torch.Tensor")
        if extrinsics.dim() < 2:
            raise ValueError("extrinsics must have at least 2 dimensions")
        h, w = extrinsics.shape[-2], extrinsics.shape[-1]
        if (h, w) == (4, 4):
            return extrinsics.clone()
        if (h, w) != (3, 4):
            raise ValueError(f"Unsupported extrinsics shape {extrinsics.shape}; expected (...,3,4) or (...,4,4).")
        # Preallocate output and fill
        batch_shape = extrinsics.shape[:-2]
        out = extrinsics.new_zeros(batch_shape + (4, 4))
        out[..., :3, :] = extrinsics
        out[..., 3, 3] = 1
        return out
