
def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
    import torch
    def _linspace(start: torch.Tensor, stop: torch.Tensor, num: int):
        start = torch.as_tensor(start)
        stop = torch.as_tensor(stop)
        if num <= 0:
            return torch.empty((0,) + tuple(start.shape), dtype=start.dtype, device=start.device)
        # broadcast start and stop to same shape
        start_b, stop_b = torch.broadcast_tensors(start, stop)
        # determine dtype (use float for interpolation)
        dtype = torch.result_type(start_b, stop_b, torch.tensor(0.0))
        device = start_b.device
        start_b = start_b.to(dtype=dtype, device=device)
        stop_b = stop_b.to(dtype=dtype, device=device)
        if num == 1:
            return start_b.unsqueeze(0)
        # use arange to form normalized positions
        steps = torch.arange(num, dtype=dtype, device=device)
        denom = float(num - 1)
        fractions = steps / denom
        # reshape for broadcasting
        frac_shape = (num,) + (1,) * start_b.dim()
        fractions = fractions.view(frac_shape)
        return start_b.unsqueeze(0) + fractions * (stop_b - start_b).unsqueeze(0)
