
def merge_dicts_recursively(*dicts):
    from collections import deque
    from collections.abc import Mapping
    def merge_dicts_recursively(*dicts):
        q = deque(d for d in dicts if isinstance(d, Mapping))
        if not q:
            return {}
        out = {}
        while q:
            current = q.popleft()
            for k, v in current.items():
                if k in out and isinstance(out[k], Mapping) and isinstance(v, Mapping):
                    out[k] = merge_dicts_recursively(out[k], v)
                else:
                    out[k] = v
        return out
