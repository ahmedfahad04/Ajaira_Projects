
def unsafeAdd(x, y):
    MAX_VAL = (1 << 256) - 1
    MOD = MAX_VAL + 1
    def unsafeAdd(x, y):
        return (x + y) % MOD
