
def get_confusion_matrix(gt_label, pred_label, num_classes):
    import numpy as np
    def get_confusion_matrix(gt_label, pred_label, num_classes):
        if not isinstance(num_classes, int) or num_classes <= 0:
            raise ValueError("num_classes must be a positive integer")
        gt = np.asarray(gt_label)
        pred = np.asarray(pred_label)
        if gt.shape[0] != pred.shape[0]:
            raise ValueError("gt_label and pred_label must have the same length")
        if gt.size == 0:
            return np.zeros((num_classes, num_classes), dtype=int)
        # Validate integer labels
        gt_i = gt.astype(int)
        pred_i = pred.astype(int)
        if np.any(gt_i != gt) or np.any(pred_i != pred):
            raise ValueError("Labels must be integer-valued")
        if gt_i.min() < 0 or pred_i.min() < 0 or gt_i.max() >= num_classes or pred_i.max() >= num_classes:
            raise ValueError("Labels must be in the range [0, num_classes-1]")
        cm = np.zeros((num_classes, num_classes), dtype=int)
        # build each row via bincount of predictions where ground truth equals the row index
        for cls in range(num_classes):
            mask = (gt_i == cls)
            if not np.any(mask):
                continue
            row_counts = np.bincount(pred_i[mask], minlength=num_classes)
            cm[cls, :] = row_counts[:num_classes]
        return cm
