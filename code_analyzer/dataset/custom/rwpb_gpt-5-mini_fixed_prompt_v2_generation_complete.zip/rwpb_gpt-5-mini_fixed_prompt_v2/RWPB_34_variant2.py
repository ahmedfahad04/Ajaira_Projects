
def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
    import numpy as np
    def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
        target = context_window + 1
        arr = np.asarray(tokens)
        if arr.ndim == 0:
            return np.pad(arr, (0, target - 1), constant_values=pad_token)[:target]
        if arr.ndim == 1:
            seq_len = arr.shape[0]
            if seq_len >= target:
                return arr[:target].astype(arr.dtype)
            pad_width = (0, target - seq_len)
            return np.pad(arr, pad_width, mode='constant', constant_values=pad_token).astype(arr.dtype)
        # arr.ndim >=2
        seq_len = arr.shape[1]
        if seq_len >= target:
            return arr[:, :target].astype(arr.dtype)
        pad_width = ((0, 0), (0, target - seq_len))
        return np.pad(arr, pad_width, mode='constant', constant_values=pad_token).astype(arr.dtype)
