
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        old = tensor.size(0)
        if batch_size == old:
            return tensor
        if old == 1:
            return tensor.expand(batch_size, *tensor.shape[1:]).clone()
        device = tensor.device
        # compute target positions
        pos = torch.linspace(0.0, float(old - 1), steps=batch_size, device=device)
        if batch_size < old:
            # choose nearest-index selection using index_select
            idx = torch.clamp((pos + 0.5).floor().long(), 0, old - 1)
            return torch.index_select(tensor, 0, idx)
        else:
            # perform vectorized index_select for floor and ceil
            low = torch.clamp(pos.floor().long(), 0, old - 1)
            high = torch.clamp(pos.ceil().long(), 0, old - 1)
            low_vals = torch.index_select(tensor, 0, low)
            high_vals = torch.index_select(tensor, 0, high)
            w = (pos - pos.floor()).to(dtype=tensor.dtype).view(batch_size, *([1] * (tensor.dim() - 1)))
            return (1.0 - w) * low_vals + w * high_vals
