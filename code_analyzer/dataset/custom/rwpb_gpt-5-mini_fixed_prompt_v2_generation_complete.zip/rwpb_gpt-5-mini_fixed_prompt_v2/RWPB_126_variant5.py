
def crop_mask(masks, boxes):
    import torch
    def crop_mask(masks, boxes):
        """
        Comprehension-based approach: build each cropped mask individually and stack.
        """
        if masks.ndim != 3:
            raise ValueError("masks must be [n, h, w]")
        n, H, W = masks.shape
        if boxes.shape[0] != n or boxes.shape[1] != 4:
            raise ValueError("boxes must be [n, 4]")
        device = masks.device
        outs = []
        # Convert boxes to integer inclusive indices
        bx = boxes.cpu().float()
        x1 = torch.floor(bx[:,0]).long()
        y1 = torch.floor(bx[:,1]).long()
        x2 = torch.ceil(bx[:,2]).long()
        y2 = torch.ceil(bx[:,3]).long()
        for i in range(n):
            xi1 = int(max(0, min(W-1, x1[i].item())))
            yi1 = int(max(0, min(H-1, y1[i].item())))
            xi2 = int(max(0, min(W-1, x2[i].item())))
            yi2 = int(max(0, min(H-1, y2[i].item())))
            out = torch.zeros((H, W), dtype=masks.dtype, device=device)
            if xi2 >= xi1 and yi2 >= yi1:
                out[yi1:yi2+1, xi1:xi2+1] = masks[i, yi1:yi2+1, xi1:xi2+1].to(device)
            outs.append(out)
        return torch.stack(outs, dim=0)
