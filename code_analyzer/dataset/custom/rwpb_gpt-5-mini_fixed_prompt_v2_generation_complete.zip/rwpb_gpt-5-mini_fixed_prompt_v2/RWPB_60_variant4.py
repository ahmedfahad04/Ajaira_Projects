
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    import math
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        # Use torch.linalg.norm to compute RMS (norm / sqrt(D))
        if upcast:
            orig_dtype = x.dtype
            x = x.float()
            weight = weight.float() if weight is not None else None
            bias = bias.float() if bias is not None else None
            residual = residual.float() if residual is not None else None
        D = x.size(-1)
        if weight is not None and weight.dim() == 1:
            weight = weight.view(*([1] * (x.dim() - 1)), -1)
        if bias is not None and bias.dim() == 1:
            bias = bias.view(*([1] * (x.dim() - 1)), -1)
        norm2 = torch.linalg.norm(x, ord=2, dim=-1, keepdim=True)
        rms = norm2 / math.sqrt(D)
        denom = torch.sqrt((rms * rms) + eps)  # stable combine
        normed = x / denom
        out = normed * weight if weight is not None else normed
        if bias is not None:
            out = out + bias
        if residual is not None:
            out = out + residual
        if upcast:
            out = out.to(orig_dtype)
        if prenorm:
            return out, x
        return out
