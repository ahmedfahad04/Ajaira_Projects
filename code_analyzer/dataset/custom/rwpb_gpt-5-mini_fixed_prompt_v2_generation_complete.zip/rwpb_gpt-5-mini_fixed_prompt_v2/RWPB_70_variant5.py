
def psnr_to_mse(psnr):
    import math
    import numpy as np
    def psnr_to_mse(psnr):
        if psnr is None:
            return None
        if np.isscalar(psnr) and not isinstance(psnr, (list, tuple)):
            return math.exp(-0.1 * math.log(10) * psnr)
        arr = np.asarray(psnr, dtype=float)
        return np.exp(-0.1 * np.log(10) * arr)
