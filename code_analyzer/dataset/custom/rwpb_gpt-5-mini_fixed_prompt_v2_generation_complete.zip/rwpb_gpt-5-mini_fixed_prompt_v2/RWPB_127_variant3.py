
def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
    import torch
    def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
        """
        Iteratively swap adjacent dimensions using transpose until the dimension reaches destination.
        """
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        nd = x.dim()
        if nd == 0:
            return x.contiguous() if make_contiguous else x
        src = src_dim + nd if src_dim < 0 else src_dim
        dest = dest_dim + nd if dest_dim < 0 else dest_dim
        if not (0 <= src < nd) or not (0 <= dest < nd):
            raise IndexError("src_dim or dest_dim out of range")
        if src == dest:
            return x.contiguous() if make_contiguous else x
        out = x
        # Move right
        if src < dest:
            i = src
            while i < dest:
                out = out.transpose(i, i + 1)
                i += 1
        else:
            i = src
            while i > dest:
                out = out.transpose(i, i - 1)
                i -= 1
        return out.contiguous() if make_contiguous else out
