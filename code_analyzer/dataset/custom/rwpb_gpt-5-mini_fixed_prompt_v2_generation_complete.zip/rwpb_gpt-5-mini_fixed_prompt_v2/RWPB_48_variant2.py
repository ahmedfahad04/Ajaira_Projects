
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return None
        ow, oh = original_size
        orig_area = ow * oh
        # Choose resolution with minimal absolute difference in area
        best = min(possible_resolutions, key=lambda r: abs(r[0]*r[1] - orig_area))
        return best
