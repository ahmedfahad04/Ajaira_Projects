
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        arr = np.asarray(arr, dtype=float)
        if window_size <= 0 or int(window_size) != window_size:
            raise ValueError("window_size must be a positive integer")
        w = int(window_size)
        n = arr.size
        if n == 0:
            return [np.array([]), np.array([])]
        left = w // 2
        right = w - 1 - left
        padded = np.pad(arr, (left, right), mode='reflect')
        ma_list = []
        for i in range(n):
            window = padded[i:i + w]
            ma_list.append(window.mean())
        ma = np.array(ma_list, dtype=float)
        residuals = arr - ma
        return [ma, residuals]
