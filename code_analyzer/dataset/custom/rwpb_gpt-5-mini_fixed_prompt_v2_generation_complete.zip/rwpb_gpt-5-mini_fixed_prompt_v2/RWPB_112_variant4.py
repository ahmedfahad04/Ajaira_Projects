
def submatrix(matrix, col):
    def submatrix(matrix, col):
        """
        Build the result iteratively without slicing (explicit loops).
        Normalizes negative index per row.
        """
        out = []
        for row in matrix:
            n = len(row)
            idx = col if col >= 0 else n + col
            if idx < 0 or idx >= n:
                raise IndexError("col index out of range")
            new_row = []
            for j in range(n):
                if j == idx:
                    continue
                new_row.append(row[j])
            out.append(new_row)
        return out
