
def numpy_to_pytorch(x):
    import numpy as np
    import torch
    def numpy_to_pytorch(x):
        # Ensure it's a numpy array and float32
        arr = np.asarray(x, dtype=np.float32)
        # Normalize
        arr = arr / 255.0
        # Add batch dimension at front
        arr = arr[np.newaxis, ...]
        # Ensure contiguous layout
        arr = np.ascontiguousarray(arr)
        # Convert to torch tensor and ensure float32
        return torch.from_numpy(arr).float()
