
def path_spliter(path: str):
    import os
    def path_spliter(path: str):
        if not path:
            return []
        sep = os.path.sep
        alt = os.path.altsep
        n = len(path)
        i = 0
        parts = []
        # handle Windows drive letter
        if n >= 2 and path[1] == ':':
            parts.append(path[:2])
            i = 2
        # handle leading separators (treat as root token)
        if i < n and path[i] in (sep, alt) if alt else path[i] == sep:
            parts.append(sep)
            while i < n and (path[i] == sep or (alt and path[i] == alt)):
                i += 1
        cur = []
        while i < n:
            ch = path[i]
            if ch == sep or (alt and ch == alt):
                if cur:
                    parts.append(''.join(cur))
                    cur = []
                while i < n and (path[i] == sep or (alt and path[i] == alt)):
                    i += 1
                continue
            cur.append(ch)
            i += 1
        if cur:
            parts.append(''.join(cur))
        return parts
