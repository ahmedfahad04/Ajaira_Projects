
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a == 0 or norm_b == 0:
            return (None, None)
        ua = a / norm_a
        ub = b / norm_b
        if np.allclose(ua, ub):
            return (None, None)
        dot = np.clip(np.dot(ua, ub), -1.0, 1.0)
        cross = np.cross(ua, ub)
        sin_theta = np.linalg.norm(cross)
        if sin_theta < 1e-12:
            # Vectors are opposite (dot ~ -1)
            # Find an arbitrary perpendicular axis
            abs_ua = np.abs(ua)
            idx = int(np.argmin(abs_ua))
            tmp = np.zeros(3)
            tmp[idx] = 1.0
            axis = np.cross(ua, tmp)
            axis = axis / np.linalg.norm(axis)
            angle = np.pi
            return (axis, angle)
        axis = cross / sin_theta
        angle = np.arccos(dot)
        return (axis, float(angle))
