
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    from collections.abc import Mapping
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        def gen(mapping, prefix):
            for k, v in mapping.items():
                key = prefix + sep + str(k) if prefix else str(k)
                if isinstance(v, Mapping):
                    yield from gen(v, key)
                else:
                    yield key, v
        return dict(gen(d, parent_key))
