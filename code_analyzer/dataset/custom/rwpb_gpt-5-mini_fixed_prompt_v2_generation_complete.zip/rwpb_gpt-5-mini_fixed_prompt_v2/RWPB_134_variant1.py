
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return None
        try:
            ow, oh = original_size
        except Exception:
            return None
        orig_area = ow * oh
        # Choose resolution with minimal absolute area difference. Tie-breaker: width diff, then height diff.
        best = None
        best_key = None
        for w, h in possible_resolutions:
            area = w * h
            area_diff = abs(area - orig_area)
            width_diff = abs(w - ow)
            height_diff = abs(h - oh)
            key = (area_diff, width_diff, height_diff)
            if best_key is None or key < best_key:
                best_key = key
                best = (w, h)
        return best
