
def pad_camera_extrinsics_4x4(extrinsics):
    import torch
    def pad_camera_extrinsics_4x4(extrinsics):
        if not isinstance(extrinsics, torch.Tensor):
            raise TypeError("extrinsics must be a torch.Tensor")
        if extrinsics.dim() < 2:
            raise ValueError("extrinsics must have at least 2 dimensions")
        h, w = extrinsics.shape[-2], extrinsics.shape[-1]
        if (h, w) == (4, 4):
            return extrinsics.clone()
        if (h, w) != (3, 4):
            raise ValueError(f"Unsupported extrinsics shape {extrinsics.shape}; expected (...,3,4) or (...,4,4).")
        # Build last row explicitly using ones and zeros
        batch_shape = extrinsics.shape[:-2]
        zeros = torch.zeros(batch_shape + (1, 3), dtype=extrinsics.dtype, device=extrinsics.device)
        one = torch.ones(batch_shape + (1, 1), dtype=extrinsics.dtype, device=extrinsics.device)
        last_row = torch.cat([zeros, one], dim=-1)
        return torch.cat([extrinsics, last_row], dim=-2)
