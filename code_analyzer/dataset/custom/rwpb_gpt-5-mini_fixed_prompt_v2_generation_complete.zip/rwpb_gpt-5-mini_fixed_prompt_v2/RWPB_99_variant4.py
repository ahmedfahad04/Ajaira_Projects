
def focal2fov(focal, pixels):
    import math
    def focal2fov(focal, pixels):
        # coerce types and handle zero explicitly
        try:
            f = float(focal)
        except Exception:
            f = 0.0
        try:
            p = float(pixels)
        except Exception:
            p = 0.0
        if f == 0.0:
            return KeyError
        ratio = p / (2.0 * f)
        return 2.0 * math.atan(ratio)
