
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        if repetition_penalty == 1.0:
            return logits
        rp = float(repetition_penalty)
        logits = logits.clone()
        if prev_output_tokens.numel() == 0:
            return logits
        # iterate over globally unique tokens and apply to batches where they appeared
        unique_tokens = torch.unique(prev_output_tokens)
        for token in unique_tokens:
            t = int(token.item())
            # find which batch entries used this token
            appeared = (prev_output_tokens == t).any(dim=1)
            if appeared.any():
                vals = logits[appeared, t]
                pos = vals > 0
                if pos.any():
                    logits[appeared, t][pos] = vals[pos] / rp
                if (~pos).any():
                    logits[appeared, t][~pos] = vals[~pos] * rp
        return logits
