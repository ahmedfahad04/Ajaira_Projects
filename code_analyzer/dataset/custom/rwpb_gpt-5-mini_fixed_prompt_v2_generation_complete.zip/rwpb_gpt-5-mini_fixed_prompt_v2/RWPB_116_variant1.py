
def round_nearest_multiple(number, a, direction='standard'):
    from decimal import Decimal, ROUND_HALF_UP, ROUND_FLOOR, ROUND_CEILING, getcontext
    def round_nearest_multiple(number, a, direction='standard'):
        if a == 0:
            raise ValueError("a must be non-zero")
        getcontext().prec = 50
        dec_a = Decimal(str(a))
        dec_num = Decimal(str(number))
        ratio = dec_num / dec_a
        dir_lower = (direction or 'standard').lower()
        if dir_lower == 'standard':
            rounding = ROUND_HALF_UP
        elif dir_lower == 'down':
            rounding = ROUND_FLOOR
        elif dir_lower == 'up':
            rounding = ROUND_CEILING
        else:
            raise ValueError("direction must be 'standard', 'down' or 'up'")
        rounded_int = ratio.quantize(Decimal('1'), rounding=rounding)
        result = rounded_int * dec_a
        # match precision of a
        exp = -dec_a.as_tuple().exponent
        if exp < 0:
            exp = 0
        fmt = f"{{0:.{exp}f}}"
        return float(fmt.format(result))
