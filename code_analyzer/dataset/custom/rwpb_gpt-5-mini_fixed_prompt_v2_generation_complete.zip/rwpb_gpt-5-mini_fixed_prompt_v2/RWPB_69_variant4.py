
def fovx_to_fovy(fovx, aspect):
    import math
    def fovx_to_fovy(fovx, aspect):
        if aspect <= 0:
            raise ValueError("aspect must be positive")
        # Solve for half vertical FoV using Newton iteration for robustness
        target = math.tan(0.5 * float(fovx))
        if target == 0.0:
            return 0.0
        # initial guess
        half_y = math.atan(target / aspect)
        for _ in range(20):
            # f(half_y) = tan(half_y)*aspect - target
            tan_h = math.tan(half_y)
            f = tan_h * aspect - target
            # f' = aspect * sec^2(half_y) = aspect * (1 + tan^2(half_y))
            df = aspect * (1.0 + tan_h * tan_h)
            if df == 0:
                break
            step = f / df
            half_y -= step
            if abs(step) < 1e-12:
                break
        return 2.0 * half_y
