
def rotate_about_z_axis(vector, theta):
    import numpy as np
    def rotate_about_z_axis(vector, theta):
        """
        Rotate using a homogeneous transformation (4x4) for demonstration.
        """
        v = np.asarray(vector, dtype=float).reshape(3,)
        c = np.cos(theta)
        s = np.sin(theta)
        H = np.array([[c, -s, 0., 0.],
                      [s,  c, 0., 0.],
                      [0., 0., 1., 0.],
                      [0., 0., 0., 1.]], dtype=float)
        v4 = np.array([v[0], v[1], v[2], 1.], dtype=float)
        res4 = H.dot(v4)
        return res4[:3]
