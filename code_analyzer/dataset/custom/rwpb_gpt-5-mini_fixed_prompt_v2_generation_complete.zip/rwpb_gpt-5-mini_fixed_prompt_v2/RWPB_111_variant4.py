
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        # Construct using repeat_interleave and view (another broadcasting approach)
        if H <= 0 or W <= 0 or B <= 0:
            return torch.empty((B, 2, H, W))
        # create 1D normalized axes
        x = torch.linspace(-1.0, 1.0, W, dtype=torch.float32)
        y = torch.linspace(-1.0, 1.0, H, dtype=torch.float32)
        # expand to 2D via outer operations
        x_row = x.unsqueeze(0).repeat(H, 1)  # (H, W)
        y_col = y.unsqueeze(1).repeat(1, W)  # (H, W)
        grid2 = torch.stack((x_row, y_col), dim=0)  # (2, H, W)
        # replicate for batch
        grid_b = grid2.unsqueeze(0).repeat(B, 1, 1, 1)
        return grid_b
