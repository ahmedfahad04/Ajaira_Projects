
def rotate_about_x_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        """
        Rotate using direct component formulas (no matrix allocation).
        """
        v = np.asarray(vector, dtype=float)
        if v.size != 3:
            raise ValueError("vector must have exactly 3 elements")
        x = float(v[0])
        y = float(v[1])
        z = float(v[2])
        c = math.cos(theta)
        s = math.sin(theta)
        y_new = y * c - z * s
        z_new = y * s + z * c
        return np.array([x, y_new, z_new], dtype=float)
