
def exp_smooth(vals, alpha):
    import numpy as np
    def exp_smooth(vals, alpha):
        vals = np.asarray(vals)
        if vals.size == 0:
            raise KeyError
        vals = vals.astype(float)
        n = vals.shape[0]
        out = np.empty(n, dtype=float)
        out[0] = vals[0]
        for i in range(1, n):
            out[i] = alpha * vals[i] + (1.0 - alpha) * out[i - 1]
        return out
