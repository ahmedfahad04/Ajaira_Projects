
def arccos2(vector, value):
    import math
    import numpy as np
    def arccos2(vector, value):
        v = float(value)
        if v != v:
            return float('nan')
        v = max(-1.0, min(1.0, v))
        sin_mag = math.sqrt(max(0.0, 1.0 - v * v))
        y = float(np.asarray(vector)[1])
        s = sin_mag if y >= 0.0 else -sin_mag
        angle = math.atan2(s, v)
        if angle < 0.0:
            angle += 2.0 * math.pi
        return angle
