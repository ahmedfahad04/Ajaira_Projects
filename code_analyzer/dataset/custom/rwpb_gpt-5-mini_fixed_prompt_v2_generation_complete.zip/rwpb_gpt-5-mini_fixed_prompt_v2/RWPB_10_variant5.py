
def euler2rot(euler_angle):
    import torch
    def euler2rot(euler_angle):
        if not isinstance(euler_angle, torch.Tensor):
            euler_angle = torch.tensor(euler_angle)
        if euler_angle.dim() == 1:
            euler_angle = euler_angle.unsqueeze(0)
        rx = euler_angle[:, 0]
        ry = euler_angle[:, 1]
        rz = euler_angle[:, 2]
        cx = torch.cos(rx); sx = torch.sin(rx)
        cy = torch.cos(ry); sy = torch.sin(ry)
        cz = torch.cos(rz); sz = torch.sin(rz)
        B = euler_angle.shape[0]
        device = euler_angle.device
        dtype = euler_angle.dtype
        # start with basis vectors
        ex = torch.tensor([1.,0.,0.], device=device, dtype=dtype).view(1,3).repeat(B,1)
        ey = torch.tensor([0.,1.,0.], device=device, dtype=dtype).view(1,3).repeat(B,1)
        ez = torch.tensor([0.,0.,1.], device=device, dtype=dtype).view(1,3).repeat(B,1)
        # Rx applied to basis
        Rx_ex = torch.stack([ex[:,0], cx*ex[:,1] - sx*ex[:,2], sx*ex[:,1] + cx*ex[:,2]], dim=1)
        Rx_ey = torch.stack([ey[:,0], cx*ey[:,1] - sx*ey[:,2], sx*ey[:,1] + cx*ey[:,2]], dim=1)
        Rx_ez = torch.stack([ez[:,0], cx*ez[:,1] - sx*ez[:,2], sx*ez[:,1] + cx*ez[:,2]], dim=1)
        # Ry applied to results
        def apply_Ry(v):
            return torch.stack([cy*v[:,0] + sy*v[:,2],
                                v[:,1],
                                -sy*v[:,0] + cy*v[:,2]], dim=1)
        Ry_ex = apply_Ry(Rx_ex)
        Ry_ey = apply_Ry(Rx_ey)
        Ry_ez = apply_Ry(Rx_ez)
        # Rz applied to results
        def apply_Rz(v):
            return torch.stack([cz*v[:,0] - sz*v[:,1],
                                sz*v[:,0] + cz*v[:,1],
                                v[:,2]], dim=1)
        R_ex = apply_Rz(Ry_ex)
        R_ey = apply_Rz(Ry_ey)
        R_ez = apply_Rz(Ry_ez)
        # columns are the rotated basis vectors
        R = torch.stack([R_ex, R_ey, R_ez], dim=2)
        return R
