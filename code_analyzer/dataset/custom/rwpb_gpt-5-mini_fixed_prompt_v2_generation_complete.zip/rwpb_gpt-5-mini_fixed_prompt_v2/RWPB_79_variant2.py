
def pr_from_grav(grav):
    import numpy as np
    import math
    def pr_from_grav(grav):
        g = np.asarray(grav, dtype=float)
        single = False
        if g.ndim == 1:
            g = g.reshape(1, 3)
            single = True
        out_p = []
        out_r = []
        for row in g:
            gx, gy, gz = row
            # safe hypotenuse
            denom = math.hypot(gy, gz)
            pitch = math.atan2(-gx, denom)
            roll = math.atan2(gy, gz)
            out_p.append(pitch)
            out_r.append(roll)
        pitches = np.array(out_p)
        rolls = np.array(out_r)
        if single:
            return pitches.reshape(-1,), rolls.reshape(-1,)
        return pitches, rolls
