
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        preds = torch.as_tensor(preds)
        labels = torch.as_tensor(labels)
        if preds.dim() == labels.dim() and preds.dim() == 2:
            preds = preds.unsqueeze(0)
            labels = labels.unsqueeze(0)
        if preds.dtype.is_floating_point:
            preds_bool = (preds >= 0.5)
        else:
            preds_bool = preds == 1
        labels_bool = labels == 1
        if ignore is not None:
            ignore_mask = labels != ignore
            if ignore_mask.dim() == 2:
                ignore_mask = ignore_mask.unsqueeze(0)
            ignore_mask = ignore_mask.expand_as(labels_bool)
        else:
            ignore_mask = torch.ones_like(labels_bool, dtype=torch.bool)
        preds_bool = preds_bool & ignore_mask
        labels_bool = labels_bool & ignore_mask
        if not per_image:
            inter = (preds_bool & labels_bool).sum().float()
            union = (preds_bool | labels_bool).sum().float()
            if union.item() == 0:
                return float(EMPTY * 100.0)
            return float((inter / union).item() * 100.0)
        else:
            inter = (preds_bool & labels_bool).view(preds_bool.size(0), -1).sum(dim=1).float()
            union = (preds_bool | labels_bool).view(preds_bool.size(0), -1).sum(dim=1).float()
            iou_per = torch.where(union == 0, torch.full_like(union, float(EMPTY)), inter / union)
            return float(iou_per.mean().item() * 100.0)
