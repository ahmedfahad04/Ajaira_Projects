
def logbessel_I_scipy(nu, z, check = True):
    import torch
    import numpy as _np
    from scipy import special as _special
    def logbessel_I_scipy(nu, z, check = True):
        # Accept torch.Tensor or array-like/scalar
        was_tensor = isinstance(z, torch.Tensor)
        device = z.device if was_tensor else None
        dtype = z.dtype if was_tensor else None
        z_np = z.detach().cpu().numpy() if was_tensor else _np.asarray(z)
        # Use scipy's iv directly
        iv_vals = _special.iv(nu, z_np)
        # convert to log, handle zeros
        with _np.errstate(divide='ignore', invalid='ignore'):
            log_iv = _np.log(iv_vals)
        if check:
            # Raise if any non-finite or -inf (zero) encountered
            if _np.any(~_np.isfinite(log_iv)):
                raise ValueError("log(I_nu(z)) contains non-finite values (possibly I_nu(z)=0).")
        # Convert back to torch tensor
        result = torch.as_tensor(log_iv)
        if was_tensor:
            result = result.to(device=device, dtype=dtype)
        return result
