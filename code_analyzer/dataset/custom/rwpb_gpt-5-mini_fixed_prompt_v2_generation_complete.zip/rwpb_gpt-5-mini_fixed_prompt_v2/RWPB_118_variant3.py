
def filter_nan(ts, vs):
    import numpy as np
    def filter_nan(ts, vs):
        ts = np.asarray(ts)
        vs = np.asarray(vs)
        out_t = []
        out_v = []
        for t, v in zip(ts, vs):
            if not (np.isnan(t) or np.isnan(v)):
                out_t.append(t)
                out_v.append(v)
        if len(out_t) == 0:
            return np.array([], dtype=ts.dtype), np.array([], dtype=vs.dtype)
        return np.array(out_t, dtype=ts.dtype), np.array(out_v, dtype=vs.dtype)
