
def get_line_angle(x1, y1, x2, y2):
    import math
    def get_line_angle(x1, y1, x2, y2):
        dx = x2 - x1
        dy = y2 - y1
        r = math.hypot(dx, dy)
        if r == 0:
            return 0.0
        cos_theta = dx / r
        cos_theta = max(-1.0, min(1.0, cos_theta))
        angle = math.degrees(math.acos(cos_theta))
        if dy < 0:
            angle = 360.0 - angle
        return angle
