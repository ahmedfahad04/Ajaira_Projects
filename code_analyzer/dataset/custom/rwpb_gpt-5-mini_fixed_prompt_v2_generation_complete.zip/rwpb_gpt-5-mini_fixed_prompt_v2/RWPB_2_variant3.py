
def logbessel_I_scipy(nu, z, check = True):
    import torch
    import numpy as _np
    from scipy import special as _special
    def logbessel_I_scipy(nu, z, check = True):
        # Elementwise robust computation: try iv, if overflow/invalid use ive + |z|
        was_tensor = isinstance(z, torch.Tensor)
        device = z.device if was_tensor else None
        dtype = z.dtype if was_tensor else None
        z_np = z.detach().cpu().numpy() if was_tensor else _np.asarray(z)
        # First attempt: direct iv
        with _np.errstate(over='ignore', divide='ignore', invalid='ignore'):
            iv_vals = _special.iv(nu, z_np)
            log_iv_direct = _np.log(iv_vals)
        # Determine problematic entries
        bad = ~_np.isfinite(log_iv_direct)
        if _np.any(bad):
            # Use ive-based stable computation for those entries
            ive_vals = _special.ive(nu, z_np[bad])
            # ive may be zero/neg; add abs(z) for scaling
            zbad = _np.abs(z_np[bad])
            with _np.errstate(divide='ignore', invalid='ignore'):
                log_iv_direct[bad] = _np.log(_np.abs(ive_vals)) + zbad
        if check:
            if _np.any(~_np.isfinite(log_iv_direct)):
                raise ValueError("log(I_nu(z)) contains non-finite values.")
        result = torch.as_tensor(log_iv_direct)
        if was_tensor:
            result = result.to(device=device, dtype=dtype)
        return result
