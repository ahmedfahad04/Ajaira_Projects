
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return None
        ow, oh = original_size
        # Prioritize matching aspect ratio, then area closeness
        if oh == 0:
            ar_orig = float('inf')
        else:
            ar_orig = ow / oh
        def score(r):
            rw, rh = r
            ar_r = rw / rh if rh != 0 else float('inf')
            ar_diff = abs(ar_orig - ar_r)
            area_diff = abs(rw * rh - ow * oh)
            # smaller is better: aspect ratio diff weighted more
            return (ar_diff, area_diff)
        return min(possible_resolutions, key=score)
