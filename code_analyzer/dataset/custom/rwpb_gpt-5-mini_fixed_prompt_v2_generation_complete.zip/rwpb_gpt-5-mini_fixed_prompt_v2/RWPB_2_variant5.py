
def logbessel_I_scipy(nu, z, check = True):
    import torch
    import numpy as _np
    from scipy import special as _special
    def logbessel_I_scipy(nu, z, check = True):
        # Series expansion for small z, ive for large z; combine for robustness
        was_tensor = isinstance(z, torch.Tensor)
        device = z.device if was_tensor else None
        dtype = z.dtype if was_tensor else None
        z_np = z.detach().cpu().numpy() if was_tensor else _np.asarray(z)
        z_flat = z_np.ravel() if z_np.size != 1 else _np.atleast_1d(z_np)
        out = _np.empty_like(z_flat, dtype=_np.float64)
        # thresholds
        small_thresh = 1.0  # small z use series
        large_thresh = 50.0  # very large use ive scaling
        for i, val in enumerate(z_flat):
            if _np.isnan(val):
                out[i] = _np.nan
                continue
            if val == 0.0:
                # I_nu(0) = 0 for nu>0, =1 for nu==0
                if float(nu) == 0.0:
                    out[i] = 0.0
                else:
                    out[i] = -_np.inf
                continue
            if _np.abs(val) <= small_thresh:
                # use power series: I_nu(z) = sum_{k=0} (z/2)^{2k+nu} / (k! Gamma(k+nu+1))
                # compute in log-space with log-sum-exp
                max_terms = 200
                logs = []
                logz2 = _np.log(_np.abs(val)/2.0)
                for k in range(0, 60):
                    # term log
                    term_log = (2*k + nu)*logz2 - _special.gammaln(k+1) - _special.gammaln(k+nu+1)
                    logs.append(term_log)
                    # stop if next term is tiny relative to max
                    if k > 0 and logs[-1] < logs[0] - 50:
                        break
                # log-sum-exp
                amax = max(logs)
                s = _np.sum(_np.exp(_np.array(logs) - amax))
                out[i] = amax + _np.log(s)
            elif _np.abs(val) >= large_thresh:
                # use ive scaling: log(I) = log(|ive|) + |z|
                ive = _special.ive(nu, val)
                with _np.errstate(divide='ignore', invalid='ignore'):
                    out[i] = _np.log(_np.abs(ive)) + _np.abs(val)
            else:
                # medium range: direct iv
                with _np.errstate(divide='ignore', invalid='ignore'):
                    out[i] = _np.log(_special.iv(nu, val))
        # reshape
        out = out.reshape(z_np.shape)
        if check:
            if _np.any(~_np.isfinite(out)):
                raise ValueError("log(I_nu(z)) contains non-finite values.")
        result = torch.as_tensor(out)
        if was_tensor:
            result = result.to(device=device, dtype=dtype)
        return result
