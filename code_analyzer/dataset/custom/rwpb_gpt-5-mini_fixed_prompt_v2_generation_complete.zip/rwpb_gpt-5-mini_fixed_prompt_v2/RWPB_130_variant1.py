
def bbox_ioa(box1, box2, iou=False, eps=1e-7):
    import numpy as np
    def bbox_ioa(box1, box2, iou=False, eps=1e-7):
        box1 = np.asarray(box1, dtype=float)
        box2 = np.asarray(box2, dtype=float)
        if box1.ndim == 1:
            box1 = box1.reshape(1, 4)
        if box2.ndim == 1:
            box2 = box2.reshape(1, 4)
        n = box1.shape[0]
        m = box2.shape[0]
        if n == 0 or m == 0:
            return np.zeros((n, m), dtype=float)
        b1 = box1[:, None, :]
        b2 = box2[None, :, :]
        x1 = np.maximum(b1[..., 0], b2[..., 0])
        y1 = np.maximum(b1[..., 1], b2[..., 1])
        x2 = np.minimum(b1[..., 2], b2[..., 2])
        y2 = np.minimum(b1[..., 3], b2[..., 3])
        w = np.clip(x2 - x1, 0, None)
        h = np.clip(y2 - y1, 0, None)
        inter = w * h
        area1 = np.clip((box1[:, 2] - box1[:, 0]) * (box1[:, 3] - box1[:, 1]), 0, None)
        area2 = np.clip((box2[:, 2] - box2[:, 0]) * (box2[:, 3] - box2[:, 1]), 0, None)
        if iou:
            denom = area1[:, None] + area2[None, :] - inter + eps
        else:
            denom = area2[None, :] + eps
        return inter / denom
