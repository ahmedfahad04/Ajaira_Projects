
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    def generate_grids(lower_limit, upper_limit, grid_size):
        lower = lower_limit.clone().to(dtype=torch.get_default_dtype())
        upper = upper_limit.clone().to(dtype=torch.get_default_dtype())
        if lower.dim() == 0:
            lower = lower.unsqueeze(0)
        if upper.dim() == 0:
            upper = upper.unsqueeze(0)
        D = lower.numel()
        if torch.is_tensor(grid_size):
            if grid_size.dim() == 0:
                gs = [int(grid_size.item())] * D
            else:
                gs = [int(x.item()) for x in grid_size.view(-1)]
        else:
            gs = [int(grid_size)] * D
        steps = (upper - lower) / torch.tensor(gs, dtype=lower.dtype)
        result = []
        def rec(idx, cur):
            if idx == D:
                result.append(torch.tensor(cur, dtype=lower.dtype))
                return
            for i in range(gs[idx]):
                rec(idx + 1, cur + [lower[idx].item() + i * steps[idx].item()])
        if D == 0:
            return torch.empty((0,0), dtype=lower.dtype), torch.empty((0,0), dtype=lower.dtype)
        rec(0, [])
        lowers = torch.stack(result, dim=0) if result else torch.empty((0,D), dtype=lower.dtype)
        uppers = lowers + steps.unsqueeze(0)
        return lowers, uppers
