
def rot6d_to_rotmat(x):
    def rot6d_to_rotmat(x):
        import torch
        if not torch.is_tensor(x):
            x = torch.tensor(x)
        if x.dim() != 2 or x.shape[1] != 6:
            raise ValueError("Input must have shape (B,6)")
        B = x.shape[0]
        mats = []
        for i in range(B):
            v = x[i]
            a1 = v[0:3]
            a2 = v[3:6]
            n1 = a1.norm(p=2)
            if n1 == 0:
                b1 = a1.clone()
            else:
                b1 = a1 / n1
            proj = (b1 * a2).sum()
            a2_orth = a2 - proj * b1
            n2 = a2_orth.norm(p=2)
            if n2 == 0:
                b2 = a2_orth.clone()
            else:
                b2 = a2_orth / n2
            b3 = torch.cross(b1, b2)
            R = torch.stack((b1, b2, b3), dim=1)
            mats.append(R)
        return torch.stack(mats, dim=0)
