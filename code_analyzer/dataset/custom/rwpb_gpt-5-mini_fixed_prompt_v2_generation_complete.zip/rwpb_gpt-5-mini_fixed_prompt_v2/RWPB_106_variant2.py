
def interpolate_features(features,:
    import numpy as np
    def interpolate_features(features,
                             input_rate,
                             output_rate,
                             output_len):
        features = np.asarray(features, dtype=np.float32)
        if features.size == 0:
            return np.zeros((output_len,) + features.shape[1:], dtype=features.dtype)
        orig_ndim = features.ndim
        if features.ndim == 1:
            feats = features.reshape(-1, 1)
        else:
            feats = features
        n = feats.shape[0]
        # map each output frame index to fractional input index
        scale = float(input_rate) / float(output_rate)
        positions = (np.arange(output_len).astype(np.float64)) * scale  # fractional index in input
        # clamp positions to [0, n-1]
        positions = np.clip(positions, 0, n - 1)
        left = np.floor(positions).astype(int)
        right = np.minimum(left + 1, n - 1)
        w = positions - left  # weight for right
        # produce output by weighted sum
        left_vals = feats[left]
        right_vals = feats[right]
        out = (1.0 - w)[:, None] * left_vals + w[:, None] * right_vals
        if orig_ndim == 1:
            return out.ravel().astype(features.dtype)
        return out.astype(features.dtype)
