
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        # Ensure numpy array
        arr = np.array(img)
        # work on uint8 binary image (foreground > 0)
        orig_dtype = arr.dtype
        max_val = int(arr.max()) if arr.size > 0 else 255
        if max_val == 0:
            return arr.copy()
        bin_img = (arr > 0).astype('uint8') * 255
        h, w = bin_img.shape[:2]
        # pad mask for floodFill
        mask = np.zeros((h + 2, w + 2), dtype='uint8')
        # flood fill from (0,0) on a copy to mark external background
        im_floodfill = bin_img.copy()
        cv2.floodFill(im_floodfill, mask, (0, 0), 255)
        # invert floodfilled to get holes
        holes = cv2.bitwise_not(im_floodfill)
        # holes now contains the inner holes as 255
        filled = cv2.bitwise_or(bin_img, holes)
        # scale back to original max value
        result = (filled // 255 * max_val).astype(orig_dtype)
        return result
