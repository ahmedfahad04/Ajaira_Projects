
def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
    import torch
    def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
        """
        Manual permutation by building list: pop then insert.
        """
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        nd = x.dim()
        if nd == 0:
            return x.contiguous() if make_contiguous else x
        src = src_dim + nd if src_dim < 0 else src_dim
        dest = dest_dim + nd if dest_dim < 0 else dest_dim
        if not (0 <= src < nd) or not (0 <= dest < nd):
            raise IndexError("src_dim or dest_dim out of range")
        if src == dest:
            return x.contiguous() if make_contiguous else x
        perm = list(range(nd))
        item = perm.pop(src)
        perm.insert(dest, item)
        out = x.permute(*perm)
        return out.contiguous() if make_contiguous else out
