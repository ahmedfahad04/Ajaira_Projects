
def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
    from typing import Callable, Dict, Tuple, Any
    import inspect
    from functools import partial
    def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
        try:
            sig = inspect.signature(func)
        except (ValueError, TypeError):
            # Can't get signature (built-in or similar), be conservative: no kwargs
            matched = {}
            return partial(func, **matched), matched
        params = dict(params or {})
        parameters = sig.parameters.values()
        # If function accepts **kwargs, pass everything
        if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in parameters):
            matched = dict(params)
            return partial(func, **matched), matched
        allowed_kinds = {inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY}
        allowed_names = {p.name for p in parameters if p.kind in allowed_kinds}
        matched = {k: v for k, v in params.items() if k in allowed_names}
        return partial(func, **matched), matched
