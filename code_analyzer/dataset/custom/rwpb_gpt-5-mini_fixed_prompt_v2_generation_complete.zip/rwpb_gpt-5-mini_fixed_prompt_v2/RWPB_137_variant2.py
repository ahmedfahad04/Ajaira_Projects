
def fit_params(:
    def fit_params(
        x,
        y,
        fun,
        a_range=(-10, 10),
        b_range=(-10, 10),
        grid_number=101,
        iteration=3,
        verbose=True,
    ):
        import numpy as _np
        from sklearn.linear_model import LinearRegression as _LR
        import torch as _torch
        is_torch = _torch.is_tensor(x) or _torch.is_tensor(y)
        if is_torch:
            x_arr = _torch.flatten(x).detach().cpu().numpy() if _torch.is_tensor(x) else _np.asarray(x)
            y_arr = _torch.flatten(y).detach().cpu().numpy() if _torch.is_tensor(y) else _np.asarray(y)
        else:
            x_arr = _np.asarray(x).astype(float)
            y_arr = _np.asarray(y).astype(float)
        a_lo, a_hi = float(a_range[0]), float(a_range[1])
        b_lo, b_hi = float(b_range[0]), float(b_range[1])
        best = (None, None, None, None, -1e9)
        for it in range(iteration):
            a_vals = _np.linspace(a_lo, a_hi, grid_number)
            b_vals = _np.linspace(b_lo, b_hi, grid_number)
            for a in a_vals:
                for b in b_vals:
                    z = a * x_arr + b
                    try:
                        F = fun(z)
                        if _torch.is_tensor(F):
                            F = F.detach().cpu().numpy()
                    except Exception:
                        # elementwise fallback
                        F = _np.array([fun(val) for val in z])
                    F = F.reshape(-1, 1)
                    model = _LR().fit(F, y_arr)
                    pred = model.predict(F)
                    ss_res = ((y_arr - pred) ** 2).sum()
                    ss_tot = ((y_arr - y_arr.mean()) ** 2).sum()
                    if ss_tot == 0:
                        r2 = 1.0 if ss_res == 0 else 0.0
                    else:
                        r2 = 1.0 - ss_res / ss_tot
                    if r2 > best[4]:
                        best = (a, b, float(model.coef_[0]), float(model.intercept_), float(r2))
            # refine
            a_best, b_best = best[0], best[1]
            a_span = (a_hi - a_lo) / max(10.0, grid_number - 1)
            b_span = (b_hi - b_lo) / max(10.0, grid_number - 1)
            a_lo = a_best - a_span
            a_hi = a_best + a_span
            b_lo = b_best - b_span
            b_hi = b_best + b_span
        if verbose:
            print("r2 is", best[4])
        if is_torch:
            import torch as _t
            return (_t.tensor(best[0]), _t.tensor(best[1]), _t.tensor(best[2]), _t.tensor(best[3]), _t.tensor(best[4]))
        else:
            return best[0], best[1], best[2], best[3], best[4]
