
def mean(l, ignore_nan=False, empty=0):
    import math
    def mean(l, ignore_nan=False, empty=0):
        it = iter(l)
        # Helper to check NaN safely
        def _isnan(x):
            try:
                return math.isnan(x)
            except Exception:
                return False
        total = 0.0
        count = 0
        # Try to find the first qualifying element to detect emptiness without materializing list
        while True:
            try:
                x = next(it)
            except StopIteration:
                break
            if _isnan(x):
                if ignore_nan:
                    continue
                else:
                    return float('nan')
            total += x
            count += 1
            break
        # Continue consuming remaining items
        for x in it:
            if _isnan(x):
                if ignore_nan:
                    continue
                else:
                    return float('nan')
            total += x
            count += 1
        if count == 0:
            if empty == 'raise':
                raise ValueError("mean of empty sequence")
            return empty
        return total / count
