
def numpy_to_pytorch(x):
    import numpy as np
    import torch
    def numpy_to_pytorch(x):
        # Defensive conversion: support list inputs as well
        arr = np.array(x, dtype=np.float32, copy=False)
        # Normalize
        arr = arr / 255.0
        # Ensure at least 1 batch dim
        if arr.ndim == 0:
            arr = arr.reshape((1,))
        arr = np.expand_dims(arr, axis=0)
        # Ensure contiguous memory layout
        if not arr.flags['C_CONTIGUOUS']:
            arr = np.copy(arr)
        # Create tensor (torch.tensor will copy, torch.from_numpy will share memory)
        # Prefer from_numpy for performance
        tensor = torch.from_numpy(arr)
        # Cast to float (ensures torch.float32)
        return tensor.float()
