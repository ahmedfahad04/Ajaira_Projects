
def pr_from_grav(grav):
    import numpy as np
    def pr_from_grav(grav):
        grav = np.asarray(grav, dtype=float)
        if grav.ndim == 1:
            grav = grav.reshape(1, 3)
        gx = grav[:, 0]
        gy = grav[:, 1]
        gz = grav[:, 2]
        # pitch: atan2(-gx, sqrt(gy^2+gz^2))
        denom = np.hypot(gy, gz)
        pitches = np.arctan2(-gx, denom)
        # roll: atan2(gy, gz)
        rolls = np.arctan2(gy, gz)
        return pitches.reshape(-1,), rolls.reshape(-1,)
