
def format_ratio(ratio):
    import math
    def format_ratio(ratio):
        r = float(ratio)
        if math.isnan(r):
            return "percentage:NaN"
        if math.isinf(r):
            return f"percentage:{r}"
        truncated = math.trunc(r * 1000) / 1000.0
        return "percentage:" + f"{truncated:.3f}"
