
def exp_smooth(vals, alpha):
    import numpy as np
    def exp_smooth(vals, alpha):
        vals_list = list(vals)
        if len(vals_list) == 0:
            raise KeyError
        s = float(vals_list[0])
        out = [s]
        for x in vals_list[1:]:
            s = alpha * float(x) + (1.0 - alpha) * s
            out.append(s)
        return np.array(out, dtype=float)
