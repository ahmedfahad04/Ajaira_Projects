
def validate_user_id(user_id):
    import re
    def validate_user_id(user_id):
        if not isinstance(user_id, str) or not user_id:
            return False
        return re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', user_id) is not None
