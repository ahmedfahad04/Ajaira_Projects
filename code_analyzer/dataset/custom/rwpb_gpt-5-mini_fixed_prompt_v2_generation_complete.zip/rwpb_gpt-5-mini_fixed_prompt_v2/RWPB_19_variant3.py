
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        import numpy as np
        preds = np.asarray(preds)
        references = np.asarray(references)
        if preds.shape != references.shape:
            raise ValueError("preds and references must have same shape")
        n = preds.size
        if n < 2:
            return 0.0
        dp = preds.reshape(-1,1) - preds.reshape(1,-1)
        dr = references.reshape(-1,1) - references.reshape(1,-1)
        sp = np.sign(dp)
        sr = np.sign(dr)
        # consider each unordered pair once (i<j)
        i_upper = np.triu_indices(n, k=1)
        matches = (sp[i_upper] == sr[i_upper]).sum()
        total = len(i_upper[0])
        return float(matches) / total if total > 0 else 0.0
