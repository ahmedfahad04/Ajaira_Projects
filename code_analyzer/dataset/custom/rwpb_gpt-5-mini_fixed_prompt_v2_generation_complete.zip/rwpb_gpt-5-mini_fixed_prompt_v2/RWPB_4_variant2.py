
def rot6d_to_rotmat(x):
    def rot6d_to_rotmat(x):
        import torch
        if not torch.is_tensor(x):
            x = torch.tensor(x)
        if x.dim() != 2 or x.shape[1] != 6:
            raise ValueError("Input must have shape (B,6)")
        B = x.shape[0]
        a = x.view(B, 2, 3).transpose(1, 2)
        q, r = torch.linalg.qr(a, mode='reduced')
        b1 = q[:, :, 0]
        b2 = q[:, :, 1]
        b3 = torch.cross(b1, b2, dim=1)
        R = torch.stack((b1, b2, b3), dim=2)
        return R
