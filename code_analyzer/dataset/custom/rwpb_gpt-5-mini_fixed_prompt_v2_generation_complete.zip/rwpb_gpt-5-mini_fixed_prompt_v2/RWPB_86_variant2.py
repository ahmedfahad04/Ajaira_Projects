
def inverse_sigmoid(x):
    import torch
    def inverse_sigmoid(x):
        x = torch.as_tensor(x)
        if not torch.is_floating_point(x):
            x = x.float()
        eps = float(torch.finfo(x.dtype).eps)
        try:
            return torch.logit(x, eps=eps)
        except Exception:
            x_clamped = torch.clamp(x, eps, 1.0 - eps)
            return torch.log(x_clamped) - torch.log1p(-x_clamped)
