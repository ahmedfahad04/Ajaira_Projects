
def xywh2xyxy(x):
    import numpy as np
    import torch
    from collections.abc import Sequence
    def xywh2xyxy(x):
        if isinstance(x, torch.Tensor):
            if x.numel() == 0:
                return x.clone()
            x0 = x[..., 0]
            y0 = x[..., 1]
            w = x[..., 2]
            h = x[..., 3]
            return torch.stack((x0, y0, x0 + w, y0 + h), dim=-1)
        if isinstance(x, Sequence) and not isinstance(x, np.ndarray):
            arr = np.array(x)
        else:
            arr = np.asarray(x)
        if arr.size == 0:
            return arr.copy()
        x0 = arr[..., 0]
        y0 = arr[..., 1]
        w = arr[..., 2]
        h = arr[..., 3]
        return np.stack((x0, y0, x0 + w, y0 + h), axis=-1)
