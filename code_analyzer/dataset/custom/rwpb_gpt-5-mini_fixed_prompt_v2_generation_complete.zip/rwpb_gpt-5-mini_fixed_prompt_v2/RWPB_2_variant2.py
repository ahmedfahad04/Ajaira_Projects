
def logbessel_I_scipy(nu, z, check = True):
    import torch
    import numpy as _np
    from scipy import special as _special
    def logbessel_I_scipy(nu, z, check = True):
        # Use exponentially-scaled ive for numerical stability: I = exp(|z|) * ive
        was_tensor = isinstance(z, torch.Tensor)
        device = z.device if was_tensor else None
        dtype = z.dtype if was_tensor else None
        z_np = z.detach().cpu().numpy() if was_tensor else _np.asarray(z)
        # Use absolute value of real z for scaling
        abs_z = _np.abs(z_np)
        ive_vals = _special.ive(nu, z_np)
        # ive may be zero or negative in edge cases; compute log carefully
        with _np.errstate(divide='ignore', invalid='ignore'):
            log_ive = _np.log(_np.abs(ive_vals))
        # original I = ive * exp(|z|) * sign(ive) but for real nu,z ive should be positive for typical inputs
        log_iv = log_ive + abs_z
        # If ive was negative (rare), keep sign information by producing NaN when check True
        if check:
            if _np.any(ive_vals <= 0) or _np.any(~_np.isfinite(log_iv)):
                # For exact zeros or invalid values raise
                raise ValueError("log(I_nu(z)) not finite or ive non-positive for some inputs.")
        result = torch.as_tensor(log_iv)
        if was_tensor:
            result = result.to(device=device, dtype=dtype)
        return result
