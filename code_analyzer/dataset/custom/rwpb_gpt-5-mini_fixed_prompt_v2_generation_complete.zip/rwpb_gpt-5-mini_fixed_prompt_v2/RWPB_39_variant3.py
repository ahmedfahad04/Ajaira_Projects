
def clean_html(:
    import re
    from typing import List
    def clean_html(
            html_to_clean: str,
            tags_to_remove: List[str] = ["style", "svg", "script"],
            attributes_to_keep: List[str] = ["id", "href"],
    ) -> str:
        s = html_to_clean or ""
        remove = {t.lower() for t in (tags_to_remove or [])}
        keep = {a.lower() for a in (attributes_to_keep or [])}
        token_re = re.compile(r'(<[^>]+>|[^<]+)', re.S)
        tagname_re = re.compile(r'^<\s*(/)?\s*([^\s/>]+)', re.I)
        attr_re = re.compile(r'([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^>\s]+)))?', re.S)
        out = []
        ignore_stack = []
        for token in token_re.findall(s):
            if not token:
                continue
            if token[0] != '<':
                if not ignore_stack:
                    out.append(token)
                continue
            if token.startswith('<!--') or token.startswith('<!'):
                if not ignore_stack:
                    out.append(token)
                continue
            m = tagname_re.match(token)
            if not m:
                if not ignore_stack:
                    out.append(token)
                continue
            closing = bool(m.group(1))
            name = m.group(2).lower()
            self_closing = token.rstrip().endswith('/>')
            if not closing and name in remove:
                if not self_closing:
                    ignore_stack.append(name)
                continue
            if closing and ignore_stack:
                if ignore_stack and ignore_stack[-1] == name:
                    ignore_stack.pop()
                continue
            if ignore_stack:
                continue
            if closing:
                out.append(f"</{m.group(2)}>")
                continue
            attrs_part = token[m.end(): -1].strip()
            if attrs_part.endswith('/'):
                attrs_part = attrs_part[:-1].rstrip()
                self_closing = True
            kept = []
            for am in attr_re.finditer(attrs_part):
                an = am.group(1)
                av = am.group(2) if am.group(2) is not None else (am.group(3) if am.group(3) is not None else am.group(4))
                if an.lower() in keep:
                    if av is None:
                        kept.append(an)
                    else:
                        v = av.replace('"', '&quot;')
                        kept.append(f'{an}="{v}"')
            if kept:
                inner = " " + " ".join(kept)
            else:
                inner = ""
            if self_closing:
                out.append(f"<{m.group(2)}{inner} />")
            else:
                out.append(f"<{m.group(2)}{inner}>")
        return "".join(out)
