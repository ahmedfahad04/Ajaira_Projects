
def rotate_about_x_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        """
        Rotate using quaternion rotation (q * v * q_conj) for rotation about x-axis.
        """
        v = np.asarray(vector, dtype=float)
        if v.size != 3:
            raise ValueError("vector must have exactly 3 elements")
        v = v.reshape(3,)
        half = theta / 2.0
        w = math.cos(half)
        x = math.sin(half)
        # quaternion q = (w, x, 0, 0)
        q = (w, x, 0.0, 0.0)
        qc = (w, -x, 0.0, 0.0)  # conjugate
        def qmul(a, b):
            aw, ax, ay, az = a
            bw, bx, by, bz = b
            return (
                aw*bw - ax*bx - ay*by - az*bz,
                aw*bx + ax*bw + ay*bz - az*by,
                aw*by - ax*bz + ay*bw + az*bx,
                aw*bz + ax*by - ay*bx + az*bw
            )
        # represent vector as quaternion (0, vx, vy, vz)
        vq = (0.0, float(v[0]), float(v[1]), float(v[2]))
        tmp = qmul(q, vq)
        rotated = qmul(tmp, qc)
        return np.array([rotated[1], rotated[2], rotated[3]], dtype=float)
