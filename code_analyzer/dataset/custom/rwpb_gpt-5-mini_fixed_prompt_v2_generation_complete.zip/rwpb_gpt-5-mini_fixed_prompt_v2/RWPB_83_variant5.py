
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        if sample is None or not isinstance(sample, dict):
            return (size[0], size[1])
        img = sample.get("image", None)
        disp = sample.get("disparity", None)
        mask = sample.get("mask", None)
        if img is not None:
            src_h, src_w = img.shape[:2]
        elif disp is not None:
            src_h, src_w = disp.shape[:2]
        elif mask is not None:
            src_h, src_w = mask.shape[:2]
        else:
            return (size[0], size[1])
        tgt_h, tgt_w = int(size[0]), int(size[1])
        if src_h >= tgt_h and src_w >= tgt_w:
            return (src_h, src_w)
        ratio_h = tgt_h / src_h
        ratio_w = tgt_w / src_w
        scale = max(ratio_h, ratio_w)
        # ensure integer dims not smaller than target
        new_h = int(math.floor(src_h * scale + 0.9999))
        new_w = int(math.floor(src_w * scale + 0.9999))
        new_h = max(new_h, tgt_h)
        new_w = max(new_w, tgt_w)
        if img is not None:
            sample["image"] = cv2.resize(img, (new_w, new_h), interpolation=image_interpolation_method)
        if disp is not None:
            dtype = disp.dtype
            disp_f = disp.astype(np.float32)
            disp_rs = cv2.resize(disp_f, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            disp_rs = disp_rs * scale
            if np.issubdtype(dtype, np.integer):
                sample["disparity"] = np.round(disp_rs).astype(dtype)
            else:
                sample["disparity"] = disp_rs.astype(dtype)
        if mask is not None:
            mask_rs = cv2.resize(mask, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            if mask_rs.dtype != mask.dtype:
                if mask.dtype == np.uint8:
                    mask_rs = (mask_rs > 0).astype(np.uint8) * 255
                else:
                    mask_rs = (mask_rs > 0)
            sample["mask"] = mask_rs.astype(mask.dtype)
        return (new_h, new_w)
