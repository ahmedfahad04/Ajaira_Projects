
def is_byte_token(s: str) -> bool:
    def is_byte_token(s: str) -> bool:
        if not isinstance(s, str):
            return False
        if len(s) < 1 or s[0] != '<' or s[-1] != '>':
            return False
        inner = s[1:-1]
        if len(inner) != 4:
            return False
        if not (inner[:2].lower() == '0x'):
            return False
        byte_part = inner[2:]
        if len(byte_part) != 2:
            return False
        try:
            val = int(byte_part, 16)
        except ValueError:
            return False
        return 0 <= val <= 0xFF
