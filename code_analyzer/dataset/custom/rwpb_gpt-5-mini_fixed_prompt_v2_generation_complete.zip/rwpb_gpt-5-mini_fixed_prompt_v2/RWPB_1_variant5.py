
def apply_colormap(:
    import torch
    import numpy as np
    from matplotlib import cm
    def apply_colormap(image, cmap="viridis"):
        """
        LUT-based mapping: build a 1024-sample LUT and use integer indexing with torch.gather for speed.
        Accepts both common channel layouts and preserves device.
        """
        if not isinstance(image, torch.Tensor):
            raise TypeError("image must be a torch.Tensor")
        x = image
        if x.ndim >= 2 and x.shape[1] == 1 and x.ndim >= 3:
            dims = list(range(x.ndim))
            dims.pop(1)
            dims.append(1)
            x = x.permute(*dims)
        if x.shape[-1] != 1:
            raise ValueError("Expected channel dimension of size 1 at the last axis")
        device = x.device
        dtype = torch.float32
        vals = x.squeeze(-1).to(dtype=dtype)
        # normalize global to [0,1]
        mn = torch.min(vals)
        mx = torch.max(vals)
        if torch.isfinite(mn) and torch.isfinite(mx) and mx > mn:
            norm = (vals - mn) / (mx - mn)
        else:
            norm = torch.zeros_like(vals)
        # build LUT
        steps = 1024
        lut_np = cm.get_cmap(cmap)(np.linspace(0.0, 1.0, steps))[:, :3].astype(np.float32)
        lut = torch.from_numpy(lut_np).to(device=device, dtype=dtype)  # (steps,3)
        # indices
        idx = (norm.clamp(0.0, 1.0) * (steps - 1)).round().to(torch.long)
        flat_idx = idx.reshape(-1)
        colors = lut[flat_idx].reshape(*idx.shape, 3)
        return colors.to(device=device, dtype=dtype)
