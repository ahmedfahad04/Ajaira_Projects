
def apply_colormap(:
    import torch
    import numpy as np
    from matplotlib import cm
    def apply_colormap(image, cmap="viridis"):
        """
        Batch-iterative approach: if first dim looks like batch (N,1,H,W) we map each item independently,
        otherwise falls back to full-tensor mapping. Uses matplotlib colormap per item.
        """
        if not isinstance(image, torch.Tensor):
            raise TypeError("image must be a torch.Tensor")
        # Detect channel-first (N,1,H,W) pattern
        if image.ndim >= 3 and image.shape[1] == 1:
            # treat as batch in dim 0
            out_list = []
            device = image.device
            dtype = torch.float32
            for i in range(image.shape[0]):
                img = image[i:i+1]  # (1,1,H,W)
                # move to last channel
                dims = list(range(img.ndim))
                dims.pop(1)
                dims.append(1)
                img_l = img.permute(*dims)
                arr = img_l.squeeze(-1).detach().cpu().numpy()
                vmin = arr.min()
                vmax = arr.max()
                if vmax > vmin:
                    norm = (arr - vmin) / (vmax - vmin)
                else:
                    norm = np.zeros_like(arr, dtype=float)
                rgba = cm.get_cmap(cmap)(norm)[..., :3].astype(np.float32)
                t = torch.from_numpy(rgba).to(device=device, dtype=dtype)
                # move back to channel-first (1,3,H,W)
                t = t.permute(-1, *range(t.ndim - 1)).unsqueeze(0)  # (1,3,H,W)
                out_list.append(t)
            return torch.cat(out_list, dim=0)
        else:
            # channel-last or single image (...,1)
            x = image
            if x.shape[-1] != 1:
                raise ValueError("Expected channel dimension of size 1 at the last axis")
            device = x.device
            dtype = torch.float32
            arr = x.squeeze(-1).detach().cpu().numpy()
            vmin = arr.min()
            vmax = arr.max()
            if vmax > vmin:
                norm = (arr - vmin) / (vmax - vmin)
            else:
                norm = np.zeros_like(arr, dtype=float)
            rgba = cm.get_cmap(cmap)(norm)[..., :3].astype(np.float32)
            return torch.from_numpy(rgba).to(device=device, dtype=dtype)
