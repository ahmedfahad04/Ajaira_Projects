
def movmean(arr, n_avg):
    import numpy as np
    def movmean(arr, n_avg):
        a = np.asarray(arr).ravel().astype(float)
        if n_avg <= 0 or a.size == 0 or n_avg > a.size:
            return np.array([])
        # cumulative sum method
        c = np.cumsum(a)
        c = np.concatenate(([0.0], c))
        sums = c[n_avg:] - c[:-n_avg]
        return sums / float(n_avg)
