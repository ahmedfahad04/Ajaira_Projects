
def get_focalLength_from_fieldOfView(fov=60, img_size=512):
    import math
    def get_focalLength_from_fieldOfView(fov=60, img_size=512):
        if fov <= 0 or fov >= 180:
            raise ValueError("fov must be in (0,180) degrees")
        # Solve for f via monotonic relation fov(f) = 2*atan((img_size/2)/f)
        target = float(fov)
        half_img = img_size / 2.0
        # binary search bounds for focal length
        lo = 1e-9
        hi = 1e12
        for _ in range(80):
            mid = (lo + hi) / 2.0
            fov_mid = math.degrees(2.0 * math.atan(half_img / mid))
            if fov_mid > target:
                # focal too small -> increase focal to reduce fov
                lo = mid
            else:
                hi = mid
        return float((lo + hi) / 2.0)
