
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        if not isinstance(masks, torch.Tensor):
            masks = torch.tensor(masks)
        if masks.ndim != 4:
            raise ValueError("masks must be (N, C, H, W)")
        N, C, Hm, Wm = masks.shape
        h, w = shape
        device = masks.device
        dtype = masks.dtype
        x = masks.view(N * C, 1, Hm, Wm).float().to(device)
        if padding:
            s = max(h, w)
            x_resized = F.interpolate(x, size=(s, s), mode='bilinear', align_corners=False)
            x_resized = x_resized.view(N, C, s, s)
            top = max(0, (s - h) // 2)
            left = max(0, (s - w) // 2)
            out = x_resized[:, :, top:top + h, left:left + w]
        else:
            out = F.interpolate(x, size=(h, w), mode='bilinear', align_corners=False)
            out = out.view(N, C, h, w)
        out = out.to(dtype)
        return out
