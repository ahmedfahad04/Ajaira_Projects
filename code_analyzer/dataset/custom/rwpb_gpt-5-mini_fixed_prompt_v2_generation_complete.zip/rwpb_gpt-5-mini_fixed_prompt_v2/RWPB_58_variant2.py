
def unpad_image_shape(current_height, current_width, original_size):
    import math
    def unpad_image_shape(current_height, current_width, original_size):
        ow, oh = original_size
        # sanity checks
        if any(x <= 0 for x in (ow, oh, current_width, current_height)):
            return (current_height, current_width)
        orig_ar = ow / oh
        cur_ar = current_width / current_height
        # Use floor to ensure we never exceed padded dims
        if orig_ar > cur_ar:
            # width determines scale
            scale = current_width / ow
            new_h = math.floor(oh * scale)
            new_h = max(1, min(current_height, new_h))
            return (new_h, current_width)
        elif orig_ar < cur_ar:
            scale = current_height / oh
            new_w = math.floor(ow * scale)
            new_w = max(1, min(current_width, new_w))
            return (current_height, new_w)
        else:
            return (current_height, current_width)
