
def mask_iou(mask1, mask2, eps=1e-7):
    import torch
    def mask_iou(mask1, mask2, eps=1e-7):
        # soft IoU using min/max per pixel (handles probabilistic masks)
        mask1 = mask1.float()
        mask2 = mask2.float()
        if mask1.numel() == 0 or mask2.numel() == 0:
            return torch.zeros((mask1.shape[0], mask2.shape[0]), dtype=mask1.dtype, device=mask1.device)
        m1 = mask1.unsqueeze(1)  # (N,1,n)
        m2 = mask2.unsqueeze(0)  # (1,M,n)
        inter = torch.min(m1, m2).sum(dim=2)  # (N,M)
        union = torch.max(m1, m2).sum(dim=2)  # (N,M)
        return inter / (union.clamp(min=eps))
