
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    import numpy as np
    def generate_grids(lower_limit, upper_limit, grid_size):
        low = lower_limit.clone().cpu().numpy()
        high = upper_limit.clone().cpu().numpy()
        if np.isscalar(low):
            low = np.array([low])
        if np.isscalar(high):
            high = np.array([high])
        if torch.is_tensor(grid_size):
            gs_arr = grid_size.clone().cpu().numpy()
        else:
            gs_arr = np.array(grid_size)
        if gs_arr.ndim == 0:
            gs_arr = np.full(low.shape, int(gs_arr), dtype=int)
        else:
            gs_arr = gs_arr.astype(int)
        steps = (high - low) / gs_arr
        lists = []
        for i in range(len(low)):
            if gs_arr[i] > 0:
                lists.append(low[i] + np.arange(gs_arr[i]) * steps[i])
            else:
                lists.append(np.array([]))
        if len(lists) == 0:
            return torch.empty((0,0)), torch.empty((0,0))
        mesh = np.meshgrid(*lists, indexing='ij')
        coords = np.stack([m.reshape(-1) for m in mesh], axis=1)
        lowers = torch.from_numpy(coords.astype(np.float32))
        uppers = lowers + torch.from_numpy(steps.astype(np.float32)).unsqueeze(0)
        return lowers, uppers
