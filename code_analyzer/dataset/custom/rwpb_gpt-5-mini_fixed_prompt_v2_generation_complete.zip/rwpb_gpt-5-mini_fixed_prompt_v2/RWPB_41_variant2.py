
def merge_short_sentences_en(sens):
    import re
    def merge_short_sentences_en(sens):
        """Use regex word counting. Merge sentences with <=2 words into the following one.
        If the final sentence is short, merge it with the previous."""
        if not sens:
            return []
        s = [x.strip() for x in sens]
        res = []
        i = 0
        n = len(s)
        word_re = re.compile(r"\w+")
        while i < n:
            cur = s[i]
            wc = len(word_re.findall(cur))
            if wc <= 2 and i + 1 < n:
                # merge current into next
                s[i + 1] = (cur + ' ' + s[i + 1]).strip()
                i += 1
            else:
                res.append(cur)
                i += 1
        # merge last short into previous if needed
        if len(res) >= 2 and len(word_re.findall(res[-1])) <= 2:
            res[-2] = (res[-2] + ' ' + res[-1]).strip()
            res.pop()
        return res
