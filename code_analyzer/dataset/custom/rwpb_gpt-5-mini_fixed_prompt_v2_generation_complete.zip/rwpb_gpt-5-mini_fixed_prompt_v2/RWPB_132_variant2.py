
def B_batch(x, grid, k=0, extend=True, device="cpu"):
    import torch
    def B_batch(x, grid, k=0, extend=True, device="cpu"):
        x = x.to(device)
        grid = grid.to(device)
        num_spline, num_sample = x.shape
        _, m = grid.shape
        p = int(k)
        # Prepare extended knot arrays for all splines at once (grids have same length)
        if m < 2:
            # trivial
            n_bases = max(0, m + p - 1)
            return torch.zeros((num_spline, n_bases, num_sample), device=device, dtype=x.dtype)
        if extend:
            left_d = (grid[:, 1] - grid[:, 0]).unsqueeze(1)  # (S,1)
            right_d = (grid[:, -1] - grid[:, -2]).unsqueeze(1)
            pre_offsets = torch.arange(p, 0, -1, device=device, dtype=grid.dtype).unsqueeze(0)  # (1,p)
            post_offsets = torch.arange(1, p+1, device=device, dtype=grid.dtype).unsqueeze(0)
            pre = grid[:, :1] - pre_offsets * left_d  # (S,p)
            post = grid[:, -1:].repeat(1, p) + post_offsets * right_d  # (S,p)
        else:
            pre = grid[:, :1].repeat(1, p)
            post = grid[:, -1:].repeat(1, p)
        T = torch.cat([pre, grid, post], dim=1)  # (S, m+2p)
        n_T = T.shape[1]
        n_bases = m + p - 1
        # x expand
        xs = x.unsqueeze(1)  # (S,1,N)
        # Build base B (degree 0)
        lefts = T[:, :-1].unsqueeze(2)  # (S, n_T-1, 1)
        rights = T[:, 1:].unsqueeze(2)
        B = ((xs >= lefts) & (xs < rights)).to(dtype=x.dtype)  # (S, n_T-1, N)
        # include last endpoint equality
        last_knot = T[:, -1].unsqueeze(1).unsqueeze(2)  # (S,1,1)
        eq_mask = (xs == last_knot).squeeze(1)  # (S,N)
        if eq_mask.any():
            B[:, -1, :][eq_mask] = 1.0
        # recursion vectorized over splines and samples
        for r in range(1, p+1):
            # compute new B of reduced length
            new_len = n_T - 1 - r
            B_new = torch.zeros((num_spline, new_len, num_sample), device=device, dtype=x.dtype)
            # denominators shapes (S, new_len)
            denom1 = (T[:, r:n_T-1] - T[:, :n_T-1-r]).to(dtype=x.dtype)  # (S,new_len)
            denom2 = (T[:, r+1:n_T] - T[:, 1:n_T-r]).to(dtype=x.dtype)
            # expand for broadcasting
            denom1_exp = denom1.unsqueeze(2)  # (S,new_len,1)
            denom2_exp = denom2.unsqueeze(2)
            left_term = torch.zeros_like(B_new)
            right_term = torch.zeros_like(B_new)
            # compute left if denom1 != 0
            mask1 = denom1_exp != 0
            if mask1.any():
                coeff1 = (xs - T[:, :n_T-1-r].unsqueeze(2)) / denom1_exp
                left_term = coeff1 * B[:, :new_len, :]
                left_term = left_term * mask1.to(dtype=left_term.dtype)
            mask2 = denom2_exp != 0
            if mask2.any():
                coeff2 = (T[:, r+1:n_T].unsqueeze(2) - xs) / denom2_exp
                right_term = coeff2 * B[:, 1:new_len+1, :]
                right_term = right_term * mask2.to(dtype=right_term.dtype)
            B = left_term + right_term
        result = B[:, :n_bases, :]
        return result
