
def unsafeSub(x, y):
    MAX_VAL = (1 << 256) - 1
    WORD = 1 << 256
    def unsafeSub(x, y):
        # simple bitmask of the raw subtraction result to simulate 256-bit wraparound
        return (x - y) & MAX_VAL
