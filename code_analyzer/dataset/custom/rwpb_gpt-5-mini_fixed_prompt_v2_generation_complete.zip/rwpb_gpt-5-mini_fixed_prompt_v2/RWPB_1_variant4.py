
def apply_colormap(:
    import torch
    import numpy as np
    from matplotlib import cm
    def apply_colormap(image, cmap="viridis"):
        """
        Percentile-clipped normalization (2nd-98th percentile) for contrast robustness, then numpy mapping.
        Handles both channel-first (C==1 at dim1) and channel-last (...,1).
        """
        if not isinstance(image, torch.Tensor):
            raise TypeError("image must be a torch.Tensor")
        x = image
        if x.ndim >= 2 and x.shape[1] == 1 and x.ndim >= 3:
            dims = list(range(x.ndim))
            dims.pop(1)
            dims.append(1)
            x = x.permute(*dims)
        if x.shape[-1] != 1:
            raise ValueError("Expected channel dimension of size 1 at the last axis")
        device = x.device
        dtype = torch.float32
        arr = x.squeeze(-1).detach().cpu().numpy()
        flat = arr.ravel()
        if flat.size == 0:
            normed = np.zeros_like(arr, dtype=float)
        else:
            lo = np.percentile(flat, 2)
            hi = np.percentile(flat, 98)
            if hi > lo:
                normed = (arr - lo) / (hi - lo)
                normed = np.clip(normed, 0.0, 1.0)
            else:
                # fallback to min-max
                mn = flat.min() if flat.size else 0.0
                mx = flat.max() if flat.size else 1.0
                if mx > mn:
                    normed = (arr - mn) / (mx - mn)
                else:
                    normed = np.zeros_like(arr, dtype=float)
        cmap_fn = cm.get_cmap(cmap)
        rgba = cmap_fn(normed)[..., :3].astype(np.float32)
        return torch.from_numpy(rgba).to(device=device, dtype=dtype)
