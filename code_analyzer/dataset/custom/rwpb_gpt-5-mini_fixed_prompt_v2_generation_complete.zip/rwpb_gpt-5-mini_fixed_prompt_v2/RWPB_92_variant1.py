
def round(number, num_decimal_places, leave_int=False):
    from decimal import Decimal, ROUND_HALF_UP
    def round(number, num_decimal_places, leave_int=False):
        """
        Decimal-based rounding using ROUND_HALF_UP.
        """
        # Validate inputs
        if num_decimal_places is None:
            raise TypeError("num_decimal_places must be an int")
        n = int(num_decimal_places)
        # Handle NaN/Inf transparently
        try:
            import math
            if isinstance(number, float) and (math.isnan(number) or math.isinf(number)):
                return float(number)
        except Exception:
            pass
        # Use Decimal for accurate rounding
        # Use repr to capture full precision of float where possible
        d = Decimal(str(number)) if not isinstance(number, Decimal) else number
        # quantize exponent
        exp = Decimal('1E{}'.format(-n))  # works for negative n as well (creates 1E3 etc.)
        rounded = d.quantize(exp, rounding=ROUND_HALF_UP)
        # Convert to int if requested and value is integer
        try:
            float_val = float(rounded)
        except Exception:
            float_val = rounded
        if leave_int:
            # If numeric value is integral, return int
            try:
                if float_val == int(float_val):
                    return int(float_val)
            except Exception:
                pass
        return float_val
