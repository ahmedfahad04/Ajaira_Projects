
def invalid_to_zeros(arr, valid_mask, ndim=999):
    import torch
    def invalid_to_zeros(arr, valid_mask, ndim=999):
        if not isinstance(arr, torch.Tensor):
            raise TypeError("arr must be a torch.Tensor")
        if ndim != 999 and arr.dim() > ndim:
            prefix = tuple(arr.shape[:ndim-1])
            suffix = 1
            for s in arr.shape[ndim-1:]:
                suffix *= s
            arr = arr.view(*prefix, suffix)
        if valid_mask is None:
            if arr.dim() >= 1:
                nnz = torch.tensor(arr.numel() // arr.shape[0], dtype=torch.long)
            else:
                nnz = torch.tensor(arr.numel(), dtype=torch.long)
            return arr, nnz
        mask = valid_mask
        if not isinstance(mask, torch.Tensor):
            mask = torch.tensor(mask, dtype=torch.bool, device=arr.device)
        mask = mask.bool().to(arr.device)
        if arr.dim() == mask.dim() and mask.shape == arr.shape:
            arr = arr.clone()
            arr[~mask] = 0
            if arr.dim() >= 1:
                nnz = mask.view(arr.shape[0], -1).sum(dim=1)
            else:
                nnz = torch.tensor(int(mask.sum().item()))
            return arr, nnz
        if arr.dim() >= 2:
            B = arr.shape[0]
            flat = arr.view(B, -1).clone()
            if mask.numel() == flat.numel():
                m = mask.view(B, -1)
                flat[~m] = 0
                arr = flat.view(*arr.shape)
                nnz = m.sum(dim=1)
                return arr, nnz
            if mask.dim() == flat.dim() - 1 and mask.shape == (B,):
                m = mask.view(B, 1).expand_as(flat)
                flat[~m] = 0
                arr = flat.view(*arr.shape)
                nnz = m.sum(dim=1)
                return arr, nnz
        # element-wise fallback using advanced indexing
        try:
            mask_flat = mask.view(-1)
            arr_flat = arr.view(-1)
            if mask_flat.numel() == arr_flat.numel():
                arr_flat[~mask_flat] = 0
                arr = arr_flat.view(*arr.shape)
                nnz = torch.tensor(int(mask_flat.sum().item()))
                return arr, nnz
        except Exception:
            pass
        # last resort: use torch.where with broadcasting
        try:
            m = mask.view(*mask.shape, *([1] * (arr.dim() - mask.dim())))
            arr = torch.where(m.expand_as(arr), arr, torch.zeros_like(arr))
            if m.shape[0] == arr.shape[0]:
                nnz = m.view(arr.shape[0], -1).sum(dim=1)
            else:
                nnz = torch.tensor(int(m.expand_as(arr).sum().item()))
            return arr, nnz
        except Exception:
            raise ValueError("Could not apply valid_mask to arr")
