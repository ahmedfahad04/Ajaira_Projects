
def cvimg2torch(img):
    def cvimg2torch(img):
        import numpy as np
        import torch
        arr = np.asarray(img)
        if arr.ndim == 2:
            arr = arr[..., None]
        if arr.ndim == 3:
            if arr.shape[2] == 3:
                arr = arr[..., ::-1]
            arr = np.ascontiguousarray(arr.transpose(2, 0, 1))
            return torch.from_numpy(arr).float().div(255.0).unsqueeze(0)
        if arr.ndim == 4:
            if arr.shape[-1] == 3:
                arr = arr[..., ::-1]
            arr = np.ascontiguousarray(arr.transpose(0, 3, 1, 2))
            return torch.from_numpy(arr).float().div(255.0)
        raise ValueError("Unsupported input shape")
