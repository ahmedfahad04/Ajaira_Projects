
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        if divisor is None:
            raise ValueError("divisor must be provided")
        if torch.is_tensor(divisor):
            d_val = divisor.max().item()
        else:
            d_val = divisor
        if d_val == 0:
            raise ValueError("divisor must be non-zero")
        d = abs(int(d_val))
        # Compute remainder in [0, d)
        q_floor = math.floor(float(x) / d)
        rem = float(x) - d * q_floor
        lower = float(x) - rem
        upper = lower + d
        # If rem is strictly less than half, choose lower; else choose upper
        if rem < (d / 2.0):
            return int(lower)
        else:
            return int(upper)
