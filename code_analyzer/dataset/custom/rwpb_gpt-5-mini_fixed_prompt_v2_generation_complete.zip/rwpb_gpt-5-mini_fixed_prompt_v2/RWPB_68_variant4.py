
def last_before(val, arr):
    from bisect import bisect_right
    def last_before(val, arr):
        try:
            seq = arr.tolist()
        except AttributeError:
            seq = list(arr)
        pos = bisect_right(seq, val)
        idx = pos - 1
        return int(idx) if idx >= 0 else -1
