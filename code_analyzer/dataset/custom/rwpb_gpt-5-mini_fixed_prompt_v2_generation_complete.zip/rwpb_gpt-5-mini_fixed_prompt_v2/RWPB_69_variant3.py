
def fovx_to_fovy(fovx, aspect):
    import math
    def fovx_to_fovy(fovx, aspect):
        if aspect <= 0:
            raise ValueError("aspect must be positive")
        # Use atan2 for numerical stability: atan(x) == atan2(x,1)
        half_tx = math.tan(0.5 * float(fovx))
        half_ty = half_tx / float(aspect)
        return 2.0 * math.atan2(half_ty, 1.0)
