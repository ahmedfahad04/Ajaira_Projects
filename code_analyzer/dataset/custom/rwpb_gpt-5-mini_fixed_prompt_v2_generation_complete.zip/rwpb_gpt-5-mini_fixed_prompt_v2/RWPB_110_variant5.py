
def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
    import numpy as np
    def find_intersection(plane_normal,plane_point,ray_direction,ray_point):
        n = np.asarray(plane_normal, dtype=float)
        a = np.asarray(plane_point, dtype=float)
        v = np.asarray(ray_direction, dtype=float)
        p = np.asarray(ray_point, dtype=float)
        eps = 1e-10
        cross = np.cross(v, n)
        if np.linalg.norm(cross) < eps:
            if abs(np.dot(n, p - a)) < eps:
                return p.copy()
            return None
        denom = np.dot(n, v)
        if abs(denom) < eps:
            return None
        t = np.dot(n, a - p) / denom
        return p + t * v
