
def merge_short_sentences_en(sens):
    def merge_short_sentences_en(sens):
        """Greedy character-length based merging: keep merging short sentences
        (len < 40 chars) with the following sentence until the combined piece
        is not 'short' or there is no next. If last remains short, attach to previous."""
        if not sens:
            return []
        s = [x.strip() for x in sens]
        out = []
        i = 0
        n = len(s)
        while i < n:
            cur = s[i]
            # threshold in characters
            if len(cur) < 40 and i + 1 < n:
                # merge repeatedly with next until threshold satisfied or no more
                j = i + 1
                combined = cur
                while j < n and len(combined) < 40:
                    combined = (combined + ' ' + s[j]).strip()
                    j += 1
                out.append(combined)
                i = j
            else:
                out.append(cur)
                i += 1
        # final fix: if last is short and there's a previous, merge back
        if len(out) >= 2 and len(out[-1]) < 40:
            out[-2] = (out[-2] + ' ' + out[-1]).strip()
            out.pop()
        return out
