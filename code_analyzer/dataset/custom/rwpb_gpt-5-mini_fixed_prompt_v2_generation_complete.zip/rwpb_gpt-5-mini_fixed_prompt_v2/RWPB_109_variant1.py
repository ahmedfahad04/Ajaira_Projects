
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        """
        Applies rotation and translation to geometry.
        geometry: [B, N, 3]
        rot: [B, 3, 3]
        trans: [B, 3]
        """
        if geometry.dim() != 3 or rot.dim() != 3 or trans.dim() != 2:
            raise ValueError("Unexpected tensor shapes")
        # rotate using batched matrix multiply, geometry are row-vectors so multiply by rot^T
        rotated = torch.bmm(geometry, rot.transpose(1, 2))
        return rotated + trans.unsqueeze(1)
