
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return None
        ow, oh = original_size
        # First try: pick largest area that fits within original (no upscaling)
        fitting = [r for r in possible_resolutions if r[0] <= ow and r[1] <= oh]
        if fitting:
            return max(fitting, key=lambda r: r[0] * r[1])
        # If none fit, choose the one that requires the smallest upscale factor.
        # Upscale factor defined as max(width_ratio, height_ratio)
        def upscale_factor(r):
            rw, rh = r
            # avoid division by zero
            fx = rw / ow if ow != 0 else float('inf')
            fy = rh / oh if oh != 0 else float('inf')
            return max(fx, fy)
        best = min(possible_resolutions, key=lambda r: (upscale_factor(r), abs(r[0]*r[1] - ow*oh)))
        return best
