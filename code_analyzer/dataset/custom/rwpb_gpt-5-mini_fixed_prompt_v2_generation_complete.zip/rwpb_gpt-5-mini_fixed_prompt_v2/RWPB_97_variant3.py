
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        arr = np.asarray(image)
        if arr.ndim == 2:
            out = arr[None, ...]
        elif arr.ndim == 3:
            out = np.moveaxis(arr, -1, 0)
        else:
            raise ValueError("Not a valid image array.")
        out = out.astype(np.float32) / 255.0
        return torch.as_tensor(out, dtype=torch.float32)
