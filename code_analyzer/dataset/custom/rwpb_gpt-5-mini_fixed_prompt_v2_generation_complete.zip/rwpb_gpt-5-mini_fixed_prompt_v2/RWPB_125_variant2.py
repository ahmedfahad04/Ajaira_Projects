
def resample_segments(segments, n=1000):
    import numpy as np
    def resample_segments(segments, n=1000):
        out = []
        for seg in segments:
            seg = np.asarray(seg, dtype=float)
            if seg.size == 0:
                out.append(np.empty((0, 2)))
                continue
            if seg.ndim == 1:
                seg = seg.reshape(-1, 2)
            m = seg.shape[0]
            if m == 1 or np.allclose(seg - seg[0], 0):
                out.append(np.repeat(seg[:1, :], n, axis=0))
                continue
            diffs = seg[1:] - seg[:-1]
            edge_len = np.sqrt((diffs ** 2).sum(axis=1))
            cum = np.concatenate(([0.0], np.cumsum(edge_len)))
            total = cum[-1]
            if total == 0.0:
                out.append(np.repeat(seg[:1, :], n, axis=0))
                continue
            newd = np.linspace(0.0, total, n)
            idx = np.searchsorted(cum, newd, side='right')
            left = np.clip(idx - 1, 0, m - 2)
            right = left + 1
            left_d = cum[left]
            seg_left = seg[left]
            seg_right = seg[right]
            denom = (cum[right] - left_d)
            denom[denom == 0] = 1.0
            alpha = (newd - left_d) / denom
            alpha = alpha.reshape(-1, 1)
            points = seg_left * (1 - alpha) + seg_right * alpha
            out.append(points)
        return out
