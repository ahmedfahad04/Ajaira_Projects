
def xywh2xyxy(x):
    import numpy as np
    import torch
    def xywh2xyxy(x):
        if isinstance(x, torch.Tensor):
            if x.numel() == 0:
                return x.clone()
            y = x.clone()
            out = torch.empty_like(y)
            out[..., 0] = y[..., 0]
            out[..., 1] = y[..., 1]
            out[..., 2] = y[..., 0] + y[..., 2]
            out[..., 3] = y[..., 1] + y[..., 3]
            return out
        x_np = np.asarray(x)
        if x_np.size == 0:
            return x_np.copy()
        y = x_np.copy()
        out = np.empty_like(y)
        out[..., 0] = y[..., 0]
        out[..., 1] = y[..., 1]
        out[..., 2] = y[..., 0] + y[..., 2]
        out[..., 3] = y[..., 1] + y[..., 3]
        return out
