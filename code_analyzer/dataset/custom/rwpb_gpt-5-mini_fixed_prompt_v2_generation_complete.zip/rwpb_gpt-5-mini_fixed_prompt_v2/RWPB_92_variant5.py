
def round(number, num_decimal_places, leave_int=False):
    from fractions import Fraction
    import math
    def round(number, num_decimal_places, leave_int=False):
        """
        Fraction-based exact rounding to avoid floating artifacts.
        Rounds halves away from zero.
        """
        n = int(num_decimal_places)
        # special floats
        if isinstance(number, float) and (math.isnan(number) or math.isinf(number)):
            return float(number)
        # Work with Fraction for exact arithmetic
        frac = Fraction(number).limit_denominator()
        if n >= 0:
            factor = 10 ** n
            scaled = frac * factor
            # scaled = q + r/d
            q = scaled.numerator // scaled.denominator
            rem = scaled.numerator % scaled.denominator
            # Determine rounding: compare 2*rem with denom
            if rem * 2 > scaled.denominator:
                q += 1
            elif rem * 2 == scaled.denominator:
                # exactly half: round away from zero
                if scaled >= 0:
                    q += 1
                else:
                    # q is floor for negative numbers; floor is <= value so rounding away -> more negative
                    q -= 1
            result = Fraction(q, 1) / factor
        else:
            factor = 10 ** (-n)
            scaled = frac / factor
            q = scaled.numerator // scaled.denominator
            rem = scaled.numerator % scaled.denominator
            if rem * 2 > scaled.denominator:
                q += 1
            elif rem * 2 == scaled.denominator:
                if scaled >= 0:
                    q += 1
                else:
                    q -= 1
            result = Fraction(q, 1) * factor
        val = float(result)
        if leave_int:
            if val == int(val):
                return int(val)
        return val
