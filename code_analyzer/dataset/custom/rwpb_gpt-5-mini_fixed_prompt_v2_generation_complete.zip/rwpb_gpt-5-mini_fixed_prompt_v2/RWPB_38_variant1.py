
def extract_imports_from_lines(lines: List[str]) -> str:
    from typing import List
    def extract_imports_from_lines(lines: List[str]) -> str:
        results = []
        for line in lines:
            if not isinstance(line, str):
                continue
            stripped = line.lstrip()
            if not stripped:
                continue
            # ignore comment-only lines
            if stripped.startswith("#"):
                continue
            # token-like check for starting keywords
            first = stripped.split(None, 1)[0] if stripped.split(None, 1) else ""
            if first in ("import", "from"):
                results.append(line.rstrip())
        return "\n".join(results)
