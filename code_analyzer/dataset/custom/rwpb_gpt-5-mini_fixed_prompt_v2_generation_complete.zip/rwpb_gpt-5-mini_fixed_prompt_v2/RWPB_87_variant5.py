
def rotate_x(a, device=None):
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        dev = torch.device(device) if device is not None else None
        # Support scalar or batch angles
        if isinstance(a, (list, tuple, np.ndarray)):
            a_t = torch.tensor(a, dtype=torch.get_default_dtype(), device=dev)
        elif isinstance(a, torch.Tensor):
            a_t = a.to(dev)
        else:
            a_t = torch.tensor([float(a)], dtype=torch.get_default_dtype(), device=dev)
        # if scalar turned into 1-element tensor, handle uniformly
        squeeze = False
        if a_t.dim() == 0:
            a_t = a_t.unsqueeze(0)
            squeeze = True
        c = torch.cos(a_t)
        s = torch.sin(a_t)
        n = a_t.shape[0]
        out = torch.zeros((n,4,4), dtype=c.dtype, device=dev)
        out[:,0,0] = 1.0
        out[:,3,3] = 1.0
        out[:,1,1] = c
        out[:,1,2] = -s
        out[:,2,1] = s
        out[:,2,2] = c
        if squeeze:
            return out[0]
        return out
