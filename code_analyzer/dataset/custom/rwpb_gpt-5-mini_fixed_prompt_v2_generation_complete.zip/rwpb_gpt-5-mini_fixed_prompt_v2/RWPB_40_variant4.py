
def extract_code_from_funct(funct: Callable) -> List[str]:
    import inspect
    import textwrap
    from typing import Callable, List
    def extract_code_from_funct(funct: Callable) -> List[str]:
        src = inspect.getsource(funct)
        src_lines = src.splitlines()
        n = len(src_lines)
        # find the 'def' or 'async def' line index (skip decorators)
        def_idx = None
        for i, line in enumerate(src_lines):
            s = line.lstrip()
            if s.startswith("def ") or s.startswith("async def "):
                def_idx = i
                break
        if def_idx is None:
            return []
        # find end of signature: the first line at or after def_idx whose stripped text ends with ':'
        sig_end = def_idx
        while sig_end < n and not src_lines[sig_end].strip().endswith(":"):
            sig_end += 1
        # body starts on the next line after sig_end
        body_start = sig_end + 1
        if body_start >= n:
            return []
        body_lines = src_lines[body_start:]
        # dedent the body
        ded = textwrap.dedent("\n".join(body_lines))
        out_lines = ded.splitlines()
        # trim empty lines
        while out_lines and out_lines[0].strip() == "":
            out_lines.pop(0)
        while out_lines and out_lines[-1].strip() == "":
            out_lines.pop()
        # remove final return if present
        if out_lines and out_lines[-1].lstrip().startswith("return"):
            out_lines.pop()
            while out_lines and out_lines[-1].strip() == "":
                out_lines.pop()
        return out_lines
