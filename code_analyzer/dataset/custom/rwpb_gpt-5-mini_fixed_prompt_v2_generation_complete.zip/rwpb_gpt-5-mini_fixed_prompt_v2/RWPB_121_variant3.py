
def isprime(n):
    import math
    def isprime(n):
        if not isinstance(n, int):
            return False
        if n <= 1:
            return False
        small_primes = (2, 3, 5, 7, 11, 13, 17, 19, 23)
        for p in small_primes:
            if n == p:
                return True
            if n % p == 0:
                return False
        # Miller-Rabin deterministic for 64-bit-ish integers
        d = n - 1
        s = 0
        while d % 2 == 0:
            d //= 2
            s += 1
        def try_composite(a):
            x = pow(a, d, n)
            if x == 1 or x == n - 1:
                return False
            for _ in range(s - 1):
                x = (x * x) % n
                if x == n - 1:
                    return False
            return True
        bases = [2, 3, 5, 7, 11, 13, 17, 19, 23]
        for a in bases:
            if a >= n:
                continue
            if try_composite(a):
                return False
        return True
