
def arccos2(vector, value):
    import math
    def arccos2(vector, value):
        x = float(vector[0])
        y = float(vector[1])
        v = float(value)
        if v != v:
            return float('nan')
        v = max(-1.0, min(1.0, v))
        cand1 = math.acos(v)
        cand2 = -cand1
        def norm(a):
            a = (a + math.pi) % (2.0 * math.pi) - math.pi
            return a
        ang_vec = math.atan2(y, x)
        d1 = abs(norm(ang_vec - cand1))
        d2 = abs(norm(ang_vec - cand2))
        chosen = cand1 if d1 <= d2 else cand2
        if chosen < 0.0:
            chosen += 2.0 * math.pi
        return chosen
