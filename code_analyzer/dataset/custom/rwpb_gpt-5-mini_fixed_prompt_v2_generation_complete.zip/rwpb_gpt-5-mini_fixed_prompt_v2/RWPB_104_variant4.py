
def mulMod(x, y, z):
    def mulMod(x, y, z):
        if z == 0:
            raise ZeroDivisionError("integer modulo by zero")
        if z < 0:
            z = -z
        x_mod = x % z
        yy = y % z
        base = 1 << 64
        mask = base - 1
        res = 0
        b_power = x_mod  # corresponds to x * base^i mod z
        i = 0
        while yy:
            chunk = yy & mask
            if chunk:
                res = (res + (b_power * chunk) ) % z
            b_power = (b_power * base) % z
            yy >>= 64
            i += 1
        return res % z
