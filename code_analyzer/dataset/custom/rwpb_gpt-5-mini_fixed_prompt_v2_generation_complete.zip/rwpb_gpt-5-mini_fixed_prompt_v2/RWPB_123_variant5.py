
def fuse_deconv_and_bn(deconv, bn):
    import torch
    import torch.nn as nn
    import numpy as np
    def fuse_deconv_and_bn(deconv, bn):
        if not isinstance(deconv, nn.ConvTranspose2d) or not isinstance(bn, nn.BatchNorm2d):
            raise TypeError("Expected ConvTranspose2d and BatchNorm2d")
        device = deconv.weight.device
        dtype = deconv.weight.dtype
        out_ch = int(deconv.out_channels)
        in_ch = int(deconv.in_channels)
        groups = int(deconv.groups)
        if bn.affine:
            gamma = bn.weight.detach().cpu().numpy()
            beta = bn.bias.detach().cpu().numpy()
        else:
            gamma = np.ones(out_ch, dtype=np.float32)
            beta = np.zeros(out_ch, dtype=np.float32)
        rm = bn.running_mean.detach().cpu().numpy()
        rv = bn.running_var.detach().cpu().numpy()
        eps = float(bn.eps)
        a = gamma / np.sqrt(rv + eps)
        b = beta - a * rm
        bias_old = deconv.bias.detach().cpu().numpy() if deconv.bias is not None else np.zeros(out_ch, dtype=np.float32)
        bias_new = a * bias_old + b
        w_old = deconv.weight.detach().cpu().numpy()  # (in_ch, out_ch//groups, kh, kw)
        kh, kw = w_old.shape[2], w_old.shape[3]
        out_per_group = out_ch // groups
        in_per_group = in_ch // groups
        w_new = np.empty_like(w_old)
        for g in range(groups):
            for local_o in range(out_per_group):
                global_o = g * out_per_group + local_o
                s = a[global_o]
                i_start = g * in_per_group
                i_end = (g + 1) * in_per_group
                w_new[i_start:i_end, local_o, :, :] = w_old[i_start:i_end, local_o, :, :] * s
        fused = nn.ConvTranspose2d(
            in_channels=deconv.in_channels,
            out_channels=deconv.out_channels,
            kernel_size=deconv.kernel_size,
            stride=deconv.stride,
            padding=deconv.padding,
            output_padding=deconv.output_padding,
            groups=deconv.groups,
            dilation=deconv.dilation,
            bias=True
        ).to(device=device, dtype=dtype)
        fused.weight.data.copy_(torch.from_numpy(w_new).to(device=device, dtype=dtype))
        fused.bias.data.copy_(torch.from_numpy(bias_new).to(device=device, dtype=dtype))
        return fused
