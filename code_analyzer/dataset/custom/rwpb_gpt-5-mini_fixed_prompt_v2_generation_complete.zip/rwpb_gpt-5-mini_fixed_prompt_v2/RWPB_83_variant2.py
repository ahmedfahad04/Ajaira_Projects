
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        if not isinstance(sample, dict):
            return (size[0], size[1])
        image = sample.get("image", None)
        disp = sample.get("disparity", None)
        mask = sample.get("mask", None)
        ref = image if image is not None else (disp if disp is not None else mask)
        if ref is None:
            return (size[0], size[1])
        h, w = ref.shape[:2]
        req_h, req_w = int(size[0]), int(size[1])
        if h >= req_h and w >= req_w:
            return (h, w)
        scale = max(req_h / h, req_w / w)
        new_h = int(math.ceil(h * scale))
        new_w = int(math.ceil(w * scale))
        if image is not None:
            sample["image"] = cv2.resize(image, (new_w, new_h), interpolation=image_interpolation_method)
        if disp is not None:
            disp_f = disp.astype(np.float32)
            disp_resized = cv2.resize(disp_f, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            disp_resized = disp_resized * scale
            sample["disparity"] = disp_resized.astype(disp.dtype) if np.issubdtype(disp.dtype, np.integer) else disp_resized
        if mask is not None:
            m_res = cv2.resize(mask, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            if m_res.dtype != mask.dtype:
                if np.issubdtype(mask.dtype, np.integer):
                    m_res = (m_res > 0).astype(mask.dtype) * (255 if mask.dtype == np.uint8 else 1)
                else:
                    m_res = (m_res > 0)
            sample["mask"] = m_res
        return (new_h, new_w)
