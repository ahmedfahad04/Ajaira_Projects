
def mask_iou(mask1, mask2, eps=1e-7):
    import torch
    def mask_iou(mask1, mask2, eps=1e-7):
        mask1 = mask1.float().unsqueeze(1)  # (N,1,n)
        mask2 = mask2.float().unsqueeze(0)  # (1,M,n)
        if mask1.numel() == 0 or mask2.numel() == 0:
            n1 = mask1.shape[0]
            n2 = mask2.shape[1]
            return torch.zeros((n1, n2), dtype=mask1.dtype, device=mask1.device)
        # elementwise multiply with broadcasting, then sum along pixels
        inter = (mask1 * mask2).sum(dim=2)  # (N,M)
        area1 = mask1.sum(dim=2).unsqueeze(1)  # (N,1)
        area2 = mask2.sum(dim=2).unsqueeze(0)  # (1,M)
        union = area1 + area2 - inter
        return inter / (union.clamp(min=eps))
