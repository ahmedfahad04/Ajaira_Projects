
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        if not isinstance(tensor1, torch.Tensor) or not isinstance(tensor2, torch.Tensor):
            raise TypeError("Inputs must be torch.Tensor")
        if tensor1.shape != tensor2.shape:
            raise ValueError("Input tensors must have the same shape")
        n = tensor1.shape[0] if tensor1.dim() > 0 else 0
        rest = tensor1.shape[1:]
        if n == 0:
            return tensor1.new_empty((0,)+rest), tensor2.new_empty((0,)+rest)
        out_shape = (n * 2,) + rest
        out1 = torch.empty(out_shape, dtype=tensor1.dtype, device=tensor1.device)
        out2 = torch.empty(out_shape, dtype=tensor1.dtype, device=tensor1.device)
        out1[0::2] = tensor1
        out1[1::2] = tensor2
        out2[0::2] = tensor2
        out2[1::2] = tensor1
        return out1, out2
