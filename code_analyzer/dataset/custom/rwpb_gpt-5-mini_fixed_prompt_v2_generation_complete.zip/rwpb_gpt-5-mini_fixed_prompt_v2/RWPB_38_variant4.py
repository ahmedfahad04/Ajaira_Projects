
def extract_imports_from_lines(lines: List[str]) -> str:
    from typing import List
    import io
    import tokenize
    def extract_imports_from_lines(lines: List[str]) -> str:
        src = "\n".join(line.rstrip("\n") for line in lines) + "\n"
        results = []
        try:
            gen = tokenize.generate_tokens(io.StringIO(src).readline)
        except Exception:
            return ""
        collecting = False
        buf = []
        paren = 0
        start_of_logical = True
        for tok in gen:
            tok_type = tok.type
            tok_str = tok.string
            # Track start of logical line
            if tok_type in (tokenize.INDENT, tokenize.DEDENT):
                start_of_logical = True
            if tok_type == tokenize.NAME and tok_str in ("import", "from") and start_of_logical:
                collecting = True
                buf.append((tok_type, tok_str))
                start_of_logical = False
                continue
            if collecting:
                buf.append((tok_type, tok_str))
                if tok_type == tokenize.OP:
                    if tok_str in "([{":
                        paren += 1
                    elif tok_str in ")]}":
                        paren -= 1
                    elif tok_str == ";" and paren == 0:
                        # end of statement
                        try:
                            text = tokenize.untokenize(buf).strip()
                        except Exception:
                            text = "".join(t[1] for t in buf).strip()
                        results.append(text)
                        buf = []
                        collecting = False
                if tok_type == tokenize.NEWLINE and paren == 0:
                    try:
                        text = tokenize.untokenize(buf).strip()
                    except Exception:
                        text = "".join(t[1] for t in buf).strip()
                    results.append(text)
                    buf = []
                    collecting = False
            # update start_of_logical
            if tok_type in (tokenize.NEWLINE, tokenize.NL):
                start_of_logical = True
            elif tok_type not in (tokenize.ENCODING, tokenize.NL):
                start_of_logical = False
        # flush if any
        if collecting and buf:
            try:
                text = tokenize.untokenize(buf).strip()
            except Exception:
                text = "".join(t[1] for t in buf).strip()
            results.append(text)
        return "\n".join(results)
