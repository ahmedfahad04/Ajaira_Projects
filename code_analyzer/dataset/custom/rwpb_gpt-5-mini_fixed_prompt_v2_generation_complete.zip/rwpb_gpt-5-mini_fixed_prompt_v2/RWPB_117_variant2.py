
def path_spliter(path: str):
    import os
    def path_spliter(path: str):
        if not path:
            return []
        parts = []
        p = path
        # Iteratively split off the tail until nothing left
        while True:
            head, tail = os.path.split(p)
            if tail:
                parts.insert(0, tail)
                p = head
                continue
            if head:
                parts.insert(0, head)
            break
        return parts
