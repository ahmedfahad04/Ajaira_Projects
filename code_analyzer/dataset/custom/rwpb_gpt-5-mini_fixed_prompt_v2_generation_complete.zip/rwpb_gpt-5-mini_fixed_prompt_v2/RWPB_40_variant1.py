
def extract_code_from_funct(funct: Callable) -> List[str]:
    import inspect
    import ast
    import textwrap
    from typing import Callable, List
    def extract_code_from_funct(funct: Callable) -> List[str]:
        src = inspect.getsource(funct)
        # Parse the source and find the first function definition node
        tree = ast.parse(src)
        func_node = None
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                func_node = node
                break
        if func_node is None:
            return []
        # Extract source segments for each statement in the function body preserving order
        segments = []
        for stmt in func_node.body:
            seg = ast.get_source_segment(src, stmt)
            if seg is not None:
                segments.append(seg)
            else:
                # fallback to using lineno/end_lineno if source segment not available
                try:
                    start = stmt.lineno - 1
                    end = getattr(stmt, "end_lineno", stmt.lineno)  # inclusive
                    lines = src.splitlines()[start:end]
                    segments.append("\n".join(lines))
                except Exception:
                    continue
        body_src = "\n".join(segments)
        ded = textwrap.dedent(body_src)
        lines = ded.splitlines()
        # strip leading/trailing empty lines
        while lines and lines[0].strip() == "":
            lines.pop(0)
        while lines and lines[-1].strip() == "":
            lines.pop()
        # remove trailing return statement if present
        if lines:
            last = lines[-1].lstrip()
            if last.startswith("return"):
                lines.pop()
                # also strip trailing blank lines after removal
                while lines and lines[-1].strip() == "":
                    lines.pop()
        return lines
