
def mean(l, ignore_nan=False, empty=0):
    import math
    import statistics
    def mean(l, ignore_nan=False, empty=0):
        def is_nan(x):
            try:
                return math.isnan(x)
            except Exception:
                return False
        if ignore_nan:
            gen = (x for x in l if not is_nan(x))
        else:
            # If any element is NaN and we are not ignoring, return NaN early by wrapping generator
            def _gen():
                for x in l:
                    if is_nan(x):
                        # immediate result: mean is NaN
                        yield float('nan')
                        # finish the generator so statistics.mean will compute NaN
                        return
                    yield x
            gen = _gen()
        try:
            result = statistics.mean(list(gen))
        except statistics.StatisticsError:
            if empty == 'raise':
                raise ValueError("mean of empty sequence")
            return empty
        return float(result)
