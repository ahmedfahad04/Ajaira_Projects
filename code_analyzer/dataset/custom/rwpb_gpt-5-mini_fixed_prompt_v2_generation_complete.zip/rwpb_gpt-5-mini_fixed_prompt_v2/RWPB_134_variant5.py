
def select_best_resolution(original_size, possible_resolutions):
    def select_best_resolution(original_size, possible_resolutions):
        if not possible_resolutions:
            return None
        try:
            ow, oh = original_size
        except Exception:
            return None
        # Greedy: prefer the largest resolution that fits within original. If none fit, choose the smallest by area.
        fitting = [(w, h) for (w, h) in possible_resolutions if w <= ow and h <= oh]
        if fitting:
            # choose largest area among fitting
            return max(fitting, key=lambda wh: wh[0] * wh[1])
        # if none fit, choose smallest area (least upscaling)
        return min(possible_resolutions, key=lambda wh: wh[0] * wh[1])
