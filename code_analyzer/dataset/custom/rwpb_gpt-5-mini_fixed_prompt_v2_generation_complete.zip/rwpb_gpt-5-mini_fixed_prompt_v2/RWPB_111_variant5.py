
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        # Simple explicit loop fill (less efficient but straightforward)
        if H <= 0 or W <= 0 or B <= 0:
            return torch.empty((B, 2, H, W))
        # prepare normalized coordinates arrays
        if W > 1:
            xs = [(2.0 * i / (W - 1) - 1.0) for i in range(W)]
        else:
            xs = [0.0]
        if H > 1:
            ys = [(2.0 * j / (H - 1) - 1.0) for j in range(H)]
        else:
            ys = [0.0]
        # create base (2,H,W)
        base = torch.empty((2, H, W), dtype=torch.float32)
        for j in range(H):
            for i in range(W):
                base[0, j, i] = xs[i]  # x
                base[1, j, i] = ys[j]  # y
        # tile for batch
        out = base.unsqueeze(0).repeat(B, 1, 1, 1)
        return out
