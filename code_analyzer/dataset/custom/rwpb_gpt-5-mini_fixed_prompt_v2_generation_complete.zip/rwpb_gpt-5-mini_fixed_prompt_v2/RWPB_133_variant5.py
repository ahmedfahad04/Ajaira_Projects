
def divide_to_patches(image, patch_size):
    from PIL import Image
    def divide_to_patches(image, patch_size):
        w, h = image.size
        patches = []
        max_x = w - (w % patch_size)
        max_y = h - (h % patch_size)
        for y in range(0, max_y, patch_size):
            for x in range(0, max_x, patch_size):
                patches.append(image.crop((x, y, x + patch_size, y + patch_size)))
        return patches
