
def apply_colormap(:
    import torch
    import numpy as np
    from matplotlib import cm
    def apply_colormap(image, cmap="viridis"):
        """
        Vectorized numpy-backed implementation.
        Accepts tensors with channel-last (...,1) or channel-first (...,1, H, W) where channel dimension equals 1 at index 1.
        """
        if not isinstance(image, torch.Tensor):
            raise TypeError("image must be a torch.Tensor")
        # Move channel to last if it's channel-first (C == 1 at dim 1)
        x = image
        if x.ndim >= 2 and x.shape[1] == 1 and x.ndim >= 3:
            dims = list(range(x.ndim))
            dims.pop(1)
            dims.append(1)
            x = x.permute(*dims)
        if x.shape[-1] != 1:
            raise ValueError("Expected channel dimension of size 1 at the last axis")
        device = image.device
        dtype = torch.float32
        arr = x.detach().cpu().numpy()
        # squeeze last axis
        vals = np.squeeze(arr, axis=-1)
        # normalize globally to [0,1]
        vmin = vals.min()
        vmax = vals.max()
        if np.isfinite(vmin) and np.isfinite(vmax) and vmax > vmin:
            normed = (vals - vmin) / (vmax - vmin)
        else:
            normed = np.zeros_like(vals, dtype=float)
        cmap_fn = cm.get_cmap(cmap)
        colored = cmap_fn(normed)  # returns RGBA in last dim
        rgb = colored[..., :3].astype(np.float32)
        out = torch.from_numpy(rgb).to(device=device, dtype=dtype)
        # ensure same leading dims as original but last dim = 3
        return out
