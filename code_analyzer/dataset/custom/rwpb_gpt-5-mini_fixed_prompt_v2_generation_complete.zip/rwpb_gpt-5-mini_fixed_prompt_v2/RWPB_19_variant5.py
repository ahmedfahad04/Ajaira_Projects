
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        if len(preds) != len(references):
            raise ValueError("preds and references must be same length")
        n = len(preds)
        if n < 2:
            return 0.0
        # We'll count concordant pairs efficiently by processing preds groups and a Fenwick over reference ranks
        items = list(range(n))
        items.sort(key=lambda i: (preds[i], i))
        refs = [references[i] for i in items]
        # compress reference values to indices for Fenwick tree
        uniq_refs = sorted(set(refs))
        comp = {v: idx+1 for idx, v in enumerate(uniq_refs)}
        size = len(uniq_refs) + 2
        fenw = [0] * (size + 1)
        def fenw_add(i, v):
            while i <= size:
                fenw[i] += v
                i += i & -i
        def fenw_sum(i):
            s = 0
            while i > 0:
                s += fenw[i]
                i -= i & -i
            return s
        total_pairs = n * (n - 1) // 2
        correct = 0
        # Process groups of equal preds
        from collections import Counter
        idx = 0
        processed = 0
        while idx < n:
            j = idx
            while j < n and preds[items[j]] == preds[items[idx]]:
                j += 1
            # items in [idx, j) have same preds
            # pairs within group are correct only if references equal
            group_refs = refs[idx:j]
            cnts = Counter(group_refs)
            for c in cnts.values():
                if c > 1:
                    correct += c * (c - 1) // 2
            # pairs across previous groups: for each element, number of previous refs strictly less than current contributes concordant
            for r in group_refs:
                ri = comp[r]
                less = fenw_sum(ri - 1)
                correct += less
            # add current group refs to fenwick as processed
            for r in group_refs:
                fenw_add(comp[r], 1)
            processed += (j - idx)
            idx = j
        return correct / total_pairs if total_pairs > 0 else 0.0
