
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        arr = np.asarray(image)
        if arr.ndim == 2:
            arr = arr[np.newaxis, ...]
        elif arr.ndim == 3:
            arr = np.transpose(arr, (2, 0, 1))
        else:
            raise ValueError("Input is not a valid image. Expected 2D or 3D array.")
        arr = arr.astype(np.float32) / 255.0
        return torch.from_numpy(np.ascontiguousarray(arr))
