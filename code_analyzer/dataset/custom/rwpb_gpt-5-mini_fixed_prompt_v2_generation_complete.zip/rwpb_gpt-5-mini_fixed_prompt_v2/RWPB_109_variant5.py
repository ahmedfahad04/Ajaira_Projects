
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        B, N, _ = geometry.shape
        ones = geometry.new_ones(B, N, 1)
        homo_pts = torch.cat([geometry, ones], dim=2)
        T = geometry.new_zeros(B, 4, 4)
        T[:, :3, :3] = rot
        T[:, :3, 3] = trans
        T[:, 3, 3] = 1.0
        transformed = torch.bmm(homo_pts, T)
        return transformed[:, :, :3]
