
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    import math
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        if upcast:
            orig_dtype = x.dtype
            x = x.float()
            weight = weight.float() if weight is not None else None
            bias = bias.float() if bias is not None else None
            residual = residual.float() if residual is not None else None
        D = x.size(-1)
        # prepare weight/bias shapes
        if weight is not None and weight.dim() == 1:
            weight = weight.view(*([1] * (x.dim() - 1)), -1)
        if bias is not None and bias.dim() == 1:
            bias = bias.view(*([1] * (x.dim() - 1)), -1)
        # use einsum to compute sum of squares, then mean
        sum_sq = torch.einsum('...d,...d->...', x, x).unsqueeze(-1)
        mean_sq = sum_sq / float(D)
        denom = torch.sqrt(mean_sq + eps)
        normed = x / denom
        out = normed * weight if weight is not None else normed
        if bias is not None:
            out = out + bias
        if residual is not None:
            out = out + residual
        if upcast:
            out = out.to(orig_dtype)
        if prenorm:
            return out, x
        return out
