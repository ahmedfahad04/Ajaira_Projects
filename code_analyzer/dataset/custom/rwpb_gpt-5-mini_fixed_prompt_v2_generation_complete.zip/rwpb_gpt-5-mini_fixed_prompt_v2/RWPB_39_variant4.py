
def clean_html(:
    import re
    from typing import List
    def clean_html(
            html_to_clean: str,
            tags_to_remove: List[str] = ["style", "svg", "script"],
            attributes_to_keep: List[str] = ["id", "href"],
    ) -> str:
        s = html_to_clean or ""
        remove = set(t.lower() for t in (tags_to_remove or []))
        keep = set(a.lower() for a in (attributes_to_keep or []))
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(s, "html.parser")
            for tag in list(soup.find_all()):
                if tag.name and tag.name.lower() in remove:
                    tag.decompose()
                else:
                    if tag.attrs:
                        new_attrs = {}
                        for k, v in list(tag.attrs.items()):
                            if k.lower() in keep:
                                new_attrs[k] = v
                        tag.attrs = new_attrs
            return str(soup)
        except Exception:
            tag_re = re.compile(r'(<[^>]+>|[^<]+)', re.S)
            nm_re = re.compile(r'^<\s*(/)?\s*([^\s/>]+)', re.I)
            attr_re = re.compile(r'([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^>\s]+)))?')
            out = []
            ignore = []
            for tok in tag_re.findall(s):
                if not tok:
                    continue
                if tok[0] != '<':
                    if not ignore:
                        out.append(tok)
                    continue
                if tok.startswith('<!--') or tok.startswith('<!'):
                    if not ignore:
                        out.append(tok)
                    continue
                m = nm_re.match(tok)
                if not m:
                    if not ignore:
                        out.append(tok)
                    continue
                closing = bool(m.group(1))
                name = m.group(2).lower()
                selfclose = tok.rstrip().endswith('/>')
                if not closing and name in remove:
                    if not selfclose:
                        ignore.append(name)
                    continue
                if closing and ignore:
                    if ignore and ignore[-1] == name:
                        ignore.pop()
                    continue
                if ignore:
                    continue
                if closing:
                    out.append(f"</{m.group(2)}>")
                    continue
                body = tok[m.end(): -1].strip()
                if body.endswith('/'):
                    body = body[:-1].rstrip()
                    selfclose = True
                attrs = []
                for am in attr_re.finditer(body):
                    an = am.group(1)
                    av = am.group(2) if am.group(2) is not None else (am.group(3) if am.group(3) is not None else am.group(4))
                    if an.lower() in keep:
                        if av is None:
                            attrs.append(an)
                        else:
                            attrs.append(f'{an}="{av.replace(\'"\', "&quot;")}"')
                if attrs:
                    inner = " " + " ".join(attrs)
                else:
                    inner = ""
                if selfclose:
                    out.append(f"<{m.group(2)}{inner} />")
                else:
                    out.append(f"<{m.group(2)}{inner}>")
            return "".join(out)
