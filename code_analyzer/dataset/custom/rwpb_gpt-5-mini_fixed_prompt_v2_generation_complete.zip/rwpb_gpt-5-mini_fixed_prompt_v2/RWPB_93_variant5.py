
def unsafeSub(x, y):
    WORD = 1 << 256
    MAX_VAL = WORD - 1
    def unsafeSub(x, y):
        # use two's complement: x + (~y + 1) masked to 256 bits
        ax = x & MAX_VAL
        ay = y & MAX_VAL
        twos = (~ay + 1) & MAX_VAL
        return (ax + twos) & MAX_VAL
