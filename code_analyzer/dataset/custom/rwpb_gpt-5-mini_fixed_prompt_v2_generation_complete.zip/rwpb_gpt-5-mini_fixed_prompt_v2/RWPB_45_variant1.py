
def invalid_to_zeros(arr, valid_mask, ndim=999):
    import torch
    def invalid_to_zeros(arr, valid_mask, ndim=999):
        if not isinstance(arr, torch.Tensor):
            raise TypeError("arr must be a torch.Tensor")
        if ndim != 999 and arr.dim() > ndim:
            head = tuple(arr.shape[:ndim-1])
            tail = int(torch.tensor(arr.shape[ndim-1:]).prod().item())
            arr = arr.view(*head, tail)
        if valid_mask is None:
            if arr.dim() == 0:
                nnz = torch.tensor(int(arr.numel()))
            else:
                nnz = torch.tensor(arr.numel() // arr.shape[0])
            return arr, nnz
        mask = valid_mask
        if not isinstance(mask, torch.Tensor):
            mask = torch.tensor(mask, dtype=torch.bool, device=arr.device)
        mask = mask.bool().to(device=arr.device)
        try:
            if mask.shape != arr.shape:
                if mask.numel() == arr.numel():
                    mask = mask.view(arr.shape)
                elif mask.dim() == arr.dim() - 1 and mask.shape == arr.shape[:mask.dim()]:
                    mask = mask.unsqueeze(-1)
                elif mask.numel() == arr.shape[0]:
                    mask = mask.view(arr.shape[0], 1)
                    expand_sizes = list(arr.shape)
                    expand_sizes[0] = arr.shape[0]
                    for i in range(1, len(expand_sizes)):
                        expand_sizes[i] = arr.shape[i]
                    mask = mask.expand(*expand_sizes)
                else:
                    mask = mask.view(*mask.shape, *([1] * (arr.dim() - mask.dim())))
            arr.masked_fill_(~mask, 0)
        except Exception:
            mask = mask.reshape(-1)
            arr_flat = arr.view(-1)
            if mask.numel() == arr_flat.numel():
                arr_flat[~mask] = 0
                arr = arr_flat.view(arr.shape)
            else:
                raise
        if mask.dim() >= 1 and mask.shape[0] == arr.shape[0]:
            nnz = mask.view(arr.shape[0], -1).sum(dim=1)
        else:
            nnz = torch.tensor((mask.view(-1) == 1).sum().item())
        return arr, nnz
