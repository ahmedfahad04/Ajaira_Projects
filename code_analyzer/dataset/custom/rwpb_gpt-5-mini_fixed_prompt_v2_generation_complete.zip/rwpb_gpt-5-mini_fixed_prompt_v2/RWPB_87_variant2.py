
def rotate_x(a, device=None):
    import torch
    import math
    def rotate_x(a, device=None):
        # normalize device
        dev = torch.device(device) if device is not None else None
        # create tensor for angle on device to use torch trig
        if isinstance(a, torch.Tensor):
            a_t = a.to(dev) if dev is not None else a
        else:
            a_t = torch.tensor(float(a), device=dev)
        c = torch.cos(a_t)
        s = torch.sin(a_t)
        # create identity and fill
        m = torch.eye(4, device=dev, dtype=torch.float32)
        m[1,1] = c
        m[1,2] = -s
        m[2,1] = s
        m[2,2] = c
        return m
