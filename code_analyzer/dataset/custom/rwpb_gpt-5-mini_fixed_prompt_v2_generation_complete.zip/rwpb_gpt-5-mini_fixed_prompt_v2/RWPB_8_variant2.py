
def cvimg2torch(img):
    def cvimg2torch(img):
        import numpy as np
        import torch
        arr = np.asarray(img)
        if arr.ndim == 2:
            arr = arr[..., None]
        if arr.ndim == 3:
            arr = np.ascontiguousarray(arr.transpose(2, 0, 1))
            return torch.from_numpy(arr).unsqueeze(0)
        if arr.ndim == 4:
            arr = np.ascontiguousarray(arr.transpose(0, 3, 1, 2))
            return torch.from_numpy(arr)
        raise ValueError("Unsupported input shape")
