
def focal2fov(focal, pixels):
    import math
    def focal2fov(focal, pixels):
        if focal == 0:
            return KeyError
        f = float(focal)
        p = float(pixels)
        return 2.0 * math.atan(p / (2.0 * f))
