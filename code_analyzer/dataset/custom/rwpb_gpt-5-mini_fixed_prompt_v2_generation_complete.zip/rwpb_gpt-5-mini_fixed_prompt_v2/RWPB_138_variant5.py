
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        arr = np.array(normal_map, dtype=np.float32, copy=True)
        if arr.ndim != 3 or arr.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        theta = np.deg2rad(angle)
        c = np.cos(theta)
        s = np.sin(theta)
        # Compute new x and z in-place using channel arithmetic
        x = arr[..., 0]
        y = arr[..., 1]
        z = arr[..., 2]
        x_new = c * x + s * z
        z_new = -s * x + c * z
        out = np.empty_like(arr)
        out[..., 0] = x_new
        out[..., 1] = y
        out[..., 2] = z_new
        # Safe normalization: only divide where norm > eps
        norms = np.linalg.norm(out, axis=2, keepdims=True)
        eps = 1e-8
        mask = norms > eps
        out = np.where(mask, out / np.maximum(norms, eps), out)
        return out
