
def arccos2(vector, value):
    import math
    def arccos2(vector, value):
        x = float(vector[0])
        y = float(vector[1])
        v = float(value)
        if v != v:
            return float('nan')
        if v > 1.0:
            v = 1.0
        if v < -1.0:
            v = -1.0
        angle = math.acos(v)
        if y < 0:
            angle = 2.0 * math.pi - angle
        return angle
