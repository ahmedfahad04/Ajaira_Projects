
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        if len(preds) != len(references):
            raise ValueError("Length mismatch")
        n = len(preds)
        if n < 2:
            return 0.0
        # fast path when there are no ties in preds and references: use inversion count
        if len(set(preds)) == n and len(set(references)) == n:
            # map preds to sorted order
            order = sorted(range(n), key=lambda i: preds[i])
            # build sequence of reference ranks in the preds order
            ref_in_pred_order = [references[i] for i in order]
            # compress references to ranks
            uniq = {v:i+1 for i,v in enumerate(sorted(set(ref_in_pred_order)))}
            ranks = [uniq[v] for v in ref_in_pred_order]
            # count inversions in ranks
            maxr = len(uniq) + 2
            bit = [0] * (maxr+1)
            def bit_add(i, val):
                while i <= maxr:
                    bit[i] += val
                    i += i & -i
            def bit_sum(i):
                s = 0
                while i > 0:
                    s += bit[i]
                    i -= i & -i
                return s
            inv = 0
            for i, r in enumerate(ranks):
                inv += i - bit_sum(r)
                bit_add(r, 1)
            total = n * (n - 1) // 2
            concordant = total - inv
            return concordant / total if total else 0.0
        # fallback: pairwise comparison
        def sgn(x):
            if x > 0: return 1
            if x < 0: return -1
            return 0
        correct = 0
        total = 0
        for i in range(n):
            for j in range(i+1, n):
                if sgn(preds[i]-preds[j]) == sgn(references[i]-references[j]):
                    correct += 1
                total += 1
        return correct / total if total else 0.0
