
def seconds_to_hh_mm_ss(seconds):
    def seconds_to_hh_mm_ss(seconds):
        try:
            total = int(seconds)
        except Exception:
            return "00:00:00"
        if total < 0:
            return "00:00:00"
        h = 0
        m = 0
        s = total
        while s >= 3600:
            s -= 3600
            h += 1
        while s >= 60:
            s -= 60
            m += 1
        return str(h).zfill(2) + ":" + str(m).zfill(2) + ":" + str(s).zfill(2)
