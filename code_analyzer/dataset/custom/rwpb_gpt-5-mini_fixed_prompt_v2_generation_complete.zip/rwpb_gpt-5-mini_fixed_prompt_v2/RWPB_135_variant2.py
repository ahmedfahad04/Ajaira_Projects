
def mask_iou(mask1, mask2, eps=1e-7):
    import torch
    def mask_iou(mask1, mask2, eps=1e-7):
        mask1 = mask1.float()
        mask2 = mask2.float()
        N = mask1.shape[0]
        M = mask2.shape[0]
        if N == 0 or M == 0:
            return torch.zeros((N, M), dtype=mask1.dtype, device=mask1.device)
        # use einsum to compute pairwise intersections
        intersection = torch.einsum('ik,jk->ij', mask1, mask2)
        area1 = mask1.sum(dim=1).unsqueeze(1)  # (N,1)
        area2 = mask2.sum(dim=1).unsqueeze(0)  # (1,M)
        union = area1 + area2 - intersection
        return intersection / (union.clamp(min=eps))
