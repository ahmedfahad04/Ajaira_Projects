
def unsafeSub(x, y):
    WORD = 1 << 256
    MAX_VAL = WORD - 1
    def unsafeSub(x, y):
        # reduce operands to 256-bit unsigned values first, then modulo
        a = x & MAX_VAL
        b = y & MAX_VAL
        return (a - b) % WORD
