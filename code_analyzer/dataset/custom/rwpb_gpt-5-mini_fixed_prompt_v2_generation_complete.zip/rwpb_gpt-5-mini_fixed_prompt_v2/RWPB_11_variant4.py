
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    from typing import List
    def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        # recursive padding/truncation
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be a non-negative integer")
        seq = list(ls)
        def ensure(seq):
            if len(seq) == max_seq_length:
                return seq
            if len(seq) > max_seq_length:
                if pad_right:
                    return seq[:max_seq_length]
                else:
                    return seq[-max_seq_length:] if max_seq_length > 0 else []
            # len < max, add one pad and recurse (tail recursion style)
            if pad_right:
                seq.append(pad_idx)
            else:
                seq.insert(0, pad_idx)
            return ensure(seq)
        res = ensure(seq)
        if check and len(res) != max_seq_length:
            raise ValueError("Result length does not equal max_seq_length")
        return res
