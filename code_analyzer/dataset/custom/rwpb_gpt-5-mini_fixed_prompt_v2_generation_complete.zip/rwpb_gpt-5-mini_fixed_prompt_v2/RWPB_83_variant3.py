
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        if sample is None or not isinstance(sample, dict):
            return (size[0], size[1])
        image = sample.get("image")
        disparity = sample.get("disparity")
        mask = sample.get("mask")
        if image is None and disparity is None and mask is None:
            return (size[0], size[1])
        if image is not None:
            h, w = image.shape[:2]
        elif disparity is not None:
            h, w = disparity.shape[:2]
        else:
            h, w = mask.shape[:2]
        min_h, min_w = int(size[0]), int(size[1])
        if h >= min_h and w >= min_w:
            return (h, w)
        scale_h = min_h / h
        scale_w = min_w / w
        scale = max(scale_h, scale_w)
        new_h = max(min_h, int(np.ceil(h * scale)))
        new_w = max(min_w, int(np.ceil(w * scale)))
        if image is not None:
            sample["image"] = cv2.resize(image, (new_w, new_h), interpolation=image_interpolation_method)
        if disparity is not None:
            d = disparity.astype(np.float64)
            d_rs = cv2.resize(d, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            d_rs = d_rs * scale
            if np.issubdtype(disparity.dtype, np.integer):
                sample["disparity"] = np.rint(d_rs).astype(disparity.dtype)
            else:
                sample["disparity"] = d_rs.astype(disparity.dtype)
        if mask is not None:
            m_rs = cv2.resize(mask, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            if m_rs.dtype != mask.dtype:
                if mask.dtype == np.bool_:
                    m_rs = (m_rs > 0)
                else:
                    m_rs = (m_rs > 0).astype(mask.dtype) * (255 if mask.dtype == np.uint8 else 1)
            sample["mask"] = m_rs
        return (new_h, new_w)
