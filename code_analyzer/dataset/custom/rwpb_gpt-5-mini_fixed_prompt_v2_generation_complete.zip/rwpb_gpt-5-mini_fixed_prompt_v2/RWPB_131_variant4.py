
def box_iou(box1, box2, eps=1e-7):
    import torch
    import numpy as np
    def box_iou(box1, box2, eps=1e-7):
        if not torch.is_tensor(box1):
            box1 = torch.tensor(box1)
        if not torch.is_tensor(box2):
            box2 = torch.tensor(box2)
        box1 = box1.float()
        box2 = box2.float()
        if box1.ndim == 1:
            box1 = box1.unsqueeze(0)
        if box2.ndim == 1:
            box2 = box2.unsqueeze(0)
        N = box1.shape[0]
        M = box2.shape[0]
        if N == 0 or M == 0:
            return torch.zeros((N, M), dtype=box1.dtype, device=box1.device)
        x1_1, y1_1, x2_1, y2_1 = box1[:,0], box1[:,1], box1[:,2], box1[:,3]
        x1_2, y1_2, x2_2, y2_2 = box2[:,0], box2[:,1], box2[:,2], box2[:,3]
        x1 = torch.maximum(x1_1[:,None], x1_2[None,:])
        y1 = torch.maximum(y1_1[:,None], y1_2[None,:])
        x2 = torch.minimum(x2_1[:,None], x2_2[None,:])
        y2 = torch.minimum(y2_1[:,None], y2_2[None,:])
        inter_w = (x2 - x1).clamp(min=0)
        inter_h = (y2 - y1).clamp(min=0)
        inter = inter_w * inter_h
        area1 = (x2_1 - x1_1).clamp(min=0) * (y2_1 - y1_1).clamp(min=0)
        area2 = (x2_2 - x1_2).clamp(min=0) * (y2_2 - y1_2).clamp(min=0)
        union = area1[:,None] + area2[None,:] - inter
        return inter / (union + eps)
