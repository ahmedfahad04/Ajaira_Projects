
def mulMod(x, y, z):
    def mulMod(x, y, z):
        if z == 0:
            raise ZeroDivisionError("integer modulo by zero")
        if z < 0:
            z = -z
        a = x % z
        b = y % z
        def rec(a, b):
            if b == 0:
                return 0
            half = rec(a, b >> 1)
            half = (half + half) % z
            if b & 1:
                return (half + a) % z
            return half
        return rec(a, b)
