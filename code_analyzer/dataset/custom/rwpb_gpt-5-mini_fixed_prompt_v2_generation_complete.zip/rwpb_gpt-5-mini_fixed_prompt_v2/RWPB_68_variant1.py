
def last_before(val, arr):
    import numpy as np
    def last_before(val, arr):
        arr = np.asarray(arr)
        if arr.size == 0:
            return -1
        pos = np.searchsorted(arr, val, side='right')
        idx = pos - 1
        return int(idx) if idx >= 0 else -1
