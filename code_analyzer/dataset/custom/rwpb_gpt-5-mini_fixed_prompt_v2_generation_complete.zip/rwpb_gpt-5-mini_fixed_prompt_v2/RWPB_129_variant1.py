
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        """
        Rescale segment masks to shape.
        masks: (N, C, H, W)
        shape: (height, width)
        padding: if True, assume letterbox padding (resize to square then center-crop)
        """
        if not isinstance(masks, torch.Tensor):
            masks = torch.as_tensor(masks)
        if masks.ndim != 4:
            raise ValueError("masks must be a 4D tensor (N, C, H, W)")
        N, C, Hm, Wm = masks.shape
        h, w = shape
        device = masks.device
        dtype = masks.dtype
        if padding:
            s = max(h, w)
            # Upsample to square (s, s)
            x = masks.reshape(N * C, 1, Hm, Wm)
            x = F.interpolate(x, size=(s, s), mode='bilinear', align_corners=False)
            x = x.reshape(N, C, s, s)
            # center crop to (h, w)
            top = (s - h) // 2
            left = (s - w) // 2
            out = x[:, :, top:top + h, left:left + w]
        else:
            x = masks.reshape(N * C, 1, Hm, Wm)
            out = F.interpolate(x, size=(h, w), mode='bilinear', align_corners=False)
            out = out.reshape(N, C, h, w)
        return out.to(device=device, dtype=dtype)
