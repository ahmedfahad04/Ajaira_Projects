
def rotate_about_z_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_z_axis(vector, theta):
        """
        Rotate by treating the (x,y) pair as a complex number and multiplying by e^{i theta}.
        """
        v = np.asarray(vector, dtype=float).reshape(3,)
        x, y, z = v[0], v[1], v[2]
        c = math.cos(theta)
        s = math.sin(theta)
        xr = x * c - y * s
        yr = x * s + y * c
        return np.array([xr, yr, z], dtype=float)
