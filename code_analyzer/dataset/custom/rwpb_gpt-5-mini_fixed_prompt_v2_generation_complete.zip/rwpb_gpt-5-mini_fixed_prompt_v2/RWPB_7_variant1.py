
def dynamic_import_function(function_path):
    from importlib import import_module
    def dynamic_import_function(function_path):
        """
        Simple import: split by last dot, import module, getattr the attribute.
        On any failure return ModuleNotFoundError.
        """
        if not isinstance(function_path, str) or '.' not in function_path:
            return ModuleNotFoundError
        module_path, attr_name = function_path.rsplit('.', 1)
        try:
            module = import_module(module_path)
        except ModuleNotFoundError:
            return ModuleNotFoundError
        except Exception:
            return ModuleNotFoundError
        try:
            return getattr(module, attr_name)
        except Exception:
            return ModuleNotFoundError
