
def cvimg2torch(img):
    def cvimg2torch(img):
        import numpy as np
        from torchvision.transforms.functional import to_tensor
        import torch
        arr = np.asarray(img)
        if arr.ndim == 2:
            arr = arr[..., None]
        if arr.ndim == 3:
            t = to_tensor(arr)
            return t.unsqueeze(0)
        if arr.ndim == 4:
            batch = []
            for i in range(arr.shape[0]):
                a = arr[i]
                if a.ndim == 2:
                    a = a[..., None]
                batch.append(to_tensor(a))
            return torch.stack(batch, dim=0)
        raise ValueError("Unsupported input shape")
