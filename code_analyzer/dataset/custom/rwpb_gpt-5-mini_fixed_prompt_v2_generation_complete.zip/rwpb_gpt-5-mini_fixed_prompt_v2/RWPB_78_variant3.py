
def check_all_columns_numeric(df):
    import pandas as pd
    import numpy as np
    def check_all_columns_numeric(df):
        if df is None or not hasattr(df, 'columns'):
            return False
        for col in df.columns:
            s = df[col]
            converted = pd.to_numeric(s, errors='coerce')
            mask_original_nonnull = s.notnull()
            if mask_original_nonnull.any():
                if converted[mask_original_nonnull].isnull().any():
                    return False
            else:
                # all values are null -> consider column numeric (no contradictory evidence)
                continue
        return True
