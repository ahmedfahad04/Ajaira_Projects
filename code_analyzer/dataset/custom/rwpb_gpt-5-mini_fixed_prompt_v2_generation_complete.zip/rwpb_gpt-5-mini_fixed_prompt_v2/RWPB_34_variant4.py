
def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
    import numpy as np
    def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
        target = context_window + 1
        arr = np.asarray(tokens)
        if arr.ndim == 1:
            keep = min(arr.shape[0], target)
            res = np.empty(target, dtype=arr.dtype)
            res.fill(pad_token)
            if keep > 0:
                res[:keep] = arr[:keep]
            return res
        if arr.ndim == 0:
            res = np.empty(target, dtype=type(arr.item()))
            res.fill(pad_token)
            return res
        # For 2D and higher, operate along last axis using apply_along_axis to unify logic
        def _pad_row(row):
            row = np.asarray(row)
            keep = min(row.shape[0], target)
            out = np.empty(target, dtype=row.dtype)
            out.fill(pad_token)
            if keep > 0:
                out[:keep] = row[:keep]
            return out
        # collapse leading dims into batch
        leading = arr.shape[:-1]
        batch = int(np.prod(leading)) if leading else 1
        reshaped = arr.reshape((batch, arr.shape[-1]))
        padded = np.vstack([_pad_row(r) for r in reshaped])
        return padded.reshape(leading + (target,))
