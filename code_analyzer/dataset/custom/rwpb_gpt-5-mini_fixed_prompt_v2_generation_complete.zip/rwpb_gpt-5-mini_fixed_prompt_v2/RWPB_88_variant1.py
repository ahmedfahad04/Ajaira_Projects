
def rotate_y(a, device=None):
    import torch
    def rotate_y(a, device=None):
        if torch.is_tensor(a):
            a_t = a if device is None else a.to(device)
        else:
            dtype = torch.get_default_dtype()
            a_t = torch.tensor(a, dtype=dtype, device=device)
        c = torch.cos(a_t)
        s = torch.sin(a_t)
        dtype = a_t.dtype
        mat = torch.eye(4, dtype=dtype, device=device)
        mat[0,0] = c
        mat[0,2] = s
        mat[1,1] = 1
        mat[2,0] = -s
        mat[2,2] = c
        return mat
