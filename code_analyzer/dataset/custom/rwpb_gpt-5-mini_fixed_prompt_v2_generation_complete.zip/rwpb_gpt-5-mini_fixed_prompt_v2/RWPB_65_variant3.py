
def merge_dicts_recursively(*dicts):
    from collections.abc import Mapping
    def merge_dicts_recursively(*dicts):
        dicts = [d for d in dicts if isinstance(d, Mapping)]
        if not dicts:
            return {}
        keys = set()
        for d in dicts:
            keys |= set(d.keys())
        result = {}
        for k in keys:
            values = [d[k] for d in dicts if k in d]
            if all(isinstance(v, Mapping) for v in values):
                result[k] = merge_dicts_recursively(*values)
            else:
                result[k] = values[-1]
        return result
