
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        if not torch.is_tensor(masks):
            masks = torch.tensor(masks)
        if masks.ndim != 4:
            raise ValueError("masks must be (N, C, H, W)")
        N, C, Hm, Wm = masks.shape
        h, w = shape
        device = masks.device
        dtype = masks.dtype
        out = torch.zeros((N, C, h, w), dtype=masks.dtype, device=device)
        if padding:
            s = max(h, w)
            for i in range(N):
                single = masks[i:i+1]  # (1, C, Hm, Wm)
                up = F.interpolate(single, size=(s, s), mode='bilinear', align_corners=False)
                top = (s - h) // 2
                left = (s - w) // 2
                out[i] = up[0, :, top:top + h, left:left + w].to(dtype)
        else:
            for i in range(N):
                single = masks[i:i+1]
                out[i] = F.interpolate(single, size=(h, w), mode='bilinear', align_corners=False)[0].to(dtype)
        return out
