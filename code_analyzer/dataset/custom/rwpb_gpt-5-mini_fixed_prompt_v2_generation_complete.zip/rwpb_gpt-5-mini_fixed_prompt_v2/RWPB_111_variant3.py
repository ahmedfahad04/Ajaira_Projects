
def mesh_grid(B, H, W):
    import torch
    def mesh_grid(B, H, W):
        # Use torch.meshgrid with explicit construction and expand without copying where possible
        if H <= 0 or W <= 0 or B <= 0:
            return torch.empty((B, 2, H, W))
        # Build unnormalized integer coordinate grids then normalize
        xs = torch.arange(W, dtype=torch.float32)
        ys = torch.arange(H, dtype=torch.float32)
        yy, xx = torch.meshgrid(ys, xs, indexing='ij')  # yy: (H,W), xx: (H,W)
        # normalize to [-1,1] safely
        if W > 1:
            xx = 2.0 * (xx / (W - 1)) - 1.0
        else:
            xx = torch.zeros_like(xx)
        if H > 1:
            yy = 2.0 * (yy / (H - 1)) - 1.0
        else:
            yy = torch.zeros_like(yy)
        grid = torch.stack((xx, yy), dim=0)  # (2,H,W)
        # Use expand to avoid data copies where possible
        return grid.unsqueeze(0).expand(B, -1, -1, -1).contiguous()
