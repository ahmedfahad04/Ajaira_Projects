
def box_iou(box1, box2, eps=1e-7):
    import torch
    import numpy as np
    def box_iou(box1, box2, eps=1e-7):
        is_numpy_input = False
        if not torch.is_tensor(box1):
            box1 = np.asarray(box1)
            is_numpy_input = True
        if not torch.is_tensor(box2):
            box2 = np.asarray(box2)
            is_numpy_input = True
        if torch.is_tensor(box1):
            device = box1.device
            box1_np = box1.detach().cpu().numpy()
        else:
            box1_np = box1
            device = torch.device('cpu')
        if torch.is_tensor(box2):
            box2_np = box2.detach().cpu().numpy()
        else:
            box2_np = box2
        if box1_np.size == 0 or box2_np.size == 0:
            res = np.zeros((box1_np.shape[0], box2_np.shape[0]), dtype=np.float32)
            return torch.from_numpy(res).to(device)
        x1 = np.maximum(box1_np[:, None, 0], box2_np[None, :, 0])
        y1 = np.maximum(box1_np[:, None, 1], box2_np[None, :, 1])
        x2 = np.minimum(box1_np[:, None, 2], box2_np[None, :, 2])
        y2 = np.minimum(box1_np[:, None, 3], box2_np[None, :, 3])
        inter_w = np.maximum(0.0, x2 - x1)
        inter_h = np.maximum(0.0, y2 - y1)
        inter = inter_w * inter_h
        area1 = np.maximum(0.0, (box1_np[:, 2] - box1_np[:, 0])) * np.maximum(0.0, (box1_np[:, 3] - box1_np[:, 1]))
        area2 = np.maximum(0.0, (box2_np[:, 2] - box2_np[:, 0])) * np.maximum(0.0, (box2_np[:, 3] - box2_np[:, 1]))
        union = area1[:, None] + area2[None, :] - inter
        iou = inter / (union + eps)
        out = torch.from_numpy(iou.astype(np.float32)).to(device)
        return out
