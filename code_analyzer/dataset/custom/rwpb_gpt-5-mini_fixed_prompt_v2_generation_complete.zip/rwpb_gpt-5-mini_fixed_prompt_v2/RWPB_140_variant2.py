
def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
    from typing import Callable, Dict, Tuple, Any
    import inspect
    from functools import partial
    def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
        params = dict(params or {})
        try:
            spec = inspect.getfullargspec(func)
        except (TypeError, ValueError):
            # fallback: no spec available
            return partial(func), {}
        # If function accepts **kwargs, we can pass all params
        if spec.varkw:
            return partial(func, **params), dict(params)
        allowed = set()
        # args (positional-or-keyword)
        if spec.args:
            allowed.update(spec.args)
        # Python 3 posonlyargs (if present)
        if hasattr(spec, "posonlyargs") and spec.posonlyargs:
            # posonlyargs cannot be passed by keyword -> do not include them
            posonly = set(spec.posonlyargs)
            allowed -= posonly
        # keyword-only args
        if spec.kwonlyargs:
            allowed.update(spec.kwonlyargs)
        matched = {k: v for k, v in params.items() if k in allowed}
        return partial(func, **matched), matched
