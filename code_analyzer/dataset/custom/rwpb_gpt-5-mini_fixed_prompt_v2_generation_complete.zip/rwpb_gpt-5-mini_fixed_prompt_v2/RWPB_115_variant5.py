
def compute_tri_normal(geometry, tris):
    import torch
    def compute_tri_normal(geometry, tris):
        """
        Compute unnormalized triangle normals (cross product of edges).
        This returns area-weighted normals (not unit length).
        """
        if tris.numel() == 0:
            return geometry.new_empty((geometry.shape[0], 0, 3))
        tris = tris.long().to(geometry.device)
        v0 = geometry.index_select(1, tris[:, 0])
        v1 = geometry.index_select(1, tris[:, 1])
        v2 = geometry.index_select(1, tris[:, 2])
        normals = torch.cross(v1 - v0, v2 - v0, dim=2)
        return normals
