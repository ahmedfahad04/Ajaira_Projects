
def round(number, num_decimal_places, leave_int=False):
    from decimal import Decimal, ROUND_HALF_DOWN
    def round(number, num_decimal_places, leave_int=False):
        """
        Decimal-based rounding using ROUND_HALF_DOWN (different tie behavior).
        """
        n = int(num_decimal_places)
        try:
            import math
            if isinstance(number, float) and (math.isnan(number) or math.isinf(number)):
                return float(number)
        except Exception:
            pass
        d = Decimal(str(number)) if not isinstance(number, Decimal) else number
        exp = Decimal('1E{}'.format(-n))
        rounded = d.quantize(exp, rounding=ROUND_HALF_DOWN)
        try:
            val = float(rounded)
        except Exception:
            val = rounded
        if leave_int:
            try:
                if val == int(val):
                    return int(val)
            except Exception:
                pass
        return val
