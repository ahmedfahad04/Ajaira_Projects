
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        # Functional style using tuple unpacking and lambdas; returns square crop.
        if box is None:
            raise ValueError("box must be provided")
        if expand <= 0:
            raise ValueError("expand must be > 0")
        x, y, x1, y1 = tuple(map(float, box))
        w = x1 - x
        h = y1 - y
        cx = x + 0.5 * w
        cy = y + 0.5 * h
        new_w = w * float(expand)
        new_h = h * float(expand)
        side = (lambda a, b: a if a >= b else b)(new_w, new_h)
        s = 0.5 * side
        make_box = lambda cx, cy, s: [cx - s, cy - s, cx + s, cy + s]
        return make_box(cx, cy, s), s
