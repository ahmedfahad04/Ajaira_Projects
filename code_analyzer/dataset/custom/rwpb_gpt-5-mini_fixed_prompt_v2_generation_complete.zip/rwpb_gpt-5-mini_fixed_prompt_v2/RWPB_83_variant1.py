
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        if sample is None:
            return (size[0], size[1])
        img = sample.get("image")
        disp = sample.get("disparity")
        mask = sample.get("mask")
        src = None
        if img is not None:
            src = img
        elif disp is not None:
            src = disp
        elif mask is not None:
            src = mask
        else:
            return (size[0], size[1])
        h, w = src.shape[:2]
        target_h, target_w = int(size[0]), int(size[1])
        scale_h = target_h / h if h > 0 else float('inf')
        scale_w = target_w / w if w > 0 else float('inf')
        scale = max(scale_h, scale_w, 1.0)
        if scale == 1.0:
            return (h, w)
        new_h = max(int(round(h * scale)), target_h)
        new_w = max(int(round(w * scale)), target_w)
        if img is not None:
            sample["image"] = cv2.resize(img, (new_w, new_h), interpolation=image_interpolation_method)
        if disp is not None:
            orig_dtype = disp.dtype
            disp_resized = cv2.resize(disp.astype(np.float32), (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            disp_resized = disp_resized * scale
            try:
                sample["disparity"] = disp_resized.astype(orig_dtype)
            except:
                sample["disparity"] = disp_resized
        if mask is not None:
            orig_dtype = mask.dtype
            mask_resized = cv2.resize(mask, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            if mask_resized.dtype != np.bool_ and orig_dtype == np.uint8:
                mask_resized = (mask_resized > 0).astype(np.uint8) * 255
            elif mask_resized.dtype != np.bool_ and orig_dtype == bool:
                mask_resized = (mask_resized > 0)
            sample["mask"] = mask_resized.astype(orig_dtype)
        return (new_h, new_w)
