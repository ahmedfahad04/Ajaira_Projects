
def movmean(arr, n_avg):
    import numpy as np
    def movmean(arr, n_avg):
        a = np.asarray(arr).ravel()
        if n_avg <= 0 or a.size == 0 or n_avg > a.size:
            return np.array([])
        alist = a.tolist()
        m = len(alist) - n_avg + 1
        res = []
        for i in range(m):
            s = 0.0
            for j in range(n_avg):
                s += float(alist[i + j])
            res.append(s / float(n_avg))
        return np.array(res, dtype=float)
