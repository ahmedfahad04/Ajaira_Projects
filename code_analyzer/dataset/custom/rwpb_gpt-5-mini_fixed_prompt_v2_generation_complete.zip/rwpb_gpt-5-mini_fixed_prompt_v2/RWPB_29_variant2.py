
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        preds = torch.as_tensor(preds)
        labels = torch.as_tensor(labels)
        if preds.dtype.is_floating_point:
            preds_bin = preds > 0.5
        else:
            preds_bin = preds != 0
        labels_fg = labels == 1
        if preds_bin.dim() == labels_fg.dim():
            if preds_bin.dim() == 2:
                preds_bin = preds_bin.unsqueeze(0)
                labels_fg = labels_fg.unsqueeze(0)
        else:
            # try to align channel dim
            if preds_bin.dim() == 4 and preds_bin.size(1) == 1:
                preds_bin = preds_bin.squeeze(1)
        if ignore is not None:
            mask = labels != ignore
            if mask.dim() == 2:
                mask = mask.unsqueeze(0)
            mask = mask.expand_as(labels_fg)
        else:
            mask = torch.ones_like(labels_fg, dtype=torch.bool)
        if not per_image:
            pm = preds_bin & mask
            lm = labels_fg & mask
            inter = torch.logical_and(pm, lm).sum(dtype=torch.float32)
            union = torch.logical_or(pm, lm).sum(dtype=torch.float32)
            if union == 0:
                return float(EMPTY * 100.0)
            return float((inter / union).item() * 100.0)
        else:
            n = preds_bin.size(0)
            scores = torch.zeros(n, dtype=torch.float32)
            for i in range(n):
                pm = preds_bin[i] & mask[i]
                lm = labels_fg[i] & mask[i]
                inter = torch.logical_and(pm, lm).sum(dtype=torch.float32)
                union = torch.logical_or(pm, lm).sum(dtype=torch.float32)
                scores[i] = EMPTY if union == 0 else inter / union
            return float(scores.mean().item() * 100.0)
