
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        img_arr = np.array(img)
        if img_arr.size == 0:
            return img_arr.copy()
        orig_dtype = img_arr.dtype
        max_val = int(img_arr.max())
        if max_val == 0:
            return img_arr.copy()
        bin_img = (img_arr > 0).astype('uint8') * 255
        # find contours with hierarchy to detect holes (RETR_CCOMP)
        contours, hierarchy = cv2.findContours(bin_img, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
        filled = bin_img.copy()
        if hierarchy is not None:
            # hierarchy shape: (1, N, 4)
            hierarchy = hierarchy[0]
            for idx, h in enumerate(hierarchy):
                parent = h[3]
                # If contour has a parent, it is a hole (child contour inside another)
                if parent != -1:
                    cv2.drawContours(filled, contours, idx, 255, thickness=cv2.FILLED)
        result = (filled // 255 * max_val).astype(orig_dtype)
        return result
