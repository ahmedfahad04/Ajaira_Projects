
def validate_user_id(user_id):
    def _is_alpha_char(ch):
        o = ord(ch)
        return (65 <= o <= 90) or (97 <= o <= 122)
    def _is_valid_rest(ch):
        o = ord(ch)
        return _is_alpha_char(ch) or (48 <= o <= 57) or (o == 95)
    def validate_user_id(user_id):
        if not isinstance(user_id, str) or len(user_id) == 0:
            return False
        if not _is_alpha_char(user_id[0]):
            return False
        for c in user_id[1:]:
            if not _is_valid_rest(c):
                return False
        return True
