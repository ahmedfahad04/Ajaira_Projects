
def format_ratio(ratio):
    import math
    def format_ratio(ratio):
        r = float(ratio)
        if math.isnan(r):
            return "percentage:NaN"
        if math.isinf(r):
            return f"percentage:{r}"
        s = f"{r:.12f}"
        neg = s.startswith('-')
        if neg:
            s = s[1:]
        if '.' in s:
            intpart, frac = s.split('.', 1)
        else:
            intpart, frac = s, ''
        frac = (frac + "000")[:3]
        out = ("-" if neg else "") + intpart + "." + frac
        return "percentage:" + out
