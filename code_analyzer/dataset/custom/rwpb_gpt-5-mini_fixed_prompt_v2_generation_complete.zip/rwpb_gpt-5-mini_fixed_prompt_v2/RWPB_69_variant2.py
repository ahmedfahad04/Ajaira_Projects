
def fovx_to_fovy(fovx, aspect):
    import numpy as np
    def fovx_to_fovy(fovx, aspect):
        # vectorized numpy implementation: supports scalars and arrays
        arr_fovx = np.asarray(fovx)
        arr_aspect = np.asarray(aspect)
        if np.any(arr_aspect <= 0):
            raise ValueError("aspect must be positive")
        half_tx = np.tan(0.5 * arr_fovx)
        half_ty = half_tx / arr_aspect
        result = 2.0 * np.arctan(half_ty)
        if np.isscalar(fovx) and np.isscalar(aspect):
            return float(result)
        return result
