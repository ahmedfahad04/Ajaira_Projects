
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        old = tensor.size(0)
        if batch_size == old:
            return tensor
        if old == 1:
            return tensor.expand(batch_size, *tensor.shape[1:]).clone()
        device = tensor.device
        pos = torch.linspace(0.0, float(old - 1), steps=batch_size, device=device)
        if batch_size < old:
            # reduction via evenly spaced integer selection using unique picks if possible
            idx = torch.round(pos).long().clamp(0, old - 1)
            return tensor[idx]
        else:
            # Build a sparse weight matrix of shape (batch_size, old) with two non-zero entries per row
            low = torch.clamp(pos.floor().long(), 0, old - 1)
            high = torch.clamp(pos.ceil().long(), 0, old - 1)
            frac = (pos - pos.floor()).to(dtype=tensor.dtype)
            # flatten remaining dims
            rest = tensor.shape[1:]
            prod = 1
            for s in rest:
                prod *= s
            flat = tensor.reshape(old, prod)  # (old, prod)
            # Build weighted combination
            # Start with zeros
            out_flat = torch.zeros((batch_size, prod), dtype=tensor.dtype, device=device)
            # add low * (1-frac)
            for i in range(batch_size):
                li = low[i].item()
                hi = high[i].item()
                f = frac[i].item()
                if li == hi:
                    out_flat[i] = flat[li]
                else:
                    out_flat[i] = (1.0 - f) * flat[li] + f * flat[hi]
            return out_flat.reshape((batch_size,) + rest)
