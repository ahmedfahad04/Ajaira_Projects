
def is_tensor(x):
    import importlib.util
    import numpy as np
    def is_tensor(x):
        try:
            import torch
        except Exception:
            torch = None
        if torch is not None and isinstance(x, torch.Tensor):
            return True
        return isinstance(x, np.ndarray)
