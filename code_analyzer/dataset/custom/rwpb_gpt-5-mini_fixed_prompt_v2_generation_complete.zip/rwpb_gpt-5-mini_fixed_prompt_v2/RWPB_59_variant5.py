
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    import torch.nn.functional as F
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        if repetition_penalty == 1.0:
            return logits
        rp = float(repetition_penalty)
        logits = logits.clone()
        batch_size, vocab_size = logits.shape
        if prev_output_tokens.numel() == 0:
            return logits
        # Build mask using one-hot sum then clamp to boolean
        one_hot = F.one_hot(prev_output_tokens.long(), num_classes=vocab_size).to(logits.device)
        mask = one_hot.sum(dim=1) > 0  # (batch, vocab)
        # Apply penalty using where for each sign
        pos_mask = mask & (logits > 0)
        neg_mask = mask & (logits <= 0)
        adjusted = logits
        adjusted = torch.where(pos_mask, adjusted / rp, adjusted)
        adjusted = torch.where(neg_mask, adjusted * rp, adjusted)
        return adjusted
