
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    def generate_grids(lower_limit, upper_limit, grid_size):
        lower = lower_limit.clone().float()
        upper = upper_limit.clone().float()
        if lower.dim() == 0:
            lower = lower.unsqueeze(0)
        if upper.dim() == 0:
            upper = upper.unsqueeze(0)
        D = lower.numel()
        if torch.is_tensor(grid_size):
            if grid_size.dim() == 0:
                gs = [int(grid_size.item())] * D
            else:
                gs = [int(x.item()) for x in grid_size.view(-1)]
        else:
            gs = [int(grid_size)] * D
        steps = (upper - lower) / torch.tensor(gs, dtype=lower.dtype)
        grids = []
        for i in range(D):
            if gs[i] > 0:
                grids.append(lower[i] + torch.arange(gs[i], dtype=lower.dtype) * steps[i])
            else:
                grids.append(torch.tensor([], dtype=lower.dtype))
        mesh = torch.meshgrid(*grids, indexing='ij') if D > 0 else []
        if D == 0:
            return torch.empty((0,0), dtype=lower.dtype), torch.empty((0,0), dtype=lower.dtype)
        coords = torch.stack([m.reshape(-1) for m in mesh], dim=1)
        lowers = coords
        uppers = lowers + steps.unsqueeze(0)
        return lowers, uppers
