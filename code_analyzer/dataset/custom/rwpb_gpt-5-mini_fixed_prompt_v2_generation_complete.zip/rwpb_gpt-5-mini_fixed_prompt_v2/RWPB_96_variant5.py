
def movmean(arr, n_avg):
    import numpy as np
    def movmean(arr, n_avg):
        a = np.asarray(arr).ravel().astype(float)
        if n_avg <= 0 or a.size == 0 or n_avg > a.size:
            return np.array([])
        try:
            from numpy.lib.stride_tricks import sliding_window_view
            windows = sliding_window_view(a, n_avg)
            return windows.mean(axis=-1)
        except Exception:
            # fallback to convolution
            kernel = np.ones(n_avg, dtype=float) / float(n_avg)
            return np.convolve(a, kernel, mode='valid')
