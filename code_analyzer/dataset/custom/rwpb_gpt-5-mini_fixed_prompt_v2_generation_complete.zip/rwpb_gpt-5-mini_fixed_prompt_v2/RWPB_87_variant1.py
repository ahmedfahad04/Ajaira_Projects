
def rotate_x(a, device=None):
    import math
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        # compute cosine and sine
        if isinstance(a, torch.Tensor):
            a_val = float(a.cpu().numpy())
        else:
            a_val = float(a)
        c = math.cos(a_val)
        s = math.sin(a_val)
        # build numpy array
        mat = np.array([
            [1.0, 0.0, 0.0, 0.0],
            [0.0,   c,  -s, 0.0],
            [0.0,   s,   c, 0.0],
            [0.0, 0.0, 0.0, 1.0]
        ], dtype=np.float32)
        kwargs = {'device': torch.device(device)} if device is not None else {}
        return torch.tensor(mat, dtype=torch.float32, **kwargs)
