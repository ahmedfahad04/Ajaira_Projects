
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        # Integer-rounded variant: produces integer coordinates for the returned box
        import math
        if box is None:
            raise ValueError("box is required")
        if expand <= 0:
            raise ValueError("expand must be > 0")
        x, y, x1, y1 = box
        x = float(x); y = float(y); x1 = float(x1); y1 = float(y1)
        w = x1 - x
        h = y1 - y
        cx = x + w / 2.0
        cy = y + h / 2.0
        new_w = w * float(expand)
        new_h = h * float(expand)
        side = max(new_w, new_h)
        s = side / 2.0
        new_x = cx - s
        new_y = cy - s
        new_x1 = cx + s
        new_y1 = cy + s
        # Round outward to include full area: floor for min coords, ceil for max coords
        new_x_i = math.floor(new_x)
        new_y_i = math.floor(new_y)
        new_x1_i = math.ceil(new_x1)
        new_y1_i = math.ceil(new_y1)
        return [new_x_i, new_y_i, new_x1_i, new_y1_i], s
