
def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    import torch.nn as nn
    def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        original_x = x
        if upcast:
            x = x.float()
            if weight is not None:
                weight = weight.float()
            if bias is not None:
                bias = bias.float()
            if residual is not None:
                residual = residual.float()
        normalized_shape = x.shape[-1]
        ln = nn.LayerNorm(normalized_shape, eps=eps, elementwise_affine=False)
        out = ln(x)
        if weight is not None:
            out = out * weight.view(*([1] * (x.dim() - 1)), -1)
        if bias is not None:
            out = out + bias.view(*([1] * (x.dim() - 1)), -1)
        if residual is not None:
            out = out + residual
        if prenorm:
            return out, original_x
        return out
