
def psnr_to_mse(psnr):
    import math
    import numpy as np
    def psnr_to_mse(psnr):
        try:
            return math.exp(-0.1 * math.log(10) * psnr)
        except TypeError:
            arr = np.asarray(psnr)
            return np.exp(-0.1 * np.log(10) * arr)
