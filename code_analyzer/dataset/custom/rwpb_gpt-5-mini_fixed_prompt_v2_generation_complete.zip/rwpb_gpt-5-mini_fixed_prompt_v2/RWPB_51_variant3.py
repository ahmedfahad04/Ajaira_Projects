
def _ssim(img1, img2, window, window_size, channel, size_average=True):
    import torch
    import torch.nn.functional as F
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        if img1.shape != img2.shape:
            raise ValueError("Input images must match in shape")
        device = img1.device
        dtype = img1.dtype
        # build flattened window weights
        if window.dim() == 2:
            w = window.view(-1).to(device).to(dtype)
        elif window.dim() == 4:
            w = window.view(window.size(0), -1).to(device).to(dtype)
            if w.size(0) == 1:
                w = w.expand(channel, w.size(1))
        else:
            w = window.view(-1).to(device).to(dtype)
        N, C, H, W = img1.shape
        pad = window_size // 2
        # Use unfold to extract patches and compute weighted moments
        patches1 = F.unfold(F.pad(img1, (pad,pad,pad,pad), mode='reflect'), kernel_size=window_size)
        patches2 = F.unfold(F.pad(img2, (pad,pad,pad,pad), mode='reflect'), kernel_size=window_size)
        # patches shape: [N, C*ws*ws, L]
        L = patches1.size(-1)
        # reshape to [N, C, ws*ws, L]
        patches1 = patches1.view(N, C, window_size*window_size, L)
        patches2 = patches2.view(N, C, window_size*window_size, L)
        if w.dim() == 1:
            w_full = w.view(1, 1, -1, 1).to(dtype)
            w_full = w_full.expand(1, C, -1, 1)
        else:
            w_full = w.view(1, C, -1, 1)
        w_full = w_full.to(device)
        # compute weighted means
        mu1 = (patches1 * w_full).sum(dim=2, keepdim=False).view(N, C, L)
        mu2 = (patches2 * w_full).sum(dim=2, keepdim=False).view(N, C, L)
        mu1 = mu1.view(N, C, int(H), int(W))
        mu2 = mu2.view(N, C, int(H), int(W))
        # compute second moments
        sigma1 = (patches1 * patches1 * w_full).sum(dim=2).view(N,C,L) - mu1.view(N,C,-1)**2
        sigma2 = (patches2 * patches2 * w_full).sum(dim=2).view(N,C,L) - mu2.view(N,C,-1)**2
        sigma12 = (patches1 * patches2 * w_full).sum(dim=2).view(N,C,L) - (mu1.view(N,C,-1)*mu2.view(N,C,-1))
        sigma1 = sigma1.view(N,C,H,W)
        sigma2 = sigma2.view(N,C,H,W)
        sigma12 = sigma12.view(N,C,H,W)
        C1 = (0.01)**2
        C2 = (0.03)**2
        mu1_mu2 = mu1 * mu2
        mu1_sq = mu1 * mu1
        mu2_sq = mu2 * mu2
        num = (2 * mu1_mu2 + C1) * (2 * sigma12 + C2)
        den = (mu1_sq + mu2_sq + C1) * (sigma1 + sigma2 + C2)
        ssim_map = num / den
        if size_average:
            return ssim_map.mean()
        else:
            return ssim_map.mean(dim=(0,2,3))
