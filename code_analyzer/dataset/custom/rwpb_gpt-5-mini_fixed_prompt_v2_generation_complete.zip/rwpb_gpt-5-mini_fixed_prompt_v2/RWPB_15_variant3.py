
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        a = np.asarray(a).flatten()
        b = np.asarray(b)
        if b.ndim == 1:
            if b.shape[0] != a.shape[0]:
                raise KeyError("length mismatch")
            na = np.linalg.norm(a)
            nb = np.linalg.norm(b)
            if na == 0 or nb == 0:
                return 1.0
            return float(1.0 - np.tensordot(a, b, axes=1) / (na * nb))
        elif b.ndim == 2:
            # prefer rows-as-vectors if possible
            if b.shape[1] == a.shape[0]:
                dots = np.tensordot(b, a, axes=([1], [0]))  # shape (n_rows,)
                na = np.linalg.norm(a)
                nbs = np.linalg.norm(b, axis=1)
                denom = na * nbs
                sims = np.zeros_like(dots, dtype=float)
                mask = denom != 0
                sims[mask] = dots[mask] / denom[mask]
                return 1.0 - sims
            elif b.shape[0] == a.shape[0]:
                dots = np.tensordot(a, b, axes=([0], [0]))  # shape (n_cols,)
                na = np.linalg.norm(a)
                nbs = np.linalg.norm(b, axis=0)
                denom = na * nbs
                sims = np.zeros_like(dots, dtype=float)
                mask = denom != 0
                sims[mask] = dots[mask] / denom[mask]
                return 1.0 - sims
            else:
                raise KeyError("length mismatch")
        else:
            raise KeyError("b must be 1D or 2D")
