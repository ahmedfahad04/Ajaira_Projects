
def interpolate_features(features,:
    import numpy as np
    def interpolate_features(features,
                             input_rate,
                             output_rate,
                             output_len):
        features = np.asarray(features, dtype=np.float64)
        if features.size == 0:
            return np.zeros((output_len,) + features.shape[1:], dtype=features.dtype)
        was_1d = features.ndim == 1
        if was_1d:
            feats = features.reshape(-1, 1)
        else:
            feats = features
        n = feats.shape[0]
        # compute fractional positions in input by mapping times
        output_times = np.arange(output_len) / float(output_rate)
        input_times = np.arange(n) / float(input_rate)
        # find right index via searchsorted
        idx = np.searchsorted(input_times, output_times, side='left')
        # clamp idx
        idx = np.clip(idx, 1, n - 1)
        left = idx - 1
        right = idx
        # compute weights based on actual times
        left_t = input_times[left]
        right_t = input_times[right]
        denom = (right_t - left_t)
        # avoid division by zero
        denom[denom == 0] = 1.0
        w_right = (output_times - left_t) / denom
        w_left = 1.0 - w_right
        out = (w_left[:, None] * feats[left]) + (w_right[:, None] * feats[right])
        if was_1d:
            return out.ravel().astype(features.dtype)
        return out.astype(features.dtype)
