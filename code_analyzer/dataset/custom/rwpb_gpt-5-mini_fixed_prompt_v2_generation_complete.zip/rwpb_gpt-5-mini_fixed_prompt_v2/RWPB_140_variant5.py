
def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
    from typing import Callable, Dict, Tuple, Any
    import inspect
    from functools import partial
    def get_args_for_func(func: Callable, params: Dict) -> Tuple[Callable, Dict[str, Any]]:
        params = dict(params or {})
        try:
            sig = inspect.signature(func)
        except (ValueError, TypeError):
            return partial(func), {}
        # Collect parameter names that can be provided as keywords
        keywordable = []
        for name, p in sig.parameters.items():
            if p.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY):
                keywordable.append(name)
            # skip POSITIONAL_ONLY and VAR_POSITIONAL
        keywordable_set = set(keywordable)
        # If accepts **kwargs, allow all
        if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()):
            matched = dict(params)
        else:
            matched = {k: v for k, v in params.items() if k in keywordable_set}
        return partial(func, **matched), matched
