
def check(x, checksum_token):
    import re
    import hashlib
    def check(x, checksum_token):
        it = list(re.finditer(r'[0-9a-fA-F]{64}', x))
        if not it:
            return False
        for m in it:
            original = m.group(0)
            replaced = x[:m.start()] + checksum_token + x[m.end():]
            if hashlib.sha256(replaced.encode('utf-8')).hexdigest().lower() == original.lower():
                return True
        return False
