
def fovx_to_fovy(fovx, aspect):
    import math
    def fovx_to_fovy(fovx, aspect):
        if aspect <= 0:
            raise ValueError("aspect must be positive")
        # compute tan through sin/cos to avoid direct overflow when cos is tiny
        half = 0.5 * float(fovx)
        sin_h = math.sin(half)
        cos_h = math.cos(half)
        if cos_h == 0.0:
            # half angle is pi/2 or -pi/2, tan infinite -> result tends to pi for positive aspect
            return math.pi if aspect > 0 else -math.pi
        half_tx = sin_h / cos_h
        half_ty = half_tx / float(aspect)
        return 2.0 * math.atan(half_ty)
