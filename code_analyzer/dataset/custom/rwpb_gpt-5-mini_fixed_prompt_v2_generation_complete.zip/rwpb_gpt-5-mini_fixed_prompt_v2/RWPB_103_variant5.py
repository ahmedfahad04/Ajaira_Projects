
def unsafeAdd(x, y):
    MAX_VAL = (1 << 256) - 1
    def unsafeAdd(x, y):
        mask = MAX_VAL
        a = x & mask
        b = y & mask
        carry = 0
        res = 0
        for i in range(32):
            ai = (a >> (i * 8)) & 0xFF
            bi = (b >> (i * 8)) & 0xFF
            s = ai + bi + carry
            res |= ((s & 0xFF) << (i * 8))
            carry = s >> 8
        return res & mask
