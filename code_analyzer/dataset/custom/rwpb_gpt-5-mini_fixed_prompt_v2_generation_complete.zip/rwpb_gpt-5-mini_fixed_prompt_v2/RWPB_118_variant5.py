
def filter_nan(ts, vs):
    import numpy as np
    def filter_nan(ts, vs):
        ts = np.asarray(ts)
        vs = np.asarray(vs)
        bad_idx = np.where(np.isnan(ts) | np.isnan(vs))[0]
        if bad_idx.size == 0:
            return ts, vs
        return np.delete(ts, bad_idx), np.delete(vs, bad_idx)
