
def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
    import numpy as np
    def pad_tokens(tokens: np.ndarray, context_window: int, pad_token: int) -> np.ndarray:
        target = context_window + 1
        arr = np.asarray(tokens, dtype=object)
        # handle list-of-sequences or 1D sequence
        if arr.ndim == 0:
            out = np.full(target, pad_token)
            return np.array(out)
        if arr.ndim == 1 and (arr.dtype == object or isinstance(arr[0], (list, tuple, np.ndarray))):
            rows = []
            for seq in arr:
                seq = np.asarray(seq)
                if seq.size >= target:
                    rows.append(seq[:target].astype(int))
                else:
                    padded = np.concatenate([seq.astype(int), np.full(target - seq.size, pad_token, dtype=int)])
                    rows.append(padded)
            return np.vstack(rows)
        # fallback for regular numeric 1D/2D arrays
        arr = np.asarray(tokens)
        if arr.ndim == 1:
            if arr.shape[0] >= target:
                return arr[:target]
            return np.concatenate([arr, np.full(target - arr.shape[0], pad_token, dtype=arr.dtype)])
        # 2D
        out = []
        for row in arr:
            if row.shape[0] >= target:
                out.append(row[:target])
            else:
                out.append(np.concatenate([row, np.full(target - row.shape[0], pad_token, dtype=row.dtype)]))
        return np.vstack(out)
