
def unpad_image_shape(current_height, current_width, original_size):
    from fractions import Fraction
    def unpad_image_shape(current_height, current_width, original_size):
        ow, oh = original_size
        if ow <= 0 or oh <= 0 or current_width <= 0 or current_height <= 0:
            return (current_height, current_width)
        # compare using fractions for exactness
        orig_frac = Fraction(ow, oh)
        cur_frac = Fraction(current_width, current_height)
        if orig_frac == cur_frac:
            return (current_height, current_width)
        if orig_frac > cur_frac:
            # width is limiting: scale = current_width / ow
            num, den = current_width, ow
            # nearest integer rounding: (value * num/den) rounded
            new_h = (oh * num + den // 2) // den
            new_h = max(1, min(current_height, int(new_h)))
            return (int(new_h), current_width)
        else:
            num, den = current_height, oh
            new_w = (ow * num + den // 2) // den
            new_w = max(1, min(current_width, int(new_w)))
            return (current_height, int(new_w))
