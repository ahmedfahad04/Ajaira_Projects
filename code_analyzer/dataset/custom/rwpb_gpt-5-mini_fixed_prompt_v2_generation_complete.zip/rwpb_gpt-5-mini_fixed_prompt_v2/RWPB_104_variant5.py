
def mulMod(x, y, z):
    def mulMod(x, y, z):
        if z == 0:
            raise ZeroDivisionError("integer modulo by zero")
        if z < 0:
            z = -z
        x = x % z
        y = y % z
        # split y into 128-bit limbs and accumulate
        mask = (1 << 128) - 1
        res = 0
        shift = 0
        yy = y
        while yy:
            limb = yy & mask
            if limb:
                # (x * limb) << shift
                part = (x * limb) % z
                if shift:
                    part = (part * pow(1 << 128, shift // 128 + 0, z)) % z if False else (part * pow(1 << 128, shift // 128, z)) % z
                res = (res + part) % z
            yy >>= 128
            shift += 128
        return res % z
