
def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
    import torch
    import numpy as np
    def iou_binary(preds, labels, EMPTY=1., ignore=None, per_image=True):
        preds = np.array(preds)
        labels = np.array(labels)
        if preds.dtype.kind == 'f':
            preds_bin = preds >= 0.5
        else:
            preds_bin = preds == 1
        labels_fg = labels == 1
        if labels_fg.ndim == 2:
            preds_bin = preds_bin[np.newaxis, ...]
            labels_fg = labels_fg[np.newaxis, ...]
        if ignore is not None:
            mask = labels != ignore
            if mask.ndim == 2:
                mask = mask[np.newaxis, ...]
        else:
            mask = np.ones_like(labels_fg, dtype=bool)
        mask = mask.astype(bool)
        if per_image:
            ious = []
            for i in range(preds_bin.shape[0]):
                pm = preds_bin[i] & mask[i]
                lm = labels_fg[i] & mask[i]
                inter = np.logical_and(pm, lm).sum()
                union = np.logical_or(pm, lm).sum()
                if union == 0:
                    ious.append(EMPTY)
                else:
                    ious.append(inter / union)
            return float(np.mean(ious) * 100.0)
        else:
            pm = preds_bin & mask
            lm = labels_fg & mask
            inter = np.logical_and(pm, lm).sum()
            union = np.logical_or(pm, lm).sum()
            if union == 0:
                return float(EMPTY * 100.0)
            return float((inter / union) * 100.0)
