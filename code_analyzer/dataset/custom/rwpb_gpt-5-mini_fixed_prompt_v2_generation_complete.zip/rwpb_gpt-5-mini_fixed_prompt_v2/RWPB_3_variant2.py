
def get_focalLength_from_fieldOfView(fov=60, img_size=512):
    import math
    def get_focalLength_from_fieldOfView(fov=60, img_size=512):
        if fov <= 0 or fov >= 180:
            raise ValueError("fov must be between 0 and 180 degrees (exclusive).")
        # convert degrees to radians
        theta = math.radians(fov) / 2.0
        # focal = (image_half) / tan(theta)
        focal = (img_size / 2.0) / math.tan(theta)
        return float(focal)
