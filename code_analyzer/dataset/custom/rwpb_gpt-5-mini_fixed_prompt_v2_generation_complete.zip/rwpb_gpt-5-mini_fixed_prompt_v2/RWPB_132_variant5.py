
def B_batch(x, grid, k=0, extend=True, device="cpu"):
    import torch
    import numpy as np
    def B_batch(x, grid, k=0, extend=True, device="cpu"):
        # implement using numpy computation then convert back to torch
        x_t = x.to(device)
        grid_t = grid.to(device)
        S, N = x_t.shape
        _, m = grid_t.shape
        p = int(k)
        if m < 2:
            n_bases = max(0, m + p - 1)
            return torch.zeros((S, n_bases, N), device=device, dtype=x_t.dtype)
        x_np = x_t.cpu().numpy()
        grid_np = grid_t.cpu().numpy()
        out = np.zeros((S, m + p - 1, N), dtype=float)
        for s in range(S):
            g = grid_np[s]
            xs = x_np[s]
            if extend:
                left = g[1] - g[0]
                right = g[-1] - g[-2]
                pre = g[0] - np.arange(p,0,-1) * (left if left != 0 else 1.0)
                post = g[-1] + np.arange(1,p+1) * (right if right != 0 else 1.0)
            else:
                pre = np.array([g[0]]*p)
                post = np.array([g[-1]]*p)
            T = np.concatenate([pre, g, post])
            n_T = len(T)
            # degree-0
            B = np.zeros((n_T-1, N), dtype=float)
            for i in range(n_T-1):
                left = T[i]; right = T[i+1]
                B[i,:] = ((xs >= left) & (xs < right)).astype(float)
            # endpoint include
            eq_idx = np.isclose(xs, T[-1])
            if eq_idx.any():
                B[-1, eq_idx] = 1.0
            for r in range(1, p+1):
                new_len = n_T - 1 - r
                B_new = np.zeros((new_len, N), dtype=float)
                for i in range(new_len):
                    denom1 = T[i+r] - T[i]
                    denom2 = T[i+r+1] - T[i+1]
                    if denom1 != 0:
                        B_new[i] += ((xs - T[i]) / denom1) * B[i]
                    if denom2 != 0:
                        B_new[i] += ((T[i+r+1] - xs) / denom2) * B[i+1]
                B = B_new
            out[s,:,:] = B[:m+p-1,:]
        return torch.from_numpy(out).to(device=device, dtype=x_t.dtype)
