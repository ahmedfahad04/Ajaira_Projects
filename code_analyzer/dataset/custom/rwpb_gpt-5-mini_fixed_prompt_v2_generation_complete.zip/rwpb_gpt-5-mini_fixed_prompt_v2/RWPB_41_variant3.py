
def merge_short_sentences_en(sens):
    from collections import deque
    def merge_short_sentences_en(sens):
        """Use a deque and iterative front-merging. Short defined as <=3 words.
        If the final remaining short sentence has no follower, it will be merged
        into the previous one."""
        if not sens:
            return []
        dq = deque(s.strip() for s in sens)
        out = []
        while dq:
            cur = dq.popleft()
            if len(cur.split()) <= 3 and dq:
                # combine with next and push back to front
                nxt = dq.popleft()
                combined = (cur + ' ' + nxt).strip()
                dq.appendleft(combined)
            else:
                out.append(cur)
        # if last output is short, merge with previous
        if len(out) >= 2 and len(out[-1].split()) <= 3:
            out[-2] = (out[-2] + ' ' + out[-1]).strip()
            out.pop()
        return out
