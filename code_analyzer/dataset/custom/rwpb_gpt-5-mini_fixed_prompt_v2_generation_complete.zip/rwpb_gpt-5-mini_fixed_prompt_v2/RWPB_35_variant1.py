
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        items = {}
        for k, v in d.items():
            key = f"{parent_key}{sep}{k}" if parent_key else str(k)
            if isinstance(v, dict):
                items.update(flatten_dict(v, key, sep=sep))
            else:
                items[key] = v
        return items
