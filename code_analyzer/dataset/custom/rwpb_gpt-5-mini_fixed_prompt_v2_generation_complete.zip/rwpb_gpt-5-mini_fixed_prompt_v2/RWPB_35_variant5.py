
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        def helper(node, path):
            if isinstance(node, dict):
                if not node:
                    return {}
                acc = {}
                for k, v in node.items():
                    acc.update(helper(v, path + [str(k)]))
                return acc
            else:
                return {sep.join(path): node}
        start_path = [parent_key] if parent_key else []
        return helper(d, start_path)
