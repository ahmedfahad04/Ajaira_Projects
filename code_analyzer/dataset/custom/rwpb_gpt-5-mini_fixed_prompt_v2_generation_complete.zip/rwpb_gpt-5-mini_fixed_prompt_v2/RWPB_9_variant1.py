
def is_byte_token(s: str) -> bool:
    import re
    _pattern = re.compile(r'^<0x[0-9A-Fa-f]{2}>$')
    def is_byte_token(s: str) -> bool:
        if not isinstance(s, str):
            return False
        return bool(_pattern.fullmatch(s))
