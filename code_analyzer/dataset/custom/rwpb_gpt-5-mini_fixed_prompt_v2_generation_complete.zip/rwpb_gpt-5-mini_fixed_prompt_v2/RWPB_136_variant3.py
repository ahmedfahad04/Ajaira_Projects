
def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
    import torch
    def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
        eps = 1e-8
        v0 = v0.clone()
        v1 = v1.clone()
        n0 = v0.norm(dim=-1, keepdim=True).clamp_min(eps)
        n1 = v1.norm(dim=-1, keepdim=True).clamp_min(eps)
        u0 = v0 / n0
        dot = (u0 * v1).sum(dim=-1, keepdim=True) / n1
        dot = dot.clamp(-1.0, 1.0)
        flip = (dot < 0.0)
        dot = torch.where(flip, -dot, dot)
        u1 = torch.where(flip.expand_as(v1), -v1 / n1, v1 / n1)
        theta = torch.acos(dot)
        sin_theta = torch.sin(theta)
        t_tensor = torch.tensor(t, dtype=theta.dtype, device=theta.device)
        near = (1.0 - dot) < (1.0 - DOT_THRESHOLD)
        s0 = torch.sin((1.0 - t_tensor) * theta) / (sin_theta + eps)
        s1 = torch.sin(t_tensor * theta) / (sin_theta + eps)
        s0 = torch.where(near, 1.0 - t_tensor, s0)
        s1 = torch.where(near, t_tensor, s1)
        out_unit = s0 * u0 + s1 * u1
        out = out_unit * ((1.0 - t_tensor) * n0 + t_tensor * n1)
        return out
