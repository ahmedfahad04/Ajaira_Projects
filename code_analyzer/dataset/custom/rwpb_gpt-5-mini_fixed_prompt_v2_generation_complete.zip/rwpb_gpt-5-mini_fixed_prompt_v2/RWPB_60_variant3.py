
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        # brute-force row-wise computation by reshaping to 2D and looping
        if upcast:
            orig_dtype = x.dtype
            x = x.to(torch.float32)
            weight = weight.to(torch.float32) if weight is not None else None
            bias = bias.to(torch.float32) if bias is not None else None
            residual = residual.to(torch.float32) if residual is not None else None
        orig_shape = x.shape
        D = orig_shape[-1]
        flat = x.reshape(-1, D)
        out_flat = torch.empty_like(flat)
        for i in range(flat.size(0)):
            row = flat[i]
            mean_sq = (row * row).sum() / float(D)
            denom = (mean_sq + eps) ** 0.5
            out_flat[i] = row / denom
        out = out_flat.reshape(*orig_shape)
        if weight is not None:
            if weight.dim() == 1:
                w = weight.view(*([1] * (x.dim() - 1)), -1)
            else:
                w = weight
            out = out * w
        if bias is not None:
            if bias.dim() == 1:
                b = bias.view(*([1] * (x.dim() - 1)), -1)
            else:
                b = bias
            out = out + b
        if residual is not None:
            out = out + residual
        if upcast:
            out = out.to(orig_dtype)
        if prenorm:
            return out, x
        return out
