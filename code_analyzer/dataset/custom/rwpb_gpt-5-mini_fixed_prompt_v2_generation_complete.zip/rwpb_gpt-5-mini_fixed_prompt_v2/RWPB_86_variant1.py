
def inverse_sigmoid(x):
    import torch
    def inverse_sigmoid(x):
        x = torch.as_tensor(x)
        if not torch.is_floating_point(x):
            x = x.float()
        eps = torch.finfo(x.dtype).eps
        x_clamped = torch.clamp(x, min=eps, max=1 - eps)
        return torch.log(x_clamped / (1 - x_clamped))
