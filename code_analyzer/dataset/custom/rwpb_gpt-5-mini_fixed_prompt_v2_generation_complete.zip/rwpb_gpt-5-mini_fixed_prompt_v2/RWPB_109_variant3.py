
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        B, N, C = geometry.shape
        if C != 3:
            raise ValueError("geometry last dim must be 3")
        out = geometry.new_empty(B, N, 3)
        for b in range(B):
            out[b] = geometry[b].mm(rot[b].t()) + trans[b].unsqueeze(0)
        return out
