
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    from typing import List
    from itertools import islice, chain
    def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be a non-negative integer")
        # Use iterators to slice/truncate then chain pads if needed
        it = iter(ls)
        if max_seq_length == 0:
            result = []
        else:
            if len(ls) >= max_seq_length:
                if pad_right:
                    result = list(islice(it, max_seq_length))
                else:
                    # take last max_seq_length elements
                    result = list(islice(iter(ls[-max_seq_length:]), max_seq_length))
            else:
                # need padding
                if pad_right:
                    result = list(ls) + [pad_idx] * (max_seq_length - len(ls))
                else:
                    result = [pad_idx] * (max_seq_length - len(ls)) + list(ls)
        if check and len(result) != max_seq_length:
            raise ValueError("Result length does not equal max_seq_length")
        return result
