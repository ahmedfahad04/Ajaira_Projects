
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    def generate_grids(lower_limit, upper_limit, grid_size):
        lower_limit = lower_limit.clone().to(dtype=torch.get_default_dtype())
        upper_limit = upper_limit.clone().to(dtype=torch.get_default_dtype())
        if lower_limit.dim() == 0:
            lower_limit = lower_limit.unsqueeze(0)
        if upper_limit.dim() == 0:
            upper_limit = upper_limit.unsqueeze(0)
        D = lower_limit.numel()
        if torch.is_tensor(grid_size):
            if grid_size.dim() == 0:
                gs = [int(grid_size.item())] * D
            else:
                gs = [int(x.item()) for x in grid_size.view(-1)]
        else:
            gs = [int(grid_size)] * D
        steps = (upper_limit - lower_limit) / torch.tensor(gs, dtype=lower_limit.dtype)
        per_dim_lowers = []
        for i in range(D):
            if gs[i] <= 0:
                per_dim_lowers.append(torch.tensor([], dtype=lower_limit.dtype))
            else:
                per_dim_lowers.append(lower_limit[i] + torch.arange(gs[i], dtype=lower_limit.dtype) * steps[i])
        if D == 0:
            return torch.empty((0,0), dtype=lower_limit.dtype), torch.empty((0,0), dtype=lower_limit.dtype)
        grid = torch.cartesian_prod(*per_dim_lowers) if D > 0 else torch.empty((0, D), dtype=lower_limit.dtype)
        lower = grid
        upper = lower + steps.unsqueeze(0)
        return lower, upper
