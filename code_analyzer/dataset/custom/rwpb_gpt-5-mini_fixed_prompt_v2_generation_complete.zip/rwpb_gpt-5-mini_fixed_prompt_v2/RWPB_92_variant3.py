
def round(number, num_decimal_places, leave_int=False):
    def round(number, num_decimal_places, leave_int=False):
        """
        String-formatting based rounding using Python's formatting (round-half-even).
        """
        n = int(num_decimal_places)
        # handle non-numeric edge cases by attempting conversion
        try:
            # If it's an int and leave_int True and n >= 0, can return immediately
            if isinstance(number, int) and leave_int and n >= 0:
                return number
            # Use format to create rounded representation
            if n >= 0:
                fmt = "{:." + str(n) + "f}"
                s = fmt.format(number)
                val = float(s)
            else:
                # negative decimals -> round to tens/hundreds
                factor = 10 ** (-n)
                val = float("{:.0f}".format(number / factor)) * factor
            if leave_int:
                if val == int(val):
                    return int(val)
            return val
        except Exception:
            # fallback to builtin behavior
            val = float(number)
            if leave_int and val == int(val):
                return int(val)
            return val
