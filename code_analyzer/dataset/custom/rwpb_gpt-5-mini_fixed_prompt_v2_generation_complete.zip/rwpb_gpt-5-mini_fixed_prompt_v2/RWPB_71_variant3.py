
def getLambertCoefs(numOfLambertCoefs):
    from math import factorial
    from fractions import Fraction
    def getLambertCoefs(numOfLambertCoefs):
        if numOfLambertCoefs <= 0:
            return []
        coefs = [Fraction(0, 1)]
        for n in range(1, numOfLambertCoefs):
            coefs.append(Fraction((-n) ** (n - 1), factorial(n)))
        if numOfLambertCoefs == 1:
            return coefs[:1]
        return coefs
