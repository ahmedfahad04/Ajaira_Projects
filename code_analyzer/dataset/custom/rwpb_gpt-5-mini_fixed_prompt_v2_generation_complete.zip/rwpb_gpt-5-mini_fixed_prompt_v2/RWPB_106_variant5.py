
def interpolate_features(features,:
    import numpy as np
    def interpolate_features(features,
                             input_rate,
                             output_rate,
                             output_len):
        features = np.asarray(features)
        if features.size == 0:
            return np.zeros((output_len,) + features.shape[1:], dtype=features.dtype)
        orig_shape = features.shape
        is_1d = features.ndim == 1
        if is_1d:
            feats = features.reshape(-1, 1).astype(np.float64)
        else:
            feats = features.astype(np.float64)
        n = feats.shape[0]
        # Build sparse-like interpolation matrix with two non-zero per row
        scale = float(input_rate) / float(output_rate)
        positions = (np.arange(output_len).astype(np.float64)) * scale
        positions = np.clip(positions, 0, n - 1)
        left = np.floor(positions).astype(int)
        right = np.minimum(left + 1, n - 1)
        w = positions - left
        # Construct weight matrix W of shape (output_len, n) but only store two columns per row
        # Compute result by accumulating into output
        out = np.zeros((output_len, feats.shape[1]), dtype=np.float64)
        np.add.at(out, np.arange(output_len), (1.0 - w)[:, None] * feats[left])
        np.add.at(out, np.arange(output_len), (w)[:, None] * feats[right])
        if is_1d:
            return out.ravel().astype(features.dtype)
        return out.astype(features.dtype)
