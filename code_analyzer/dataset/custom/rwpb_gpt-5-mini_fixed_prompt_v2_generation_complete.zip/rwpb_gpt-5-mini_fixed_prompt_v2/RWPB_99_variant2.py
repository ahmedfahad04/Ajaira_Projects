
def focal2fov(focal, pixels):
    import math
    def focal2fov(focal, pixels):
        try:
            fx = float(focal)
            px = float(pixels)
            # This will raise ZeroDivisionError if focal is zero
            return 2.0 * math.atan(px / (2.0 * fx))
        except ZeroDivisionError:
            return KeyError
