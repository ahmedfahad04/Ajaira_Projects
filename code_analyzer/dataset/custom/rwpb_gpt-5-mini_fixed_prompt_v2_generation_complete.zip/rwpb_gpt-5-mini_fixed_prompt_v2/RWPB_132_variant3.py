
def B_batch(x, grid, k=0, extend=True, device="cpu"):
    import torch
    from functools import lru_cache
    def B_batch(x, grid, k=0, extend=True, device="cpu"):
        x = x.to(device)
        grid = grid.to(device)
        S, N = x.shape
        _, m = grid.shape
        p = int(k)
        out = torch.zeros((S, max(0, m + p - 1), N), device=device, dtype=x.dtype)
        for s in range(S):
            g = grid[s].cpu().numpy().astype(float)
            xs = x[s].cpu().numpy().astype(float)
            if m < 2:
                continue
            # build T as python list
            if extend:
                left = g[1] - g[0]
                right = g[-1] - g[-2]
                pre = [g[0] - i * left for i in range(p, 0, -1)]
                post = [g[-1] + i * right for i in range(1, p+1)]
            else:
                pre = [g[0]] * p
                post = [g[-1]] * p
            T = pre + g.tolist() + post
            n_T = len(T)
            n_bases = max(0, m + p - 1)
            @lru_cache(maxsize=None)
            def B_ij(i, r, xi):
                # r = degree level (0..p), xi is index into xs
                xval = xs[xi]
                if r == 0:
                    left = T[i]
                    right = T[i+1]
                    if (xval >= left and xval < right) or (i == n_T - 2 and abs(xval - T[-1]) < 1e-12):
                        return 1.0
                    else:
                        return 0.0
                denom1 = T[i + r] - T[i]
                denom2 = T[i + r + 1] - T[i + 1]
                left_term = 0.0
                right_term = 0.0
                if denom1 != 0:
                    left_term = ((xval - T[i]) / denom1) * B_ij(i, r-1, xi)
                if denom2 != 0:
                    right_term = ((T[i + r + 1] - xval) / denom2) * B_ij(i+1, r-1, xi)
                return left_term + right_term
            for i in range(n_bases):
                vals = [B_ij(i, p, xi) for xi in range(N)]
                out[s, i] = torch.tensor(vals, device=device, dtype=x.dtype)
        return out
