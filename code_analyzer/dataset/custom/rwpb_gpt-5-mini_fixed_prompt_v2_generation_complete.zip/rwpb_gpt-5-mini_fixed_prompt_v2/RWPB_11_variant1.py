
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    from typing import List
    def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be a non-negative integer")
        seq = list(ls)  # copy to avoid mutating input
        n = len(seq)
        if n > max_seq_length:
            # truncate: keep left part if padding on right, else keep right part
            if pad_right:
                seq = seq[:max_seq_length]
            else:
                seq = seq[-max_seq_length:] if max_seq_length > 0 else []
        elif n < max_seq_length:
            pad_len = max_seq_length - n
            pads = [pad_idx] * pad_len
            seq = seq + pads if pad_right else pads + seq
        if check and len(seq) != max_seq_length:
            raise ValueError("Result length does not equal max_seq_length")
        return seq
