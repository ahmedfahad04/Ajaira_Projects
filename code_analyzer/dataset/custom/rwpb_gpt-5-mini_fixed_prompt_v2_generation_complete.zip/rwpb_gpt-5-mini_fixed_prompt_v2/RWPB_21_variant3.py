
def validate_user_id(user_id):
    def validate_user_id(user_id):
        if not isinstance(user_id, str):
            return False
        if not user_id:
            return False
        first = user_id[0]
        if not first.isalpha():
            return False
        for ch in user_id[1:]:
            if not (ch.isalnum() or ch == '_'):
                return False
        return True
