
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        if divisor is None:
            raise ValueError("divisor must be provided")
        # Handle torch tensor divisor by taking its max
        if torch.is_tensor(divisor):
            d_val = divisor.max().item()
        else:
            d_val = divisor
        if d_val == 0:
            raise ValueError("divisor must be non-zero")
        d = int(abs(int(d_val)))
        # nearest multiple by rounding quotient
        q = float(x) / d
        nearest = round(q) * d
        return int(nearest)
