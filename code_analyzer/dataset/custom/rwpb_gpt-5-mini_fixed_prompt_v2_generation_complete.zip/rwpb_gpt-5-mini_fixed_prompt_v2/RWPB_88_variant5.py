
def rotate_y(a, device=None):
    import torch
    def rotate_y(a, device=None):
        a_t = torch.as_tensor(a)
        if device is not None:
            a_t = a_t.to(device)
        c = torch.cos(a_t)
        s = torch.sin(a_t)
        dtype = a_t.dtype
        dev = None if device is None else torch.device(device)
        row0 = torch.stack([c, torch.tensor(0., dtype=dtype, device=dev), s, torch.tensor(0., dtype=dtype, device=dev)])
        row1 = torch.stack([torch.tensor(0., dtype=dtype, device=dev), torch.tensor(1., dtype=dtype, device=dev), torch.tensor(0., dtype=dtype, device=dev), torch.tensor(0., dtype=dtype, device=dev)])
        row2 = torch.stack([-s, torch.tensor(0., dtype=dtype, device=dev), c, torch.tensor(0., dtype=dtype, device=dev)])
        row3 = torch.stack([torch.tensor(0., dtype=dtype, device=dev), torch.tensor(0., dtype=dtype, device=dev), torch.tensor(0., dtype=dtype, device=dev), torch.tensor(1., dtype=dtype, device=dev)])
        return torch.stack([row0, row1, row2, row3])
