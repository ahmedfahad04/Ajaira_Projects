
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        arr = np.asarray(image)
        if arr.ndim == 2:
            proc = np.expand_dims(arr, 0)
        elif arr.ndim == 3:
            proc = np.rollaxis(arr, 2, 0)
        else:
            raise ValueError("Invalid image: expected 2D or 3D numpy array.")
        proc = proc.astype(np.float32) / 255.0
        return torch.as_tensor(proc, dtype=torch.float32)
