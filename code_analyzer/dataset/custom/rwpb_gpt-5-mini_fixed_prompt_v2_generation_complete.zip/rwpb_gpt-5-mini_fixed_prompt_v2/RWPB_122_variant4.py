
def view_range(x, i, j, shape):
    import torch
    def view_range(x, i, j, shape):
        ndim = x.dim()
        if j is None:
            j = ndim
        # normalize negatives
        if i < 0:
            i = ndim + i
        if j < 0:
            j = ndim + j
        i = max(0, min(i, ndim))
        j = max(0, min(j, ndim))
        if i > j:
            raise ValueError("i must be <= j")
        # compute products
        left = x.shape[:i]
        mid = x.shape[i:j]
        right = x.shape[j:]
        mid_prod = 1
        for d in mid:
            mid_prod *= d
        # allow tuple or list for shape
        target = list(shape)
        # infer -1 if present
        neg_count = target.count(-1)
        if neg_count > 1:
            raise ValueError("Only one -1 allowed in shape")
        if neg_count == 1:
            known = 1
            for s in target:
                if s != -1:
                    known *= s
            if known == 0 or mid_prod % known != 0:
                raise ValueError("Cannot infer -1 dimension")
            target = [ (mid_prod // known) if s == -1 else s for s in target ]
        prod = 1
        for s in target:
            prod *= s
        if prod != mid_prod:
            raise ValueError("Product mismatch")
        # build final shape
        final_shape = tuple(left) + tuple(target) + tuple(right)
        # use torch.reshape to handle non-contiguous tensors
        return torch.reshape(x, final_shape)
