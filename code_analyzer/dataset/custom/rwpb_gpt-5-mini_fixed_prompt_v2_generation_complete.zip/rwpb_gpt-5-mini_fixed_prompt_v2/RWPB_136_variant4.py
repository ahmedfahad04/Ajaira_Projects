
def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
    import torch
    def slerp(v0: torch.Tensor, v1: torch.Tensor, t: float, DOT_THRESHOLD: float = 0.9995) -> torch.Tensor:
        eps = 1e-10
        n0 = v0.norm(dim=-1, keepdim=True).clamp_min(eps)
        n1 = v1.norm(dim=-1, keepdim=True).clamp_min(eps)
        u0 = v0 / n0
        dot = (u0 * v1).sum(dim=-1, keepdim=True) / n1
        dot = dot.clamp(-1.0, 1.0)
        negate = (dot < 0)
        u1 = torch.where(negate.expand_as(v1), -v1 / n1, v1 / n1)
        dot = torch.where(negate, -dot, dot)
        orth = u1 - dot * u0
        orth_norm = orth.norm(dim=-1, keepdim=True).clamp_min(eps)
        orth_unit = orth / orth_norm
        theta = torch.acos(dot)
        t_tensor = torch.tensor(t, dtype=theta.dtype, device=theta.device)
        small = (theta.abs() < 1e-6).squeeze(-1)
        cos_term = torch.cos(theta * t_tensor).unsqueeze(-1)
        sin_term = torch.sin(theta * t_tensor).unsqueeze(-1)
        out_unit = cos_term * u0 + sin_term * orth_unit
        out = out_unit * ((1.0 - t_tensor) * n0 + t_tensor * n1)
        if small.any():
            linear = ((1.0 - t_tensor) * v0 + t_tensor * v1)
            out = torch.where(small.view(*([1] * (out.dim() - 1) + [1])), linear, out)
        return out
