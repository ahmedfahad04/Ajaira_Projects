
def interpolate_features(features,:
    import numpy as np
    def interpolate_features(features,
                             input_rate,
                             output_rate,
                             output_len):
        features = np.asarray(features)
        if features.size == 0:
            return np.zeros((output_len,) + features.shape[1:], dtype=features.dtype)
        orig_shape = features.shape
        is_1d = features.ndim == 1
        if is_1d:
            feats = features.reshape(-1, 1)
        else:
            feats = features
        n = feats.shape[0]
        # times in seconds for original and desired
        input_times = np.arange(n) / float(input_rate)
        output_times = np.arange(output_len) / float(output_rate)
        # np.interp works on 1D arrays; do each column
        out = np.empty((output_len, feats.shape[1]), dtype=feats.dtype)
        for d in range(feats.shape[1]):
            out[:, d] = np.interp(output_times, input_times, feats[:, d])
        if is_1d:
            return out.ravel()
        return out
