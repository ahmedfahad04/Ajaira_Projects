
def rotate_x(a, device=None):
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        # Build rows explicitly with torch tensors
        dev = torch.device(device) if device is not None else None
        # ensure scalar
        if isinstance(a, (list, tuple, np.ndarray)):
            # pick first element if list/array scalar-like
            a_val = float(np.array(a).ravel()[0])
        elif isinstance(a, torch.Tensor):
            a_val = float(a.cpu().numpy())
        else:
            a_val = float(a)
        c = np.cos(a_val)
        s = np.sin(a_val)
        row0 = torch.tensor([1.0, 0.0, 0.0, 0.0], dtype=torch.float64, device=dev)
        row1 = torch.tensor([0.0, c, -s, 0.0], dtype=torch.float64, device=dev)
        row2 = torch.tensor([0.0, s,  c, 0.0], dtype=torch.float64, device=dev)
        row3 = torch.tensor([0.0, 0.0, 0.0, 1.0], dtype=torch.float64, device=dev)
        return torch.stack([row0, row1, row2, row3], dim=0)
