
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        if repetition_penalty == 1.0:
            return logits
        if not torch.is_tensor(logits):
            logits = torch.tensor(logits)
        batch_size, vocab_size = logits.shape
        rp = float(repetition_penalty)
        # modify in-place for efficiency
        for b in range(batch_size):
            prev = prev_output_tokens[b]
            if prev.numel() == 0:
                continue
            unique_tokens = torch.unique(prev)
            for token in unique_tokens:
                idx = int(token.item())
                val = logits[b, idx]
                if val > 0:
                    logits[b, idx] = val / rp
                else:
                    logits[b, idx] = val * rp
        return logits
