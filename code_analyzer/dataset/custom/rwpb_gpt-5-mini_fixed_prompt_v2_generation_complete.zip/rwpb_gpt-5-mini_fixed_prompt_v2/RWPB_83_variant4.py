
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        if not isinstance(sample, dict):
            return (size[0], size[1])
        image = sample.get("image", None)
        disp = sample.get("disparity", None)
        mask = sample.get("mask", None)
        # determine reference dimensions
        for ref in (image, disp, mask):
            if ref is not None:
                h, w = ref.shape[:2]
                break
        else:
            return (size[0], size[1])
        min_h, min_w = int(size[0]), int(size[1])
        if h >= min_h and w >= min_w:
            return (h, w)
        scale = max(min_h / h, min_w / w)
        new_h = int(max(min_h, math.ceil(h * scale)))
        new_w = int(max(min_w, math.ceil(w * scale)))
        if image is not None:
            sample["image"] = cv2.resize(image, (new_w, new_h), interpolation=image_interpolation_method)
        if disp is not None:
            orig_dtype = disp.dtype
            disp_f = disp.astype(np.float32)
            disp_res = cv2.resize(disp_f, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            disp_res = disp_res * (new_w / float(w))  # adjust disparity by horizontal scaling (consistent)
            if np.issubdtype(orig_dtype, np.integer):
                sample["disparity"] = np.rint(disp_res).astype(orig_dtype)
            else:
                sample["disparity"] = disp_res.astype(orig_dtype)
        if mask is not None:
            mask_res = cv2.resize(mask, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            if mask_res.dtype != mask.dtype:
                if mask.dtype == np.uint8:
                    mask_res = (mask_res > 0).astype(np.uint8) * 255
                elif mask.dtype == bool:
                    mask_res = (mask_res > 0)
            sample["mask"] = mask_res.astype(mask.dtype)
        return (new_h, new_w)
