
def euler2rot(euler_angle):
    import torch
    def euler2rot(euler_angle):
        if not isinstance(euler_angle, torch.Tensor):
            euler_angle = torch.tensor(euler_angle)
        if euler_angle.dim() == 1:
            euler_angle = euler_angle.unsqueeze(0)
        B = euler_angle.shape[0]
        device = euler_angle.device
        dtype = euler_angle.dtype
        R_batch = torch.empty((B, 3, 3), device=device, dtype=dtype)
        for i in range(B):
            rx, ry, rz = euler_angle[i]
            cx = torch.cos(rx).item(); sx = torch.sin(rx).item()
            cy = torch.cos(ry).item(); sy = torch.sin(ry).item()
            cz = torch.cos(rz).item(); sz = torch.sin(rz).item()
            r00 = cz * cy
            r01 = cz * sy * sx - sz * cx
            r02 = cz * sy * cx + sz * sx
            r10 = sz * cy
            r11 = sz * sy * sx + cz * cx
            r12 = sz * sy * cx - cz * sx
            r20 = -sy
            r21 = cy * sx
            r22 = cy * cx
            R_batch[i, 0, 0] = r00
            R_batch[i, 0, 1] = r01
            R_batch[i, 0, 2] = r02
            R_batch[i, 1, 0] = r10
            R_batch[i, 1, 1] = r11
            R_batch[i, 1, 2] = r12
            R_batch[i, 2, 0] = r20
            R_batch[i, 2, 1] = r21
            R_batch[i, 2, 2] = r22
        return R_batch
