
def merge_dicts_recursively(*dicts):
    from copy import deepcopy
    from collections.abc import Mapping
    def merge_dicts_recursively(*dicts):
        dicts = [d for d in dicts if isinstance(d, Mapping)]
        if not dicts:
            return {}
        result = deepcopy(dicts[-1])
        for d in reversed(dicts[:-1]):
            for k, v in d.items():
                if k in result and isinstance(result[k], Mapping) and isinstance(v, Mapping):
                    result[k] = merge_dicts_recursively(v, result[k])
                elif k not in result:
                    result[k] = deepcopy(v)
        return result
