
def unpad_image_shape(current_height, current_width, original_size):
    def unpad_image_shape(current_height, current_width, original_size):
        ow, oh = original_size
        # guard against invalid originals
        if ow <= 0 or oh <= 0 or current_width <= 0 or current_height <= 0:
            return (current_height, current_width)
        orig_ar = ow / oh
        cur_ar = current_width / current_height
        if abs(orig_ar - cur_ar) < 1e-12:
            return (current_height, current_width)
        if orig_ar > cur_ar:
            # original is wider -> width was fit, compute new height
            scale = current_width / ow
            new_h = int(round(oh * scale))
            new_h = max(1, min(current_height, new_h))
            return (new_h, current_width)
        else:
            # original is taller -> height was fit, compute new width
            scale = current_height / oh
            new_w = int(round(ow * scale))
            new_w = max(1, min(current_width, new_w))
            return (current_height, new_w)
