
def seconds_to_hh_mm_ss(seconds):
    def seconds_to_hh_mm_ss(seconds):
        """
        Converts a given number of seconds to a string in hh:mm:ss format.
        Args:
            seconds: An integer representing the number of seconds.
        Returns:
            A string in hh:mm:ss format, or "00:00:00" if seconds is negative.
        """
        try:
            total = int(seconds)
        except Exception:
            return "00:00:00"
        if total < 0:
            return "00:00:00"
        hours = total // 3600
        minutes = (total % 3600) // 60
        secs = total % 60
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
