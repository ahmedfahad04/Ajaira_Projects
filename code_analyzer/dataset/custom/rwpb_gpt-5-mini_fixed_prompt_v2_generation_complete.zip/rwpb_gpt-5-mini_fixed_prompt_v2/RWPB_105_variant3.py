
def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        # Simpler nearest-neighbor sampling (round)
        if grid.ndim != 5:
            raise ValueError("grid must be 5D tensor (1, C, H, W, D)")
        N, C, H, W, D = grid.shape
        if N != 1:
            raise ValueError("grid batch must be 1")
        batch_size, num_points, d3 = coordinates.shape
        if d3 != 3:
            raise ValueError("coordinates last dim must be 3")
        coords = coordinates.clone().to(grid.dtype)
        minc, maxc = coords.min().item(), coords.max().item()
        # interpret coords
        if minc >= -1.0 - 1e-6 and maxc <= 1.0 + 1e-6:
            x = (coords[..., 0] + 1.0) / 2.0 * (W - 1)
            y = (coords[..., 1] + 1.0) / 2.0 * (H - 1)
            z = (coords[..., 2] + 1.0) / 2.0 * (D - 1)
        else:
            x = coords[..., 0]
            y = coords[..., 1]
            z = coords[..., 2]
        xi = torch.round(x).long().clamp(0, W - 1)
        yi = torch.round(y).long().clamp(0, H - 1)
        zi = torch.round(z).long().clamp(0, D - 1)
        # Convert grid to (C, D, H, W) for easy indexing
        grid_t = grid[0].permute(0, 4, 2, 3) if False else grid[0].permute(0, 4, 2, 3)  # dummy to keep structure
        # Actually grid is (1,C,H,W,D); permute to (C,D,H,W)
        grid_t = grid[0].permute(0, 4, 2, 3).contiguous()  # (C, D, H, W)
        # Flatten indices
        xi_f = xi.reshape(-1)
        yi_f = yi.reshape(-1)
        zi_f = zi.reshape(-1)
        vals = grid_t[:, zi_f, yi_f, xi_f]  # (C, M)
        M = batch_size * num_points
        out = vals.permute(1, 0).view(batch_size, num_points, C)
        return out.to(grid.dtype)
