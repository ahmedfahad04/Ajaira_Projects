
def unsafeAdd(x, y):
    MAX_VAL = (1 << 256) - 1
    MOD = MAX_VAL + 1
    def unsafeAdd(x, y):
        s = x + y
        if 0 <= s <= MAX_VAL:
            return s
        return s % MOD
