
def generate_grids(lower_limit, upper_limit, grid_size):
    import torch
    import math
    from functools import reduce
    import operator
    def generate_grids(lower_limit, upper_limit, grid_size):
        low = lower_limit.clone().to(dtype=torch.get_default_dtype())
        high = upper_limit.clone().to(dtype=torch.get_default_dtype())
        if low.dim() == 0:
            low = low.unsqueeze(0)
        if high.dim() == 0:
            high = high.unsqueeze(0)
        D = low.numel()
        if torch.is_tensor(grid_size):
            if grid_size.dim() == 0:
                gs = [int(grid_size.item())] * D
            else:
                gs = [int(x.item()) for x in grid_size.view(-1)]
        else:
            gs = [int(grid_size)] * D
        steps = (high - low) / torch.tensor(gs, dtype=low.dtype)
        total = 1
        for g in gs:
            total *= max(0, g)
        if total == 0:
            return torch.empty((0,D), dtype=low.dtype), torch.empty((0,D), dtype=low.dtype)
        idxs = []
        suffix_products = []
        for i in range(D):
            prod = 1
            for j in range(i+1, D):
                prod *= gs[j]
            suffix_products.append(prod)
        for i in range(D):
            n = gs[i]
            rep = suffix_products[i] if suffix_products[i] > 0 else 1
            tile = int(total // (rep * n))
            base = torch.arange(n, dtype=torch.long)
            expanded = torch.repeat_interleave(base, rep)
            if tile > 0:
                expanded = expanded.repeat(tile)
            idxs.append(expanded)
        indices = torch.stack(idxs, dim=1).to(dtype=low.dtype)
        lowers = low.unsqueeze(0) + indices * steps.unsqueeze(0)
        uppers = lowers + steps.unsqueeze(0)
        return lowers, uppers
