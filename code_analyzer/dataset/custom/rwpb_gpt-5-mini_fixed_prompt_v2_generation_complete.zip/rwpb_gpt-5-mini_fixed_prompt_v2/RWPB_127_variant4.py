
def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
    import torch
    def shift_dim(x, src_dim=-1, dest_dim=-1, make_contiguous=True):
        """
        Construct permutation with slice concatenation depending on relative positions.
        """
        if not isinstance(x, torch.Tensor):
            raise TypeError("x must be a torch.Tensor")
        nd = x.dim()
        if nd == 0:
            return x.contiguous() if make_contiguous else x
        src = src_dim + nd if src_dim < 0 else src_dim
        dest = dest_dim + nd if dest_dim < 0 else dest_dim
        if not (0 <= src < nd) or not (0 <= dest < nd):
            raise IndexError("src_dim or dest_dim out of range")
        if src == dest:
            return x.contiguous() if make_contiguous else x
        if src < dest:
            perm = list(range(0, src)) + list(range(src+1, dest+1)) + [src] + list(range(dest+1, nd))
        else:
            perm = list(range(0, dest)) + [src] + list(range(dest, src)) + list(range(src+1, nd))
        out = x.permute(*perm)
        return out.contiguous() if make_contiguous else out
