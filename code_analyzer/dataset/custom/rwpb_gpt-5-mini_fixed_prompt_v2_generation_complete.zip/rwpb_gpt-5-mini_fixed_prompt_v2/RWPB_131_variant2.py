
def box_iou(box1, box2, eps=1e-7):
    import torch
    import numpy as np
    def box_iou(box1, box2, eps=1e-7):
        if not torch.is_tensor(box1):
            box1 = torch.tensor(box1)
        if not torch.is_tensor(box2):
            box2 = torch.tensor(box2)
        box1 = box1.float()
        box2 = box2.float()
        N = box1.shape[0]
        M = box2.shape[0]
        if N == 0 or M == 0:
            return torch.zeros((N, M), dtype=box1.dtype, device=box1.device)
        b1 = box1[:, None, :].expand(N, M, 4)
        b2 = box2[None, :, :].expand(N, M, 4)
        max_xy = torch.min(b1[..., 2:], b2[..., 2:])
        min_xy = torch.max(b1[..., :2], b2[..., :2])
        inter = (max_xy - min_xy).clamp(min=0)
        inter_area = inter[..., 0] * inter[..., 1]
        area1 = ((box1[:, 2] - box1[:, 0]).clamp(min=0) * (box1[:, 3] - box1[:, 1]).clamp(min=0))[:, None]
        area2 = ((box2[:, 2] - box2[:, 0]).clamp(min=0) * (box2[:, 3] - box2[:, 1]).clamp(min=0))[None, :]
        union = area1 + area2 - inter_area
        iou = inter_area / (union + eps)
        return iou
