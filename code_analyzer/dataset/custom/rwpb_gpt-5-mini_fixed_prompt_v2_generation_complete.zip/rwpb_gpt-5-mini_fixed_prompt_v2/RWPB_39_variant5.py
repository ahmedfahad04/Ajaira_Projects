
def clean_html(:
    import re
    from typing import List
    def clean_html(
            html_to_clean: str,
            tags_to_remove: List[str] = ["style", "svg", "script"],
            attributes_to_keep: List[str] = ["id", "href"],
    ) -> str:
        text = html_to_clean or ""
        remove = set([t.lower() for t in (tags_to_remove or [])])
        keep = set([a.lower() for a in (attributes_to_keep or [])])
        parts = re.split(r'(<[^>]+>)', text, flags=re.S)
        out = []
        stack = []
        tagname_re = re.compile(r'^<\s*(/)?\s*([^\s>/]+)', re.I)
        attr_re = re.compile(r'([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^>\s]+)))?')
        for token in parts:
            if not token:
                continue
            if token[0] != '<':
                if not stack:
                    out.append(token)
                continue
            if token.startswith('<!--') or token.startswith('<!'):
                if not stack:
                    out.append(token)
                continue
            m = tagname_re.match(token)
            if not m:
                if not stack:
                    out.append(token)
                continue
            closing = bool(m.group(1))
            name = m.group(2).lower()
            self_closing = token.rstrip().endswith('/>')
            if not closing and name in remove:
                if not self_closing:
                    stack.append(name)
                continue
            if closing and stack:
                if stack and stack[-1] == name:
                    stack.pop()
                continue
            if stack:
                continue
            if closing:
                out.append(f"</{m.group(2)}>")
                continue
            attrs_text = token[m.end(): -1].strip()
            if attrs_text.endswith('/'):
                attrs_text = attrs_text[:-1].rstrip()
                self_closing = True
            kept_attrs = []
            for am in attr_re.finditer(attrs_text):
                an = am.group(1)
                av = am.group(2) if am.group(2) is not None else (am.group(3) if am.group(3) is not None else am.group(4))
                if an.lower() in keep:
                    if av is None:
                        kept_attrs.append(an)
                    else:
                        v = av.replace('"', '&quot;')
                        kept_attrs.append(f'{an}="{v}"')
            inner = (" " + " ".join(kept_attrs)) if kept_attrs else ""
            if self_closing:
                out.append(f"<{m.group(2)}{inner} />")
            else:
                out.append(f"<{m.group(2)}{inner}>")
        return "".join(out)
