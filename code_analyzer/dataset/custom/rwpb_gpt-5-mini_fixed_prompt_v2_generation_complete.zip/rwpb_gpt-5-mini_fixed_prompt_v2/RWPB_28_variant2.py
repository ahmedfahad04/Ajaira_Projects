
def mean(l, ignore_nan=False, empty=0):
    import numpy as np
    def mean(l, ignore_nan=False, empty=0):
        # Materialize the iterable into a numpy array of floats
        arr = np.array(list(l), dtype=float)
        if arr.size == 0:
            if empty == 'raise':
                raise ValueError("mean of empty sequence")
            return empty
        if ignore_nan:
            # If all are NaN, treat as empty
            if np.isnan(arr).all():
                if empty == 'raise':
                    raise ValueError("mean of empty sequence")
                return empty
            return float(np.nanmean(arr))
        else:
            # If any NaN present, mean should be NaN
            if np.isnan(arr).any():
                return float(np.nan)
            return float(arr.mean())
