
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        a = np.asarray(a)
        b = np.asarray(b)
        if a.ndim != 1:
            a = a.ravel()
        dim = a.shape[0]
        if b.ndim == 0:
            raise KeyError("b must be a vector or matrix")
        if b.ndim == 1:
            if b.shape[0] != dim:
                raise KeyError("length mismatch")
            na = np.linalg.norm(a)
            nb = np.linalg.norm(b)
            if na == 0 or nb == 0:
                return 1.0
            return float(1.0 - np.dot(a, b) / (na * nb))
        elif b.ndim == 2:
            # if rows match dim treat each row as vector, else if cols match treat columns
            if b.shape[1] == dim:
                B = b
                dots = B.dot(a)  # shape (n_rows,)
                na = np.linalg.norm(a)
                nbs = np.linalg.norm(B, axis=1)
                # avoid division by zero
                sims = np.zeros_like(dots, dtype=float)
                denom = na * nbs
                nonzero = denom != 0
                sims[nonzero] = dots[nonzero] / denom[nonzero]
                return 1.0 - sims
            elif b.shape[0] == dim:
                B = b
                dots = a.dot(B)  # shape (n_cols,)
                na = np.linalg.norm(a)
                nbs = np.linalg.norm(B, axis=0)
                sims = np.zeros_like(dots, dtype=float)
                denom = na * nbs
                nonzero = denom != 0
                sims[nonzero] = dots[nonzero] / denom[nonzero]
                return 1.0 - sims
            else:
                raise KeyError("length mismatch")
        else:
            raise KeyError("b must be 1D or 2D")
