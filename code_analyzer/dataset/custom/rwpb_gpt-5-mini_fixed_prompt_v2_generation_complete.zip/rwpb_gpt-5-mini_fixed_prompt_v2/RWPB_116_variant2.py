
def round_nearest_multiple(number, a, direction='standard'):
    import math
    def round_nearest_multiple(number, a, direction='standard'):
        if a == 0:
            raise ValueError("a must be non-zero")
        dir_lower = (direction or 'standard').lower()
        ratio = number / a
        if dir_lower == 'standard':
            if ratio >= 0:
                k = int(math.floor(ratio + 0.5))
            else:
                k = int(math.ceil(ratio - 0.5))
        elif dir_lower == 'down':
            k = int(math.floor(ratio))
        elif dir_lower == 'up':
            k = int(math.ceil(ratio))
        else:
            raise ValueError("direction must be 'standard', 'down' or 'up'")
        result = k * a
        s = format(a, 'f')
        if '.' in s:
            dec = len(s.split('.')[1].rstrip('0'))
        else:
            dec = 0
        fmt = f"{{0:.{dec}f}}"
        return float(fmt.format(result))
