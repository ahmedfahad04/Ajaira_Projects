
def cvimg2torch(img):
    def cvimg2torch(img):
        import numpy as np
        import torch
        if isinstance(img, (list, tuple)):
            arrs = [np.asarray(i) for i in img]
            proc = []
            for a in arrs:
                if a.ndim == 2:
                    a = a[..., None]
                if a.ndim != 3:
                    raise ValueError("Each item must be HxW or HxWxC")
                proc.append(a)
            batch = np.stack(proc, axis=0)
            batch = np.ascontiguousarray(batch.transpose(0, 3, 1, 2))
            return torch.from_numpy(batch).float().div(255.0)
        arr = np.asarray(img)
        if arr.ndim == 2:
            arr = arr[..., None]
        if arr.ndim == 3:
            out = np.ascontiguousarray(arr.transpose(2, 0, 1))[None, ...]
            return torch.from_numpy(out).float().div(255.0)
        if arr.ndim == 4:
            out = np.ascontiguousarray(arr.transpose(0, 3, 1, 2))
            return torch.from_numpy(out).float().div(255.0)
        raise ValueError("Unsupported input shape")
