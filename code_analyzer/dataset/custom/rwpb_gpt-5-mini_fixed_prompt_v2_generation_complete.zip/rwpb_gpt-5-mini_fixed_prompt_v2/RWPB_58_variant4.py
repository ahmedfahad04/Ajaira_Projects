
def unpad_image_shape(current_height, current_width, original_size):
    def unpad_image_shape(current_height, current_width, original_size):
        ow, oh = original_size
        if ow <= 0 or oh <= 0:
            return (current_height, current_width)
        # Find the largest uniform scale that keeps the image within current dims
        scale_w = current_width / ow
        scale_h = current_height / oh
        scale = min(scale_w, scale_h)
        # compute scaled dims, make sure they don't exceed current
        new_w = int((ow * scale) // 1)
        new_h = int((oh * scale) // 1)
        if new_w > current_width:
            new_w = current_width
        if new_h > current_height:
            new_h = current_height
        # If one dimension matches the padded dimension, return that pattern
        if new_w == current_width and new_h <= current_height:
            return (new_h if new_h >= 1 else 1, current_width)
        if new_h == current_height and new_w <= current_width:
            return (current_height, new_w if new_w >= 1 else 1)
        # Fallback: choose which side was limiting
        if scale == scale_w:
            return (max(1, new_h), current_width)
        else:
            return (current_height, max(1, new_w))
