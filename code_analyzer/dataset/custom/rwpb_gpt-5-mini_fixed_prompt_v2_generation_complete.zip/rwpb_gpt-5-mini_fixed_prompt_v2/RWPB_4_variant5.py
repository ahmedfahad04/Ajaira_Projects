
def rot6d_to_rotmat(x):
    def rot6d_to_rotmat(x):
        import torch
        if not torch.is_tensor(x):
            x = torch.tensor(x)
        if x.dim() != 2 or x.shape[1] != 6:
            raise ValueError("Input must have shape (B,6)")
        eps = 1e-8
        a1 = x[:, 0:3]
        a2 = x[:, 3:6]
        n1 = torch.linalg.norm(a1, dim=1, keepdim=True).clamp_min(eps)
        b1 = a1 / n1
        dot = (b1 * a2).sum(dim=1, keepdim=True)
        a2_orth = a2 - dot * b1
        n2 = torch.linalg.norm(a2_orth, dim=1, keepdim=True).clamp_min(eps)
        b2 = a2_orth / n2
        b3 = torch.cross(b1, b2, dim=1)
        R = torch.cat((b1.unsqueeze(2), b2.unsqueeze(2), b3.unsqueeze(2)), dim=2)
        return R
