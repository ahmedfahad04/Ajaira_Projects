
def movmean(arr, n_avg):
    import numpy as np
    def movmean(arr, n_avg):
        arr = np.asarray(arr)
        if n_avg <= 0 or arr.size == 0 or n_avg > arr.size:
            return np.array([])
        a = arr.ravel().astype(float)
        kernel = np.ones(n_avg, dtype=float) / float(n_avg)
        return np.convolve(a, kernel, mode='valid')
