
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    import math
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        original_h, original_w = original_size
        if not isinstance(tensor, torch.Tensor):
            tensor = torch.as_tensor(tensor)
        if tensor.ndim == 4:
            results = []
            for i in range(tensor.shape[0]):
                results.append(unpad_image(tensor[i], original_size))
            return torch.stack(results, dim=0)
        if tensor.ndim == 2:
            tensor = tensor.unsqueeze(0)
        C, H, W = tensor.shape
        if H == 0 or W == 0:
            return tensor
        target_ratio = original_h / original_w
        current_ratio = H / W
        if abs(current_ratio - target_ratio) < 1e-8:
            return tensor
        if current_ratio > target_ratio:
            exact_new_h = W * target_ratio
            new_h = max(1, int(math.floor(exact_new_h + 0.5)))
            pad_total = H - new_h
            top = math.ceil(pad_total / 2)
            bottom = pad_total - top
            start = top
            end = H - bottom
            return tensor[:, start:end, :]
        else:
            exact_new_w = H / target_ratio
            new_w = max(1, int(math.floor(exact_new_w + 0.5)))
            pad_total = W - new_w
            left = math.ceil(pad_total / 2)
            right = pad_total - left
            start = left
            end = W - right
            return tensor[:, :, start:end]
