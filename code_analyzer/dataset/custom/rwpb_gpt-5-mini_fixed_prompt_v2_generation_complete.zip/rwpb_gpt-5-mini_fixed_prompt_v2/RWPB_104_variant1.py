
def mulMod(x, y, z):
    def mulMod(x, y, z):
        if z == 0:
            raise ZeroDivisionError("integer modulo by zero")
        if z < 0:
            z = -z
        x = x % z
        y = y % z
        return (x * y) % z
