
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    import math
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.array(a, dtype=float)
        b = np.array(b, dtype=float)
        ax, ay, az = a[0], a[1], a[2]
        bx, by, bz = b[0], b[1], b[2]
        la = math.sqrt(ax*ax + ay*ay + az*az)
        lb = math.sqrt(bx*bx + by*by + bz*bz)
        if la == 0 or lb == 0:
            return (None, None)
        ax /= la; ay /= la; az /= la
        bx /= lb; by /= lb; bz /= lb
        dot = ax*bx + ay*by + az*bz
        dot = max(-1.0, min(1.0, dot))
        if dot > 1 - 1e-10:
            return (None, None)
        # cross product
        cx = ay*bz - az*by
        cy = az*bx - ax*bz
        cz = ax*by - ay*bx
        cn = math.sqrt(cx*cx + cy*cy + cz*cz)
        if cn < 1e-10:
            # opposite vectors: pick orthogonal axis
            # choose smallest absolute component to swap
            abs_a = [abs(ax), abs(ay), abs(az)]
            i = abs_a.index(min(abs_a))
            e = [0.0, 0.0, 0.0]
            e[i] = 1.0
            ex, ey, ez = e
            ox = ay*ez - az*ey
            oy = az*ex - ax*ez
            oz = ax*ey - ay*ex
            on = math.sqrt(ox*ox + oy*oy + oz*oz)
            axis = np.array([ox/on, oy/on, oz/on])
            return (axis, math.pi)
        axis = np.array([cx/cn, cy/cn, cz/cn])
        angle = math.acos(dot)
        return (axis, float(angle))
