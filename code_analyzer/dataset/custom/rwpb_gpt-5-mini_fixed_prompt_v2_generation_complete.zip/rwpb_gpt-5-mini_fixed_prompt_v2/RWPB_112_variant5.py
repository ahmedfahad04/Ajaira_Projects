
def submatrix(matrix, col):
    def submatrix(matrix, col):
        """
        Recursive approach: remove column from the first row then recurse on the rest.
        Assumes consistent column indexing across rows (rectangular matrix).
        """
        if not matrix:
            return []
        first, rest = matrix[0], matrix[1:]
        n = len(first)
        idx = col if col >= 0 else n + col
        if idx < 0 or idx >= n:
            raise IndexError("col index out of range")
        new_first = first[:idx] + first[idx+1:]
        return [new_first] + submatrix(rest, col)
