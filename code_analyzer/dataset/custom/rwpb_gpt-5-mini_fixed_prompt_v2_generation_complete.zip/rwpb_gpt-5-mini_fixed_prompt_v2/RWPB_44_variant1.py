
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        if not isinstance(tensor1, torch.Tensor) or not isinstance(tensor2, torch.Tensor):
            raise TypeError("Inputs must be torch.Tensor")
        if tensor1.shape != tensor2.shape:
            raise ValueError("Input tensors must have the same shape")
        if tensor1.numel() == 0:
            # preserve shape
            return tensor1.new_zeros((0,)+tensor1.shape[1:]), tensor2.new_zeros((0,)+tensor2.shape[1:])
        # stack along a new second dim then reshape to interleave
        rest = tensor1.shape[1:]
        stacked1 = torch.stack((tensor1, tensor2), dim=1).contiguous()
        stacked2 = torch.stack((tensor2, tensor1), dim=1).contiguous()
        out1 = stacked1.view(-1, *rest) if rest else stacked1.view(-1)
        out2 = stacked2.view(-1, *rest) if rest else stacked2.view(-1)
        return out1, out2
