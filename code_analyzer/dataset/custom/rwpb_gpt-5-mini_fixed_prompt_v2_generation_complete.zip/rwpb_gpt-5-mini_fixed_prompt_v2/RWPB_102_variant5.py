
def rotate_about_z_axis(vector, theta):
    import numpy as np
    def rotate_about_z_axis(vector, theta):
        """
        Use Rodrigues' rotation formula with axis k = (0,0,1).
        """
        v = np.asarray(vector, dtype=float).reshape(3,)
        k = np.array([0.0, 0.0, 1.0], dtype=float)
        cos_t = np.cos(theta)
        sin_t = np.sin(theta)
        v_cos = v * cos_t
        k_cross_v = np.cross(k, v) * sin_t
        k_dot_v = np.dot(k, v)
        v_par = k * k_dot_v * (1 - cos_t)
        return v_cos + k_cross_v + v_par
