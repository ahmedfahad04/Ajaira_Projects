
def fit_params(:
    def fit_params(
        x,
        y,
        fun,
        a_range=(-10, 10),
        b_range=(-10, 10),
        grid_number=101,
        iteration=3,
        verbose=True,
    ):
        import numpy as _np
        import torch as _torch
        is_torch = _torch.is_tensor(x) or _torch.is_tensor(y)
        if is_torch:
            x_np = _torch.flatten(x).detach().cpu().numpy()
            y_np = _torch.flatten(y).detach().cpu().numpy()
        else:
            x_np = _np.asarray(x).astype(float)
            y_np = _np.asarray(y).astype(float)
        # Full-grid vectorized over all (a,b) pairs per iteration
        a_lo, a_hi = float(a_range[0]), float(a_range[1])
        b_lo, b_hi = float(b_range[0]), float(b_range[1])
        def fit_cd_vectorized(Y, F):
            # Y: (n,), F: (n, m)
            Ym = Y.mean()
            Fm = F.mean(axis=0)
            num = ((Y[:, None] - Ym) * (F - Fm[None, :])).sum(axis=0)
            den = ((F - Fm[None, :]) ** 2).sum(axis=0)
            c = _np.zeros_like(den)
            d = _np.zeros_like(den)
            with _np.errstate(divide='ignore', invalid='ignore'):
                mask = (den != 0)
                c[mask] = num[mask] / den[mask]
                d = Ym - c * Fm
            preds = c[None, :] * F + d[None, :]
            ss_res = ((Y[:, None] - preds) ** 2).sum(axis=0)
            ss_tot = ((Y - Ym) ** 2).sum()
            r2 = _np.where(ss_tot == 0, _np.where(ss_res == 0, 1.0, 0.0), 1.0 - ss_res / ss_tot)
            return c, d, r2
        best = (None, None, None, None, -1e9)
        for it in range(iteration):
            a_vals = _np.linspace(a_lo, a_hi, grid_number)
            b_vals = _np.linspace(b_lo, b_hi, grid_number)
            A, B = _np.meshgrid(a_vals, b_vals, indexing='ij')
            As = A.ravel()
            Bs = B.ravel()
            # compute F for all pairs by forming (n, m) matrix
            m = As.size
            n = x_np.size
            F = _np.empty((n, m), dtype=float)
            for i in range(m):
                z = As[i] * x_np + Bs[i]
                try:
                    fz = fun(z)
                    if _torch.is_tensor(fz):
                        fz = fz.detach().cpu().numpy()
                except Exception:
                    fz = _np.array([fun(v) for v in z])
                F[:, i] = fz
            c_arr, d_arr, r2_arr = fit_cd_vectorized(y_np, F)
            idx = _np.argmax(r2_arr)
            a_best = As[idx]
            b_best = Bs[idx]
            c_best = float(c_arr[idx])
            d_best = float(d_arr[idx])
            r2_best = float(r2_arr[idx])
            if r2_best > best[4]:
                best = (a_best, b_best, c_best, d_best, r2_best)
            # refine window
            a_span = (a_hi - a_lo) / max(10.0, grid_number - 1)
            b_span = (b_hi - b_lo) / max(10.0, grid_number - 1)
            a_lo = a_best - a_span
            a_hi = a_best + a_span
            b_lo = b_best - b_span
            b_hi = b_best + b_span
        if verbose:
            print("r2 is", best[4])
        if is_torch:
            return (_torch.tensor(best[0]), _torch.tensor(best[1]), _torch.tensor(best[2]), _torch.tensor(best[3]), _torch.tensor(best[4]))
        else:
            return best[0], best[1], best[2], best[3], best[4]
