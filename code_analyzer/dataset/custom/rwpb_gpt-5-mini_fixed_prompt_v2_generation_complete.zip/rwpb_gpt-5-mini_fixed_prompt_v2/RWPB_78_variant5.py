
def check_all_columns_numeric(df):
    import pandas as pd
    def check_all_columns_numeric(df):
        if df is None:
            return False
        try:
            df.apply(lambda col: pd.to_numeric(col, errors='raise'))
            return True
        except Exception:
            return False
