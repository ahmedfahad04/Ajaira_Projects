
def psnr_to_mse(psnr):
    import numpy as np
    def psnr_to_mse(psnr):
        a = np.asarray(psnr)
        res = np.power(10.0, -a / 10.0)
        if np.isscalar(psnr):
            return float(res)
        return res
