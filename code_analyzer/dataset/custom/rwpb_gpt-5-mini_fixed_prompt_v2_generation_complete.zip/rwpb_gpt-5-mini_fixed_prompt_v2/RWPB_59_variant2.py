
def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
    import torch
    import torch.nn.functional as F
    def modify_logit_for_repetition_penalty(logits, prev_output_tokens, repetition_penalty=1.0):
        if repetition_penalty == 1.0:
            return logits
        rp = float(repetition_penalty)
        logits = logits.clone()
        batch_size, vocab_size = logits.shape
        # Build mask of shape (batch_size, vocab_size) indicating whether token appeared
        # Use one-hot and reduce
        if prev_output_tokens.numel() == 0:
            return logits
        one_hot = F.one_hot(prev_output_tokens.long(), num_classes=vocab_size)  # (batch, seq_len, vocab)
        mask = one_hot.any(dim=1)  # (batch, vocab)
        pos_mask = mask & (logits > 0)
        neg_mask = mask & (logits <= 0)
        logits = torch.where(pos_mask, logits / rp, logits)
        logits = torch.where(neg_mask, logits * rp, logits)
        return logits
