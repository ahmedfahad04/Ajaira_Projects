
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        B, N, _ = geometry.shape
        geom_flat = geometry.reshape(B * N, 3)
        rot_rep = rot.repeat_interleave(N, dim=0)
        geom_flat_reshaped = geom_flat.unsqueeze(1)
        rotated_flat = torch.bmm(geom_flat_reshaped, rot_rep.transpose(1, 2)).squeeze(1)
        rotated = rotated_flat.reshape(B, N, 3)
        trans_expanded = trans.unsqueeze(1).expand(B, N, 3)
        return rotated + trans_expanded
