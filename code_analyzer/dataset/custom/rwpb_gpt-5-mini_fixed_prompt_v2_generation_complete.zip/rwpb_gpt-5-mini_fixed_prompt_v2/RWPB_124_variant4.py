
def make_divisible(x, divisor):
    import math
    import torch
    def make_divisible(x, divisor):
        if divisor is None:
            raise ValueError("divisor must be provided")
        # If tensor divisor, use its max value; allow tensor or scalar
        if torch.is_tensor(divisor):
            d_val = float(divisor.max().item())
        else:
            d_val = float(divisor)
        if d_val == 0.0:
            raise ValueError("divisor must be non-zero")
        d = abs(d_val)
        # Use torch rounding when available for consistency
        try:
            xt = torch.tensor(float(x))
            dt = torch.tensor(d)
            nearest = torch.round(xt / dt) * dt
            return int(nearest.item())
        except Exception:
            # fallback
            q = float(x) / d
            return int(round(q) * d)
