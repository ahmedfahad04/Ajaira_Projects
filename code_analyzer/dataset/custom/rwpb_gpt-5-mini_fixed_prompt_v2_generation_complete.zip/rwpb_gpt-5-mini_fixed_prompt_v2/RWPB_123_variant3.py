
def fuse_deconv_and_bn(deconv, bn):
    import torch
    import torch.nn as nn
    def fuse_deconv_and_bn(deconv, bn):
        if not isinstance(deconv, nn.ConvTranspose2d) or not isinstance(bn, nn.BatchNorm2d):
            raise TypeError("Expected ConvTranspose2d and BatchNorm2d")
        device = deconv.weight.device
        dtype = deconv.weight.dtype
        out_ch = deconv.out_channels
        in_ch = deconv.in_channels
        groups = deconv.groups
        if bn.affine:
            gamma = bn.weight.detach().to(device=device, dtype=dtype)
            beta = bn.bias.detach().to(device=device, dtype=dtype)
        else:
            gamma = torch.ones(out_ch, device=device, dtype=dtype)
            beta = torch.zeros(out_ch, device=device, dtype=dtype)
        rm = bn.running_mean.detach().to(device=device, dtype=dtype)
        rv = bn.running_var.detach().to(device=device, dtype=dtype)
        eps = bn.eps
        scale = gamma / torch.sqrt(rv + eps)
        bias_old = deconv.bias.detach() if deconv.bias is not None else torch.zeros(out_ch, device=device, dtype=dtype)
        bias_new = beta + scale * (bias_old - rm)
        # Build scale map for weight shape (in_ch, out_ch//groups, KH, KW)
        out_per_group = out_ch // groups
        in_per_group = in_ch // groups
        # reshape scale into (groups, out_per_group)
        scale_groups = scale.view(groups, out_per_group)  # (g, out_per_group)
        # repeat each group row in proportion to input channels per group
        scale_map = scale_groups.repeat_interleave(in_per_group, dim=0)  # (in_ch, out_per_group)
        # expand to kernel dims
        w_old = deconv.weight.detach()
        w_new = w_old * scale_map.view(in_ch, out_per_group, 1, 1)
        fused = nn.ConvTranspose2d(
            in_channels=deconv.in_channels,
            out_channels=deconv.out_channels,
            kernel_size=deconv.kernel_size,
            stride=deconv.stride,
            padding=deconv.padding,
            output_padding=deconv.output_padding,
            groups=deconv.groups,
            dilation=deconv.dilation,
            bias=True
        ).to(device=device, dtype=dtype)
        fused.weight.data.copy_(w_new)
        fused.bias.data.copy_(bias_new)
        return fused
