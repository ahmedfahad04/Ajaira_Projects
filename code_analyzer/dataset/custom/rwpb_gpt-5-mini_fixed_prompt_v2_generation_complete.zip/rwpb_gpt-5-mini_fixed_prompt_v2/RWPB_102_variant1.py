
def rotate_about_z_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_z_axis(vector, theta):
        """
        Rotate a 3D vector about the z-axis by a specified angle using a rotation matrix.
        """
        v = np.asarray(vector, dtype=float).reshape(3,)
        c = math.cos(theta)
        s = math.sin(theta)
        R = np.array([[c, -s, 0.0],
                      [s,  c, 0.0],
                      [0.0, 0.0, 1.0]], dtype=float)
        return R.dot(v)
