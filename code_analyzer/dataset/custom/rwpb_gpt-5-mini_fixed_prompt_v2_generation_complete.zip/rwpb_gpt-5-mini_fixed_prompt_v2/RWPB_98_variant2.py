
def exp_smooth(vals, alpha):
    import numpy as np
    def exp_smooth(vals, alpha):
        a = np.asarray(vals)
        if a.size == 0:
            raise KeyError
        a = a.astype(float)
        n = a.shape[0]
        idx = np.arange(n)
        # build lower-triangular matrix of powers (1-alpha)^(t-i) for t>=i
        diff = idx[:, None] - idx[None, :]
        mask = diff >= 0
        W = np.zeros((n, n), dtype=float)
        W[mask] = (1.0 - alpha) ** diff[mask]
        a_excl = a.copy()
        a_excl[0] = 0.0
        result = (1.0 - alpha) ** idx * a[0] + alpha * (W.dot(a_excl))
        return result
