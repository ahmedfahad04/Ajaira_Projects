
def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
    import numpy as np
    import math
    def align_vector_to_another(a=np.array([0, 0, 1]), b=np.array([1, 0, 0])):
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na == 0 or nb == 0:
            return (None, None)
        ua = a / na
        ub = b / nb
        if np.allclose(ua, ub):
            return (None, None)
        cross = np.cross(ua, ub)
        cross_norm = np.linalg.norm(cross)
        dot = np.dot(ua, ub)
        # angle robust with atan2
        angle = math.atan2(cross_norm, np.clip(dot, -1.0, 1.0))
        if cross_norm < 1e-12:
            # opposite vectors -> choose perpendicular axis
            abs_ua = np.abs(ua)
            idx = int(np.argmin(abs_ua))
            tmp = np.zeros(3)
            tmp[idx] = 1.0
            axis = np.cross(ua, tmp)
            axis /= np.linalg.norm(axis)
            return (axis, float(np.pi))
        axis = cross / cross_norm
        return (axis, float(angle))
