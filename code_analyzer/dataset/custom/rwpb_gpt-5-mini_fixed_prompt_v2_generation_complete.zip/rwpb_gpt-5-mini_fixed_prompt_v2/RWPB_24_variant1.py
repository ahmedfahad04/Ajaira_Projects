
def check(x, checksum_token):
    import re
    import hashlib
    def check(x, checksum_token):
        m = re.search(r'[0-9a-fA-F]{64}', x)
        if not m:
            return False
        original = m.group(0)
        replaced = x[:m.start()] + checksum_token + x[m.end():]
        h = hashlib.sha256(replaced.encode('utf-8')).hexdigest()
        return h.lower() == original.lower()
