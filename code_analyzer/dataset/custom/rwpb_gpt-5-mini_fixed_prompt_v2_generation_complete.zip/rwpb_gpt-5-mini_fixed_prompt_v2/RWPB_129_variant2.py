
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        if not isinstance(masks, torch.Tensor):
            masks = torch.tensor(masks)
        if masks.ndim != 4:
            raise ValueError("masks must be (N, C, H, W)")
        N, C, Hm, Wm = masks.shape
        h, w = shape
        device = masks.device
        dtype = masks.dtype
        # Use nearest interpolation for binary-like masks by default, bilinear otherwise
        mode = 'nearest' if masks.dtype == torch.uint8 or masks.dtype == torch.bool else 'bilinear'
        if padding:
            s = max(h, w)
            x = masks.view(N * C, 1, Hm, Wm).to(dtype=torch.float32)
            x = F.interpolate(x, size=(s, s), mode=mode, align_corners=False if mode == 'bilinear' else None)
            x = x.view(N, C, s, s)
            top = (s - h) // 2
            left = (s - w) // 2
            out = x[:, :, top:top + h, left:left + w]
        else:
            x = masks.view(N * C, 1, Hm, Wm).to(dtype=torch.float32)
            out = F.interpolate(x, size=(h, w), mode=mode, align_corners=False if mode == 'bilinear' else None)
            out = out.view(N, C, h, w)
        if dtype == torch.bool:
            out = out > 0.5
        else:
            out = out.to(dtype)
        return out.to(device)
