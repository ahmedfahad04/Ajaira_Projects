
def is_byte_token(s: str) -> bool:
    import binascii
    def is_byte_token(s: str) -> bool:
        if not isinstance(s, str):
            return False
        if len(s) != 6 or not (s.startswith("<") and s.endswith(">")):
            return False
        inner = s[1:-1]
        if not inner[:2].lower() == "0x":
            return False
        hexpart = inner[2:]
        if len(hexpart) != 2:
            return False
        try:
            b = binascii.unhexlify(hexpart)
        except (binascii.Error, TypeError):
            return False
        return isinstance(b, (bytes, bytearray)) and len(b) == 1
