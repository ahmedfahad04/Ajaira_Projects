
def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def layer_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        original_x = x
        if upcast:
            x = x.float()
            if weight is not None:
                weight = weight.float()
            if bias is not None:
                bias = bias.float()
            if residual is not None:
                residual = residual.float()
        # compute mean and std using torch.mean and sqrt of variance computed via E[x^2]-E[x]^2
        mean = x.mean(dim=-1, keepdim=True)
        mean2 = (x * x).mean(dim=-1, keepdim=True)
        var = mean2 - mean * mean
        std = torch.sqrt(var + eps)
        normalized = (x - mean) / std
        if weight is not None:
            weight_shape = [1] * (x.dim() - 1) + [x.size(-1)]
            normalized = normalized * weight.view(*weight_shape)
        if bias is not None:
            bias_shape = [1] * (x.dim() - 1) + [x.size(-1)]
            normalized = normalized + bias.view(*bias_shape)
        if residual is not None:
            normalized = normalized + residual
        if prenorm:
            return normalized, original_x
        return normalized
