
def dynamic_import_function(function_path):
    from importlib import import_module, util
    def dynamic_import_function(function_path):
        """
        Use importlib.util.find_spec to validate module existence before import.
        Try progressive splits to locate a valid module and then walk attributes.
        """
        if not isinstance(function_path, str):
            return ModuleNotFoundError
        parts = function_path.split('.')
        if len(parts) < 2:
            return ModuleNotFoundError
        # try possible module splits (longest first)
        for i in range(len(parts)-1, 0, -1):
            module_name = '.'.join(parts[:i])
            attr_parts = parts[i:]
            try:
                spec = util.find_spec(module_name)
            except Exception:
                spec = None
            if spec is None:
                continue
            try:
                module = import_module(module_name)
            except Exception:
                continue
            obj = module
            ok = True
            for a in attr_parts:
                try:
                    obj = getattr(obj, a)
                except Exception:
                    ok = False
                    break
            if ok:
                return obj
        return ModuleNotFoundError
