
def interpolate_features(features,:
    import numpy as np
    def interpolate_features(features,
                             input_rate,
                             output_rate,
                             output_len):
        features = np.asarray(features)
        if features.size == 0:
            return np.zeros((output_len,) + features.shape[1:], dtype=features.dtype)
        # fast integer upsample/downsample when possible
        n = features.shape[0]
        if output_rate % input_rate == 0:
            factor = output_rate // input_rate
            if output_len == n * factor:
                return np.repeat(features, repeats=factor, axis=0)
        if input_rate % output_rate == 0:
            factor = input_rate // output_rate
            if output_len == n // factor:
                # average pooling
                trimmed = features[:(n // factor) * factor]
                newshape = (trimmed.shape[0] // factor, factor) + trimmed.shape[1:]
                resh = trimmed.reshape(newshape)
                return resh.mean(axis=1)
        # fallback: linear interpolation using times
        features = features.astype(np.float32)
        is_1d = features.ndim == 1
        if is_1d:
            feats = features.reshape(-1, 1)
        else:
            feats = features
        input_times = np.arange(feats.shape[0]) / float(input_rate)
        output_times = np.arange(output_len) / float(output_rate)
        out = np.empty((output_len, feats.shape[1]), dtype=feats.dtype)
        for i in range(feats.shape[1]):
            out[:, i] = np.interp(output_times, input_times, feats[:, i])
        return out.ravel() if is_1d else out
