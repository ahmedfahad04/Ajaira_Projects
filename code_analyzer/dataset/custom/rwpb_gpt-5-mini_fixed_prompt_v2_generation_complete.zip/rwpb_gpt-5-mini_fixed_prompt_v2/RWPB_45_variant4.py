
def invalid_to_zeros(arr, valid_mask, ndim=999):
    import torch
    def invalid_to_zeros(arr, valid_mask, ndim=999):
        if not isinstance(arr, torch.Tensor):
            raise TypeError("arr must be a torch.Tensor")
        if ndim != 999 and arr.dim() > ndim:
            keep = list(arr.shape[:ndim-1])
            prod = 1
            for s in arr.shape[ndim-1:]:
                prod *= s
            arr = arr.view(*keep, prod)
        if valid_mask is None:
            if arr.dim() >= 1:
                nnz = torch.tensor(arr.numel() // arr.shape[0], dtype=torch.long)
            else:
                nnz = torch.tensor(arr.numel(), dtype=torch.long)
            return arr, nnz
        mask = valid_mask
        if not isinstance(mask, torch.Tensor):
            mask = torch.tensor(mask, dtype=torch.bool, device=arr.device)
        mask = mask.bool().to(arr.device)
        if arr.dim() >= 1:
            B = arr.shape[0]
            arr_out = arr.clone()
            if mask.numel() == arr.numel():
                arr_out.view(-1)[~mask.view(-1)] = 0
                if B:
                    nnz = mask.view(B, -1).sum(dim=1)
                else:
                    nnz = torch.tensor(int(mask.sum().item()))
                return arr_out, nnz
            if mask.dim() == arr.dim() - 1 and mask.shape == arr.shape[:mask.dim()]:
                for i in range(B):
                    sel = mask[i].view(-1)
                    chunk = arr_out[i].view(-1)
                    if sel.numel() == chunk.numel():
                        chunk[~sel] = 0
                    else:
                        chunk[~sel] = 0
                    arr_out[i] = chunk.view(arr_out[i].shape)
                nnz = mask.view(B, -1).sum(dim=1)
                return arr_out, nnz
            if mask.numel() == B:
                for i in range(B):
                    if not bool(mask.view(-1)[i]):
                        arr_out[i].zero_()
                nnz = mask.view(B).to(torch.long)
                return arr_out, nnz
        # fallback
        try:
            m = mask.view(*mask.shape, *([1] * (arr.dim() - mask.dim())))
            arr = arr.clone()
            arr[~m.expand_as(arr)] = 0
            if m.shape[0] == arr.shape[0]:
                nnz = m.view(arr.shape[0], -1).sum(dim=1)
            else:
                nnz = torch.tensor(int(m.expand_as(arr).sum().item()))
            return arr, nnz
        except Exception:
            raise ValueError("Could not apply mask to array")
