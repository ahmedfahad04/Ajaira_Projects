
def unsafeSub(x, y):
    WORD = 1 << 256
    MAX_VAL = WORD - 1
    def unsafeSub(x, y):
        # compute difference and adjust if negative to simulate wraparound
        a = x & MAX_VAL
        b = y & MAX_VAL
        res = a - b
        if res < 0:
            res += WORD
        return res & MAX_VAL
