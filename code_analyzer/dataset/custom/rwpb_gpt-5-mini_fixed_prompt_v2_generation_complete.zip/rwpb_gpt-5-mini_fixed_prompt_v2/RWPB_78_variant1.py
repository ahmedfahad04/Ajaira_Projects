
def check_all_columns_numeric(df):
    import pandas as pd
    from pandas.api.types import is_numeric_dtype
    def check_all_columns_numeric(df):
        if df is None:
            return False
        if not hasattr(df, 'dtypes'):
            return False
        for col in df.columns:
            if not is_numeric_dtype(df[col].dtype):
                return False
        return True
