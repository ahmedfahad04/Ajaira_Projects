
def fit_params(:
    def fit_params(
        x,
        y,
        fun,
        a_range=(-10, 10),
        b_range=(-10, 10),
        grid_number=101,
        iteration=3,
        verbose=True,
    ):
        import numpy as _np
        import torch as _torch
        is_torch = _torch.is_tensor(x) or _torch.is_tensor(y)
        if is_torch:
            x_t = x if _torch.is_tensor(x) else _torch.tensor(x, dtype=_torch.get_default_dtype())
            y_t = y if _torch.is_tensor(y) else _torch.tensor(y, dtype=_torch.get_default_dtype())
        else:
            x_t = _np.asarray(x).astype(float)
            y_t = _np.asarray(y).astype(float)
        def to_output(a, b, c, d, r2):
            if is_torch:
                return (
                    _torch.tensor(a),
                    _torch.tensor(b),
                    _torch.tensor(c),
                    _torch.tensor(d),
                    _torch.tensor(r2),
                )
            else:
                return float(a), float(b), float(c), float(d), float(r2)
        # closed form linear fit for c,d: c = cov(y,f)/var(f), d = mean(y)-c*mean(f)
        def fit_cd(yv, fv):
            if is_torch:
                ym = fv.new_tensor(yv.mean()) if isinstance(yv, _torch.Tensor) else fv.new_tensor(_torch.tensor(yv).mean())
                fm = fv.mean()
                num = ((yv - ym) * (fv - fm)).sum()
                den = ((fv - fm) ** 2).sum()
                if den.abs() < 1e-12:
                    c = fv.new_tensor(0.0)
                    d = ym
                else:
                    c = num / den
                    d = ym - c * fm
                # r2
                ss_res = ((yv - (c * fv + d)) ** 2).sum()
                ss_tot = ((yv - ym) ** 2).sum()
                if ss_tot == 0:
                    r2 = 1.0 if ss_res == 0 else 0.0
                else:
                    r2 = 1.0 - (ss_res / ss_tot).item()
                return c.item() if not isinstance(c, float) else c, d.item() if not isinstance(d, float) else d, float(r2)
            else:
                ym = yv.mean()
                fm = fv.mean()
                num = ((yv - ym) * (fv - fm)).sum()
                den = ((fv - fm) ** 2).sum()
                if abs(den) < 1e-12:
                    c = 0.0
                    d = ym
                else:
                    c = num / den
                    d = ym - c * fm
                ss_res = ((yv - (c * fv + d)) ** 2).sum()
                ss_tot = ((yv - ym) ** 2).sum()
                if ss_tot == 0:
                    r2 = 1.0 if ss_res == 0 else 0.0
                else:
                    r2 = 1.0 - ss_res / ss_tot
                return c, d, float(r2)
        a_lo, a_hi = float(a_range[0]), float(a_range[1])
        b_lo, b_hi = float(b_range[0]), float(b_range[1])
        best = (None, None, None, None, -1e9)
        for it in range(iteration):
            a_vals = _np.linspace(a_lo, a_hi, grid_number)
            b_vals = _np.linspace(b_lo, b_hi, grid_number)
            # iterate over a and vectorize over b to reduce memory
            for a in a_vals:
                if is_torch:
                    a_t = _torch.tensor(a, dtype=x_t.dtype)
                    # compute matrix (n, nb)
                    xb = a_t * x_t.unsqueeze(-1) + _torch.tensor(b_vals, dtype=x_t.dtype).unsqueeze(0)
                    try:
                        F = fun(xb)
                    except Exception:
                        # fallback to elementwise
                        F = _torch.stack([fun(a_t * x_t + _torch.tensor(b, dtype=x_t.dtype)) for b in b_vals], dim=1)
                    # for each column compute c,d,r2
                    for j, b in enumerate(b_vals):
                        fv = F[:, j]
                        c, d, r2 = fit_cd(y_t, fv)
                        if r2 > best[4]:
                            best = (a, b, c, d, r2)
                else:
                    xb = a * x_t[:, None] + b_vals[None, :]
                    try:
                        F = fun(xb)
                    except Exception:
                        F = _np.column_stack([fun(a * x_t + b) for b in b_vals])
                    for j, b in enumerate(b_vals):
                        fv = F[:, j]
                        c, d, r2 = fit_cd(y_t, fv)
                        if r2 > best[4]:
                            best = (a, b, c, d, r2)
            # refine around best a,b
            a_best, b_best, c_best, d_best, r2_best = best
            a_span = (a_hi - a_lo) / max(10.0, grid_number - 1)
            b_span = (b_hi - b_lo) / max(10.0, grid_number - 1)
            a_lo = a_best - a_span
            a_hi = a_best + a_span
            b_lo = b_best - b_span
            b_hi = b_best + b_span
        if verbose:
            print("r2 is", best[4])
        return to_output(best[0], best[1], best[2], best[3], best[4])
