
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        # Use concatenation of per-element pairs built via unsqueeze and cat
        if not isinstance(tensor1, torch.Tensor) or not isinstance(tensor2, torch.Tensor):
            raise TypeError("Inputs must be torch.Tensor")
        if tensor1.shape != tensor2.shape:
            raise ValueError("Input tensors must have the same shape")
        if tensor1.numel() == 0:
            return tensor1.clone(), tensor2.clone()
        # Create (N,2,...) then reshape
        t1u = tensor1.unsqueeze(1)
        t2u = tensor2.unsqueeze(1)
        pair12 = torch.cat((t1u, t2u), dim=1).contiguous()
        pair21 = torch.cat((t2u, t1u), dim=1).contiguous()
        rest = tensor1.shape[1:]
        out1 = pair12.view(-1, *rest) if rest else pair12.view(-1)
        out2 = pair21.view(-1, *rest) if rest else pair21.view(-1)
        return out1, out2
