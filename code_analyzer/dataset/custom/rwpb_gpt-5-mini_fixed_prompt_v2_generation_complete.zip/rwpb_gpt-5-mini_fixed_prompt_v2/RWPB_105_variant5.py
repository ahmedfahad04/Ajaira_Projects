
def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
    import torch
    def sample_from_3dgrid(grid: torch.Tensor, coordinates: torch.Tensor) -> torch.Tensor:
        # Hybrid approach: decompose trilinear into three 1D linear interpolations for clarity
        if grid.ndim != 5:
            raise ValueError("grid must be 5D tensor (1, C, H, W, D)")
        _, C, H, W, D = grid.shape
        B, P, d3 = coordinates.shape
        if d3 != 3:
            raise ValueError("coordinates last dim must be 3")
        device = grid.device
        # Convert grid to (C, D, H, W)
        g = grid[0].permute(0, 4, 2, 3).contiguous()  # (C, D, H, W)
        coords = coordinates.clone().to(device).to(torch.float32)
        minc, maxc = coords.min().item(), coords.max().item()
        if minc >= -1.0 - 1e-6 and maxc <= 1.0 + 1e-6:
            x = (coords[..., 0] + 1.0) / 2.0 * (W - 1)
            y = (coords[..., 1] + 1.0) / 2.0 * (H - 1)
            z = (coords[..., 2] + 1.0) / 2.0 * (D - 1)
        else:
            x = coords[..., 0]
            y = coords[..., 1]
            z = coords[..., 2]
        # Flatten for processing
        x = x.reshape(-1)
        y = y.reshape(-1)
        z = z.reshape(-1)
        x0 = torch.floor(x).long().clamp(0, W - 1)
        x1 = (x0 + 1).clamp(0, W - 1)
        y0 = torch.floor(y).long().clamp(0, H - 1)
        y1 = (y0 + 1).clamp(0, H - 1)
        z0 = torch.floor(z).long().clamp(0, D - 1)
        z1 = (z0 + 1).clamp(0, D - 1)
        wx = (x - x0.float()).unsqueeze(0)
        wy = (y - y0.float()).unsqueeze(0)
        wz = (z - z0.float()).unsqueeze(0)
        # First interpolate along x for both y0/z0, y1/z0, y0/z1, y1/z1
        def get_vals(ix, iy, iz):
            return g[:, iz, iy, ix]  # (C, M)
        v000 = get_vals(x0, y0, z0)
        v100 = get_vals(x1, y0, z0)
        v010 = get_vals(x0, y1, z0)
        v110 = get_vals(x1, y1, z0)
        v001 = get_vals(x0, y0, z1)
        v101 = get_vals(x1, y0, z1)
        v011 = get_vals(x0, y1, z1)
        v111 = get_vals(x1, y1, z1)
        lx00 = v000 * (1 - wx) + v100 * wx
        lx10 = v010 * (1 - wx) + v110 * wx
        lx01 = v001 * (1 - wx) + v101 * wx
        lx11 = v011 * (1 - wx) + v111 * wx
        ly0 = lx00 * (1 - wy) + lx10 * wy
        ly1 = lx01 * (1 - wy) + lx11 * wy
        lz = ly0 * (1 - wz) + ly1 * wz  # (C, M)
        M = B * P
        out = lz.permute(1, 0).view(B, P, C)
        return out
