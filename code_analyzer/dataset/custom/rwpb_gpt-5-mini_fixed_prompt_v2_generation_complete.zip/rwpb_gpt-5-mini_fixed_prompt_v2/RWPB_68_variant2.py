
def last_before(val, arr):
    def last_before(val, arr):
        try:
            n = len(arr)
        except TypeError:
            arr = list(arr)
            n = len(arr)
        if n == 0:
            return -1
        lo = 0
        hi = n - 1
        ans = -1
        while lo <= hi:
            mid = (lo + hi) // 2
            if arr[mid] <= val:
                ans = mid
                lo = mid + 1
            else:
                hi = mid - 1
        return int(ans)
