
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        result = {}
        stack = [(parent_key, d)]
        while stack:
            base, cur = stack.pop()
            for k, v in cur.items():
                new_key = base + sep + str(k) if base else str(k)
                if isinstance(v, dict):
                    stack.append((new_key, v))
                else:
                    result[new_key] = v
        return result
