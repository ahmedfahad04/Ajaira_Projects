
def filter_nan(ts, vs):
    import numpy as np
    def filter_nan(ts, vs):
        ts = np.asarray(ts)
        vs = np.asarray(vs)
        mask = np.isfinite(ts) & np.isfinite(vs)
        return ts[mask], vs[mask]
