
def rank_accuracy(preds, references):
    def rank_accuracy(preds, references):
        from itertools import combinations
        if len(preds) != len(references):
            raise ValueError("Length mismatch")
        n = len(preds)
        if n < 2:
            return 0.0
        def sign(x):
            if x > 0:
                return 1
            if x < 0:
                return -1
            return 0
        pairs = combinations(range(n), 2)
        correct = 0
        total = 0
        for i, j in pairs:
            if sign(preds[i] - preds[j]) == sign(references[i] - references[j]):
                correct += 1
            total += 1
        return correct / total if total else 0.0
