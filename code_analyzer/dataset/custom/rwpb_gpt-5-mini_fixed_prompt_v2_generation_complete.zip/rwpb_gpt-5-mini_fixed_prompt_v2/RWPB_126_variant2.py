
def crop_mask(masks, boxes):
    import torch
    def crop_mask(masks, boxes):
        """
        Vectorized boolean mask built from meshgrid of coordinates.
        """
        if masks.ndim != 3:
            raise ValueError("masks must be [n, h, w]")
        n, H, W = masks.shape
        if boxes.shape[0] != n or boxes.shape[1] != 4:
            raise ValueError("boxes must be [n, 4]")
        device = masks.device
        # Pixel coordinate grids
        ys = torch.arange(H, device=device).view(1, H, 1).expand(n, H, W)
        xs = torch.arange(W, device=device).view(1, 1, W).expand(n, H, W)
        # Prepare integer inclusive bounds
        x1 = torch.floor(boxes[:, 0]).to(device).view(n, 1, 1)
        y1 = torch.floor(boxes[:, 1]).to(device).view(n, 1, 1)
        x2 = torch.ceil(boxes[:, 2]).to(device).view(n, 1, 1)
        y2 = torch.ceil(boxes[:, 3]).to(device).view(n, 1, 1)
        # Clamp
        x1 = x1.clamp(0, W - 1)
        y1 = y1.clamp(0, H - 1)
        x2 = x2.clamp(0, W - 1)
        y2 = y2.clamp(0, H - 1)
        # Create boolean inside-box mask: inclusive
        inside = (xs >= x1) & (xs <= x2) & (ys >= y1) & (ys <= y2)
        return masks * inside.to(masks.dtype)
