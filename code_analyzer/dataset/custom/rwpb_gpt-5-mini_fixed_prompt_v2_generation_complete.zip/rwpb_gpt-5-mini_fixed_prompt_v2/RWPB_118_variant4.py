
def filter_nan(ts, vs):
    import numpy as np
    def filter_nan(ts, vs):
        ts = np.asarray(ts)
        vs = np.asarray(vs)
        data = np.vstack((ts, vs))
        mask = np.isnan(data).any(axis=0)
        filtered = data[:, ~mask]
        if filtered.size == 0:
            return np.array([], dtype=ts.dtype), np.array([], dtype=vs.dtype)
        return filtered[0].copy(), filtered[1].copy()
