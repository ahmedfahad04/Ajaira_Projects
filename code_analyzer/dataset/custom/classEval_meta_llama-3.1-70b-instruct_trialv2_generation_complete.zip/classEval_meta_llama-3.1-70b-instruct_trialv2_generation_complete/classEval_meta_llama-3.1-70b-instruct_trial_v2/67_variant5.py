class Order:
    def __init__(self):
        self.menu = []
        self.selected_dishes = []
        self.sales = {}

    def add_dish(self, dish):
        for item in self.menu:
            if item["dish"] == dish["dish"] and item["price"] == dish["price"] and item["count"] >= dish["count"]:
                item["count"] -= dish["count"]
                self.selected_dishes.append({"dish": dish["dish"], "count": dish["count"], "price": dish["price"]})
                return True
        return False

    def calculate_total(self):
        total = sum(self.calculate_dish_total(dish) for dish in self.selected_dishes)
        return total

    def calculate_dish_total(self, dish):
        sales = self.sales.get(dish["dish"], 1)
        return dish["count"] * dish["price"] * sales

    def checkout(self):
        if self.selected_dishes:
            return self.calculate_total()
        return False