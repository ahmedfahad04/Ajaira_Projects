class BankAccount:
    """ This is a class as a bank account system, which supports deposit money, withdraw money, view balance, and transfer money. """
    def __init__(self, balance=0):
        """ Initializes a bank account object with an attribute balance, default value is 0. """
        self.balance = balance

    def deposit(self, amount):
        """ Deposits a certain amount into the account, increasing the account balance, return the current account balance. If amount is negative, raise a ValueError("Invalid amount"). :param amount: int """
        if amount < 0:
            raise ValueError("Invalid amount")
        self.balance += amount
        return self.balance

    def _perform_transaction(self, amount):
        if amount < 0 and abs(amount) > self.balance:
            raise ValueError("Insufficient balance.")
        if amount < 0:
            self.balance -= abs(amount)
        else:
            self.balance += amount
        return self.balance

    def withdraw(self, amount):
        """ Withdraws a certain amount from the account, decreasing the account balance, return the current account balance. If amount is negative, raise a ValueError("Invalid amount"). If the withdrawal amount is greater than the account balance, raise a ValueError("Insufficient balance."). :param amount: int """
        if amount < 0:
            raise ValueError("Invalid amount")
        return self._perform_transaction(-amount)

    def view_balance(self):
        """ Return the account balance. """
        return self.balance

    def transfer(self, other_account, amount):
        """ Transfers a certain amount from the current account to another account. :param other_account: BankAccount :param amount: int """
        self.withdraw(amount)
        other_account.deposit(amount)