def eat(number, need, remaining):
    # compute how many carrots remain hungry after stock is exhausted
    shortfall = max(0, need - remaining)
    consumed = need - shortfall
    return [number + consumed, remaining - consumed]