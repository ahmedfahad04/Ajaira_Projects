import math
def choose_num(x, y):
    if x > y:
        return -1
    L = math.ceil(x)
    U = math.floor(y)
    if U < L:
        return -1
    candidate = U if U % 2 == 0 else U - 1
    return candidate if candidate >= L else -1