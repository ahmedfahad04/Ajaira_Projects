from typing import List

def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    plen = len(prefix)
    result: List[str] = []
    for s in strings:
        if s[:plen] == prefix:
            result.append(s)
    return result

# Classification response:
# helper function extraction; for loop; accumulator list; list comprehension; slicing; temporary variable; standard library helper