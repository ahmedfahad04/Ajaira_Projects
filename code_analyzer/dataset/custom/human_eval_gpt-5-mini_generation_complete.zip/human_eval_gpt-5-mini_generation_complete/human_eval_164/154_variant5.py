import re
def cycpattern_check(a , b):
    if b == "":
        return True
    n = len(b)
    if n > len(a):
        return False
    bb = b + b
    parts = [re.escape(bb[i:i+n]) for i in range(n)]
    pattern = '|'.join(parts)
    return re.search(pattern, a) is not None