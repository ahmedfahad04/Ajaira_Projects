from typing import List

def remove_duplicates(numbers: List[int]) -> List[int]:
    return [x for x in numbers if numbers.count(x) == 1]

# Classification response:
# helper function extraction; function renaming; accumulator dict; temporary variable; builtin function; brute force; frequency counting