def make_a_pile(n):
    res = []
    current = n
    for _ in range(n):
        res.append(current)
        current += 2
    return res