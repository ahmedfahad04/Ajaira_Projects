def reverse_delete(s,c):
    table = {ord(ch): None for ch in c}
    res = s.translate(table)
    i, j = 0, len(res) - 1
    while i < j:
        if res[i] != res[j]:
            return res, False
        i += 1
        j -= 1
    return res, True