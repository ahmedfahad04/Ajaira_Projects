def double_the_difference(lst):
    from functools import reduce
    def acc(total, x):
        if isinstance(x, int) and not isinstance(x, bool) and x >= 0 and x % 2 != 0:
            return total + x*x
        return total
    return reduce(acc, lst, 0)