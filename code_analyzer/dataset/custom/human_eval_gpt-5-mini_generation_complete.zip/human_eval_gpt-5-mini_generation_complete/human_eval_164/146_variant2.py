def specialFilter(nums):
    odds = set("13579")
    cnt = 0
    for n in nums:
        if n > 10:
            s = str(abs(n))
            if s[0] in odds and s[-1] in odds:
                cnt += 1
    return cnt