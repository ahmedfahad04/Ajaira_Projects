def find_max(words):
    import heapq
    if not words:
        return ""
    heap = []
    for w in words:
        # want largest unique count, and if tie smallest lexicographic -> use (-count, word)
        heap.append((-len(set(w)), w))
    heapq.heapify(heap)
    return heapq.heappop(heap)[1]