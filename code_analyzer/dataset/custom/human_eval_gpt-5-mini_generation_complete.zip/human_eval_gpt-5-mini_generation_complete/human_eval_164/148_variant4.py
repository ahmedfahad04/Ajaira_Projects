def bf(planet1, planet2):
    planets = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
    try:
        i = planets.index(planet1)
        j = planets.index(planet2)
    except ValueError:
        return ()
    lo, hi = sorted((i, j))
    return tuple(p for idx, p in enumerate(planets) if lo < idx < hi)