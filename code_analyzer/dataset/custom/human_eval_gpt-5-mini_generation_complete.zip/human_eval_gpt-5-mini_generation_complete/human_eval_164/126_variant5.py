def is_sorted(lst):
    # brute-force frequency checks with list.count and manual order check
    # check ascending (non-decreasing)
    for i in range(1, len(lst)):
        if lst[i] < lst[i-1]:
            return False
    # check counts using count (O(n^2) worst-case)
    seen = set()
    for x in lst:
        if x in seen:
            continue
        seen.add(x)
        if lst.count(x) > 2:
            return False
    return True