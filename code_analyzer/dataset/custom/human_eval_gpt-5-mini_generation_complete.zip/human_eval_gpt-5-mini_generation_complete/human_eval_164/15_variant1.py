def string_sequence(n: int) -> str:
    if n < 0:
        return ''
    return ' '.join(map(str, range(n + 1)))

# Classification response:
# helper function extraction; guard clause; map/filter usage; list comprehension; input validation