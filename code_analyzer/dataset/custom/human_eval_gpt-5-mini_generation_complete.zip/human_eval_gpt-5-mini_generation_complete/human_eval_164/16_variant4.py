from functools import reduce

def count_distinct_characters(string: str) -> int:
    if not string:
        return 0
    unique_set = reduce(lambda acc, ch: acc | {ch.lower()}, string, set())
    return len(unique_set)

# Classification response:
# helper function extraction;functools usage;lambda expression;accumulator set;guard clause;import reorganization;temporary variable