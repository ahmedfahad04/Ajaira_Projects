def sum_squares(lst):
    # recursive approach
    n = len(lst)
    def helper(i):
        if i >= n:
            return 0
        v = lst[i]
        if i % 3 == 0:
            val = v**2
        elif i % 4 == 0:
            val = v**3
        else:
            val = v
        return val + helper(i+1)
    return helper(0)