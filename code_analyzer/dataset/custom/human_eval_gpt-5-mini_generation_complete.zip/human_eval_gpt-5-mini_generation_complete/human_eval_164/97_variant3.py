def multiply(a, b):
    da = divmod(abs(a), 10)[1]
    db = divmod(abs(b), 10)[1]
    return da * db