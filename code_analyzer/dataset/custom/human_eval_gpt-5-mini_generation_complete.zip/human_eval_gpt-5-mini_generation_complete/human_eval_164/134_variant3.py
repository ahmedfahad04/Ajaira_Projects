import re
def check_if_last_char_is_a_letter(txt):
    return bool(re.search(r'(^[A-Za-z]$)|(\s[A-Za-z]$)', txt))