def minSubArraySum(nums):
    if not nums:
        return 0
    def rec(l, r):
        if l == r:
            return nums[l]
        m = (l + r) // 2
        left_min = rec(l, m)
        right_min = rec(m+1, r)
        # min suffix on left
        s = 0
        min_left_suffix = float('inf')
        for i in range(m, l-1, -1):
            s += nums[i]
            if s < min_left_suffix:
                min_left_suffix = s
        # min prefix on right
        s = 0
        min_right_prefix = float('inf')
        for i in range(m+1, r+1):
            s += nums[i]
            if s < min_right_prefix:
                min_right_prefix = s
        cross = min_left_suffix + min_right_prefix
        return left_min if left_min < right_min and left_min < cross else (right_min if right_min < cross else cross)
    return rec(0, len(nums)-1)