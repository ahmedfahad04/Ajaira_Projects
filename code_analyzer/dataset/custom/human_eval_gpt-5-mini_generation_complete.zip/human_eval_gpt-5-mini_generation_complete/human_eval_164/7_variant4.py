from typing import List
import re

def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """Return list of strings that contain substring using regex search (escaped)."""
    if substring == "":
        return list(strings)
    pattern = re.compile(re.escape(substring))
    return [s for s in strings if pattern.search(s) is not None]