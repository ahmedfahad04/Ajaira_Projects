import math
def is_prime(n):
    if not isinstance(n, int):
        try:
            n = int(n)
        except Exception:
            return False
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0:
        return False
    r = int(math.isqrt(n))
    for i in range(3, r + 1, 2):
        if n % i == 0:
            return False
    return True

# Classification response:
# helper function extraction;guard clause;try-except wrapper;loop rewrite;sqrt-bound trial division;temporary variable;standard library helper;type conversion;input validation;boundary case handling