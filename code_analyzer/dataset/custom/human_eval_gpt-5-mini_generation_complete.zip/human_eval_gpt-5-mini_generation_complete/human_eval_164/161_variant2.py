import re
def solve(s):
    if re.search(r'[A-Za-z]', s) is None:
        return s[::-1]
    res_chars = []
    for c in s:
        if c.islower():
            res_chars.append(c.upper())
        elif c.isupper():
            res_chars.append(c.lower())
        else:
            res_chars.append(c)
    return ''.join(res_chars)