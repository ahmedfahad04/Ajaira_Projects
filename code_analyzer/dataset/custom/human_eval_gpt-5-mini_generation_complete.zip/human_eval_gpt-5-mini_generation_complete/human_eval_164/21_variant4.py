from typing import List

def rescale_to_unit(numbers: List[float]) -> List[float]:
    if not numbers:
        return []
    lo = min(numbers)
    hi = max(numbers)
    try:
        inv = 1.0 / (hi - lo)
    except ZeroDivisionError:
        return [0.0] * len(numbers)
    return [ (num - lo) * inv for num in numbers ]

# Classification response:
# helper function extraction;import reorganization;guard clause;try-except wrapper;empty input handling;variable renaming;temporary variable;list comprehension