from itertools import zip_longest

def string_xor(a: str, b: str) -> str:
    return ''.join('1' if x != y else '0' for x, y in zip_longest(a, b, fillvalue='0'))

# Classification response:
# function renaming; helper function inlining; conditional expression; itertools usage; generator expression; boundary case handling