def can_arrange(arr):
    # use generator with next to find first from the end
    n = len(arr)
    return next((i for i in range(n-1, 0, -1) if arr[i] < arr[i-1]), -1)