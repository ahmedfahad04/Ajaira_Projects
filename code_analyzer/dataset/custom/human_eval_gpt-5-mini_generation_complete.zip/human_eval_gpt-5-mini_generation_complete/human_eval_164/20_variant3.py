from typing import List, Tuple
import itertools

def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    if len(numbers) < 2:
        raise ValueError("At least two numbers required")
    pair = min(itertools.combinations(numbers, 2), key=lambda p: abs(p[0] - p[1]))
    a, b = pair
    return (a, b) if a <= b else (b, a)

# Classification response:
# function renaming; import reorganization; loop rewrite; itertools usage; lambda expression; guard clause; input validation; boundary case handling; flattened conditional; tuple unpacking; brute force