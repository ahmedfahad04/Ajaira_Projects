import re
from typing import List

def parse_music(music_string: str) -> List[int]:
    # Find tokens: prefer two-character tokens first
    tokens = re.findall(r'o\||\.\||o', music_string)
    mapping = {'o|': 2, '.|': 1, 'o': 4}
    return [mapping[t] for t in tokens]

# Classification response:
# helper function extraction; variable renaming; import reorganization; regex usage; standard library helper; list comprehension; dictionary lookup; empty input handling; type annotations