def valid_date(date):
    if not date or not isinstance(date, str):
        return False
    first = date.find('-')
    if first == -1:
        return False
    second = date.find('-', first + 1)
    if second == -1 or second == first + 1 or second == len(date) - 1:
        return False
    m = date[:first]
    d = date[first+1:second]
    y = date[second+1:]
    if not (m.isdigit() and d.isdigit() and y.isdigit()):
        return False
    if len(y) != 4:
        return False
    month = int(m)
    day = int(d)
    if not (1 <= month <= 12):
        return False
    if day < 1:
        return False
    if month == 2:
        return day <= 29
    if month in (4, 6, 9, 11):
        return day <= 30
    return day <= 31