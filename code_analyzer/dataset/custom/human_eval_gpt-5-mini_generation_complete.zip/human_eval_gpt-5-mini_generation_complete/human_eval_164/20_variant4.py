from typing import List, Tuple
import math

def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    if len(numbers) < 2:
        raise ValueError("At least two numbers required")
    s = sorted(numbers)
    # choose the adjacent pair minimizing (difference, smaller, larger) for deterministic tie-break
    best = (math.inf, math.inf, math.inf)
    for i in range(1, len(s)):
        a, b = s[i-1], s[i]
        diff = b - a
        cand = (diff, a, b)
        if cand < best:
            best = cand
    _, a, b = best
    return (a, b)

# Classification response:
# sorting-based approach; loop rewrite; index-based loop; flattened conditional; tuple unpacking; temporary variable; input validation; boundary case handling; import reorganization; standard library helper