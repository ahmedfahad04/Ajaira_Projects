def get_positive(l: list):
    res = []
    for x in l:
        if x > 0:
            res.append(x)
    return res

# Classification response:
# helper function extraction; loop rewrite; for loop; list comprehension; accumulator list; temporary variable; in-place mutation