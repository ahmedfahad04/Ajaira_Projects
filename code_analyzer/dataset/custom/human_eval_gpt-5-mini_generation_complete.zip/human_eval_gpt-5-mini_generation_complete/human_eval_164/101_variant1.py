import re
def words_string(s):
    if s is None:
        return []
    s = s.strip()
    if not s:
        return []
    parts = re.split(r'[,\s]+', s)
    return [p for p in parts if p != '']