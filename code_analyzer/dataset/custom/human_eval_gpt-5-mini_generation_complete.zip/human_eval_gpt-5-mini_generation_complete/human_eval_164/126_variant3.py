from itertools import groupby

def is_sorted(lst):
    if not lst:
        return True
    prev = None
    for key, group in groupby(lst):
        if prev is not None and key < prev:
            return False
        length = sum(1 for _ in group)
        if length > 2:
            return False
        prev = key
    return True