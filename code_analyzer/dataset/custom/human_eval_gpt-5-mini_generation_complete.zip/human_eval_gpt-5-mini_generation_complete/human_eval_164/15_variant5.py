def string_sequence(n: int) -> str:
    if n < 0:
        return ''
    from io import StringIO
    buf = StringIO()
    first = True
    for i in range(n + 1):
        if not first:
            buf.write(' ')
        buf.write(str(i))
        first = False
    return buf.getvalue()

# Classification response:
# function renaming; helper function extraction; guard clause; loop rewrite; for loop; list comprehension; accumulator string; sentinel flag; temporary variable; standard library helper; import reorganization; input validation; boundary case handling