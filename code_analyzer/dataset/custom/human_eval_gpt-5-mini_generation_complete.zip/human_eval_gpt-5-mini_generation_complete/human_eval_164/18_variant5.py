def how_many_times(string: str, substring: str) -> int:
    if not substring:
        return 0
    # recursive with slicing (may be less efficient but simple)
    def helper(s):
        if len(s) < len(substring):
            return 0
        if s.startswith(substring):
            return 1 + helper(s[1:])
        else:
            return helper(s[1:])
    return helper(string)

# Classification response:
# function renaming; recursion with base case; helper function extraction; early return; empty input handling; slicing; standard library helper