from typing import List

def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    return list(filter(lambda s: s.startswith(prefix), strings))

# Classification response:
# helper function extraction; map/filter usage; lambda expression; list conversion; import reorganization; type annotations