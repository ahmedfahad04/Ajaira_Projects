def unique_digits(x):
    def all_odd_digits(n):
        n = abs(n)
        if n == 0:
            return False
        while n:
            d = n % 10
            if d % 2 == 0:
                return False
            n //= 10
        return True
    return sorted([n for n in x if all_odd_digits(n)])