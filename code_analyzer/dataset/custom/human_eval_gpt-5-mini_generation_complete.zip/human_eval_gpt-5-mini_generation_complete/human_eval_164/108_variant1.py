def count_nums(arr):
    count = 0
    for n in arr:
        s = str(n)
        if s.startswith('-'):
            # digits after the minus sign
            ds = [int(ch) for ch in s[1:]] if len(s) > 1 else []
            if ds:
                total = -ds[0] + sum(ds[1:])
            else:
                total = 0
        else:
            total = sum(int(ch) for ch in s) if s else 0
        if total > 0:
            count += 1
    return count