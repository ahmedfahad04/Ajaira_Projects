def minSubArraySum(nums):
    if not nums:
        return 0
    min_ending_here = nums[0]
    min_so_far = nums[0]
    for x in nums[1:]:
        min_ending_here = x if x < min_ending_here + x else min_ending_here + x
        if min_ending_here < min_so_far:
            min_so_far = min_ending_here
    return min_so_far