import re
def fix_spaces(text):
    if not text:
        return text
    def repl(m):
        cnt = len(m.group(0))
        return '-' if cnt > 2 else '_' * cnt
    return re.sub(r' +', repl, text)