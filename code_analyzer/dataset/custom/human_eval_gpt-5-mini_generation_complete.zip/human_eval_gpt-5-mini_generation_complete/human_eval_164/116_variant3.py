def sort_array(arr):
    from collections import defaultdict
    buckets = defaultdict(list)
    for x in arr:
        c = x.bit_count() if hasattr(x, "bit_count") else bin(x).count('1')
        buckets[c].append(x)
    result = []
    for c in sorted(buckets):
        result.extend(sorted(buckets[c]))
    return result