def count_nums(arr):
    def msd(x):
        # return most significant digit of positive integer x
        if x < 10:
            return x
        return msd(x // 10)

    def signed_sum(n):
        if n >= 0:
            return sum(int(ch) for ch in str(n)) if n != 0 else 0
        m = abs(n)
        if m == 0:
            return 0
        total = sum(int(ch) for ch in str(m))
        return total - 2 * msd(m)

    total_count = 0
    for v in arr:
        if signed_sum(v) > 0:
            total_count += 1
    return total_count