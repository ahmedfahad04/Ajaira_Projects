def int_to_mini_roman(number):
    if not (1 <= number <= 1000):
        raise ValueError("number out of range")
    values = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
    symbols = ['m', 'cm', 'd', 'cd', 'c', 'xc', 'l', 'xl', 'x', 'ix', 'v', 'iv', 'i']
    n = number
    res = []
    for val, sym in zip(values, symbols):
        q, n = divmod(n, val)
        if q:
            res.append(sym * q)
        if n == 0:
            break
    return ''.join(res)