def greatest_common_divisor(a: int, b: int) -> int:
    a, b = abs(a), abs(b)
    if a == 0 and b == 0:
        return 0
    if a == 0:
        return b
    if b == 0:
        return a
    m = min(a, b)
    for d in range(m, 0, -1):
        if a % d == 0 and b % d == 0:
            return d
    return 1

# Classification response:
# function renaming;helper function extraction;guard clause;for loop;brute force;boundary case handling;type conversion