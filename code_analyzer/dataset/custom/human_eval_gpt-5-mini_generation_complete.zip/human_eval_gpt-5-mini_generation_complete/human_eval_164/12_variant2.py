from typing import List, Optional

def longest(strings: List[str]) -> Optional[str]:
    if not strings:
        return None
    idx, s = max(enumerate(strings), key=lambda x: (len(x[1]), -x[0]))
    return s

# Classification response:
# loop rewrite; enumerate loop; lambda expression; builtin function; tuple unpacking; import reorganization; standard library helper; empty input handling