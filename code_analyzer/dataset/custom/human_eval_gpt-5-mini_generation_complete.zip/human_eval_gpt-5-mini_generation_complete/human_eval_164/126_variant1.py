def is_sorted(lst):
    if not lst:
        return True
    # check non-decreasing order
    for i in range(1, len(lst)):
        if lst[i] < lst[i - 1]:
            return False
    # check frequency constraint (no element appears more than twice)
    freq = {}
    for x in lst:
        freq[x] = freq.get(x, 0) + 1
        if freq[x] > 2:
            return False
    return True