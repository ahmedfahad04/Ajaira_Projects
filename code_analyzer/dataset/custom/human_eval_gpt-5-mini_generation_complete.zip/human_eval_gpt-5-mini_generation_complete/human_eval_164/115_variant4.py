def max_fill(grid, capacity):
    def helper(i):
        if i >= len(grid):
            return 0
        cnt = grid[i].count(1)
        return (cnt + capacity - 1) // capacity + helper(i + 1)
    return helper(0)