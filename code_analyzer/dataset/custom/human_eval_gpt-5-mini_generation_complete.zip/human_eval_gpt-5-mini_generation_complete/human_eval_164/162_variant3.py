def string_to_md5(text):
    if text == "":
        return None
    import hashlib, binascii
    h = hashlib.md5()
    h.update(text.encode('utf-8'))
    return binascii.hexlify(h.digest()).decode('ascii')