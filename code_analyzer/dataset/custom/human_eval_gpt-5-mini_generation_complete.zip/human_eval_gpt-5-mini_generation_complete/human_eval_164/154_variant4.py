from collections import deque
def cycpattern_check(a , b):
    if b == "":
        return True
    n = len(b)
    if n > len(a):
        return False
    d = deque(b)
    for _ in range(n):
        s = ''.join(d)
        if s in a:
            return True
        d.rotate(-1)
    return False