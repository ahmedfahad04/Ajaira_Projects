def solution(lst):
    if not lst:
        return 0
    head = lst[0]
    add = head if (head & 1) else 0
    return add + solution(lst[2:])