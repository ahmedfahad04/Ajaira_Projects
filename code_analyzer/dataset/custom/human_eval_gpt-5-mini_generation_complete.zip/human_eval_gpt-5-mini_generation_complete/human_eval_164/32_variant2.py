def poly(xs: list, x: float):
    if not xs:
        return 0.0
    result = 0.0
    for coeff in reversed(xs):
        result = result * x + coeff
    return result

# Classification response:
# loop rewrite; for loop; prefix/suffix computation; state variable; empty input handling; builtin function