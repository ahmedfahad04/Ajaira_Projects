import re
def specialFilter(nums):
    pat = re.compile(r'^[13579].*[13579]$')
    c = 0
    for n in nums:
        if n > 10:
            s = str(abs(n))
            if pat.match(s):
                c += 1
    return c