def is_prime(n):
    if not isinstance(n, int):
        try:
            n = int(n)
        except Exception:
            return False
    if n <= 1:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    def check(k):
        if k * k > n:
            return True
        if n % k == 0:
            return False
        return check(k + 2)
    return check(3)

# Classification response:
# guard clause; try-except wrapper; helper function extraction; recursion with base case; sqrt bound; odd-only iteration; input validation; type conversion; boundary case handling