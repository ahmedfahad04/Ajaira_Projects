def Strongest_Extension(class_name, extensions):
    if not extensions:
        return class_name + '.'
    # use max with a key that prefers earlier index on ties
    def strength_of(ext):
        caps = sum(1 for c in ext if c.isupper())
        lows = sum(1 for c in ext if c.islower())
        return caps - lows
    indexed = enumerate(extensions)
    best_index, best_ext = max(indexed, key=lambda iv: (strength_of(iv[1]), -iv[0]))
    return class_name + '.' + best_ext