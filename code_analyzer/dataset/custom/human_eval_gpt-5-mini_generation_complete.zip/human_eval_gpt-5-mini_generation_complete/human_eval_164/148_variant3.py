def bf(planet1, planet2):
    planets = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
    if planet1 not in planets or planet2 not in planets:
        return ()
    i = planets.index(planet1)
    j = planets.index(planet2)
    a, b = min(i, j), max(i, j)
    def collect(s, e):
        if s + 1 >= e:
            return []
        return [planets[s+1]] + collect(s+1, e)
    return tuple(collect(a, b))