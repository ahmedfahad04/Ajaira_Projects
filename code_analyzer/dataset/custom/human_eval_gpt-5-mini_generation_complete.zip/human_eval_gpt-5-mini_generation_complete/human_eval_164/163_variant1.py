def generate_integers(a, b):
    low, high = min(a, b), max(a, b)
    digits = [0, 2, 4, 6, 8]
    return [d for d in digits if low <= d <= high]