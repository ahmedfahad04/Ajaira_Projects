from typing import List
import math

def factorize(n: int) -> List[int]:
    if n is None:
        return []
    n = int(n)
    if n < 2:
        return []
    factors: List[int] = []
    while n % 2 == 0:
        factors.append(2)
        n //= 2
    i = 3
    # trial division by odd numbers
    while i * i <= n:
        while n % i == 0:
            factors.append(i)
            n //= i
        i += 2
    if n > 1:
        factors.append(n)
    return factors

# Classification response:
# variable renaming; import reorganization; guard clause; helper function extraction; loop rewrite; accumulator list; input validation; type conversion; boundary case handling