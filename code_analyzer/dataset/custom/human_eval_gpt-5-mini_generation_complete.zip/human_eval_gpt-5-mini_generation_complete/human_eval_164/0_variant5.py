from typing import List
import bisect

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    if threshold <= 0:
        return False
    seen: List[float] = []
    for x in numbers:
        i = bisect.bisect_left(seen, x)
        if i > 0 and abs(seen[i - 1] - x) < threshold:
            return True
        if i < len(seen) and abs(seen[i] - x) < threshold:
            return True
        seen.insert(i, x)
    return False