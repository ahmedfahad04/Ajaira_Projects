def strlen(string: str) -> int:
    return len(string)

# Classification response:
# helper function extraction; builtin function; type annotations