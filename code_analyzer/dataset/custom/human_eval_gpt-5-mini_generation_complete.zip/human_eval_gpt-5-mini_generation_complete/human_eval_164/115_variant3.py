def max_fill(grid, capacity):
    from functools import reduce
    parts = map(lambda r: (sum(r) + capacity - 1) // capacity, grid)
    return reduce(lambda a, b: a + b, parts, 0)