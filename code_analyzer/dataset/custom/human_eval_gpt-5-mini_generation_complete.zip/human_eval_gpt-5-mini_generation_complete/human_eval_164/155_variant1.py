def even_odd_count(num):
    s = str(num)
    even = odd = 0
    for ch in s:
        if ch == '-':
            continue
        d = ord(ch) - 48
        if d % 2 == 0:
            even += 1
        else:
            odd += 1
    return (even, odd)