def string_sequence(n: int) -> str:
    if n < 0:
        return ''
    parts = []
    for i in range(n + 1):
        parts.append(str(i))
    return ' '.join(parts)

# Classification response:
# helper function extraction; guard clause; loop rewrite; for loop; accumulator list; list comprehension; input validation