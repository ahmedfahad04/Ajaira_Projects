import math

def x_or_y(n, x, y):
    # generator-based primality check
    try:
        n = int(n)
    except:
        return y
    if n <= 1:
        return y
    if n <= 3:
        return x
    if n % 2 == 0:
        return y
    r = int(math.isqrt(n))
    if all(n % i != 0 for i in range(3, r + 1, 2)):
        return x
    return y