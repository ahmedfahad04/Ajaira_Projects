def is_nested(string):
    opens = [i for i, c in enumerate(string) if c == '[']
    if len(opens) < 2:
        return False
    second_open_idx = opens[1]
    closes_after = sum(1 for i in range(second_open_idx + 1, len(string)) if string[i] == ']')
    return closes_after >= 2