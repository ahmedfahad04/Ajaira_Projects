def maximum(arr, k):
    if k <= 0:
        return []
    n = len(arr)
    if k >= n:
        return sorted(arr)
    sorted_arr = sorted(arr)
    res = sorted_arr[-k:]
    return res