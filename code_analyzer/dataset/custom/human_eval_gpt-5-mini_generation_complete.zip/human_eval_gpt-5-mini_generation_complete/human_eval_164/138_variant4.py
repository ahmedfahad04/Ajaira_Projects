def is_equal_to_sum_even(n):
    if not isinstance(n, int):
        return False
    if n % 2 != 0 or n < 8:
        return False
    target = n
    def helper(k, rem):
        if k == 1:
            return rem >= 2 and rem % 2 == 0
        min_needed = 2 * k
        if rem < min_needed:
            return False
        max_first = rem - 2 * (k - 1)
        for x in range(2, max_first + 1, 2):
            if helper(k - 1, rem - x):
                return True
        return False
    return helper(4, target)