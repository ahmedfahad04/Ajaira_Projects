def get_max_triples(n):
    c0 = 0
    # count indices i in [1..n] with i % 3 == 2
    i = 2
    while i <= n:
        c0 += 1
        i += 3
    c1 = n - c0
    # compute C(k,3) via loop to avoid large intermediate factorials
    def c3(k):
        if k < 3:
            return 0
        res = 1
        res *= k
        res *= (k - 1)
        res *= (k - 2)
        return res // 6
    return c3(c0) + c3(c1)