def by_length(arr):
    names = {1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"}
    a = list(arr)
    a.sort()
    a.reverse()
    out = []
    for v in a:
        if v in names:
            out.append(names[v])
    return out