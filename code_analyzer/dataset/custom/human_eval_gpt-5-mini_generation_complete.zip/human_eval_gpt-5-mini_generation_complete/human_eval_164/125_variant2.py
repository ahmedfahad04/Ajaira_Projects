import re

def split_words(txt):
    if re.search(r'\s', txt):
        return re.findall(r'\S+', txt)
    if ',' in txt:
        return txt.split(',')
    return sum(1 for c in txt if c.islower() and ((ord(c) - ord('a')) & 1 == 1))