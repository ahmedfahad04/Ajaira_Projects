def words_in_sentence(sentence):
    words = sentence.split()
    from functools import lru_cache

    @lru_cache(None)
    def is_prime(n):
        if n < 2:
            return False
        if n % 2 == 0:
            return n == 2
        i = 3
        while i * i <= n:
            if n % i == 0:
                return False
            i += 2
        return True

    def collect(idx):
        if idx >= len(words):
            return []
        head = words[idx]
        rest = collect(idx + 1)
        if is_prime(len(head)):
            return [head] + rest
        return rest

    return " ".join(collect(0))