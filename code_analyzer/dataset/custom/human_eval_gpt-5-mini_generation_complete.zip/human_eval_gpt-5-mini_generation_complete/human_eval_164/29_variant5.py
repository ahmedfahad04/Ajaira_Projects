from typing import List
import re

def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    if prefix == "":
        return strings[:]
    pat = re.compile(re.escape(prefix))
    return [s for s in strings if pat.match(s)]

# Classification response:
# helper function extraction; import reorganization; regex usage; guard clause; copy before mutation; empty input handling