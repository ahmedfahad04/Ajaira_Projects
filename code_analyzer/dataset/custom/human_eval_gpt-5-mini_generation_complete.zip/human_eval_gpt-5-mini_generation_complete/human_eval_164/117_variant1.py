def select_words(s, n):
    vowels = set("aeiou")
    result = []
    for word in s.split():
        cnt = 0
        for ch in word:
            if ch.lower() not in vowels:
                cnt += 1
        if cnt == n:
            result.append(word)
    return result