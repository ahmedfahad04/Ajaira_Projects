def how_many_times(string: str, substring: str) -> int:
    if not substring:
        return 0
    n, m = len(string), len(substring)
    if m > n:
        return 0
    count = 0
    for i in range(n - m + 1):
        if string[i:i + m] == substring:
            count += 1
    return count

# Classification response:
# function renaming; variable renaming; tuple unpacking; guard clause; input validation