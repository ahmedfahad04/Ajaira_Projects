def digits(n):
    s = str(abs(int(n)))
    odds = [int(ch) for ch in s if (ord(ch) - ord('0')) % 2 == 1]
    if not odds:
        return 0
    prod = 1
    for d in odds:
        prod *= d
    return prod