def select_words(s, n):
    trans = {ord(c): None for c in "aeiouAEIOU"}
    res = []
    for w in s.split():
        rem = w.translate(trans)
        if len(rem) == n:
            res.append(w)
    return res