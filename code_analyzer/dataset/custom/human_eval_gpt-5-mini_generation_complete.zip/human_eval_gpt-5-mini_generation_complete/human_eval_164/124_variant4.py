import re
def valid_date(date):
    if not date or not isinstance(date, str):
        return False
    m = re.match(r"^(\d{1,2})-(\d{1,2})-(\d{4})$", date)
    if not m:
        return False
    month = int(m.group(1))
    day = int(m.group(2))
    if month < 1 or month > 12:
        return False
    if day < 1:
        return False
    if month == 2:
        return day <= 29
    if month in (4, 6, 9, 11):
        return day <= 30
    return day <= 31