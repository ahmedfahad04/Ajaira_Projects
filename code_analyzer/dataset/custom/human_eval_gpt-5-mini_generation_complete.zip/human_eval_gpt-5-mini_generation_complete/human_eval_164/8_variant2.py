from typing import List, Tuple
import math

def sum_product(numbers: List[int]) -> Tuple[int, int]:
    return (sum(numbers), math.prod(numbers))