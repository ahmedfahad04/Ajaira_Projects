def can_arrange(arr):
    n = len(arr)
    if n < 2:
        return -1
    for i in range(n - 1, 0, -1):
        if arr[i] < arr[i - 1]:
            return i
    return -1