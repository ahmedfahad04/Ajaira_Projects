def words_in_sentence(sentence):
    def is_prime(n):
        if n < 2:
            return False
        if n in (2, 3):
            return True
        if n % 2 == 0:
            return False
        i = 3
        while i * i <= n:
            if n % i == 0:
                return False
            i += 2
        return True

    words = sentence.split()
    res = [w for w in words if is_prime(len(w))]
    return " ".join(res)