def check_if_last_char_is_a_letter(txt):
    head, sep, tail = txt.rpartition(' ')
    return len(tail) == 1 and tail.isalpha()