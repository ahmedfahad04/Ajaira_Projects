def greatest_common_divisor(a: int, b: int) -> int:
    a, b = abs(a), abs(b)
    if b == 0:
        return a
    return greatest_common_divisor(b, a % b)

# Classification response:
# function renaming; recursion with base case; loop rewrite; guard clause; builtin function; type conversion; boundary case handling