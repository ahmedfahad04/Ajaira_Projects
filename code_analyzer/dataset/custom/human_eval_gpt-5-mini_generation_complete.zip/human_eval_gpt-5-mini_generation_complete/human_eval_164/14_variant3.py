from typing import List
from itertools import accumulate
import operator

def all_prefixes(string: str) -> List[str]:
    return list(accumulate(string, operator.add))

# Classification response:
# helper function extraction; loop rewrite; itertools usage; accumulator string; list conversion; import reorganization