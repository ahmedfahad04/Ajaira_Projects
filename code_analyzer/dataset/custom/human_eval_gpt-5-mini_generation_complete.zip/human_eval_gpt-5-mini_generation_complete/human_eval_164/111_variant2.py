def histogram(test):
    if not test or test.strip() == "":
        return {}
    parts = test.split()
    counts = {}
    for p in parts:
        counts[p] = counts.get(p, 0) + 1
    if not counts:
        return {}
    max_count = max(counts.values())
    result = {}
    for k, v in counts.items():
        if v == max_count:
            result[k] = v
    return result