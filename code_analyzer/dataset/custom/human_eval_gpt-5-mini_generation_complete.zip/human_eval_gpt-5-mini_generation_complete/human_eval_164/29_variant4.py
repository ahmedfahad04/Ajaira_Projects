from typing import List

def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    if not strings:
        return []
    head, *tail = strings
    rest = filter_by_prefix(tail, prefix)
    if head.startswith(prefix):
        return [head] + rest
    return rest

# Classification response:
# helper function extraction; recursion with base case; guard clause; tuple unpacking; import reorganization; empty input handling