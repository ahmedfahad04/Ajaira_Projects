def split_words(txt):
    for ch in txt:
        if ch.isspace():
            res = []
            cur = []
            for ch2 in txt:
                if ch2.isspace():
                    if cur:
                        res.append(''.join(cur))
                        cur = []
                else:
                    cur.append(ch2)
            if cur:
                res.append(''.join(cur))
            return res
    if ',' in txt:
        return txt.split(',')
    count = 0
    for c in txt:
        if 'a' <= c <= 'z':
            if (ord(c) - ord('a')) % 2 == 1:
                count += 1
    return count