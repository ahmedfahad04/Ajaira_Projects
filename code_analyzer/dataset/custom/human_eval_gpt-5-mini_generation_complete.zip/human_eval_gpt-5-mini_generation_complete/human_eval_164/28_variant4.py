from typing import List

def concatenate(strings: List[str]) -> str:
    n = len(strings)
    if n == 0:
        return ""
    if n == 1:
        return strings[0]
    mid = n // 2
    return concatenate(strings[:mid]) + concatenate(strings[mid:])

# Classification response:
# helper function extraction; recursion with base case; divide and conquer; early return; empty input handling; boundary case handling; slicing; standard library helper