def odd_count(lst):
    template = "the number of odd elements in the string i of the input."
    result = []
    for s in lst:
        cnt = 0
        for ch in s:
            d = ord(ch) - 48
            if d & 1:
                cnt += 1
        # build replaced string character by character to allow multi-digit cnt
        rep = []
        cs = str(cnt)
        for ch in template:
            if ch == "i":
                rep.append(cs)
            else:
                rep.append(ch)
        result.append("".join(rep))
    return result