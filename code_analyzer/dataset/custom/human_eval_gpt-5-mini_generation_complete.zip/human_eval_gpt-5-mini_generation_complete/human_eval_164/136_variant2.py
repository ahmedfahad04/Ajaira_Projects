def largest_smallest_integers(lst):
    negs = [x for x in lst if x < 0]
    poss = [x for x in lst if x > 0]
    return (max(negs) if negs else None, min(poss) if poss else None)