def special_factorial(n):
    if n <= 0:
        return 1
    result = 1
    for k in range(1, n + 1):
        f = 1
        for i in range(1, k + 1):
            f *= i
        result *= f
    return result