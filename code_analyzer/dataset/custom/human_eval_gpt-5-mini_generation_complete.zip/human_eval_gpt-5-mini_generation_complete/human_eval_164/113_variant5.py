def odd_count(lst):
    template = "the number of odd elements in the string i of the input."
    out = []
    for s in lst:
        cnt = 0
        for ch in s:
            if ch in "13579":
                cnt += 1
        # use split/join variant for replacement
        parts = template.split("i")
        out.append(str(cnt).join(parts))
    return out