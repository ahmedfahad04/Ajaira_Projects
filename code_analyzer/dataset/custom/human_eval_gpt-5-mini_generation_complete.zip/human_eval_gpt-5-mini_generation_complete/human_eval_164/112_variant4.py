def reverse_delete(s,c):
    cs = set(c)
    res = ''.join(filter(lambda ch: ch not in cs, s))
    n = len(res)
    pal = all(res[i] == res[n-1-i] for i in range(n//2))
    return res, pal