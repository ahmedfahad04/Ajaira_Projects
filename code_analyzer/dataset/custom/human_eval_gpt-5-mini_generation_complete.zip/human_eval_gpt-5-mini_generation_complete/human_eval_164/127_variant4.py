def intersection(interval1, interval2):
    a1, b1 = interval1
    a2, b2 = interval2
    s = max(a1, a2)
    e = min(b1, b2)
    if e < s:
        return "NO"
    n = e - s
    if n < 2:
        return "NO"
    # Use sieve if n reasonably small, otherwise fall back to trial division
    if n <= 1000000:
        m = n
        sieve = bytearray(b'\x01') * (m + 1)
        sieve[0:2] = b'\x00\x00'
        import math
        for p in range(2, int(math.isqrt(m)) + 1):
            if sieve[p]:
                step = p
                start = p * p
                sieve[start:m+1:step] = b'\x00' * (((m - start) // step) + 1)
        return "YES" if sieve[n] else "NO"
    else:
        # trial division
        import math
        if n % 2 == 0:
            return "YES" if n == 2 else "NO"
        lim = math.isqrt(n)
        i = 3
        while i <= lim:
            if n % i == 0:
                return "NO"
            i += 2
        return "YES"