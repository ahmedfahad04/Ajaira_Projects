from typing import List, Any

def filter_integers(values: List[Any]) -> List[int]:
    # Imperative loop collecting valid ints, excluding booleans
    result: List[int] = []
    for v in values:
        if isinstance(v, int) and not isinstance(v, bool):
            result.append(v)
    return result

# Classification response:
# helper function extraction; loop rewrite; for loop; accumulator list; in-place mutation; temporary variable; import reorganization; boundary case handling; type check