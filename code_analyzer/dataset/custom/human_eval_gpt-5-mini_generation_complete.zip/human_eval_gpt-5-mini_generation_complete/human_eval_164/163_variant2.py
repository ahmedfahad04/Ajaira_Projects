def generate_integers(a, b):
    low, high = min(a, b), max(a, b)
    result = []
    for x in range(low, high + 1):
        if 0 <= x <= 9 and x % 2 == 0:
            result.append(x)
    return result