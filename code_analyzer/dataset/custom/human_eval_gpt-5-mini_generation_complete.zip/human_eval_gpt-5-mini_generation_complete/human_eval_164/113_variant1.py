def odd_count(lst):
    template = "the number of odd elements in the string i of the input."
    out = []
    for s in lst:
        cnt = sum(1 for ch in s if ch in "13579")
        out.append(template.replace("i", str(cnt)))
    return out