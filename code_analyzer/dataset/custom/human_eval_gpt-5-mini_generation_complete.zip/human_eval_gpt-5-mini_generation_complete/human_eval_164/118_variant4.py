def get_closest_vowel(word):
    vowels = set("aeiouAEIOU")
    if len(word) < 3:
        return ""
    def helper(i):
        if i < 1:
            return ""
        if word[i] in vowels and word[i-1] not in vowels and word[i+1] not in vowels:
            return word[i]
        return helper(i-1)
    return helper(len(word)-2)