def make_a_pile(n):
    def build(curr, remaining):
        if remaining == 0:
            return []
        return [curr] + build(curr + 2, remaining - 1)
    return build(n, n)