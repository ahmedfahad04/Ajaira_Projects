def find_max(words):
    if not words:
        return ""
    best_for_count = {}
    max_count = 0
    for w in words:
        c = len(set(w))
        if c in best_for_count:
            if w < best_for_count[c]:
                best_for_count[c] = w
        else:
            best_for_count[c] = w
        if c > max_count:
            max_count = c
    return best_for_count[max_count]