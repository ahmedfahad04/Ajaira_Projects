def compare_one(a, b):
    from decimal import Decimal, InvalidOperation
    def norm(x):
        if isinstance(x, str):
            s = x.strip()
            # simple normalization: treat last of '.' or ',' as decimal sep if both present
            if '.' in s and ',' in s:
                if s.rfind(',') > s.rfind('.'):
                    s = s.replace('.', '').replace(',', '.')
                else:
                    s = s.replace(',', '')
            else:
                s = s.replace(',', '.')
            return Decimal(s)
        return Decimal(str(x))
    try:
        na = norm(a)
        nb = norm(b)
    except (InvalidOperation, ValueError):
        # fallback to Python comparison
        if a == b:
            return None
        return a if a > b else b
    if na == nb:
        return None
    return a if na > nb else b