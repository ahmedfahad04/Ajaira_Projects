import math
def right_angle_triangle(a, b, c):
    triples = ((a, b, c), (b, c, a), (c, a, b))
    for x, y, z in triples:
        try:
            xf, yf, zf = float(x), float(y), float(z)
        except Exception:
            xf, yf, zf = x, y, z
        if xf <= 0 or yf <= 0 or zf <= 0:
            continue
        if xf + yf <= zf:
            continue
        if math.isclose(xf * xf + yf * yf, zf * zf, rel_tol=1e-9, abs_tol=1e-9):
            return True
    return False