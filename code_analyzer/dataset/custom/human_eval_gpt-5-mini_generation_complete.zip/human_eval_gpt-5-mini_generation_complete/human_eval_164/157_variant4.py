import math
def right_angle_triangle(a, b, c):
    try:
        sides = [float(a), float(b), float(c)]
    except Exception:
        sides = [a, b, c]
    if any(x <= 0 for x in sides):
        return False
    sides.sort()
    a1, b1, c1 = sides
    if a1 + b1 <= c1:
        return False
    denom = 2 * a1 * b1
    if denom == 0:
        return False
    cosC = (a1*a1 + b1*b1 - c1*c1) / denom
    return abs(cosC) <= 1e-9