def minPath(grid, k):
    n = len(grid)
    # find value 1 position (minimum value)
    sx = sy = None
    for i in range(n):
        for j in range(n):
            if grid[i][j] == 1:
                sx, sy = i, j
                break
        if sx is not None:
            break
    path = [1]
    x, y = sx, sy
    dirs = [(1,0),(-1,0),(0,1),(0,-1)]
    for _ in range(k-1):
        best = None
        bx = by = None
        for dx, dy in dirs:
            nx, ny = x+dx, y+dy
            if 0 <= nx < n and 0 <= ny < n:
                val = grid[nx][ny]
                if best is None or val < best:
                    best = val
                    bx, by = nx, ny
        # move to minimal neighbor
        path.append(best)
        x, y = bx, by
    return path