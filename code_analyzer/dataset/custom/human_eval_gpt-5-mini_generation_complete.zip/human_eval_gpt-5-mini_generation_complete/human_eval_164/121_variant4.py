def solution(lst):
    from functools import reduce
    return reduce(lambda acc, iv: acc + (iv[1] if (iv[0] % 2 == 0 and iv[1] % 2 == 1) else 0), enumerate(lst), 0)