def x_or_y(n, x, y):
    # Sieve approach: build sieve up to n
    try:
        n = int(n)
    except:
        return y
    if n <= 1:
        return y
    if n == 2:
        return x
    if n < 2:
        return y
    limit = n
    sieve = bytearray(b'\x01') * (limit + 1)
    sieve[0:2] = b'\x00\x00'
    p = 2
    while p * p <= limit:
        if sieve[p]:
            step = p
            start = p * p
            sieve[start:limit+1:step] = b'\x00' * (((limit - start) // step) + 1)
        p += 1
    return x if sieve[n] else y