from typing import List

def rescale_to_unit(numbers: List[float]) -> List[float]:
    def helper(i, acc, lo, hi):
        if i == len(numbers):
            return acc
        if hi == lo:
            acc.append(0.0)
        else:
            acc.append((numbers[i] - lo) / (hi - lo))
        return helper(i+1, acc, lo, hi)
    if not numbers:
        return []
    lo = min(numbers)
    hi = max(numbers)
    return helper(0, [], lo, hi)

# Classification response:
# function renaming; variable renaming; import reorganization; helper function extraction; recursion; accumulator list; guard clause; early return; empty input handling; boundary case handling