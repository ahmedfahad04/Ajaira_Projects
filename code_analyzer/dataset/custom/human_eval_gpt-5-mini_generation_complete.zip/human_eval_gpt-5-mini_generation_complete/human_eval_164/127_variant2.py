def intersection(interval1, interval2):
    a1, b1 = interval1
    a2, b2 = interval2
    s = max(a1, a2)
    e = min(b1, b2)
    if e < s:
        return "NO"
    n = e - s
    if n < 2:
        return "NO"
    if n % 2 == 0:
        return "YES" if n == 2 else "NO"
    i = 3
    import math
    lim = math.isqrt(n)
    while i <= lim:
        if n % i == 0:
            return "NO"
        i += 2
    return "YES"