import math
def choose_num(x, y):
    # iterate downward from floor(y) to ceil(x)
    if x > y:
        return -1
    low = math.ceil(x)
    cur = math.floor(y)
    while cur >= low:
        if cur % 2 == 0:
            return cur
        cur -= 1
    return -1