from typing import List
from collections import OrderedDict

def remove_duplicates(numbers: List[int]) -> List[int]:
    od = OrderedDict()
    for x in numbers:
        od[x] = od.get(x, 0) + 1
    return [x for x in numbers if od[x] == 1]

# Classification response:
# import reorganization; helper function extraction; loop rewrite; accumulator dict; frequency counting