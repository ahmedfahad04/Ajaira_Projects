def even_odd_count(num):
    n = abs(int(num))
    def recurse(x):
        if x == 0:
            return (0, 0)
        if x < 10:
            return ((1, 0) if x % 2 == 0 else (0, 1))
        e, o = recurse(x // 10)
        if (x % 10) % 2 == 0:
            return (e + 1, o)
        else:
            return (e, o + 1)
    if n == 0:
        return (1, 0)
    return recurse(n)