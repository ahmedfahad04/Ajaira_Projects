from typing import List

def below_zero(operations: List[int]) -> bool:
    def rec(i: int, bal: int) -> bool:
        if i >= len(operations):
            return False
        bal += operations[i]
        if bal < 0:
            return True
        return rec(i + 1, bal)
    return rec(0, 0)