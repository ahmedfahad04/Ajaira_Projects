def words_string(s):
    if not s:
        return []
    res = []
    token = []
    for ch in s:
        if ch == ',' or ch.isspace():
            if token:
                res.append(''.join(token))
                token = []
        else:
            token.append(ch)
    if token:
        res.append(''.join(token))
    return res