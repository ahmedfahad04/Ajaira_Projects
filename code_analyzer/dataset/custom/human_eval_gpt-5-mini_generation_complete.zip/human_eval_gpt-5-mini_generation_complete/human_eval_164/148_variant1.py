def bf(planet1, planet2):
    planets = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
    if planet1 not in planets or planet2 not in planets:
        return ()
    i = planets.index(planet1)
    j = planets.index(planet2)
    if i < j:
        return tuple(planets[i+1:j])
    else:
        return tuple(planets[j+1:i])