def how_many_times(string: str, substring: str) -> int:
    if not substring:
        return 0
    import re
    pattern = '(?=' + re.escape(substring) + ')'
    return sum(1 for _ in re.finditer(pattern, string))

# Classification response:
# guard clause; empty input handling; import reorganization; regex usage; standard library helper; generator expression; builtin function