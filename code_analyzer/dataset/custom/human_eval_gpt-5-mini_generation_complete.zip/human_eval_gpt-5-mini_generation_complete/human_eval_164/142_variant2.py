def sum_squares(lst):
    return sum((v*v if i%3==0 else (v*v*v if i%4==0 else v)) for i,v in enumerate(lst))