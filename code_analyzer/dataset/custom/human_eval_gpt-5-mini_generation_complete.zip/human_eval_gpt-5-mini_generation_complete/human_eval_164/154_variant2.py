def cycpattern_check(a , b):
    if b == "":
        return True
    n = len(b)
    if n > len(a):
        return False
    bb = b + b
    rotations = {bb[i:i+n] for i in range(n)}
    for rot in rotations:
        if rot in a:
            return True
    return False