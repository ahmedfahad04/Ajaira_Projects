def special_factorial(n):
    import math
    from itertools import accumulate
    from operator import mul
    if n <= 0:
        return 1
    return math.prod(accumulate(range(1, n + 1), mul))