def double_the_difference(lst):
    def rec(i):
        if i >= len(lst):
            return 0
        x = lst[i]
        add = 0
        if isinstance(x, int) and not isinstance(x, bool) and x >= 0 and x % 2 != 0:
            add = x * x
        return add + rec(i+1)
    return rec(0)