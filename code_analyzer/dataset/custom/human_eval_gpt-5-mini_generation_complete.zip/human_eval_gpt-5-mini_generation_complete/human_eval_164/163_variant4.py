def generate_integers(a, b):
    low, high = min(a, b), max(a, b)
    start = max(low, 0)
    end = min(high, 9)
    if start > end:
        return []
    if start % 2 != 0:
        start += 1
    if start > end:
        return []
    return list(range(start, end + 1, 2))