def sort_numbers(numbers: str) -> str:
    idx = ['zero','one','two','three','four','five','six','seven','eight','nine']
    s = numbers.strip()
    if not s:
        return ''
    arr = s.split()
    # simple in-place sort using index lookup
    def keyfn(w):
        try:
            return idx.index(w)
        except ValueError:
            return 0
    arr.sort(key=keyfn)
    return ' '.join(arr)

# Classification response:
# helper function extraction; guard clause; try-except wrapper; in-place mutation; temporary variable; default value handling