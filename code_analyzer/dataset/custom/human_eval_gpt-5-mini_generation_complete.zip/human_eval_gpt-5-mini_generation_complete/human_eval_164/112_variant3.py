def reverse_delete(s,c):
    cs = set(c)
    def build(i):
        if i == len(s):
            return ''
        tail = build(i+1)
        if s[i] in cs:
            return tail
        return s[i] + tail
    res = build(0)
    def ispal(l, r):
        if l >= r:
            return True
        if res[l] != res[r]:
            return False
        return ispal(l+1, r-1)
    return res, ispal(0, len(res)-1)