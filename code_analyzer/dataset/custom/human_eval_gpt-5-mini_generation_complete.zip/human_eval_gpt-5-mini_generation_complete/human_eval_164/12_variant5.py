from typing import List, Optional

def longest(strings: List[str]) -> Optional[str]:
    if not strings:
        return None
    if len(strings) == 1:
        return strings[0]
    head, *rest = strings
    best_rest = longest(rest)
    if best_rest is None:
        return head
    return head if len(head) >= len(best_rest) else best_rest

# Classification response:
# recursion with base case; guard clause; tuple unpacking; import reorganization; boundary case handling