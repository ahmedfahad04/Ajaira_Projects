import math
def largest_divisor(n: int) -> int:
    m = abs(n)
    if m <= 1:
        return 0
    if m % 2 == 0:
        return m // 2
    r = int(math.isqrt(m))
    for i in range(3, r + 1, 2):
        if m % i == 0:
            return m // i
    return 1

# Classification response:
# helper function extraction;loop rewrite;guard clause;temporary variable;standard library helper;type conversion;boundary case handling;behavior change;import reorganization;sqrt-based factor search