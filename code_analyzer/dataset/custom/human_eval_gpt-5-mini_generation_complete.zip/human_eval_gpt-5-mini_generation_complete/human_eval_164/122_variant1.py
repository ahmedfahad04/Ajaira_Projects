def add_elements(arr, k):
    total = 0
    for i in range(min(k, len(arr))):
        n = arr[i]
        if abs(n) <= 99:
            total += n
    return total