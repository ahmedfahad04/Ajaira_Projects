def compare_one(a, b):
    from fractions import Fraction
    def to_fraction(x):
        if isinstance(x, str):
            s = x.strip()
            if '.' in s and ',' in s:
                # decide decimal sep by last occurrence
                if s.rfind(',') > s.rfind('.'):
                    s = s.replace('.', '').replace(',', '.')
                else:
                    s = s.replace(',', '')
            else:
                s = s.replace(',', '.')
            # use Decimal-like conversion via Fraction from string
            if '.' in s:
                whole, frac = s.split('.', 1)
                sign = '-' if whole.startswith('-') else ''
                if whole.startswith(('+', '-')):
                    whole = whole[1:]
                num = int(whole) if whole != '' else 0
                den = 10 ** len(frac)
                numerator = abs(num) * den + int(frac)
                if sign == '-':
                    numerator = -numerator
                return Fraction(numerator, den)
            else:
                return Fraction(int(s))
        if isinstance(x, float):
            # convert float to Fraction via str to reduce binary issues
            return Fraction(str(x))
        return Fraction(int(x))
    try:
        fa = to_fraction(a)
        fb = to_fraction(b)
    except Exception:
        if a == b:
            return None
        return a if a > b else b
    if fa == fb:
        return None
    return a if fa > fb else b