def count_upper(s):
    vowels = set("AEIOU")
    return sum(1 for ch in s[::2] if ch in vowels)