def bf(planet1, planet2):
    planets = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
    index_map = {p: idx for idx, p in enumerate(planets)}
    if planet1 not in index_map or planet2 not in index_map:
        return ()
    a = index_map[planet1]
    b = index_map[planet2]
    start = min(a, b) + 1
    end = max(a, b)
    result = []
    k = start
    while k < end:
        result.append(planets[k])
        k += 1
    return tuple(result)