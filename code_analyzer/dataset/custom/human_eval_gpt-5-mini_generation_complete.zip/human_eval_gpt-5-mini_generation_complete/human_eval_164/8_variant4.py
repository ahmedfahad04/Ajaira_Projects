from typing import List, Tuple

def sum_product(numbers: List[int]) -> Tuple[int, int]:
    n = len(numbers)
    if n == 0:
        return 0, 1
    if n == 1:
        return numbers[0], numbers[0]
    mid = n // 2
    s1, p1 = sum_product(numbers[:mid])
    s2, p2 = sum_product(numbers[mid:])
    return s1 + s2, p1 * p2