from typing import List, Tuple
import bisect
import math

def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    if len(numbers) < 2:
        raise ValueError("At least two numbers required")
    sorted_list: List[float] = []
    best_diff = math.inf
    best_pair = (numbers[0], numbers[1])
    for x in numbers:
        pos = bisect.bisect_left(sorted_list, x)
        if pos > 0:
            left = sorted_list[pos-1]
            d = abs(x - left)
            if d < best_diff:
                best_diff = d
                best_pair = (left, x) if left <= x else (x, left)
        if pos < len(sorted_list):
            right = sorted_list[pos]
            d = abs(right - x)
            if d < best_diff:
                best_diff = d
                best_pair = (x, right) if x <= right else (right, x)
        bisect.insort(sorted_list, x)
    a, b = best_pair
    return (a, b)

# Classification response:
# variable renaming; loop rewrite; accumulator list; in-place mutation; tuple unpacking; temporary variable; guard clause; input validation; standard library helper; sorting-based approach