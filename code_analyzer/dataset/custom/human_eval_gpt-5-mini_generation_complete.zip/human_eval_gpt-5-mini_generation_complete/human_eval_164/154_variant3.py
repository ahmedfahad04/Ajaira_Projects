def cycpattern_check(a , b):
    if b == "":
        return True
    m = len(b)
    if m > len(a):
        return False
    bb = b + b
    for i in range(len(a) - m + 1):
        if a[i:i+m] in bb:
            return True
    return False