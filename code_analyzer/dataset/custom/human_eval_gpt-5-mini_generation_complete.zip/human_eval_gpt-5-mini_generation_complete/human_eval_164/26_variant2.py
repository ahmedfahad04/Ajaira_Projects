from typing import List

def remove_duplicates(numbers: List[int]) -> List[int]:
    counts = {}
    for x in numbers:
        counts[x] = counts.get(x, 0) + 1
    res = []
    for x in numbers:
        if counts[x] == 1:
            res.append(x)
    return res

# Classification response:
# helper function extraction; variable renaming; for loop; accumulator list; dictionary lookup; in-place mutation; import reorganization