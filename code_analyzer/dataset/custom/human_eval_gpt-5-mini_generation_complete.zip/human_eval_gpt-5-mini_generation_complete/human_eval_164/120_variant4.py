def maximum(arr, k):
    if k <= 0:
        return []
    n = len(arr)
    if k >= n:
        return sorted(arr)
    offset = 1000
    size = 2001
    counts = [0] * size
    for x in arr:
        counts[x + offset] += 1
    res = []
    need = k
    for val in range(size - 1, -1, -1):
        if counts[val] == 0:
            continue
        take = min(counts[val], need)
        res.extend([val - offset] * take)
        need -= take
        if need == 0:
            break
    res.sort()
    return res