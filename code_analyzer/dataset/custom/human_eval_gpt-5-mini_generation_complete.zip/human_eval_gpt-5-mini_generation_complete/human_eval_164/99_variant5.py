import math

def closest_integer(value):
    v = float(value)
    t = int(v)
    diff = abs(v - t)
    if diff < 0.5:
        return t
    if diff > 0.5:
        return t + 1 if v > 0 else t - 1
    if math.isclose(diff, 0.5, rel_tol=0.0, abs_tol=1e-12):
        return t + 1 if v > 0 else t - 1
    return t