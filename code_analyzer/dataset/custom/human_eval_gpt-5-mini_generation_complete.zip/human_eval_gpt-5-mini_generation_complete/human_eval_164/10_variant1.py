def is_palindrome(string: str) -> bool:
    return string == string[::-1]

# Classification response:
# helper function extraction; slicing; behavior change; empty input handling