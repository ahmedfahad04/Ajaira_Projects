def prod_signs(arr):
    if not arr:
        return None
    if any(x == 0 for x in arr):
        return 0
    neg_count = sum(1 for x in arr if x < 0)
    total_abs = sum(abs(x) for x in arr)
    sign = -1 if (neg_count % 2) else 1
    return total_abs * sign