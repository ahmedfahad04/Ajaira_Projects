def make_a_pile(n):
    return list(map(lambda i: n + 2 * i, range(n)))