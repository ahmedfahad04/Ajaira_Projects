def special_factorial(n):
    import math
    if n <= 0:
        return 1
    return math.prod(math.factorial(i) for i in range(1, n + 1))