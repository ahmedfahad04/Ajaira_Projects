from typing import List
from functools import reduce

def rolling_max(numbers: List[int]) -> List[int]:
    def reducer(acc: List[int], x: int) -> List[int]:
        if not acc:
            return [x]
        acc.append(acc[-1] if acc[-1] > x else x)
        return acc
    return reduce(reducer, numbers, [])