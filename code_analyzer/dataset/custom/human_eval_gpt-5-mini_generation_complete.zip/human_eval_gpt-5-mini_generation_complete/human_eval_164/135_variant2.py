def can_arrange(arr):
    n = len(arr)
    # collect all indices where current is less than previous
    bad = [i for i in range(1, n) if arr[i] < arr[i - 1]]
    return max(bad) if bad else -1