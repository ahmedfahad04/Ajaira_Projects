from typing import List, Any
from functools import reduce

def filter_integers(values: List[Any]) -> List[int]:
    # Use reduce to accumulate integers while skipping booleans
    return reduce(lambda acc, x: acc + [x] if isinstance(x, int) and not isinstance(x, bool) else acc, values, [])

# Classification response:
# function renaming; helper function extraction; import reorganization; functools reduce; lambda expression; accumulator list; combined condition; type check; behavior change