def flip_case(string: str) -> str:
    return string.swapcase()

# Classification response:
# helper function extraction; type annotations