def words_in_sentence(sentence):
    words = sentence.split()
    if not words:
        return ""
    max_len = max((len(w) for w in words), default=0)
    sieve = [True] * (max_len + 1)
    sieve[:2] = [False, False] if max_len >= 1 else [False]
    p = 2
    while p * p <= max_len:
        if sieve[p]:
            for multiple in range(p * p, max_len + 1, p):
                sieve[multiple] = False
        p += 1
    result = [w for w in words if sieve[len(w)]]
    return " ".join(result)