def compare(game,guess):
    if len(game) != len(guess):
        raise ValueError("game and guess must be the same length")
    res = []
    for i in range(len(game)):
        a = game[i]
        b = guess[i]
        res.append(0 if a == b else (a - b if a > b else b - a))
    return res