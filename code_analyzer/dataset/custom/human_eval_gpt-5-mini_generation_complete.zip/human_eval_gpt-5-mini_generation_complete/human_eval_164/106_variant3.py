def f(n):
    if n <= 0:
        return []
    def helper(i, fact):
        if i > n:
            return []
        fact *= i
        val = fact if i % 2 == 0 else i * (i + 1) // 2
        return [val] + helper(i + 1, fact)
    return helper(1, 1)