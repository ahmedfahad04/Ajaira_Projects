from typing import List
import math

def factorize(n: int) -> List[int]:
    if n is None:
        return []
    n = int(n)
    if n < 2:
        return []
    factors: List[int] = []
    # incremental prime generation using primes found so far
    primes: List[int] = [2]
    while n % 2 == 0:
        factors.append(2)
        n //= 2
    candidate = 3
    while n > 1 and candidate * candidate <= n:
        is_prime = True
        lim = int(math.isqrt(candidate))
        for p in primes:
            if p > lim:
                break
            if candidate % p == 0:
                is_prime = False
                break
        if is_prime:
            primes.append(candidate)
            while n % candidate == 0:
                factors.append(candidate)
                n //= candidate
        candidate += 2
    if n > 1:
        factors.append(n)
    return factors

# Classification response:
# variable renaming; import reorganization; early return; guard clause; loop rewrite; for loop; accumulator list; temporary variable; standard library helper; incremental prime generation; input validation; type conversion; boundary case handling