def largest_divisor(n: int) -> int:
    m = abs(n)
    if m <= 1:
        return 0
    for i in range(m // 2, 0, -1):
        if m % i == 0:
            return i
    return 0

# Classification response:
# helper function extraction;guard clause;loop rewrite;for loop;temporary variable;boundary case handling;error suppression