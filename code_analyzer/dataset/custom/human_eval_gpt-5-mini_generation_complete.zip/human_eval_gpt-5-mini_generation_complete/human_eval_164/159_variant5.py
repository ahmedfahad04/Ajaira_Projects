def eat(number, need, remaining):
    if need <= 0 or remaining <= 0:
        return [number, remaining if remaining >= 0 else 0]
    # recursive single-step consumption
    return eat(number + 1, need - 1, remaining - 1)