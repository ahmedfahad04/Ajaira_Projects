from fractions import Fraction
import math
def right_angle_triangle(a, b, c):
    sides = [a, b, c]
    if any(isinstance(x, float) and (math.isnan(x) or math.isinf(x)) for x in sides):
        return False
    if any(isinstance(x, float) for x in sides):
        try:
            s = sorted((float(a), float(b), float(c)))
        except Exception:
            return False
        if s[0] <= 0 or s[0] + s[1] <= s[2]:
            return False
        return math.isclose(s[0]*s[0] + s[1]*s[1], s[2]*s[2], rel_tol=1e-9, abs_tol=1e-9)
    try:
        f = sorted((Fraction(a), Fraction(b), Fraction(c)))
    except Exception:
        try:
            s = sorted((float(a), float(b), float(c)))
        except Exception:
            return False
        if s[0] <= 0 or s[0] + s[1] <= s[2]:
            return False
        return math.isclose(s[0]*s[0] + s[1]*s[1], s[2]*s[2], rel_tol=1e-9, abs_tol=1e-9)
    if f[0] <= 0 or f[0] + f[1] <= f[2]:
        return False
    return f[0]*f[0] + f[1]*f[1] == f[2]*f[2]