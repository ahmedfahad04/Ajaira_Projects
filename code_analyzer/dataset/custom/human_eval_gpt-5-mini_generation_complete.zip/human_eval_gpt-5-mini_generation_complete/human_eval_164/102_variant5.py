import math
def choose_num(x, y):
    if x > y:
        return -1
    L = math.ceil(x)
    U = math.floor(y)
    if U < L:
        return -1
    def find(u):
        if u < L:
            return -1
        if u % 2 == 0:
            return u
        return find(u - 1)
    return find(U)