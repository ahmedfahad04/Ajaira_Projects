from typing import List

def concatenate(strings: List[str]) -> str:
    return "".join(strings)

# Classification response:
# helper function extraction; import reorganization; standard library helper; type annotations; literal rewrite