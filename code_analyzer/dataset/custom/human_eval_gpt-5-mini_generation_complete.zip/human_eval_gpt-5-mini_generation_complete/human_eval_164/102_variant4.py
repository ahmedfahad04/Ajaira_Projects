import math
def choose_num(x, y):
    if x > y:
        return -1
    L = math.ceil(x)
    U = math.floor(y)
    if U < L:
        return -1
    evens = [n for n in range(L, U + 1) if n % 2 == 0]
    return max(evens) if evens else -1