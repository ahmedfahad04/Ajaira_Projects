from functools import reduce

def prod_signs(arr):
    if not arr:
        return None
    total_abs = sum(abs(x) for x in arr)
    def sgn(x):
        if x == 0:
            return 0
        return 1 if x > 0 else -1
    sign_product = reduce(lambda a, b: a * b, (sgn(x) for x in arr), 1)
    if sign_product == 0:
        return 0
    return total_abs * sign_product