from typing import List

def rescale_to_unit(numbers: List[float]) -> List[float]:
    if not numbers:
        return []
    lo = min(numbers)
    hi = max(numbers)
    if hi == lo:
        return [0.0 for _ in numbers]
    span = hi - lo
    return [(x - lo) / span for x in numbers]

# Classification response:
# variable renaming; helper function extraction; guard clause; early return; temporary variable; list comprehension; empty input handling; boundary case handling; type annotations added