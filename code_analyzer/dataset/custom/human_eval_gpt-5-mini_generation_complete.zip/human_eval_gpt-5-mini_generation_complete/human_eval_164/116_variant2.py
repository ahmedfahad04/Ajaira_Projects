def sort_array(arr):
    try:
        return sorted(arr, key=lambda x: (x.bit_count(), x))
    except AttributeError:
        return sorted(arr, key=lambda x: (bin(x).count('1'), x))