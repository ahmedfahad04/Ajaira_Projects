from decimal import Decimal, ROUND_HALF_UP

def closest_integer(value):
    s = value.strip()
    if 'e' in s or 'E' in s:
        return int(Decimal(s).quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    sign = 1
    if s.startswith('+'):
        s = s[1:]
    if s.startswith('-'):
        sign = -1
        s = s[1:]
    if '.' not in s:
        return sign * int(s) if s != '' else 0
    integer_part, frac_part = s.split('.', 1)
    if integer_part == '':
        integer_part = '0'
    whole = int(integer_part)
    if frac_part == '':
        frac_part = '0'
    first = frac_part[0] if frac_part else '0'
    tail = frac_part[1:] if len(frac_part) > 1 else ''
    if first > '5':
        res = whole + 1
    elif first < '5':
        res = whole
    else:
        if any(ch != '0' for ch in tail):
            res = whole + 1
        else:
            res = whole + 1
    return sign * res