from functools import reduce
import math

def sum_squares(lst):
    return reduce(lambda acc, x: acc + (math.ceil(x) ** 2), lst, 0)