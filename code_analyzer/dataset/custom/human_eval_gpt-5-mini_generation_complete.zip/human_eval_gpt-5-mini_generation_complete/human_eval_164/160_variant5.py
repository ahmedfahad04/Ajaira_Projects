def do_algebra(operator, operand):
    import ast, operator as op
    expr = str(operand[0])
    for o, v in zip(operator, operand[1:]):
        expr += " " + o + " " + str(v)
    tree = ast.parse(expr, mode='eval')
    BINOPS = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.FloorDiv: op.floordiv, ast.Pow: op.pow}
    def eval_node(n):
        if isinstance(n, ast.Expression):
            return eval_node(n.body)
        if isinstance(n, ast.BinOp):
            left = eval_node(n.left)
            right = eval_node(n.right)
            t = type(n.op)
            if t in BINOPS:
                return BINOPS[t](left, right)
            raise ValueError("Unsupported op")
        if isinstance(n, ast.Constant):
            return n.value
        if isinstance(n, ast.Num):
            return n.n
        raise ValueError("Unsupported node")
    return eval_node(tree)