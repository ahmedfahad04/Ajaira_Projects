def odd_count(lst):
    template = "the number of odd elements in the string i of the input."
    def count_odds(s):
        return sum(map(lambda c: int(c) % 2, s)) if s else 0
    return [template.replace("i", str(count_odds(s))) for s in lst]