from typing import List, Any

def filter_integers(values: List[Any]) -> List[int]:
    # Use type equality to avoid accepting bool (since bool is a subclass of int)
    return list(filter(lambda x: type(x) is int, values))

# Classification response:
# helper function extraction;map/filter usage;lambda expression;list conversion;import reorganization;type check;behavior change