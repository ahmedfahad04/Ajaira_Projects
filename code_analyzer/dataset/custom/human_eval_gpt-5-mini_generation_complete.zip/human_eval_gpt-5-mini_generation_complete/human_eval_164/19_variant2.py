def sort_numbers(numbers: str) -> str:
    order = ['zero','one','two','three','four','five','six','seven','eight','nine']
    s = numbers.strip()
    if not s:
        return ''
    parts = s.split()
    counts = {w:0 for w in order}
    for p in parts:
        counts[p] = counts.get(p, 0) + 1
    out = []
    for w in order:
        if counts[w]:
            out.extend([w]*counts[w])
    return ' '.join(out)

# Classification response:
# helper function extraction;guard clause;loop rewrite;for loop;accumulator dict;dict comprehension;frequency counting;empty input handling;join/split usage