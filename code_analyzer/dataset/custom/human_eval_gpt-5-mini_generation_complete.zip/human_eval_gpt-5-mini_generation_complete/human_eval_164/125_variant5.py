def split_words(txt):
    has_space = False
    for c in txt:
        if c.isspace():
            has_space = True
            break
    if has_space:
        return txt.split()
    if ',' in txt:
        return [p for p in txt.split(',')]
    return sum(map(lambda ch: 1 if ('a' <= ch <= 'z' and ((ord(ch) - ord('a')) & 1)) else 0, txt))