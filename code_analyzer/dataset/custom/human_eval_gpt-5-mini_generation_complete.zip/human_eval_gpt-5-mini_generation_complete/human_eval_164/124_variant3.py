def valid_date(date):
    if not date or not isinstance(date, str):
        return False
    if len(date) != 10:
        return False
    if date[2] != '-' or date[5] != '-':
        return False
    mm = date[:2]
    dd = date[3:5]
    yyyy = date[6:]
    if not (mm.isdigit() and dd.isdigit() and yyyy.isdigit()):
        return False
    month = int(mm)
    day = int(dd)
    if month < 1 or month > 12:
        return False
    if day < 1:
        return False
    if month == 2:
        return day <= 29
    if month in (4, 6, 9, 11):
        return day <= 30
    return day <= 31