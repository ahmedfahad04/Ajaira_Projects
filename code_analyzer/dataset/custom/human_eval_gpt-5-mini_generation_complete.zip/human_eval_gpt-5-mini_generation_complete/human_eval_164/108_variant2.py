def count_nums(arr):
    def signed_digit_sum(n):
        if n >= 0:
            s = 0
            while n:
                s += n % 10
                n //= 10
            return s
        else:
            m = abs(n)
            if m == 0:
                return 0
            s = 0
            most = 0
            while m:
                d = m % 10
                s += d
                most = d
                m //= 10
            return s - 2 * most

    cnt = 0
    for x in arr:
        if signed_digit_sum(x) > 0:
            cnt += 1
    return cnt