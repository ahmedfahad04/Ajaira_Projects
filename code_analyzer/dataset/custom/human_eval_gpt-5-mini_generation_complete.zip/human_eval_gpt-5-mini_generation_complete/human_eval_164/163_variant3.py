def generate_integers(a, b):
    low, high = min(a, b), max(a, b)
    allowed = {0, 2, 4, 6, 8}
    in_range = set(range(max(0, low), min(9, high) + 1))
    return sorted(list(allowed & in_range))