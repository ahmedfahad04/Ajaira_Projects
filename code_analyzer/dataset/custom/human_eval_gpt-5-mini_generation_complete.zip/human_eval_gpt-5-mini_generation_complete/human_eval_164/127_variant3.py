def intersection(interval1, interval2):
    a1, b1 = interval1
    a2, b2 = interval2
    start = max(a1, a2)
    end = min(b1, b2)
    if end < start:
        return "NO"
    n = end - start
    if n < 2:
        return "NO"
    # Deterministic Miller-Rabin for 64-bit integers
    def is_prime(n):
        if n < 2:
            return False
        small_primes = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29)
        for p in small_primes:
            if n % p == 0:
                return n == p
        d = n - 1
        s = 0
        while d % 2 == 0:
            d //= 2
            s += 1
        # bases sufficient for testing 64-bit ints
        for a in (2, 325, 9375, 28178, 450775, 9780504, 1795265022):
            if a % n == 0:
                continue
            x = pow(a, d, n)
            if x == 1 or x == n - 1:
                continue
            skip_to_next_n = False
            for _ in range(s - 1):
                x = (x * x) % n
                if x == n - 1:
                    skip_to_next_n = True
                    break
            if skip_to_next_n:
                continue
            return False
        return True
    return "YES" if is_prime(n) else "NO"