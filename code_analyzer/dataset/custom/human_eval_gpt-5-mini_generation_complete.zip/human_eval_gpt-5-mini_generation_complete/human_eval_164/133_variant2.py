import math

def sum_squares(lst):
    return sum(map(lambda v: pow(math.ceil(v), 2), lst))