def sum_squares(lst):
    total = 0
    for x in lst:
        xi = int(x)
        if x > xi:
            c = xi + 1
        else:
            c = xi
        total += c * c
    return total