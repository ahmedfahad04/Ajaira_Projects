def strlen(string: str) -> int:
    i = 0
    try:
        while True:
            _ = string[i]
            i += 1
    except IndexError:
        return i

# Classification response:
# function renaming;while loop;index-based loop;try-except wrapper;state variable;brute force;behavior change