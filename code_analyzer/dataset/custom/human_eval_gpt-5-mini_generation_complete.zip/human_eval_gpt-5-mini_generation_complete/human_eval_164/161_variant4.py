def solve(s):
    letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    swapped = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    trans = str.maketrans(letters, swapped)
    if any(c.isalpha() for c in s):
        return s.translate(trans)
    return s[::-1]