def valid_date(date):
    if not date or not isinstance(date, str):
        return False
    parts = date.split('-')
    if len(parts) != 3:
        return False
    m, d, y = parts
    if not (m.isdigit() and d.isdigit() and y.isdigit()):
        return False
    if len(y) != 4:
        return False
    try:
        month = int(m)
        day = int(d)
    except ValueError:
        return False
    if month < 1 or month > 12:
        return False
    if day < 1:
        return False
    if month in (1, 3, 5, 7, 8, 10, 12):
        return day <= 31
    if month in (4, 6, 9, 11):
        return day <= 30
    return day <= 29