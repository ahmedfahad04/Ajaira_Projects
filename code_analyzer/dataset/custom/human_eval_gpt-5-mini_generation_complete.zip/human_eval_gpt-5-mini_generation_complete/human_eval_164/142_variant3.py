def sum_squares(lst):
    # iterative index-based loop
    n = len(lst)
    i = 0
    s = 0
    while i < n:
        v = lst[i]
        if i % 3 == 0:
            s += v**2
        elif i % 4 == 0:
            s += v**3
        else:
            s += v
        i += 1
    return s