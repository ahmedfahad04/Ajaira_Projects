def minSubArraySum(nums):
    if not nums:
        return 0
    # compute max subarray sum of negated array, then negate result
    neg = [-x for x in nums]
    max_ending = neg[0]
    max_so_far = neg[0]
    for x in neg[1:]:
        max_ending = x if x > max_ending + x else max_ending + x
        if max_ending > max_so_far:
            max_so_far = max_ending
    return -max_so_far