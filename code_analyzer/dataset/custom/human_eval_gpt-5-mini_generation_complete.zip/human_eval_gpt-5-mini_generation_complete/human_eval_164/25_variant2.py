from typing import List

def factorize(n: int) -> List[int]:
    if n is None:
        return []
    n = int(n)
    if n < 2:
        return []
    factors: List[int] = []
    # handle 2 and 3
    while n % 2 == 0:
        factors.append(2)
        n //= 2
    while n % 3 == 0:
        factors.append(3)
        n //= 3
    # 6k +/- 1 optimization
    i = 5
    while i * i <= n:
        for d in (i, i + 2):
            while n % d == 0:
                factors.append(d)
                n //= d
        i += 6
    if n > 1:
        factors.append(n)
    return factors

# Classification response:
# variable renaming; guard clause; loop rewrite; for loop; while loop; accumulator list; type conversion; input validation; boundary case handling; import reorganization; mathematical formula