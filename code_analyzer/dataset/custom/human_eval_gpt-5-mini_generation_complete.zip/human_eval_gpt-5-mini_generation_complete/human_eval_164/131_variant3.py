def digits(n):
    n = abs(int(n))
    def helper(x):
        if x == 0:
            return (1, False)
        p, f = helper(x // 10)
        d = x % 10
        if d % 2 == 1:
            return (p * d, True)
        return (p, f)
    prod, found = helper(n)
    # special-case n==0 (no digits) -> return 0
    if n == 0:
        return 0
    return prod if found else 0