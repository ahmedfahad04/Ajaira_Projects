from typing import List

def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """Return list of strings that contain substring using filter and lambda."""
    return list(filter(lambda s: substring in s, strings))