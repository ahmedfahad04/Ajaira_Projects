def string_xor(a: str, b: str) -> str:
    if a == '' and b == '':
        return ''
    A = int(a or '0', 2)
    B = int(b or '0', 2)
    res = A ^ B
    return format(res, 'b').zfill(max(len(a), len(b)))

# Classification response:
# function renaming; helper function inlining; guard clause; type conversion; temporary variable; string formatting change; empty input handling; behavior change; builtin function