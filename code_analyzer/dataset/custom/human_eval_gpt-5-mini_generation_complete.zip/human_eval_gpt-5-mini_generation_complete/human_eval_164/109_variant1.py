def move_one_ball(arr):
    if not arr:
        return True
    n = len(arr)
    # try all right shifts
    for k in range(n):
        if k == 0:
            rotated = arr[:]
        else:
            rotated = arr[-k:] + arr[:-k]
        ok = True
        for i in range(len(rotated) - 1):
            if rotated[i] > rotated[i + 1]:
                ok = False
                break
        if ok:
            return True
    return False