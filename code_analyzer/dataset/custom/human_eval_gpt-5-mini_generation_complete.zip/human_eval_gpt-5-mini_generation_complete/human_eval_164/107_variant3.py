def even_odd_palindrome(n):
    pals = set()
    max_len = len(str(n))
    for L in range(1, max_len + 1):
        half_len = (L + 1) // 2
        start = 1 if half_len == 1 else 10 ** (half_len - 1)
        end = 10 ** half_len
        for half in range(start, end):
            s = str(half)
            if L % 2 == 0:
                p = int(s + s[::-1])
            else:
                p = int(s + s[:-1][::-1])
            if p > n:
                continue
            pals.add(p)
    ev = sum(1 for x in pals if x % 2 == 0)
    od = sum(1 for x in pals if x % 2 == 1)
    return (ev, od)