def special_factorial(n):
    import math
    if n <= 1:
        return 1
    return math.factorial(n) * special_factorial(n - 1)