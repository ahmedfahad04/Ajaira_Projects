import re
def words_string(s):
    if s is None:
        return []
    return re.findall(r'[^,\s]+', s)