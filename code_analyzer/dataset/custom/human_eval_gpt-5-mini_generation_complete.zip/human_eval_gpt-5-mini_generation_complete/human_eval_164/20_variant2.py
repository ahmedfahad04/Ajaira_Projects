from typing import List, Tuple
import math

def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    n = len(numbers)
    if n < 2:
        raise ValueError("At least two numbers required")
    best_diff = math.inf
    best_pair = None
    for i in range(n):
        for j in range(i+1, n):
            a, b = numbers[i], numbers[j]
            d = abs(a - b)
            if d < best_diff:
                best_diff = d
                best_pair = (a, b)
    a, b = best_pair
    return (a, b) if a <= b else (b, a)

# Classification response:
# function renaming; variable renaming; loop rewrite; index-based loop; flattened conditional; temporary variable; tuple unpacking; conditional expression; guard clause; input validation; boundary case handling; standard library helper; brute force