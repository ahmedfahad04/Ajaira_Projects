from typing import List

def separate_paren_groups(paren_string: str) -> List[str]:
    s = paren_string.replace(" ", "")
    if not s:
        return []
    res = []
    cur = []
    depth = 0
    for ch in s:
        if ch not in "()":
            continue
        cur.append(ch)
        if ch == "(":
            depth += 1
        else:
            depth -= 1
        if depth == 0 and cur:
            res.append("".join(cur))
            cur = []
    return res