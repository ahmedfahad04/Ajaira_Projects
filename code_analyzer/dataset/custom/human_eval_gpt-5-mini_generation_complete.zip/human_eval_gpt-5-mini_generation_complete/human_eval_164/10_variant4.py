def is_palindrome(string: str) -> bool:
    return string == ''.join(reversed(string))

# Classification response:
# builtin function; join/split usage