def sorted_list_sum(lst):
    from functools import cmp_to_key
    def cmp(a, b):
        la, lb = len(a), len(b)
        if la != lb:
            return la - lb
        if a < b:
            return -1
        if a > b:
            return 1
        return 0
    filtered = [s for s in lst if len(s) % 2 == 0]
    return sorted(filtered, key=cmp_to_key(cmp))