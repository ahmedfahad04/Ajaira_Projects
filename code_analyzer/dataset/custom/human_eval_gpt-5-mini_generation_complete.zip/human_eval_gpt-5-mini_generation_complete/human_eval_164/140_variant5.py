import re
def fix_spaces(text):
    if not text:
        return text
    out = []
    last = 0
    for m in re.finditer(r' +', text):
        start, end = m.start(), m.end()
        out.append(text[last:start])
        cnt = end - start
        out.append('-' if cnt > 2 else '_' * cnt)
        last = end
    out.append(text[last:])
    return ''.join(out)