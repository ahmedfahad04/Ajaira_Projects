from itertools import zip_longest

def string_xor(a: str, b: str) -> str:
    def rec(i):
        if i >= max(len(a), len(b)):
            return ''
        x = a[i] if i < len(a) else '0'
        y = b[i] if i < len(b) else '0'
        return ('1' if x != y else '0') + rec(i + 1)
    return rec(0)

# Classification response:
# function renaming;recursion with base case;helper function extraction;index-based loop;accumulator string;import reorganization;boundary case handling;default value handling;behavior change;generator expression