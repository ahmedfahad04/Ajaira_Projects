from typing import List
import itertools

def parse_nested_parens(paren_string: str) -> List[int]:
    groups = [g for g in paren_string.split() if g]
    out: List[int] = []
    for g in groups:
        if not g:
            out.append(0)
            continue
        vals = (1 if c == '(' else -1 for c in g)
        acc = list(itertools.accumulate(vals))
        out.append(max(acc) if acc else 0)
    return out