def smallest_change(arr):
    n = len(arr)
    cnt = 0
    for i in range(n // 2):
        if arr[i] != arr[n - 1 - i]:
            cnt += 1
    return cnt

# Classification response:
# function renaming; variable renaming; temporary variable; index-based loop