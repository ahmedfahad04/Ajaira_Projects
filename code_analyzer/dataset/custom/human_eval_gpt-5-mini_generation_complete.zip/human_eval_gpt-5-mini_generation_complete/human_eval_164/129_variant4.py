def minPath(grid, k):
    n = len(grid)
    # find coordinates of smallest value (1)
    found = False
    for i in range(n):
        for j in range(n):
            if grid[i][j] == 1:
                x, y = i, j
                found = True
                break
        if found:
            break
    res = [1]
    # iterative recursion-like construction
    stack = [(x, y)]
    dirs = [(0,1),(0,-1),(1,0),(-1,0)]
    for _ in range(k-1):
        x, y = stack[-1]
        # find smallest neighbor
        best_val = None
        best_pos = None
        for dx, dy in dirs:
            nx, ny = x+dx, y+dy
            if 0 <= nx < n and 0 <= ny < n:
                val = grid[nx][ny]
                if best_val is None or val < best_val:
                    best_val = val
                    best_pos = (nx, ny)
        res.append(best_val)
        stack.append(best_pos)
    return res