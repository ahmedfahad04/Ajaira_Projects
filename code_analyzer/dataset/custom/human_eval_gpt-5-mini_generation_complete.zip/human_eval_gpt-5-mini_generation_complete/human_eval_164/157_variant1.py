import math
def right_angle_triangle(a, b, c):
    try:
        s = sorted((float(a), float(b), float(c)))
    except Exception:
        s = sorted((a, b, c))
    if s[0] <= 0:
        return False
    if s[0] + s[1] <= s[2]:
        return False
    return math.isclose(s[0] * s[0] + s[1] * s[1], s[2] * s[2], rel_tol=1e-9, abs_tol=1e-9)