from typing import List

def mean_absolute_deviation(numbers: List[float]) -> float:
    length = len(numbers)
    if length == 0:
        return 0.0
    # compute mean with a single pass accumulation then compute deviations in a second pass with explicit loop
    s = 0.0
    for x in numbers:
        s += x
    mean = s / length
    abs_sum = 0.0
    for x in numbers:
        diff = x - mean
        if diff < 0:
            diff = -diff
        abs_sum += diff
    return abs_sum / length