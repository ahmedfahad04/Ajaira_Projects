def int_to_mini_roman(number):
    if not (1 <= number <= 1000):
        raise ValueError("number out of range")
    thousands = ["", "m"]
    hundreds = ["", "c", "cc", "ccc", "cd", "d", "dc", "dcc", "dccc", "cm"]
    tens = ["", "x", "xx", "xxx", "xl", "l", "lx", "lxx", "lxxx", "xc"]
    ones = ["", "i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix"]
    t = number // 1000
    h = (number % 1000) // 100
    te = (number % 100) // 10
    o = number % 10
    return (thousands[t] + hundreds[h] + tens[te] + ones[o])