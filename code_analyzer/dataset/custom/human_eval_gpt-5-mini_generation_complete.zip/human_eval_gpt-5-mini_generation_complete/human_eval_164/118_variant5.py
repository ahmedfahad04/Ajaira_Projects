def get_closest_vowel(word):
    vowels = set("aeiouAEIOU")
    if len(word) < 3:
        return ""
    triples = list(zip(word, word[1:], word[2:]))
    for k in range(len(triples) - 1, -1, -1):
        prev, mid, nxt = triples[k]
        if mid in vowels and prev not in vowels and nxt not in vowels:
            return mid
    return ""