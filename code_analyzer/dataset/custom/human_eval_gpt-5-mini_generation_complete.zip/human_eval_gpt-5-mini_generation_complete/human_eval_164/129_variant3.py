def minPath(grid, k):
    n = len(grid)
    # precompute adjacency lists of neighbor values, sorted ascending
    adj = {}
    dirs = [(1,0),(-1,0),(0,1),(0,-1)]
    for i in range(n):
        for j in range(n):
            v = grid[i][j]
            neigh = []
            for dx, dy in dirs:
                ni, nj = i+dx, j+dy
                if 0 <= ni < n and 0 <= nj < n:
                    neigh.append(grid[ni][nj])
            neigh.sort()
            adj[v] = neigh
    # start at value 1
    cur = 1
    res = [1]
    for _ in range(k-1):
        # smallest neighbor value available
        cur = adj[cur][0]
        res.append(cur)
    return res