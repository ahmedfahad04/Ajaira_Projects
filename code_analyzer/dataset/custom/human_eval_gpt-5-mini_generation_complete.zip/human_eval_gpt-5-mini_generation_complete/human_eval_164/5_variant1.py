from typing import List

def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    n = len(numbers)
    if n <= 1:
        return numbers[:] if n == 1 else []
    res: List[int] = []
    for i, v in enumerate(numbers):
        res.append(v)
        if i != n - 1:
            res.append(delimeter)
    return res