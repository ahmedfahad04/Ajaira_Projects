import re
def valid_date(date):
    if not date or not isinstance(date, str):
        return False
    if not re.fullmatch(r"\d{2}-\d{2}-\d{4}", date):
        return False
    m = int(date[0:2])
    d = int(date[3:5])
    if m < 1 or m > 12:
        return False
    if d < 1:
        return False
    if m == 2:
        return d <= 29
    if m in (4, 6, 9, 11):
        return d <= 30
    return d <= 31