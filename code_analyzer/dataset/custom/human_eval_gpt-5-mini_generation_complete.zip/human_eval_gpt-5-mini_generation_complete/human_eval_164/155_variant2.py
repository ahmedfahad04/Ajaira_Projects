def even_odd_count(num):
    n = abs(int(num))
    if n == 0:
        return (1, 0)
    even = odd = 0
    while n:
        d = n % 10
        if d % 2 == 0:
            even += 1
        else:
            odd += 1
        n //= 10
    return (even, odd)