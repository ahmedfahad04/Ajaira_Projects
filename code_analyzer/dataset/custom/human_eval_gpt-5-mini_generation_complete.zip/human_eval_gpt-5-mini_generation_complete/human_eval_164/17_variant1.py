from typing import List

def parse_music(music_string: str) -> List[int]:
    mapping = {'o': 4, 'o|': 2, '.|': 1}
    # split on whitespace and map tokens
    tokens = music_string.split()
    return [mapping[token] for token in tokens if token]

# Classification response:
# variable renaming; helper function extraction; import reorganization; standard library helper; temporary variable; join/split usage; list comprehension