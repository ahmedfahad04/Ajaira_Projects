def rounded_avg(n, m):
    if n > m:
        return -1
    total = 0
    count = 0
    x = n
    while x <= m:
        total += x
        count += 1
        x += 1
    # compute average and use Python's round (bankers rounding)
    avg = round(total / count)
    return bin(int(avg))