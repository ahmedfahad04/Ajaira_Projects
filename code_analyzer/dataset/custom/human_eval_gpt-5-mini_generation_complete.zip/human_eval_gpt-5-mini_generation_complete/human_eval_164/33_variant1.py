def sort_third(l: list):
    if not l:
        return []
    vals = [v for i, v in enumerate(l) if i % 3 == 0]
    vals.sort()
    res = list(l)
    vi = 0
    for i in range(len(res)):
        if i % 3 == 0:
            res[i] = vals[vi]
            vi += 1
    return res

# Classification response:
# list comprehension; enumerate loop; index-based loop; guard clause; empty input handling; in-place mutation; copy before mutation; temporary variable; state variable