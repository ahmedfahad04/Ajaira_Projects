import math

def closest_integer(value):
    v = float(value)
    sign = 1 if v >= 0 else -1
    a = abs(v)
    whole = math.floor(a)
    frac = a - whole
    eps = 1e-12
    if frac > 0.5 + eps:
        res = whole + 1
    elif frac < 0.5 - eps:
        res = whole
    else:
        res = whole + 1
    return sign * res