def digits(n):
    n = abs(int(n))
    s = str(n)
    prod = 1
    any_odd = False
    for ch in s:
        d = ord(ch) - 48
        if d & 1:
            prod *= d
            any_odd = True
    return prod if any_odd else 0