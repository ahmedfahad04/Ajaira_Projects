import re
from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    parts = [p for p in paren_string.split() if p != ""]
    depths: List[int] = []
    for s in parts:
        d = 0
        while s:
            new = re.sub(r'\(\)', '', s)
            if new == s:
                break
            d += 1
            s = new
        depths.append(d)
    return depths