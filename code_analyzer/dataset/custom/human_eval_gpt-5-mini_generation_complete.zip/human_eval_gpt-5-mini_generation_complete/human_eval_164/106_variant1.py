def f(n):
    res = []
    if n <= 0:
        return res
    fact = 1
    for i in range(1, n + 1):
        fact *= i
        if i % 2 == 0:
            res.append(fact)
        else:
            res.append(i * (i + 1) // 2)
    return res