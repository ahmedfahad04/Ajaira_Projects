def do_algebra(operator, operand):
    ops = operator[:]
    vals = operand[:]
    # handle exponentiation right-to-left
    while '**' in ops:
        i = max(idx for idx, o in enumerate(ops) if o == '**')
        computed = vals[i] ** vals[i+1]
        vals[i] = computed
        del vals[i+1]
        del ops[i]
    # handle * and // left-to-right
    new_ops = []
    new_vals = [vals[0]]
    for i, op in enumerate(ops):
        if op == '*' or op == '//':
            if op == '*':
                new_vals[-1] = new_vals[-1] * vals[i+1]
            else:
                new_vals[-1] = new_vals[-1] // vals[i+1]
        else:
            new_ops.append(op)
            new_vals.append(vals[i+1])
    # handle + and - left-to-right
    result = new_vals[0]
    for i, op in enumerate(new_ops):
        if op == '+':
            result += new_vals[i+1]
        else:
            result -= new_vals[i+1]
    return result