def add_elements(arr, k):
    def helper(i):
        if i >= k or i >= len(arr):
            return 0
        val = arr[i]
        return (val if abs(val) <= 99 else 0) + helper(i+1)
    return helper(0)