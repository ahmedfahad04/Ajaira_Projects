def get_positive(l: list):
    return list(filter(lambda x: x > 0, l))

# Classification response:
# helper function extraction; map/filter usage; lambda expression; list conversion; variable renaming