def string_sequence(n: int) -> str:
    if n < 0:
        return ''
    def build(k: int) -> str:
        if k == 0:
            return "0"
        return build(k - 1) + " " + str(k)
    return build(n)

# Classification response:
# recursion with base case; helper function extraction; guard clause; empty input handling; list comprehension; join/split usage; accumulator string