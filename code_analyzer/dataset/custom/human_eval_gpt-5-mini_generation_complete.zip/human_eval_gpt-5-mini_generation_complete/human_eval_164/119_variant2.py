def match_parens(lst):
    a, b = lst[0], lst[1]
    def balance_and_min(s):
        bal = 0
        min_pref = 0
        for ch in s:
            if ch == '(':
                bal += 1
            else:
                bal -= 1
            min_pref = min(min_pref, bal)
        return bal, min_pref
    bal_a, min_a = balance_and_min(a)
    bal_b, min_b = balance_and_min(b)
    # final balance must be zero
    if bal_a + bal_b != 0:
        return 'No'
    # check order a then b
    if min_a >= 0 and min_b + bal_a >= 0:
        return 'Yes'
    # check order b then a
    if min_b >= 0 and min_a + bal_b >= 0:
        return 'Yes'
    return 'No'