def can_arrange(arr):
    def helper(i):
        if i <= 0:
            return -1
        if arr[i] < arr[i-1]:
            return i
        return helper(i-1)
    return helper(len(arr)-1)