import math

def x_or_y(n, x, y):
    if not isinstance(n, int):
        try:
            n = int(n)
        except:
            return y
    if n <= 1:
        return y
    if n <= 3:
        return x
    if n % 2 == 0:
        return y
    limit = int(math.isqrt(n))
    i = 3
    while i <= limit:
        if n % i == 0:
            return y
        i += 2
    return x