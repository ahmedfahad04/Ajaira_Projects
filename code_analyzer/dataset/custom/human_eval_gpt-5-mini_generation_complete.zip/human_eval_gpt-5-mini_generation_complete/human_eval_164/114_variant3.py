def minSubArraySum(nums):
    n = len(nums)
    if n == 0:
        return 0
    pref = [0] * (n + 1)
    for i in range(n):
        pref[i+1] = pref[i] + nums[i]
    ans = float('inf')
    for i in range(n):
        for j in range(i+1, n+1):
            s = pref[j] - pref[i]
            if s < ans:
                ans = s
    return ans