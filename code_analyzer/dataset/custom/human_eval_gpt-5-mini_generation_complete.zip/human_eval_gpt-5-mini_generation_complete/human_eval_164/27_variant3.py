def flip_case(string: str) -> str:
    import string as _s
    lower = _s.ascii_lowercase
    upper = _s.ascii_uppercase
    trans = str.maketrans(lower + upper, upper + lower)
    return string.translate(trans)

# Classification response:
# helper function extraction; import reorganization; standard library helper; temporary variable; behavior change