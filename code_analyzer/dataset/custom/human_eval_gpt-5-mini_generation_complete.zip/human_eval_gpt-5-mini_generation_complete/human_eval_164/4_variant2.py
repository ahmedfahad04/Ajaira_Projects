from typing import List
import math
import statistics

def mean_absolute_deviation(numbers: List[float]) -> float:
    if not numbers:
        return 0.0
    mean = statistics.mean(numbers)
    # use math.fsum for better floating point summation
    total_abs = math.fsum((abs(x - mean) for x in numbers))
    return total_abs / len(numbers)