import math
def largest_divisor(n: int) -> int:
    m = abs(n)
    if m <= 1:
        return 0
    divs = {1}
    r = int(math.isqrt(m))
    for i in range(1, r + 1):
        if m % i == 0:
            divs.add(i)
            divs.add(m // i)
    if m in divs:
        divs.remove(m)
    return max(divs) if divs else 0

# Classification response:
# helper function extraction; loop rewrite; for loop; accumulator set; temporary variable; standard library helper; builtin function; conditional expression; boundary case handling; sqrt factorization