def flip_case(string: str) -> str:
    import re
    return re.sub(r'[A-Za-z]', lambda m: m.group(0).lower() if m.group(0).isupper() else m.group(0).upper(), string)

# Classification response:
# function renaming; helper function extraction; import reorganization; regex usage; lambda expression