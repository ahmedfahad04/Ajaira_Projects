def simplify(x, n):
    import math
    a, b = map(int, x.split('/'))
    c, d = map(int, n.split('/'))
    num = a * c
    den = b * d
    while True:
        g = math.gcd(num, den)
        if g == 1:
            break
        num //= g
        den //= g
    return den == 1