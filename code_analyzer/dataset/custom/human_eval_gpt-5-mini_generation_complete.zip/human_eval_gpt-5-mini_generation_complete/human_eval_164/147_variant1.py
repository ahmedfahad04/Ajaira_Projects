def get_max_triples(n):
    def choose3(x):
        if x < 3:
            return 0
        return x * (x - 1) * (x - 2) // 6
    c0 = (n + 1) // 3
    c1 = n - c0
    return choose3(c0) + choose3(c1)