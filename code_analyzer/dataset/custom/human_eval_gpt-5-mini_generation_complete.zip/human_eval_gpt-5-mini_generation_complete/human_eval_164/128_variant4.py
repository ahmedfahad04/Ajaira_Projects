def prod_signs(arr):
    if not arr:
        return None
    # recursive helper returns (sum_abs, sign_prod)
    def helper(i):
        if i == len(arr):
            return (0, 1)
        if arr[i] == 0:
            return (0, 0)
        s_abs, s_sign = helper(i + 1)
        if s_sign == 0:
            return (0, 0)
        cur_sign = 1 if arr[i] > 0 else -1
        return (abs(arr[i]) + s_abs, cur_sign * s_sign)
    total_abs, sign = helper(0)
    if sign == 0:
        return 0
    return total_abs * sign