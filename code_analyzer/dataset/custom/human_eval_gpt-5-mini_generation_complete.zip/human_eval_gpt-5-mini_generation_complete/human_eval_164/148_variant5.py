def bf(planet1, planet2):
    planets = ("Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune")
    try:
        i = planets.index(planet1)
        j = planets.index(planet2)
    except ValueError:
        return ()
    if i == j:
        return ()
    a, b = (i, j) if i < j else (j, i)
    # slice returns tuple when applied to tuple
    return planets[a+1:b]