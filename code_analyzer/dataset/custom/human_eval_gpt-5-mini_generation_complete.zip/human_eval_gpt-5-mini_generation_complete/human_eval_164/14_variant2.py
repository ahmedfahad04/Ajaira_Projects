from typing import List

def all_prefixes(string: str) -> List[str]:
    prefixes: List[str] = []
    current = ""
    for ch in string:
        current += ch
        prefixes.append(current)
    return prefixes

# Classification response:
# function renaming; variable renaming; helper function extraction; loop rewrite; accumulator string; import reorganization