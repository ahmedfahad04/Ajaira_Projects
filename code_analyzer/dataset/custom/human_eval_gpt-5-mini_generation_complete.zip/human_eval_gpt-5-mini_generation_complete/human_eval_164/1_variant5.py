from typing import List

def separate_paren_groups(paren_string: str) -> List[str]:
    s = "".join(ch for ch in paren_string if ch in "()")
    res = []
    i = 0
    n = len(s)
    while i < n:
        if s[i] != "(":
            i += 1
            continue
        depth = 0
        j = i
        while j < n:
            if s[j] == "(":
                depth += 1
            else:
                depth -= 1
            j += 1
            if depth == 0:
                break
        if depth == 0:
            res.append(s[i:j])
            i = j
        else:
            break
    return res