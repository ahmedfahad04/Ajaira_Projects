def count_upper(s):
    vowels = {'A', 'E', 'I', 'O', 'U'}
    count = 0
    for i, ch in enumerate(s):
        if i % 2 == 0 and ch in vowels:
            count += 1
    return count