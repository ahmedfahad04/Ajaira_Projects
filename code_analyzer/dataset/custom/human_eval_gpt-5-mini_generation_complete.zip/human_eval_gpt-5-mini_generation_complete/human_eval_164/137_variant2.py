def compare_one(a, b):
    from decimal import Decimal, InvalidOperation, getcontext
    getcontext().prec = 28
    def to_decimal(x):
        if isinstance(x, str):
            s = x.strip().replace(',', '.')
            return Decimal(s)
        # use str() for floats to avoid binary representation issues
        return Decimal(str(x))
    try:
        da = to_decimal(a)
        db = to_decimal(b)
    except (InvalidOperation, ValueError):
        if a == b:
            return None
        return a if a > b else b
    if da == db:
        return None
    return a if da > db else b