def Strongest_Extension(class_name, extensions):
    if not extensions:
        return class_name + '.'
    strengths = []
    for ext in extensions:
        caps = sum(1 for c in ext if c.isupper())
        lows = sum(1 for c in ext if c.islower())
        strengths.append(caps - lows)
    max_strength = max(strengths)
    idx = next(i for i, s in enumerate(strengths) if s == max_strength)
    return class_name + '.' + extensions[idx]