def get_odd_collatz(n):
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer")
    seen = set()
    def helper(x):
        if x % 2 == 1:
            seen.add(x)
        if x == 1:
            return
        if x % 2 == 0:
            helper(x // 2)
        else:
            helper(3 * x + 1)
    helper(n)
    return sorted(seen)