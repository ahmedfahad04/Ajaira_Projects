def get_max_triples(n):
    # direct closed formulas by n mod 3 for c0 = (n+1)//3
    r = n % 3
    if r == 0:
        c0 = (n // 3)
    elif r == 1:
        c0 = (n // 3)
    else:  # r == 2
        c0 = (n // 3) + 1
    # note above is equivalent to (n+1)//3 but written differently
    c1 = n - c0
    if c0 < 3 and c1 < 3:
        return 0
    def combos(k):
        return 0 if k < 3 else (k * (k - 1) * (k - 2) // 6)
    return combos(c0) + combos(c1)