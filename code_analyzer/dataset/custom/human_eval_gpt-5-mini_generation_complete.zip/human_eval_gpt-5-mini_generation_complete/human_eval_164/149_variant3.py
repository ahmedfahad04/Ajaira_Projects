def sorted_list_sum(lst):
    from collections import defaultdict
    groups = defaultdict(list)
    for s in lst:
        if len(s) % 2 == 0:
            groups[len(s)].append(s)
    result = []
    for l in sorted(groups.keys()):
        result.extend(sorted(groups[l]))
    return result