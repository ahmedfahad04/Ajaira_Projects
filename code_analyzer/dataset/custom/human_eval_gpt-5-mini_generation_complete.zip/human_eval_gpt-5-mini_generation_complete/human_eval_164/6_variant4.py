from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    def depth_of_group(s: str) -> int:
        n = len(s)
        if n == 0:
            return 0
        def scan(i: int):
            # s[i] == '('
            i += 1
            max_child = 0
            while i < n and s[i] != ')':
                if s[i] == '(':
                    child_depth, i = scan(i)
                    if child_depth > max_child:
                        max_child = child_depth
                else:
                    i += 1
            i += 1  # consume ')'
            return max_child + 1, i
        depth = 0
        i = 0
        while i < n:
            if s[i] == '(':
                d, i = scan(i)
                if d > depth:
                    depth = d
            else:
                i += 1
        return depth

    return [depth_of_group(g) for g in paren_string.split() if g != ""]