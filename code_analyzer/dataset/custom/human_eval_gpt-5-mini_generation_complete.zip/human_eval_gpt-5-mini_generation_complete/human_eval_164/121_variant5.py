def solution(lst):
    import itertools
    return sum(x for x in itertools.islice(lst, 0, None, 2) if x & 1)