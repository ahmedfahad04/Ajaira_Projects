def select_words(s, n):
    import re
    words = re.findall(r"[A-Za-z]+", s)
    out = []
    for w in words:
        consonants = re.sub(r"(?i)[aeiou]", "", w)
        if len(consonants) == n:
            out.append(w)
    return out