from typing import List

def below_zero(operations: List[int]) -> bool:
    def gen():
        b = 0
        for op in operations:
            b += op
            yield b
    return any(v < 0 for v in gen())