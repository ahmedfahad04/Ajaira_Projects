def multiply(a, b):
    a_abs = abs(a)
    b_abs = abs(b)
    da = a_abs - (a_abs // 10) * 10
    db = b_abs - (b_abs // 10) * 10
    return da * db