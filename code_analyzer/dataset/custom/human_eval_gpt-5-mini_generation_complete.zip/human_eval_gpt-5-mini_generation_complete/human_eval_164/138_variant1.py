def is_equal_to_sum_even(n):
    if not isinstance(n, int):
        return False
    return n >= 8 and (n & 1) == 0