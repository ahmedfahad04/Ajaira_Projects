def sort_numbers(numbers: str) -> str:
    mapping = {
        'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4,
        'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9
    }
    s = numbers.strip()
    if not s:
        return ''
    parts = s.split()
    parts.sort(key=lambda w: mapping[w])
    return ' '.join(parts)

# Classification response:
# variable renaming; helper function extraction; guard clause; empty input handling; join/split usage; in-place mutation; temporary variable; sort key