def rounded_avg(n, m):
    if n > m:
        return -1
    s = n + m
    q, r = divmod(s, 2)
    if r == 0:
        res = q
    else:
        # tie .5: round to nearest even
        if q % 2 == 0:
            res = q
        else:
            res = q + 1
    return bin(res)