def poly(xs: list, x: float):
    if not xs:
        return 0.0
    total = 0.0
    for i, coeff in enumerate(xs):
        total += coeff * (x ** i)
    return total

# Classification response:
# helper function extraction; input validation; for loop; enumerate loop; temporary variable; in-place mutation