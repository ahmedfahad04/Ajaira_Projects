def generate_integers(a, b):
    low, high = min(a, b), max(a, b)
    digits = [0, 2, 4, 6, 8]
    def recurse(i):
        if i == len(digits):
            return []
        head = [digits[i]] if low <= digits[i] <= high else []
        return head + recurse(i + 1)
    return recurse(0)