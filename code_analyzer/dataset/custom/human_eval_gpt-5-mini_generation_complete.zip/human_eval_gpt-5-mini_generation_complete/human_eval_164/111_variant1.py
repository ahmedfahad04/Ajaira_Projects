def histogram(test):
    from collections import Counter
    if not test:
        return {}
    parts = test.split()
    if not parts:
        return {}
    cnt = Counter(parts)
    if not cnt:
        return {}
    maxv = max(cnt.values())
    return {k: v for k, v in cnt.items() if v == maxv}