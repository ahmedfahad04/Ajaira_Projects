def digits(n):
    from functools import reduce
    from operator import mul
    s = str(abs(int(n)))
    odd_digits = [int(c) for c in s if int(c) % 2 == 1]
    if not odd_digits:
        return 0
    return reduce(mul, odd_digits, 1)