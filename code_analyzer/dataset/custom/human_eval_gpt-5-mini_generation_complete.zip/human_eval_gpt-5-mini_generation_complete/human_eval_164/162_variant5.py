def string_to_md5(text):
    if text == "":
        return None
    import hashlib
    d = hashlib.md5(text.encode('utf-8')).digest()
    # manual hex conversion from bytes
    return ''.join('{:02x}'.format(b) for b in d)