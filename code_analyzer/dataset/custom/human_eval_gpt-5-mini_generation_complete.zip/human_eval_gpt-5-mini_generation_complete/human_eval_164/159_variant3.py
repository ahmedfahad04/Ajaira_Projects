def eat(number, need, remaining):
    consumed = 0
    while consumed < need and remaining > 0:
        consumed += 1
        remaining -= 1
    return [number + consumed, remaining]