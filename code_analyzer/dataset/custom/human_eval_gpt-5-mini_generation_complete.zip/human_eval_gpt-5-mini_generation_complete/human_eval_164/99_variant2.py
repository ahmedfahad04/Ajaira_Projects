from decimal import Decimal
from fractions import Fraction

def closest_integer(value):
    d = Decimal(value)
    f = Fraction(d)
    sign = -1 if f < 0 else 1
    af = abs(f)
    whole = af.numerator // af.denominator
    rem = af.numerator % af.denominator
    if rem * 2 > af.denominator:
        res = whole + 1
    elif rem * 2 < af.denominator:
        res = whole
    else:
        res = whole + 1
    return sign * res