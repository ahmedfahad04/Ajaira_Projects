def get_odd_collatz(n):
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer")
    cache = {1: {1}}
    start = n
    path = []
    while n not in cache:
        path.append(n)
        n = n // 2 if n % 2 == 0 else 3 * n + 1
    # known set for the tail
    known = set(cache[n])
    # propagate back
    for x in reversed(path):
        if x % 2 == 1:
            known = known | {x}
        cache[x] = set(known)
    return sorted(cache[start])