def order_by_points(nums):
    def digit_sum(n):
        n = abs(n)
        s = 0
        while n:
            s += n % 10
            n //= 10
        return s
    enumerated = list(enumerate(nums))
    enumerated.sort(key=lambda x: (digit_sum(x[1]), x[0]))
    return [val for idx, val in enumerated