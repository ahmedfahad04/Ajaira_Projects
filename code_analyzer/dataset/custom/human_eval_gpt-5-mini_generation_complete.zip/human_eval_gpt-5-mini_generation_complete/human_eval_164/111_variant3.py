def histogram(test):
    from collections import defaultdict
    parts = test.split()
    if not parts:
        return {}
    d = defaultdict(int)
    for x in parts:
        d[x] += 1
    mx = 0
    for v in d.values():
        if v > mx:
            mx = v
    return {k: v for k, v in d.items() if v == mx}