def double_the_difference(lst):
    def is_valid(n):
        return isinstance(n, int) and not isinstance(n, bool) and n >= 0 and n % 2 != 0
    return sum(map(lambda v: v*v, filter(is_valid, lst)))