def minSubArraySum(nums):
    if not nums:
        return 0
    prefix = 0
    max_prefix = 0
    min_sub = float('inf')
    for x in nums:
        prefix += x
        # minimal subarray ending here is prefix - max_prefix_seen_before
        if prefix - max_prefix < min_sub:
            min_sub = prefix - max_prefix
        if prefix > max_prefix:
            max_prefix = prefix
    return min_sub