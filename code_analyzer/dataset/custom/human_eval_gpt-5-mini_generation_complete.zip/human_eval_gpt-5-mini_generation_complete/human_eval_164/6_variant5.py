from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    res: List[int] = []
    cur_max = 0
    cur_depth = 0
    in_group = False
    for ch in paren_string:
        if ch == '(':
            in_group = True
            cur_depth += 1
            if cur_depth > cur_max:
                cur_max = cur_depth
        elif ch == ')':
            in_group = True
            cur_depth -= 1
        elif ch.isspace():
            if in_group:
                res.append(cur_max)
                cur_max = 0
                cur_depth = 0
                in_group = False
            else:
                continue
        else:
            # ignore other characters
            pass
    if in_group:
        res.append(cur_max)
    return res