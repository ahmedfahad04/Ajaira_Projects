from itertools import starmap

def compare(game,guess):
    return list(starmap(lambda a, b: abs(a - b), zip(game, guess)))