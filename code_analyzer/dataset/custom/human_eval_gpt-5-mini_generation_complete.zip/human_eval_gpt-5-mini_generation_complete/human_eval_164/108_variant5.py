def count_nums(arr):
    import math
    def signed_sum(n):
        if n >= 0:
            return sum(int(ch) for ch in str(n)) if n != 0 else 0
        m = abs(n)
        if m == 0:
            return 0
        digits = int(math.log10(m)) + 1
        msd = m // (10 ** (digits - 1))
        total = sum(int(ch) for ch in str(m))
        return total - 2 * msd

    c = 0
    for x in arr:
        if signed_sum(x) > 0:
            c += 1
    return c