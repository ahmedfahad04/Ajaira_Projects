def string_to_md5(text):
    if text == "":
        return None
    import hashlib
    data = text.encode('utf-8')
    h = hashlib.md5()
    # use memoryview to avoid extra copies (demonstrative)
    h.update(memoryview(data))
    return h.hexdigest()