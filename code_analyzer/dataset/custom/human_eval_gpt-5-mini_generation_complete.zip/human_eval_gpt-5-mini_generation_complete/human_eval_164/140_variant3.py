def fix_spaces(text):
    res = []
    i = 0
    n = len(text)
    while i < n:
        if text[i] != ' ':
            res.append(text[i])
            i += 1
        else:
            j = i
            while j < n and text[j] == ' ':
                j += 1
            cnt = j - i
            if cnt > 2:
                res.append('-')
            else:
                res.append('_' * cnt)
            i = j
    return ''.join(res)