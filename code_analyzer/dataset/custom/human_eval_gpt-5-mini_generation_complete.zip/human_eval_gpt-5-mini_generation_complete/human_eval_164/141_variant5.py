import os
def file_name_check(file_name):
    if file_name.count('.') != 1:
        return 'No'
    root, ext = os.path.splitext(file_name)
    if ext.startswith('.'):
        ext = ext[1:]
    else:
        ext = ''
    if not root:
        return 'No'
    if not root[0].isalpha():
        return 'No'
    if ext not in ('txt', 'exe', 'dll'):
        return 'No'
    if sum(ch.isdigit() for ch in file_name) > 3:
        return 'No'
    return 'Yes'