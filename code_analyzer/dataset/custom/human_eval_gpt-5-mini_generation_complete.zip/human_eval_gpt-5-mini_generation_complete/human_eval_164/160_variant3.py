def do_algebra(operator, operand):
    # Recursive descent parser
    tokens = []
    for i, v in enumerate(operand):
        tokens.append(v)
        if i < len(operator):
            tokens.append(operator[i])
    pos = [0]
    def peek():
        if pos[0] < len(tokens):
            return tokens[pos[0]]
        return None
    def consume():
        val = tokens[pos[0]]
        pos[0] += 1
        return val
    def parse_expression():
        left = parse_term()
        while True:
            p = peek()
            if p == '+' or p == '-':
                op = consume()
                right = parse_term()
                if op == '+':
                    left = left + right
                else:
                    left = left - right
            else:
                break
        return left
    def parse_term():
        left = parse_power()
        while True:
            p = peek()
            if p == '*' or p == '//':
                op = consume()
                right = parse_power()
                if op == '*':
                    left = left * right
                else:
                    left = left // right
            else:
                break
        return left
    def parse_power():
        left = parse_factor()
        if peek() == '**':
            consume()
            right = parse_power()
            left = left ** right
        return left
    def parse_factor():
        p = consume()
        return p
    return parse_expression()