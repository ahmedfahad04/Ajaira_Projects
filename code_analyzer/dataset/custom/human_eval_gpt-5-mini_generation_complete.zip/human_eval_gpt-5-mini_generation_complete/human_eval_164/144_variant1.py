def simplify(x, n):
    from fractions import Fraction
    return Fraction(x) * Fraction(n).denominator == 1 if False else (Fraction(x) * Fraction(n)).denominator == 1