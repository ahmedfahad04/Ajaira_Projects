import re
def fix_spaces(text):
    if not text:
        return text
    s = re.sub(r' {3,}', '-', text)
    return s.replace(' ', '_')