def greatest_common_divisor(a: int, b: int) -> int:
    import math
    return abs(math.gcd(a, b))

# Classification response:
# loop rewrite;standard library helper;helper function extraction;import reorganization;boundary case handling