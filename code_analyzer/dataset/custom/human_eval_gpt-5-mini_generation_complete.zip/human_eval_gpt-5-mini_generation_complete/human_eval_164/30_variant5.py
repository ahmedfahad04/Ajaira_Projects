from functools import reduce
def get_positive(l: list):
    return reduce(lambda acc, x: acc + [x] if x > 0 else acc, l, [])

# Classification response:
# function renaming; helper function extraction; loop rewrite; accumulator list; functools reduce; lambda expression; list comprehension