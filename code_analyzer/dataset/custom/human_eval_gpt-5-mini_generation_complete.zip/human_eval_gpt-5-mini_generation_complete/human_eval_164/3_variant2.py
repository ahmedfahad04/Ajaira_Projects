from typing import List
import itertools

def below_zero(operations: List[int]) -> bool:
    return any(x < 0 for x in itertools.accumulate(operations))