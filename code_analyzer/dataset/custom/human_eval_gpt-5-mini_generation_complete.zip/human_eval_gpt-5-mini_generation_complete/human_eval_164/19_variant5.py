def sort_numbers(numbers: str) -> str:
    order = {'zero':0,'one':1,'two':2,'three':3,'four':4,'five':5,'six':6,'seven':7,'eight':8,'nine':9}
    s = numbers.strip()
    if not s:
        return ''
    parts = s.split()
    # recursive merge sort using the order mapping
    def merge_sort(lst):
        if len(lst) <= 1:
            return lst
        mid = len(lst)//2
        left = merge_sort(lst[:mid])
        right = merge_sort(lst[mid:])
        res = []
        i = j = 0
        while i < len(left) and j < len(right):
            if order[left[i]] <= order[right[j]]:
                res.append(left[i]); i += 1
            else:
                res.append(right[j]); j += 1
        if i < len(left):
            res.extend(left[i:])
        if j < len(right):
            res.extend(right[j:])
        return res
    sorted_parts = merge_sort(parts)
    return ' '.join(sorted_parts)

# Classification response:
# variable renaming;helper function extraction;recursion with base case;divide and conquer;early return;empty input handling;join/split usage;dictionary lookup;accumulator list;temporary variable