from typing import List

def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """Return list of strings that contain substring using an explicit loop."""
    result: List[str] = []
    for s in strings:
        if substring in s:
            result.append(s)
    return result