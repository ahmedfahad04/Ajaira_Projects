from typing import List

def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    n = len(numbers)
    if n == 0:
        return []
    if n == 1:
        return numbers[:]
    # preallocate and assign slices for efficiency
    res = [0] * (2 * n - 1)
    res[0::2] = numbers
    res[1::2] = [delimeter] * (n - 1)
    return res