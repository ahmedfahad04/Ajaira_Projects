def words_in_sentence(sentence):
    import math
    from functools import reduce

    def is_prime(n):
        if n < 2:
            return False
        if n == 2:
            return True
        if n % 2 == 0:
            return False
        r = int(math.sqrt(n))
        for i in range(3, r + 1, 2):
            if n % i == 0:
                return False
        return True

    words = sentence.split()
    filtered = list(filter(lambda w: is_prime(len(w)), words))
    return reduce(lambda a, b: a + " " + b if a else b, filtered, "")