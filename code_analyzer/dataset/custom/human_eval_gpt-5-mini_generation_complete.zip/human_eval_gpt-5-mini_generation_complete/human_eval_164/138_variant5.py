def is_equal_to_sum_even(n):
    if not isinstance(n, int):
        return False
    # reduce problem: sum of four positive evens == 2 * (sum of four positives)
    # so n must be even and n/2 must be >= 4
    return n % 2 == 0 and (n // 2) >= 4