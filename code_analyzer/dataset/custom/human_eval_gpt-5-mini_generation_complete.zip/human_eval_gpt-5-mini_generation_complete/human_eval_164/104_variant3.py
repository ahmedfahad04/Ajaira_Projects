def unique_digits(x):
    import re
    pat = re.compile(r'^[13579]+$')
    return sorted([n for n in x if pat.match(str(n))])