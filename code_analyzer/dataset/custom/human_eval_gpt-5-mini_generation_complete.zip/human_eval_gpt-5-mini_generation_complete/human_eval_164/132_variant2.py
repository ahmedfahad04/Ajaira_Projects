def is_nested(string):
    opens = 0
    seen_second = False
    closes_after_second = 0
    for ch in string:
        if ch == '[':
            opens += 1
            if opens == 2:
                seen_second = True
        elif ch == ']' and seen_second:
            closes_after_second += 1
            if closes_after_second >= 2:
                return True
    return False