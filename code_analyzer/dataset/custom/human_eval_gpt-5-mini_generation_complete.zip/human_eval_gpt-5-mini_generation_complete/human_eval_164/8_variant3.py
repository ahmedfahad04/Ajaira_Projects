from typing import List, Tuple
from functools import reduce
import operator

def sum_product(numbers: List[int]) -> Tuple[int, int]:
    total = reduce(operator.add, numbers, 0)
    prod = reduce(operator.mul, numbers, 1)
    return total, prod