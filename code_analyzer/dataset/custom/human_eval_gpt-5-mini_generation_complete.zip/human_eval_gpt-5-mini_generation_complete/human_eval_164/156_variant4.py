def int_to_mini_roman(number):
    if not (1 <= number <= 1000):
        raise ValueError("number out of range")
    n = number
    parts = []
    # thousands
    if n >= 1000:
        parts.append('m' * (n // 1000))
        n %= 1000
    # hundreds
    h = n // 100
    n %= 100
    if h == 9:
        parts.append('cm')
    elif h >= 5:
        parts.append('d' + 'c' * (h - 5))
    elif h == 4:
        parts.append('cd')
    else:
        parts.append('c' * h)
    # tens
    t = n // 10
    n %= 10
    if t == 9:
        parts.append('xc')
    elif t >= 5:
        parts.append('l' + 'x' * (t - 5))
    elif t == 4:
        parts.append('xl')
    else:
        parts.append('x' * t)
    # ones
    o = n
    if o == 9:
        parts.append('ix')
    elif o >= 5:
        parts.append('v' + 'i' * (o - 5))
    elif o == 4:
        parts.append('iv')
    else:
        parts.append('i' * o)
    return ''.join(parts)