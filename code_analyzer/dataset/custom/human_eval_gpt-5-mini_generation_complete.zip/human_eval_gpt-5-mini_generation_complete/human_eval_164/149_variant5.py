def sorted_list_sum(lst):
    def merge(left, right):
        i = j = 0
        out = []
        while i < len(left) and j < len(right):
            a, b = left[i], right[j]
            if len(a) < len(b) or (len(a) == len(b) and a <= b):
                out.append(a); i += 1
            else:
                out.append(b); j += 1
        out.extend(left[i:]); out.extend(right[j:])
        return out

    arr = [s for s in lst if len(s) % 2 == 0]
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = sorted_list_sum(arr[:mid])
    right = sorted_list_sum(arr[mid:])
    return merge(left, right)