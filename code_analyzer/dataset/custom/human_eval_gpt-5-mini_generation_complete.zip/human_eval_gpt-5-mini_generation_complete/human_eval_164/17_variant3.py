from typing import List

def parse_music(music_string: str) -> List[int]:
    s = music_string
    n = len(s)
    i = 0
    res: List[int] = []
    while i < n:
        ch = s[i]
        if ch.isspace():
            i += 1
            continue
        if ch == 'o':
            if i + 1 < n and s[i+1] == '|':
                res.append(2)
                i += 2
            else:
                res.append(4)
                i += 1
        elif ch == '.':
            if i + 1 < n and s[i+1] == '|':
                res.append(1)
                i += 2
            else:
                # lone '.' not defined by legend; skip it
                i += 1
        else:
            # unknown char: skip
            i += 1
    return res

# Classification response:
# helper function extraction;while loop;index-based loop;accumulator list;in-place mutation;temporary variable;nested conditional;guard clause;import reorganization;boundary case handling