def match_parens(lst):
    a, b = lst[0], lst[1]
    def reduce_pairs(s):
        prev = None
        while prev != s:
            prev = s
            s = s.replace('()', '')
        return s == ''
    if reduce_pairs(a + b) or reduce_pairs(b + a):
        return 'Yes'
    return 'No'