def specialFilter(nums):
    def first(n):
        n = abs(n)
        while n >= 10:
            n //= 10
        return n
    return sum(1 for n in nums if n > 10 and first(n) % 2 == 1 and (abs(n) % 10) % 2 == 1)