def histogram(test):
    from itertools import groupby
    parts = test.split()
    if not parts:
        return {}
    parts_sorted = sorted(parts)
    counts = {k: sum(1 for _ in g) for k, g in groupby(parts_sorted)}
    if not counts:
        return {}
    maxc = max(counts.values())
    return {k: v for k, v in counts.items() if v == maxc}