def max_fill(grid, capacity):
    total = 0
    i = 0
    n = len(grid)
    while i < n:
        row = grid[i]
        # manual count using indexing
        j = 0
        ones = 0
        m = len(row)
        while j < m:
            ones += 1 if row[j] == 1 else 0
            j += 1
        total += -(-ones // capacity)  # ceiling via negative floor division
        i += 1
    return total