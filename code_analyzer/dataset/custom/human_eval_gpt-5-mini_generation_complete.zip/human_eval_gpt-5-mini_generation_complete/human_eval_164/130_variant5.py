def tri(n):
    if n < 0:
        raise ValueError("n must be non-negative")
    memo = {}
    def get(k):
        if k in memo:
            return memo[k]
        if k == 0:
            memo[0] = 1
            return 1
        if k == 1:
            memo[1] = 3
            return 3
        if k % 2 == 0:
            memo[k] = 1 + k // 2
            return memo[k]
        # odd: replace tri(k+1) with its even formula
        val = get(k - 1) + get(k - 2) + (1 + (k + 1) // 2)
        memo[k] = val
        return val

    return [get(i) for i in range(n + 1)]