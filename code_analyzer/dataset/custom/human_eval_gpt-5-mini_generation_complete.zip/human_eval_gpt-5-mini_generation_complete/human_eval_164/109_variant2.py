def move_one_ball(arr):
    if not arr:
        return True
    # find index of minimum element and rotate so it comes first
    n = len(arr)
    min_val = min(arr)
    min_idx = arr.index(min_val)
    rotated = arr[min_idx:] + arr[:min_idx]
    # check non-decreasing
    for i in range(n - 1):
        if rotated[i] > rotated[i + 1]:
            return False
    return True