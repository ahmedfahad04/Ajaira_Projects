def Strongest_Extension(class_name, extensions):
    if not extensions:
        return class_name + '.'
    best_ext = None
    best_strength = None
    for ext in extensions:
        cap = 0
        low = 0
        for ch in ext:
            if ch.isupper():
                cap += 1
            elif ch.islower():
                low += 1
        strength = cap - low
        if best_strength is None or strength > best_strength:
            best_strength = strength
            best_ext = ext
    return class_name + '.' + best_ext