def digits(n):
    n = abs(int(n))
    if n == 0:
        return 0
    prod = 1
    found = False
    while n:
        d = n % 10
        if d % 2 == 1:
            prod *= d
            found = True
        n //= 10
    return prod if found else 0