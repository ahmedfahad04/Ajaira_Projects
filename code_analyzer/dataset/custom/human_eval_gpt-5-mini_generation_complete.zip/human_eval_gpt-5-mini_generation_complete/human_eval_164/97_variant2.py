def multiply(a, b):
    sa = str(abs(a))
    sb = str(abs(b))
    return int(sa[-1]) * int(sb[-1])