def reverse_delete(s,c):
    remove = set(c)
    res = ''.join(ch for ch in s if ch not in remove)
    return res, res == res[::-1]