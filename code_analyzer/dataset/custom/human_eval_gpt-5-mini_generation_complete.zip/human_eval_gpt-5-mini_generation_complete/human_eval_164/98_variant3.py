def count_upper(s):
    vowels = set("AEIOU")
    def rec(i):
        if i >= len(s):
            return 0
        return (1 if s[i] in vowels else 0) + rec(i + 2)
    return rec(0)