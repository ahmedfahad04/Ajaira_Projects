def is_equal_to_sum_even(n):
    try:
        if int(n) != n:
            return False
    except Exception:
        return False
    n = int(n)
    return n % 2 == 0 and n // 2 >= 4