from typing import List

def parse_music(music_string: str) -> List[int]:
    # Ensure tokens are separated by spaces by padding known tokens first
    s = music_string
    # do replacements longest-first to avoid partial replacement
    s = s.replace('o|', ' o| ')
    s = s.replace('.|', ' .| ')
    s = s.replace('o', ' o ')
    tokens = [t for t in s.split() if t]
    mapping = {'o': 4, 'o|': 2, '.|': 1}
    return [mapping[t] for t in tokens]

# Classification response:
# helper function extraction; variable renaming; import reorganization; temporary variable; list comprehension; join/split usage; boundary case handling