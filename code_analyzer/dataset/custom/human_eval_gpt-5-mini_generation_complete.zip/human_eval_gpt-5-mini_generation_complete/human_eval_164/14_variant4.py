from typing import List

def all_prefixes(string: str) -> List[str]:
    if not string:
        return []
    prev = all_prefixes(string[:-1])
    return prev + [string]

# Classification response:
# function renaming; recursion; recursion with base case; guard clause; accumulator list; temporary variable; copy before mutation; standard library helper; empty input handling