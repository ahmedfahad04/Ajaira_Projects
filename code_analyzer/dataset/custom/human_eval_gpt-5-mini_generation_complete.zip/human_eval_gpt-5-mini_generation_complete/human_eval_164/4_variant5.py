from typing import List
from decimal import Decimal, getcontext

def mean_absolute_deviation(numbers: List[float]) -> float:
    if not numbers:
        return 0.0
    # increase precision a bit for decimal operations
    getcontext().prec = 28
    decs = [Decimal(str(x)) for x in numbers]
    n = Decimal(len(decs))
    mean = sum(decs) / n
    total_abs = sum((abs(x - mean) for x in decs))
    mad = total_abs / n
    return float(mad)