def rounded_avg(n, m):
    if n > m:
        return -1
    from fractions import Fraction
    avg_frac = Fraction(n + m, 2)
    # round works with Fraction and uses bankers rounding
    res = round(avg_frac)
    return bin(int(res))