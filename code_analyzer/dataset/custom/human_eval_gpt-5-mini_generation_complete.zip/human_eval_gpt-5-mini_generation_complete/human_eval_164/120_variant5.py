import random

def maximum(arr, k):
    if k <= 0:
        return []
    n = len(arr)
    if k >= n:
        return sorted(arr)
    target = k  # number of largest elements to pick

    def select_kth_largest(a, k):
        if not a:
            return None
        pivot = random.choice(a)
        highs = [x for x in a if x > pivot]
        lows = [x for x in a if x < pivot]
        equals = [x for x in a if x == pivot]
        if len(highs) >= k:
            return select_kth_largest(highs, k)
        elif len(highs) + len(equals) >= k:
            return pivot
        else:
            return select_kth_largest(lows, k - len(highs) - len(equals))

    threshold = select_kth_largest(arr, target)
    greater = [x for x in arr if x > threshold]
    equals = [x for x in arr if x == threshold]
    need = target - len(greater)
    result = greater + equals[:need]
    result.sort()
    return result