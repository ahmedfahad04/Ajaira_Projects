import itertools

def split_words(txt):
    if any(ch.isspace() for ch in txt):
        parts = [''.join(group) for key, group in itertools.groupby(txt, key=str.isspace) if not key]
        return parts
    if ',' in txt:
        return txt.split(',')
    return sum(1 for c in txt if c.islower() and ((ord(c) - ord('a')) % 2 == 1))