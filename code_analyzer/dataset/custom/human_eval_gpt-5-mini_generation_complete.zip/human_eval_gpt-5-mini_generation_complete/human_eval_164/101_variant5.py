def words_string(s):
    if not s:
        return []
    parts = s.split(',')
    res = []
    for part in parts:
        for w in part.split():
            if w:
                res.append(w)
    return res