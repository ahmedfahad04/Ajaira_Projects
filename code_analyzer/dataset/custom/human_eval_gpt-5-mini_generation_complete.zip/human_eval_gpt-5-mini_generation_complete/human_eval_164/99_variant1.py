from decimal import Decimal, ROUND_HALF_UP

def closest_integer(value):
    d = Decimal(value)
    q = d.quantize(Decimal('1'), rounding=ROUND_HALF_UP)
    return int(q)