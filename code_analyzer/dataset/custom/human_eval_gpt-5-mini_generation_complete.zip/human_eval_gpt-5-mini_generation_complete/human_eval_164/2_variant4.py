def truncate_number(number: float) -> float:
    """ Given a positive floating point number, return the decimal part. """
    from decimal import Decimal, getcontext
    getcontext().prec = 28
    d = Decimal(str(number))
    whole = int(d)
    frac = d - Decimal(whole)
    return float(frac)