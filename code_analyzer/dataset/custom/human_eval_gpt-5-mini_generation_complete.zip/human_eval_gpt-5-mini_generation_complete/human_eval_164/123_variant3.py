def get_odd_collatz(n):
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer")
    def gen(x):
        while True:
            yield x
            if x == 1:
                break
            x = x // 2 if x % 2 == 0 else 3 * x + 1
    return sorted({x for x in gen(n) if x % 2 == 1})