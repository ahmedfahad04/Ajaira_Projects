from collections import Counter

def count_distinct_characters(string: str) -> int:
    if not string:
        return 0
    return len(Counter(ch.lower() for ch in string))

# Classification response:
# helper function extraction; guard clause; generator expression; standard library helper; frequency counting; empty input handling