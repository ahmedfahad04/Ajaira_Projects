from itertools import zip_longest
from operator import xor

def string_xor(a: str, b: str) -> str:
    return ''.join(str(xor(int(x), int(y))) for x, y in zip_longest(a, b, fillvalue='0'))

# Classification response:
# function renaming; import reorganization; itertools usage; helper function inlining; type conversion; generator expression; default value handling; boundary case handling