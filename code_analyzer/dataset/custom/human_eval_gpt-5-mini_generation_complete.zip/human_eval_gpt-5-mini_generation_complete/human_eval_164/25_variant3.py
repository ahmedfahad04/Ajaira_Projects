from typing import List
import math

def factorize(n: int) -> List[int]:
    if n is None:
        return []
    n = int(n)
    if n < 2:
        return []
    m = int(math.isqrt(n)) + 1
    sieve = bytearray(b'\x01') * (m + 1)
    sieve[0:2] = b'\x00\x00'
    primes = []
    p = 2
    while p * p <= m:
        if sieve[p]:
            for j in range(p * p, m + 1, p):
                sieve[j] = 0
        p += 1
    for i in range(2, m + 1):
        if sieve[i]:
            primes.append(i)
    factors: List[int] = []
    for p in primes:
        if p * p > n:
            break
        while n % p == 0:
            factors.append(p)
            n //= p
    if n > 1:
        factors.append(n)
    return factors

# Classification response:
# function renaming; import reorganization; guard clause; early return; loop rewrite; accumulator list; temporary variable; standard library helper; sieve of eratosthenes; input validation; type conversion; boundary case handling