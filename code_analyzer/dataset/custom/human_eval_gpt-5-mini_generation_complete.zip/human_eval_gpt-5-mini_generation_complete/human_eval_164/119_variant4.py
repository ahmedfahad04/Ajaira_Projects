def match_parens(lst):
    from itertools import accumulate
    mapping = {'(': 1, ')': -1}
    def good_by_acc(s):
        vals = [mapping[ch] for ch in s]
        acc = list(accumulate(vals))
        if not acc:
            return True
        return min(acc) >= 0 and acc[-1] == 0
    a, b = lst[0], lst[1]
    if good_by_acc(a + b) or good_by_acc(b + a):
        return 'Yes'
    return 'No'