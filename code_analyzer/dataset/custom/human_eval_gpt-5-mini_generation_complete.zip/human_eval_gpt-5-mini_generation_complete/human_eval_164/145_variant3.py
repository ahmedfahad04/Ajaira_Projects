def order_by_points(nums):
    if not nums:
        return []
    def digit_sum(n):
        return sum(int(c) for c in str(abs(n)))
    sums = [digit_sum(n) for n in nums]
    max_sum = max(sums) if sums else 0
    buckets = [[] for _ in range(max_sum + 1)]
    for idx, n in enumerate(nums):
        buckets[sums[idx]].append((idx, n))
    result = []
    for b in buckets:
        for idx, n in b:
            result.append(n)
    return result