def count_distinct_characters(string: str) -> int:
    if not string:
        return 0
    return len(set(string.lower()))

# Classification response:
# helper function extraction; guard clause; empty input handling; set conversion; type hint addition