import heapq

def maximum(arr, k):
    if k <= 0:
        return []
    if k >= len(arr):
        return sorted(arr)
    topk = heapq.nlargest(k, arr)
    return sorted(topk)