def by_length(arr):
    names = {1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"}
    return list(map(lambda x: names[x], filter(lambda y: isinstance(y, int) and 1 <= y <= 9, sorted(arr, reverse=True))))