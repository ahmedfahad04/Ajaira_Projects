def match_parens(lst):
    s1, s2 = lst
    def stack_check(s):
        stack = 0
        for ch in s:
            if ch == '(':
                stack += 1
            else:
                if stack == 0:
                    return False
                stack -= 1
        return stack == 0
    if stack_check(s1 + s2) or stack_check(s2 + s1):
        return 'Yes'
    return 'No'