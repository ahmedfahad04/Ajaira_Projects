def even_odd_count(num):
    n = abs(int(num))
    if n == 0:
        return (1, 0)
    even = odd = 0
    while n > 0:
        n, d = divmod(n, 10)
        if d & 1:
            odd += 1
        else:
            even += 1
    return (even, odd)