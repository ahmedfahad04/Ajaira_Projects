def tri(n):
    # iterative bottom-up list
    if n < 0:
        raise ValueError("n must be non-negative")
    if n == 0:
        return [1]
    res = [1, 3]
    for i in range(2, n + 1):
        if i % 2 == 0:
            res.append(1 + i // 2)
        else:
            # tri(i) = tri(i-1) + tri(i-2) + tri(i+1)
            # tri(i+1) is even so replace with formula
            res.append(res[-1] + res[-2] + (1 + (i + 1) // 2))
    return res[: n + 1]