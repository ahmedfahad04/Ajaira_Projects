from typing import List
import random

def _is_probable_prime(n: int) -> bool:
    if n < 2:
        return False
    small_primes = (2,3,5,7,11,13,17,19,23,29)
    for p in small_primes:
        if n % p == 0:
            return n == p
    d = n - 1
    s = 0
    while d % 2 == 0:
        d //= 2
        s += 1
    # deterministic bases for 64-bit integers
    for a in (2, 325, 9375, 28178, 450775, 9780504, 1795265022):
        if a % n == 0:
            continue
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        skip_to_next = False
        for _ in range(s - 1):
            x = (x * x) % n
            if x == n - 1:
                skip_to_next = True
                break
        if skip_to_next:
            continue
        return False
    return True

def _pollard_rho(n: int) -> int:
    if n % 2 == 0:
        return 2
    if n % 3 == 0:
        return 3
    while True:
        c = random.randrange(1, n - 1)
        x = random.randrange(2, n - 1)
        y = x
        d = 1
        while d == 1:
            x = (x * x + c) % n
            y = (y * y + c) % n
            y = (y * y + c) % n
            d = math_gcd(abs(x - y), n)
            if d == n:
                break
        if d > 1 and d < n:
            return d

def math_gcd(a: int, b: int) -> int:
    while b:
        a, b = b, a % b
    return a

def factorize(n: int) -> List[int]:
    if n is None:
        return []
    n = int(n)
    if n < 2:
        return []
    def _factor(n: int, out: List[int]):
        if n == 1:
            return
        if _is_probable_prime(n):
            out.append(n)
            return
        d = _pollard_rho(n)
        _factor(d, out)
        _factor(n // d, out)
    out: List[int] = []
    _factor(n, out)
    out.sort()
    return out

# Classification response:
# function renaming; variable renaming; import reorganization; helper function extraction; recursion with base case; probabilistic algorithm; loop rewrite; accumulator list; tuple unpacking; in-place mutation; early return; input validation; type conversion