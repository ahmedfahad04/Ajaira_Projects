def f(n):
    if n <= 0:
        return []
    res = [i * (i + 1) // 2 for i in range(1, n + 1)]
    fact = 1
    for i in range(1, n + 1):
        fact *= i
        if i % 2 == 0:
            res[i - 1] = fact
    return res