def sort_array(arr):
    def bitcount(n):
        n = abs(n)
        cnt = 0
        while n:
            n &= n - 1
            cnt += 1
        return cnt
    decorated = [(bitcount(x), x) for x in arr]
    decorated.sort()
    return [x for _, x in decorated]