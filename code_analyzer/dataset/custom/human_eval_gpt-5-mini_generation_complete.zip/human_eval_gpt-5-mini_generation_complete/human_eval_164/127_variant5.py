def intersection(interval1, interval2):
    a, b = interval1
    c, d = interval2
    start = max(a, c)
    end = min(b, d)
    if end < start:
        return "NO"
    length = end - start
    if length < 2:
        return "NO"
    # memoized primality checks
    _cache = {}
    def is_prime(n):
        if n in _cache:
            return _cache[n]
        if n < 2:
            _cache[n] = False
            return False
        if n % 2 == 0:
            _cache[n] = (n == 2)
            return _cache[n]
        i = 3
        import math
        lim = math.isqrt(n)
        while i <= lim:
            if n % i == 0:
                _cache[n] = False
                return False
            i += 2
        _cache[n] = True
        return True
    return "YES" if is_prime(length) else "NO"