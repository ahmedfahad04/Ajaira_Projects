def get_max_triples(n):
    # build residue counts by scanning small set of residues periodically
    full_cycles = n // 3
    rem = n % 3
    # each cycle contributes one i%3 == 2
    c0 = full_cycles
    if rem >= 2:
        c0 += 1
    c1 = n - c0
    # compute C(k,3)
    if c0 < 3 and c1 < 3:
        return 0
    def C3(k):
        if k < 3:
            return 0
        return (k * (k - 1) * (k - 2)) // 6
    return C3(c0) + C3(c1)