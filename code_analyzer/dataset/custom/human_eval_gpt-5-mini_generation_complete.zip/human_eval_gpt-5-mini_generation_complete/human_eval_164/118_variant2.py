import re

def get_closest_vowel(word):
    if len(word) < 3:
        return ""
    pattern = re.compile(r'(?<=[^aeiouAEIOU])[aeiouAEIOU](?=[^aeiouAEIOU])')
    matches = list(pattern.finditer(word))
    if not matches:
        return ""
    return matches[-1].group(0)