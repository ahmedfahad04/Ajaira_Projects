from typing import List, Any

def filter_integers(values: List[Any]) -> List[int]:
    # Use a list comprehension, include only ints but exclude bools
    return [x for x in values if isinstance(x, int) and not isinstance(x, bool)]

# Classification response:
# helper function extraction; import reorganization; type check; behavior change