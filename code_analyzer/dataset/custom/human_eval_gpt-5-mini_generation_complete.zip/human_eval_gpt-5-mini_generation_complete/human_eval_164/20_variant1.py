from typing import List, Tuple
import math

def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    if len(numbers) < 2:
        raise ValueError("At least two numbers required")
    nums = sorted(numbers)
    best_diff = math.inf
    best_pair = (nums[0], nums[1])
    for i in range(1, len(nums)):
        a, b = nums[i-1], nums[i]
        d = b - a
        if d < best_diff:
            best_diff = d
            best_pair = (a, b)
    return best_pair

# Classification response:
# sorting-based approach; loop rewrite; guard clause; input validation; variable renaming; tuple unpacking; standard library helper; import reorganization; list conversion; behavior change