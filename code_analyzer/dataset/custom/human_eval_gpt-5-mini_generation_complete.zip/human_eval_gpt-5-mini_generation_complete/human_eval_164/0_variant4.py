from typing import List

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    if threshold <= 0:
        return False
    n = len(numbers)
    if n < 2:
        return False
    nums = sorted(numbers)
    i = 0
    for j in range(1, n):
        while i < j and nums[j] - nums[i] >= threshold:
            i += 1
        if i < j and nums[j] - nums[i] < threshold:
            return True
    return False