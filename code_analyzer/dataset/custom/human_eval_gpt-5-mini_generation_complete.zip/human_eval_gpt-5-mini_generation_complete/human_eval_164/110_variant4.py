def exchange(lst1, lst2):
    from itertools import combinations
    combined = lst1 + lst2
    n = len(lst1)
    for indices in combinations(range(len(combined)), n):
        ok = True
        for i in indices:
            if combined[i] % 2 != 0:
                ok = False
                break
        if ok:
            return "YES"
    return "NO"