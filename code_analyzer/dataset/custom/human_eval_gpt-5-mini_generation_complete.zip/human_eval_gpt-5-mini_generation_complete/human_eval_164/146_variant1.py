def specialFilter(nums):
    count = 0
    for n in nums:
        if n > 10:
            x = abs(n)
            last = x % 10
            first = x
            while first >= 10:
                first //= 10
            if first % 2 == 1 and last % 2 == 1:
                count += 1
    return count