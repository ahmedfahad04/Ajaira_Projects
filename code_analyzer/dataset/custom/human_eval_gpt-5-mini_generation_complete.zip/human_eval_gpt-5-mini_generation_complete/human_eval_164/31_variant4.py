import math
def is_prime(n):
    if not isinstance(n, int):
        try:
            n = int(n)
        except Exception:
            return False
    if n <= 1:
        return False
    limit = int(math.isqrt(n))
    if limit < 2:
        return True
    sieve = bytearray(b'\x01') * (limit + 1)
    sieve[0:2] = b'\x00\x00'
    p = 2
    while p * p <= limit:
        if sieve[p]:
            step = p
            start = p * p
            sieve[start:limit+1:step] = b'\x00' * (((limit - start) // step) + 1)
        p += 1
    for i in range(2, limit + 1):
        if sieve[i] and n % i == 0:
            return False
    return True

# Classification response:
# function renaming;guard clause;try-except wrapper;while loop;for loop;loop rewrite;in-place mutation;slicing;temporary variable;standard library helper;mathematical formula;sieve of eratosthenes;input validation;type conversion;boundary case handling