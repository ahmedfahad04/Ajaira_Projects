from typing import List

def rescale_to_unit(numbers: List[float]) -> List[float]:
    if len(numbers) == 0:
        return []
    lo = min(numbers)
    hi = max(numbers)
    if hi == lo:
        return list(map(lambda _: 0.0, numbers))
    return list(map(lambda x: (x - lo) / (hi - lo), numbers))

# Classification response:
# helper function extraction;variable renaming;import reorganization;map/filter usage;lambda expression;list conversion;early return;empty input handling;boundary case handling