from typing import List, Optional
from functools import reduce

def longest(strings: List[str]) -> Optional[str]:
    if not strings:
        return None
    return reduce(lambda a, b: b if len(b) > len(a) else a, strings)

# Classification response:
# helper function extraction; import reorganization; functools reduce; lambda expression; loop rewrite; accumulator string; empty input handling; type annotations