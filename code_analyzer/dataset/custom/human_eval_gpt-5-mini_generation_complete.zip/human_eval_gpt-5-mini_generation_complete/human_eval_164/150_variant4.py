def x_or_y(n, x, y):
    # recursive divisor check (odd divisors)
    try:
        n = int(n)
    except:
        return y
    if n <= 1:
        return y
    if n <= 3:
        return x
    if n % 2 == 0:
        return y

    def is_prime_rec(d):
        if d * d > n:
            return True
        if n % d == 0:
            return False
        return is_prime_rec(d + 2)

    return x if is_prime_rec(3) else y