import re
def reverse_delete(s,c):
    if not c:
        res = s
    else:
        pat = '[' + ''.join(re.escape(ch) for ch in c) + ']'
        res = re.sub(pat, '', s)
    return res, res == res[::-1]