def solve(s):
    has_letter = any(ch.isalpha() for ch in s)
    if not has_letter:
        return s[::-1]
    def proc(i):
        if i >= len(s):
            return ''
        c = s[i]
        if c.islower():
            return c.upper() + proc(i+1)
        if c.isupper():
            return c.lower() + proc(i+1)
        return c + proc(i+1)
    return proc(0)