def minPath(grid, k):
    n = len(grid)
    # Flatten positions with values, find start pos for value 1
    start = None
    for i in range(n):
        for j in range(n):
            if grid[i][j] == 1:
                start = (i, j)
                break
        if start:
            break
    x, y = start
    ans = [1]
    # use manual min comparisons to avoid extra lists
    for _ in range(k-1):
        best = 10**18
        bx = by = None
        if x+1 < n:
            v = grid[x+1][y]
            if v < best:
                best = v; bx, by = x+1, y
        if x-1 >= 0:
            v = grid[x-1][y]
            if v < best:
                best = v; bx, by = x-1, y
        if y+1 < n:
            v = grid[x][y+1]
            if v < best:
                best = v; bx, by = x, y+1
        if y-1 >= 0:
            v = grid[x][y-1]
            if v < best:
                best = v; bx, by = x, y-1
        ans.append(best)
        x, y = bx, by
    return ans