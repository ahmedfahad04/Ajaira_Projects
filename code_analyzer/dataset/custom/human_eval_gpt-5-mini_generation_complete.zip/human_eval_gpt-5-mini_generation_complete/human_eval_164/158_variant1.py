def find_max(words):
    if not words:
        return ""
    best_word = None
    best_count = -1
    for w in words:
        c = len(set(w))
        if best_word is None:
            best_word = w
            best_count = c
        else:
            if c > best_count or (c == best_count and w < best_word):
                best_word = w
                best_count = c
    return best_word