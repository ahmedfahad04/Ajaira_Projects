def intersection(interval1, interval2):
    a1, b1 = interval1
    a2, b2 = interval2
    start = max(a1, a2)
    end = min(b1, b2)
    if end < start:
        return "NO"
    length = end - start
    if length < 2:
        return "NO"
    import math
    lim = math.isqrt(length)
    for d in range(2, lim + 1):
        if length % d == 0:
            return "NO"
    return "YES"