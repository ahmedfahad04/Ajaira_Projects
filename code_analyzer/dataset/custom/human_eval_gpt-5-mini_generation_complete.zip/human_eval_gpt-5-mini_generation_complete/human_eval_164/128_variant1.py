def prod_signs(arr):
    if not arr:
        return None
    total = 0
    sign_prod = 1
    for x in arr:
        if x == 0:
            return 0
        if x < 0:
            sign_prod = -sign_prod
        total += abs(x)
    return total * sign_prod