def simplify(x, n):
    import math
    a, b = map(int, x.split('/'))
    c, d = map(int, n.split('/'))
    num = a * c
    den = b * d
    g = math.gcd(num, den)
    num //= g
    den //= g
    return den == 1