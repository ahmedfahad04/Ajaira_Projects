def strlen(string: str) -> int:
    idx = -1
    for i, _ in enumerate(string):
        idx = i
    return idx + 1

# Classification response:
# function renaming; helper function extraction; loop rewrite; for loop; enumerate loop; temporary variable; tuple unpacking; builtin function