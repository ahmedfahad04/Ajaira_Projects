from typing import List

def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    # recursive approach
    if not numbers:
        return []
    if len(numbers) == 1:
        return [numbers[0]]
    first, rest = numbers[0], numbers[1:]
    return [first, delimeter] + intersperse(rest, delimeter)