def move_one_ball(arr):
    from collections import deque
    if not arr:
        return True
    dq = deque(arr)
    n = len(arr)
    for _ in range(n):
        # check if current deque is non-decreasing
        ok = True
        prev = dq[0]
        for x in list(dq)[1:]:
            if prev > x:
                ok = False
                break
            prev = x
        if ok:
            return True
        # perform one right shift: move last to front
        dq.appendleft(dq.pop())
    return False