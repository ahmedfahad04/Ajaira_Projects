def even_odd_count(num):
    s = str(abs(int(num)))
    digits = list(map(lambda ch: ord(ch) - 48, s))
    even = sum(1 for d in digits if d % 2 == 0)
    odd = len(digits) - even
    return (even, odd)