def is_palindrome(string: str) -> bool:
    n = len(string)
    if n <= 1:
        return True
    if string[0] != string[-1]:
        return False
    return is_palindrome(string[1:-1])

# Classification response:
# recursion with base case; guard clause; slicing