def unique_digits(x):
    def rec(n):
        n = abs(n)
        if n == 0:
            return False
        if n < 10:
            return n % 2 == 1
        if (n % 10) % 2 == 0:
            return False
        return rec(n // 10)
    res = []
    for n in x:
        if rec(n):
            res.append(n)
    res.sort()
    return res