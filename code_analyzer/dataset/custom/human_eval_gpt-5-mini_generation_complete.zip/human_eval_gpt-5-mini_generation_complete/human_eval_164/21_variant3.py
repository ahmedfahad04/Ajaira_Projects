from typing import List

def rescale_to_unit(numbers: List[float]) -> List[float]:
    n = len(numbers)
    if n == 0:
        return []
    lo = numbers[0]
    hi = numbers[0]
    for v in numbers:
        if v < lo:
            lo = v
        if v > hi:
            hi = v
    if hi == lo:
        out = []
        for _ in numbers:
            out.append(0.0)
        return out
    denom = 1.0 / (hi - lo)
    result = []
    for v in numbers:
        result.append((v - lo) * denom)
    return result

# Classification response:
# function renaming; variable renaming; import reorganization; guard clause; empty input handling; boundary case handling; loop rewrite; for loop; accumulator list; list comprehension