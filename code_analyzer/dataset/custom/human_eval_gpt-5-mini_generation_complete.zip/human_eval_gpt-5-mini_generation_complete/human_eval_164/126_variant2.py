from collections import Counter

def is_sorted(lst):
    # sortedness: list must equal its sorted version (non-decreasing)
    if lst != sorted(lst):
        return False
    # count occurrences using Counter
    counts = Counter(lst)
    for v in counts.values():
        if v > 2:
            return False
    return True