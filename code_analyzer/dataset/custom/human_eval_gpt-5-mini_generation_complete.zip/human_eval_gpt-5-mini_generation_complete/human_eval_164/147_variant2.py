def get_max_triples(n):
    import math
    # numbers i with i%3 == 2 give a[i] % 3 == 0
    c0 = (n + 1) // 3
    c1 = n - c0
    # use math.comb for binomial
    res = 0
    if c0 >= 3:
        res += math.comb(c0, 3)
    if c1 >= 3:
        res += math.comb(c1, 3)
    return res