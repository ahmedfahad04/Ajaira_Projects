from itertools import accumulate
from operator import mul

def f(n):
    if n <= 0:
        return []
    nums = list(range(1, n + 1))
    facts = list(accumulate(nums, mul))
    return [facts[i-1] if (i % 2 == 0) else i * (i + 1) // 2 for i in range(1, n + 1)]