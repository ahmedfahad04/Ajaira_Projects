def strlen(string: str) -> int:
    if string == "":
        return 0
    return 1 + strlen(string[1:])

# Classification response:
# recursion with base case; helper function extraction; slicing; empty input handling; builtin function