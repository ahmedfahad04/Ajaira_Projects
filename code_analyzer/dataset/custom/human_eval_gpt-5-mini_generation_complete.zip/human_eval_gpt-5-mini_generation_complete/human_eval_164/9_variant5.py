from typing import List

def rolling_max(numbers: List[int]) -> List[int]:
    n = len(numbers)
    if n == 0:
        return []
    result = [0] * n
    def helper(i: int, cur: int) -> None:
        if i == n:
            return
        if i == 0:
            cur = numbers[0]
            result[0] = cur
            helper(1, cur)
        else:
            if numbers[i] > cur:
                cur = numbers[i]
            result[i] = cur
            helper(i + 1, cur)
    helper(0, None)
    return result