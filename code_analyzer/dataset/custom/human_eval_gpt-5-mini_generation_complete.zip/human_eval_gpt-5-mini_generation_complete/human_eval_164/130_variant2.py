from functools import lru_cache

def tri(n):
    if n < 0:
        raise ValueError("n must be non-negative")

    @lru_cache(None)
    def t(k):
        if k == 0:
            return 1
        if k == 1:
            return 3
        if k % 2 == 0:
            return 1 + k // 2
        # k is odd: tri(k) = tri(k-1) + tri(k-2) + tri(k+1)
        # tri(k+1) is even, so use its closed form
        return t(k - 1) + t(k - 2) + (1 + (k + 1) // 2)

    return [t(i) for i in range(n + 1)]