def strlen(string: str) -> int:
    count = 0
    for _ in string:
        count += 1
    return count

# Classification response:
# helper function extraction; for loop; temporary variable; builtin function