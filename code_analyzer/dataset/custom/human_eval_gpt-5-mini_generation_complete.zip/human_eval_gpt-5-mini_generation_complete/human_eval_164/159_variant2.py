def eat(number, need, remaining):
    if need == 0 or remaining == 0:
        return [number, remaining]
    if need <= remaining:
        total = number + need
        left = remaining - need
    else:
        total = number + remaining
        left = 0
    return [total, left]