def minPath(grid, k):
    n = len(grid)
    # build mapping from value to coordinates
    pos = {}
    for i in range(n):
        for j in range(n):
            pos[grid[i][j]] = (i, j)
    # start at minimum value (1)
    cur_val = 1
    path = [cur_val]
    dirs = [(0,1),(0,-1),(1,0),(-1,0)]
    for _ in range(k-1):
        x, y = pos[cur_val]
        # examine neighbor values
        best = None
        for dx, dy in dirs:
            nx, ny = x+dx, y+dy
            if 0 <= nx < n and 0 <= ny < n:
                v = grid[nx][ny]
                if best is None or v < best:
                    best = v
        cur_val = best
        path.append(cur_val)
    return path