def find_max(words):
    # sort lexicographically so that among ties the smallest comes first
    if not words:
        return ""
    sorted_words = sorted(words)
    return max(sorted_words, key=lambda w: len(set(w)))