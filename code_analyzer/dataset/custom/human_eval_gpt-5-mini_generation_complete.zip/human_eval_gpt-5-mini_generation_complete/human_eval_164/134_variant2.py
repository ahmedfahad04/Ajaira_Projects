def check_if_last_char_is_a_letter(txt):
    parts = txt.rsplit(' ', 1)
    last = parts[-1]
    return len(last) == 1 and last.isalpha()