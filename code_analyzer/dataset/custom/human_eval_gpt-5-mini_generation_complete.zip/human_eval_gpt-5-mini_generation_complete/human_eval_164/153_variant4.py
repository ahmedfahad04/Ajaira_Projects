def Strongest_Extension(class_name, extensions):
    import re
    if not extensions:
        return class_name + '.'
    best = None
    best_s = None
    for ext in extensions:
        caps = len(re.findall(r'[A-Z]', ext))
        lows = len(re.findall(r'[a-z]', ext))
        s = caps - lows
        if best_s is None or s > best_s:
            best_s = s
            best = ext
    return class_name + '.' + best