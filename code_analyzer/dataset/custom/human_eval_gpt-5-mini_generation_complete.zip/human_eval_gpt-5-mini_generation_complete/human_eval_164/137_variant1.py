def compare_one(a, b):
    import math
    def to_num(x):
        if isinstance(x, str):
            s = x.strip().replace(',', '.')
            return float(s)
        return float(x)
    try:
        na = to_num(a)
        nb = to_num(b)
    except Exception:
        # if conversion fails, fallback to direct comparison
        if a == b:
            return None
        return a if a > b else b
    if math.isclose(na, nb, rel_tol=1e-9, abs_tol=1e-12):
        return None
    return a if na > nb else b