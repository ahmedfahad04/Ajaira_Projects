from typing import List
import math

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    if threshold <= 0:
        return False
    if len(numbers) < 2:
        return False
    buckets = {}
    size = threshold
    for x in numbers:
        idx = math.floor(x / size)
        # check same bucket
        if idx in buckets and abs(x - buckets[idx]) < threshold:
            return True
        # check neighbor buckets
        left = idx - 1
        if left in buckets and abs(x - buckets[left]) < threshold:
            return True
        right = idx + 1
        if right in buckets and abs(x - buckets[right]) < threshold:
            return True
        buckets[idx] = x
    return False