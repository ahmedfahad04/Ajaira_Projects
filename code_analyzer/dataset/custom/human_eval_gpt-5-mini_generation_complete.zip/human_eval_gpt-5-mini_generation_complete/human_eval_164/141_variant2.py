import re
def file_name_check(file_name):
    if file_name.count('.') != 1:
        return 'No'
    if sum(c.isdigit() for c in file_name) > 3:
        return 'No'
    if not re.match(r'^[A-Za-z].*\.(txt|exe|dll)$', file_name):
        return 'No'
    return 'Yes'