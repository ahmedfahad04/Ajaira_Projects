from typing import List
from functools import reduce

def separate_paren_groups(paren_string: str) -> List[str]:
    chars = [c for c in paren_string if c in "()"]
    def step(acc, ch):
        depth, cur, out = acc
        if ch == "(":
            depth += 1
        else:
            depth -= 1
        cur.append(ch)
        if depth == 0:
            out.append("".join(cur))
            cur = []
        return (depth, cur, out)
    _, _, result = reduce(step, chars, (0, [], []))
    return result