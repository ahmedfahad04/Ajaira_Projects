def even_odd_palindrome(n):
    ev = sum(1 for i in range(1, n + 1) if (s := str(i)) == s[::-1] and i % 2 == 0)
    od = sum(1 for i in range(1, n + 1) if (s := str(i)) == s[::-1] and i % 2 == 1)
    return (ev, od)