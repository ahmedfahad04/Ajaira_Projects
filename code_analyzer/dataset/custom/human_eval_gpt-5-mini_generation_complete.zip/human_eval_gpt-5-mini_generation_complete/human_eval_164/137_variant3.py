def compare_one(a, b):
    import math
    def smart_parse(s):
        s = s.strip()
        # if both separators present, determine decimal separator by last occurrence
        if '.' in s and ',' in s:
            if s.rfind('.') < s.rfind(','):
                # '.' as thousand sep, ',' as decimal
                s = s.replace('.', '').replace(',', '.')
            else:
                # ',' as thousand sep, '.' as decimal
                s = s.replace(',', '')
        else:
            s = s.replace(',', '.')
        return float(s)
    def to_num(x):
        if isinstance(x, str):
            return smart_parse(x)
        return float(x)
    try:
        na = to_num(a)
        nb = to_num(b)
    except Exception:
        if a == b:
            return None
        return a if a > b else b
    if abs(na - nb) <= 1e-9 * max(1.0, abs(na), abs(nb)):
        return None
    return a if na > nb else b