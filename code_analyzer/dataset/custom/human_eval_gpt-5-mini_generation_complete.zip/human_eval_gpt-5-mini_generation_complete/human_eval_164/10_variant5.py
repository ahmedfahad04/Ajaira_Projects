def is_palindrome(string: str) -> bool:
    return all(string[i] == string[-1-i] for i in range(len(string)//2))

# Classification response:
# generator expression; any/all usage; index-based loop; helper function extraction