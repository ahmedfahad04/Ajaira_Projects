def unique_digits(x):
    def check(n):
        return all((int(ch) & 1) == 1 for ch in str(n))
    return sorted(filter(check, x))