def make_a_pile(n):
    from itertools import islice, count
    return list(islice(count(n, 2), n))