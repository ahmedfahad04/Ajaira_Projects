def largest_smallest_integers(lst):
    if not lst:
        return (None, None)
    s = sorted(lst)
    largest_neg = None
    smallest_pos = None
    for x in s:
        if x < 0:
            largest_neg = x
        elif x > 0:
            smallest_pos = x
            break
    return (largest_neg, smallest_pos)