def sum_squares(lst):
    from functools import reduce
    def comb(acc, iv):
        i, v = iv
        if i % 3 == 0:
            return acc + v**2
        if i % 4 == 0:
            return acc + v**3
        return acc + v
    return reduce(comb, enumerate(lst), 0)