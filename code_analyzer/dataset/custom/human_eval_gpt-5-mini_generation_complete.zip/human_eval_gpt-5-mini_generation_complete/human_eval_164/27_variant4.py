def flip_case(string: str) -> str:
    out = []
    for ch in string:
        o = ord(ch)
        if 97 <= o <= 122:
            out.append(chr(o - 32))
        elif 65 <= o <= 90:
            out.append(chr(o + 32))
        else:
            out.append(ch)
    return ''.join(out)

# Classification response:
# function renaming; helper function extraction; for loop; accumulator list; join/split usage; builtin function; combined condition; literal rewrite; brute force