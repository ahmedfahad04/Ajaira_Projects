def int_to_mini_roman(number):
    if not (1 <= number <= 1000):
        raise ValueError("number out of range")
    mapping = [
        (1000, 'm'), (900, 'cm'), (500, 'd'), (400, 'cd'),
        (100, 'c'), (90, 'xc'), (50, 'l'), (40, 'xl'),
        (10, 'x'), (9, 'ix'), (5, 'v'), (4, 'iv'), (1, 'i')
    ]
    def helper(n):
        if n == 0:
            return ''
        for val, sym in mapping:
            if n >= val:
                return sym + helper(n - val)
        return ''
    return helper(number)