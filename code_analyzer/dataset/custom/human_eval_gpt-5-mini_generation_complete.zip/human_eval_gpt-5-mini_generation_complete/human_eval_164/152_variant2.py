def compare(game,guess):
    return list(map(lambda a, b: abs(a - b), game, guess))