def get_positive(l: list):
    if not l:
        return []
    head, tail = l[0], l[1:]
    rest = get_positive(tail)
    if head > 0:
        return [head] + rest
    return rest

# Classification response:
# list comprehension; helper function extraction; recursion with base case; guard clause; empty input handling; tuple unpacking