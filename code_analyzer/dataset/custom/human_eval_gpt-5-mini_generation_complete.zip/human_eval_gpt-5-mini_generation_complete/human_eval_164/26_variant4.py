from typing import List

def remove_duplicates(numbers: List[int]) -> List[int]:
    seen = set()
    duplicates = set()
    result = []
    for x in numbers:
        if x in seen:
            duplicates.add(x)
            if x in result:
                result.remove(x)
        else:
            seen.add(x)
            result.append(x)
    return result

# Classification response:
# helper function extraction; import reorganization; set conversion; accumulator list; accumulator set; in-place mutation; membership test