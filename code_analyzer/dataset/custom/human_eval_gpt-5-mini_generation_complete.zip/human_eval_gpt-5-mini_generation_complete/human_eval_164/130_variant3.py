def tri(n):
    if n < 0:
        raise ValueError("n must be non-negative")
    # Pre-fill even indices by formula; set tri(1)=3 explicitly
    vals = {}
    for i in range(0, n + 1, 2):
        vals[i] = 1 + i // 2
    if n >= 1:
        vals[1] = 3
    # compute odd indices in increasing order (3,5,7,...)
    i = 3
    while i <= n:
        # tri(i) uses tri(i-1), tri(i-2), and tri(i+1) (which is even and prefilled)
        vals[i] = vals[i - 1] + vals[i - 2] + vals[i + 1]
        i += 2
    return [vals[i] for i in range(n + 1)]