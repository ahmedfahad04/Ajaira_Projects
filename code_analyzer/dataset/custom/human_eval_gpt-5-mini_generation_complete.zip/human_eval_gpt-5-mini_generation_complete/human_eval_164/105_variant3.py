def by_length(arr):
    # Counting approach: count occurrences of digits 1..9 then emit in descending order
    names = ["One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"]
    counts = [0] * 10
    for x in arr:
        if isinstance(x, int) and 1 <= x <= 9:
            counts[x] += 1
    res = []
    for d in range(9, 0, -1):
        if counts[d]:
            res.extend([names[d - 1]] * counts[d])
    return res