import math
def sum_squares(lst):
    def helper(i):
        if i >= len(lst):
            return 0
        c = math.ceil(lst[i])
        return c*c + helper(i+1)
    return helper(0)