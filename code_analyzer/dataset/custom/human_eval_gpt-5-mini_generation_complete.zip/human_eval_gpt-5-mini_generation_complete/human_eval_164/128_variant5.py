import math

def prod_signs(arr):
    if not arr:
        return None
    signs = []
    for x in arr:
        if x == 0:
            return 0
        signs.append(1 if x > 0 else -1)
    total_abs = sum(abs(x) for x in arr)
    sign_prod = math.prod(signs) if signs else 1
    return total_abs * sign_prod