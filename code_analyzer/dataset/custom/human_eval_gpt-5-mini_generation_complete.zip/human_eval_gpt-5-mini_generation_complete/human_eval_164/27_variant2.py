def flip_case(string: str) -> str:
    result_chars = []
    for c in string:
        if c.islower():
            result_chars.append(c.upper())
        elif c.isupper():
            result_chars.append(c.lower())
        else:
            result_chars.append(c)
    return ''.join(result_chars)

# Classification response:
# helper function extraction; function renaming; for loop; accumulator list