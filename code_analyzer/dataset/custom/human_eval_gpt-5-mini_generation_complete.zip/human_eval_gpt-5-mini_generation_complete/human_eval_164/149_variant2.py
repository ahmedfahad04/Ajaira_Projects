def sorted_list_sum(lst):
    res = []
    for s in lst:
        if len(s) % 2 == 0:
            res.append(s)
    res.sort(key=lambda x: (len(x), x))
    return res