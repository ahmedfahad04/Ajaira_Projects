from typing import List, Any

def filter_integers(values: List[Any]) -> List[int]:
    # Recursive approach
    def helper(lst: List[Any]) -> List[int]:
        if not lst:
            return []
        head, *tail = lst
        rest = helper(tail)
        if isinstance(head, int) and not isinstance(head, bool):
            return [head] + rest
        return rest
    return helper(values)

# Classification response:
# recursion; helper function extraction; guard clause; tuple unpacking; combined condition; accumulator list; import reorganization; behavior change