def count_nums(arr):
    from functools import reduce
    def signed_sum_from_str(n):
        s = str(n)
        it = iter(s)
        if s.startswith('-'):
            next(it)  # skip '-'
            try:
                first = -int(next(it))
            except StopIteration:
                return 0
            rest = sum(int(ch) for ch in it)
            return first + rest
        else:
            return sum(int(ch) for ch in it) if s else 0

    return sum(1 for x in arr if signed_sum_from_str(x) > 0)