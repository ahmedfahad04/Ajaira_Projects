def simplify(x, n):
    import math
    a, b = map(int, x.split('/'))
    c, d = map(int, n.split('/'))
    g = math.gcd(a, d)
    a //= g
    d //= g
    g = math.gcd(c, b)
    c //= g
    b //= g
    return (a * c) % (b * d) == 0 if (b * d) != 1 else True