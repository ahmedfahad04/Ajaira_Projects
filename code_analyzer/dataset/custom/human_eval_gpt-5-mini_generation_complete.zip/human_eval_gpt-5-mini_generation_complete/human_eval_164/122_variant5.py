def add_elements(arr, k):
    def digit_count(n):
        n = abs(n)
        if n == 0:
            return 1
        c = 0
        while n:
            n //= 10
            c += 1
        return c
    return sum(x for x in arr[:k] if digit_count(x) <= 2)