def even_odd_palindrome(n):
    pals = list(filter(lambda x: str(x) == str(x)[::-1], range(1, n + 1)))
    ev = sum(map(lambda x: 1 if x % 2 == 0 else 0, pals))
    od = len(pals) - ev
    return (ev, od)