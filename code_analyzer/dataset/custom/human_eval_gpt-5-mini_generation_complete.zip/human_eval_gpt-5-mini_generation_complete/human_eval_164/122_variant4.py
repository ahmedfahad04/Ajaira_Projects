def add_elements(arr, k):
    from functools import reduce
    return reduce(lambda acc, x: acc + x if abs(x) <= 99 else acc, arr[:k], 0)