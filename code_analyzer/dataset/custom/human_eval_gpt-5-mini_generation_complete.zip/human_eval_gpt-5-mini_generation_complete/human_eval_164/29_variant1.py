from typing import List

def filter_by_prefix(strings: List[str], prefix: str) -> List[str]:
    return [s for s in strings if s.startswith(prefix)]

# Classification response:
# variable renaming; import reorganization; helper function extraction; list comprehension; standard library helper; type annotation addition