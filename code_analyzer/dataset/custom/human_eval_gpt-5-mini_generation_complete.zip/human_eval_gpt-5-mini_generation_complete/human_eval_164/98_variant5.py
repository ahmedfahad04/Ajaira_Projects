def count_upper(s):
    import re
    pattern = re.compile(r'[AEIOU]')
    cnt = 0
    for m in pattern.finditer(s):
        if m.start() % 2 == 0:
            cnt += 1
    return cnt