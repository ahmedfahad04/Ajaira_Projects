def max_fill(grid, capacity):
    total = 0
    for row in grid:
        ones = 0
        for v in row:
            if v:
                ones += 1
        total += (ones + capacity - 1) // capacity
    return total