from typing import List

def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    n = len(numbers)
    if n == 0:
        return []
    # build with comprehension that emits tuples then flattens
    return [x for i in range(n) for x in ((numbers[i],) + ((delimeter,) if i < n - 1 else ())) ]