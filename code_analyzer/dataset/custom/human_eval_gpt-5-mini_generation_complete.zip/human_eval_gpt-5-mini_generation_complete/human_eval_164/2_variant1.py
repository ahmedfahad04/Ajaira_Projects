def truncate_number(number: float) -> float:
    """ Given a positive floating point number, return the decimal part. """
    import math
    frac, _ = math.modf(number)
    return float(frac)