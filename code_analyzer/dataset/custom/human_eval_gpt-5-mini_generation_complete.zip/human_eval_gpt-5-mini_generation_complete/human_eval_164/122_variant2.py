def add_elements(arr, k):
    return sum(x for x in arr[:k] if len(str(abs(x))) <= 2)