def largest_divisor(n: int) -> int:
    m = abs(n)
    if m <= 1:
        return 0
    def find_smallest_divisor(x, i=2):
        if i * i > x:
            return None
        if x % i == 0:
            return i
        return find_smallest_divisor(x, i + 1)
    sd = find_smallest_divisor(m, 2)
    if sd is None:
        return 1
    return m // sd

# Classification response:
# helper function extraction; recursion with base case; loop rewrite; guard clause; boundary case handling; mathematical formula; temporary variable; builtin function