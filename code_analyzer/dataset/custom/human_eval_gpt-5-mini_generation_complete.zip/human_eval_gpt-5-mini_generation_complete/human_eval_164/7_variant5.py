from typing import List

def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    """Recursive implementation returning strings that contain substring."""
    def helper(idx: int) -> List[str]:
        if idx >= len(strings):
            return []
        head = strings[idx]
        rest = helper(idx + 1)
        if substring in head:
            return [head] + rest
        return rest
    return helper(0)