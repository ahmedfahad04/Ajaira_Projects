def solution(lst):
    total = 0
    for i, v in enumerate(lst):
        if i % 2 == 0 and v % 2 == 1:
            total += v
    return total