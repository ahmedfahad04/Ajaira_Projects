def is_sorted(lst):
    n = len(lst)
    def helper(i, prev, run):
        if i == n:
            return True
        cur = lst[i]
        if prev is not None and cur < prev:
            return False
        if prev is None or cur != prev:
            return helper(i + 1, cur, 1)
        else:
            # cur == prev
            if run + 1 > 2:
                return False
            return helper(i + 1, cur, run + 1)
    return helper(0, None, 0)