from typing import List, Tuple

def sum_product(numbers: List[int]) -> Tuple[int, int]:
    if not numbers:
        return 0, 1
    head, *tail = numbers
    s_rest, p_rest = sum_product(tail)
    return head + s_rest, head * p_rest