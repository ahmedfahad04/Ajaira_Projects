from itertools import zip_longest

def string_xor(a: str, b: str) -> str:
    return ''.join(chr((ord(x) ^ ord(y)) + 48) for x, y in zip_longest(a, b, fillvalue='0'))

# Classification response:
# function renaming; helper function inlining; import reorganization; itertools usage; conditional expression; generator expression; builtin function; default value handling; literal rewrite