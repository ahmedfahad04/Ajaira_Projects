import math
def largest_divisor(n: int) -> int:
    m = abs(n)
    if m <= 1:
        return 0
    best = 1
    r = int(math.isqrt(m))
    for i in range(2, r + 1):
        if m % i == 0:
            other = m // i
            if other < m:
                best = max(best, other)
            if i < m:
                best = max(best, i)
    return best

# Classification response:
# helper function extraction; loop rewrite; sqrt-based search; state variable; temporary variable; standard library helper; guard clause; boundary case handling; behavior change