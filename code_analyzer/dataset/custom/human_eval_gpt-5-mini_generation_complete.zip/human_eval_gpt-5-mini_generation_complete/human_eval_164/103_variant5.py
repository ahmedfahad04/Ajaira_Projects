def rounded_avg(n, m):
    if n > m:
        return -1
    from decimal import Decimal, ROUND_HALF_EVEN, getcontext
    # ensure enough precision
    getcontext().prec = max(28, len(str(n + m)) + 5)
    dec = Decimal(n + m) / Decimal(2)
    rounded = dec.quantize(Decimal('1'), rounding=ROUND_HALF_EVEN)
    return bin(int(rounded))