from itertools import groupby
def fix_spaces(text):
    parts = []
    for ch, group in groupby(text):
        grp = list(group)
        if ch == ' ':
            cnt = len(grp)
            if cnt > 2:
                parts.append('-')
            else:
                parts.append('_' * cnt)
        else:
            parts.append(''.join(grp))
    return ''.join(parts)