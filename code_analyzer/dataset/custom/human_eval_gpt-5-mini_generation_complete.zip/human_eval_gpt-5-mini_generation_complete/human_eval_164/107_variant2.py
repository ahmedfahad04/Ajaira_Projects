def even_odd_palindrome(n):
    def is_pal(num):
        original = num
        rev = 0
        while num > 0:
            rev = rev * 10 + (num % 10)
            num //= 10
        return rev == original

    ev = 0
    od = 0
    for i in range(1, n + 1):
        if is_pal(i):
            if i % 2 == 0:
                ev += 1
            else:
                od += 1
    return (ev, od)