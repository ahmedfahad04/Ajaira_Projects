def truncate_number(number: float) -> float:
    """ Given a positive floating point number, return the decimal part. """
    return float(number % 1)