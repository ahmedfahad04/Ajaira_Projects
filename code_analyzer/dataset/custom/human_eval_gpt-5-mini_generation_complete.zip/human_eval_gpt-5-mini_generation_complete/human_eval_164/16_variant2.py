def count_distinct_characters(string: str) -> int:
    seen = set()
    for ch in string:
        seen.add(ch.lower())
    return len(seen)

# Classification response:
# function renaming; loop rewrite; for loop; accumulator set; in-place mutation