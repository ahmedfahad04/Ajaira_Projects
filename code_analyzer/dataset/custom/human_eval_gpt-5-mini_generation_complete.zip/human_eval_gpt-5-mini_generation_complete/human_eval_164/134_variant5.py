def check_if_last_char_is_a_letter(txt):
    parts = txt.split(' ')
    last = parts[-1] if parts else ''
    return len(last) == 1 and last.isalpha()