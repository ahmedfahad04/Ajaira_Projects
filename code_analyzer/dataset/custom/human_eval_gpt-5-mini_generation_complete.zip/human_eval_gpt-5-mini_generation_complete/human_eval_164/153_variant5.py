def Strongest_Extension(class_name, extensions):
    if not extensions:
        return class_name + '.'
    from math import inf
    n = len(extensions)
    def recurse(i):
        if i == n:
            return (-inf, -1)
        caps = sum(1 for c in extensions[i] if c.isupper())
        lows = sum(1 for c in extensions[i] if c.islower())
        cur = (caps - lows, i)
        best_rest = recurse(i + 1)
        # choose the one with larger strength; on tie choose smaller index
        if cur[0] > best_rest[0]:
            return cur
        elif cur[0] < best_rest[0]:
            return best_rest
        else:
            return cur if cur[1] < best_rest[1] else best_rest
    best_strength, best_idx = recurse(0)
    return class_name + '.' + extensions[best_idx]