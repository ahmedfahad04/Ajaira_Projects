def is_nested(string):
    s1 = False  # have first '['
    s2 = False  # have two '[' (i.e., "[[")
    s3 = False  # have "[[]"
    s4 = False  # have "[[]]"
    for ch in string:
        if ch == '[':
            if s1:
                s2 = True or s2
            s1 = True or s1
        else:  # ch == ']'
            if s3:
                s4 = True or s4
            if s2:
                s3 = True or s3
        if s4:
            return True
    return False