def histogram(test):
    parts = test.split()
    if not parts:
        return {}
    def rec(i, acc):
        if i >= len(parts):
            return acc
        key = parts[i]
        acc[key] = acc.get(key, 0) + 1
        return rec(i + 1, acc)
    counts = rec(0, {})
    if not counts:
        return {}
    m = max(counts.values())
    return {k: v for k, v in counts.items() if v == m}