def multiply(a, b):
    pa = (-a if a < 0 else a) % 10
    pb = (-b if b < 0 else b) % 10
    return pa * pb