def x_or_y(n, x, y):
    # deterministic Miller-Rabin for 64-bit integers
    try:
        n = int(n)
    except:
        return y
    if n <= 1:
        return y
    if n <= 3:
        return x
    if n % 2 == 0:
        return y

    # write n-1 as d * 2^s
    d = n - 1
    s = 0
    while d % 2 == 0:
        d //= 2
        s += 1

    def check(a, s, d, n):
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            return True
        for _ in range(s - 1):
            x = (x * x) % n
            if x == n - 1:
                return True
        return False

    # bases that are sufficient for testing 64-bit integers
    bases = [2, 325, 9375, 28178, 450775, 9780504, 1795265022]
    for a in bases:
        if a % n == 0:
            return x
        if not check(a, s, d, n):
            return y
    return x