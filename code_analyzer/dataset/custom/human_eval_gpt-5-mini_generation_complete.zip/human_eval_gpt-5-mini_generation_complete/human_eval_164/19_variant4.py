def sort_numbers(numbers: str) -> str:
    mapping = {'zero':0,'one':1,'two':2,'three':3,'four':4,'five':5,'six':6,'seven':7,'eight':8,'nine':9}
    reverse = {v:k for k,v in mapping.items()}
    s = numbers.strip()
    if not s:
        return ''
    nums = [mapping[w] for w in s.split()]
    nums.sort()
    return ' '.join(reverse[n] for n in nums)

# Classification response:
# helper function extraction;variable renaming;dict comprehension;list comprehension;generator expression;dictionary lookup;in-place mutation;early return;empty input handling;join/split usage