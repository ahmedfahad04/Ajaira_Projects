def order_by_points(nums):
    def digit_sum_str(n):
        return sum(int(ch) for ch in str(abs(n)))
    arr = [(i, n, digit_sum_str(n)) for i, n in enumerate(nums)]
    arr.sort(key=lambda x: (x[2], x[0]))
    return [t[1] for t in arr