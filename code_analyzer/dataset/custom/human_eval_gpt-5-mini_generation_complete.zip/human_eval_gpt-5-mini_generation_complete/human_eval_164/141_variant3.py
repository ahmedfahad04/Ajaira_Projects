def file_name_check(file_name):
    # find the single dot
    dot_first = file_name.find('.')
    if dot_first == -1 or file_name.rfind('.') != dot_first:
        return 'No'
    if dot_first == 0:
        return 'No'
    first_char = file_name[0]
    if not ('A' <= first_char <= 'Z' or 'a' <= first_char <= 'z'):
        return 'No'
    ext = file_name[dot_first+1:]
    if ext not in ('txt', 'exe', 'dll'):
        return 'No'
    digits = 0
    for ch in file_name:
        if '0' <= ch <= '9':
            digits += 1
            if digits > 3:
                return 'No'
    return 'Yes'