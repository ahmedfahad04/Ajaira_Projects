from typing import List
from functools import reduce

def mean_absolute_deviation(numbers: List[float]) -> float:
    n = len(numbers)
    if n == 0:
        return 0.0
    mean = sum(numbers) / n
    total_abs = reduce(lambda acc, x: acc + (x - mean if x >= mean else mean - x), numbers, 0.0)
    return total_abs / n