def sort_array(arr):
    from functools import cmp_to_key
    def cmp(a, b):
        ca = a.bit_count() if hasattr(a, "bit_count") else bin(a).count('1')
        cb = b.bit_count() if hasattr(b, "bit_count") else bin(b).count('1')
        if ca < cb:
            return -1
        if ca > cb:
            return 1
        if a < b:
            return -1
        if a > b:
            return 1
        return 0
    return sorted(arr, key=cmp_to_key(cmp))