def right_angle_triangle(a, b, c):
    sides = [a, b, c]
    if any(x is None for x in sides):
        return False
    if any(x <= 0 for x in sides):
        return False
    s = sorted(sides)
    if s[0] + s[1] <= s[2]:
        return False
    if all(isinstance(x, int) for x in sides):
        return s[0]*s[0] + s[1]*s[1] == s[2]*s[2]
    else:
        import math
        return math.isclose(s[0]*s[0] + s[1]*s[1], s[2]*s[2], rel_tol=1e-9, abs_tol=1e-9)