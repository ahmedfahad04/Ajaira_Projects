def order_by_points(nums):
    def digit_sum(n):
        n = abs(n)
        s = 0
        while n:
            s += n % 10
            n //= 10
        return s
    def merge_sort(items):
        if len(items) <= 1:
            return items
        mid = len(items) // 2
        left = merge_sort(items[:mid])
        right = merge_sort(items[mid:])
        res = []
        i = j = 0
        while i < len(left) and j < len(right):
            li, ln = left[i]
            ri, rn = right[j]
            lk = (digit_sum(ln), li)
            rk = (digit_sum(rn), ri)
            if lk <= rk:
                res.append(left[i])
                i += 1
            else:
                res.append(right[j])
                j += 1
        res.extend(left[i:])
        res.extend(right[j:])
        return res
    indexed = list(enumerate(nums))
    sorted_indexed = merge_sort(indexed)
    return [val for idx, val in sorted_indexed