def by_length(arr):
    names = ["One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"]
    if not arr:
        return []
    return [names[x - 1] for x in sorted(arr, reverse=True) if 1 <= x <= 9]