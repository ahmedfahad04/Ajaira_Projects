from typing import List

def all_prefixes(string: str) -> List[str]:
    return list(map(lambda i: string[:i], range(1, len(string) + 1)))

# Classification response:
# loop rewrite; map/filter usage; lambda expression; helper function extraction; import reorganization; list conversion