from typing import List
from itertools import accumulate

def separate_paren_groups(paren_string: str) -> List[str]:
    s = "".join(ch for ch in paren_string if ch in "()")
    if not s:
        return []
    deltas = [1 if ch == "(" else -1 for ch in s]
    depths = list(accumulate(deltas))
    res = []
    start = 0
    for i, d in enumerate(depths):
        if d == 0:
            res.append(s[start:i+1])
            start = i + 1
    return res