import heapq

def maximum(arr, k):
    if k <= 0:
        return []
    n = len(arr)
    if k >= n:
        return sorted(arr)
    heap = []
    for x in arr:
        if len(heap) < k:
            heapq.heappush(heap, x)
        else:
            if x > heap[0]:
                heapq.heapreplace(heap, x)
    return sorted(heap)