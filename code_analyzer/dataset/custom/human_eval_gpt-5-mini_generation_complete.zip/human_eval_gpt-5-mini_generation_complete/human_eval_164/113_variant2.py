import re
def odd_count(lst):
    template = "the number of odd elements in the string i of the input."
    res = []
    for s in lst:
        cnt = len(re.findall(r'[13579]', s))
        res.append(str(cnt).join(template.split('i')))
    return res