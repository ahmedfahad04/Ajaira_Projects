def how_many_times(string: str, substring: str) -> int:
    if not substring:
        return 0
    # KMP algorithm to count occurrences including overlaps
    s, p = string, substring
    n, m = len(s), len(p)
    if m > n:
        return 0
    # build lps
    lps = [0] * m
    length = 0
    i = 1
    while i < m:
        if p[i] == p[length]:
            length += 1
            lps[i] = length
            i += 1
        else:
            if length != 0:
                length = lps[length - 1]
            else:
                lps[i] = 0
                i += 1
    # search
    count = 0
    i = j = 0
    while i < n:
        if s[i] == p[j]:
            i += 1
            j += 1
            if j == m:
                count += 1
                j = lps[j - 1]
        else:
            if j != 0:
                j = lps[j - 1]
            else:
                i += 1
    return count

# Classification response:
# function renaming; guard clause; loop rewrite; accumulator list; kmp algorithm; input validation