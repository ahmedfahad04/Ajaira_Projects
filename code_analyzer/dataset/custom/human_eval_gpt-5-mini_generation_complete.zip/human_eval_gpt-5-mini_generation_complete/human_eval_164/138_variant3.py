def is_equal_to_sum_even(n):
    if not isinstance(n, int) or n < 8 or n % 2 != 0:
        return False
    for a in range(2, n - 5, 2):
        for b in range(2, n - a - 3, 2):
            for c in range(2, n - a - b - 1, 2):
                d = n - a - b - c
                if d >= 2 and d % 2 == 0:
                    return True
    return False