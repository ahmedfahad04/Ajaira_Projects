from typing import List
from functools import reduce
import operator

def concatenate(strings: List[str]) -> str:
    return reduce(operator.add, strings, "")

# Classification response:
# helper function extraction;functools reduce;import reorganization;type annotations