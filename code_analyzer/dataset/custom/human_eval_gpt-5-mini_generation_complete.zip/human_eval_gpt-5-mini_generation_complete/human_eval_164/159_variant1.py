def eat(number, need, remaining):
    take = min(need, remaining)
    return [number + take, remaining - take]