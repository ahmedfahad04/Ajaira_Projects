from typing import List, Optional

def longest(strings: List[str]) -> Optional[str]:
    if not strings:
        return None
    sorted_list = sorted(strings, key=len, reverse=True)
    return sorted_list[0]

# Classification response:
# function renaming; import reorganization; loop rewrite; sort key; temporary variable; standard library helper