import math
def choose_num(x, y):
    if x > y:
        return -1
    L = math.ceil(x)
    U = math.floor(y)
    if U < L:
        return -1
    if U % 2 == 0:
        return U
    if U - 1 >= L:
        return U - 1
    return -1