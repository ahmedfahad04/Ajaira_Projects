from typing import List

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    if threshold <= 0:
        return False
    n = len(numbers)
    if n < 2:
        return False
    nums = sorted(numbers)
    for a, b in zip(nums, nums[1:]):
        if b - a < threshold:
            return True
    return False