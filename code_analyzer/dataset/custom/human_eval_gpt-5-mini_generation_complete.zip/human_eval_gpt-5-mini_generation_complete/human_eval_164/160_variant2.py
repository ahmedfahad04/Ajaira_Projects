def do_algebra(operator, operand):
    # Shunting-yard to RPN then evaluate
    ops = operator[:]
    vals = operand[:]
    tokens = []
    for i, v in enumerate(vals):
        tokens.append(v)
        if i < len(ops):
            tokens.append(ops[i])
    prec = {'+': 1, '-': 1, '*': 2, '//': 2, '**': 3}
    assoc = {'+': 'L', '-': 'L', '*': 'L', '//': 'L', '**': 'R'}
    output = []
    stack = []
    for t in tokens:
        if isinstance(t, int):
            output.append(t)
        else:
            while stack and stack[-1] in prec:
                top = stack[-1]
                if (assoc[t] == 'L' and prec[t] <= prec[top]) or (assoc[t] == 'R' and prec[t] < prec[top]):
                    output.append(stack.pop())
                else:
                    break
            stack.append(t)
    while stack:
        output.append(stack.pop())
    # evaluate RPN
    st = []
    for t in output:
        if isinstance(t, int):
            st.append(t)
        else:
            b = st.pop()
            a = st.pop()
            if t == '+':
                st.append(a + b)
            elif t == '-':
                st.append(a - b)
            elif t == '*':
                st.append(a * b)
            elif t == '//':
                st.append(a // b)
            elif t == '**':
                st.append(a ** b)
    return st[0]