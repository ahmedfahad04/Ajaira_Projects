def file_name_check(file_name):
    before, sep, after = file_name.partition('.')
    if sep != '.' or '.' in after:
        return 'No'
    if not before:
        return 'No'
    if not before[0].isalpha():
        return 'No'
    if after not in ('txt', 'exe', 'dll'):
        return 'No'
    if sum(ch.isdigit() for ch in file_name) > 3:
        return 'No'
    return 'Yes'