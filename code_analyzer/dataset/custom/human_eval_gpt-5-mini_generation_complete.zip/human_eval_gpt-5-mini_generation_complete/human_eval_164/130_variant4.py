def tri(n):
    if n < 0:
        raise ValueError("n must be non-negative")
    # Use a deque-like manual rolling computation for memory efficiency
    if n == 0:
        return [1]
    if n == 1:
        return [1, 3]
    res = [0] * (n + 1)
    # base and even rules
    res[0] = 1
    res[1] = 3
    for i in range(2, n + 1):
        if i % 2 == 0:
            res[i] = 1 + i // 2
        else:
            # tri(i+1) is even -> known by formula
            res[i] = res[i - 1] + res[i - 2] + (1 + (i + 1) // 2)
    return res