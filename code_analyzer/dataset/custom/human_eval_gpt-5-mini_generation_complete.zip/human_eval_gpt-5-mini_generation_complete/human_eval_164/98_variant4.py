def count_upper(s):
    from functools import reduce
    vowels = set("AEIOU")
    def reducer(acc, item):
        i, ch = item
        return acc + (1 if i % 2 == 0 and ch in vowels else 0)
    return reduce(reducer, enumerate(s), 0)