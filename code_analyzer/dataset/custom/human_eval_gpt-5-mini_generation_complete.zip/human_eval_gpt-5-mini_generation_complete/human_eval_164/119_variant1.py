def match_parens(lst):
    s1, s2 = lst[0], lst[1]
    def valid(s):
        bal = 0
        for ch in s:
            if ch == '(':
                bal += 1
            else:
                bal -= 1
            if bal < 0:
                return False
        return bal == 0
    if valid(s1 + s2) or valid(s2 + s1):
        return 'Yes'
    return 'No'