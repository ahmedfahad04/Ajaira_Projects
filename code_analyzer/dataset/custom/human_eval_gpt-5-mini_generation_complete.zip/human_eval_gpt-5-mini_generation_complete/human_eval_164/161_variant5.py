def solve(s):
    if not any(ch.isalpha() for ch in s):
        return s[::-1]
    return ''.join((c.lower() if c.isupper() else c.upper()) if c.isalpha() else c for c in s)