from typing import List
import itertools

def intersperse(numbers: List[int], delimeter: int) -> List[int]:
    if not numbers:
        return []
    # create pairs (x, delimeter) for each x, flatten, then drop the final delimeter
    flat = list(itertools.chain.from_iterable((x, delimeter) for x in numbers))
    # remove the last delimeter
    flat.pop()
    return flat