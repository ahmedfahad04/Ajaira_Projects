def string_sequence(n: int) -> str:
    if n < 0:
        return ''
    from functools import reduce
    seq = map(str, range(n + 1))
    return reduce(lambda a, b: a + " " + b, seq)

# Classification response:
# helper function extraction;guard clause;input validation;map/filter usage;functools reduce;lambda expression;import reorganization