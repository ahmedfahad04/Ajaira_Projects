def count_distinct_characters(string: str) -> int:
    # recursive approach building a set
    def helper(idx: int, acc: set) -> set:
        if idx >= len(string):
            return acc
        acc.add(string[idx].casefold())
        return helper(idx + 1, acc)
    return len(helper(0, set()))

# Classification response:
# function renaming; helper function extraction; recursion with base case; accumulator set; in-place mutation; behavior change