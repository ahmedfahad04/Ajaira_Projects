def is_nested(string):
    from bisect import bisect_right
    opens = [i for i,ch in enumerate(string) if ch == '[']
    closes = [i for i,ch in enumerate(string) if ch == ']']
    if len(opens) < 2 or len(closes) < 2:
        return False
    second_open = opens[1]
    pos = bisect_right(closes, second_open)
    return (len(closes) - pos) >= 2