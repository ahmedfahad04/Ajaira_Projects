def exchange(lst1, lst2):
    from itertools import chain
    evens = sum(1 for x in chain(lst1, lst2) if x & 1 == 0)
    return "YES" if evens >= len(lst1) else "NO"