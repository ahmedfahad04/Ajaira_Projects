def specialFilter(nums):
    def first_digit(n):
        n = abs(n)
        if n < 10:
            return n
        return first_digit(n // 10)
    def last_digit(n):
        return abs(n) % 10
    total = 0
    for n in nums:
        if n > 10:
            if first_digit(n) % 2 == 1 and last_digit(n) % 2 == 1:
                total += 1
    return total