def unique_digits(x):
    allowed = set("13579")
    result = []
    for n in x:
        s = str(n)
        if set(s) <= allowed:
            result.append(n)
    return sorted(result)