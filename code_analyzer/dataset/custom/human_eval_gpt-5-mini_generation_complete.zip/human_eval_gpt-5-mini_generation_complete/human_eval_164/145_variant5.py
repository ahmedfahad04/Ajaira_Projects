def order_by_points(nums):
    from functools import cmp_to_key
    def digit_sum(n):
        return sum(int(c) for c in str(abs(n)))
    def cmp(a, b):
        ai, an = a
        bi, bn = b
        sa = digit_sum(an)
        sb = digit_sum(bn)
        if sa < sb:
            return -1
        if sa > sb:
            return 1
        if ai < bi:
            return -1
        if ai > bi:
            return 1
        return 0
    indexed = list(enumerate(nums))
    indexed.sort(key=cmp_to_key(cmp))
    return [v for i, v in indexed