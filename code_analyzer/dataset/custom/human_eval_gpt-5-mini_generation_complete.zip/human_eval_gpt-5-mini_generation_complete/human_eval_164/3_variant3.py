from typing import List
from functools import reduce

def below_zero(operations: List[int]) -> bool:
    _, fell = reduce(lambda acc, x: (acc[0] + x, acc[1] or (acc[0] + x) < 0), operations, (0, False))
    return fell