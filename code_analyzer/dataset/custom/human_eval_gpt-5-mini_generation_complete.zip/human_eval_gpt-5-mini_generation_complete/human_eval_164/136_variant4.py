def largest_smallest_integers(lst):
    from functools import reduce
    def updater(acc, x):
        max_neg, min_pos = acc
        if x < 0:
            if max_neg is None or x > max_neg:
                max_neg = x
        elif x > 0:
            if min_pos is None or x < min_pos:
                min_pos = x
        return (max_neg, min_pos)
    return reduce(updater, lst, (None, None))