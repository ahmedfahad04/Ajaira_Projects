def rounded_avg(n, m):
    if n > m:
        return -1
    # direct formula, using Python round on the midpoint
    avg = round((n + m) / 2)
    return bin(int(avg))