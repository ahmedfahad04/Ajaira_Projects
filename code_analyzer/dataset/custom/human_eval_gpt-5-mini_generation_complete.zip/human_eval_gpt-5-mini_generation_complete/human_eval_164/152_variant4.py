def compare(game,guess):
    n = min(len(game), len(guess))
    def rec(i):
        if i >= n:
            return []
        a = game[i]; b = guess[i]
        diff = 0 if a == b else abs(a - b)
        return [diff] + rec(i + 1)
    return rec(0)