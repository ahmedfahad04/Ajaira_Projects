def is_palindrome(string: str) -> bool:
    i, j = 0, len(string) - 1
    while i < j:
        if string[i] != string[j]:
            return False
        i += 1
        j -= 1
    return True

# Classification response:
# helper function extraction;loop rewrite;index-based loop;two pointer;early return;slicing