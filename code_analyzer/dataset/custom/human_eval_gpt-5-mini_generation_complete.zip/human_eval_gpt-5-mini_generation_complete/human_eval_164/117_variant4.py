def select_words(s, n):
    words = s.split()
    def helper(idx):
        if idx >= len(words):
            return []
        w = words[idx]
        cnt = 0
        for ch in w:
            if ch.lower() not in "aeiou":
                cnt += 1
        rest = helper(idx+1)
        if cnt == n:
            return [w] + rest
        return rest
    return helper(0)