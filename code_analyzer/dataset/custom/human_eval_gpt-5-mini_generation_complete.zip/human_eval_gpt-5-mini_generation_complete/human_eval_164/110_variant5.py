def exchange(lst1, lst2):
    from functools import reduce
    combined = lst1 + lst2
    evens = reduce(lambda acc, x: acc + (1 if x % 2 == 0 else 0), combined, 0)
    return "YES" if evens >= len(lst1) else "NO"