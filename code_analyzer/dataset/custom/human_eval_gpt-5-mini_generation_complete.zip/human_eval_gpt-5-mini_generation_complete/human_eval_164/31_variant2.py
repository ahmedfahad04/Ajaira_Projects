def is_prime(n):
    if not isinstance(n, int):
        try:
            n = int(n)
        except Exception:
            return False
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True

# Classification response:
# function renaming;loop rewrite;while loop;early return;guard clause;combined condition;temporary variable;type conversion;input validation;boundary case handling;sqrt trial division