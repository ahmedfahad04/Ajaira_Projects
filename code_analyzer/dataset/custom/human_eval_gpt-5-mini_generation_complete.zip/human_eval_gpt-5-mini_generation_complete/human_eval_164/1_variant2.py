from typing import List

def separate_paren_groups(paren_string: str) -> List[str]:
    s = "".join(ch for ch in paren_string if ch in "()")
    n = len(s)
    if n == 0:
        return []
    def helper(i: int) -> List[str]:
        while i < n and s[i] != "(":
            i += 1
        if i >= n:
            return []
        depth = 0
        j = i
        while j < n:
            if s[j] == "(":
                depth += 1
            else:
                depth -= 1
            j += 1
            if depth == 0:
                break
        group = s[i:j]
        return [group] + helper(j)
    return helper(0)