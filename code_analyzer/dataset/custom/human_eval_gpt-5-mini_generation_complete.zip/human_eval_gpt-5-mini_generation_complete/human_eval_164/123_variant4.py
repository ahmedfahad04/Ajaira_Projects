def get_odd_collatz(n):
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer")
    odds = set()
    while True:
        if n % 2 == 1:
            odds.add(n)
            if n == 1:
                break
            n = 3 * n + 1
        # collapse consecutive even steps quickly
        while n % 2 == 0:
            n //= 2
            if n == 1:
                odds.add(1)
                break
    return sorted(odds)