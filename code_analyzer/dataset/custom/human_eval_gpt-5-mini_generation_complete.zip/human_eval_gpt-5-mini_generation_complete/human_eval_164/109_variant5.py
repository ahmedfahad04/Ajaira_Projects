def move_one_ball(arr):
    if not arr:
        return True
    n = len(arr)
    s = sorted(arr)
    # try to align sorted list s to arr by checking rotation positions of s[0]
    first = s[0]
    # there could be only one position because elements unique
    try:
        start = arr.index(first)
    except ValueError:
        return False
    for j in range(n):
        if arr[(start + j) % n] != s[j]:
            return False
    return True