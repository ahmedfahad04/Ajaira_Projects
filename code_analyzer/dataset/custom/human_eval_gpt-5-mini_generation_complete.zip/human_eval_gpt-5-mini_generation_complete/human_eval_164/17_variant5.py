from typing import List

def parse_music(music_string: str) -> List[int]:
    mapping = {'o': 4, 'o|': 2, '.|': 1}
    # defensive split and validate tokens using map with error on unknown
    tokens = music_string.split()
    result: List[int] = []
    for tok in tokens:
        if not tok:
            continue
        if tok in mapping:
            result.append(mapping[tok])
        else:
            # attempt to parse consecutive characters (in case of no spaces)
            j = 0
            while j < len(tok):
                if tok[j] == 'o':
                    if j+1 < len(tok) and tok[j+1] == '|':
                        result.append(2); j += 2
                    else:
                        result.append(4); j += 1
                elif tok[j] == '.':
                    if j+1 < len(tok) and tok[j+1] == '|':
                        result.append(1); j += 2
                    else:
                        j += 1
                else:
                    j += 1
    return result

# Classification response:
# helper function extraction; variable renaming; accumulator list; for loop; while loop; guard clause; nested conditional; membership test; dictionary lookup; join/split usage; boundary case handling; behavior change