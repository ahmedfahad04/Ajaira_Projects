def poly(xs: list, x: float):
    if not xs:
        return 0.0
    power = 1.0
    total = 0.0
    for coeff in xs:
        total += coeff * power
        power *= x
    return total

# Classification response:
# guard clause; for loop; temporary variable; state variable; empty input handling