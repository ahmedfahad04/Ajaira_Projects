def by_length(arr):
    names = ["One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"]
    s = sorted(arr, reverse=True)
    def helper(i):
        if i >= len(s):
            return []
        cur = s[i]
        head = [names[cur-1]] if isinstance(cur, int) and 1 <= cur <= 9 else []
        return head + helper(i+1)
    return helper(0)