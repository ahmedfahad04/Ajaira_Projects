def find_max(words):
    from functools import reduce
    if not words:
        return ""
    def better(a, b):
        # choose better of two words a and b
        ca = len(set(a))
        cb = len(set(b))
        if ca > cb:
            return a
        if cb > ca:
            return b
        # tie -> lexicographically smaller
        return a if a <= b else b
    return reduce(better, words)