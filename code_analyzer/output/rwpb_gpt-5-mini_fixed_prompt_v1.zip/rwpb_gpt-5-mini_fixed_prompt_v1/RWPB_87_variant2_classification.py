
def rotate_x(a, device=None):
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        if device is not None:
            device = torch.device(device)
        angle = torch.tensor(a, dtype=torch.float64, device=device)
        ca = torch.cos(angle).item()
        sa = torch.sin(angle).item()
        mat = torch.eye(4, dtype=torch.float64, device=device)
        mat[1,1] = ca
        mat[1,2] = -sa
        mat[2,1] = sa
        mat[2,2] = ca
        return mat.to(dtype=torch.float32)


# Classification response:
# variable renaming; import reorganization; literal rewrite; in-place mutation; temporary variable; type conversion; helper function extraction; behavior change