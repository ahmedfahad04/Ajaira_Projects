
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        # Ensure same device/dtype and compatible shapes
        if tensor1.shape[1:] != tensor2.shape[1:]:
            # allow scalar inputs (0-d) by treating as length-1
            if tensor1.dim() == 0 and tensor2.dim() == 0:
                t1 = tensor1.unsqueeze(0)
                t2 = tensor2.unsqueeze(0)
            else:
                raise ValueError("Input tensors must have the same shape except for the first dimension.")
        else:
            t1 = tensor1
            t2 = tensor2
        # If inputs are 0-d, we already unsqueezed; otherwise keep as-is
        if t1.dim() == 0:
            t1 = t1.unsqueeze(0)
            t2 = t2.unsqueeze(0)
        n = t1.size(0)
        out_shape = (2 * n,) + t1.shape[1:]
        out1 = torch.empty(out_shape, dtype=t1.dtype, device=t1.device)
        out2 = torch.empty_like(out1)
        out1[0::2] = t1
        out1[1::2] = t2
        out2[0::2] = t2
        out2[1::2] = t1
        return out1, out2


# Classification response:
# input validation; boundary case handling; guard clause; nested conditional; temporary variable; in-place mutation; slicing; import reorganization