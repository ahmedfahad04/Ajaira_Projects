
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    from typing import List
    def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        if ls is None:
            ls = []
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be non-negative integer")
        # recursive strategy for padding when shorter
        def _pad_recursive(current):
            if len(current) == max_seq_length:
                return current
            if len(current) > max_seq_length:
                # shouldn't happen here
                if check:
                    raise ValueError("Result length is not equal to max_seq_length")
                return current[:max_seq_length] if pad_right else current[-max_seq_length:]
            # add one pad and recurse
            if pad_right:
                return _pad_recursive(current + [pad_idx])
            else:
                return _pad_recursive([pad_idx] + current)
        if len(ls) > max_seq_length:
            if check:
                raise ValueError("Input length greater than max_seq_length")
            return ls[:max_seq_length] if pad_right else ls[-max_seq_length:]
        return _pad_recursive(list(ls))


# Classification response:
# recursion; helper function extraction; input validation; type check; empty input handling; boundary case handling; early return; list conversion; import reorganization; exception handling; behavior change