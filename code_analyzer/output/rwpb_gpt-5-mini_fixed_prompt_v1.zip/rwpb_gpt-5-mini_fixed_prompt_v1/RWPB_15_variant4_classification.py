
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        a = np.asarray(a, dtype=float).reshape(-1)
        b = np.asarray(b, dtype=float)
        if b.ndim == 1:
            if a.shape[0] != b.shape[0]:
                raise KeyError("Length mismatch between a and b")
            na = np.linalg.norm(a)
            nb = np.linalg.norm(b)
            if na == 0 or nb == 0:
                return 1.0
            an = a / na
            bn = b / nb
            cos = np.dot(an, bn)
            return float(1.0 - np.clip(cos, -1.0, 1.0))
        elif b.ndim == 2:
            if a.shape[0] != b.shape[1]:
                raise KeyError("Length mismatch between a and b")
            na = np.linalg.norm(a)
            if na == 0:
                return np.ones(b.shape[0])
            an = a / na
            bn = b / np.linalg.norm(b, axis=1, keepdims=True)
            bn = np.where(np.isfinite(bn), bn, 0.0)
            cos = bn.dot(an)
            cos = np.clip(cos, -1.0, 1.0)
            return 1.0 - cos
        else:
            raise KeyError("b must be a vector or 2D matrix")


# Classification response:
# import reorganization; nested conditional; early return; exception handling; input validation; boundary case handling; type conversion; temporary variable; vectorized computation; numpy usage; behavior change