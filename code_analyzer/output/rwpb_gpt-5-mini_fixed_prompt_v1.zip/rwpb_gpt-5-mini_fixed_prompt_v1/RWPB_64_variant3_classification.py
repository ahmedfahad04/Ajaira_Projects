
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        arr = np.asarray(arr, dtype=float)
        if window_size <= 0:
            raise ValueError("window_size must be positive")
        n = arr.size
        if n == 0:
            return [np.array([]), np.array([])]
        if window_size >= n:
            ma = np.full(n, arr.mean(), dtype=float)
            return [ma, arr - ma]
        ma = np.empty(n, dtype=float)
        left_shift = (window_size - 1) // 2
        for i in range(n):
            start = i - left_shift
            if start < 0:
                start = 0
            end = start + window_size
            if end > n:
                end = n
                start = n - window_size
            ma[i] = arr[start:end].mean()
        residuals = arr - ma
        return [ma, residuals]


# Classification response:
# import reorganization; for loop; brute force; early return; input validation; empty input handling; boundary case handling; type conversion; temporary variable