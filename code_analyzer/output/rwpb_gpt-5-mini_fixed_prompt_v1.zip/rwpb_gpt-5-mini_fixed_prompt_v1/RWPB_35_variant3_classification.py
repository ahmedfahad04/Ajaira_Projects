
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        def _gen(obj, base):
            if not isinstance(obj, dict):
                if base:
                    yield base, obj
                return
            for k, v in obj.items():
                new = base + sep + str(k) if base else str(k)
                if isinstance(v, dict) and v:
                    yield from _gen(v, new)
                else:
                    yield new, v
        return dict(_gen(d, parent_key))


# Classification response:
# helper function extraction; generator expression; guard clause; recursion with base case; string formatting change; type conversion; empty input handling; combined condition