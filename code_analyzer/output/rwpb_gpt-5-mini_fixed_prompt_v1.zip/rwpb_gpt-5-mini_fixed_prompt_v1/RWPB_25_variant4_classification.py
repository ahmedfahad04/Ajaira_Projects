
def hole_fill(img):
    import numpy as np
    import cv2
    from collections import deque
    def hole_fill(img):
        """
        Pure numpy flood fill from borders (BFS) to detect background, then fill holes.
        """
        if img is None:
            return img
        gray = img.copy()
        if gray.ndim == 3:
            gray = cv2.cvtColor(gray, cv2.COLOR_BGR2GRAY)
        # binary threshold
        _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
        bw = (bw > 0).astype(np.uint8)
        h, w = bw.shape
        visited = np.zeros((h, w), dtype=np.bool_)
        bg = np.zeros((h, w), dtype=np.uint8)
        dq = deque()
        # push all border zeros (background candidates)
        for x in range(w):
            if bw[0, x] == 0:
                dq.append((0, x)); visited[0, x] = True; bg[0, x] = 1
            if bw[h-1, x] == 0:
                dq.append((h-1, x)); visited[h-1, x] = True; bg[h-1, x] = 1
        for y in range(h):
            if bw[y, 0] == 0:
                dq.append((y, 0)); visited[y, 0] = True; bg[y, 0] = 1
            if bw[y, w-1] == 0:
                dq.append((y, w-1)); visited[y, w-1] = True; bg[y, w-1] = 1
        # BFS to mark background connected to border
        while dq:
            y, x = dq.popleft()
            for ny, nx in ((y-1,x),(y+1,x),(y,x-1),(y,x+1)):
                if 0 <= ny < h and 0 <= nx < w and not visited[ny, nx] and bw[ny, nx] == 0:
                    visited[ny, nx] = True
                    bg[ny, nx] = 1
                    dq.append((ny, nx))
        # Holes are zero pixels not marked as background
        holes = np.logical_and(bw == 0, bg == 0)
        filled = bw.copy()
        filled[holes] = 1
        filled = (filled * 255).astype(np.uint8)
        if img.ndim == 3:
            return cv2.cvtColor(filled, cv2.COLOR_GRAY2BGR)
        return filled


# Classification response:
# queue-based; while loop; for loop; helper function extraction; import reorganization; variable renaming; state variable; in-place mutation; tuple unpacking; standard library helper; input validation; type conversion; boundary case handling