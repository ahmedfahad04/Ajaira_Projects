
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        """
        Alternate implementation handling fractional padding by computing symmetric padding
        based on the minimum uniform scale that fits the original image into the mask grid.
        """
        if not isinstance(masks, torch.Tensor):
            masks = torch.tensor(masks)
        N, C, H, W = masks.shape
        target_h, target_w = int(shape[0]), int(shape[1])
        if not padding:
            resized = F.interpolate(masks.view(-1, 1, H, W), size=(target_h, target_w),
                                    mode='bilinear', align_corners=False)
            return resized.view(N, C, target_h, target_w)
        # Find uniform gain that was used when placing original image into padded mask grid
        gain_y = H / float(target_h)
        gain_x = W / float(target_w)
        # Use the smaller of the two gains so that scaled original fits in model grid
        gain = min(gain_y, gain_x)
        # Compute the region that contains the scaled original image
        scaled_h = int(round(target_h * gain))
        scaled_w = int(round(target_w * gain))
        pad_h = max(H - scaled_h, 0)
        pad_w = max(W - scaled_w, 0)
        # assume symmetric padding
        top = pad_h // 2
        left = pad_w // 2
        bottom = top + scaled_h
        right = left + scaled_w
        # Ensure indices valid
        top = max(0, min(top, H))
        left = max(0, min(left, W))
        bottom = max(top, min(bottom, H))
        right = max(left, min(right, W))
        if bottom - top <= 0 or right - left <= 0:
            # fallback: direct resize
            out = F.interpolate(masks.view(-1, 1, H, W), size=(target_h, target_w),
                                mode='bilinear', align_corners=False)
            return out.view(N, C, target_h, target_w)
        cropped = masks[:, :, top:bottom, left:right]
        out = F.interpolate(cropped.view(-1, 1, cropped.shape[-2], cropped.shape[-1]),
                            size=(target_h, target_w), mode='bilinear', align_corners=False)
        out = out.view(N, C, target_h, target_w)
        # preserve integer/boolean masks by thresholding
        if masks.dtype in (torch.uint8, torch.bool):
            out = (out > 0.5).to(masks.dtype)
        return out


# Classification response:
# import reorganization; variable renaming; tuple unpacking; guard clause; type conversion; type check; boundary case handling; behavior change