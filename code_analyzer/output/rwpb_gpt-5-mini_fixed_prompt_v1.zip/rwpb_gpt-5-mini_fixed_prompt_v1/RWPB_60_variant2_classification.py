
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        orig_x = x
        device = x.device
        if upcast:
            x = x.to(torch.float32)
            if weight is not None:
                weight = weight.to(torch.float32)
            if bias is not None:
                bias = bias.to(torch.float32)
            if residual is not None:
                residual = residual.to(torch.float32)
        n = x.shape[-1]
        # compute l2 norm then convert to rms
        l2 = torch.linalg.vector_norm(x, dim=-1, keepdim=True)
        ms = (l2 * l2) / float(n)
        inv = torch.rsqrt(ms + eps)
        normalized = x * inv
        # prepare parameters to broadcast
        if weight is not None and weight.ndim == 1:
            weight = weight.view(*([1] * (normalized.ndim - 1)), -1)
        if bias is not None and bias.ndim == 1:
            bias = bias.view(*([1] * (normalized.ndim - 1)), -1)
        out = normalized * weight if weight is not None else normalized
        if bias is not None:
            out = out + bias
        if residual is not None:
            out = out + residual.to(out.dtype)
        if upcast:
            out = out.to(orig_x.dtype)
        if prenorm:
            return out, orig_x
        return out


# Classification response:
# variable renaming; helper function extraction; branch reordering; temporary variable; standard library helper; type conversion; boundary case handling