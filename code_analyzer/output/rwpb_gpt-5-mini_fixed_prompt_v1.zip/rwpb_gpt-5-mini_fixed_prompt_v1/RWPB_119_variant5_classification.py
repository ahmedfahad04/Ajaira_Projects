
def rotate_about_x_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        arr = np.asarray(vector, dtype=float)
        if arr.shape not in [(3,), (3,1), (1,3)]:
            if arr.size == 3:
                arr = arr.ravel()
            else:
                raise ValueError("vector must be length 3")
        # Build rotation matrix by components and multiply with explicit loops
        c = math.cos(theta)
        s = math.sin(theta)
        R = [[1.0, 0.0, 0.0],
             [0.0,   c,  -s],
             [0.0,   s,   c]]
        res = [0.0, 0.0, 0.0]
        for i in range(3):
            acc = 0.0
            for j in range(3):
                acc += R[i][j] * float(arr[j])
            res[i] = acc
        return np.array(res, dtype=float)


# Classification response:
# import reorganization; standard library helper; loop rewrite; for loop; input validation; type conversion; accumulator list; temporary variable; literal rewrite