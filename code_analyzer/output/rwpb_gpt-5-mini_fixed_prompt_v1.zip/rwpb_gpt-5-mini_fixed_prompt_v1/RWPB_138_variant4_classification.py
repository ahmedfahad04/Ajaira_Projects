
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        """
        Straightforward Python-loop implementation applying rotation per-pixel.
        """
        if not isinstance(normal_map, np.ndarray):
            normal_map = np.array(normal_map, dtype=np.float64)
        nm = normal_map.astype(np.float64)
        if nm.ndim != 3 or nm.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        h, w, _ = nm.shape
        theta = np.deg2rad(angle)
        c = np.cos(theta)
        s = np.sin(theta)
        out = np.empty_like(nm)
        for i in range(h):
            for j in range(w):
                vx, vy, vz = nm[i, j]
                # Rotation about Y:
                x2 = c * vx + s * vz
                y2 = vy
                z2 = -s * vx + c * vz
                # normalize
                norm = (x2 * x2 + y2 * y2 + z2 * z2) ** 0.5
                if norm == 0:
                    out[i, j] = np.array([0.0, 1.0, 0.0])
                else:
                    out[i, j] = np.array([x2 / norm, y2 / norm, z2 / norm])
        return out


# Classification response:
# loop rewrite; index-based loop; input validation; type conversion; guard clause; boundary case handling; tuple unpacking; temporary variable; import reorganization; behavior change