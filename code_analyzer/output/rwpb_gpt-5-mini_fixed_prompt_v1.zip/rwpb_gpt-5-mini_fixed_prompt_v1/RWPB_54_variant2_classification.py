
def get_crop_box(box, expand):
    import numpy as np
    def get_crop_box(box, expand):
        x, y, x1, y1 = box
        if expand < 0:
            raise ValueError("expand must be non-negative")
        coords = np.array([x, y, x1, y1], dtype=float)
        # Ensure ordering
        if coords[2] < coords[0]:
            coords[[0,2]] = coords[[2,0]]
        if coords[3] < coords[1]:
            coords[[1,3]] = coords[[3,1]]
        center = np.array([(coords[0] + coords[2]) / 2.0, (coords[1] + coords[3]) / 2.0])
        w, h = coords[2] - coords[0], coords[3] - coords[1]
        half_size = max(w, h) * expand / 2.0
        new_tl = center - half_size
        new_br = center + half_size
        new_box = [float(new_tl[0]), float(new_tl[1]), float(new_br[0]), float(new_br[1])]
        return new_box, float(half_size)


# Classification response:
# import reorganization;numpy usage;helper function extraction;guard clause;input validation;boundary case handling;type conversion;in-place mutation;tuple unpacking;temporary variable