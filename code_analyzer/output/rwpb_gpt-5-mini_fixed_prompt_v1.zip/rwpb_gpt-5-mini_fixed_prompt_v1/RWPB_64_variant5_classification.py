
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        arr = np.asarray(arr, dtype=float)
        if window_size <= 0:
            raise ValueError("window_size must be positive")
        n = arr.size
        if n == 0:
            return [np.array([]), np.array([])]
        ma = np.empty(n, dtype=float)
        low_half = (window_size - 1) // 2
        high_half = window_size // 2
        for i in range(n):
            start = max(0, i - low_half)
            end = min(n, i + high_half + 1)
            ma[i] = arr[start:end].mean()
        residuals = arr - ma
        return [ma, residuals]


# Classification response:
# import reorganization; type conversion; input validation; empty input handling; early return; for loop; brute force; sliding window; in-place mutation; temporary variable; behavior change