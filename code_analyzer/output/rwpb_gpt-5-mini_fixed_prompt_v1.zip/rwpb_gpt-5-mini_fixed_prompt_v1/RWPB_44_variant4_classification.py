
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        # Use concatenation then fancy indexing
        if tensor1.dim() == 0 and tensor2.dim() == 0:
            t1 = tensor1.unsqueeze(0)
            t2 = tensor2.unsqueeze(0)
        else:
            t1 = tensor1
            t2 = tensor2
        if t1.shape[1:] != t2.shape[1:]:
            raise ValueError("Shapes must match except for the first dimension")
        n = t1.size(0)
        concat = torch.cat((t1, t2), dim=0)  # first block t1(0..n-1), then t2(n..2n-1)
        idx = torch.arange(n, device=concat.device)
        idx1 = torch.stack((idx, idx + n), dim=1).view(-1)
        idx2 = torch.stack((idx + n, idx), dim=1).view(-1)
        interleaved1 = concat.index_select(0, idx1)
        interleaved2 = concat.index_select(0, idx2)
        return interleaved1, interleaved2


# Classification response:
# import reorganization; helper function extraction; guard clause; exception handling; temporary variable; input validation; boundary case handling