
def rotate_normalmap_by_angle_torch(normal_map, angle):
    import torch
    import numpy as np
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        if not isinstance(normal_map, torch.Tensor):
            raise TypeError("normal_map must be a torch.Tensor")
        device = normal_map.device
        dtype = normal_map.dtype
        nm = normal_map.cpu().to(torch.get_default_dtype())
        permuted_back = False
        if nm.dim() == 3 and nm.shape[0] == 3:
            nm = nm.permute(1, 2, 0)
            permuted_back = True
        if not (nm.dim() == 3 and nm.shape[2] == 3):
            raise ValueError("normal_map must have shape (H,W,3) or (3,H,W)")
        arr = nm.numpy()
        theta = np.deg2rad(angle)
        c = np.cos(theta)
        s = np.sin(theta)
        R = np.array([[c, 0.0, s],
                      [0.0, 1.0, 0.0],
                      [-s, 0.0, c]], dtype=arr.dtype)
        flat = arr.reshape(-1, 3)
        rotated = flat @ R.T
        norms = np.linalg.norm(rotated, axis=1, keepdims=True)
        norms = np.maximum(norms, np.finfo(rotated.dtype).eps)
        rotated = rotated / norms
        rotated = rotated.reshape(arr.shape)
        out = torch.from_numpy(rotated).to(device=device, dtype=dtype)
        if permuted_back:
            out = out.permute(2, 0, 1)
        return out


# Classification response:
# guard clause;exception handling;input validation;type check;type conversion;boundary case handling;import reorganization;numpy interop;sentinel flag;temporary variable