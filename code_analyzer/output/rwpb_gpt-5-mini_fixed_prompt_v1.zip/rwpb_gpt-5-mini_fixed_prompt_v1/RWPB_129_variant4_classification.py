
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        """
        Use grid_sample with an affine transform to map the unpadded crop to the output grid.
        """
        if not isinstance(masks, torch.Tensor):
            masks = torch.tensor(masks)
        N, C, H, W = masks.shape
        target_h, target_w = int(shape[0]), int(shape[1])
        if not padding:
            out = F.interpolate(masks.view(-1, 1, H, W), size=(target_h, target_w),
                                mode='bilinear', align_corners=False)
            return out.view(N, C, target_h, target_w)
        # Compute uniform gain that fits original into model grid (letterbox)
        gain_y = H / float(target_h)
        gain_x = W / float(target_w)
        gain = min(gain_y, gain_x)
        scaled_h = target_h * gain
        scaled_w = target_w * gain
        pad_h = max(H - scaled_h, 0.0)
        pad_w = max(W - scaled_w, 0.0)
        top = pad_h / 2.0
        left = pad_w / 2.0
        # Define crop center and size in input (pixel coords)
        crop_h = scaled_h
        crop_w = scaled_w
        center_y = top + crop_h / 2.0
        center_x = left + crop_w / 2.0
        # Convert to normalized coordinates in [-1,1] for grid_sample mapping
        # scale components: how much of the input normalized domain is covered
        scale_x = (crop_w / W)
        scale_y = (crop_h / H)
        trans_x = (2.0 * center_x / W) - 1.0
        trans_y = (2.0 * center_y / H) - 1.0
        # Build theta for affine_grid: shape (N, 2, 3)
        theta = masks.new_zeros((N, 2, 3))
        theta[:, 0, 0] = scale_x
        theta[:, 1, 1] = scale_y
        theta[:, 0, 2] = trans_x
        theta[:, 1, 2] = trans_y
        # Prepare input for grid_sample (N*C as batch)
        inp = masks.view(N * C, 1, H, W)
        # Repeat theta per channel
        theta_rep = theta.unsqueeze(1).repeat(1, C, 1, 1).view(N * C, 2, 3)
        grid = F.affine_grid(theta_rep, size=(N * C, 1, target_h, target_w), align_corners=False)
        sampled = F.grid_sample(inp, grid, mode='bilinear', padding_mode='zeros', align_corners=False)
        out = sampled.view(N, C, target_h, target_w)
        if masks.dtype in (torch.uint8, torch.bool):
            out = (out > 0.5).to(masks.dtype)
        return out


# Classification response:
# import reorganization; tuple unpacking; temporary variable; early return; affine grid sampling; type conversion; input validation; boundary case handling; membership test