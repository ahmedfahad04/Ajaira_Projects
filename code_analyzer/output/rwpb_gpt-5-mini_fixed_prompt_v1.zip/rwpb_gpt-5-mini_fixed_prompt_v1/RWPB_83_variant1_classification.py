
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        if sample is None:
            return (size[0], size[1])
        target_h, target_w = size
        img = sample.get("image", None)
        disp = sample.get("disparity", None)
        mask = sample.get("mask", None)
        def _shape(arr):
            if arr is None:
                return None
            if isinstance(arr, np.ndarray):
                if arr.ndim >= 2:
                    return arr.shape[0], arr.shape[1]
            raise ValueError("Unsupported array for shape")
        img_shape = _shape(img) if img is not None else None
        base_shape = img_shape or _shape(disp) or _shape(mask)
        if base_shape is None:
            return (target_h, target_w)
        h, w = base_shape
        scale_h = float(target_h) / h if h < target_h else 1.0
        scale_w = float(target_w) / w if w < target_w else 1.0
        scale = max(scale_h, scale_w, 1.0)
        if scale == 1.0:
            return (h, w)
        new_h = int(math.ceil(h * scale))
        new_w = int(math.ceil(w * scale))
        if img is not None:
            interp = image_interpolation_method
            sample["image"] = cv2.resize(img, (new_w, new_h), interpolation=interp)
        if disp is not None:
            # use linear interpolation for disparity and scale disparity values
            disp_dtype = disp.dtype
            disp_resized = cv2.resize(disp, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            # multiply disparity values by scale to keep metric meaning
            if np.issubdtype(disp_resized.dtype, np.integer):
                # convert to float for scaling then cast back
                disp_resized = (disp_resized.astype(np.float32) * scale).astype(disp_dtype)
            else:
                disp_resized = disp_resized.astype(np.float32) * scale
                if disp_dtype != disp_resized.dtype:
                    try:
                        disp_resized = disp_resized.astype(disp_dtype)
                    except Exception:
                        pass
            sample["disparity"] = disp_resized
        if mask is not None:
            # nearest to preserve binary regions
            original_dtype = mask.dtype
            mask_resized = cv2.resize(mask, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            if original_dtype != mask_resized.dtype:
                try:
                    mask_resized = mask_resized.astype(original_dtype)
                except Exception:
                    pass
            sample["mask"] = mask_resized
        return (new_h, new_w)


# Classification response:
# variable renaming; temporary variable; tuple unpacking; dictionary lookup; helper function extraction; import reorganization; early return; guard clause; flattened conditional; split condition; type check; input validation; boundary case handling; error suppression; behavior change; mathematical formula