
def unsafeSub(x, y):
    MAX_VAL = (1 << 256) - 1
    def unsafeSub(x, y):
        return (x - y) & MAX_VAL


# Classification response:
# helper function extraction; temporary variable; literal rewrite