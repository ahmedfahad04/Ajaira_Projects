
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        if not isinstance(image, np.ndarray):
            raise ValueError("Input must be a numpy array")
        dims = image.ndim
        if dims == 2:
            if 0 in image.shape:
                raise ValueError("Invalid image")
            norm = (image.astype(np.float32) / 255.0).reshape(1, image.shape[0], image.shape[1])
            return torch.tensor(norm, dtype=torch.float)
        if dims == 3:
            if 0 in image.shape:
                raise ValueError("Invalid image")
            H, W, C = image.shape
            norm = image.astype(np.float32) / 255.0
            norm = norm.reshape(H, W, C).transpose(2, 0, 1).copy()
            return torch.tensor(norm, dtype=torch.float)
        raise ValueError("Not a valid image: expected 2D (H,W) or 3D (H,W,C) array")


# Classification response:
# import reorganization; input validation; guard clause; exception handling; empty input handling; type conversion; tuple unpacking; temporary variable; copy before mutation; membership test; behavior change