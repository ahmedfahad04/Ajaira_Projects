
def arccos2(vector, value):
    import math
    import numpy as np
    def arccos2(vector, value):
        v = np.asarray(vector, dtype=float)
        # Clamp value to valid domain
        val = max(-1.0, min(1.0, float(value)))
        base = math.acos(val)  # in [0, pi]
        # If vector points to lower half-plane, take the reflex angle
        if v.size != 2:
            return base
        y = float(v[1])
        if math.isnan(y):
            return base
        if y < 0:
            return 2 * math.pi - base
        return base


# Classification response:
# import reorganization;standard library helper;temporary variable;type conversion;guard clause;early return;boundary case handling;type check;mathematical formula;behavior change