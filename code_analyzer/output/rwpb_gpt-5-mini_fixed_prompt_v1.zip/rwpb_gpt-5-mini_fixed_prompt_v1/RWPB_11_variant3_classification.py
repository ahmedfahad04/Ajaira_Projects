
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    from typing import List
    def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        # Build result by computing indices mapping
        if ls is None:
            ls = []
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be a non-negative integer")
        n = len(ls)
        if n > max_seq_length:
            if check:
                raise ValueError("Input longer than max_seq_length")
            # truncate preserving side
            if pad_right:
                ls2 = ls[:max_seq_length]
            else:
                ls2 = ls[-max_seq_length:]
            return list(ls2)
        if n == max_seq_length:
            return list(ls)
        # build using direct indexing
        if pad_right:
            return [ls[i] if i < n else pad_idx for i in range(max_seq_length)]
        else:
            offset = max_seq_length - n
            return [pad_idx if i < offset else ls[i - offset] for i in range(max_seq_length)]


# Classification response:
# guard clause; early return; list comprehension; index-based loop; temporary variable; input validation; type check; empty input handling; boundary case handling; helper function extraction; import reorganization; behavior change