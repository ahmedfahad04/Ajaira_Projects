
def psnr_to_mse(psnr):
    import numpy as np
    def psnr_to_mse(psnr):
        psnr_arr = np.asarray(psnr)
        result = np.exp(-0.1 * np.log(10.0) * psnr_arr)
        if np.isscalar(psnr) or psnr_arr.ndim == 0:
            return float(result)
        return result


# Classification response:
# import reorganization; helper function extraction; guard clause; combined condition; temporary variable; type conversion; boundary case handling; literal rewrite; standard library helper