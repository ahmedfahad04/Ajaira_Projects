
def extract_code_from_funct(funct: Callable) -> List[str]:
    import inspect
    import textwrap
    from typing import Callable, List
    def extract_code_from_funct(funct: Callable) -> List[str]:
        try:
            src_lines, _ = inspect.getsourcelines(funct)
        except (OSError, IOError, TypeError):
            return []
        # join and dedent
        src = "".join(src_lines)
        ded = textwrap.dedent(src)
        lines = ded.splitlines()
        # find def line index
        def_i = None
        for i, ln in enumerate(lines):
            if ln.lstrip().startswith("def ") or ln.lstrip().startswith("async def "):
                def_i = i
                break
        if def_i is None:
            return []
        body = lines[def_i+1:]
        # compute minimal indent
        min_indent = None
        for ln in body:
            if ln.strip() == "":
                continue
            cur = len(ln) - len(ln.lstrip())
            if min_indent is None or cur < min_indent:
                min_indent = cur
        if min_indent is None:
            return []
        out = [ln[min_indent:] if len(ln) >= min_indent else "" for ln in body]
        # strip leading/trailing blank lines
        while out and out[0].strip() == "":
            out.pop(0)
        while out and out[-1].strip() == "":
            out.pop()
        # If last meaningful line starts with 'return', remove the entire return expression possibly spanning multiple lines.
        # We'll detect parentheses balance from that return line forward.
        for j in range(len(out)-1, -1, -1):
            if out[j].strip() == "" or out[j].lstrip().startswith("#"):
                continue
            last_idx = j
            break
        else:
            return out
        if out[last_idx].lstrip().startswith("return"):
            # remove from last_idx forward based on parentheses balance
            to_remove_start = last_idx
            bal = 0
            removed = 0
            for k in range(last_idx, len(out)):
                ln = out[k]
                for ch in ln:
                    if ch in "([{":
                        bal += 1
                    elif ch in ")]}":
                        if bal > 0:
                            bal -= 1
                removed += 1
                # stop when we are reasonably balanced and the line does not end with backslash or an open continuation
                if bal == 0 and not ln.rstrip().endswith("\\"):
                    break
            out = out[:to_remove_start]
            # trim trailing blanks again
            while out and out[-1].strip() == "":
                out.pop()
        return out


# Classification response:
# import reorganization; try-except wrapper; early return; guard clause; conditional expression; combined condition; enumerate loop; helper function extraction; temporary variable; list comprehension; standard library helper; join/split usage; empty input handling; boundary case handling; error suppression; behavior change