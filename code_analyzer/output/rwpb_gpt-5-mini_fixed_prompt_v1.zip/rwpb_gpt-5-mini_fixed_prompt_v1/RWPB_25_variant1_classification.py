
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        """
        FloodFill-based hole filling using OpenCV floodFill.
        """
        if img is None:
            return img
        # Work on grayscale / single channel
        gray = img.copy()
        if gray.ndim == 3:
            gray = cv2.cvtColor(gray, cv2.COLOR_BGR2GRAY)
        # Binarize: treat non-zero as foreground
        _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
        # Invert image: holes become foreground for floodFill background marking
        inv = cv2.bitwise_not(bw)
        h, w = inv.shape
        # Create mask for floodFill with 2 pixels padding
        mask = np.zeros((h + 2, w + 2), dtype=np.uint8)
        inv_copy = inv.copy()
        # Flood fill from border pixels to mark background
        for x in range(w):
            if mask is None:
                break
        cv2.floodFill(inv_copy, mask, (0, 0), 255)
        # Now inv_copy has background (connected to border) filled with 255
        # Holes are foreground pixels in inv that are not part of inv_copy background
        holes = cv2.bitwise_and(inv, cv2.bitwise_not(inv_copy))
        # Combine holes into original binary image
        filled = cv2.bitwise_or(bw, holes)
        # Preserve original dtype
        if img.ndim == 3:
            # replicate to 3 channels
            return cv2.cvtColor(filled, cv2.COLOR_GRAY2BGR)
        return filled


# Classification response:
# import reorganization;guard clause;helper function extraction;for loop;tuple unpacking;temporary variable;input validation;type conversion;binarization preprocessing