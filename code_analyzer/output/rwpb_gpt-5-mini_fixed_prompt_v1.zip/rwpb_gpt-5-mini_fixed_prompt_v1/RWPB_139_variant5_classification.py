
def rotate_normalmap_by_angle_torch(normal_map, angle):
    import torch
    import numpy as np
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        if not isinstance(normal_map, torch.Tensor):
            raise TypeError("normal_map must be a torch.Tensor")
        orig_dtype = normal_map.dtype
        device = normal_map.device
        nm = normal_map.to(torch.get_default_dtype()).to(device)
        if nm.dim() == 3 and nm.shape[2] == 3:
            H, W, _ = nm.shape
            flat = nm.reshape(-1, 3)
            theta = angle * np.pi / 180.0
            c = torch.tensor(np.cos(theta), device=device, dtype=flat.dtype)
            s = torch.tensor(np.sin(theta), device=device, dtype=flat.dtype)
            R = torch.stack([torch.stack([c, torch.zeros(1, device=device, dtype=flat.dtype)[0], s]),
                             torch.stack([torch.zeros(1, device=device, dtype=flat.dtype)[0], torch.ones(1, device=device, dtype=flat.dtype)[0], torch.zeros(1, device=device, dtype=flat.dtype)[0]]),
                             torch.stack([-s, torch.zeros(1, device=device, dtype=flat.dtype)[0], c])], dim=0)
            R = R.expand(flat.shape[0], 3, 3)
            flat = flat.unsqueeze(1)
            rotated = torch.bmm(flat, R).squeeze(1)
            eps = torch.finfo(rotated.dtype).eps
            norm = torch.linalg.vector_norm(rotated, dim=1, keepdim=True).clamp_min(eps)
            rotated = rotated / norm
            return rotated.reshape(H, W, 3).to(orig_dtype)
        elif nm.dim() == 3 and nm.shape[0] == 3:
            nm = nm.permute(1, 2, 0)
            return rotate_normalmap_by_angle_torch(nm, angle).permute(2, 0, 1).to(orig_dtype)
        else:
            raise ValueError("normal_map must have shape (H,W,3) or (3,H,W)")


# Classification response:
# import reorganization; helper function extraction; recursion; input validation; type conversion; default value handling; exception handling; boundary case handling; standard library helper; loop rewrite