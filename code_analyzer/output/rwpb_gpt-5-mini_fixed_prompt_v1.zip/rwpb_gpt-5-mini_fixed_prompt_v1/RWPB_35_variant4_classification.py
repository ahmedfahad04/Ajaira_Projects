
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    from collections import deque
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        result = {}
        if not isinstance(d, dict):
            return {parent_key: d} if parent_key else {}
        q = deque()
        q.append((d, parent_key))
        while q:
            cur, base = q.popleft()
            for k, v in cur.items():
                new_key = base + sep + str(k) if base else str(k)
                if isinstance(v, dict) and v:
                    q.append((v, new_key))
                else:
                    result[new_key] = v
        return result


# Classification response:
# loop rewrite; queue-based; accumulator dict; standard library helper; early return; input validation; string formatting change