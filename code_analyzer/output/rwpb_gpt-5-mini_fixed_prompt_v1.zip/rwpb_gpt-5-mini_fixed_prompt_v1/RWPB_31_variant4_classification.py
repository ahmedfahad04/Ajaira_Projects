
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        N = tensor.shape[0]
        if batch_size == N:
            return tensor
        if N == 0:
            raise ValueError("original batch size is zero")
        device = tensor.device
        # Compute fractional positions
        pos = torch.linspace(0.0, float(N - 1), steps=batch_size, device=device, dtype=torch.float32)
        idx0 = pos.floor().long().clamp(0, N - 1)
        idx1 = pos.ceil().long().clamp(0, N - 1)
        frac = (pos - idx0.to(pos.dtype)).to(torch.float32)
        a = tensor[idx0].to(torch.float32)
        b = tensor[idx1].to(torch.float32)
        # use torch.lerp for linear interpolation
        # prepare frac to broadcast
        shape = (batch_size,) + (1,) * (tensor.dim() - 1)
        frac_b = frac.view(shape)
        out = torch.lerp(a, b, frac_b)
        if tensor.dtype.is_floating_point:
            return out.to(tensor.dtype)
        else:
            return out.round().to(tensor.dtype)


# Classification response:
# variable renaming; import reorganization; loop rewrite; flattened conditional; temporary variable; vectorized tensor ops; linear interpolation resampling; input validation; empty input handling; type conversion