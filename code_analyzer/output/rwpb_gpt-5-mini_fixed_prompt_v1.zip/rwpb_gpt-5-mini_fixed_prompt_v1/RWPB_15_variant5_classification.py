
def cosine_distance(a, b):
    import numpy as np
    import math
    def cosine_distance(a, b):
        a = np.asarray(a, dtype=float).ravel()
        b = np.asarray(b, dtype=float)
        if b.ndim == 1:
            if a.size != b.size:
                raise KeyError("Length mismatch between a and b")
            na = math.sqrt((a * a).sum())
            nb = math.sqrt((b * b).sum())
            if na == 0 or nb == 0:
                return 1.0
            cos = float((a * b).sum()) / (na * nb)
            cos = max(-1.0, min(1.0, cos))
            return 1.0 - cos
        elif b.ndim >= 2:
            if a.size != b.shape[-1]:
                raise KeyError("Length mismatch between a and b")
            flat = b.reshape(-1, b.shape[-1])
            na = math.sqrt((a * a).sum())
            dots = (flat * a).sum(axis=1)
            nbs = np.sqrt((flat * flat).sum(axis=1))
            res = []
            for d, nb in zip(dots, nbs):
                if na == 0 or nb == 0:
                    res.append(1.0)
                else:
                    c = d / (na * nb)
                    c = max(-1.0, min(1.0, c))
                    res.append(1.0 - c)
            out = np.array(res)
            return out.reshape(b.shape[:-1])
        else:
            raise KeyError("b must be vector or have last dimension equal to len(a)")


# Classification response:
# import reorganization; type conversion; split condition; for loop; accumulator list; zip usage; temporary variable; standard library helper; input validation; boundary case handling; exception handling; behavior change; early return; mathematical formula