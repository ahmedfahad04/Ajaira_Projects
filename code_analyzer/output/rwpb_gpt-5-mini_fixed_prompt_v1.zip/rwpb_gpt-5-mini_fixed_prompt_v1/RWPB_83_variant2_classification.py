
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        if not isinstance(sample, dict):
            raise ValueError("sample must be a dict")
        target_h, target_w = size
        def get_hw(x):
            if x is None:
                return None
            if isinstance(x, np.ndarray):
                return x.shape[0], x.shape[1]
            raise ValueError("Unsupported type in sample")
        hws = [get_hw(sample.get(k)) for k in ("image", "disparity", "mask")]
        hws = [x for x in hws if x is not None]
        if not hws:
            return (target_h, target_w)
        # pick the reference smallest one to guarantee all meet min
        h, w = hws[0]
        # compute required scale so both dims >= target
        scale = max(float(target_h) / h, float(target_w) / w, 1.0)
        if scale == 1.0:
            return (h, w)
        new_h = int(math.ceil(h * scale))
        new_w = int(math.ceil(w * scale))
        # choose interpolation dynamically: upscaling use cubic, downscaling use provided
        def choose_interp(scale_factor, default):
            return cv2.INTER_CUBIC if scale_factor > 1.0 else default
        if sample.get("image") is not None:
            img = sample["image"]
            interp = choose_interp(scale, image_interpolation_method)
            sample["image"] = cv2.resize(img, (new_w, new_h), interpolation=interp)
        if sample.get("disparity") is not None:
            d = sample["disparity"]
            # use nearest if discrete labels, else linear; detect integer dtype
            interp = cv2.INTER_NEAREST if np.issubdtype(d.dtype, np.integer) else cv2.INTER_LINEAR
            disp_resized = cv2.resize(d, (new_w, new_h), interpolation=interp)
            # multiply by scale for true disparity values
            if disp_resized.dtype.kind in ('u', 'i', 'f'):
                disp_resized = (disp_resized.astype(np.float32) * scale).astype(d.dtype) if np.issubdtype(d.dtype, np.integer) else disp_resized.astype(np.float32) * scale
            sample["disparity"] = disp_resized
        if sample.get("mask") is not None:
            m = sample["mask"]
            mask_resized = cv2.resize(m, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            # ensure binary 0/1 if original was boolean-like
            if m.dtype == np.bool_:
                mask_resized = mask_resized > 0.5
            else:
                mask_resized = mask_resized.astype(m.dtype)
            sample["mask"] = mask_resized
        return (new_h, new_w)


# Classification response:
# input validation;guard clause;early return;helper function extraction;list comprehension;tuple unpacking;variable renaming;import reorganization;type check;type conversion;empty input handling;behavior change;temporary variable