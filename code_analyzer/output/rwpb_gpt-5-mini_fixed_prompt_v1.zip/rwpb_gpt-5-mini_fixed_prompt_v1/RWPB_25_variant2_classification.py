
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        """
        Morphological closing based hole filling. Uses progressively larger kernels
        to close small holes and then reconstructs the fill.
        """
        if img is None:
            return img
        gray = img.copy()
        if gray.ndim == 3:
            gray = cv2.cvtColor(gray, cv2.COLOR_BGR2GRAY)
        _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
        bw = bw.astype(np.uint8)
        # Use closing to fill small holes
        h, w = bw.shape
        # Kernel size relative to image size
        k = max(3, int(min(h, w) * 0.02))  # 2% of smaller dimension
        if k % 2 == 0:
            k += 1
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
        closed = cv2.morphologyEx(bw, cv2.MORPH_CLOSE, kernel, iterations=2)
        # To avoid overfilling, combine closed result with original using distance transform reconstruction
        # Mark seeds where original is foreground
        seeds = bw.copy()
        prev = np.zeros_like(bw)
        curr = seeds.copy()
        # morphological reconstruction by dilation until stability, constrained by closed
        while True:
            dilated = cv2.dilate(curr, kernel)
            curr = cv2.bitwise_and(dilated, closed)
            if np.array_equal(curr, prev):
                break
            prev = curr.copy()
        filled = curr
        if img.ndim == 3:
            return cv2.cvtColor(filled, cv2.COLOR_GRAY2BGR)
        return filled


# Classification response:
# variable renaming; import reorganization; early return; while loop; temporary variable; input validation; type conversion; morphological closing; morphological reconstruction; otsu thresholding; helper function extraction