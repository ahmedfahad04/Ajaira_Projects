
def is_byte_token(s: str) -> bool:
    def is_byte_token(s: str) -> bool:
        if not isinstance(s, str):
            return False
        if len(s) != 6:
            return False
        if not (s.startswith("<0x") or s.startswith("<0X")) or not s.endswith(">"):
            return False
        hex_str = s[3:-1]
        if len(hex_str) != 2:
            return False
        try:
            val = int(hex_str, 16)
        except ValueError:
            return False
        return 0 <= val <= 0xFF


# Classification response:
# 