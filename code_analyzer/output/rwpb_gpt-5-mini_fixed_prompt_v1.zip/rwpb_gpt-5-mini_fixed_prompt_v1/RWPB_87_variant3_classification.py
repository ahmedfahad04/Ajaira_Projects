
def rotate_x(a, device=None):
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        if device is not None:
            device = torch.device(device)
        ca = np.cos(a).astype(np.float32)
        sa = np.sin(a).astype(np.float32)
        m = torch.zeros((4,4), dtype=torch.float32, device=device)
        m[0,0] = 1.0
        m[3,3] = 1.0
        m[1,1] = ca
        m[1,2] = -sa
        m[2,1] = sa
        m[2,2] = ca
        return m


# Classification response:
# import reorganization; in-place mutation; temporary variable; guard clause; type conversion; behavior change