
def rotate_normalmap_by_angle_torch(normal_map, angle):
    import torch
    import numpy as np
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        if not isinstance(normal_map, torch.Tensor):
            raise TypeError("normal_map must be a torch.Tensor")
        orig_dtype = normal_map.dtype
        device = normal_map.device
        nm = normal_map.to(torch.get_default_dtype()).to(device)
        if nm.dim() == 3 and nm.shape[2] == 3:
            H, W, C = nm.shape
            reshaped = nm.reshape(-1, 3)
            theta = torch.tensor(angle * np.pi / 180.0, device=device, dtype=reshaped.dtype)
            c = torch.cos(theta)
            s = torch.sin(theta)
            R = torch.tensor([[c, 0.0, s],
                              [0.0, 1.0, 0.0],
                              [-s, 0.0, c]], device=device, dtype=reshaped.dtype)
            rotated = reshaped @ R.t()
            eps = torch.finfo(rotated.dtype).eps
            norm = torch.linalg.norm(rotated, dim=1, keepdim=True).clamp_min(eps)
            rotated = rotated / norm
            return rotated.reshape(H, W, 3).to(orig_dtype)
        elif nm.dim() == 3 and nm.shape[0] == 3:
            nm = nm.permute(1, 2, 0)
            return rotate_normalmap_by_angle_torch(nm, angle).permute(2, 0, 1).to(orig_dtype)
        else:
            raise ValueError("normal_map must have shape (H,W,3) or (3,H,W)")


# Classification response:
# import reorganization; guard clause; input validation; type conversion; default value handling; boundary case handling; behavior change; combined condition; recursion; helper function extraction; temporary variable; tuple unpacking; unit vector normalization