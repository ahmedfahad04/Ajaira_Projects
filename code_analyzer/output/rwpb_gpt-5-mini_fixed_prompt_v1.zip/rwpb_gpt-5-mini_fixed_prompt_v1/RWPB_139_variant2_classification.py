
def rotate_normalmap_by_angle_torch(normal_map, angle):
    import torch
    import numpy as np
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        if not isinstance(normal_map, torch.Tensor):
            raise TypeError("normal_map must be a torch.Tensor")
        device = normal_map.device
        dtype = normal_map.dtype
        nm = normal_map.to(torch.get_default_dtype()).to(device)
        if nm.dim() == 3 and nm.shape[2] == 3:
            theta = angle * np.pi / 180.0
            c = float(np.cos(theta))
            s = float(np.sin(theta))
            x = nm[..., 0]
            y = nm[..., 1]
            z = nm[..., 2]
            x_new = c * x + s * z
            y_new = y
            z_new = -s * x + c * z
            out = torch.stack((x_new, y_new, z_new), dim=-1)
            eps = torch.finfo(out.dtype).eps
            norm = torch.sqrt((out ** 2).sum(dim=-1, keepdim=True)).clamp_min(eps)
            out = out / norm
            return out.to(dtype)
        elif nm.dim() == 3 and nm.shape[0] == 3:
            nm = nm.permute(1, 2, 0)
            return rotate_normalmap_by_angle_torch(nm, angle).permute(2, 0, 1).to(dtype)
        else:
            raise ValueError("normal_map must have shape (H,W,3) or (3,H,W)")


# Classification response:
# import reorganization;input validation;type check;guard clause;exception handling;split condition;recursion with base case;type conversion;default value handling;mathematical formula;temporary variable;numpy usage;boundary case handling