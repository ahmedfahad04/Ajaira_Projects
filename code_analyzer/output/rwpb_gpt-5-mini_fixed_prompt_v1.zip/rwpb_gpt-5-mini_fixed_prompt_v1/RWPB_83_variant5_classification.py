
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        if sample is None:
            return (size[0], size[1])
        target_h, target_w = size
        # helper: compute required new dims for an array
        def required_dims(arr):
            if arr is None:
                return None
            if not isinstance(arr, np.ndarray):
                return None
            h, w = arr.shape[:2]
            sh = float(target_h) / h if h < target_h else 1.0
            sw = float(target_w) / w if w < target_w else 1.0
            s = max(sh, sw, 1.0)
            return int(math.ceil(h * s)), int(math.ceil(w * s)), s
        # determine the max new dims required by any present array
        candidates = [required_dims(sample.get(k)) for k in ("image", "disparity", "mask")]
        candidates = [c for c in candidates if c is not None]
        if not candidates:
            return (target_h, target_w)
        # choose dims that satisfy all (max of each)
        new_h = max(c[0] for c in candidates)
        new_w = max(c[1] for c in candidates)
        # compute global scale relative to each array when needed
        # resize image
        if "image" in sample and sample["image"] is not None:
            img = sample["image"]
            interp = image_interpolation_method
            sample["image"] = cv2.resize(img, (new_w, new_h), interpolation=interp)
        if "disparity" in sample and sample["disparity"] is not None:
            d = sample["disparity"]
            h, w = d.shape[:2]
            if h == 0 or w == 0:
                sample["disparity"] = d
            else:
                scale_y = new_h / float(h)
                scale_x = new_w / float(w)
                # assume isotropic scaling for disparity values: use average scale
                val_scale = (scale_x + scale_y) / 2.0
                interp = cv2.INTER_LINEAR if not np.issubdtype(d.dtype, np.integer) else cv2.INTER_NEAREST
                d_res = cv2.resize(d, (new_w, new_h), interpolation=interp)
                if not np.issubdtype(d.dtype, np.integer):
                    d_res = d_res.astype(np.float32) * val_scale
                    try:
                        d_res = d_res.astype(d.dtype)
                    except Exception:
                        pass
                sample["disparity"] = d_res
        if "mask" in sample and sample["mask"] is not None:
            m = sample["mask"]
            m_res = cv2.resize(m, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            # if original was boolean, convert back
            if m.dtype == np.bool_:
                sample["mask"] = m_res > 0.5
            else:
                sample["mask"] = m_res.astype(m.dtype)
        return (new_h, new_w)


# Classification response:
# guard clause; early return; helper function extraction; try-except wrapper; combined condition; list comprehension; generator expression; tuple unpacking; in-place mutation; import reorganization; input validation; empty input handling; boundary case handling; type check; type conversion; error suppression; behavior change