
def is_byte_token(s: str) -> bool:
    def is_byte_token(s: str) -> bool:
        try:
            if s[0] != '<' or s[-1] != '>':
                return False
            if s[1] != '0' or s[2].lower() != 'x':
                return False
            hex_part = s[3:5]
            if len(hex_part) != 2:
                return False
            bytes.fromhex(hex_part)
            return True
        except Exception:
            return False


# Classification response:
# 