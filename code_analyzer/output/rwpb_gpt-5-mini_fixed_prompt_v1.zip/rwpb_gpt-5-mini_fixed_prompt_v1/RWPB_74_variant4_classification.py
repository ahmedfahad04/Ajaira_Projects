
def arccos2(vector, value):
    import math
    import numpy as np
    from decimal import Decimal, getcontext, ROUND_HALF_UP
    getcontext().prec = 28
    def arccos2(vector, value):
        v = np.asarray(vector, dtype=float)
        val = float(value)
        # robust clamp using Decimal to avoid tiny overflows
        dv = Decimal(val)
        if dv > Decimal(1):
            dv = Decimal(1)
        if dv < Decimal(-1):
            dv = Decimal(-1)
        base = float(Decimal(math.acos(float(dv))))
        if v.size != 2:
            return base
        y = float(v[1])
        # use sign of y (with tiny tolerance) to decide orientation; if negative -> -base
        if y < -1e-12:
            return -base
        else:
            return base


# Classification response:
# variable renaming;helper function extraction;guard clause;flattened conditional;temporary variable;type conversion;import reorganization;standard library helper;input validation;boundary case handling;behavior change