
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        h0, w0 = original_size
        t = tensor
        if t.dim() == 3:
            c, H, W = t.shape
            top = (H - h0) // 2 if H > h0 else 0
            left = (W - w0) // 2 if W > w0 else 0
            height = min(h0, H)
            width = min(w0, W)
            out = t[:, top:top+height, left:left+width]
            if out.shape[1] < h0 or out.shape[2] < w0:
                pad_h = h0 - out.shape[1]
                pad_w = w0 - out.shape[2]
                pad_top = pad_h // 2
                pad_bottom = pad_h - pad_top
                pad_left = pad_w // 2
                pad_right = pad_w - pad_left
                out = F.pad(out, (pad_left, pad_right, pad_top, pad_bottom))
            return out
        elif t.dim() == 4:
            n, c, H, W = t.shape
            top = (H - h0) // 2 if H > h0 else 0
            left = (W - w0) // 2 if W > w0 else 0
            height = min(h0, H)
            width = min(w0, W)
            out = t[:, :, top:top+height, left:left+width]
            if out.shape[2] < h0 or out.shape[3] < w0:
                pad_h = h0 - out.shape[2]
                pad_w = w0 - out.shape[3]
                pad_top = pad_h // 2
                pad_bottom = pad_h - pad_top
                pad_left = pad_w // 2
                pad_right = pad_w - pad_left
                out = F.pad(out, (pad_left, pad_right, pad_top, pad_bottom))
            return out
        else:
            raise ValueError("Expected 3D (C,H,W) or 4D (N,C,H,W) tensor")


# Classification response:
# variable renaming; tuple unpacking; temporary variable; import reorganization; early return; flattened conditional; input validation; boundary case handling; exception handling; standard library helper; behavior change