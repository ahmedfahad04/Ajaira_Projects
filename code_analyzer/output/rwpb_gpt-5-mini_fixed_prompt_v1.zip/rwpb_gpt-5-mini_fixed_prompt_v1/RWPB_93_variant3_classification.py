
def unsafeSub(x, y):
    MAX_VAL = (1 << 256) - 1
    BASE = MAX_VAL + 1
    def unsafeSub(x, y):
        if x >= y:
            return x - y
        else:
            return (BASE - (y - x)) & MAX_VAL


# Classification response:
# literal rewrite; temporary variable; nested function; guard clause; boundary case handling