
def extract_code_from_funct(funct: Callable) -> List[str]:
    import inspect
    import textwrap
    from typing import Callable, List
    def extract_code_from_funct(funct: Callable) -> List[str]:
        try:
            src = inspect.getsource(funct)
        except (OSError, TypeError):
            return []
        # Normalize indentation
        src = textwrap.dedent(src)
        lines = src.splitlines()
        # Find the function definition line
        def_idx = None
        for i, ln in enumerate(lines):
            if ln.lstrip().startswith("def ") or ln.lstrip().startswith("async def "):
                def_idx = i
                break
        if def_idx is None:
            return []
        body_lines = lines[def_idx+1:]
        # Determine minimal indentation among non-blank lines
        min_indent = None
        for ln in body_lines:
            if ln.strip() == "":
                continue
            leading = len(ln) - len(ln.lstrip())
            if min_indent is None or leading < min_indent:
                min_indent = leading
        if min_indent is None:
            return []
        # Strip the indentation
        out = [ln[min_indent:] if len(ln) >= min_indent else "" for ln in body_lines]
        # Remove trailing blank lines
        while out and out[-1].strip() == "":
            out.pop()
        # Remove final return if present (simple one-line return)
        if out and out[-1].lstrip().startswith("return"):
            out.pop()
            # remove trailing blanks again
            while out and out[-1].strip() == "":
                out.pop()
        # Remove leading blank lines
        while out and out[0].strip() == "":
            out.pop(0)
        return out


# Classification response:
# try-except wrapper;guard clause;enumerate loop;while loop;combined condition;standard library helper;import reorganization;accumulator list;temporary variable;list comprehension;input validation;empty input handling;boundary case handling;error suppression