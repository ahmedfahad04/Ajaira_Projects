
def movmean(arr, n_avg):
    import numpy as np
    def movmean(arr, n_avg):
        arr = np.asarray(arr)
        if n_avg <= 0 or n_avg > arr.size or arr.ndim != 1:
            return np.array([])
        L = arr.size
        out_len = L - n_avg + 1
        res = np.empty(out_len, dtype=float)
        s = float(np.sum(arr[:n_avg]))
        res[0] = s / n_avg
        for i in range(1, out_len):
            s += float(arr[i + n_avg - 1]) - float(arr[i - 1])
            res[i] = s / n_avg
        return res


# Classification response:
# sliding window; loop rewrite; for loop; guard clause; input validation; type conversion; import reorganization; temporary variable; state variable