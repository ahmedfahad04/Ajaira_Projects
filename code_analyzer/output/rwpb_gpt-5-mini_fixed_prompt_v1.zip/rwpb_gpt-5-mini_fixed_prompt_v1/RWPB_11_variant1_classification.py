
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    from typing import List
    def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be a non-negative integer")
        if ls is None:
            ls = []
        n = len(ls)
        if n == max_seq_length:
            return list(ls)
        if n > max_seq_length:
            if check:
                raise ValueError("Input length is greater than max_seq_length")
            # when not checking, truncate
            return list(ls[:max_seq_length]) if pad_right else list(ls[-max_seq_length:])
        # need padding
        pad_count = max_seq_length - n
        pads = [pad_idx] * pad_count
        return list(ls) + pads if pad_right else pads + list(ls)


# Classification response:
# variable renaming; helper function extraction; guard clause; early return; flattened conditional; conditional expression; temporary variable; list conversion; import reorganization; input validation; empty input handling; type check; boundary case handling; exception handling