
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        """
        Apply rotation using batched matrix multiplication by permuting geometry, then translate.
        """
        # geometry: [B, N, 3] -> [B, 3, N] for bmm
        geom_permuted = geometry.permute(0, 2, 1)  # [B, 3, N]
        # rot: [B, 3, 3] @ geom_permuted: [B, 3, N]
        rotated_permuted = torch.bmm(rot, geom_permuted)
        # back to [B, N, 3]
        rotated = rotated_permuted.permute(0, 2, 1)
        return rotated + trans.unsqueeze(1)


# Classification response:
# variable renaming;temporary variable;import reorganization;helper function extraction;formatting only