
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        x0, y0, x1, y1 = box
        if expand < 0:
            raise ValueError("expand must be non-negative")
        # Normalize box
        x_min = x0 if x0 <= x1 else x1
        x_max = x1 if x1 >= x0 else x0
        y_min = y0 if y0 <= y1 else y1
        y_max = y1 if y1 >= y0 else y0
        w = x_max - x_min
        h = y_max - y_min
        # If box has zero area, treat it as tiny point and give minimal size proportional to expand
        if w == 0 and h == 0:
            s = 0.5 * max(1.0, expand)
        else:
            s = max(w, h) * expand / 2.0
        cx = (x_min + x_max) / 2.0
        cy = (y_min + y_max) / 2.0
        new_x = cx - s
        new_y = cy - s
        new_x1 = cx + s
        new_y1 = cy + s
        return [new_x, new_y, new_x1, new_y1], s


# Classification response:
# variable renaming;guard clause;conditional expression;input validation;boundary case handling;type conversion