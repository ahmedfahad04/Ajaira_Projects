
def is_byte_token(s: str) -> bool:
    import re
    def is_byte_token(s: str) -> bool:
        if not isinstance(s, str):
            return False
        return re.fullmatch(r"<0[xX][0-9A-Fa-f]{2}>", s) is not None


# Classification response:
# 