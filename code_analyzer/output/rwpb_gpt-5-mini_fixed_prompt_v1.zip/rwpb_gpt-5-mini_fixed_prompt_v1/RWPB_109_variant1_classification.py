
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        """
        Apply rotation and translation to geometry using batched matmul with rotated transpose.
        geometry: [B, N, 3], rot: [B, 3, 3], trans: [B, 3]
        """
        # Rotate: multiply geometry by rot^T so that result[b,n,i] = sum_j geometry[b,n,j] * rot[b,i,j]
        rotated = torch.matmul(geometry, rot.transpose(-2, -1))
        # Translate: broadcast translation over points
        return rotated + trans.unsqueeze(1)


# Classification response:
# import reorganization; helper function extraction; temporary variable; builtin function