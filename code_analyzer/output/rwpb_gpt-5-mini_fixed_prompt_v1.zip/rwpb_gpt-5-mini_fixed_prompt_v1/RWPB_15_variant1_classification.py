
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        a = np.asarray(a, dtype=float).ravel()
        b = np.asarray(b, dtype=float)
        if a.ndim != 1:
            a = a.ravel()
        if b.ndim == 1:
            if a.size != b.size:
                raise KeyError("Length mismatch between a and b")
            dot = float(np.dot(a, b))
            na = np.linalg.norm(a)
            nb = np.linalg.norm(b)
            if na == 0 or nb == 0:
                return 1.0
            cos = dot / (na * nb)
            return float(1.0 - np.clip(cos, -1.0, 1.0))
        elif b.ndim == 2:
            if a.size != b.shape[1]:
                raise KeyError("Length mismatch between a and b")
            dots = b.dot(a)
            na = np.linalg.norm(a)
            nb = np.linalg.norm(b, axis=1)
            denom = na * nb
            with np.errstate(divide='ignore', invalid='ignore'):
                cos = np.where(denom == 0, 0.0, dots / denom)
            cos = np.clip(cos, -1.0, 1.0)
            return 1.0 - cos
        else:
            raise KeyError("b must be a vector or a 2D matrix")


# Classification response:
# import reorganization;helper function extraction;split condition;early return;guard clause;temporary variable;type conversion;input validation;boundary case handling;error suppression;behavior change