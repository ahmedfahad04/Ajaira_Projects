
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        """
        Rescale segment masks to shape.
        masks: (N, C, H, W)
        shape: (height, width)
        """
        if not isinstance(masks, torch.Tensor):
            masks = torch.tensor(masks)
        N, C, H, W = masks.shape
        target_h, target_w = int(shape[0]), int(shape[1])
        # If no padding assumption, simple resize
        if not padding:
            out = F.interpolate(masks.view(-1, 1, H, W), size=(target_h, target_w),
                                mode='bilinear', align_corners=False)
            return out.view(N, C, target_h, target_w)
        # Assume YOLO-style letterbox: input was scaled so that max(shape) -> model size (H or W)
        # Compute scale relative to max original side
        max_orig = max(target_h, target_w)
        # compute model padded size (assume square or either dimension)
        model_h, model_w = H, W
        # scale factor: how much original was scaled to get inside model dims
        gain = float(max(model_h, model_w)) / float(max_orig)
        # compute scaled original size in model coords
        scaled_h = int(round(target_h * gain))
        scaled_w = int(round(target_w * gain))
        # compute padding (centered)
        pad_h = max(model_h - scaled_h, 0)
        pad_w = max(model_w - scaled_w, 0)
        top = int(round(pad_h / 2.0))
        left = int(round(pad_w / 2.0))
        bottom = top + scaled_h
        right = left + scaled_w
        # clip to bounds
        top = max(0, min(top, model_h))
        left = max(0, min(left, model_w))
        bottom = max(top, min(bottom, model_h))
        right = max(left, min(right, model_w))
        # crop the non-padded region
        if bottom <= top or right <= left:
            # fallback: resize entire mask to target
            out = F.interpolate(masks.view(-1, 1, H, W), size=(target_h, target_w),
                                mode='bilinear', align_corners=False)
            return out.view(N, C, target_h, target_w)
        cropped = masks[:, :, top:bottom, left:right]
        out = F.interpolate(cropped.view(-1, 1, cropped.shape[-2], cropped.shape[-1]),
                            size=(target_h, target_w), mode='bilinear', align_corners=False)
        out = out.view(N, C, target_h, target_w)
        # If original masks were boolean-like, threshold
        if masks.dtype == torch.bool or masks.dtype == torch.uint8:
            out = (out > 0.5).to(masks.dtype)
        return out


# Classification response:
# variable renaming; guard clause; early return; tuple unpacking; temporary variable; import reorganization; mathematical formula; type conversion; input validation; boundary case handling