
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    from typing import List
    from itertools import islice, chain, repeat
    def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        if ls is None:
            ls = []
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be a non-negative integer")
        n = len(ls)
        if n == max_seq_length:
            return list(ls)
        if n > max_seq_length:
            if check:
                raise ValueError("Result length would not equal max_seq_length")
            # Truncate depending on pad direction convention
            return list(islice(ls, max_seq_length)) if pad_right else list(ls[-max_seq_length:])
        # n < max_seq_length: pad using itertools.repeat for efficiency
        pad_iter = repeat(pad_idx, max_seq_length - n)
        if pad_right:
            return list(chain(ls, pad_iter))
        else:
            return list(chain(pad_iter, ls))


# Classification response:
# guard clause; early return; flattened conditional; conditional expression; temporary variable; slicing; itertools usage; list conversion; input validation; type check; empty input handling; default value handling; boundary case handling; behavior change; import reorganization; exception handling