
def extract_code_from_funct(funct: Callable) -> List[str]:
    import inspect
    import ast
    import textwrap
    from typing import Callable, List
    def extract_code_from_funct(funct: Callable) -> List[str]:
        try:
            src = inspect.getsource(funct)
        except (OSError, TypeError):
            return []
        ded = textwrap.dedent(src)
        try:
            mod = ast.parse(ded)
        except SyntaxError:
            # fallback: simple split approach
            lines = ded.splitlines()
            idx = 0
            for i, ln in enumerate(lines):
                if ln.lstrip().startswith("def ") or ln.lstrip().startswith("async def "):
                    idx = i
                    break
            body = lines[idx+1:]
            # remove common indent
            min_indent = None
            for ln in body:
                if ln.strip():
                    lead = len(ln) - len(ln.lstrip())
                    if min_indent is None or lead < min_indent:
                        min_indent = lead
            if min_indent is None:
                return []
            out = [ln[min_indent:] for ln in body]
            while out and out[0].strip() == "":
                out.pop(0)
            while out and out[-1].strip() == "":
                out.pop()
            if out and out[-1].lstrip().startswith("return"):
                out.pop()
            return out
        # Find the correct function node (prefer one with matching name and smallest lineno)
        func_nodes = [n for n in ast.walk(mod) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == funct.__name__]
        func = None
        if func_nodes:
            func = min(func_nodes, key=lambda n: getattr(n, "lineno", 0))
        else:
            # fallback to first function in module
            for n in mod.body:
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    func = n
                    break
        if func is None:
            return []
        out_lines: List[str] = []
        # take all body nodes except trailing Return
        body_nodes = list(func.body)
        if body_nodes and isinstance(body_nodes[-1], ast.Return):
            body_nodes = body_nodes[:-1]
        src_lines = ded.splitlines()
        for node in body_nodes:
            # use node lineno/end_lineno to extract precise lines
            start = getattr(node, "lineno", None)
            end = getattr(node, "end_lineno", None)
            if start is None or end is None:
                # try ast.get_source_segment
                seg = ast.get_source_segment(ded, node)
                if seg:
                    for ln in textwrap.dedent(seg).splitlines():
                        out_lines.append(ln)
                continue
            seg_lines = src_lines[start-1:end]
            seg = "\n".join(seg_lines)
            for ln in textwrap.dedent(seg).splitlines():
                out_lines.append(ln)
        # Trim leading/trailing blank lines
        while out_lines and out_lines[0].strip() == "":
            out_lines.pop(0)
        while out_lines and out_lines[-1].strip() == "":
            out_lines.pop()
        return out_lines


# Classification response:
# import reorganization;try-except wrapper;guard clause;accumulator list;list conversion;standard library helper;join/split usage;ast-based parsing;empty input handling;boundary case handling;error suppression