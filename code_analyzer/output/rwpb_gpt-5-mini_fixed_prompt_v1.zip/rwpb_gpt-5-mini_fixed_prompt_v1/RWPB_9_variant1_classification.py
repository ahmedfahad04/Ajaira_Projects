
def is_byte_token(s: str) -> bool:
    def is_byte_token(s: str) -> bool:
        if not isinstance(s, str):
            return False
        if len(s) != 6:
            return False
        if s[0] != '<' or s[-1] != '>':
            return False
        if s[1] != '0' or s[2] not in ('x', 'X'):
            return False
        hex_part = s[3:5]
        hexdigits = "0123456789abcdefABCDEF"
        return all(ch in hexdigits for ch in hex_part)


# Classification response:
# 