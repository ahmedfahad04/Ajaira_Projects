
def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
    from typing import List
    def pad_to_max_seq_length(ls: List[int], max_seq_length: int, pad_idx: int=0, pad_right: bool=True, check: bool=True):
        # Validate
        if ls is None:
            ls = []
        if not isinstance(max_seq_length, int) or max_seq_length < 0:
            raise ValueError("max_seq_length must be a non-negative integer")
        length = len(ls)
        # If longer than allowed
        if length > max_seq_length:
            if check:
                raise ValueError("Sequence longer than max_seq_length")
            # Truncate depending on padding side
            return list(ls[:max_seq_length]) if pad_right else list(ls[-max_seq_length:])
        # Compute pads quickly with multiplication
        needed = max_seq_length - length
        if needed == 0:
            return list(ls)
        pads = [pad_idx] * needed
        if pad_right:
            return ls + pads if isinstance(ls, list) else list(ls) + pads
        else:
            return pads + (ls if isinstance(ls, list) else list(ls))


# Classification response:
# guard clause; early return; input validation; type check; empty input handling; boundary case handling; behavior change; list conversion; temporary variable; import reorganization