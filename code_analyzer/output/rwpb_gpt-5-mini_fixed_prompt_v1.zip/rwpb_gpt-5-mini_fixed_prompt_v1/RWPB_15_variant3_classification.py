
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        a = np.asarray(a, dtype=float).ravel()
        b = np.asarray(b, dtype=float)
        if b.ndim == 1:
            if a.size != b.size:
                raise KeyError("Length mismatch between a and b")
            num = np.einsum('i,i->', a, b)
            na = np.sqrt(np.einsum('i,i->', a, a))
            nb = np.sqrt(np.einsum('i,i->', b, b))
            if na == 0 or nb == 0:
                return 1.0
            cos = num / (na * nb)
            return float(1.0 - np.clip(cos, -1.0, 1.0))
        elif b.ndim == 2:
            if a.size != b.shape[1]:
                raise KeyError("Length mismatch between a and b")
            num = np.einsum('i,ji->j', a, b)
            na = np.sqrt(np.einsum('i,i->', a, a))
            nb = np.sqrt(np.einsum('ji,ji->j', b, b))
            denom = na * nb
            with np.errstate(divide='ignore', invalid='ignore'):
                cos = np.where(denom == 0, 0.0, num / denom)
            cos = np.clip(cos, -1.0, 1.0)
            return 1.0 - cos
        else:
            raise KeyError("b must be 1D or 2D array")


# Classification response:
# import reorganization; helper function extraction; nested conditional; guard clause; temporary variable; numpy einsum usage; mathematical formula; input validation; boundary case handling; type conversion; error suppression; behavior change