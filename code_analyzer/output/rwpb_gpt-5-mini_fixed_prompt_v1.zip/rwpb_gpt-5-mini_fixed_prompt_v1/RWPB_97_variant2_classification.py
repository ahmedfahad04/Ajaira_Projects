
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        try:
            arr = np.asarray(image)
        except Exception:
            raise ValueError("Unable to convert input to numpy array")
        if arr.ndim == 2:
            out = np.expand_dims(arr, axis=0).astype(np.float32) / 255.0
            return torch.as_tensor(out, dtype=torch.float)
        if arr.ndim == 3:
            if arr.shape[0] <= 0 or arr.shape[1] <= 0 or arr.shape[2] <= 0:
                raise ValueError("Invalid image dimensions")
            out = np.moveaxis(arr.astype(np.float32), -1, 0) / 255.0
            return torch.as_tensor(out, dtype=torch.float)
        raise ValueError("Input is not a valid image (expected 2D or 3D array)")


# Classification response:
# import reorganization;try-except wrapper;input validation;boundary case handling;type conversion;temporary variable;branch reordering;function renaming