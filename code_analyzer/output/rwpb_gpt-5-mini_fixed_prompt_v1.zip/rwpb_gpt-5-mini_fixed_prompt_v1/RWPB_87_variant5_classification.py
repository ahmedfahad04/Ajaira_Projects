
def rotate_x(a, device=None):
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        if device is not None:
            device = torch.device(device)
        c = np.cos(a)
        s = np.sin(a)
        arr = np.eye(4, dtype=np.float32)
        arr[1,1] = c
        arr[1,2] = -s
        arr[2,1] = s
        arr[2,2] = c
        return torch.from_numpy(arr).to(device=device)


# Classification response:
# import reorganization; helper function extraction; in-place mutation; temporary variable; type conversion; behavior change