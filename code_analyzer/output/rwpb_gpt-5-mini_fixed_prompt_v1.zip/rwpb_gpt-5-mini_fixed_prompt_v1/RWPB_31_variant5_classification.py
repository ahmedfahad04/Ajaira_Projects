
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        N = tensor.shape[0]
        if batch_size == N:
            return tensor
        if N == 0:
            raise ValueError("original batch size is zero")
        # If downsampling: pick indices evenly across the original batch (rounding)
        if batch_size < N:
            idx = torch.linspace(0, N - 1, steps=batch_size, device=tensor.device)
            idx = idx.round().long().clamp(0, N - 1)
            return tensor[idx]
        # If upsampling: ensure every original element is represented by repeating elements
        repeats = batch_size // N
        rem = batch_size % N
        pieces = []
        for i in range(N):
            r = repeats + (1 if i < rem else 0)
            if r > 0:
                pieces.append(tensor[i].unsqueeze(0).repeat(r, *([1] * (tensor.dim() - 1))))
        return torch.cat(pieces, dim=0)


# Classification response:
# import reorganization;guard clause;input validation;type check;empty input handling;loop rewrite;accumulator list;temporary variable;standard library helper