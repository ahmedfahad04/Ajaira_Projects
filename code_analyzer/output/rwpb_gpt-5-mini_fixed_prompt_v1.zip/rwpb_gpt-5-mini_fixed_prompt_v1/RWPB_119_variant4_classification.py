
def rotate_about_x_axis(vector, theta):
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        v = np.asarray(vector, dtype=float)
        if v.size != 3:
            raise ValueError("Input must be a 3-element vector.")
        x = float(v[0])
        # rotate the complex number y + i*z by e^{i*theta}
        y = float(v[1])
        z = float(v[2])
        comp = complex(y, z) * complex(np.cos(theta), np.sin(theta))
        return np.array([x, comp.real, comp.imag], dtype=float)


# Classification response:
# import reorganization; guard clause; temporary variable; input validation; type conversion; boundary case handling; mathematical formula