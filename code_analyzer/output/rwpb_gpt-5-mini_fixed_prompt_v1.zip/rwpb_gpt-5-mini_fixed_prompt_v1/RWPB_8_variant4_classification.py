
def cvimg2torch(img):
    import numpy as np
    import torch
    def cvimg2torch(img):
        """
        Convert a img to tensor
        input:
            img -> ndarray uint8 HxWxC or HxW
        return
            tensor -> torch.tensor BxCxHxW (float32 normalized 0..1)
        This variant converts BGR->RGB for 3-channel images.
        """
        arr = np.asarray(img)
        if arr.ndim == 2:
            arr = arr[:, :, None]
        if arr.ndim != 3:
            raise ValueError("img must be HxW or HxWxC")
        # If 3 channels, assume BGR and convert to RGB
        if arr.shape[2] == 3:
            arr = arr[..., ::-1]
        # HWC -> CHW
        chw = arr.transpose(2, 0, 1).copy()
        tensor = torch.from_numpy(chw).float().div(255.0).unsqueeze(0)
        return tensor


# Classification response:
# variable renaming;temporary variable;helper function extraction;import reorganization;guard clause;exception handling;input validation;copy before mutation;type conversion;behavior change