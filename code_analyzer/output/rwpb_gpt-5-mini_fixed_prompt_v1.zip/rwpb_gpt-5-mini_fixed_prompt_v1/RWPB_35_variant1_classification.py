
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        result = {}
        if not isinstance(d, dict):
            return {parent_key: d} if parent_key else {}
        for k, v in d.items():
            key = f"{parent_key}{sep}{k}" if parent_key else str(k)
            if isinstance(v, dict) and v:
                result.update(flatten_dict(v, key, sep))
            else:
                result[key] = v
        return result


# Classification response:
# helper function extraction; accumulator dict; guard clause; type check; recursion with base case; in-place mutation; combined condition; string formatting change; type conversion; behavior change