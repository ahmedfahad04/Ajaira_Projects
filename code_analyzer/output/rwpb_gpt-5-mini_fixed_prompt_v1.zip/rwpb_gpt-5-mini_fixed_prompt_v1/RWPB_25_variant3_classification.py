
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        """
        Connected components approach: invert image, label components, mark background
        components touching border and fill remaining components (holes).
        """
        if img is None:
            return img
        gray = img.copy()
        if gray.ndim == 3:
            gray = cv2.cvtColor(gray, cv2.COLOR_BGR2GRAY)
        _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
        bw = bw.astype(np.uint8)
        inv = cv2.bitwise_not(bw)
        # Label connected components in inverted image
        num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(inv, connectivity=8)
        h, w = inv.shape
        # Determine which labels touch the border -> background
        border_labels = set()
        # top and bottom rows
        border_labels.update(np.unique(labels[0, :]))
        border_labels.update(np.unique(labels[h-1, :]))
        # left and right cols
        border_labels.update(np.unique(labels[:, 0]))
        border_labels.update(np.unique(labels[:, w-1]))
        # Build background mask
        background_mask = np.zeros_like(inv, dtype=np.uint8)
        for lbl in border_labels:
            if lbl == 0:
                continue
            background_mask[labels == lbl] = 255
        # Holes are inverted components that are not background
        holes_mask = cv2.bitwise_and(inv, cv2.bitwise_not(background_mask))
        filled = cv2.bitwise_or(bw, holes_mask)
        if img.ndim == 3:
            return cv2.cvtColor(filled, cv2.COLOR_GRAY2BGR)
        return filled


# Classification response:
# connected-components approach;import reorganization;helper function extraction;guard clause;input validation;tuple unpacking;accumulator set;in-place mutation;for loop;type conversion