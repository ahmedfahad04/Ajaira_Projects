
def movmean(arr, n_avg):
    import numpy as np
    def movmean(arr, n_avg):
        arr = np.asarray(arr)
        if n_avg <= 0 or n_avg > arr.size or arr.ndim != 1:
            return np.array([])
        c = np.empty(arr.size + 1, dtype=float)
        c[0] = 0.0
        c[1:] = np.cumsum(arr, dtype=float)
        mov = (c[n_avg:] - c[:-n_avg]) / float(n_avg)
        return mov


# Classification response:
# guard clause; input validation; type conversion; copy before mutation; prefix/suffix computation; import reorganization; helper function extraction