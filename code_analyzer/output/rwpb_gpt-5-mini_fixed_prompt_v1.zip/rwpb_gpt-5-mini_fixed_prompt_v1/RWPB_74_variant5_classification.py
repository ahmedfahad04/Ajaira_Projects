
def arccos2(vector, value):
    import math
    import numpy as np
    def arccos2(vector, value):
        v = np.asarray(vector, dtype=float)
        val = float(value)
        # clamp
        if val > 1.0:
            val = 1.0
        elif val < -1.0:
            val = -1.0
        base = math.acos(val)
        if v.size != 2:
            return base
        vx, vy = float(v[0]), float(v[1])
        # construct candidate unit vector for +base and -base, pick by cross product sign
        ux_pos = math.cos(base); uy_pos = math.sin(base)
        # cross = v x candidate = vx*uy - vy*ux ; positive means candidate is CCW from v
        cross_pos = vx * uy_pos - vy * ux_pos
        if cross_pos < 0:
            # candidate +base is clockwise from vector -> choose 2pi-base
            return 2 * math.pi - base
        else:
            return base


# Classification response:
# import reorganization; standard library helper; helper function extraction; type conversion; input validation; boundary case handling; temporary variable; tuple unpacking; geometric orientation