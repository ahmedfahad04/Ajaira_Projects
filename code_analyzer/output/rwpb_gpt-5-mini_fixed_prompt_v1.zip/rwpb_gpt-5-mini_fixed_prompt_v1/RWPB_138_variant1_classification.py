
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        """
        Vectorized rotation around Y-axis using rotation matrix and renormalization.
        """
        if not isinstance(normal_map, np.ndarray):
            normal_map = np.array(normal_map, dtype=np.float64)
        nm = normal_map.astype(np.float64)
        if nm.ndim != 3 or nm.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        theta = np.deg2rad(angle)
        c = np.cos(theta)
        s = np.sin(theta)
        # Rotation matrix for rotation about Y: [ [c,0,s],[0,1,0],[-s,0,c] ]
        R = np.array([[c, 0.0, s],
                      [0.0, 1.0, 0.0],
                      [-s, 0.0, c]], dtype=nm.dtype)
        # apply rotation: use einsum for clarity
        rotated = np.einsum('ij,...j->...i', R, nm)
        # renormalize to unit length to avoid numerical drift
        norms = np.linalg.norm(rotated, axis=2, keepdims=True)
        eps = 1e-12
        norms = np.maximum(norms, eps)
        rotated = rotated / norms
        return rotated


# Classification response:
# variable renaming; import reorganization; guard clause; helper function extraction; temporary variable; input validation; type conversion; boundary case handling; exception handling; standard library helper