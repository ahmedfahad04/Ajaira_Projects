
def cvimg2torch(img):
    import numpy as np
    import torch
    def cvimg2torch(img):
        """
        Convert a img to tensor
        input:
            img -> ndarray uint8 HxWxC or HxW
        return
            tensor -> torch.tensor BxCxHxW
        This variant preserves dtype if not uint8, otherwise converts to float32 normalized.
        """
        arr = np.asarray(img)
        if arr.ndim == 2:
            arr = arr[:, :, None]
        if arr.ndim == 3:
            # HWC -> CHW
            arr_chw = np.moveaxis(arr, -1, 0).copy()
            if arr_chw.dtype == np.uint8:
                t = torch.from_numpy(arr_chw).to(torch.float32).div(255.0)
            else:
                t = torch.from_numpy(arr_chw).to(torch.float32)
            return t.unsqueeze(0)
        elif arr.ndim == 4:
            # assume batch B x H x W x C -> B x C x H x W
            arr_bc = np.moveaxis(arr, -1, 1).copy()
            if arr_bc.dtype == np.uint8:
                t = torch.from_numpy(arr_bc).to(torch.float32).div(255.0)
            else:
                t = torch.from_numpy(arr_bc).to(torch.float32)
            return t
        else:
            raise ValueError("Unsupported image shape")


# Classification response:
# import reorganization; helper function extraction; split condition; early return; exception handling; input validation; boundary case handling; type conversion; behavior change; temporary variable; copy before mutation