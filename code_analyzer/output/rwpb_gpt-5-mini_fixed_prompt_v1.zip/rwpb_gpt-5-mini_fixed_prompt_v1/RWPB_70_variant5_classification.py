
def psnr_to_mse(psnr):
    import numpy as np
    import math
    def psnr_to_mse(psnr):
        # use vectorize to support scalars, lists, tuples, numpy arrays uniformly
        def scalar_calc(x):
            return math.exp(-0.1 * math.log(10.0) * float(x))
        vec = np.vectorize(scalar_calc, otypes=[float])
        res = vec(psnr)
        # if input was scalar, np.vectorize returns an array of shape () sometimes; convert
        if hasattr(psnr, '__iter__') and not isinstance(psnr, (str, bytes)):
            return res
        return float(res)


# Classification response:
# import reorganization; helper function extraction; numpy vectorize usage; standard library helper; guard clause; type check; type conversion; input validation; boundary case handling; temporary variable