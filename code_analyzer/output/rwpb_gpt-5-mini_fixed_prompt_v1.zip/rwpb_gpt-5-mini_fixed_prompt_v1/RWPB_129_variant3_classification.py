
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        """
        Brute-force per-channel resizing. Slower but straightforward.
        """
        if not isinstance(masks, torch.Tensor):
            masks = torch.tensor(masks)
        N, C, H, W = masks.shape
        target_h, target_w = int(shape[0]), int(shape[1])
        # flatten batch and channels to iterate
        out_list = []
        for n in range(N):
            ch_list = []
            for c in range(C):
                m = masks[n, c:c+1]  # shape (1, H, W)
                m = m.unsqueeze(0)   # (1,1,H,W)
                if not padding:
                    r = F.interpolate(m, size=(target_h, target_w), mode='bilinear', align_corners=False)
                else:
                    # estimate letterbox crop like common YOLO: model size corresponds to max side
                    model_h, model_w = H, W
                    gain = float(max(model_h, model_w)) / float(max(target_h, target_w))
                    scaled_h = int(round(target_h * gain))
                    scaled_w = int(round(target_w * gain))
                    pad_h = max(model_h - scaled_h, 0)
                    pad_w = max(model_w - scaled_w, 0)
                    top = int(round(pad_h / 2.0))
                    left = int(round(pad_w / 2.0))
                    bottom = top + scaled_h
                    right = left + scaled_w
                    top = max(0, min(top, model_h))
                    left = max(0, min(left, model_w))
                    bottom = max(top, min(bottom, model_h))
                    right = max(left, min(right, model_w))
                    if bottom <= top or right <= left:
                        r = F.interpolate(m, size=(target_h, target_w), mode='bilinear', align_corners=False)
                    else:
                        cropped = m[:, :, top:bottom, left:right]
                        r = F.interpolate(cropped, size=(target_h, target_w), mode='bilinear', align_corners=False)
                ch_list.append(r.squeeze(0))  # (1, H, W) -> (1, target_h, target_w)
            # stack channels
            stacked = torch.cat(ch_list, dim=0)  # (C, target_h, target_w)
            out_list.append(stacked.unsqueeze(0))  # (1, C, ...)
        result = torch.cat(out_list, dim=0)  # (N, C, target_h, target_w)
        # restore input dtype for booleans/integers
        if masks.dtype in (torch.uint8, torch.bool):
            result = (result > 0.5).to(masks.dtype)
        return result


# Classification response:
# import reorganization;loop rewrite;for loop;index-based loop;accumulator list;temporary variable;tuple unpacking;brute force;helper function extraction;type conversion;boundary case handling;nested conditional;behavior change