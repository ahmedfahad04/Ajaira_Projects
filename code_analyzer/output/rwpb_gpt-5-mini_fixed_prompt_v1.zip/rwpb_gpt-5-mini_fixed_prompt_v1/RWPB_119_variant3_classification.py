
def rotate_about_x_axis(vector, theta):
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        v = np.asarray(vector, dtype=float).reshape(3,)
        if v.shape != (3,):
            raise ValueError("vector must be length 3")
        # Use Rodrigues' rotation formula with axis k = (1,0,0)
        k = np.array([1.0, 0.0, 0.0], dtype=float)
        cos_t = np.cos(theta)
        sin_t = np.sin(theta)
        v_cos = v * cos_t
        k_cross_v = np.cross(k, v) * sin_t
        k_dot_v = np.dot(k, v)
        k_term = k * (k_dot_v * (1.0 - cos_t))
        return v_cos + k_cross_v + k_term


# Classification response:
# mathematical formula;guard clause;exception handling;input validation;type conversion;temporary variable