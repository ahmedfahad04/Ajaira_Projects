
def arccos2(vector, value):
    import math
    import numpy as np
    def arccos2(vector, value):
        v = np.asarray(vector, dtype=float)
        val = float(value)
        if val > 1.0:
            val = 1.0
        elif val < -1.0:
            val = -1.0
        base = math.acos(val)
        # Return signed angle in [-pi, pi]
        if v.size != 2:
            return base
        y = float(v[1])
        # if exactly on x-axis and pointing left, preserve sign of x to choose +/-pi
        if abs(y) < 1e-12:
            x = float(v[0])
            if x < 0:
                return math.copysign(math.pi, x)
            else:
                return base
        return -base if y < 0 else base


# Classification response:
# import reorganization;variable renaming;temporary variable;guard clause;conditional expression;standard library helper;input validation;boundary case handling;type conversion;helper function extraction