
def cvimg2torch(img):
    import numpy as np
    import torch
    def cvimg2torch(img):
        """
        Convert a img to tensor
        input:
            img -> ndarray uint8 HxWxC or HxW
        return
            tensor -> torch.tensor BxCxHxW (float32 normalized 0..1)
        """
        arr = np.asarray(img)
        if arr.ndim == 2:
            # H x W -> H x W x 1
            arr = arr[:, :, None]
        if arr.ndim != 3:
            raise ValueError("img must be HxW or HxWxC")
        # ensure contiguous
        arr = np.ascontiguousarray(arr)
        # HWC -> CHW
        arr = arr.transpose(2, 0, 1)
        tensor = torch.from_numpy(arr).float().div(255.0)
        # add batch dim
        tensor = tensor.unsqueeze(0)
        return tensor


# Classification response:
# import reorganization;variable renaming;temporary variable;input validation;boundary case handling;guard clause;split condition;standard library helper;type conversion