
def arccos2(vector, value):
    import math
    import numpy as np
    def _norm_angle(a):
        return a % (2 * math.pi)
    def _circular_dist(a, b):
        d = abs(a - b) % (2 * math.pi)
        return min(d, 2 * math.pi - d)
    def arccos2(vector, value):
        v = np.asarray(vector, dtype=float)
        val = float(value)
        val = max(-1.0, min(1.0, val))
        base = math.acos(val)  # candidate angles: base and 2pi-base
        if v.size != 2:
            return base
        vx, vy = float(v[0]), float(v[1])
        vec_angle = _norm_angle(math.atan2(vy, vx))
        c1 = _norm_angle(base)
        c2 = _norm_angle(2 * math.pi - base)
        # choose candidate closest to vector angle
        if _circular_dist(vec_angle, c1) <= _circular_dist(vec_angle, c2):
            return c1
        else:
            return c2


# Classification response:
# helper function extraction; guard clause; tuple unpacking; temporary variable; standard library helper; import reorganization; input validation; type conversion; boundary case handling; mathematical formula