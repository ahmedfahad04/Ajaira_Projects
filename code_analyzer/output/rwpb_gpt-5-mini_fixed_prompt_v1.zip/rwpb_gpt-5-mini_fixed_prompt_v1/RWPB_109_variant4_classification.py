
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        """
        Apply rotation and translation using an explicit Python loop over batch dimension.
        """
        B = geometry.shape[0]
        out_list = []
        for b in range(B):
            # rot[b]: [3,3], geometry[b]: [N,3]
            # compute rot[b] @ geometry[b].T -> [3, N], transpose back to [N,3]
            rotated_b = (rot[b] @ geometry[b].T).T
            translated_b = rotated_b + trans[b].unsqueeze(0)
            out_list.append(translated_b)
        return torch.stack(out_list, dim=0)


# Classification response:
# import reorganization; loop rewrite; for loop; index-based loop; accumulator list; temporary variable; helper function extraction