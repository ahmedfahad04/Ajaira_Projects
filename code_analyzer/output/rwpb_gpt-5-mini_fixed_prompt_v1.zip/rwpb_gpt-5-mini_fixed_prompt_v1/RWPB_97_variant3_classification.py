
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        if not isinstance(image, np.ndarray):
            raise ValueError("Input must be a numpy.ndarray")
        if image.ndim == 3:
            h, w, c = image.shape
            if h <= 0 or w <= 0 or c <= 0:
                raise ValueError("Invalid image shape")
            tmp = image.astype(np.float32) / 255.0
            t = torch.from_numpy(tmp)
            t = t.permute(2, 0, 1).contiguous().to(dtype=torch.float)
            return t
        elif image.ndim == 2:
            h, w = image.shape
            if h <= 0 or w <= 0:
                raise ValueError("Invalid image shape")
            tmp = image.astype(np.float32) / 255.0
            t = torch.from_numpy(tmp)
            t = t.unsqueeze(0).contiguous().to(dtype=torch.float)
            return t
        else:
            raise ValueError("Not a valid image array (expected 2D or 3D)")


# Classification response:
# input validation; type check; boundary case handling; exception handling; behavior change; early return; nested conditional; tuple unpacking; temporary variable; copy before mutation; import reorganization