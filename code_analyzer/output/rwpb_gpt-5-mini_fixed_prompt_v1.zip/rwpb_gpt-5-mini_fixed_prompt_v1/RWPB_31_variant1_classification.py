
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        orig_bs = tensor.shape[0]
        if batch_size == orig_bs:
            return tensor
        if orig_bs == 0:
            raise ValueError("original batch size is zero")
        device = tensor.device
        # Positions in original index-space
        pos = torch.linspace(0.0, float(orig_bs - 1), steps=batch_size, device=device, dtype=torch.float32)
        idx0 = pos.floor().long().clamp(0, orig_bs - 1)
        idx1 = pos.ceil().long().clamp(0, orig_bs - 1)
        frac = (pos - idx0.to(pos.dtype)).to(torch.float32)
        a = tensor[idx0]
        b = tensor[idx1]
        # expand frac to broadcast over remaining dims
        expand_shape = (batch_size,) + (1,) * (tensor.dim() - 1)
        w = frac.view(expand_shape)
        a_f = a.to(torch.float32)
        b_f = b.to(torch.float32)
        out = a_f * (1.0 - w) + b_f * w
        if tensor.dtype.is_floating_point:
            return out.to(tensor.dtype)
        else:
            return out.round().to(tensor.dtype)


# Classification response:
# variable renaming; import reorganization; guard clause; flattened conditional; loop rewrite; temporary variable; vectorized tensor ops; linear interpolation resampling; type check; empty input handling; type conversion; exception handling