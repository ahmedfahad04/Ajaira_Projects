
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        """
        Rotate by shifting azimuth (spherical approach). Detects common [0,1] encoding and converts.
        """
        if not isinstance(normal_map, np.ndarray):
            normal_map = np.array(normal_map, dtype=np.float64)
        nm = normal_map.astype(np.float64)
        if nm.ndim != 3 or nm.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        # Detect if normals are in [0,1] (common texture encoding). If so, convert to [-1,1].
        vmin = nm.min()
        vmax = nm.max()
        encoded = (vmin >= 0.0 and vmax <= 1.0)
        if encoded:
            nm = nm * 2.0 - 1.0
        x = nm[..., 0]
        y = nm[..., 1]
        z = nm[..., 2]
        # Compute azimuth and radius in the XZ plane
        az = np.arctan2(z, x)
        r = np.hypot(x, z)
        theta = np.deg2rad(angle)
        az2 = az + theta
        x2 = r * np.cos(az2)
        z2 = r * np.sin(az2)
        rotated = np.empty_like(nm)
        rotated[..., 0] = x2
        rotated[..., 1] = y
        rotated[..., 2] = z2
        # Renormalize to unit length to ensure valid normals
        norms = np.linalg.norm(rotated, axis=2, keepdims=True)
        eps = 1e-12
        norms = np.maximum(norms, eps)
        rotated = rotated / norms
        # If originally encoded, map back to [0,1]
        if encoded:
            rotated = (rotated + 1.0) * 0.5
        return rotated


# Classification response:
# guard clause;combined condition;helper function extraction;temporary variable;input validation;type conversion;boundary case handling;mathematical formula;numpy vectorized transform;vector renormalization;import reorganization