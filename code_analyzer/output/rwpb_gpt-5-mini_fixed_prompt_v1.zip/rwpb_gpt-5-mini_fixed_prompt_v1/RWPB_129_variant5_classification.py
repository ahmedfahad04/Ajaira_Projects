
def scale_masks(masks, shape, padding=True):
    import torch
    import torch.nn.functional as F
    def scale_masks(masks, shape, padding=True):
        """
        Fast path using nearest neighbor for discrete masks, bilinear otherwise.
        Handles padding by computing integer crop from center.
        """
        if not isinstance(masks, torch.Tensor):
            masks = torch.tensor(masks)
        N, C, H, W = masks.shape
        target_h, target_w = int(shape[0]), int(shape[1])
        mode = 'nearest' if masks.dtype in (torch.bool, torch.uint8, torch.int8, torch.int16, torch.int32, torch.int64) else 'bilinear'
        if not padding:
            out = F.interpolate(masks.view(-1, 1, H, W), size=(target_h, target_w),
                                mode=mode, align_corners=False if mode == 'bilinear' else None)
            return out.view(N, C, target_h, target_w)
        # Compute symmetric padding assuming model input fit original by scaling max side
        model_h, model_w = H, W
        max_orig = max(target_h, target_w)
        gain = float(max(model_h, model_w)) / float(max_orig)
        scaled_h = int(round(target_h * gain))
        scaled_w = int(round(target_w * gain))
        pad_h = model_h - scaled_h
        pad_w = model_w - scaled_w
        top = pad_h // 2
        left = pad_w // 2
        bottom = top + scaled_h
        right = left + scaled_w
        # Clamp
        top = max(0, min(top, model_h))
        left = max(0, min(left, model_w))
        bottom = max(top, min(bottom, model_h))
        right = max(left, min(right, model_w))
        if bottom <= top or right <= left:
            out = F.interpolate(masks.view(-1, 1, H, W), size=(target_h, target_w),
                                mode=mode, align_corners=False if mode == 'bilinear' else None)
            return out.view(N, C, target_h, target_w)
        cropped = masks[:, :, top:bottom, left:right]
        out = F.interpolate(cropped.view(-1, 1, cropped.shape[-2], cropped.shape[-1]),
                            size=(target_h, target_w), mode=mode, align_corners=False if mode == 'bilinear' else None)
        out = out.view(N, C, target_h, target_w)
        return out


# Classification response:
# variable renaming; tuple unpacking; import reorganization; guard clause; conditional expression; membership test; type conversion; boundary case handling; mathematical formula; helper function extraction