
def rotate_x(a, device=None):
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        if device is not None:
            device = torch.device(device)
        c = np.cos(a)
        s = np.sin(a)
        mat = np.array([
            [1.0, 0.0, 0.0, 0.0],
            [0.0,  c,  -s,  0.0],
            [0.0,  s,   c,  0.0],
            [0.0, 0.0, 0.0, 1.0]
        ], dtype=np.float32)
        return torch.tensor(mat, device=device)


# Classification response:
# import reorganization; helper function extraction; temporary variable; literal rewrite; standard library helper; type conversion; behavior change