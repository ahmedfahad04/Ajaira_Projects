
def movmean(arr, n_avg):
    import numpy as np
    from numpy.lib.stride_tricks import as_strided
    def movmean(arr, n_avg):
        arr = np.asarray(arr)
        if n_avg <= 0 or n_avg > arr.size or arr.ndim != 1:
            return np.array([])
        L = arr.size
        out_len = L - n_avg + 1
        stride = arr.strides[0]
        windows = as_strided(arr, shape=(out_len, n_avg), strides=(stride, stride))
        return windows.mean(axis=1)


# Classification response:
# sliding window; stride_tricks usage; import reorganization; input validation; empty input handling; type conversion; temporary variable