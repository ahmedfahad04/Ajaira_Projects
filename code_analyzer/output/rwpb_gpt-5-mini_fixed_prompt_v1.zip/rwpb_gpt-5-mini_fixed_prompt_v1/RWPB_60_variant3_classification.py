
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        orig_x = x
        if upcast:
            x = x.to(torch.float32)
            weight = weight.to(torch.float32) if weight is not None else None
            bias = bias.to(torch.float32) if bias is not None else None
            residual = residual.to(torch.float32) if residual is not None else None
        # flatten leading dims to do per-row computation (brute-force style)
        leading = 1
        for s in x.shape[:-1]:
            leading *= s
        d = x.shape[-1]
        flat = x.contiguous().view(leading, d)
        out_rows = []
        for i in range(leading):
            row = flat[i]
            ms = float((row * row).mean().item())
            inv = 1.0 / (ms + eps) ** 0.5
            norm_row = row * inv
            out_rows.append(norm_row)
        out = torch.stack(out_rows, dim=0).view(*x.shape)
        if weight is not None:
            if weight.ndim == 1:
                w = weight.view(*([1] * (x.ndim - 1)), -1)
            else:
                w = weight
            out = out * w
        if bias is not None:
            if bias.ndim == 1:
                b = bias.view(*([1] * (x.ndim - 1)), -1)
            else:
                b = bias
            out = out + b
        if residual is not None:
            out = out + residual.to(out.dtype)
        if upcast:
            out = out.to(orig_x.dtype)
        if prenorm:
            return out, orig_x
        return out


# Classification response:
# import reorganization;helper function extraction;loop rewrite;for loop;index-based loop;accumulator list;temporary variable;brute force;type conversion;behavior change