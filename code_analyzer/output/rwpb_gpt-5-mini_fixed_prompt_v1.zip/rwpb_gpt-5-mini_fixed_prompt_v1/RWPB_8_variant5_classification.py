
def cvimg2torch(img):
    import numpy as np
    import torch
    def cvimg2torch(img):
        """
        Convert a img to tensor
        input:
            img -> ndarray uint8 HxWxC or HxW
        return
            tensor -> torch.tensor BxCxHxW (float32, not normalized)
        This variant returns float32 image in range [0,255] without dividing by 255.
        """
        arr = np.asarray(img)
        if arr.ndim == 2:
            arr = arr[:, :, None]
        if arr.ndim == 3:
            # HWC -> CHW
            chw = np.ascontiguousarray(np.transpose(arr, (2, 0, 1)))
            t = torch.from_numpy(chw).to(torch.float32)
            return t.unsqueeze(0)
        elif arr.ndim == 4:
            # B x H x W x C -> B x C x H x W
            bc = np.ascontiguousarray(np.transpose(arr, (0, 3, 1, 2)))
            return torch.from_numpy(bc).to(torch.float32)
        else:
            raise ValueError("Unsupported image dimensions")


# Classification response:
# behavior change; input validation; boundary case handling; type conversion; copy before mutation; temporary variable; early return; nested conditional; exception handling; slicing