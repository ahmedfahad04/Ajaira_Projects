
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        if not isinstance(image, np.ndarray):
            raise ValueError("Input is not a NumPy array")
        if image.ndim == 3:
            if image.shape[0] == 0 or image.shape[1] == 0 or image.shape[2] == 0:
                raise ValueError("Invalid image shape")
            arr = image.astype(np.float32, copy=False) / 255.0
            arr = np.transpose(arr, (2, 0, 1))
        elif image.ndim == 2:
            if image.shape[0] == 0 or image.shape[1] == 0:
                raise ValueError("Invalid image shape")
            arr = image.astype(np.float32, copy=False) / 255.0
            arr = np.expand_dims(arr, 0)
        else:
            raise ValueError("Input is not a valid 2D or 3D image array")
        arr = np.ascontiguousarray(arr)
        return torch.from_numpy(arr).to(dtype=torch.float)


# Classification response:
# import reorganization; helper function extraction; guard clause; input validation; type check; boundary case handling; nested conditional; temporary variable; type conversion; behavior change