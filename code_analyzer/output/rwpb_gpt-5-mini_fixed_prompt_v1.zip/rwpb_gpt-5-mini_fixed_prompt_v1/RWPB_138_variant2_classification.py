
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        """
        Rotate using quaternion rotation about Y axis (vectorized).
        """
        if not isinstance(normal_map, np.ndarray):
            normal_map = np.array(normal_map, dtype=np.float64)
        nm = normal_map.astype(np.float64)
        if nm.ndim != 3 or nm.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        theta = np.deg2rad(angle)
        half = theta / 2.0
        w = np.cos(half)
        sin_half = np.sin(half)
        # quaternion for axis (0,1,0)
        qx = 0.0
        qy = sin_half
        qz = 0.0
        q0 = w
        # apply quaternion rotation: v' = v + 2*q_vec x (q_vec x v + q0*v)
        v = nm
        qvec = np.array([qx, qy, qz], dtype=nm.dtype)
        # compute q_vec x v
        # broadcasting: (H,W,3)
        qv = np.cross(qvec, v)
        inner = qv + q0 * v
        rotated = v + 2.0 * np.cross(qvec, inner)
        # normalize to mitigate numerical issues
        norms = np.linalg.norm(rotated, axis=2, keepdims=True)
        norms[norms == 0] = 1.0
        rotated = rotated / norms
        return rotated


# Classification response:
# mathematical formula;helper function extraction;import reorganization;input validation;type conversion;boundary case handling;in-place mutation;temporary variable