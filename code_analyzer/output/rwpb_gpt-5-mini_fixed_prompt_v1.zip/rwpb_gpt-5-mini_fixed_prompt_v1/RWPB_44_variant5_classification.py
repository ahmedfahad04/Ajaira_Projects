
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        # Use scatter to place elements into preallocated output
        if tensor1.dim() == 0 and tensor2.dim() == 0:
            t1 = tensor1.unsqueeze(0)
            t2 = tensor2.unsqueeze(0)
        else:
            t1 = tensor1
            t2 = tensor2
        if t1.shape[1:] != t2.shape[1:]:
            raise ValueError("Shapes must match except for the first dimension")
        n = t1.size(0)
        out_shape = (2 * n,) + t1.shape[1:]
        device = t1.device
        dtype = t1.dtype
        out1 = torch.empty(out_shape, device=device, dtype=dtype)
        out2 = torch.empty_like(out1)
        # indices for placement
        idx1 = torch.arange(0, 2 * n, 2, device=device)
        idx2 = torch.arange(1, 2 * n, 2, device=device)
        out1.index_copy_(0, idx1, t1)
        out1.index_copy_(0, idx2, t2)
        out2.index_copy_(0, idx1, t2)
        out2.index_copy_(0, idx2, t1)
        return out1, out2


# Classification response:
# import reorganization; helper function extraction; guard clause; input validation; empty input handling; preallocated output; in-place mutation; temporary variable; standard library helper; scatter-based placement