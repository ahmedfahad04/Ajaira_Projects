
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        # Functional-style implementation
        x, y, x1, y1 = box
        if expand < 0:
            raise ValueError("expand must be non-negative")
        # canonicalize
        left, right = (x, x1) if x <= x1 else (x1, x)
        top, bottom = (y, y1) if y <= y1 else (y1, y)
        w = right - left
        h = bottom - top
        cx = (left + right) / 2.0
        cy = (top + bottom) / 2.0
        # compute expanded half-size and produce square crop
        s = (max(w, h) * expand) / 2.0
        new_box = [cx - s, cy - s, cx + s, cy + s]
        return new_box, s


# Classification response:
# variable renaming; helper function extraction; guard clause; exception handling; conditional expression; type conversion; input validation; boundary case handling