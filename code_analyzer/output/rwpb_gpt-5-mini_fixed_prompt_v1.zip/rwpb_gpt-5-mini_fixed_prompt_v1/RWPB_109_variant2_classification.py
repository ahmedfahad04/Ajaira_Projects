
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        """
        Apply rotation and translation using einsum.
        """
        # Use einsum to compute rotated points: y[b,n,i] = sum_j rot[b,i,j] * geometry[b,n,j]
        rotated = torch.einsum('bij,bnj->bni', rot, geometry)
        return rotated + trans[:, None, :]


# Classification response:
# standard library helper; import reorganization; helper function extraction; temporary variable; slicing