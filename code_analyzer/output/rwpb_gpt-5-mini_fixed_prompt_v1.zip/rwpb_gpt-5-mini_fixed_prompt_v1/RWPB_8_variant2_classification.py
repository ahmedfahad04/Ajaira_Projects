
def cvimg2torch(img):
    import numpy as np
    import torch
    def cvimg2torch(img):
        """
        Convert a img to tensor
        input:
            img -> ndarray uint8 HxWxC or HxW
        return
            tensor -> torch.tensor BxCxHxW (float32 normalized 0..1)
        This variant uses torch.tensor constructor (copies) and handles batched input.
        """
        arr = np.asarray(img)
        # If batch of images given: B x H x W x C
        if arr.ndim == 4:
            # move to B x C x H x W
            out = np.moveaxis(arr, -1, 1)
            t = torch.tensor(out, dtype=torch.float32).div(255.0)
            return t
        if arr.ndim == 2:
            arr = arr[:, :, None]
        if arr.ndim != 3:
            raise ValueError("img must be HxW, HxWxC, or batch BxHxWxC")
        # HWC -> CHW
        chw = np.moveaxis(arr, -1, 0)
        t = torch.tensor(chw, dtype=torch.float32).div(255.0)
        return t.unsqueeze(0)


# Classification response:
# import reorganization; temporary variable; copy before mutation; early return; input validation; boundary case handling; standard library helper