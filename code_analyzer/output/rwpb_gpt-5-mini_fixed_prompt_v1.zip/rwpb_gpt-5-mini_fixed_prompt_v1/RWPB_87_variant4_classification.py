
def rotate_x(a, device=None):
    import torch
    import numpy as np
    def rotate_x(a, device=None):
        if device is not None:
            device = torch.device(device)
        ca = np.cos(a).astype(np.float32)
        sa = np.sin(a).astype(np.float32)
        rot2 = torch.tensor([[ca, -sa],[sa, ca]], dtype=torch.float32, device=device)
        mat = torch.eye(4, dtype=torch.float32, device=device)
        mat[1:3,1:3] = rot2
        return mat


# Classification response:
# import reorganization; helper function extraction; guard clause; type conversion; temporary variable; slicing; in-place mutation; standard library helper