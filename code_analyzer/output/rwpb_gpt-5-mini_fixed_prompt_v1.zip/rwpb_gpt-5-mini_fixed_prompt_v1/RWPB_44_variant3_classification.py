
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        # Brute-force assemble using list of slices then cat
        if tensor1.dim() == 0 and tensor2.dim() == 0:
            t1 = tensor1.unsqueeze(0)
            t2 = tensor2.unsqueeze(0)
        else:
            t1 = tensor1
            t2 = tensor2
        if t1.shape[1:] != t2.shape[1:]:
            raise ValueError("Shapes must match except for the first dimension")
        n = t1.size(0)
        pieces1 = []
        pieces2 = []
        for i in range(n):
            pieces1.append(t1[i:i+1])
            pieces1.append(t2[i:i+1])
            pieces2.append(t2[i:i+1])
            pieces2.append(t1[i:i+1])
        interleaved1 = torch.cat(pieces1, dim=0)
        interleaved2 = torch.cat(pieces2, dim=0)
        return interleaved1, interleaved2


# Classification response:
# loop rewrite;for loop;accumulator list;temporary variable;brute force;input validation;boundary case handling;guard clause;import reorganization;helper function extraction