
def psnr_to_mse(psnr):
    def psnr_to_mse(psnr):
        try:
            # try direct numeric / numpy-friendly power
            return 10.0 ** (-psnr / 10.0)
        except Exception:
            # fallback for Python iterables (lists, tuples, etc.)
            try:
                return [10.0 ** (-float(x) / 10.0) for x in psnr]
            except Exception:
                # last resort: coerce to float
                return float(10.0 ** (-float(psnr) / 10.0))


# Classification response:
# helper function extraction;try-except wrapper;list comprehension;builtin function;mathematical formula;type conversion;error suppression