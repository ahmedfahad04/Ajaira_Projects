
def rot_trans_geo(geometry, rot, trans):
    import torch
    def rot_trans_geo(geometry, rot, trans):
        """
        Apply rotation using broadcasting matmul by adding a points-dimension to rotation and using matmul.
        """
        # rot: [B, 3, 3] -> [B, 1, 3, 3]
        rot_exp = rot.unsqueeze(1)
        # geometry: [B, N, 3] -> [B, N, 3, 1]
        geo_exp = geometry.unsqueeze(-1)
        # matmul with broadcasting: result [B, N, 3, 1] -> squeeze to [B, N, 3]
        rotated = torch.matmul(rot_exp, geo_exp).squeeze(-1)
        return rotated + trans.unsqueeze(1)


# Classification response:
# import reorganization; nested function; helper function extraction; temporary variable; broadcasting matmul