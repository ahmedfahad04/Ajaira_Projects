
def psnr_to_mse(psnr):
    from decimal import Decimal, getcontext
    def psnr_to_mse(psnr):
        getcontext().prec = 50
        D10 = Decimal(10)
        def dec(val):
            return float(D10 ** (Decimal(-val) / Decimal(10)))
        # scalar
        if isinstance(psnr, (int, float)):
            return dec(psnr)
        # iterable
        try:
            return [dec(float(x)) for x in psnr]
        except Exception:
            return dec(float(psnr))


# Classification response:
# helper function extraction;standard library helper;list comprehension;try-except wrapper;guard clause;type check;type conversion;mathematical formula;behavior change;import reorganization;temporary variable