
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        orig_x = x
        if upcast:
            compute_dtype = torch.float32
            x = x.to(compute_dtype)
            weight = weight.to(compute_dtype) if weight is not None else None
            bias = bias.to(compute_dtype) if bias is not None else None
            residual = residual.to(compute_dtype) if residual is not None else None
        # compute mean of squares using torch.mean and square
        ms = torch.mean(torch.square(x), dim=-1, keepdim=True)
        # use torch.sqrt then reciprocal for stability
        denom = torch.sqrt(ms + eps)
        normalized = x / denom
        if weight is not None:
            if weight.ndim == 1:
                w = weight.view(*([1] * (x.ndim - 1)), -1)
            else:
                w = weight
            out = normalized * w
        else:
            out = normalized
        if bias is not None:
            if bias.ndim == 1:
                b = bias.view(*([1] * (x.ndim - 1)), -1)
            else:
                b = bias
            out = out + b
        if residual is not None:
            out = out + residual.to(out.dtype)
        if upcast:
            out = out.to(orig_x.dtype)
        if prenorm:
            return out, orig_x
        return out


# Classification response:
# import reorganization; nested function; variable renaming; guard clause; split condition; temporary variable; tuple unpacking; branch reordering; type conversion; behavior change