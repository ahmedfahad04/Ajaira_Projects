
def extract_code_from_funct(funct: Callable) -> List[str]:
    import inspect
    import ast
    import textwrap
    from typing import Callable, List
    def extract_code_from_funct(funct: Callable) -> List[str]:
        try:
            src = inspect.getsource(funct)
        except (OSError, TypeError):
            return []
        # Dedent to normalize indentation for AST source segments
        dedented = textwrap.dedent(src)
        try:
            module = ast.parse(dedented)
        except SyntaxError:
            # Fall back to simple line-based extraction
            lines = dedented.splitlines()
            # find def line
            idx = 0
            for i, ln in enumerate(lines):
                if ln.lstrip().startswith("def ") or ln.lstrip().startswith("async def "):
                    idx = i
                    break
            body = lines[idx+1:]
            # trim common indent
            min_indent = None
            for ln in body:
                if ln.strip():
                    leading = len(ln) - len(ln.lstrip())
                    if min_indent is None or leading < min_indent:
                        min_indent = leading
            if min_indent is None:
                return []
            out = [ln[min_indent:] for ln in body]
            # remove trailing return line if present
            for j in range(len(out)-1, -1, -1):
                if out[j].strip() == "" or out[j].lstrip().startswith("#"):
                    continue
                if out[j].lstrip().startswith("return"):
                    out = out[:j]
                break
            # strip leading/trailing blank lines
            while out and out[0].strip()=="":
                out.pop(0)
            while out and out[-1].strip()=="":
                out.pop()
            return out
        # find the FunctionDef/AsyncFunctionDef with matching name
        target = None
        for node in ast.walk(module):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == funct.__name__:
                target = node
                break
        if target is None:
            # fallback: first function in module
            for node in module.body:
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    target = node
                    break
        if target is None:
            return []
        lines_out = []
        # iterate over body nodes, skip final Return if present
        body_nodes = list(target.body)
        if body_nodes and isinstance(body_nodes[-1], ast.Return):
            body_nodes = body_nodes[:-1]
        for node in body_nodes:
            seg = ast.get_source_segment(dedented, node)
            if seg is None:
                # try to reconstruct from lineno/end_lineno
                start = getattr(node, "lineno", None)
                end = getattr(node, "end_lineno", None)
                if start is not None and end is not None:
                    seg_lines = dedented.splitlines()[start-1:end]
                    seg = "\n".join(seg_lines)
                else:
                    continue
            # dedent each segment and collect non-empty lines
            for ln in textwrap.dedent(seg).splitlines():
                lines_out.append(ln)
        # strip leading/trailing blank lines
        while lines_out and lines_out[0].strip()=="":
            lines_out.pop(0)
        while lines_out and lines_out[-1].strip()=="":
            lines_out.pop()
        return lines_out


# Classification response:
# try-except wrapper; early return; helper function extraction; tree traversal; standard library helper; accumulator list; temporary variable; in-place mutation; loop rewrite; empty input handling