
def get_crop_box(box, expand):
    def get_crop_box(box, expand):
        x, y, x1, y1 = box
        if expand < 0:
            raise ValueError("expand must be non-negative")
        # Normalize coordinates in case they're reversed
        if x1 < x:
            x, x1 = x1, x
        if y1 < y:
            y, y1 = y1, y
        w = x1 - x
        h = y1 - y
        cx = (x + x1) / 2.0
        cy = (y + y1) / 2.0
        # Make square by using the larger side, then apply expand factor
        s = max(w, h) * expand / 2.0
        new_x = cx - s
        new_y = cy - s
        new_x1 = cx + s
        new_y1 = cy + s
        return [new_x, new_y, new_x1, new_y1], s


# Classification response:
# variable renaming;guard clause;nested conditional;exception handling;tuple unpacking;temporary variable;type conversion;mathematical formula;input validation;boundary case handling