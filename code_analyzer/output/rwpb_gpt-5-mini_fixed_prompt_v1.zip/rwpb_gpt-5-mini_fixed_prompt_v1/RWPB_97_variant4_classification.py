
def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
    import numpy as np
    import torch
    def numpy_image_to_torch(image: np.ndarray) -> torch.Tensor:
        arr = np.array(image, copy=False)
        if arr.ndim == 2:
            H, W = arr.shape
            if H == 0 or W == 0:
                raise ValueError("Invalid image")
            arr2 = np.empty((1, H, W), dtype=np.float32)
            arr2[0] = arr.astype(np.float32) / 255.0
            return torch.from_numpy(arr2)
        if arr.ndim == 3:
            H, W, C = arr.shape
            if H == 0 or W == 0 or C == 0:
                raise ValueError("Invalid image")
            arr2 = np.empty((C, H, W), dtype=np.float32)
            for i in range(C):
                arr2[i] = arr[:, :, i].astype(np.float32) / 255.0
            return torch.from_numpy(arr2)
        raise ValueError("Input is not a valid image (must be 2D or 3D numpy array)")


# Classification response:
# import reorganization;branch reordering;guard clause;early return;nested conditional;loop rewrite;for loop;tuple unpacking;temporary variable;in-place mutation;type conversion;input validation;boundary case handling;behavior change