
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        h0, w0 = original_size
        t = tensor
        if t.dim() == 4:
            n, c, H, W = t.shape
            outs = []
            for i in range(n):
                img = t[i]
                while img.shape[1] > h0:
                    top = 0
                    bottom = img.shape[1]
                    img = img[:, 1:bottom-1 if bottom-1>top else bottom]
                while img.shape[2] > w0:
                    left = 0
                    right = img.shape[2]
                    img = img[:, :, 1:right-1 if right-1>left else right]
                if img.shape[1] < h0 or img.shape[2] < w0:
                    pad_h = h0 - img.shape[1]
                    pad_w = w0 - img.shape[2]
                    pad_top = pad_h // 2
                    pad_bottom = pad_h - pad_top
                    pad_left = pad_w // 2
                    pad_right = pad_w - pad_left
                    img = torch.nn.functional.pad(img, (pad_left, pad_right, pad_top, pad_bottom))
                outs.append(img)
            return torch.stack(outs, dim=0)
        elif t.dim() == 3:
            img = t
            while img.shape[1] > h0:
                top = 0
                bottom = img.shape[1]
                img = img[:, 1:bottom-1 if bottom-1>top else bottom]
            while img.shape[2] > w0:
                left = 0
                right = img.shape[2]
                img = img[:, :, 1:right-1 if right-1>left else right]
            if img.shape[1] < h0 or img.shape[2] < w0:
                pad_h = h0 - img.shape[1]
                pad_w = w0 - img.shape[2]
                pad_top = pad_h // 2
                pad_bottom = pad_h - pad_top
                pad_left = pad_w // 2
                pad_right = pad_w - pad_left
                img = torch.nn.functional.pad(img, (pad_left, pad_right, pad_top, pad_bottom))
            return img
        else:
            raise ValueError("Unsupported tensor shape")


# Classification response:
# variable renaming; import reorganization; helper function extraction; for loop; while loop; accumulator list; tuple unpacking; temporary variable; early return; input validation; brute force; boundary case handling