
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        if not isinstance(sample, dict):
            raise ValueError("sample must be a dict")
        target_h, target_w = size
        # find the maximum required scale among all present images so all reach min
        def hw(x):
            if x is None:
                return None
            if isinstance(x, np.ndarray):
                return x.shape[0], x.shape[1]
            return None
        hw_list = [hw(sample.get(k)) for k in ("image", "disparity", "mask")]
        hw_list = [h for h in hw_list if h is not None]
        if not hw_list:
            return (target_h, target_w)
        # compute per-array scale, take max to satisfy all
        scales = []
        for h, w in hw_list:
            sh = float(target_h) / h if h < target_h else 1.0
            sw = float(target_w) / w if w < target_w else 1.0
            scales.append(max(sh, sw, 1.0))
        overall_scale = max(scales)
        if overall_scale == 1.0:
            return hw_list[0]
        new_h = int(math.ceil(hw_list[0][0] * overall_scale))
        new_w = int(math.ceil(hw_list[0][1] * overall_scale))
        # Resize each present entry with appropriate interpolation and post-processing
        if sample.get("image") is not None:
            img = sample["image"]
            interp = image_interpolation_method if overall_scale <= 1.0 else cv2.INTER_CUBIC
            sample["image"] = cv2.resize(img, (new_w, new_h), interpolation=interp)
        if sample.get("disparity") is not None:
            d = sample["disparity"]
            # if integer (discrete labels), use nearest and do NOT scale values
            if np.issubdtype(d.dtype, np.integer):
                d_res = cv2.resize(d, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
                sample["disparity"] = d_res.astype(d.dtype)
            else:
                d_res = cv2.resize(d, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
                # scale disparity values to match resized image metric
                d_res = d_res.astype(np.float32) * overall_scale
                sample["disparity"] = d_res.astype(d.dtype)
        if sample.get("mask") is not None:
            m = sample["mask"]
            m_res = cv2.resize(m, (new_w, new_h), interpolation=cv2.INTER_NEAREST)
            # ensure mask remains binary if originally was boolean-like
            if m.dtype == np.bool_:
                sample["mask"] = m_res > 0.5
            else:
                sample["mask"] = m_res.astype(m.dtype)
        return (new_h, new_w)


# Classification response:
# variable renaming; import reorganization; helper function extraction; list comprehension; for loop; early return; input validation; empty input handling; type check; behavior change