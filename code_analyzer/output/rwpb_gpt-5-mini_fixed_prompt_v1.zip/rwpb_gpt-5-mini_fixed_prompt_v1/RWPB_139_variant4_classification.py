
def rotate_normalmap_by_angle_torch(normal_map, angle):
    import torch
    import numpy as np
    def rotate_normalmap_by_angle_torch(normal_map, angle):
        if not isinstance(normal_map, torch.Tensor):
            raise TypeError("normal_map must be a torch.Tensor")
        device = normal_map.device
        dtype = normal_map.dtype
        nm = normal_map.to(torch.get_default_dtype()).to(device)
        if nm.dim() == 3 and nm.shape[2] == 3:
            theta = torch.tensor(angle * np.pi / 180.0, device=device, dtype=nm.dtype)
            c = torch.cos(theta)
            s = torch.sin(theta)
            R = torch.stack([
                torch.stack([c, torch.tensor(0., device=device, dtype=nm.dtype), s]),
                torch.stack([torch.tensor(0., device=device, dtype=nm.dtype), torch.tensor(1., device=device, dtype=nm.dtype), torch.tensor(0., device=device, dtype=nm.dtype)]),
                torch.stack([-s, torch.tensor(0., device=device, dtype=nm.dtype), c])
            ], dim=0)
            out = torch.einsum('ij,hwj->hwi', R, nm)
            eps = torch.finfo(out.dtype).eps
            norm = torch.sqrt((out ** 2).sum(dim=-1, keepdim=True)).clamp_min(eps)
            out = out / norm
            return out.to(dtype)
        elif nm.dim() == 3 and nm.shape[0] == 3:
            nm = nm.permute(1, 2, 0)
            return rotate_normalmap_by_angle_torch(nm, angle).permute(2, 0, 1).to(dtype)
        else:
            raise ValueError("normal_map must have shape (H,W,3) or (3,H,W)")


# Classification response:
# input validation; type check; type conversion; import reorganization; temporary variable; builtin function; recursion; boundary case handling; behavior change