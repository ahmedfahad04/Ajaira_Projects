
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        arr = np.asarray(arr, dtype=float)
        if window_size <= 0:
            raise ValueError("window_size must be a positive integer")
        if arr.size == 0:
            return [np.array([]), np.array([])]
        kernel = np.ones(window_size, dtype=float) / float(window_size)
        smoothed = np.convolve(arr, kernel, mode='same')
        residuals = arr - smoothed
        return [smoothed, residuals]


# Classification response:
# import reorganization; helper function extraction; type conversion; input validation; empty input handling; early return; temporary variable; sliding window; behavior change