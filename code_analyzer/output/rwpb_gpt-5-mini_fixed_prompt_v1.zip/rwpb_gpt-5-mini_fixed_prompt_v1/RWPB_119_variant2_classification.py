
def rotate_about_x_axis(vector, theta):
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        v = np.asarray(vector, dtype=float)
        if v.size != 3:
            raise ValueError("Input must be a 3-element vector.")
        # Rotation matrix for rotation about x-axis
        c = np.cos(theta)
        s = np.sin(theta)
        R = np.array([[1.0, 0.0, 0.0],
                      [0.0,   c,  -s],
                      [0.0,   s,   c]], dtype=float)
        return R.dot(v)


# Classification response:
# import reorganization;guard clause;input validation;type conversion;temporary variable;literal rewrite;helper function extraction