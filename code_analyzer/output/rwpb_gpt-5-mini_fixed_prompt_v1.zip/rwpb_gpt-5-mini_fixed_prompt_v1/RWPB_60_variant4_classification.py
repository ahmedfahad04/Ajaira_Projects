
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        orig_x = x
        dtype_orig = x.dtype
        if upcast:
            x = x.to(torch.float32)
            weight = weight.to(torch.float32) if weight is not None else None
            bias = bias.to(torch.float32) if bias is not None else None
            residual = residual.to(torch.float32) if residual is not None else None
        # use einsum to compute mean of squares
        d = x.shape[-1]
        sumsq = torch.einsum('...d,...d->...', x, x).unsqueeze(-1)
        ms = sumsq / float(d)
        inv = torch.rsqrt(ms + eps)
        normalized = x * inv
        if weight is not None:
            if weight.ndim == 1:
                weight = weight.view(*([1] * (normalized.ndim - 1)), -1)
            out = normalized * weight
        else:
            out = normalized
        if bias is not None:
            if bias.ndim == 1:
                bias = bias.view(*([1] * (normalized.ndim - 1)), -1)
            out = out + bias
        if residual is not None:
            out = out + residual.to(out.dtype)
        if upcast:
            out = out.to(dtype_orig)
        if prenorm:
            return out, orig_x
        return out


# Classification response:
# variable renaming; import reorganization; helper function extraction; standard library helper; temporary variable; input validation; branch reordering; type conversion; behavior change