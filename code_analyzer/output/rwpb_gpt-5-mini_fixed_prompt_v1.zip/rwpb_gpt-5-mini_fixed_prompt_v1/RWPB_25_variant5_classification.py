
def hole_fill(img):
    import numpy as np
    import cv2
    def hole_fill(img):
        """
        Contour-based hole filling: find contours and use hierarchy to fill inner contours (holes).
        """
        if img is None:
            return img
        gray = img.copy()
        if gray.ndim == 3:
            gray = cv2.cvtColor(gray, cv2.COLOR_BGR2GRAY)
        # Binary image
        _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
        bwu = bw.copy()
        # Find contours with hierarchy
        contours, hierarchy = cv2.findContours(bwu, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
        if not contours or hierarchy is None:
            if img.ndim == 3:
                return cv2.cvtColor(bw, cv2.COLOR_GRAY2BGR)
            return bw
        hierarchy = hierarchy[0]
        # Create mask to draw fills
        mask = bw.copy()
        for idx, hier in enumerate(hierarchy):
            # hier = [next, prev, first_child, parent]
            parent = hier[3]
            # If contour has a parent, it's a hole (inner contour)
            if parent != -1:
                cv2.drawContours(mask, contours, idx, 255, thickness=cv2.FILLED)
        # Also ensure outer contours remain
        filled = cv2.bitwise_or(bw, mask)
        if img.ndim == 3:
            return cv2.cvtColor(filled, cv2.COLOR_GRAY2BGR)
        return filled


# Classification response:
# import reorganization;guard clause;combined condition;enumerate loop;in-place mutation;temporary variable;contour-based filling;input validation;type conversion;boundary case handling