
def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
    import math
    import cv2
    import numpy as np
    def apply_min_size(sample, size, image_interpolation_method=cv2.INTER_AREA):
        if sample is None or not isinstance(sample, dict):
            return (size[0], size[1])
        target_h, target_w = size
        # determine reference size as image if available else disparity else mask
        ref = None
        for k in ("image", "disparity", "mask"):
            if k in sample and sample[k] is not None:
                arr = sample[k]
                if isinstance(arr, np.ndarray) and arr.ndim >= 2:
                    ref = arr
                    break
        if ref is None:
            return (target_h, target_w)
        h, w = ref.shape[0], ref.shape[1]
        # iterative doubling approach for large upscales for quality
        scale_h = target_h / h if h < target_h else 1.0
        scale_w = target_w / w if w < target_w else 1.0
        final_scale = max(scale_h, scale_w, 1.0)
        if final_scale == 1.0:
            return (h, w)
        # perform progressive scaling by factors of 2 until close, then final resize
        current_img = None
        new_h = h
        new_w = w
        scales = []
        s = final_scale
        while s > 2.0:
            scales.append(2.0)
            s /= 2.0
        if s > 1.0:
            scales.append(s)
        # helper resize function
        def _resize_once(arr, factor, interp):
            if factor == 1.0:
                return arr
            nh = int(math.ceil(arr.shape[0] * factor))
            nw = int(math.ceil(arr.shape[1] * factor))
            return cv2.resize(arr, (nw, nh), interpolation=interp)
        # apply progressive scaling for each component
        # image with chosen interpolation but cubic for upscaling steps
        if "image" in sample and sample["image"] is not None:
            arr = sample["image"]
            for factor in scales:
                interp = cv2.INTER_CUBIC if factor > 1.0 else image_interpolation_method
                arr = _resize_once(arr, factor, interp)
            sample["image"] = arr
            new_h, new_w = arr.shape[0], arr.shape[1]
        # disparity: scale values together with resizing (use linear)
        if "disparity" in sample and sample["disparity"] is not None:
            arr = sample["disparity"].astype(np.float32)
            for factor in scales:
                arr = _resize_once(arr, factor, cv2.INTER_LINEAR)
                # after each resize, scale disparity values by that factor
                arr = arr * factor
            sample["disparity"] = arr.astype(sample["disparity"].dtype)
        # mask: nearest interpolation in progressive steps
        if "mask" in sample and sample["mask"] is not None:
            arr = sample["mask"]
            for factor in scales:
                arr = _resize_once(arr, factor, cv2.INTER_NEAREST)
            # preserve dtype
            sample["mask"] = arr.astype(sample["mask"].dtype)
        return (new_h, new_w)


# Classification response:
# variable renaming; import reorganization; helper function extraction; loop rewrite; while loop; for loop; accumulator list; temporary variable; guard clause; early return; type check; membership test; in-place mutation; progressive scaling