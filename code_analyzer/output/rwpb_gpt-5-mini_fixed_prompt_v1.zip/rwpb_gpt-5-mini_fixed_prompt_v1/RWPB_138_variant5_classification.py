
def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
    import numpy as np
    def rotate_normalmap_by_angle(normal_map: np.ndarray, angle: float):
        """
        Reshape + matrix multiplication approach. Keeps original magnitude of vectors if desired,
        then optionally re-normalizes to unit normals.
        """
        if not isinstance(normal_map, np.ndarray):
            normal_map = np.array(normal_map, dtype=np.float64)
        nm = normal_map.astype(np.float64)
        if nm.ndim != 3 or nm.shape[2] != 3:
            raise ValueError("normal_map must have shape (H, W, 3)")
        h, w, _ = nm.shape
        flat = nm.reshape(-1, 3)
        theta = np.deg2rad(angle)
        c = np.cos(theta)
        s = np.sin(theta)
        R = np.array([[c, 0.0, s],
                      [0.0, 1.0, 0.0],
                      [-s, 0.0, c]], dtype=flat.dtype)
        # Use dot: rotated_flat = flat @ R.T
        rotated_flat = flat.dot(R.T)
        # Re-normalize to unit vectors
        norms = np.linalg.norm(rotated_flat, axis=1, keepdims=True)
        eps = 1e-12
        norms = np.maximum(norms, eps)
        rotated_flat = rotated_flat / norms
        rotated = rotated_flat.reshape(h, w, 3)
        return rotated


# Classification response:
# import reorganization;input validation;type conversion;guard clause;exception handling;behavior change;boundary case handling;helper function extraction;temporary variable;tuple unpacking;literal rewrite