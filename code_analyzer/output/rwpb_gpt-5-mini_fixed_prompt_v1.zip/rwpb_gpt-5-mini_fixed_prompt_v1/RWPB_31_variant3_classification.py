
def resize_to_batch_size(tensor, batch_size):
    import torch
    import math
    def resize_to_batch_size(tensor, batch_size):
        if not isinstance(tensor, torch.Tensor):
            raise TypeError("tensor must be a torch.Tensor")
        N = tensor.shape[0]
        if batch_size == N:
            return tensor
        if N == 0:
            raise ValueError("original batch size is zero")
        device = tensor.device
        out_list = []
        for i in range(batch_size):
            pos = i * (N - 1) / max(batch_size - 1, 1)
            i0 = int(math.floor(pos))
            i1 = int(math.ceil(pos))
            w = pos - i0
            a = tensor[i0].to(torch.float32)
            b = tensor[i1].to(torch.float32)
            sample = a * (1.0 - w) + b * w
            if not tensor.dtype.is_floating_point:
                sample = sample.round()
                sample = sample.to(tensor.dtype)
            out_list.append(sample)
        return torch.stack(out_list, dim=0)


# Classification response:
# accumulator list; nested function; import reorganization; input validation; empty input handling; type conversion; variable renaming; flattened conditional; guard clause; temporary variable; linear interpolation resampling