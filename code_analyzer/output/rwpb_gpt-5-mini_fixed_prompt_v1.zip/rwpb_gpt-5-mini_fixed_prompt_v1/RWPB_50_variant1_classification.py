
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        if tensor is None:
            return tensor
        h0, w0 = original_size
        t = tensor
        if t.dim() == 4:
            n, c, H, W = t.shape
            top = max((H - h0) // 2, 0)
            left = max((W - w0) // 2, 0)
            bottom = top + min(h0, H)
            right = left + min(w0, W)
            cropped = t[:, :, top:bottom, left:right]
            if cropped.shape[2] != h0 or cropped.shape[3] != w0:
                pad_top = max(0, (h0 - cropped.shape[2]) // 2)
                pad_bottom = h0 - cropped.shape[2] - pad_top
                pad_left = max(0, (w0 - cropped.shape[3]) // 2)
                pad_right = w0 - cropped.shape[3] - pad_left
                padded = torch.nn.functional.pad(cropped, (pad_left, pad_right, pad_top, pad_bottom))
                return padded
            return cropped
        elif t.dim() == 3:
            c, H, W = t.shape
            top = max((H - h0) // 2, 0)
            left = max((W - w0) // 2, 0)
            bottom = top + min(h0, H)
            right = left + min(w0, W)
            cropped = t[:, top:bottom, left:right]
            if cropped.shape[1] != h0 or cropped.shape[2] != w0:
                pad_top = max(0, (h0 - cropped.shape[1]) // 2)
                pad_bottom = h0 - cropped.shape[1] - pad_top
                pad_left = max(0, (w0 - cropped.shape[2]) // 2)
                pad_right = w0 - cropped.shape[2] - pad_left
                padded = torch.nn.functional.pad(cropped, (pad_left, pad_right, pad_top, pad_bottom))
                return padded
            return cropped
        else:
            raise ValueError("Unsupported tensor shape. Expected CHW or NCHW.")


# Classification response:
# variable renaming; import reorganization; helper function extraction; early return; split condition; exception handling; input validation; boundary case handling; behavior change; temporary variable; tuple unpacking; slicing; type check