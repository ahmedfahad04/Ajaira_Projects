
def validate_user_id(user_id):
    def validate_user_id(user_id):
        if not isinstance(user_id, str) or user_id == '':
            return False
        it = iter(user_id)
        first = next(it)
        if not first.isalpha():
            return False
        return all((c.isalnum() or c == '_') for c in it)


# Classification response:
# guard clause;split condition;helper function extraction;temporary variable;generator expression;any/all usage;type check;empty input handling;regex usage