
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    from collections.abc import Mapping
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        result = {}
        def _flatten(obj, base):
            if not isinstance(obj, Mapping):
                if base:
                    result[base] = obj
                return
            if not obj and base:
                result[base] = obj
                return
            for k, v in obj.items():
                key = base + sep + str(k) if base else str(k)
                _flatten(v, key)
        _flatten(d, parent_key)
        return result


# Classification response:
# helper function extraction; accumulator dict; in-place mutation; recursion with base case; early return; type check; empty input handling; behavior change; import reorganization; string formatting change; standard library helper