
def cosine_distance(a, b):
    import numpy as np
    def cosine_distance(a, b):
        a = np.asarray(a, dtype=float).flatten()
        b = np.asarray(b, dtype=float)
        if b.ndim == 0:
            b = b.reshape(-1)
        if b.ndim == 1:
            if a.shape[0] != b.shape[0]:
                raise KeyError("Length mismatch between a and b")
            dot = 0.0
            na2 = 0.0
            nb2 = 0.0
            for i in range(a.shape[0]):
                dot += a[i] * b[i]
                na2 += a[i] * a[i]
                nb2 += b[i] * b[i]
            if na2 == 0 or nb2 == 0:
                return 1.0
            return 1.0 - (dot / ((na2**0.5) * (nb2**0.5)))
        elif b.ndim == 2:
            if a.shape[0] != b.shape[1]:
                raise KeyError("Length mismatch between a and b")
            results = []
            for row in b:
                dot = 0.0
                na2 = 0.0
                nb2 = 0.0
                for i in range(a.shape[0]):
                    dot += a[i] * row[i]
                    na2 += a[i] * a[i]
                    nb2 += row[i] * row[i]
                if na2 == 0 or nb2 == 0:
                    results.append(1.0)
                else:
                    results.append(1.0 - (dot / ((na2**0.5) * (nb2**0.5))))
            return np.array(results)
        else:
            raise KeyError("b must be vector or 2D matrix")


# Classification response:
# import reorganization; type conversion; input validation; boundary case handling; helper function extraction; nested conditional; index-based loop; accumulator list; temporary variable; early return; brute force; behavior change