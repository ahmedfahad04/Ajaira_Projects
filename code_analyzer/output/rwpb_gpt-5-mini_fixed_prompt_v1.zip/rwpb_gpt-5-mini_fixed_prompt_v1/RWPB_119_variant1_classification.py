
def rotate_about_x_axis(vector, theta):
    import math
    import numpy as np
    def rotate_about_x_axis(vector, theta):
        """
        Rotate a 3D vector about the x-axis by angle theta (radians).
        """
        v = np.asarray(vector, dtype=float)
        if v.shape != (3,):
            v = v.ravel()
            if v.shape[0] != 3:
                raise ValueError("vector must have length 3")
        x = v[0]
        y = v[1]
        z = v[2]
        c = math.cos(theta)
        s = math.sin(theta)
        y_new = y * c - z * s
        z_new = y * s + z * c
        return np.array([x, y_new, z_new], dtype=float)


# Classification response:
# import reorganization; temporary variable; type conversion; input validation; nested conditional; guard clause; mathematical formula; standard library helper