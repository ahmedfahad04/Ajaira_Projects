
def is_byte_token(s: str) -> bool:
    import string
    def is_byte_token(s: str) -> bool:
        if not isinstance(s, str) or len(s) != 6:
            return False
        if s[0] != '<' or s[-1] != '>':
            return False
        if s[1] != '0' or s[2].lower() != 'x':
            return False
        hex_chars = set(string.hexdigits)
        return s[3] in hex_chars and s[4] in hex_chars


# Classification response:
# 