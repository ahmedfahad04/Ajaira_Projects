
def moving_average(arr, window_size):
    import numpy as np
    def moving_average(arr, window_size):
        arr = np.asarray(arr, dtype=float)
        if window_size <= 0:
            raise ValueError("window_size must be > 0")
        n = arr.size
        if n == 0:
            return [np.array([]), np.array([])]
        if window_size >= n:
            ma = np.full(n, arr.mean(), dtype=float)
            return [ma, arr - ma]
        try:
            from numpy.lib.stride_tricks import sliding_window_view
            windows = sliding_window_view(arr, window_size)
            valid = windows.mean(axis=1)
        except Exception:
            cumsum = np.concatenate(([0.0], arr.cumsum()))
            valid = (cumsum[window_size:] - cumsum[:-window_size]) / float(window_size)
        m = valid.size
        left = (window_size - 1) // 2
        right = n - m - left
        ma = np.concatenate((np.full(left, valid[0], dtype=float), valid, np.full(right, valid[-1], dtype=float)))
        residuals = arr - ma
        return [ma, residuals]


# Classification response:
# variable renaming; import reorganization; helper function extraction; guard clause; early return; try-except wrapper; sliding window; prefix/suffix computation; input validation; empty input handling; boundary case handling; behavior change; type conversion; standard library helper