
def interleave(tensor1, tensor2):
    import torch
    def interleave(tensor1, tensor2):
        # Handle scalar 0-d tensors by promoting to 1-d
        scalar_mode = False
        if tensor1.dim() == 0 and tensor2.dim() == 0:
            t1 = tensor1.unsqueeze(0)
            t2 = tensor2.unsqueeze(0)
            scalar_mode = True
        else:
            t1 = tensor1
            t2 = tensor2
        if t1.shape[1:] != t2.shape[1:]:
            raise ValueError("Shapes must match except for the first dimension")
        # Stack along new dim 0 as (2, n, ...)
        stacked = torch.stack((t1, t2), dim=0)  # shape (2, n, ...)
        # Transpose to (n, 2, ...) then reshape to (2*n, ...)
        trans = stacked.transpose(0, 1).contiguous()
        interleaved1 = trans.view(-1, *t1.shape[1:])
        # Build second by stacking reversed order
        stacked_rev = torch.stack((t2, t1), dim=0)
        trans_rev = stacked_rev.transpose(0, 1).contiguous()
        interleaved2 = trans_rev.view(-1, *t1.shape[1:])
        return interleaved1, interleaved2


# Classification response:
# helper function extraction;guard clause;input validation;boundary case handling;temporary variable;import reorganization