
def get_crop_box(box, expand):
    import math
    def get_crop_box(box, expand):
        x, y, x1, y1 = box
        if expand < 0:
            raise ValueError("expand must be non-negative")
        # handle reversed coordinates
        left = min(x, x1)
        right = max(x, x1)
        top = min(y, y1)
        bottom = max(y, y1)
        w = right - left
        h = bottom - top
        cx = (left + right) / 2.0
        cy = (top + bottom) / 2.0
        # ensure integer pixel coordinates for the returned box
        s = max(w, h) * expand / 2.0
        # round to nearest integer boundaries while keeping center aligned as integers
        new_x = int(math.floor(cx - s + 0.5))
        new_y = int(math.floor(cy - s + 0.5))
        new_x1 = int(math.floor(cx + s + 0.5))
        new_y1 = int(math.floor(cy + s + 0.5))
        # Recompute half-size based on the integerized box to return consistent s
        s_int = max(new_x1 - new_x, new_y1 - new_y) / 2.0
        return [new_x, new_y, new_x1, new_y1], s_int


# Classification response:
# import reorganization; guard clause; input validation; boundary case handling; standard library helper; type conversion; temporary variable; mathematical formula; helper function extraction