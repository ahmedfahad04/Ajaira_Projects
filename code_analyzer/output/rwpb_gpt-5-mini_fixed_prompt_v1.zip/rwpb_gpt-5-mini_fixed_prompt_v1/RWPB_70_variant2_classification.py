
def psnr_to_mse(psnr):
    import math
    def psnr_to_mse(psnr):
        k = -0.1 * math.log(10.0)
        # handle scalars
        if isinstance(psnr, (int, float)):
            return math.exp(k * psnr)
        # handle iterables (lists, tuples, numpy arrays, etc.)
        try:
            iterator = iter(psnr)
        except TypeError:
            # fallback for unexpected types
            return math.exp(k * psnr)
        return [math.exp(k * float(x)) for x in iterator]


# Classification response:
# import reorganization;standard library helper;guard clause;try-except wrapper;helper function extraction;list comprehension;temporary variable;type check;type conversion;behavior change