
def movmean(arr, n_avg):
    import numpy as np
    def movmean(arr, n_avg):
        arr = np.asarray(arr)
        if n_avg <= 0 or n_avg > arr.size or arr.ndim != 1:
            return np.array([])
        try:
            from numpy.lib.stride_tricks import sliding_window_view
            windows = sliding_window_view(arr, window_shape=n_avg)
            return windows.mean(axis=1)
        except Exception:
            kernel = np.ones(n_avg, dtype=float) / float(n_avg)
            return np.convolve(arr, kernel, mode='valid')


# Classification response:
# import reorganization; guard clause; try-except wrapper; helper function extraction; type conversion; boundary case handling; sliding window; standard library helper; error suppression