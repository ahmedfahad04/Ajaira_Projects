
def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
    import torch
    def rms_norm_ref(x, weight, bias, residual=None, eps=1e-6, prenorm=False, upcast=False):
        orig_x = x
        if upcast:
            compute_dtype = torch.float32
            x = x.to(compute_dtype)
            weight = weight.to(compute_dtype) if weight is not None else None
            bias = bias.to(compute_dtype) if bias is not None else None
            residual = residual.to(compute_dtype) if residual is not None else None
        # ensure weight/bias broadcastable to last dim
        last = x.shape[-1]
        if weight is not None and weight.ndim == 1:
            w = weight.view(*([1] * (x.ndim - 1)), last)
        else:
            w = weight
        if bias is not None and bias.ndim == 1:
            b = bias.view(*([1] * (x.ndim - 1)), last)
        else:
            b = bias
        ms = (x * x).mean(dim=-1, keepdim=True)
        inv = torch.rsqrt(ms + eps)
        normalized = x * inv
        if w is not None:
            out = normalized * w
        else:
            out = normalized
        if b is not None:
            out = out + b
        if residual is not None:
            # align residual dtype and shape
            if residual.dtype != out.dtype:
                residual = residual.to(out.dtype)
            out = out + residual
        if upcast:
            out = out.to(orig_x.dtype)
        if prenorm:
            return out, orig_x
        return out


# Classification response:
# variable renaming; temporary variable; import reorganization; standard library helper; split condition; branch reordering; type conversion; boundary case handling; behavior change; helper function extraction