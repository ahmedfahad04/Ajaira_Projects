
def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
    def flatten_dict(d: dict, parent_key: str = "", sep: str = "/") -> dict:
        if not isinstance(d, dict):
            return {parent_key: d} if parent_key else {}
        result = {}
        stack = [(d, parent_key)]
        while stack:
            current, base = stack.pop()
            for k, v in current.items():
                new_key = base + sep + str(k) if base else str(k)
                if isinstance(v, dict) and v:
                    stack.append((v, new_key))
                else:
                    result[new_key] = v
        return result


# Classification response:
# loop rewrite;stack-based;accumulator dict;in-place mutation;type check;empty input handling;string formatting change;helper function extraction;variable renaming