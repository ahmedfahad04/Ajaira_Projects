
def movmean(arr, n_avg):
    import numpy as np
    def movmean(arr, n_avg):
        arr = np.asarray(arr)
        if n_avg <= 0 or n_avg > arr.size or arr.ndim != 1:
            return np.array([])
        kernel = np.ones(n_avg, dtype=float) / float(n_avg)
        return np.convolve(arr, kernel, mode='valid')


# Classification response:
# import reorganization;guard clause;input validation;empty input handling;type conversion;temporary variable;helper function extraction;sliding window