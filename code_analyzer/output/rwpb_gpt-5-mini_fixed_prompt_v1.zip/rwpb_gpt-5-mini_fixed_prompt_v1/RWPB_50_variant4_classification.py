
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        h0, w0 = original_size
        t = tensor
        single = False
        if t.dim() == 3:
            single = True
            t = t.unsqueeze(0)
        if t.dim() != 4:
            raise ValueError("Expected 3D (C,H,W) or 4D (N,C,H,W) tensor")
        n, c, H, W = t.shape
        target_aspect = h0 / float(w0)
        current_aspect = H / float(W)
        if abs(current_aspect - target_aspect) < 1e-6:
            top = (H - h0) // 2
            left = (W - w0) // 2
            out = t[:, :, max(top,0):max(top,0)+min(h0,H), max(left,0):max(left,0)+min(w0,W)]
        else:
            if current_aspect > target_aspect:
                new_H = int(round(W * target_aspect))
                new_H = min(new_H, H)
                top = (H - new_H) // 2
                out = t[:, :, top:top+new_H, :]
            else:
                new_W = int(round(H / target_aspect))
                new_W = min(new_W, W)
                left = (W - new_W) // 2
                out = t[:, :, :, left:left+new_W]
            if out.shape[2] != h0 or out.shape[3] != w0:
                dtype = out.dtype
                device = out.device
                was_int = dtype in (torch.uint8, torch.int8, torch.int16, torch.int32, torch.int64)
                if was_int:
                    out = out.float()
                out = F.interpolate(out, size=(h0, w0), mode='bilinear', align_corners=False)
                if was_int:
                    out = out.to(dtype)
        if single:
            out = out.squeeze(0)
        return out


# Classification response:
# variable renaming;guard clause;nested conditional;temporary variable;import reorganization;standard library helper;type conversion;input validation;boundary case handling;behavior change