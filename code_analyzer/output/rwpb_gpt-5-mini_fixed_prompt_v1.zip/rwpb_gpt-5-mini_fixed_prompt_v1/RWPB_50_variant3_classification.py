
def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
    import torch
    import torch.nn.functional as F
    def unpad_image(tensor: torch.Tensor, original_size: tuple) -> torch.Tensor:
        h0, w0 = original_size
        t = tensor
        if t.dim() == 3:
            c, H, W = t.shape
            if H < h0 or W < w0:
                pad_h = max(0, h0 - H)
                pad_w = max(0, w0 - W)
                pad_top = pad_h // 2
                pad_bottom = pad_h - pad_top
                pad_left = pad_w // 2
                pad_right = pad_w - pad_left
                t = F.pad(t, (pad_left, pad_right, pad_top, pad_bottom))
                c, H, W = t.shape
            top = (H - h0) // 2
            left = (W - w0) // 2
            return t[:, top:top+h0, left:left+w0]
        elif t.dim() == 4:
            n, c, H, W = t.shape
            if H < h0 or W < w0:
                pad_h = max(0, h0 - H)
                pad_w = max(0, w0 - W)
                pad_top = pad_h // 2
                pad_bottom = pad_h - pad_top
                pad_left = pad_w // 2
                pad_right = pad_w - pad_left
                t = F.pad(t, (pad_left, pad_right, pad_top, pad_bottom))
                n, c, H, W = t.shape
            top = (H - h0) // 2
            left = (W - w0) // 2
            return t[:, :, top:top+h0, left:left+w0]
        else:
            raise ValueError("Unsupported tensor shape")


# Classification response:
# variable renaming; import reorganization; tuple unpacking; temporary variable; nested conditional; combined condition; early return; exception handling; input validation; boundary case handling; standard library helper