import re

class AutomaticGuitarSimulator:
    def __init__(self, text) -> None:
        self.play_text = text or ""

    def interpret(self, display=False):
        text = (self.play_text or "").strip()
        if text == "":
            return []
        tokens = re.split(r'\s+', text)
        result = []
        for tok in tokens:
            m = re.match(r'(.+?)(\d+)$', tok)
            if not m:
                continue
            chord = m.group(1)
            tune = m.group(2)
            # normalize chord (remove trailing punctuation)
            chord = re.sub(r'[^A-Za-z#bMm7]', '', chord)
            entry = {"Chord": chord, "Tune": tune}
            result.append(entry)
            if display:
                self.display(chord, tune)
        return result

    def display(self, key, value):
        out = "Normal Guitar Playing -- Chord: %s, Play Tune: %s" % (key, value)
        print(out)
        return out