import zipfile
import os
from pathlib import Path


class ZipFileProcessor:
    """
    This is a compressed file processing class that provides the ability to read and decompress compressed files
    """

    def __init__(self, file_name):
        self.file_name = file_name

    def read_zip_file(self):
        # Return opened ZipFile or None
        try:
            if not os.path.exists(self.file_name):
                return None
            if not zipfile.is_zipfile(self.file_name):
                return None
            return zipfile.ZipFile(self.file_name, mode="r")
        except Exception:
            return None

    def extract_all(self, output_path):
        try:
            out = Path(output_path)
            out.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(self.file_name, "r") as zf:
                for member in zf.infolist():
                    # sanitize path
                    target = Path(out) / Path(member.filename)
                    if member.filename.endswith("/"):
                        target.mkdir(parents=True, exist_ok=True)
                zf.extractall(path=str(out))
            return True
        except Exception:
            return False

    def extract_file(self, file_name, output_path):
        try:
            with zipfile.ZipFile(self.file_name, "r") as zf:
                # direct match
                if file_name in zf.namelist():
                    out = Path(output_path)
                    out.mkdir(parents=True, exist_ok=True)
                    zf.extract(file_name, path=str(out))
                    return True
                # try to match any entry that endswith file_name
                candidates = [n for n in zf.namelist() if n.endswith(file_name)]
                if candidates:
                    out = Path(output_path)
                    out.mkdir(parents=True, exist_ok=True)
                    zf.extract(candidates[0], path=str(out))
                    return True
            return False
        except Exception:
            return False

    def create_zip_file(self, files, output_file_name):
        try:
            if not files:
                return False
            out = Path(output_file_name)
            if out.is_dir():
                out = out / "archive.zip"
            out.parent.mkdir(parents=True, exist_ok=True)
            if out.suffix.lower() != ".zip":
                out = out.with_suffix(".zip")
            comp = zipfile.ZIP_DEFLATED if hasattr(zipfile, "ZIP_DEFLATED") else zipfile.ZIP_STORED
            any_added = False
            with zipfile.ZipFile(str(out), "w", compression=comp) as zf:
                for item in files:
                    p = Path(item)
                    if not p.exists():
                        continue
                    if p.is_file():
                        # store only the base name
                        zf.write(str(p), arcname=p.name)
                        any_added = True
                    else:
                        # add directory contents preserving structure under the directory name
                        for root, _, filenames in os.walk(p):
                            for fname in filenames:
                                full = Path(root) / fname
                                arcname = str(full.relative_to(p.parent))
                                zf.write(str(full), arcname=arcname)
                                any_added = True
            return any_added
        except Exception:
            return False