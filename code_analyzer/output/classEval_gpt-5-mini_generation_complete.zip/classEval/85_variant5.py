import time
import math

class Thermostat:
    """
    The class manages temperature control, including setting and retrieving the target temperature, adjusting the mode, and simulating temperature operation.
    """

    def __init__(self, current_temperature, target_temperature, mode):
        self.current_temperature = float(current_temperature)
        self.target_temperature = float(target_temperature)
        self.mode = mode

    def get_target_temperature(self):
        return self.target_temperature

    def set_target_temperature(self, temperature):
        self.target_temperature = float(temperature)

    def get_mode(self):
        return self.mode

    def set_mode(self, mode):
        if mode not in ('heat', 'cool'):
            raise ValueError("Mode must be 'heat' or 'cool'")
        self.mode = mode

    def auto_set_mode(self):
        self.mode = 'heat' if self.current_temperature < self.target_temperature else 'cool'

    def auto_check_conflict(self):
        if self.current_temperature < self.target_temperature:
            if self.mode == 'heat':
                return True
            else:
                self.auto_set_mode()
                return False
        else:
            if self.mode == 'cool':
                return True
            else:
                self.auto_set_mode()
                return False

    def _step_generator(self):
        self.auto_set_mode()
        direction = 1.0 if self.mode == 'heat' else -1.0
        while True:
            diff = self.target_temperature - self.current_temperature
            if abs(diff) < 1e-9:
                break
            step = diff if abs(diff) < 1.0 else direction * 1.0
            # normalize sign for last fractional step
            if step == direction * 1.0:
                self.current_temperature += step
            else:
                self.current_temperature = float(self.target_temperature)
            yield 1

    def simulate_operation(self):
        gen = self._step_generator()
        count = 0
        for _ in gen:
            count += 1
        return count