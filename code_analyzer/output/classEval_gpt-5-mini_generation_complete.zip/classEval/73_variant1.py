class RPGCharacter:
    """
    The class represents a role-playing game character, which allows to attack other characters, heal, gain experience, level up, and check if the character is alive.
    """

    def __init__(self, name, hp, attack_power, defense, level=1):
        self.name = name
        # treat hp as both current hp and max_hp at start
        self.max_hp = hp
        self.hp = hp
        self.attack_power = attack_power
        self.defense = defense
        self.level = level
        self.exp = 0

    def attack(self, other_character):
        damage = self.attack_power - other_character.defense
        if damage < 0:
            damage = 0
        other_character.hp = max(0, other_character.hp - damage)
        return damage

    def heal(self):
        self.hp = min(self.max_hp, self.hp + 10)
        return self.hp

    def _inc_level(self):
        if self.level >= 100:
            return
        self.level += 1
        # increase max and current hp
        self.max_hp += 20
        self.hp += 20
        self.attack_power += 5
        self.defense += 5

    def gain_exp(self, amount):
        # add amount to current exp and level up as long as threshold met and level < 100
        self.exp += amount
        while self.level < 100:
            threshold = 100 * self.level
            if self.exp >= threshold:
                # consume threshold and level up
                self.exp -= threshold
                self._inc_level()
            else:
                break
        # if at max level, exp cannot increase beyond threshold (keep as is or cap?). We'll cap to threshold.
        if self.level >= 100:
            # At max level, keep exp as min(current, threshold)
            self.exp = min(self.exp, 100 * self.level)
        return None

    def level_up(self):
        # level up once and reset exp to zero, obey max level
        if self.level >= 100:
            self.exp = 0
            return (self.level, self.hp, self.attack_power, self.defense)
        self._inc_level()
        self.exp = 0
        return (self.level, self.hp, self.attack_power, self.defense)

    def is_alive(self):
        return self.hp > 0

# Classification response:
# helper function extraction; state variable; temporary variable; while loop; boundary case handling; behavior change; builtin function