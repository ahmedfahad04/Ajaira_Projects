import numpy as np
from gensim import matutils
from numpy import dot, array

class VectorUtil:
    """
    The class provides vector operations, including calculating similarity, cosine similarities, average similarity, and IDF weights.
    """

    @staticmethod
    def similarity(vector_1, vector_2):
        v1 = np.asarray(vector_1, dtype=float)
        v2 = np.asarray(vector_2, dtype=float)
        norm1 = np.linalg.norm(v1)
        norm2 = np.linalg.norm(v2)
        if norm1 == 0 or norm2 == 0:
            return 0.0
        return float(np.dot(v1, v2) / (norm1 * norm2))

    @staticmethod
    def cosine_similarities(vector_1, vectors_all):
        v1 = np.asarray(vector_1, dtype=float)
        if len(vectors_all) == 0:
            return np.array([], dtype=float)
        stacked = np.vstack([np.asarray(v, dtype=float) for v in vectors_all])
        norm1 = np.linalg.norm(v1)
        norms = np.linalg.norm(stacked, axis=1)
        dots = stacked.dot(v1)
        # avoid division by zero
        denom = norms * norm1
        denom_zero = denom == 0
        result = np.empty_like(dots, dtype=float)
        result[denom_zero] = 0.0
        result[~denom_zero] = dots[~denom_zero] / denom[~denom_zero]
        return result

    @staticmethod
    def n_similarity(vector_list_1, vector_list_2):
        if not vector_list_1 or not vector_list_2:
            return 0.0
        arr1 = np.vstack([np.asarray(v, dtype=float) for v in vector_list_1]).mean(axis=0)
        arr2 = np.vstack([np.asarray(v, dtype=float) for v in vector_list_2]).mean(axis=0)
        return VectorUtil.similarity(arr1, arr2)

    @staticmethod
    def compute_idf_weight_dict(total_num, number_dict):
        total = float(total_num)
        return {k: float(np.log((total + 1.0) / (v + 1.0))) for k, v in number_dict.items()}