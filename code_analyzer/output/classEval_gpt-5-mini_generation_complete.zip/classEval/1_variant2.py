import math
class AreaCalculator:
    """
    This is a class for calculating the area of different shapes, including circle, sphere, cylinder, sector and annulus.
    """

    def __init__(self, radius):
        """
        Initialize the radius for shapes.
        :param radius: float
        """
        if not isinstance(radius, (int, float)):
            raise TypeError("radius must be a number")
        if radius < 0:
            raise ValueError("radius must be non-negative")
        self.radius = float(radius)

    def _ensure_non_negative(self, *values):
        for v in values:
            if not isinstance(v, (int, float)):
                raise TypeError("arguments must be numbers")
            if v < 0:
                raise ValueError("arguments must be non-negative")

    def calculate_circle_area(self):
        """
        calculate the area of circle based on self.radius
        :return: area of circle, float
        """
        return math.pi * self.radius * self.radius

    def calculate_sphere_area(self):
        """
        calculate the area of sphere based on self.radius
        :return: area of sphere, float
        """
        return 4.0 * math.pi * self.radius * self.radius

    def calculate_cylinder_area(self, height):
        """
        calculate the area of cylinder based on self.radius and height
        :param height: height of cylinder, float
        :return: area of cylinder, float
        """
        self._ensure_non_negative(height)
        return 2.0 * math.pi * self.radius * (self.radius + float(height))

    def calculate_sector_area(self, angle):
        """
        calculate the area of sector based on self.radius and angle
        :param angle: angle of sector, float
        :return: area of sector, float
        """
        if not isinstance(angle, (int, float)):
            raise TypeError("angle must be a number (radians)")
        return 0.5 * (self.radius ** 2) * float(angle)

    def calculate_annulus_area(self, inner_radius, outer_radius):
        """
        calculate the area of annulus based on inner_radius and out_radius
        :param inner_radius: inner radius of sector, float
        :param outer_radius: outer radius of sector, float
        :return: area of annulus, float
        """
        self._ensure_non_negative(inner_radius, outer_radius)
        if outer_radius < inner_radius:
            raise ValueError("outer_radius must be >= inner_radius")
        return math.pi * (float(outer_radius) ** 2 - float(inner_radius) ** 2)