import csv
import os

class CSVProcessor:
    """
    This is a class for processing CSV files, including readring and writing CSV data, as well as processing specific operations and saving as a new CSV file.
    """

    def __init__(self):
        pass

    def read_csv(self, file_name):
        try:
            with open(file_name, newline='', encoding='utf-8') as f:
                reader = csv.reader(f)
                iterator = iter(reader)
                try:
                    title = next(iterator)
                except StopIteration:
                    return [], []
                data = [row for row in iterator]
                return title, data
        except Exception:
            return [], []

    def write_csv(self, data, file_name):
        try:
            with open(file_name, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
                for row in data:
                    writer.writerow(row)
            return 1
        except Exception:
            return 0

    def process_csv_data(self, N, save_file_name):
        try:
            title, data = self.read_csv(save_file_name)
            if title == [] and data == []:
                return 0
            processed = []
            for row in data:
                if N < 0 or N >= len(row):
                    processed.append([''])
                else:
                    processed.append([row[N].upper()])
            base, ext = os.path.splitext(save_file_name)
            if ext:
                out_name = f"{base}_process{ext}"
            else:
                out_name = f"{save_file_name}_process"
            out_content = [title] + processed
            return self.write_csv(out_content, out_name)
        except Exception:
            return 0