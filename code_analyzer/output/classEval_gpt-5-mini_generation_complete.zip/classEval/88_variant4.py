from math import pi, fabs

class TriCalculator:
    def __init__(self):
        pass

    def factorial(self, a):
        if a < 0:
            raise ValueError("factorial undefined for negative")
        result = 1
        i = 1
        while i <= a:
            result *= i
            i += 1
        return result

    def _rad(self, x):
        r = (x % 360) * pi / 180.0
        if r > pi:
            r -= 2 * pi
        return r

    def taylor(self, x, n):
        rad = self._rad(x)
        # compute with tolerance but run exactly n terms as requested
        term = 1.0
        s = term
        for k in range(1, n):
            # recurrence: term_{k} = term_{k-1} * ( -x^2 / ((2k-1)(2k)) )
            term *= - (rad * rad) / ((2 * k - 1) * (2 * k))
            s += term
        return s

    def cos(self, x):
        # default to 25 terms for good precision
        return self.taylor(x, 25)

    def sin(self, x):
        rad = self._rad(x)
        term = rad
        s = term
        k = 1
        while k < 25:
            term *= - (rad * rad) / ((2 * k) * (2 * k + 1))
            s += term
            k += 1
        return s

    def tan(self, x):
        c = self.cos(x)
        if fabs(c) <= 1e-15:
            raise ZeroDivisionError("tan undefined for this angle")
        return self.sin(x) / c