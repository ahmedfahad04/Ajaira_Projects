import re

class Calculator:
    """
    This is a class for a calculator, capable of performing basic arithmetic calculations on numerical expressions using the operators +, -, *, /, and ^ (exponentiation).
    """

    def __init__(self):
        """
        Initialize the operations performed by the five operators'+','-','*','/','^'
        """
        self.operators = {
            '+': lambda x, y: x + y,
            '-': lambda x, y: x - y,
            '*': lambda x, y: x * y,
            '/': lambda x, y: x / y,
            '^': lambda x, y: x ** y
        }

    def precedence(self, operator):
        if operator in ('+','-'):
            return 1
        if operator in ('*','/'):
            return 2
        if operator == '^':
            return 3
        return 0

    def apply_operator(self, operand_stack, operator_stack):
        if not operator_stack or len(operand_stack) < 2:
            return operand_stack, operator_stack
        op = operator_stack.pop()
        b = operand_stack.pop()
        a = operand_stack.pop()
        operand_stack.append(self.operators[op](a, b))
        return operand_stack, operator_stack

    def _tokenize(self, s):
        tokens = []
        i = 0
        n = len(s)
        while i < n:
            c = s[i]
            if c.isspace():
                i += 1
                continue
            if c in '()+-*/^':
                # unary handling
                if c in '+-' and (not tokens or tokens[-1] in ('(', '+', '-', '*', '/', '^')):
                    j = i + 1
                    num = c
                    dot = False
                    while j < n and (s[j].isdigit() or s[j] == '.'):
                        if s[j] == '.':
                            if dot:
                                break
                            dot = True
                        num += s[j]
                        j += 1
                    if len(num) > 1 and (num[1].isdigit() or num[1] == '.'):
                        tokens.append(num)
                        i = j
                        continue
                tokens.append(c)
                i += 1
            elif c.isdigit() or c == '.':
                j = i
                num = ''
                dot = False
                while j < n and (s[j].isdigit() or s[j] == '.'):
                    if s[j] == '.':
                        if dot:
                            break
                        dot = True
                    num += s[j]
                    j += 1
                tokens.append(num)
                i = j
            else:
                return None
        return tokens

    def calculate(self, expression):
        tokens = self._tokenize(expression)
        if tokens is None:
            return None
        operand_stack = []
        operator_stack = []
        right_assoc = {'^'}
        try:
            for tok in tokens:
                if re.fullmatch(r'[+-]?\d+(\.\d+)?', tok):
                    operand_stack.append(float(tok))
                elif tok == '(':
                    operator_stack.append(tok)
                elif tok == ')':
                    while operator_stack and operator_stack[-1] != '(':
                        operand_stack, operator_stack = self.apply_operator(operand_stack, operator_stack)
                    if not operator_stack or operator_stack[-1] != '(':
                        return None
                    operator_stack.pop()
                elif tok in self.operators:
                    while operator_stack and operator_stack[-1] in self.operators:
                        top = operator_stack[-1]
                        if (top not in right_assoc and self.precedence(top) >= self.precedence(tok)) or (top in right_assoc and self.precedence(top) > self.precedence(tok)):
                            operand_stack, operator_stack = self.apply_operator(operand_stack, operator_stack)
                        else:
                            break
                    operator_stack.append(tok)
                else:
                    return None
            while operator_stack:
                if operator_stack[-1] in '()':
                    return None
                operand_stack, operator_stack = self.apply_operator(operand_stack, operator_stack)
        except Exception:
            return None
        if len(operand_stack) != 1:
            return None
        return float(operand_stack[0])