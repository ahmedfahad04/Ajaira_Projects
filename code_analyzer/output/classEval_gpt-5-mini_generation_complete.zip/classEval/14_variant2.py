import sqlite3

class BookManagementDB:
    """
    This is a database class as a book management system, used to handle the operations of adding, removing, updating, and searching books.
    """

    def __init__(self, db_name):
        self.connection = sqlite3.connect(db_name, timeout=5)
        # use row factory default (tuples)
        self.create_table()

    def create_table(self):
        with self.connection:
            self.connection.execute(
                "CREATE TABLE IF NOT EXISTS books ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "title TEXT NOT NULL, "
                "author TEXT NOT NULL, "
                "available INTEGER NOT NULL DEFAULT 1)"
            )

    def add_book(self, title, author):
        if not isinstance(title, str) or not isinstance(author, str):
            raise ValueError("title and author must be strings")
        with self.connection:
            cur = self.connection.execute(
                "INSERT INTO books (title, author, available) VALUES (?, ?, 1)",
                (title.strip(), author.strip())
            )
            return cur.lastrowid

    def remove_book(self, book_id):
        with self.connection:
            cur = self.connection.execute("DELETE FROM books WHERE id = ?", (book_id,))
            return cur.rowcount

    def borrow_book(self, book_id):
        with self.connection:
            # ensure only available books can be borrowed
            cur = self.connection.execute(
                "UPDATE books SET available = 0 WHERE id = ? AND available = 1",
                (book_id,)
            )
            return cur.rowcount == 1

    def return_book(self, book_id):
        with self.connection:
            cur = self.connection.execute(
                "UPDATE books SET available = 1 WHERE id = ? AND available = 0",
                (book_id,)
            )
            return cur.rowcount == 1

    def search_books(self):
        cur = self.connection.execute("SELECT id, title, author, available FROM books ORDER BY id")
        return cur.fetchall()