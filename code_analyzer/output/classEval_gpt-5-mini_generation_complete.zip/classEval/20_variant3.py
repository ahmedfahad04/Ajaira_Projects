from datetime import datetime
from dataclasses import dataclass, asdict

@dataclass
class Message:
    sender: str
    receiver: str
    message: str
    timestamp: str

class Chat:
    """
    This is a chat class with the functions of adding users, removing users, sending messages, and obtaining messages.
    """

    def __init__(self):
        """
        Initialize the Chat with an attribute users, which is an empty dictionary.
        """
        self.users = {}

    def add_user(self, username):
        if username in self.users:
            return False
        self.users[username] = []
        return True

    def remove_user(self, username):
        if username in self.users:
            del self.users[username]
            return True
        return False

    def send_message(self, sender, receiver, message):
        if sender not in self.users or receiver not in self.users:
            return False
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        msg = Message(sender=sender, receiver=receiver, message=message, timestamp=ts)
        self.users[sender].append(msg)
        return True

    def get_messages(self, username):
        if username not in self.users:
            return []
        return [asdict(m) for m in self.users[username]]