from collections import defaultdict

class Hotel:
    """
    This is a class as hotel management system, managing the booking, check-in, check-out, and availability of rooms in a hotel with different room types.
    """

    def __init__(self, name, rooms):
        self.name = name
        self.available_rooms = dict(rooms)
        # booked_rooms maps room_type -> {name: count}
        self.booked_rooms = defaultdict(dict)

    def book_room(self, room_type, room_number, name):
        if room_type not in self.available_rooms:
            return False
        if room_number <= 0:
            return False
        avail = self.available_rooms[room_type]
        if room_number > avail:
            return avail if avail != 0 else False
        # success
        self.available_rooms[room_type] = avail - room_number
        current = self.booked_rooms[room_type].get(name, 0)
        self.booked_rooms[room_type][name] = current + room_number
        return 'Success!'

    def check_in(self, room_type, room_number, name):
        if room_type not in self.booked_rooms:
            return False
        person_map = self.booked_rooms[room_type]
        if name not in person_map:
            return False
        booked = person_map[name]
        if room_number <= 0 or room_number > booked:
            return False
        if room_number == booked:
            # remove guest but keep empty dict object
            person_map.pop(name, None)
            # ensure the key remains in booked_rooms as an empty dict
            self.booked_rooms[room_type] = {}
        else:
            person_map[name] = booked - room_number

    def check_out(self, room_type, room_number):
        if room_number <= 0:
            return
        self.available_rooms[room_type] = self.available_rooms.get(room_type, 0) + room_number

    def get_available_rooms(self, room_type):
        return self.available_rooms.get(room_type, 0)