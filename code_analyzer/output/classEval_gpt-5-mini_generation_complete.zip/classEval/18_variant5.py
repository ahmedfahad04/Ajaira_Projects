class CamelCaseMap:
    """
    This is a custom class that allows keys to be in camel case style by converting them from underscore style, which provides dictionary-like functionality.
    """

    def __init__(self):
        """
        Initialize data to an empty dictionary
        """
        self._data = {}

    def __getitem__(self, key):
        ck = self._convert_key(key)
        return self._data[ck]

    def __setitem__(self, key, value):
        ck = self._convert_key(key)
        self._data[ck] = value

    def __delitem__(self, key):
        ck = self._convert_key(key)
        del self._data[ck]

    def __iter__(self):
        return iter(self._data.keys())

    def __len__(self):
        return len(self._data)

    def _convert_key(self, key):
        if isinstance(key, str):
            return self._to_camel_case(key)
        return key

    @staticmethod
    def _to_camel_case(key):
        if not isinstance(key, str):
            return key
        # use title on each segment then lowercase first letter of result
        parts = [p for p in key.split('_')]
        if not parts:
            return ''
        # preserve empty segments by treating them as empty strings
        first = parts[0]
        rest = ''.join(p.capitalize() if p else '' for p in parts[1:])
        return first + rest