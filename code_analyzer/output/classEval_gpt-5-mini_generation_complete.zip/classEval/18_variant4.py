class CamelCaseMap:
    """
    This is a custom class that allows keys to be in camel case style by converting them from underscore style, which provides dictionary-like functionality.
    """

    def __init__(self):
        """
        Initialize data to an empty dictionary
        """
        self._data = {}

    def __getitem__(self, key):
        keyc = self._convert_key(key)
        return self._data[keyc]

    def __setitem__(self, key, value):
        keyc = self._convert_key(key)
        self._data[keyc] = value

    def __delitem__(self, key):
        keyc = self._convert_key(key)
        del self._data[keyc]

    def __iter__(self):
        return iter(self._data)

    def __len__(self):
        return len(self._data)

    def _convert_key(self, key):
        if isinstance(key, str):
            return self._to_camel_case(key)
        return key

    @staticmethod
    def _to_camel_case(key):
        if not isinstance(key, str):
            return key
        res_chars = []
        upper_next = False
        for ch in key:
            if ch == '_':
                upper_next = True
                continue
            if upper_next:
                res_chars.append(ch.upper())
                upper_next = False
            else:
                res_chars.append(ch)
        return ''.join(res_chars)