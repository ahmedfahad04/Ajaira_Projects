import itertools
from functools import reduce
import operator

class ArrangementCalculator:
    """
    The Arrangement class provides permutation calculations and selection operations for a given set of data elements.
    """

    def __init__(self, datas):
        self.datas = list(datas)

    @staticmethod
    def factorial(n):
        if n < 0:
            raise ValueError("Negative factorial is not defined")
        return reduce(operator.mul, range(1, n + 1), 1)

    @staticmethod
    def count(n, m=None):
        if n < 0:
            return 0
        if m is None or m == n:
            return ArrangementCalculator.factorial(n)
        if m < 0 or m > n:
            return 0
        # compute product n*(n-1)*...*(n-m+1)
        return reduce(operator.mul, range(n - m + 1, n + 1), 1)

    @staticmethod
    def count_all(n):
        if n <= 0:
            return 0
        return sum(ArrangementCalculator.count(n, k) for k in range(1, n + 1))

    def select(self, m=None):
        n = len(self.datas)
        if m is None:
            m = n
        if m < 0 or m > n:
            return []
        return [list(p) for p in itertools.permutations(self.datas, m)]

    def select_all(self):
        return [list(p) for k in range(1, len(self.datas) + 1) for p in itertools.permutations(self.datas, k)]