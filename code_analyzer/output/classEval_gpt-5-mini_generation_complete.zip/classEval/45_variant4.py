from PIL import Image, ImageEnhance
from typing import Union

class ImageProcessor:
    """
    This is a class to process image, including loading, saving, resizing, rotating, and adjusting the brightness of images.
    """

    def __init__(self):
        """
        Initialize self.image
        """
        self.image = None

    def load_image(self, image_path: Union[str, bytes]):
        """
        Use Image util in PIL to open a image
        """
        if not image_path:
            raise ValueError("image_path must be provided")
        img = Image.open(image_path)
        # store as RGB or preserve mode if already appropriate
        try:
            self.image = img.convert("RGBA") if img.mode == "P" else img.copy()
        finally:
            img.close()
        return self.image

    def save_image(self, save_path: str):
        """
        Save image to a path if image has opened
        """
        if self.image is None:
            raise ValueError("No image loaded")
        # If image has no format, let PIL determine from path
        params = {}
        if getattr(self.image, "format", None):
            params['format'] = self.image.format
        self.image.save(save_path, **params)

    def resize_image(self, width: int, height: int):
        """
        Risize the image if image has opened.
        """
        if self.image is None:
            raise ValueError("No image loaded")
        if not isinstance(width, int) or not isinstance(height, int):
            raise TypeError("width and height must be integers")
        if width <= 0 or height <= 0:
            raise ValueError("width and height must be positive")
        # preserve aspect ratio by computing scale and padding to fit exact size
        orig_w, orig_h = self.image.size
        scale = min(width / orig_w, height / orig_h)
        new_w = max(1, int(orig_w * scale))
        new_h = max(1, int(orig_h * scale))
        resized = self.image.resize((new_w, new_h), Image.LANCZOS)
        if resized.size != (width, height):
            # create background and paste centered
            background = Image.new(self.image.mode, (width, height))
            x = (width - new_w) // 2
            y = (height - new_h) // 2
            background.paste(resized, (x, y))
            self.image = background
        else:
            self.image = resized
        return self.image

    def rotate_image(self, degrees: float):
        """
        rotate image if image has opened
        """
        if self.image is None:
            raise ValueError("No image loaded")
        try:
            deg = float(degrees)
        except Exception:
            raise TypeError("degrees must be numeric")
        self.image = self.image.rotate(deg, resample=Image.BICUBIC, expand=True)
        return self.image

    def adjust_brightness(self, factor: float):
        """
        Adjust the brightness of image if image has opened.
        """
        if self.image is None:
            raise ValueError("No image loaded")
        try:
            f = float(factor)
        except Exception:
            raise TypeError("factor must be numeric")
        enhancer = ImageEnhance.Brightness(self.image)
        self.image = enhancer.enhance(f)
        return self.image