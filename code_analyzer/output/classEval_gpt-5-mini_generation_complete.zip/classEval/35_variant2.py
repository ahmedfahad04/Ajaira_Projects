import copy

class EightPuzzle:
    """
    This class is an implementation of the classic 8-puzzle game, including methods for finding the blank tile, making moves, getting possible moves, and solving the puzzle using a breadth-first search algorithm.
    """

    def __init__(self, initial_state):
        self.initial_state = initial_state
        self.goal_state = [[1,2,3],[4,5,6],[7,8,0]]

    def find_blank(self, state):
        for r in range(3):
            for c in range(3):
                if state[r][c] == 0:
                    return (r, c)
        return (-1, -1)

    def move(self, state, direction):
        r, c = self.find_blank(state)
        new = [row[:] for row in state]
        if direction == 'up' and r > 0:
            new[r][c], new[r-1][c] = new[r-1][c], new[r][c]
        elif direction == 'down' and r < 2:
            new[r][c], new[r+1][c] = new[r+1][c], new[r][c]
        elif direction == 'left' and c > 0:
            new[r][c], new[r][c-1] = new[r][c-1], new[r][c]
        elif direction == 'right' and c < 2:
            new[r][c], new[r][c+1] = new[r][c+1], new[r][c]
        return new

    def get_possible_moves(self, state):
        r, c = self.find_blank(state)
        res = []
        # natural reading order
        if r > 0:
            res.append('up')
        if r < 2:
            res.append('down')
        if c > 0:
            res.append('left')
        if c < 2:
            res.append('right')
        return res

    def solve(self):
        # BFS using parent mapping
        if self.initial_state == self.goal_state:
            return []
        def to_key(s):
            return tuple(x for row in s for x in row)
        start = to_key(self.initial_state)
        goal = to_key(self.goal_state)
        queue = [start]
        parent = {start: None}
        move_from = {start: None}
        while queue:
            cur = queue.pop(0)
            cur_state = [list(cur[i*3:(i+1)*3]) for i in range(3)]
            for m in self.get_possible_moves(cur_state):
                nxt_state = self.move(cur_state, m)
                nxt_key = to_key(nxt_state)
                if nxt_key in parent:
                    continue
                parent[nxt_key] = cur
                move_from[nxt_key] = m
                if nxt_key == goal:
                    # reconstruct
                    path = []
                    k = nxt_key
                    while move_from[k] is not None:
                        path.append(move_from[k])
                        k = parent[k]
                    return list(reversed(path))
                queue.append(nxt_key)
        return []