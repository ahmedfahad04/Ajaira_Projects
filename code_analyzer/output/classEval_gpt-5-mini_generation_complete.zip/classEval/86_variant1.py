class TicTacToe:
    """
    The class represents a game of Tic-Tac-Toe and its functions include making a move on the board, checking for a winner, and determining if the board is full.
    """

    def __init__(self, N=3):
        """
        Initialize an NxN game board with all empty spaces and current symble player, default is 'X'.
        """
        self.N = N
        self.board = [[' ' for _ in range(self.N)] for _ in range(self.N)]
        self.current_player = 'X'

    def make_move(self, row, col):
        """
        Place the current player's mark at the specified position on the board and switch the mark.
        :param row: int, the row index of the position (0-based)
        :param col: int, the column index of the position (0-based)
        :return: bool, indicating whether the move was successful or not
        """
        if not (0 <= row < self.N and 0 <= col < self.N):
            return False
        if self.board[row][col] != ' ':
            return False
        self.board[row][col] = self.current_player
        self.current_player = 'O' if self.current_player == 'X' else 'X'
        return True

    def check_winner(self):
        """
        Check if there is a winner on the board in rows, columns and diagonals.
        :return: str or None, the mark of the winner ('X' or 'O'), or None if there is no winner yet
        """
        # Rows
        for r in range(self.N):
            first = self.board[r][0]
            if first == ' ':
                continue
            win = True
            for c in range(1, self.N):
                if self.board[r][c] != first:
                    win = False
                    break
            if win:
                return first
        # Columns
        for c in range(self.N):
            first = self.board[0][c]
            if first == ' ':
                continue
            win = True
            for r in range(1, self.N):
                if self.board[r][c] != first:
                    win = False
                    break
            if win:
                return first
        # Main diagonal
        first = self.board[0][0]
        if first != ' ':
            win = True
            for i in range(1, self.N):
                if self.board[i][i] != first:
                    win = False
                    break
            if win:
                return first
        # Anti-diagonal
        first = self.board[0][self.N - 1]
        if first != ' ':
            win = True
            for i in range(1, self.N):
                if self.board[i][self.N - 1 - i] != first:
                    win = False
                    break
            if win:
                return first
        return None

    def is_board_full(self):
        """
        Check if the game board is completely filled.
        :return: bool, indicating whether the game board is full or not
        """
        for r in range(self.N):
            for c in range(self.N):
                if self.board[r][c] == ' ':
                    return False
        return True