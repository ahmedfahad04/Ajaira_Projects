from decimal import Decimal, getcontext

class DiscountStrategy:
    """
    This is a class that allows to use different discount strategy based on shopping credit or shopping cart in supermarket.
    Uses Decimal for monetary calculations.
    """

    def __init__(self, customer, cart, promotion=None):
        getcontext().prec = 28
        self.customer = customer or {}
        self.cart = list(cart) if cart is not None else []
        self.promotion = promotion
        # precompute as Decimal
        self._total_dec = None
        self.total()

    def total(self):
        if self._total_dec is None:
            total = Decimal('0')
            for item in self.cart:
                qty = Decimal(str(item.get('quantity', 0)))
                price = Decimal(str(item.get('price', 0)))
                total += qty * price
            self._total_dec = total
        return float(self._total_dec)

    def due(self):
        total_dec = Decimal(str(self.total()))
        discount = Decimal('0')
        if self.promotion and callable(self.promotion):
            discount = Decimal(str(self.promotion(self)))
        return float(total_dec - discount)

    @staticmethod
    def FidelityPromo(order):
        fidelity = order.customer.get('fidelity', 0)
        total_dec = Decimal(str(order.total()))
        if fidelity >= 1000:
            return float(total_dec * Decimal('0.05'))
        return 0.0

    @staticmethod
    def BulkItemPromo(order):
        from decimal import Decimal
        discount = Decimal('0')
        for item in order.cart:
            qty = item.get('quantity', 0)
            if qty >= 20:
                discount += Decimal(str(qty)) * Decimal(str(item.get('price', 0))) * Decimal('0.10')
        return float(discount)

    @staticmethod
    def LargeOrderPromo(order):
        from decimal import Decimal
        products = {item.get('product') for item in order.cart if 'product' in item}
        if len(products) >= 10:
            return float(Decimal(str(order.total())) * Decimal('0.07'))
        return 0.0