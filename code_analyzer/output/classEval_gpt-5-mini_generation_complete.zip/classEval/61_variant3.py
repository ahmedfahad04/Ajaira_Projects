import random
import threading

class MusicPlayer:
    """
    This is a class as a music player that provides to play, stop, add songs, remove songs, set volume, shuffle, and switch to the next or previous song.
    """

    def __init__(self):
        """
        Initializes the music player with an empty playlist, no current song, and a default volume of 50.
        """
        self.playlist = []
        self.current_song = None
        self._current_index = None
        self.volume = 50
        self._lock = threading.Lock()

    def _sync_index_to_song(self):
        if self._current_index is None:
            self.current_song = None
        elif 0 <= self._current_index < len(self.playlist):
            self.current_song = self.playlist[self._current_index]
        else:
            self._current_index = None
            self.current_song = None

    def add_song(self, song):
        """
        Adds a song to the playlist.
        """
        with self._lock:
            self.playlist.append(song)
            if self._current_index is None:
                self._current_index = 0
                self._sync_index_to_song()

    def remove_song(self, song):
        """
        Removes a song from the playlist.
        """
        with self._lock:
            if song not in self.playlist:
                return False
            idx = self.playlist.index(song)
            self.playlist.pop(idx)
            if self._current_index is None:
                self.current_song = None
                return True
            if idx < self._current_index:
                self._current_index -= 1
            elif idx == self._current_index:
                # try to keep playing next song at same index
                if self._current_index < len(self.playlist):
                    # current index remains same and now points to next song
                    pass
                else:
                    # no next song, try previous
                    if len(self.playlist) == 0:
                        self._current_index = None
                    else:
                        self._current_index = len(self.playlist) - 1
            self._sync_index_to_song()
            return True

    def play(self):
        """
        Plays the current song in the playlist.
        """
        with self._lock:
            if not self.playlist:
                self._current_index = None
                self.current_song = None
                return False
            if self._current_index is None:
                self._current_index = 0
            self._sync_index_to_song()
            return self.current_song

    def stop(self):
        """
        Stops the current song in the playlist.
        """
        with self._lock:
            if self._current_index is None or self.current_song is None:
                return False
            self._current_index = None
            self.current_song = None
            return True

    def switch_song(self):
        """
        Switches to the next song in the playlist.
        """
        with self._lock:
            if not self.playlist:
                return False
            if self._current_index is None:
                self._current_index = 0
                self._sync_index_to_song()
                return True
            if self._current_index + 1 < len(self.playlist):
                self._current_index += 1
                self._sync_index_to_song()
                return True
            return False

    def previous_song(self):
        """
        Switches to the previous song in the playlist.
        """
        with self._lock:
            if not self.playlist:
                return False
            if self._current_index is None:
                self._current_index = 0
                self._sync_index_to_song()
                return True
            if self._current_index - 1 >= 0:
                self._current_index -= 1
                self._sync_index_to_song()
                return True
            return False

    def set_volume(self, volume):
        """
        Sets the volume of the music player, if the volume is between 0 and 100 is valid.
        """
        try:
            vol = int(volume)
        except Exception:
            return False
        if 0 <= vol <= 100:
            with self._lock:
                self.volume = vol
            return True
        return False

    def shuffle(self):
        """
        Shuffles the playlist.
        """
        with self._lock:
            if not self.playlist:
                return False
            current = None
            if self._current_index is not None and 0 <= self._current_index < len(self.playlist):
                current = self.playlist[self._current_index]
            random.shuffle(self.playlist)
            if current is not None and current in self.playlist:
                self._current_index = self.playlist.index(current)
            else:
                self._current_index = 0
            self._sync_index_to_song()
            return True

# Classification response:
# import reorganization; helper function extraction; state variable; guard clause; try-except wrapper; type conversion; boundary case handling; temporary variable; error suppression