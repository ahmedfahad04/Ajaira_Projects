import ipaddress

class IPAddress:
    """
    This is a class to process IP Address, including validating, getting the octets and obtaining the binary representation of a valid IP address.
    """
    def __init__(self, ip_address):
        self.ip_address = ip_address

    def is_valid(self):
        if not isinstance(self.ip_address, str):
            return False
        parts = self.ip_address.split('.')
        if len(parts) != 4:
            return False
        for p in parts:
            if p == '' or (p[0] in '+-'):
                return False
            if not all(ch.isdigit() for ch in p):
                return False
            try:
                v = int(p)
            except Exception:
                return False
            if v < 0 or v > 255:
                return False
        # Additionally verify using ipaddress to catch odd cases
        try:
            ipaddress.IPv4Address(self.ip_address)
        except Exception:
            return False
        return True

    def get_octets(self):
        return self.ip_address.split('.') if self.is_valid() else []

    def get_binary(self):
        if not self.is_valid():
            return ''
        return '.'.join(f"{int(o):08b}" for o in self.get_octets())