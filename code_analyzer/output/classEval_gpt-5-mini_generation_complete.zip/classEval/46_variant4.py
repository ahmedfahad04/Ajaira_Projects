class Interpolation:
    """
    This is a class that implements the Linear interpolation operation of one-dimensional and two-dimensional data
    """

    def __init__(self):
        pass

    @staticmethod
    def interpolate_1d(x, y, x_interp):
        if len(x) != len(y):
            raise ValueError("x and y must have same length")
        n = len(x)
        if n == 0:
            return []
        out = []
        for xp in x_interp:
            if n == 1:
                out.append(float(y[0]))
                continue
            # find interval by scanning from left to right but break early
            idx = 0
            while idx + 1 < n and xp > x[idx+1]:
                idx += 1
            if xp <= x[0]:
                x0, x1 = x[0], x[1]
                y0, y1 = y[0], y[1]
            elif xp >= x[-1]:
                x0, x1 = x[-2], x[-1]
                y0, y1 = y[-2], y[-1]
            else:
                x0, x1 = x[idx], x[idx+1]
                y0, y1 = y[idx], y[idx+1]
            if x1 == x0:
                out.append(float(y0))
            else:
                t = (xp - x0) / (x1 - x0)
                out.append(float(y0 + t * (y1 - y0)))
        return out

    @staticmethod
    def interpolate_2d(x, y, z, x_interp, y_interp):
        if len(x) == 0 or len(y) == 0:
            return []
        if len(z) != len(x) or any(len(row) != len(y) for row in z):
            raise ValueError("z must be of shape (len(x), len(y))")
        out = []
        for xp, yp in zip(x_interp, y_interp):
            if len(x) == 1 and len(y) == 1:
                out.append(float(z[0][0]))
                continue
            # interpolate in x direction for each y to get row at xp
            row_at_xp = []
            for j in range(len(y)):
                col_vals = [z[i][j] for i in range(len(x))]
                row_at_xp.append(Interpolation.interpolate_1d(x, col_vals, [xp])[0])
            # now interpolate that row along y
            val = Interpolation.interpolate_1d(y, row_at_xp, [yp])[0]
            out.append(float(val))
        return out