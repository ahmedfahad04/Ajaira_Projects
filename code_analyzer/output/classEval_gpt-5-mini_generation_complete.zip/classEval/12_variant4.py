import random

class BlackjackGame:
    """
    This is a class representing a game of blackjack, which includes creating a deck, calculating the value of a hand, and determine the winner based on the hand values of the player and dealer.
    """

    def __init__(self):
        self.deck = self.create_deck()
        self.player_hand = []
        self.dealer_hand = []

    def create_deck(self):
        ranks = ['A'] + [str(n) for n in range(2, 11)] + ['J', 'Q', 'K']
        suits = ['S', 'H', 'D', 'C']
        deck = []
        for r in ranks:
            for s in suits:
                deck.append(f"{r}{s}")
        # Fisher-Yates shuffle
        for i in range(len(deck)-1, 0, -1):
            j = random.randint(0, i)
            deck[i], deck[j] = deck[j], deck[i]
        return deck

    def calculate_hand_value(self, hand):
        total = 0
        aces = 0
        for card in hand:
            rank = card[:-1]
            if rank == 'A':
                aces += 1
                total += 11
            elif rank in ('J', 'Q', 'K'):
                total += 10
            else:
                total += int(rank)
        # convert some aces to value 1 as needed
        while total > 21 and aces > 0:
            total -= 10
            aces -= 1
        return total

    def check_winner(self, player_hand, dealer_hand):
        pv = self.calculate_hand_value(player_hand)
        dv = self.calculate_hand_value(dealer_hand)
        # If both <=21, closer to 21 wins (tie -> Dealer)
        if pv <= 21 and dv <= 21:
            if pv == dv:
                return 'Dealer wins'
            return 'Player wins' if pv > dv else 'Dealer wins'
        # Otherwise lower numeric value wins
        if pv == dv:
            return 'Dealer wins'
        return 'Player wins' if pv < dv else 'Dealer wins'