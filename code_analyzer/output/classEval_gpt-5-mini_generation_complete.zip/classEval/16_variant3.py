import re

class Calculator:
    """
    This is a class for a calculator, capable of performing basic arithmetic calculations on numerical expressions using the operators +, -, *, /, and ^ (exponentiation).
    """

    def __init__(self):
        """
        Initialize the operations performed by the five operators'+','-','*','/','^'
        """
        self.operators = {
            '+': lambda x, y: x + y,
            '-': lambda x, y: x - y,
            '*': lambda x, y: x * y,
            '/': lambda x, y: x / y,
            '^': lambda x, y: x ** y
        }

    def precedence(self, operator):
        if operator in ('+','-'):
            return 1
        if operator in ('*','/'):
            return 2
        if operator == '^':
            return 3
        return 0

    def apply_operator(self, operand_stack, operator_stack):
        if not operator_stack or len(operand_stack) < 2:
            return operand_stack, operator_stack
        op = operator_stack.pop()
        b = operand_stack.pop()
        a = operand_stack.pop()
        operand_stack.append(self.operators[op](a, b))
        return operand_stack, operator_stack

    def calculate(self, expression):
        # Validate only allowed characters: digits, operators, dot, parentheses, spaces
        if not re.fullmatch(r'[\d\.\+\-\*/\^\(\)\s]+', expression):
            return None
        # Replace ^ with ** for Python eval
        expr = expression.replace('^', '**')
        # Prevent accidental leading zeros like empty expression
        try:
            # Use restricted eval environment
            result = eval(expr, {"__builtins__": None}, {})
            return float(result)
        except Exception:
            return None