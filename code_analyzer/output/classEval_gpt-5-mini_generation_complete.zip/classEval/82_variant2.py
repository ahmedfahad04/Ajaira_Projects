class StockPortfolioTracker:
    """
    Dict-backed implementation for faster lookup. Keeps self.portfolio synced as list of dicts.
    """

    def __init__(self, cash_balance):
        self._holdings = {}  # name -> {"price": float, "quantity": int}
        self.portfolio = []
        self.cash_balance = float(cash_balance)

    def _sync_portfolio(self):
        self.portfolio = [{"name": name, "price": v["price"], "quantity": v["quantity"]} for name, v in self._holdings.items()]

    def add_stock(self, stock):
        name = stock["name"]
        price = float(stock["price"])
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        if name in self._holdings:
            self._holdings[name]["quantity"] += qty
            self._holdings[name]["price"] = price
        else:
            self._holdings[name] = {"price": price, "quantity": qty}
        self._sync_portfolio()
        return True

    def remove_stock(self, stock):
        name = stock["name"]
        price = float(stock["price"])
        qty = int(stock["quantity"])
        if name in self._holdings and self._holdings[name]["price"] == price and self._holdings[name]["quantity"] == qty:
            del self._holdings[name]
            self._sync_portfolio()
            return True
        return False

    def buy_stock(self, stock):
        name = stock["name"]
        price = float(stock["price"])
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        cost = price * qty
        if self.cash_balance < cost:
            return False
        self.cash_balance -= cost
        if name in self._holdings:
            self._holdings[name]["quantity"] += qty
            self._holdings[name]["price"] = price
        else:
            self._holdings[name] = {"price": price, "quantity": qty}
        self._sync_portfolio()
        return True

    def sell_stock(self, stock):
        name = stock["name"]
        price = float(stock["price"])
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        if name not in self._holdings:
            return False
        if self._holdings[name]["quantity"] < qty:
            return False
        self._holdings[name]["quantity"] -= qty
        self.cash_balance += price * qty
        if self._holdings[name]["quantity"] == 0:
            del self._holdings[name]
        self._sync_portfolio()
        return True

    def calculate_portfolio_value(self):
        holdings_value = sum(v["price"] * v["quantity"] for v in self._holdings.values())
        return float(self.cash_balance + holdings_value)

    def get_portfolio_summary(self):
        items = [{"name": name, "value": float(v["price"] * v["quantity"])} for name, v in self._holdings.items()]
        return (self.calculate_portfolio_value(), items)

    def get_stock_value(self, stock):
        return float(float(stock["price"]) * int(stock["quantity"]))