class TicTacToe:
    """
    The class represents a game of Tic-Tac-Toe and its functions include making a move on the board, checking for a winner, and determining if the board is full.
    """

    def __init__(self, N=3):
        """
        Initialize an NxN game board with all empty spaces and current symble player, default is 'X'.
        """
        self.N = N
        self.board = [[' ' for _ in range(N)] for _ in range(N)]
        self.current_player = 'X'

    def make_move(self, row, col):
        """
        Place the current player's mark at the specified position on the board and switch the mark.
        :param row: int, the row index of the position (0-based)
        :param col: int, the column index of the position (0-based)
        :return: bool, indicating whether the move was successful or not
        """
        if not (0 <= row < self.N and 0 <= col < self.N):
            return False
        if self.board[row][col] != ' ':
            return False
        self.board[row][col] = self.current_player
        self.current_player = {'X': 'O', 'O': 'X'}[self.current_player]
        return True

    def check_winner(self):
        """
        Check if there is a winner on the board in rows, columns and diagonals.
        :return: str or None, the mark of the winner ('X' or 'O'), or None if there is no winner yet
        """
        # Check rows
        for r in range(self.N):
            s = set(self.board[r])
            if len(s) == 1 and ' ' not in s:
                return next(iter(s))
        # Check columns
        for c in range(self.N):
            colset = {self.board[r][c] for r in range(self.N)}
            if len(colset) == 1 and ' ' not in colset:
                return next(iter(colset))
        # Check diagonals
        diag1 = {self.board[i][i] for i in range(self.N)}
        if len(diag1) == 1 and ' ' not in diag1:
            return next(iter(diag1))
        diag2 = {self.board[i][self.N - 1 - i] for i in range(self.N)}
        if len(diag2) == 1 and ' ' not in diag2:
            return next(iter(diag2))
        return None

    def is_board_full(self):
        """
        Check if the game board is completely filled.
        :return: bool, indicating whether the game board is full or not
        """
        return all(cell != ' ' for row in self.board for cell in row)