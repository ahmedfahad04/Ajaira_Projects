from collections import Counter

class Hotel:
    """
    This is a class as hotel management system, managing the booking, check-in, check-out, and availability of rooms in a hotel with different room types.
    """

    def __init__(self, name, rooms):
        self.name = name
        # use Counter to simplify arithmetic
        self.available_rooms = Counter(rooms)
        # booked_rooms: room_type -> Counter(name -> count)
        self.booked_rooms = {}

    def book_room(self, room_type, room_number, name):
        if room_number <= 0:
            return False
        if self.available_rooms.get(room_type, 0) == 0:
            return False
        avail = self.available_rooms.get(room_type, 0)
        if room_type not in self.available_rooms:
            return False
        if room_number > avail:
            return avail if avail != 0 else False
        # success
        self.available_rooms[room_type] -= room_number
        if room_type not in self.booked_rooms:
            self.booked_rooms[room_type] = Counter()
        self.booked_rooms[room_type][name] += room_number
        return 'Success!'

    def check_in(self, room_type, room_number, name):
        if room_type not in self.booked_rooms:
            return False
        counter = self.booked_rooms[room_type]
        if name not in counter:
            return False
        booked = counter[name]
        if room_number <= 0 or room_number > booked:
            return False
        if room_number == booked:
            del counter[name]
            # ensure an empty mapping remains
            self.booked_rooms[room_type] = {}
        else:
            counter[name] -= room_number

    def check_out(self, room_type, room_number):
        if room_number <= 0:
            return
        self.available_rooms[room_type] = self.available_rooms.get(room_type, 0) + room_number

    def get_available_rooms(self, room_type):
        return int(self.available_rooms.get(room_type, 0))