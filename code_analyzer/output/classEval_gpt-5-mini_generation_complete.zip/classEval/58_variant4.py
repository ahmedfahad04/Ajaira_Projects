import random

class MinesweeperGame:
    """
    This is a class that implements mine sweeping games including minesweeping and winning judgment.
    """

    def __init__(self, n, k) -> None:
        self.n = n
        self.k = k
        self.minesweeper_map = self.generate_mine_sweeper_map()
        self.player_map = self.generate_playerMap()
        self.score = 0

    def generate_mine_sweeper_map(self):
        n, k = self.n, self.k
        grid = [[0 for _ in range(n)] for _ in range(n)]
        # place mines deterministically by random rows and columns zipped
        positions = [(i, j) for i in range(n) for j in range(n)]
        random.shuffle(positions)
        mines = set(positions[:min(k, n * n)])
        for i, j in mines:
            grid[i][j] = 'X'
        # increment neighbors
        for i in range(n):
            for j in range(n):
                if grid[i][j] == 'X':
                    continue
                s = 0
                for a in (i-1, i, i+1):
                    for b in (j-1, j, j+1):
                        if a == i and b == j:
                            continue
                        if 0 <= a < n and 0 <= b < n and grid[a][b] == 'X':
                            s += 1
                grid[i][j] = s
        return grid

    def generate_playerMap(self):
        return [['-' for _ in range(self.n)] for _ in range(self.n)]

    def check_won(self, map):
        # Won if every non-mine cell is revealed
        for i in range(self.n):
            for j in range(self.n):
                if self.minesweeper_map[i][j] != 'X' and map[i][j] == '-':
                    return False
        return True

    def sweep(self, x, y):
        if not (0 <= x < self.n and 0 <= y < self.n):
            return self.player_map
        if self.player_map[x][y] != '-':
            return self.player_map
        if self.minesweeper_map[x][y] == 'X':
            self.player_map[x][y] = 'X'
            return False
        # Reveal using queue list
        q = [(x, y)]
        seen = set()
        newly = 0
        while q:
            i, j = q.pop(0)
            if (i, j) in seen:
                continue
            seen.add((i, j))
            if not (0 <= i < self.n and 0 <= j < self.n):
                continue
            if self.player_map[i][j] != '-':
                continue
            self.player_map[i][j] = self.minesweeper_map[i][j]
            newly += 1
            if self.minesweeper_map[i][j] == 0:
                for di in (-1, 0, 1):
                    for dj in (-1, 0, 1):
                        ni, nj = i + di, j + dj
                        if 0 <= ni < self.n and 0 <= nj < self.n and (ni, nj) not in seen:
                            q.append((ni, nj))
        self.score += newly
        if self.check_won(self.player_map):
            return True
        return self.player_map

# Classification response:
# variable renaming;list comprehension;set conversion;tuple unpacking;standard library helper;brute force;queue-based;accumulator set;guard clause;input validation;behavior change