import itertools

class PageUtil:
    """
    PageUtil class is a versatile utility for handling pagination and search functionalities in an efficient and convenient manner.
    """

    def __init__(self, data, page_size):
        self.data = list(data)
        self.page_size = int(page_size) if page_size and int(page_size) > 0 else 1
        self.total_items = len(self.data)
        self.total_pages = (self.total_items + self.page_size - 1) // self.page_size

    def _page_indices(self, page_number):
        try:
            page_number = int(page_number)
        except Exception:
            return None
        if page_number == 0:
            page_number = self.total_pages
        # allow negative indexing: -1 last page
        if page_number < 0:
            page_number = self.total_pages + page_number + 1
        if page_number < 1 or page_number > self.total_pages:
            return None
        start = (page_number - 1) * self.page_size
        end = start + self.page_size
        return start, end, page_number

    def get_page(self, page_number):
        idx = self._page_indices(page_number)
        if idx is None:
            return []
        start, end, _ = idx
        # use itertools.islice to fetch slice without copying whole list (though list backing exists)
        return list(itertools.islice(self.data, start, end))

    def get_page_info(self, page_number):
        idx = self._page_indices(page_number)
        if idx is None:
            if self.total_pages == 0:
                return {"current_page": 1, "per_page": self.page_size, "total_pages": 0,
                        "total_items": self.total_items, "has_previous": False,
                        "has_next": False, "data": []}
            # out of range -> clamp
            page_number = 1
            idx = self._page_indices(page_number)
        start, end, page_number = idx
        data = list(itertools.islice(self.data, start, end))
        return {
            "current_page": page_number,
            "per_page": self.page_size,
            "total_pages": self.total_pages,
            "total_items": self.total_items,
            "has_previous": page_number > 1,
            "has_next": page_number < self.total_pages,
            "data": data
        }

    def search(self, keyword):
        if keyword is None:
            keyword = ""
        s = str(keyword).lower()
        results = [item for item in self.data if s in str(item).lower()]
        total_results = len(results)
        total_pages = (total_results + self.page_size - 1) // self.page_size if total_results else 0
        return {"keyword": str(keyword), "total_results": total_results, "total_pages": total_pages, "results": results}

# Classification response:
# helper function extraction;tuple unpacking;itertools usage;list conversion;type conversion;default value handling;input validation;try-except wrapper;guard clause;empty input handling;list comprehension;behavior change