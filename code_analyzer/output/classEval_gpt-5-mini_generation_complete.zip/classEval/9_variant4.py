class BigNumCalculator:
    """
    This is a class that implements big number calculations, including adding, subtracting and multiplying.
    """

    @staticmethod
    def _norm(s):
        if not s:
            return "0"
        s = s.strip()
        sign = ""
        if s[0] == '+' :
            s = s[1:]
        if s[0] == '-':
            sign = "-"
            s = s[1:]
        s = s.lstrip("0")
        if s == "":
            return "0"
        return (sign + s) if sign == "-" else s

    @staticmethod
    def _add_positive(a, b):
        if len(a) < len(b):
            a, b = b, a
        a = a[::-1]
        b = b[::-1]
        carry = 0
        res = []
        for i in range(len(a)):
            da = ord(a[i]) - 48
            db = ord(b[i]) - 48 if i < len(b) else 0
            s = da + db + carry
            res.append(chr(48 + s % 10))
            carry = s // 10
        if carry:
            res.append(chr(48 + carry))
        return "".join(res[::-1])

    @staticmethod
    def _cmp_positive(a, b):
        if len(a) != len(b):
            return 1 if len(a) > len(b) else -1
        if a == b:
            return 0
        return 1 if a > b else -1

    @staticmethod
    def _sub_positive(a, b):
        a = a[::-1]
        b = b[::-1]
        carry = 0
        res = []
        for i in range(len(a)):
            da = ord(a[i]) - 48
            db = ord(b[i]) - 48 if i < len(b) else 0
            d = da - db - carry
            if d < 0:
                d += 10
                carry = 1
            else:
                carry = 0
            res.append(chr(48 + d))
        while len(res) > 1 and res[-1] == '0':
            res.pop()
        return "".join(res[::-1])

    @staticmethod
    def add(num1, num2):
        n1 = BigNumCalculator._norm(num1)
        n2 = BigNumCalculator._norm(num2)
        if n1 == "0":
            return n2
        if n2 == "0":
            return n1
        s1 = "-" if n1[0] == "-" else "+"
        s2 = "-" if n2[0] == "-" else "+"
        if s1 == "-":
            n1 = n1[1:]
        if s2 == "-":
            n2 = n2[1:]
        if s1 == s2:
            res = BigNumCalculator._add_positive(n1, n2)
            return ("-" + res) if s1 == "-" else res
        cmp = BigNumCalculator._cmp_positive(n1, n2)
        if cmp == 0:
            return "0"
        if cmp > 0:
            res = BigNumCalculator._sub_positive(n1, n2)
            return ("-" + res) if s1 == "-" else res
        else:
            res = BigNumCalculator._sub_positive(n2, n1)
            return ("-" + res) if s2 == "-" else res

    @staticmethod
    def subtract(num1, num2):
        if num2.startswith("-"):
            n2 = num2[1:]
        else:
            n2 = "-" + num2
        return BigNumCalculator.add(num1, n2)

    @staticmethod
    def _karatsuba(x, y):
        x = x.lstrip('0')
        y = y.lstrip('0')
        if x == "":
            x = "0"
        if y == "":
            y = "0"
        if len(x) < 10 or len(y) < 10:
            return str(int(x) * int(y))
        n = max(len(x), len(y))
        m = n // 2
        x_high = x[:-m] if len(x) > m else "0"
        x_low = x[-m:]
        y_high = y[:-m] if len(y) > m else "0"
        y_low = y[-m:]
        z0 = BigNumCalculator._karatsuba(x_low, y_low)
        z2 = BigNumCalculator._karatsuba(x_high, y_high)
        sum_x = str(int(x_high) + int(x_low))
        sum_y = str(int(y_high) + int(y_low))
        z1 = BigNumCalculator._karatsuba(sum_x, sum_y)
        z1 = str(int(z1) - int(z2) - int(z0))
        res = int(z2) * (10 ** (2 * m)) + int(z1) * (10 ** m) + int(z0)
        return str(res)

    @staticmethod
    def multiply(num1, num2):
        n1 = BigNumCalculator._norm(num1)
        n2 = BigNumCalculator._norm(num2)
        sign = 1
        if n1.startswith("-"):
            sign = -sign
            n1 = n1[1:]
        if n2.startswith("-"):
            sign = -sign
            n2 = n2[1:]
        if n1 == "0" or n2 == "0":
            return "0"
        res = BigNumCalculator._karatsuba(n1, n2)
        return ("-" + res) if sign < 0 else res