import re

class AutomaticGuitarSimulator:
    def __init__(self, text) -> None:
        self.play_text = text or ""

    def interpret(self, display=False):
        text = self.play_text or ""
        if text.strip() == "":
            return []
        pattern = re.compile(r'([^\d\s]+?)(\d+)')
        result = []
        for m in pattern.finditer(text):
            chord = m.group(1)
            tune = m.group(2)
            # sanitize chord to remove accidental trailing punctuation
            chord = re.sub(r'[^A-Za-z#bMm7]', '', chord)
            entry = {"Chord": chord, "Tune": tune}
            result.append(entry)
            if display:
                self.display(chord, tune)
        return result

    def display(self, key, value):
        out = f"Normal Guitar Playing -- Chord: {key}, Play Tune: {value}"
        print(out)
        return out