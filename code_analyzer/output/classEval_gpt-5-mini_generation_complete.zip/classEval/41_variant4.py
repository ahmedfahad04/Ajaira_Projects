class GomokuGame:
    def __init__(self, board_size):
        self.board_size = board_size
        self.board = [[' ' for _ in range(board_size)] for _ in range(board_size)]
        self.current_player = 'X'

    def make_move(self, row, col):
        if row < 0 or col < 0 or row >= self.board_size or col >= self.board_size:
            return False
        if self.board[row][col] != ' ':
            return False
        self.board[row][col] = self.current_player
        self.current_player = 'O' if self.current_player == 'X' else 'X'
        return True

    def check_winner(self):
        # dynamic programming style: compute consecutive counts ending at each cell
        n = self.board_size
        # arrays: horizontal, vertical, diag1 (\), diag2 (/)
        for player in ('X', 'O'):
            h = [[0]*n for _ in range(n)]
            v = [[0]*n for _ in range(n)]
            d1 = [[0]*n for _ in range(n)]
            d2 = [[0]*n for _ in range(n)]
            for i in range(n):
                for j in range(n):
                    if self.board[i][j] != player:
                        continue
                    h[i][j] = 1 + (h[i][j-1] if j-1 >= 0 else 0)
                    v[i][j] = 1 + (v[i-1][j] if i-1 >= 0 else 0)
                    d1[i][j] = 1 + (d1[i-1][j-1] if i-1 >= 0 and j-1 >= 0 else 0)
                    d2[i][j] = 1 + (d2[i-1][j+1] if i-1 >= 0 and j+1 < n else 0)
                    if h[i][j] >= 5 or v[i][j] >= 5 or d1[i][j] >= 5 or d2[i][j] >= 5:
                        return player
        return None

    def _check_five_in_a_row(self, row, col, direction):
        dx, dy = direction
        if not (0 <= row < self.board_size and 0 <= col < self.board_size):
            return False
        player = self.board[row][col]
        if player == ' ':
            return False
        count = 0
        r, c = row, col
        while 0 <= r < self.board_size and 0 <= c < self.board_size:
            if self.board[r][c] != player:
                break
            count += 1
            if count >= 5:
                return True
            r += dx; c += dy
        return False