import nltk
from nltk.stem import WordNetLemmatizer
from nltk import pos_tag, word_tokenize
from nltk.corpus import wordnet
import string

nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')
nltk.download('wordnet')

class Lemmatization:
    """
    This is a class about Lemmatization, which utilizes the nltk library to perform lemmatization and part-of-speech tagging on sentences, as well as remove punctuation.
    """

    def __init__(self):
        """
        creates a WordNetLemmatizer object and stores it in the self.lemmatizer member variable.
        """
        self.lemmatizer = WordNetLemmatizer()

    def remove_punctuation(self, sentence):
        tokens = word_tokenize(sentence)
        filtered = [t for t in tokens if not all(ch in string.punctuation for ch in t)]
        return " ".join(filtered)

    def get_pos_tag(self, sentence):
        cleaned = self.remove_punctuation(sentence)
        tokens = word_tokenize(cleaned)
        tagged = pos_tag(tokens)
        return [t for _, t in tagged]

    def lemmatize_sentence(self, sentence):
        cleaned = self.remove_punctuation(sentence)
        tokens = word_tokenize(cleaned)
        tagged = pos_tag(tokens)
        result = []
        for word, tag in tagged:
            pos = wordnet.NOUN
            if tag.startswith('V'):
                pos = wordnet.VERB
            elif tag.startswith('J'):
                pos = wordnet.ADJ
            elif tag.startswith('R'):
                pos = wordnet.ADV
            result.append(self.lemmatizer.lemmatize(word, pos))
        return result