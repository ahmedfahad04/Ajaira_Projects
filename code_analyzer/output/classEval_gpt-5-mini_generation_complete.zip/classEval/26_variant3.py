import csv
from io import StringIO

class CSVProcessor:
    """
    This is a class for processing CSV files, including readring and writing CSV data, as well as processing specific operations and saving as a new CSV file.
    """

    def __init__(self):
        pass

    def read_csv(self, file_name):
        try:
            with open(file_name, 'r', encoding='utf-8', newline='') as f:
                data = f.read()
            if data == '':
                return [], []
            sio = StringIO(data)
            reader = csv.reader(sio)
            rows = list(reader)
            if not rows:
                return [], []
            return rows[0], rows[1:]
        except Exception:
            return [], []

    def write_csv(self, data, file_name):
        try:
            with open(file_name, 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)
                for row in data:
                    writer.writerow(row)
            return 1
        except Exception:
            return 0

    def process_csv_data(self, N, save_file_name):
        try:
            title, data = self.read_csv(save_file_name)
            if title == [] and data == []:
                return 0
            new_data = []
            for r in data:
                val = ''
                if 0 <= N < len(r):
                    val = r[N].upper()
                new_data.append([val])
            # build processed filename
            if '.' in save_file_name:
                parts = save_file_name.rsplit('.', 1)
                out = parts[0] + '_process.' + parts[1]
            else:
                out = save_file_name + '_process'
            full = [title] + new_data
            return self.write_csv(full, out)
        except Exception:
            return 0