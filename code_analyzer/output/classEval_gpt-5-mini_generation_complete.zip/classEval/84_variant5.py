import json

class TextFileProcessor:
    """
    The class handles reading, writing, and processing text files. It can read the file as JSON, read the raw text, write content to the file, and process the file by removing non-alphabetic characters.
    """

    def __init__(self, file_path):
        self.file_path = file_path

    def read_file_as_json(self):
        with open(self.file_path, 'rb') as f:
            raw = f.read()
        text = raw.decode('utf-8')
        return json.loads(text)

    def read_file(self):
        with open(self.file_path, 'rb') as f:
            raw = f.read()
        return raw.decode('utf-8', errors='replace')

    def write_file(self, content):
        if isinstance(content, bytes):
            data = content
            mode = 'wb'
        else:
            if not isinstance(content, str):
                try:
                    data = json.dumps(content)
                except Exception:
                    data = str(content)
            else:
                data = content
            mode = 'w'
        if mode == 'wb':
            with open(self.file_path, mode) as f:
                f.write(data)
        else:
            with open(self.file_path, mode, encoding='utf-8') as f:
                f.write(data)

    def process_file(self):
        text = self.read_file()
        res_chars = []
        for c in text:
            if c.isalpha():
                res_chars.append(c)
        result = ''.join(res_chars)
        with open(self.file_path, 'w', encoding='utf-8') as f:
            f.write(result)
        return result