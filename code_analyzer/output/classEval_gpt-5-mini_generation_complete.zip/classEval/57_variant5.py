import numpy as np


class MetricsCalculator2:
    """
    The class provides to calculate Mean Reciprocal Rank (MRR) and Mean Average Precision (MAP) based on input data, where MRR measures the ranking quality and MAP measures the average precision.
    """

    def __init__(self):
        pass

    @staticmethod
    def _as_list_of_pairs(data):
        if isinstance(data, list):
            # already list - assume list of pairs
            return data
        return [data]

    @staticmethod
    def mrr(data):
        pairs = MetricsCalculator2._as_list_of_pairs(data)
        rr_scores = []
        for p in pairs:
            try:
                labels = list(p[0])
            except Exception:
                rr_scores.append(0.0)
                continue
            rr = 0.0
            for i, x in enumerate(labels):
                if int(x) == 1:
                    rr = 1.0 / (i + 1)
                    break
            rr_scores.append(rr)
        mean_rr = float(np.mean(rr_scores)) if rr_scores else 0.0
        return mean_rr, rr_scores

    @staticmethod
    def map(data):
        pairs = MetricsCalculator2._as_list_of_pairs(data)
        ap_scores = []
        for p in pairs:
            try:
                labels = list(p[0])
                gt = p[1]
            except Exception:
                ap_scores.append(0.0)
                continue
            gt = float(gt) if gt is not None else 0.0
            if gt == 0:
                ap_scores.append(0.0)
                continue
            running_hits = 0
            sum_prec = 0.0
            for idx, val in enumerate(labels, 1):
                if int(val) == 1:
                    running_hits += 1
                    sum_prec += running_hits / float(idx)
            ap_scores.append(sum_prec / gt)
        mean_ap = float(np.mean(ap_scores)) if ap_scores else 0.0
        return mean_ap, ap_scores

# Classification response:
# helper function extraction; flattened conditional; try-except wrapper; error suppression; default value handling; enumerate loop; loop rewrite; accumulator list; variable renaming; list conversion; type conversion; guard clause