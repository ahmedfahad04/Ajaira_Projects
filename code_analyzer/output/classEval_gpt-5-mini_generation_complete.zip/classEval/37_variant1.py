class EncryptionUtils:
    """
    This is a class that provides methods for encryption, including the Caesar cipher, Vigenere cipher, and Rail Fence cipher.
    """

    def __init__(self, key):
        """
        Initializes the class with a key.
        :param key: The key to use for encryption, str.
        """
        self.key = key

    def caesar_cipher(self, plaintext, shift):
        """
        Encrypts the plaintext using the Caesar cipher.
        """
        if shift is None:
            return plaintext
        shift = shift % 26
        res = []
        for ch in plaintext:
            o = ord(ch)
            if 65 <= o <= 90:
                res.append(chr((o - 65 + shift) % 26 + 65))
            elif 97 <= o <= 122:
                res.append(chr((o - 97 + shift) % 26 + 97))
            else:
                res.append(ch)
        return ''.join(res)

    def vigenere_cipher(self, plaintext):
        """
        Encrypts the plaintext using the Vigenere cipher.
        """
        key_letters = [c for c in self.key if c.isalpha()]
        if not key_letters:
            return plaintext
        # prepare numeric shifts
        shifts = [(ord(c.lower()) - 97) % 26 for c in key_letters]
        res = []
        k = 0
        for ch in plaintext:
            if ch.isalpha():
                shift = shifts[k % len(shifts)]
                o = ord(ch)
                if 'A' <= ch <= 'Z':
                    res.append(chr((o - 65 + shift) % 26 + 65))
                else:
                    res.append(chr((o - 97 + shift) % 26 + 97))
                k += 1
            else:
                res.append(ch)
        return ''.join(res)

    def rail_fence_cipher(self,plain_text, rails):
        """
        Encrypts the plaintext using the Rail Fence cipher.
        """
        if rails is None or rails <= 1 or rails >= len(plain_text):
            return plain_text
        fence = ['' for _ in range(rails)]
        rail = 0
        step = 1
        for ch in plain_text:
            fence[rail] += ch
            rail += step
            if rail == 0:
                step = 1
            elif rail == rails - 1:
                step = -1
        return ''.join(fence)