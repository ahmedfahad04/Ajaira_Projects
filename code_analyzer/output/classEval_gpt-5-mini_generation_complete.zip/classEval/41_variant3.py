class GomokuGame:
    def __init__(self, board_size):
        self.board_size = board_size
        self.board = [[' ' for _ in range(board_size)] for _ in range(board_size)]
        self.current_player = 'X'

    def make_move(self, row, col):
        if not (0 <= row < self.board_size and 0 <= col < self.board_size):
            return False
        if self.board[row][col] != ' ':
            return False
        self.board[row][col] = self.current_player
        self.current_player = 'O' if self.current_player == 'X' else 'X'
        return True

    def check_winner(self):
        target_x = 'XXXXX'
        target_o = 'OOOOO'
        # check rows
        for r in range(self.board_size):
            s = ''.join(self.board[r])
            if target_x in s:
                return 'X'
            if target_o in s:
                return 'O'
        # check cols
        for c in range(self.board_size):
            s = ''.join(self.board[r][c] for r in range(self.board_size))
            if target_x in s:
                return 'X'
            if target_o in s:
                return 'O'
        # check diagonals (top-left to bottom-right)
        for start in range(-self.board_size + 1, self.board_size):
            diag = []
            for r in range(self.board_size):
                c = r - start
                if 0 <= c < self.board_size:
                    diag.append(self.board[r][c])
            s = ''.join(diag)
            if target_x in s:
                return 'X'
            if target_o in s:
                return 'O'
        # check anti-diagonals (top-right to bottom-left)
        for start in range(0, 2 * self.board_size - 1):
            diag = []
            for r in range(self.board_size):
                c = start - r
                if 0 <= c < self.board_size:
                    diag.append(self.board[r][c])
            s = ''.join(diag)
            if target_x in s:
                return 'X'
            if target_o in s:
                return 'O'
        return None

    def _check_five_in_a_row(self, row, col, direction):
        dx, dy = direction
        if not (0 <= row < self.board_size and 0 <= col < self.board_size):
            return False
        player = self.board[row][col]
        if player == ' ':
            return False
        r, c = row, col
        cnt = 0
        while 0 <= r < self.board_size and 0 <= c < self.board_size and self.board[r][c] == player:
            cnt += 1
            if cnt >= 5:
                return True
            r += dx; c += dy
        return False