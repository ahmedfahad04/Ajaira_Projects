class BalancedBrackets:
    """
    This is a class that checks for bracket matching
    """

    def __init__(self, expr):
        """
        Initializes the class with an expression.
        :param expr: The expression to check for balanced brackets,str.
        """
        self.stack = []
        self.left_brackets = ["(", "{", "["]
        self.right_brackets = [")", "}", "]"]
        self.expr = expr

    def clear_expr(self):
        """
        Clears the expression of all characters that are not brackets.
        """
        allowed = set(self.left_brackets + self.right_brackets)
        self.expr = ''.join(ch for ch in (self.expr or "") if ch in allowed)

    def check_balanced_brackets(self):
        """
        Checks if the expression has balanced brackets.
        :return: True if the expression has balanced brackets, False otherwise.
        """
        self.clear_expr()
        self.stack = []
        match = {")": "(", "}": "{", "]": "["}
        for ch in self.expr:
            if ch in self.left_brackets:
                self.stack.append(ch)
            elif ch in self.right_brackets:
                if not self.stack:
                    return False
                top = self.stack.pop()
                if match[ch] != top:
                    return False
        return not self.stack