class ChandrasekharSieve:
    """
    This is a class that uses the Chandrasekhar's Sieve method to find all prime numbers within the range
    """

    def __init__(self, n):
        self.n = int(n)
        self.primes = self.generate_primes()

    def generate_primes(self):
        n = self.n
        if n < 2:
            return []
        is_composite = [False] * (n + 1)
        primes = []
        for i in range(2, n + 1):
            if not is_composite[i]:
                primes.append(i)
            for p in primes:
                mult = i * p
                if mult > n:
                    break
                is_composite[mult] = True
                if i % p == 0:
                    break
        return primes

    def get_primes(self):
        return list(self.primes)