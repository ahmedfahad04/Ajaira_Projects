class HRManagementSystem:
    """
    This is a class as personnel management system that implements functions such as adding, deleting, querying, and updating employees
    """

    def __init__(self):
        """
        Initialize the HRManagementSystem withan attribute employees, which is an empty dictionary.
        """
        self.employees = {}

    def add_employee(self, employee_id, name, position, department, salary):
        """
        Add a new employee to the HRManagementSystem.
        """
        if employee_id in self.employees:
            return False
        self.employees[employee_id] = {
            'name': name,
            'position': position,
            'department': department,
            'salary': salary
        }
        return True

    def remove_employee(self, employee_id):
        """
        Remove an employee from the HRManagementSystem.
        """
        if employee_id in self.employees:
            del self.employees[employee_id]
            return True
        return False

    def update_employee(self, employee_id: int, employee_info: dict):
        """
        Update an employee's information in the HRManagementSystem.
        """
        if employee_id not in self.employees:
            return False
        # update allowed fields only
        for key in ('name', 'position', 'department', 'salary'):
            if key in employee_info:
                self.employees[employee_id][key] = employee_info[key]
        return True

    def get_employee(self, employee_id):
        """
        Get an employee's information from the HRManagementSystem.
        """
        if employee_id not in self.employees:
            return False
        # return a shallow copy to avoid external modification
        return dict(self.employees[employee_id])

    def list_employees(self):
        """
        List all employees' information in the HRManagementSystem.
        """
        result = {}
        for eid, info in self.employees.items():
            out = {'employee_ID': eid}
            out.update(info)
            result[eid] = out
        return result