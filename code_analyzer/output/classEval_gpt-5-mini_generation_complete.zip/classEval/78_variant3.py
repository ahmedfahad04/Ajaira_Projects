import re

class SplitSentence:
    """
    The class allows to split sentences, count words in a sentence, and process a text file to find the maximum word count.
    """

    def split_sentences(self, sentences_string):
        s = sentences_string or ""
        # Use lookbehind for common titles to avoid splitting at those dots
        # negative lookbehinds for each abbreviation (fixed width)
        pattern = r'(?:(?<!Mr)(?<!Mrs)(?<!Dr)(?<!Ms)(?<!Jr)(?<!Sr)(?<!St)([.?])(?=\s|$))'
        # find positions of sentence-ending punctuation
        sentences = []
        last = 0
        for m in re.finditer(pattern, s):
            end = m.end(1)
            # include punctuation at position m.start(1)
            sent = s[last:end].strip()
            if sent:
                sentences.append(sent)
            # advance last past spaces after punctuation
            last = end
            while last < len(s) and s[last].isspace():
                last += 1
        # tail
        if last < len(s):
            tail = s[last:].strip()
            if tail:
                sentences.append(tail)
        return sentences

    def count_words(self, sentence):
        if not sentence:
            return 0
        # Only pure alphabetic words count
        return len(re.findall(r'\b[A-Za-z]+\b', sentence))

    def process_text_file(self, sentences_string):
        maxw = 0
        for sent in self.split_sentences(sentences_string):
            c = self.count_words(sent)
            if c > maxw:
                maxw = c
        return maxw