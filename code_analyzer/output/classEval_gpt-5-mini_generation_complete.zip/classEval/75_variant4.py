from dataclasses import dataclass

@dataclass
class _Item:
    price: float
    quantity: int

class ShoppingCart:
    """
    The class manages items, their prices, quantities, and allows to for add, removie, view items, and calculate the total price.
    """

    def __init__(self):
        """
        Initialize the items representing the shopping list as an empty dictionary
        """
        self.items = {}

    def add_item(self, item, price, quantity=1):
        q = int(quantity)
        if q <= 0:
            return
        p = float(price)
        if item in self.items:
            it = self.items[item]
            # update price to newest
            it.price = p
            it.quantity += q
        else:
            self.items[item] = _Item(price=p, quantity=q)

    def remove_item(self, item, quantity=1):
        if item not in self.items:
            raise KeyError("Item not present")
        q = int(quantity)
        if q <= 0:
            return
        it = self.items[item]
        if q >= it.quantity:
            del self.items[item]
        else:
            it.quantity -= q

    def view_items(self) -> dict:
        return {k: {"price": v.price, "quantity": v.quantity} for k, v in self.items.items()}

    def total_price(self) -> float:
        return sum(v.price * v.quantity for v in self.items.values())