class NumberConverter:
    """
    The class allows to convert  decimal to binary, octal and hexadecimal repectively and contrarily
    """

    @staticmethod
    def decimal_to_binary(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        sign = '-' if decimal_num < 0 else ''
        return sign + format(abs(decimal_num), 'b')

    @staticmethod
    def binary_to_decimal(binary_num):
        if isinstance(binary_num, int):
            binary_num = str(binary_num)
        if not isinstance(binary_num, str):
            raise TypeError("binary_num must be str or int convertible to str")
        s = binary_num.strip()
        if s.startswith('-'):
            return -int(s[1:], 2)
        return int(s, 2)

    @staticmethod
    def decimal_to_octal(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        sign = '-' if decimal_num < 0 else ''
        return sign + format(abs(decimal_num), 'o')

    @staticmethod
    def octal_to_decimal(octal_num):
        if isinstance(octal_num, int):
            octal_num = str(octal_num)
        if not isinstance(octal_num, str):
            raise TypeError("octal_num must be str or int convertible to str")
        s = octal_num.strip()
        if s.startswith('-'):
            return -int(s[1:], 8)
        return int(s, 8)

    @staticmethod
    def decimal_to_hex(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        sign = '-' if decimal_num < 0 else ''
        return sign + format(abs(decimal_num), 'x')

    @staticmethod
    def hex_to_decimal(hex_num):
        if isinstance(hex_num, int):
            hex_num = format(hex_num, 'x')
        if not isinstance(hex_num, str):
            raise TypeError("hex_num must be str or int convertible to str")
        s = hex_num.strip()
        if s.startswith('-'):
            return -int(s[1:], 16)
        return int(s, 16)

# Classification response:
# input validation; type check; guard clause; type conversion; temporary variable; builtin function; boundary case handling; empty input handling