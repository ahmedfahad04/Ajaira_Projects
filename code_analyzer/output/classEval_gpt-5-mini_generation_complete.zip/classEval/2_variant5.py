class ArgumentParser:
    """
    This is a class for parsing command line arguments to a dictionary.
    """

    def __init__(self):
        self.arguments = {}
        self.required = set()
        self.types = {}

    def parse_arguments(self, command_string):
        parts = command_string.split()
        # Collect option tokens in order
        i = 0
        while i < len(parts):
            token = parts[i]
            if token.startswith('-'):
                key = token.lstrip('-')
                if '=' in key:
                    k, v = key.split('=', 1)
                    self.arguments[k] = self._convert_type(k, v)
                    i += 1
                    continue
                # next token as value if it exists and is not an option
                if i + 1 < len(parts) and not parts[i + 1].startswith('-'):
                    self.arguments[key] = self._convert_type(key, parts[i + 1])
                    i += 2
                    continue
                # a switch
                self.arguments[key] = self._convert_type(key, True)
                i += 1
            else:
                i += 1
        missing = set()
        for r in self.required:
            if r not in self.arguments:
                missing.add(r)
        if missing:
            return (False, missing)
        return (True, None)

    def get_argument(self, key):
        return self.arguments.get(key)

    def add_argument(self, arg, required=False, arg_type=str):
        if required:
            self.required.add(arg)
        if isinstance(arg_type, str):
            if arg_type == 'int':
                self.types[arg] = int
            elif arg_type == 'float':
                self.types[arg] = float
            elif arg_type == 'bool':
                self.types[arg] = bool
            else:
                self.types[arg] = str
        else:
            self.types[arg] = arg_type

    def _convert_type(self, arg, value):
        typ = self.types.get(arg)
        if typ is None:
            return value
        if typ is bool:
            if isinstance(value, bool):
                return value
            s = str(value).lower()
            if s in ('true', '1', 'yes', 'y', 'on'):
                return True
            if s in ('false', '0', 'no', 'n', 'off'):
                return False
            return True
        try:
            return typ(value)
        except Exception:
            return value