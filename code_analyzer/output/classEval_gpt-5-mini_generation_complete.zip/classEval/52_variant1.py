import nltk
from nltk.stem import WordNetLemmatizer
from nltk import pos_tag, word_tokenize
from nltk.corpus import wordnet
import string

nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')
nltk.download('wordnet')

class Lemmatization:
    """
    This is a class about Lemmatization, which utilizes the nltk library to perform lemmatization and part-of-speech tagging on sentences, as well as remove punctuation.
    """

    def __init__(self):
        """
        creates a WordNetLemmatizer object and stores it in the self.lemmatizer member variable.
        """
        self.lemmatizer = WordNetLemmatizer()

    def _penn_to_wordnet(self, tag):
        if not tag:
            return wordnet.NOUN
        t = tag[0].upper()
        if t == 'J':
            return wordnet.ADJ
        if t == 'V':
            return wordnet.VERB
        if t == 'N':
            return wordnet.NOUN
        if t == 'R':
            return wordnet.ADV
        return wordnet.NOUN

    def remove_punctuation(self, sentence):
        return sentence.translate(str.maketrans('', '', string.punctuation))

    def get_pos_tag(self, sentence):
        cleaned = self.remove_punctuation(sentence)
        tokens = word_tokenize(cleaned)
        tags = pos_tag(tokens)
        return [t for _, t in tags]

    def lemmatize_sentence(self, sentence):
        cleaned = self.remove_punctuation(sentence)
        tokens = word_tokenize(cleaned)
        tagged = pos_tag(tokens)
        lemmatized = []
        for word, tag in tagged:
            wn_tag = self._penn_to_wordnet(tag)
            lemmatized.append(self.lemmatizer.lemmatize(word, wn_tag))
        return lemmatized