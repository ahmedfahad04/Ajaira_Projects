class Warehouse:
    """
    The class manages inventory and orders, including adding products, updating product quantities, retrieving product quantities, creating orders, changing order statuses, and tracking orders.
    """

    def __init__(self):
        """
        Initialize two fields.
        self.inventory is a dict that stores the products.
        self.inventory = {Product ID: Product}
        self.orders is a dict that stores the products in a order.
        self.orders = {Order ID: Order}
        """
        self.inventory = {}
        self.orders = {}

    def add_product(self, product_id, name, quantity):
        # create or update product; if exists, keep original name unless None passed
        if product_id in self.inventory:
            self.inventory[product_id]['quantity'] += quantity
            if name is not None:
                self.inventory[product_id]['name'] = self.inventory[product_id]['name']
        else:
            self.inventory[product_id] = {'name': name, 'quantity': quantity}
        return True

    def update_product_quantity(self, product_id, quantity):
        if product_id not in self.inventory:
            return False
        self.inventory[product_id]['quantity'] += quantity
        return True

    def get_product_quantity(self, product_id):
        if product_id not in self.inventory:
            return False
        return self.inventory[product_id]['quantity']

    def create_order(self, order_id, product_id, quantity):
        if product_id not in self.inventory:
            return False
        if quantity <= 0:
            return False
        available = self.inventory[product_id]['quantity']
        if available < quantity:
            return False
        # Deduct and create order
        self.inventory[product_id]['quantity'] = available - quantity
        self.orders[order_id] = {'product_id': product_id, 'quantity': quantity, 'status': 'Shipped'}
        return True

    def change_order_status(self, order_id, status):
        if order_id not in self.orders:
            return False
        self.orders[order_id]['status'] = status
        return True

    def track_order(self, order_id):
        order = self.orders.get(order_id)
        if not order:
            return False
        return order['status']