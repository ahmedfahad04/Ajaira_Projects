import csv
import os

class CSVProcessor:
    """
    This is a class for processing CSV files, including readring and writing CSV data, as well as processing specific operations and saving as a new CSV file.
    """

    def __init__(self):
        pass

    def read_csv(self, file_name):
        try:
            with open(file_name, newline='', encoding='utf-8') as f:
                reader = csv.reader(f)
                all_rows = list(reader)
                if not all_rows:
                    return [], []
                title = all_rows[0]
                data = all_rows[1:]
                return title, data
        except Exception:
            return [], []

    def write_csv(self, data, file_name):
        try:
            with open(file_name, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                for row in data:
                    writer.writerow(row)
            return 1
        except Exception:
            return 0

    def _process_filename(self, file_name):
        base, ext = os.path.splitext(file_name)
        if ext == '':
            return base + '_process'
        return base + '_process' + ext

    def process_csv_data(self, N, save_file_name):
        try:
            title, data = self.read_csv(save_file_name)
            if title == [] and data == []:
                # Could be empty file or error
                return 0
            new_rows = []
            for row in data:
                if 0 <= N < len(row):
                    new_rows.append([row[N].upper()])
                else:
                    new_rows.append([''])
            out_name = self._process_filename(save_file_name)
            # write title as original full title, then processed rows
            out_data = [title] + new_rows
            return self.write_csv(out_data, out_name)
        except Exception:
            return 0