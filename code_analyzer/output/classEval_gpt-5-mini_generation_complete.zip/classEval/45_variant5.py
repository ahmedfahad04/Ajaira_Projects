from PIL import Image, ImageEnhance
import io

class ImageProcessor:
    """
    This is a class to process image, including loading, saving, resizing, rotating, and adjusting the brightness of images.
    """

    def __init__(self):
        """
        Initialize self.image
        """
        self.image = None

    def load_image(self, image_path):
        """
        Use Image util in PIL to open a image
        """
        if image_path is None:
            raise ValueError("image_path required")
        # accept bytes, file-like, or path
        if isinstance(image_path, (bytes, bytearray)):
            self.image = Image.open(io.BytesIO(image_path)).copy()
        elif hasattr(image_path, "read"):
            self.image = Image.open(image_path).copy()
        else:
            self.image = Image.open(str(image_path)).copy()
        return self.image

    def save_image(self, save_path):
        """
        Save image to a path if image has opened
        """
        if self.image is None:
            raise RuntimeError("No image loaded")
        # Infer format from extension
        self.image.save(save_path)

    def resize_image(self, width, height):
        """
        Risize the image if image has opened.
        """
        if self.image is None:
            raise RuntimeError("No image loaded")
        if not isinstance(width, int) or not isinstance(height, int):
            raise TypeError("width and height must be integers")
        if width <= 0 or height <= 0:
            raise ValueError("width and height must be > 0")
        # Use thumbnail on a copy to maintain aspect ratio, then paste onto background of desired size
        img_copy = self.image.copy()
        img_copy.thumbnail((width, height), Image.LANCZOS)
        if img_copy.size == (width, height):
            self.image = img_copy
            return self.image
        background = Image.new(self.image.mode, (width, height))
        x = (width - img_copy.width) // 2
        y = (height - img_copy.height) // 2
        background.paste(img_copy, (x, y))
        self.image = background
        return self.image

    def rotate_image(self, degrees):
        """
        rotate image if image has opened
        """
        if self.image is None:
            raise RuntimeError("No image loaded")
        try:
            deg = float(degrees)
        except Exception:
            raise TypeError("degrees must be numeric")
        # rotate in place allowing expand so no cropping
        self.image = self.image.rotate(deg, resample=Image.BICUBIC, expand=True)
        return self.image

    def adjust_brightness(self, factor):
        """
        Adjust the brightness of image if image has opened.
        """
        if self.image is None:
            raise RuntimeError("No image loaded")
        try:
            f = float(factor)
        except Exception:
            raise TypeError("factor must be numeric")
        enhancer = ImageEnhance.Brightness(self.image)
        self.image = enhancer.enhance(f)
        return self.image