import xml.etree.ElementTree as ET
import re


class XMLProcessor:
    """
    XML handler that can remove empty elements during processing and supports flexible find.
    """

    def __init__(self, file_name):
        self.file_name = file_name
        self.root = None

    def read_xml(self):
        tree = ET.parse(self.file_name)
        self.root = tree.getroot()
        return self.root

    def write_xml(self, file_name):
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return False
        try:
            ET.ElementTree(self.root).write(file_name, encoding="utf-8", xml_declaration=True)
            return True
        except Exception:
            return False

    def process_xml_data(self, file_name):
        """
        Remove elements that have no text and no attributes and no children.
        Also trims whitespace from text nodes and replaces multiple spaces with single space.
        """
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return False

        def cleanup(parent):
            # iterate over a static list since we may remove children
            for child in list(parent):
                cleanup(child)
                text = child.text.strip() if child.text else ""
                if (not list(child)) and (not child.attrib) and (text == ""):
                    parent.remove(child)
                else:
                    if child.text:
                        cleaned = re.sub(r"\s+", " ", child.text.strip())
                        child.text = cleaned

        # process root children
        cleanup(self.root)
        # also clean root text
        if self.root.text:
            self.root.text = re.sub(r"\s+", " ", self.root.text.strip())
        return self.write_xml(file_name)

    def find_element(self, element_name):
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return []
        # allow regex-like find: if element_name contains '*' treat as wildcard
        if "*" in element_name:
            pattern = "^" + element_name.replace("*", ".*") + "$"
            regex = re.compile(pattern)
            return [e for e in self.root.iter() if regex.match(e.tag)]
        else:
            return self.root.findall(".//" + element_name)