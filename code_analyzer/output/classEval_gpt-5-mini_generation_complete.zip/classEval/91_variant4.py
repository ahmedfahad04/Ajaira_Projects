import urllib.parse

class UrlPath:
    """
    The  class is a utility for encapsulating and manipulating the path component of a URL, including adding nodes, parsing path strings, and building path strings with optional encoding.
    """

    def __init__(self):
        """
        Initializes the UrlPath object with an empty list of segments and a flag indicating the presence of an end tag.
        """
        self.segments = []
        self.with_end_tag = False

    def add(self, segment):
        """
        Adds a segment to the list of segments in the UrlPath.
        Returns self to allow chaining.
        """
        if segment is None:
            return self
        s = str(segment)
        if s == '':
            self.with_end_tag = True
            return self
        # keep the provided segment as-is (strip accidental slashes)
        s = s.strip('/')
        if s:
            self.segments.append(s)
            self.with_end_tag = False
        return self

    def parse(self, path, charset):
        """
        Parses a given path string and populates the list of segments in the UrlPath.
        This variant uses unquote_plus (turns '+' into space) for decoding.
        """
        self.segments = []
        self.with_end_tag = False
        if path is None:
            return
        # Accept full URLs as input and get their path component
        try:
            p = urllib.parse.urlsplit(path).path or ''
        except Exception:
            p = path or ''
        if p.endswith('/'):
            self.with_end_tag = True
        # remove leading/trailing slashes and split
        p = p.strip('/')
        if not p:
            return
        for part in p.split('/'):
            if part == '':
                continue
            # decode percent encoding; treat plus as space
            try:
                decoded = urllib.parse.unquote_plus(part, encoding=charset, errors='replace')
            except TypeError:
                decoded = urllib.parse.unquote_plus(part)
            self.segments.append(decoded)

    @staticmethod
    def fix_path(path):
        """
        Fixes the given path string by removing leading and trailing slashes.
        """
        if path is None:
            return ''
        try:
            p = urllib.parse.urlsplit(path).path
            if p is None:
                p = path
        except Exception:
            p = path
        # Remove leading and trailing slashes; do not touch internal slashes
        return p.strip('/')