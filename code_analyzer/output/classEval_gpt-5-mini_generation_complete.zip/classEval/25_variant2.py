import json
import os
import tempfile

class CookiesUtil:
    """
    This is a class as utility for managing and manipulating Cookies, including methods for retrieving, saving, and setting Cookies data.
    """

    def __init__(self, cookies_file):
        self.cookies_file = cookies_file
        self.cookies = {}

    def get_cookies(self, reponse):
        if not isinstance(reponse, dict):
            raise TypeError("reponse must be a dict")
        new = reponse.get('cookies', {})
        if not isinstance(new, dict):
            raise TypeError("response['cookies'] must be a dict")
        # merge with existing cookies, new values override old ones
        existing = self.load_cookies() or {}
        merged = existing.copy()
        merged.update(new)
        self.cookies = merged
        self._save_cookies()
        return self.cookies

    def load_cookies(self):
        if not os.path.exists(self.cookies_file):
            self.cookies = {}
            return self.cookies
        try:
            with open(self.cookies_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, dict):
                    self.cookies = data
                else:
                    self.cookies = {}
        except (IOError, json.JSONDecodeError):
            self.cookies = {}
        return self.cookies

    def _save_cookies(self):
        try:
            dirpath = os.path.dirname(os.path.abspath(self.cookies_file)) or '.'
            fd, tmppath = tempfile.mkstemp(dir=dirpath)
            try:
                with os.fdopen(fd, 'w', encoding='utf-8') as tmpf:
                    json.dump(self.cookies if isinstance(self.cookies, dict) else {}, tmpf)
                os.replace(tmppath, self.cookies_file)
            finally:
                if os.path.exists(tmppath):
                    try:
                        os.remove(tmppath)
                    except Exception:
                        pass
            return True
        except Exception:
            return False