import sqlite3
import threading

class UserLoginDB:
    """
    This is a database management class for user login verification, providing functions for inserting user information, searching user information, deleting user information, and validating user login.
    Thread-safe, uses a persistent connection with row_factory and prepared statement reuse.
    """

    def __init__(self, db_name):
        """
        Initializes the UserLoginDB object with the specified database name.
        """
        self.connection = sqlite3.connect(db_name, check_same_thread=False)
        self.connection.row_factory = None
        self.cursor = self.connection.cursor()
        self._lock = threading.RLock()
        self._prepare_stmts()

    def _prepare_stmts(self):
        # Prepare SQL templates (will be used with execute each time)
        self._insert_sql = "INSERT OR IGNORE INTO users (username, password) VALUES (?, ?)"
        self._select_sql = "SELECT id, username, password FROM users WHERE username = ?"
        self._delete_sql = "DELETE FROM users WHERE username = ?"

    def create_table(self):
        with self._lock:
            self.cursor.execute(
                "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT)"
            )
            self.connection.commit()

    def insert_user(self, username, password):
        with self._lock:
            self.cursor.execute(self._insert_sql, (username, password))
            self.connection.commit()

    def search_user_by_username(self, username):
        with self._lock:
            self.cursor.execute(self._select_sql, (username,))
            return self.cursor.fetchall()

    def delete_user_by_username(self, username):
        with self._lock:
            self.cursor.execute(self._delete_sql, (username,))
            self.connection.commit()

    def validate_user_login(self, username, password):
        with self._lock:
            self.cursor.execute("SELECT password FROM users WHERE username = ?", (username,))
            row = self.cursor.fetchone()
            if not row:
                return False
            stored_password = row[0]
            return stored_password == password