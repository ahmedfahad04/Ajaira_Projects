import re
import string
import gensim
from bs4 import BeautifulSoup

class HtmlUtil:
    """
    This is a class as util for html, supporting for formatting and extracting code from HTML text, including cleaning up the text and converting certain elements into specific marks.
    """

    def __init__(self):
        """
        Initialize a series of labels
        """
        self.SPACE_MARK = '-SPACE-'
        self.JSON_MARK = '-JSON-'
        self.MARKUP_LANGUAGE_MARK = '-MARKUP_LANGUAGE-'
        self.URL_MARK = '-URL-'
        self.NUMBER_MARK = '-NUMBER-'
        self.TRACE_MARK = '-TRACE-'
        self.COMMAND_MARK = '-COMMAND-'
        self.COMMENT_MARK = '-COMMENT-'
        self.CODE_MARK = '-CODE-'

    @staticmethod
    def __format_line_feed(text):
        """
        Replace consecutive line breaks with a single line break
        """
        return re.sub(r'\n{2,}', '\n', text)

    def format_line_html_text(self, html_text):
        """
        Alternative: mark code regions, then extract visible text while keeping order.
        """
        soup = BeautifulSoup(html_text, 'html.parser')
        body = soup.body or soup

        # Insert unique sentinel around pre tags to ensure splitting yields markers as lines
        sentinel = '<<<HTML_UTIL_CODE_MARKER>>>'
        for pre in soup.find_all('pre'):
            pre.insert_before(soup.new_string('\n' + sentinel + '\n'))
            pre.insert_after(soup.new_string('\n' + sentinel + '\n'))
            pre.decompose()
        # Also handle code tags not inside pre
        for code in soup.find_all('code'):
            if code.parent.name != 'pre':
                code.insert_before(soup.new_string('\n' + sentinel + '\n'))
                code.insert_after(soup.new_string('\n' + sentinel + '\n'))
                code.decompose()

        text = body.get_text(separator='\n')
        text = self.__format_line_feed(text)
        # Replace sentinel with actual CODE_MARK and clean lines
        text = text.replace(sentinel, self.CODE_MARK)
        lines = [ln.strip() for ln in text.splitlines()]
        cleaned = []
        for ln in lines:
            if ln == self.CODE_MARK:
                cleaned.append(self.CODE_MARK)
            elif ln:
                # collapse multiple spaces into one
                cleaned.append(re.sub(r'\s+', ' ', ln))
        return '\n'.join(cleaned).strip()

    def extract_code_from_html_text(self, html_text):
        """
        Extract inner contents of <pre> tags, preserving indentation and newlines.
        """
        soup = BeautifulSoup(html_text, 'html.parser')
        out = []
        for pre in soup.find_all('pre'):
            code = pre.find('code')
            if code:
                content = code.get_text()
            else:
                content = pre.get_text()
            # keep internal spacing; trim only surrounding blank lines
            content = re.sub(r'^\s*\n', '', content)
            content = re.sub(r'\n\s*$', '', content)
            out.append(content)
        return out