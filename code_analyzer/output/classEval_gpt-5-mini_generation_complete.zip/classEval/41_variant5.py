class GomokuGame:
    def __init__(self, board_size):
        self.board_size = board_size
        self.board = [[' ' for _ in range(board_size)] for _ in range(board_size)]
        self.current_player = 'X'

    def make_move(self, row, col):
        if not (0 <= row < self.board_size and 0 <= col < self.board_size):
            return False
        if self.board[row][col] != ' ':
            return False
        self.board[row][col] = self.current_player
        self.current_player = 'O' if self.current_player == 'X' else 'X'
        return True

    def check_winner(self):
        n = self.board_size
        visited = set()
        directions = [(0,1),(1,0),(1,1),(1,-1)]
        for i in range(n):
            for j in range(n):
                if self.board[i][j] == ' ':
                    continue
                for d in directions:
                    key = (i, j, d)
                    if key in visited:
                        continue
                    # walk backward to the start of this segment to avoid duplicates
                    dx, dy = d
                    x, y = i, j
                    while 0 <= x-dx < n and 0 <= y-dy < n and self.board[x-dx][y-dy] == self.board[i][j]:
                        x -= dx; y -= dy
                    # now traverse forward counting
                    count = 0
                    tx, ty = x, y
                    while 0 <= tx < n and 0 <= ty < n and self.board[tx][ty] == self.board[i][j]:
                        visited.add((tx, ty, d))
                        count += 1
                        tx += dx; ty += dy
                    if count >= 5:
                        return self.board[i][j]
        return None

    def _check_five_in_a_row(self, row, col, direction):
        dx, dy = direction
        if not (0 <= row < self.board_size and 0 <= col < self.board_size):
            return False
        player = self.board[row][col]
        if player == ' ':
            return False
        cnt = 0
        r, c = row, col
        while 0 <= r < self.board_size and 0 <= c < self.board_size and self.board[r][c] == player:
            cnt += 1
            if cnt >= 5:
                return True
            r += dx; c += dy
        return False