from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
import os


class DocFileHandler:
    """
    This is a class that handles Word documents and provides functionalities for reading, writing, and modifying the content of Word documents.
    """

    def __init__(self, file_path):
        self.file_path = file_path

    def read_text(self):
        if not os.path.exists(self.file_path):
            return ""
        try:
            doc = Document(self.file_path)
        except Exception:
            return ""
        content_parts = []
        for p in doc.paragraphs:
            content_parts.append(p.text)
        for tbl in doc.tables:
            table_lines = []
            for r in tbl.rows:
                table_lines.append(", ".join(cell.text for cell in r.cells))
            if table_lines:
                content_parts.append("\n".join(table_lines))
        return "\n".join(filter(None, content_parts))

    def write_text(self, content, font_size=12, alignment='left'):
        try:
            # Always create a new document (overwrite)
            doc = Document()
            align_val = self._get_alignment_value(alignment)
            if isinstance(content, str):
                parts = content.splitlines()
            elif isinstance(content, (list, tuple)):
                parts = [str(x) for x in content]
            else:
                parts = [str(content)]
            for part in parts:
                p = doc.add_paragraph()
                p.alignment = align_val
                run = p.add_run(part)
                run.font.size = Pt(font_size)
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def add_heading(self, heading, level=1):
        try:
            doc = Document(self.file_path) if os.path.exists(self.file_path) else Document()
            doc.add_heading(heading, level=level)
            # set heading font size for clarity
            try:
                p = doc.paragraphs[-1]
                size = {1: 22, 2: 18, 3: 14}.get(level, 12)
                for r in p.runs:
                    r.font.size = Pt(size)
            except Exception:
                pass
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def add_table(self, data):
        try:
            if not data or not isinstance(data, (list, tuple)):
                return False
            rows = len(data)
            cols = max((len(r) for r in data if isinstance(r, (list, tuple))), default=0)
            if cols <= 0:
                return False
            doc = Document(self.file_path) if os.path.exists(self.file_path) else Document()
            table = doc.add_table(rows=rows, cols=cols)
            table.style = 'Table Grid'
            for i, row in enumerate(data):
                for j in range(cols):
                    value = ""
                    if isinstance(row, (list, tuple)) and j < len(row):
                        value = "" if row[j] is None else str(row[j])
                    table.cell(i, j).text = value
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def _get_alignment_value(self, alignment):
        if isinstance(alignment, WD_PARAGRAPH_ALIGNMENT):
            return alignment
        if not isinstance(alignment, str):
            return WD_PARAGRAPH_ALIGNMENT.LEFT
        a = alignment.strip().lower()
        if a in ('center', 'centre'):
            return WD_PARAGRAPH_ALIGNMENT.CENTER
        if a == 'right':
            return WD_PARAGRAPH_ALIGNMENT.RIGHT
        return WD_PARAGRAPH_ALIGNMENT.LEFT