class BankAccount:
    """
    BankAccount with encapsulated balance property and validation via property setter.
    """

    def __init__(self, balance=0):
        self._balance = 0
        self.balance = balance

    @property
    def balance(self):
        return self._balance

    @balance.setter
    def balance(self, value):
        if not isinstance(value, (int, float)):
            raise TypeError("Balance must be numeric")
        self._balance = value

    def deposit(self, amount):
        if not isinstance(amount, (int, float)):
            raise TypeError("Amount must be numeric")
        if amount < 0:
            raise ValueError("Invalid amount")
        self._balance += amount
        return self._balance

    def withdraw(self, amount):
        if not isinstance(amount, (int, float)):
            raise TypeError("Amount must be numeric")
        if amount < 0:
            raise ValueError("Invalid amount")
        if amount > self._balance:
            raise ValueError("Insufficient balance.")
        self._balance -= amount
        return self._balance

    def view_balance(self):
        return self._balance

    def transfer(self, other_account, amount):
        if not isinstance(other_account, BankAccount):
            raise TypeError("other_account must be a BankAccount")
        # reuse withdraw and deposit for consistency
        self.withdraw(amount)
        other_account.deposit(amount)
        return (self._balance, other_account._balance)