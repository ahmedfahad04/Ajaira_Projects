import PyPDF2

class PDFHandler:
    """
    The class allows merging multiple PDF files into one and extracting text from PDFs using PyPDF2 library.
    """

    def __init__(self, filepaths):
        """
        takes a list of file paths filepaths as a parameter.
        It creates a list named readers using PyPDF2, where each reader opens a file from the given paths.
        """
        self.filepaths = filepaths
        self.readers = [PyPDF2.PdfFileReader(fp) for fp in filepaths]

    def merge_pdfs(self, output_filepath):
        writer = PyPDF2.PdfFileWriter()
        for reader in self.readers:
            try:
                if hasattr(reader, "isEncrypted") and reader.isEncrypted:
                    try:
                        reader.decrypt("")
                    except Exception:
                        pass
                num = reader.getNumPages()
            except Exception:
                # fallback for newer reader objects
                num = len(getattr(reader, "pages", []))
            for i in range(num):
                try:
                    page = reader.getPage(i)
                except Exception:
                    page = reader.pages[i]
                writer.addPage(page)
        with open(output_filepath, "wb") as out_f:
            writer.write(out_f)
        return f"Merged PDFs saved at {output_filepath}"

    def extract_text_from_pdfs(self):
        results = []
        for reader in self.readers:
            text_parts = []
            try:
                if hasattr(reader, "isEncrypted") and reader.isEncrypted:
                    try:
                        reader.decrypt("")
                    except Exception:
                        pass
                num = reader.getNumPages()
                for i in range(num):
                    try:
                        page = reader.getPage(i)
                        txt = page.extractText() if hasattr(page, "extractText") else getattr(page, "extract_text", lambda: "")()
                    except Exception:
                        page = reader.pages[i]
                        txt = getattr(page, "extract_text", lambda: "")()
                    if txt:
                        text_parts.append(txt)
            except Exception:
                pages = getattr(reader, "pages", [])
                for page in pages:
                    txt = getattr(page, "extract_text", lambda: "")()
                    if txt:
                        text_parts.append(txt)
            results.append("".join(text_parts))
        return results

# Classification response:
# variable renaming;method renaming;class renaming;list comprehension;accumulator list;accumulator string;temporary variable;try-except wrapper;exception handling;nested conditional;lambda expression;join/split usage;boundary case handling;empty input handling;error suppression;default value handling