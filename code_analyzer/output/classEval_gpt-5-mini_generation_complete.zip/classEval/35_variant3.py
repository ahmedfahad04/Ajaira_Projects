class EightPuzzle:
    """
    This class is an implementation of the classic 8-puzzle game, including methods for finding the blank tile, making moves, getting possible moves, and solving the puzzle using a breadth-first search algorithm.
    """

    def __init__(self, initial_state):
        self.initial_state = initial_state
        self.goal_state = [[1,2,3],[4,5,6],[7,8,0]]

    def find_blank(self, state):
        for i in range(3):
            for j in range(3):
                if state[i][j] == 0:
                    return (i,j)
        return None

    def move(self, state, direction):
        i,j = self.find_blank(state)
        new = [row[:] for row in state]
        if direction == 'up' and i > 0:
            new[i][j], new[i-1][j] = new[i-1][j], new[i][j]
        elif direction == 'down' and i < 2:
            new[i][j], new[i+1][j] = new[i+1][j], new[i][j]
        elif direction == 'left' and j > 0:
            new[i][j], new[i][j-1] = new[i][j-1], new[i][j]
        elif direction == 'right' and j < 2:
            new[i][j], new[i][j+1] = new[i][j+1], new[i][j]
        return new

    def get_possible_moves(self, state):
        i,j = self.find_blank(state)
        moves = []
        # prefer center moves order
        if j > 0:
            moves.append('left')
        if j < 2:
            moves.append('right')
        if i > 0:
            moves.append('up')
        if i < 2:
            moves.append('down')
        return moves

    def solve(self):
        # BFS using simple list as queue (pop(0))
        if self.initial_state == self.goal_state:
            return []
        def key(s):
            return tuple(item for row in s for item in row)
        start = key(self.initial_state)
        goal = key(self.goal_state)
        open_list = [start]
        visited = {start}
        parents = {start: None}
        moves_from = {start: None}
        while open_list:
            cur = open_list.pop(0)
            cur_state = [list(cur[i*3:(i+1)*3]) for i in range(3)]
            for mv in self.get_possible_moves(cur_state):
                nxt_state = self.move(cur_state, mv)
                nxt = key(nxt_state)
                if nxt in visited:
                    continue
                visited.add(nxt)
                parents[nxt] = cur
                moves_from[nxt] = mv
                if nxt == goal:
                    path = []
                    node = nxt
                    while moves_from[node] is not None:
                        path.append(moves_from[node])
                        node = parents[node]
                    return list(reversed(path))
                open_list.append(nxt)
        return []