from datetime import datetime

class Chat:
    """
    This is a chat class with the functions of adding users, removing users, sending messages, and obtaining messages.
    """

    def __init__(self):
        """
        Initialize the Chat with an attribute users, which is an empty dictionary.
        """
        self.users = {}

    def add_user(self, username):
        if username in self.users:
            return False
        self.users[username] = []
        return True

    def remove_user(self, username):
        if username in self.users:
            # Remove user and drop any central references
            del self.users[username]
            return True
        return False

    def send_message(self, sender, receiver, message):
        if sender not in self.users or receiver not in self.users:
            return False
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        message_obj = {
            "sender": sender,
            "receiver": receiver,
            "message": message,
            "timestamp": timestamp
        }
        # store only in sender's outbox (as per examples)
        self.users[sender].append(message_obj)
        return True

    def get_messages(self, username):
        if username not in self.users:
            return []
        # return new list of dicts so callers can't mutate internal state
        return [msg.copy() for msg in self.users[username]]