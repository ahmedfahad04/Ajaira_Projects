class AvgPartition:
    """
    This is a class that partitions the given list into different blocks by specifying the number of partitions, with each block having a uniformly distributed length.
    """

    def __init__(self, lst, limit):
        if not isinstance(limit, int) or limit <= 0:
            raise ValueError("limit must be a positive integer")
        self.lst = list(lst)
        self.limit = limit
        self._parts = None

    def setNum(self):
        n = len(self.lst)
        base = n // self.limit
        rem = n % self.limit
        return (base, rem)

    def _build_parts(self):
        if self._parts is not None:
            return self._parts
        base, rem = self.setNum()
        parts = []
        i = 0
        for idx in range(self.limit):
            size = base + (1 if idx < rem else 0)
            parts.append(self.lst[i:i+size])
            i += size
        self._parts = parts
        return parts

    def get(self, index):
        if not isinstance(index, int):
            raise TypeError("index must be an integer")
        if index < 0:
            index += self.limit
        parts = self._build_parts()
        if index < 0 or index >= self.limit:
            raise IndexError("partition index out of range")
        return parts[index]