import sqlite3
import pandas as pd

class DatabaseProcessor:
    """
    This is a class for processing a database, supporting to create tables, insert data into the database, search for data based on name, and delete data from the database.
    """

    def __init__(self, database_name):
        """
        Initialize database name of database processor
        """
        self.database_name = database_name
        self.conn = sqlite3.connect(self.database_name)
        self.conn.execute("PRAGMA foreign_keys = ON")

    def __del__(self):
        try:
            self.conn.close()
        except Exception:
            pass

    def create_table(self, table_name, key1, key2):
        if not all(isinstance(x, str) for x in (table_name, key1, key2)):
            raise ValueError("Table and column names must be strings")
        sql = f'CREATE TABLE IF NOT EXISTS "{table_name}" (id INTEGER PRIMARY KEY, "{key1}" TEXT, "{key2}" INTEGER)'
        cur = self.conn.cursor()
        cur.execute(sql)
        self.conn.commit()

    def insert_into_database(self, table_name, data):
        if not data:
            return
        if not isinstance(data, list):
            raise ValueError("data must be a list of dicts")
        df = pd.DataFrame.from_records(data)
        if df.empty:
            return
        cols = list(df.columns)
        placeholders = ",".join("?" for _ in cols)
        col_sql = ",".join(f'"{c}"' for c in cols)
        rows = [tuple(x) for x in df[cols].itertuples(index=False, name=None)]
        sql = f'INSERT INTO "{table_name}" ({col_sql}) VALUES ({placeholders})'
        cur = self.conn.cursor()
        cur.executemany(sql, rows)
        self.conn.commit()

    def _get_search_column(self, table_name):
        cur = self.conn.cursor()
        cur.execute(f'PRAGMA table_info("{table_name}")')
        cols = cur.fetchall()
        for col in cols:
            if col[1] != 'id':
                return col[1]
        return None

    def search_database(self, table_name, name):
        col = self._get_search_column(table_name)
        if col is None:
            return None
        cur = self.conn.cursor()
        cur.execute(f'SELECT * FROM "{table_name}" WHERE "{col}" = ?', (name,))
        rows = cur.fetchall()
        return rows if rows else None

    def delete_from_database(self, table_name, name):
        col = self._get_search_column(table_name)
        if col is None:
            return
        cur = self.conn.cursor()
        cur.execute(f'DELETE FROM "{table_name}" WHERE "{col}" = ?', (name,))
        self.conn.commit()