import csv
import os

class CSVProcessor:
    """
    This is a class for processing CSV files, including readring and writing CSV data, as well as processing specific operations and saving as a new CSV file.
    """

    def __init__(self):
        pass

    def read_csv(self, file_name):
        try:
            with open(file_name, newline='', encoding='utf-8') as f:
                reader = csv.reader(f)
                rows = []
                for row in reader:
                    rows.append([cell for cell in row])
                if not rows:
                    return [], []
                return rows[0], rows[1:]
        except Exception:
            return [], []

    def write_csv(self, data, file_name):
        try:
            dirn = os.path.dirname(file_name)
            if dirn and not os.path.exists(dirn):
                os.makedirs(dirn, exist_ok=True)
            with open(file_name, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                for row in data:
                    writer.writerow(row)
            return 1
        except Exception:
            return 0

    def process_csv_data(self, N, save_file_name):
        try:
            title, rows = self.read_csv(save_file_name)
            if title == [] and rows == []:
                return 0
            processed_rows = []
            for r in rows:
                if 0 <= N < len(r):
                    processed_rows.append([r[N].upper()])
                else:
                    processed_rows.append([''])
            name, ext = os.path.splitext(save_file_name)
            if ext == '':
                out_name = name + '_process'
            else:
                out_name = name + '_process' + ext
            all_out = [title] + processed_rows
            return self.write_csv(all_out, out_name)
        except Exception:
            return 0