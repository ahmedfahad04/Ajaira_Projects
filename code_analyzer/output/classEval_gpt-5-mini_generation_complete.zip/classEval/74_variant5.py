class Server:
    """
    This is a class as a server, which handles a white list, message sending and receiving, and information display.
    """

    def __init__(self):
        """
        Initialize the whitelist as an empty list, and initialize the sending and receiving information as an empty dictionary
        """
        self.white_list = []
        self.send_struct = {}
        self.receive_struct = {}

    def add_white_list(self, addr):
        """
        Add an address to the whitelist and do nothing if it already exists
        """
        if any(a == addr for a in self.white_list):
            return False
        self.white_list += [addr]
        return self.white_list

    def del_white_list(self, addr):
        """
        Remove an address from the whitelist and do nothing if it does not exist
        """
        for i, a in enumerate(self.white_list):
            if a == addr:
                # remove at index to preserve order
                del self.white_list[i]
                return self.white_list
        return False

    def recv(self, info):
        """
        Receive information containing address and content. If the address is on the whitelist, receive the content; otherwise, do not receive it
        """
        if not isinstance(info, dict):
            return False
        if "addr" not in info or "content" not in info:
            return False
        addr = info["addr"]
        if addr in self.white_list:
            self.receive_struct = {"addr": addr, "content": info["content"]}
            return info["content"]
        return False

    def send(self, info):
        """
        Send information containing address and content
        """
        if not isinstance(info, dict):
            return "Error: info not dict"
        if "addr" not in info or "content" not in info:
            return "Error: missing addr/content"
        # require addr to be int for sending success
        if not isinstance(info["addr"], int):
            return "Error: addr must be int"
        self.send_struct = {"addr": info["addr"], "content": info["content"]}

    def show(self, type):
        """
        Returns struct of the specified type
        """
        if type == "send":
            return self.send_struct
        if type == "receive":
            return self.receive_struct
        return False