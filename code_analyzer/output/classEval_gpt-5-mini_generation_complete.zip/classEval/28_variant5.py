import sqlite3
import pandas as pd

class DatabaseProcessor:
    """
    This is a class for processing a database, supporting to create tables, insert data into the database, search for data based on name, and delete data from the database.
    """

    def __init__(self, database_name):
        """
        Initialize database name of database processor
        """
        self.database_name = database_name

    def create_table(self, table_name, key1, key2):
        if not all(isinstance(x, str) for x in (table_name, key1, key2)):
            raise ValueError("Identifiers must be strings")
        conn = sqlite3.connect(self.database_name)
        try:
            cur = conn.cursor()
            cur.execute('CREATE TABLE IF NOT EXISTS "{}" (id INTEGER PRIMARY KEY, "{}" TEXT, "{}" INTEGER)'.format(table_name, key1, key2))
            conn.commit()
        finally:
            conn.close()

    def insert_into_database(self, table_name, data):
        if not isinstance(data, list):
            raise ValueError("data must be a list of dicts")
        if not data:
            return
        df = pd.DataFrame.from_records(data)
        if df.empty:
            return
        cols = list(df.columns)
        col_str = ",".join('"{}"'.format(c) for c in cols)
        placeholders = ",".join("?" for _ in cols)
        rows = [tuple(x) for x in df[cols].itertuples(index=False, name=None)]
        conn = sqlite3.connect(self.database_name)
        try:
            cur = conn.cursor()
            cur.executemany('INSERT INTO "{}" ({}) VALUES ({})'.format(table_name, col_str, placeholders), rows)
            conn.commit()
        finally:
            conn.close()

    def _find_search_column(self, conn, table_name):
        cur = conn.cursor()
        cur.execute('PRAGMA table_info("{}")'.format(table_name))
        info = cur.fetchall()
        for col in info:
            if col[1] != 'id':
                return col[1]
        return None

    def search_database(self, table_name, name):
        conn = sqlite3.connect(self.database_name)
        try:
            col = self._find_search_column(conn, table_name)
            if col is None:
                return None
            df = pd.read_sql_query('SELECT * FROM "{}" WHERE "{}" = ?'.format(table_name, col), conn, params=(name,))
            if df.empty:
                return None
            return [tuple(row) for row in df.itertuples(index=False, name=None)]
        finally:
            conn.close()

    def delete_from_database(self, table_name, name):
        conn = sqlite3.connect(self.database_name)
        try:
            col = self._find_search_column(conn, table_name)
            if col is None:
                return
            cur = conn.cursor()
            cur.execute('DELETE FROM "{}" WHERE "{}" = ?'.format(table_name, col), (name,))
            conn.commit()
        finally:
            conn.close()