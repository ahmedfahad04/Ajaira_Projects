import re
from collections import defaultdict, Counter
from itertools import chain

class NLPDataProcessor2:
    """
    The class processes NLP data by extracting words from a list of strings, calculating the frequency of each word, and returning the top 5 most frequent words.
    """

    def process_data(self, string_list):
        pattern = re.compile(r'[^A-Za-z ]+')
        return [pattern.sub('', s).lower().split() for s in string_list]

    def calculate_word_frequency(self, words_list):
        freq = defaultdict(int)
        for word in chain.from_iterable(words_list):
            freq[word] += 1
        if not freq:
            return {}
        items = sorted(freq.items(), key=lambda kv: (-kv[1], kv[0]))
        top = items[:5]
        return {k: v for k, v in top}

    def process(self, string_list):
        words = self.process_data(string_list)
        return self.calculate_word_frequency(words)

# Classification response:
# import reorganization;list comprehension;regex usage;itertools usage;accumulator dict;dict comprehension;sort key;slicing;guard clause;frequency counting;empty input handling;variable renaming;loop rewrite