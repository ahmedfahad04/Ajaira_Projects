class WeatherSystem:
    """
    This is a class representing a weather system that provides functionality to query weather information for a specific city and convert temperature units between Celsius and Fahrenheit.
    """

    def __init__(self, city) -> None:
        """
        Initialize the weather system with a city name.
        """
        self.temperature = None
        self.weather = None
        self.city = city
        self.weather_list = {}

    def query(self, weather_list, tmp_units = 'celsius'):
        """
        Query the weather system and convert temperature. Returns (temperature, weather).
        If city not present returns (None, None).
        """
        # store reference
        self.weather_list = weather_list
        # find entry by exact or case-insensitive key
        entry = None
        if isinstance(weather_list, dict):
            if self.city in weather_list:
                entry = weather_list[self.city]
            else:
                if isinstance(self.city, str):
                    for k, v in weather_list.items():
                        if isinstance(k, str) and k.lower() == self.city.lower():
                            entry = v
                            break
        else:
            return (None, None)
        if entry is None:
            return (None, None)
        temp = entry.get('temperature')
        units = entry.get('temperature units', 'celsius')
        self.weather = entry.get('weather')
        self.temperature = temp
        if temp is None:
            return (None, self.weather)
        src = (units or 'celsius').strip().lower()
        dst = (tmp_units or 'celsius').strip().lower()
        if src.startswith('c') and dst.startswith('f'):
            converted = self._c2f(self.temperature)
            # update internal temperature to the converted value
            self.temperature = converted
            return (converted, self.weather)
        if src.startswith('f') and dst.startswith('c'):
            converted = self._f2c(self.temperature)
            self.temperature = converted
            return (converted, self.weather)
        return (self.temperature, self.weather)

    def set_city(self, city):
        """
        Set the city of the weather system.
        """
        self.city = city

    def celsius_to_fahrenheit(self):
        """
        Convert the temperature from Celsius to Fahrenheit.
        """
        if self.temperature is None:
            return None
        return self._c2f(self.temperature)

    def fahrenheit_to_celsius(self):
        """
        Convert the temperature from Fahrenheit to Celsius.
        """
        if self.temperature is None:
            return None
        return self._f2c(self.temperature)

    # helper static methods
    @staticmethod
    def _c2f(c):
        return float(c) * 9.0 / 5.0 + 32.0

    @staticmethod
    def _f2c(f):
        return (float(f) - 32.0) * 5.0 / 9.0