import re

class Words2Numbers:
    """
    The class provides a text-to-number conversion utility, allowing conversion of written numbers (in words) to their numerical representation.
    """

    def __init__(self):
        """
        Initialize the word lists and dictionaries required for conversion
        """
        self.numwords = {}
        self.units = [
            "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
            "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
            "sixteen", "seventeen", "eighteen", "nineteen",
        ]
        self.tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]
        self.scales = ["hundred", "thousand", "million", "billion", "trillion"]

        self.numwords["and"] = (1, 0)
        for idx, word in enumerate(self.units):
            self.numwords[word] = (1, idx)
        for idx, word in enumerate(self.tens):
            if word:
                self.numwords[word] = (1, idx * 10)
        for idx, word in enumerate(self.scales):
            self.numwords[word] = (10 ** (idx * 3 or 2), 0)

        self.ordinal_words = {'first': 1, 'second': 2, 'third': 3, 'fifth': 5, 'eighth': 8, 'ninth': 9, 'twelfth': 12}
        self.ordinal_endings = [('ieth', 'y'), ('th', '')]

    def _normalize_and_split(self, textnum):
        text = textnum.lower().strip()
        text = re.sub(r'[,]+', ' ', text)
        text = re.sub(r'[-\u2010\u2011\u2012\u2013\u2014\u2015]', ' ', text)
        tokens = re.split(r'\s+', text)
        return [t for t in tokens if t]

    def _word_to_value(self, word):
        if word in self.numwords:
            return self.numwords[word]
        if word in self.ordinal_words:
            return (1, self.ordinal_words[word])
        for ending, repl in self.ordinal_endings:
            if word.endswith(ending):
                base = word[:-len(ending)] + repl
                if base in self.numwords:
                    return self.numwords[base]
        return None

    def text2int(self, textnum):
        if not isinstance(textnum, str):
            raise ValueError("Input must be a string")
        tokens = self._normalize_and_split(textnum)
        if not tokens:
            return "0"
        negative = False
        if tokens and tokens[0] in ("minus", "negative"):
            negative = True
            tokens = tokens[1:]
        total = 0
        current = 0
        for token in tokens:
            if token == 'and':
                continue
            val = self._word_to_value(token)
            if val is None:
                raise ValueError("Invalid token: {}".format(token))
            scale, increment = val
            if scale > 1:
                if current == 0:
                    current = 1
                current = current * scale
                if scale > 100:
                    total += current
                    current = 0
            else:
                current += increment
        total += current
        if negative:
            total = -total
        return str(total)

    def is_valid_input(self, textnum):
        if not isinstance(textnum, str):
            return False
        if '-' in textnum:
            return False
        tokens = self._normalize_and_split(textnum)
        if not tokens:
            return False
        for i, token in enumerate(tokens):
            if token in ("minus", "negative", "and"):
                continue
            if token in self.numwords or token in self.ordinal_words:
                continue
            matched = False
            for ending, repl in self.ordinal_endings:
                if token.endswith(ending):
                    base = token[:-len(ending)] + repl
                    if base in self.numwords:
                        matched = True
                        break
            if matched:
                continue
            return False
        return True