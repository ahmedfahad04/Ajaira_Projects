import threading

class CurrencyConverter:
    """
    This is a class for currency conversion, which supports to convert amounts between different currencies, retrieve supported currencies, add new currency rates, and update existing currency rates.
    """
    def __init__(self):
        self._lock = threading.RLock()
        self.rates = {
            'USD': 1.0,
            'EUR': 0.85,
            'GBP': 0.72,
            'JPY': 110.15,
            'CAD': 1.23,
            'AUD': 1.34,
            'CNY': 6.40,
        }

    def convert(self, amount, from_currency, to_currency):
        with self._lock:
            if from_currency not in self.rates:
                raise ValueError("Unsupported source currency")
            if to_currency not in self.rates:
                raise ValueError("Unsupported target currency")
            if not isinstance(amount, (int, float)):
                raise TypeError("amount must be numeric")
            rf = self.rates[from_currency]
            rt = self.rates[to_currency]
            if rf == 0:
                raise ZeroDivisionError("Source rate is zero")
            return float(amount * (rt / rf))

    def get_supported_currencies(self):
        with self._lock:
            return list(self.rates.keys())

    def add_currency_rate(self, currency, rate):
        with self._lock:
            if currency in self.rates:
                return False
            if not isinstance(rate, (int, float)):
                raise TypeError("rate must be numeric")
            self.rates[currency] = float(rate)

    def update_currency_rate(self, currency, new_rate):
        with self._lock:
            if currency not in self.rates:
                return False
            if not isinstance(new_rate, (int, float)):
                raise TypeError("new_rate must be numeric")
            self.rates[currency] = float(new_rate)