import re

class PersonRequest:
    """
    This class validates input personal information data and sets invalid fields to None based to specific rules.
    """

    def __init__(self, name: str, sex: str, phoneNumber: str):
        self.name = self._validate_name(name)
        self.sex = self._validate_sex(sex)
        self.phoneNumber = self._validate_phoneNumber(phoneNumber)

    def _validate_name(self, name: str) -> str:
        if name is None:
            return None
        try:
            s = str(name).strip()
        except Exception:
            return None
        if s == "" or len(s) > 33:
            return None
        return s

    def _validate_sex(self, sex: str) -> str:
        if sex is None:
            return None
        try:
            s = str(sex)
        except Exception:
            return None
        allowed = {"Man", "Woman", "UGM"}
        return s if s in allowed else None

    def _validate_phoneNumber(self, phoneNumber: str) -> str:
        if phoneNumber is None:
            return None
        try:
            s = str(phoneNumber).strip()
        except Exception:
            return None
        if s == "":
            return None
        if re.fullmatch(r"\d{11}", s):
            return s
        return None

# Classification response:
# try-except wrapper; type conversion; regex usage; membership test; set conversion; input validation; empty input handling; boundary case handling; temporary variable; behavior change