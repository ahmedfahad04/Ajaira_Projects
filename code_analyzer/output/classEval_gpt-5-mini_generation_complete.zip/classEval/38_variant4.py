import openpyxl
from openpyxl import Workbook
from openpyxl import load_workbook
from openpyxl.writer.write_only import WriteOnlyWorkbook
import os


class ExcelProcessor:
    """
    This is a class for processing excel files, including readring and writing excel data, as well as processing specific operations and saving as a new excel file.
    """

    def __init__(self):
        pass

    def read_excel(self, file_name):
        """
        Reading data from Excel files (streaming-friendly)
        :param file_name:str, Excel file name to read
        :return:list of data, Data in Excel
        """
        try:
            wb = load_workbook(filename=file_name, read_only=True, data_only=True)
            ws = wb.active
            data = []
            for row in ws.iter_rows(values_only=True):
                data.append(tuple(row))
            return data
        except Exception:
            return []

    def write_excel(self, data, file_name):
        """
        Write data to the specified Excel file using write-only mode for large data
        :param data: list, Data to be written
        :param file_name: str, Excel file name to write to
        :return: 0 or 1, 1 represents successful writing, 0 represents failed writing
        """
        try:
            wb = WriteOnlyWorkbook()
            ws = wb.create_sheet()
            if data:
                # if data are dicts, write header first
                if isinstance(data[0], dict):
                    headers = list(data[0].keys())
                    ws.append(headers)
                    for d in data:
                        ws.append([d.get(h) for h in headers])
                else:
                    for row in data:
                        ws.append(list(row))
            wb.save(file_name)
            return 1
        except Exception:
            return 0

    def process_excel_data(self, N, save_file_name):
        """
        Change the specified column in the Excel file to uppercase using streaming
        :param N: int, The serial number of the column that want to change
        :param save_file_name: str, source file name
        :return:(int, str), The former is the return value of write_excel, while the latter is the saved file name of the processed data
        """
        try:
            src = load_workbook(filename=save_file_name, read_only=True, data_only=True)
            src_ws = src.active
            new_wb = WriteOnlyWorkbook()
            new_ws = new_wb.create_sheet()
            for row in src_ws.iter_rows(values_only=True):
                row = list(row)
                if 1 <= N <= len(row):
                    if row[N - 1] is not None:
                        row[N - 1] = str(row[N - 1]).upper()
                new_ws.append(row)
            base, ext = os.path.splitext(save_file_name)
            out = f"{base}_stream_upper{ext or '.xlsx'}"
            new_wb.save(out)
            return 1, out
        except Exception:
            base, ext = os.path.splitext(save_file_name)
            out = f"{base}_stream_upper{ext or '.xlsx'}"
            return 0, out