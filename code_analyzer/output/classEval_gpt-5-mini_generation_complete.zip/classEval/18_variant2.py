import re
from functools import lru_cache

class CamelCaseMap:
    """
    This is a custom class that allows keys to be in camel case style by converting them from underscore style, which provides dictionary-like functionality.
    """

    def __init__(self):
        """
        Initialize data to an empty dictionary
        """
        self._data = {}

    def __getitem__(self, key):
        ck = self._convert_key(key)
        return self._data[ck]

    def __setitem__(self, key, value):
        ck = self._convert_key(key)
        self._data[ck] = value

    def __delitem__(self, key):
        ck = self._convert_key(key)
        del self._data[ck]

    def __iter__(self):
        return iter(self._data)

    def __len__(self):
        return len(self._data)

    def _convert_key(self, key):
        if not isinstance(key, str):
            return key
        return self._to_camel_case(key)

    @staticmethod
    def _to_camel_case(key):
        if not isinstance(key, str):
            return key
        # use a cached inner function to avoid decorating the staticmethod directly
        @lru_cache(maxsize=2048)
        def _convert(s):
            # replace underscores followed by a char with the uppercase char
            def repl(m):
                return m.group(1).upper()
            return re.sub(r'_([a-zA-Z0-9])', repl, s)
        return _convert(key)