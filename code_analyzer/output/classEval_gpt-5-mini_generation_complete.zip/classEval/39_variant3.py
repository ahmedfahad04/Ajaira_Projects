from collections import deque
import re
from decimal import Decimal, getcontext

class ExpressionCalculator:
    """
    This is a class in Python that can perform calculations with basic arithmetic operations, including addition, subtraction, multiplication, division, and modulo.
    """

    def __init__(self):
        """
        Initialize the expression calculator
        """
        self.postfix_stack = deque()
        self.operat_priority = [0, 3, 2, 1, -1, 1, 0, 2]
        getcontext().prec = 28

    def calculate(self, expression):
        """
        Calculate using Decimal arithmetic for precision
        """
        expr = self.transform(expression)
        self.prepare(expr)
        stack = []
        for tok in list(self.postfix_stack):
            if tok in {'+', '-', '*', '/', '%'}:
                if len(stack) < 2:
                    raise ValueError("Invalid expression")
                b = stack.pop()
                a = stack.pop()
                stack.append(self._calculate(a, b, tok))
            else:
                stack.append(Decimal(tok))
        if not stack:
            return 0.0
        return float(stack[-1])

    def prepare(self, expression):
        """
        Tokenize and convert to postfix (RPN)
        """
        tokens = re.findall(r'\d+\.\d+|\d+|[()+\-*/%]', expression)
        out = []
        ops = []
        prec = {'+':1,'-':1,'*':2,'/':2,'%':2}
        for i, t in enumerate(tokens):
            if re.match(r'^\d+(\.\d+)?$', t):
                out.append(t)
            elif t == '(':
                ops.append(t)
            elif t == ')':
                while ops and ops[-1] != '(':
                    out.append(ops.pop())
                if ops:
                    ops.pop()
            else:
                # unary minus detection
                if t == '-' and (i == 0 or tokens[i-1] in {'(', '+', '-', '*', '/', '%'}):
                    out.append('0')
                while ops and ops[-1] != '(' and prec.get(ops[-1],0) >= prec.get(t,0):
                    out.append(ops.pop())
                ops.append(t)
        while ops:
            out.append(ops.pop())
        self.postfix_stack = deque(out)

    @staticmethod
    def is_operator(c):
        return c in {'+', '-', '*', '/', '(', ')', '%'}

    def compare(self, cur, peek):
        priority = {'+':1,'-':1,'*':2,'/':2,'%':2}
        return priority.get(cur,0) >= priority.get(peek,0)

    @staticmethod
    def _calculate(first_value, second_value, current_op):
        a = Decimal(str(first_value)) if not isinstance(first_value, Decimal) else first_value
        b = Decimal(str(second_value)) if not isinstance(second_value, Decimal) else second_value
        if current_op == '+':
            return a + b
        if current_op == '-':
            return a - b
        if current_op == '*':
            return a * b
        if current_op == '/':
            if b == 0:
                raise ZeroDivisionError("division by zero")
            return a / b
        if current_op == '%':
            if b == 0:
                raise ZeroDivisionError("modulo by zero")
            return a % b
        raise ValueError("Unknown operator")

    @staticmethod
    def transform(expression):
        return ''.join(expression.split())