from collections import defaultdict

class VendingMachine:
    """
    This is a class to simulate a vending machine, including adding products, inserting coins, purchasing products, viewing balance, replenishing product inventory, and displaying product information.
    """

    def __init__(self):
        """
        Initializes the vending machine's inventory and balance.
        """
        # default structure ensures keys map to dict entries
        self.inventory = {}
        self.balance = 0.0

    def add_item(self, item_name, price, quantity):
        if quantity <= 0 or price < 0:
            return
        self.inventory[item_name] = {'price': float(price), 'quantity': int(quantity)}

    def insert_coin(self, amount):
        try:
            amt = float(amount)
        except (TypeError, ValueError):
            return self.balance
        if amt <= 0:
            return self.balance
        self.balance = round(self.balance + amt, 2)
        return self.balance

    def purchase_item(self, item_name):
        item = self.inventory.get(item_name)
        if not item:
            return False
        if item['quantity'] <= 0:
            return False
        price = float(item['price'])
        if self.balance < price:
            return False
        item['quantity'] -= 1
        self.balance = round(self.balance - price, 2)
        return self.balance

    def restock_item(self, item_name, quantity):
        if item_name not in self.inventory:
            return False
        if quantity > 0:
            self.inventory[item_name]['quantity'] += int(quantity)
        return True

    def display_items(self):
        if not self.inventory:
            return False
        # deterministic ordering
        keys = sorted(self.inventory.keys())
        lines = []
        for k in keys:
            v = self.inventory[k]
            lines.append(f"{k} - ${v['price']:.2f} [{v['quantity']}]")
        return "\n".join(lines)