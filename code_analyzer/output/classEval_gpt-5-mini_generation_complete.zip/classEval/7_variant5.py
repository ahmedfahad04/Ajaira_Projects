class BalancedBrackets:
    """
    This is a class that checks for bracket matching
    """

    def __init__(self, expr):
        """
        Initializes the class with an expression.
        :param expr: The expression to check for balanced brackets,str.
        """
        self.stack = []
        self.left_brackets = ["(", "{", "["]
        self.right_brackets = [")", "}", "]"]
        self.expr = expr

    def clear_expr(self):
        """
        Clears the expression of all characters that are not brackets.
        """
        s = self.expr or ""
        out = []
        for ch in s:
            if ch in '(){}[]':
                out.append(ch)
        self.expr = ''.join(out)

    def check_balanced_brackets(self):
        """
        Checks if the expression has balanced brackets.
        :return: True if the expression has balanced brackets, False otherwise.
        """
        self.clear_expr()
        self.stack = []
        # Use index matching instead of dict
        for ch in self.expr:
            if ch in self.left_brackets:
                self.stack.append(ch)
            else:
                # must be a right bracket
                try:
                    idx = self.right_brackets.index(ch)
                except ValueError:
                    return False
                if not self.stack:
                    return False
                top = self.stack.pop()
                if self.left_brackets[idx] != top:
                    return False
        return len(self.stack) == 0