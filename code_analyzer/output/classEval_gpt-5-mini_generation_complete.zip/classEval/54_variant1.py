import random
from collections import deque

class MahjongConnect:
    """
    MahjongConnect is a class representing a game board for Mahjong Connect with features like creating the board, checking valid moves, finding paths, removing icons, and checking if the game is over.
    """

    def __init__(self, BOARD_SIZE, ICONS):
        self.BOARD_SIZE = BOARD_SIZE
        self.ICONS = ICONS
        self.board = self.create_board()

    def create_board(self):
        rows, cols = self.BOARD_SIZE
        board = []
        for r in range(rows):
            row = []
            for c in range(cols):
                row.append(self.ICONS[c % len(self.ICONS)])
            board.append(row)
        return board

    def in_bounds(self, x, y):
        return 0 <= x < self.BOARD_SIZE[0] and 0 <= y < self.BOARD_SIZE[1]

    def is_valid_move(self, pos1, pos2):
        if not (isinstance(pos1, tuple) and isinstance(pos2, tuple)):
            return False
        if pos1 == pos2:
            return False
        x1, y1 = pos1
        x2, y2 = pos2
        if not (self.in_bounds(x1, y1) and self.in_bounds(x2, y2)):
            return False
        if self.board[x1][y1] == ' ' or self.board[x2][y2] == ' ':
            return False
        if self.board[x1][y1] != self.board[x2][y2]:
            return False
        return self.has_path(pos1, pos2)

    def has_path(self, pos1, pos2):
        # BFS with direction and turns tracking (max 2 turns)
        rows, cols = self.BOARD_SIZE
        x1, y1 = pos1
        x2, y2 = pos2
        if pos1 == pos2:
            return False
        # Allowed to move through spaces or the target cell
        def ok(nx, ny):
            if not (0 <= nx < rows and 0 <= ny < cols):
                return False
            if (nx, ny) == (x2, y2):
                return True
            return self.board[nx][ny] == ' '
        # directions: up, right, down, left
        dirs = [(-1,0),(0,1),(1,0),(0,-1)]
        # visited[(x,y,dir)] = minimal turns to reach
        visited = {}
        dq = deque()
        # initialize: from start, try all four directions stepping at least one
        for d_idx, (dx,dy) in enumerate(dirs):
            nx, ny = x1 + dx, y1 + dy
            while 0 <= nx < rows and 0 <= ny < cols and ok(nx, ny):
                state = (nx, ny, d_idx)
                if visited.get(state, 99) > 0:
                    visited[state] = 0
                    dq.append((nx, ny, d_idx, 0))
                if (nx, ny) == (x2, y2):
                    return True
                nx += dx; ny += dy
        # Also allow staying in place directionless (in case adjacent target)
        # BFS
        while dq:
            x, y, d, turns = dq.popleft()
            if turns > 2:
                continue
            if (x, y) == (x2, y2):
                return True
            for nd, (dx,dy) in enumerate(dirs):
                nx, ny = x + dx, y + dy
                nturns = turns + (0 if nd == d else 1)
                if nturns > 2:
                    continue
                while 0 <= nx < rows and 0 <= ny < cols and ok(nx, ny):
                    state = (nx, ny, nd)
                    if visited.get(state, 99) > nturns:
                        visited[state] = nturns
                        if (nx, ny) == (x2, y2):
                            return True
                        dq.append((nx, ny, nd, nturns))
                    nx += dx; ny += dy
        return False

    def remove_icons(self, pos1, pos2):
        if not self.is_valid_move(pos1, pos2):
            return
        x1, y1 = pos1
        x2, y2 = pos2
        self.board[x1][y1] = ' '
        self.board[x2][y2] = ' '

    def is_game_over(self):
        for row in self.board:
            for cell in row:
                if cell != ' ':
                    return False
        return True

# Classification response:
# helper function extraction;loop rewrite;queue-based;stack-based;dictionary lookup;index-based loop;standard library helper;guard clause;input validation;behavior change