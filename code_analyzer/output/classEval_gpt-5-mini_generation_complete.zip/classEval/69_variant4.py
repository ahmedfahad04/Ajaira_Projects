import PyPDF2

class PDFHandler:
    """
    The class allows merging multiple PDF files into one and extracting text from PDFs using PyPDF2 library.
    """

    def __init__(self, filepaths):
        """
        takes a list of file paths filepaths as a parameter.
        It creates a list named readers using PyPDF2, where each reader opens a file from the given paths.
        """
        self.filepaths = filepaths
        self.readers = [PyPDF2.PdfFileReader(fp) for fp in filepaths]

    def merge_pdfs(self, output_filepath):
        writer = PyPDF2.PdfFileWriter()
        for fp in self.filepaths:
            try:
                with open(fp, "rb") as f:
                    reader = PyPDF2.PdfFileReader(f)
                    if getattr(reader, "isEncrypted", False):
                        try:
                            reader.decrypt("")
                        except Exception:
                            pass
                    for i in range(reader.getNumPages()):
                        writer.addPage(reader.getPage(i))
            except Exception:
                try:
                    # fallback to original reader objects
                    idx = self.filepaths.index(fp)
                    r = self.readers[idx]
                    if getattr(r, "isEncrypted", False):
                        try:
                            r.decrypt("")
                        except Exception:
                            pass
                    for i in range(r.getNumPages()):
                        writer.addPage(r.getPage(i))
                except Exception:
                    continue
        with open(output_filepath, "wb") as out_f:
            writer.write(out_f)
        return f"Merged PDFs saved at {output_filepath}"

    def extract_text_from_pdfs(self):
        texts = []
        for fp in self.filepaths:
            collected = []
            try:
                with open(fp, "rb") as f:
                    reader = PyPDF2.PdfFileReader(f)
                    if getattr(reader, "isEncrypted", False):
                        try:
                            reader.decrypt("")
                        except Exception:
                            pass
                    for i in range(reader.getNumPages()):
                        p = reader.getPage(i)
                        txt = p.extractText() if hasattr(p, "extractText") else getattr(p, "extract_text", lambda: "")()
                        if txt:
                            collected.append(txt)
            except Exception:
                try:
                    idx = self.filepaths.index(fp)
                    r = self.readers[idx]
                    if getattr(r, "isEncrypted", False):
                        try:
                            r.decrypt("")
                        except Exception:
                            pass
                    for i in range(r.getNumPages()):
                        p = r.getPage(i)
                        txt = p.extractText() if hasattr(p, "extractText") else getattr(p, "extract_text", lambda: "")()
                        if txt:
                            collected.append(txt)
                except Exception:
                    pass
            texts.append("".join(collected))
        return texts

# Classification response:
# variable renaming; loop rewrite; try-except wrapper; nested conditional; accumulator list; join/split usage; lambda expression; method renaming; class renaming; error suppression; boundary case handling