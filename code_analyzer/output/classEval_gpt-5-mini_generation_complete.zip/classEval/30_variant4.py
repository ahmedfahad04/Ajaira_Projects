import numpy as np
import math

class DataStatistics2:
    """
    This is a class for performing data statistics, supporting to get the sum, minimum, maximum, variance, standard deviation, and correlation of a given dataset.
    """

    def __init__(self, data):
        """
        Initialize Data List
        :param data:list
        """
        self.data = np.array(data, dtype=float).reshape(-1)

    def _require_nonempty(self):
        if self.data.size == 0:
            raise ValueError("data is empty")

    def get_sum(self):
        self._require_nonempty()
        s = float(np.add.reduce(self.data))
        if s.is_integer():
            return int(s)
        return s

    def get_min(self):
        self._require_nonempty()
        v = float(np.minimum.reduce(self.data))
        return int(v) if v.is_integer() else v

    def get_max(self):
        self._require_nonempty()
        v = float(np.maximum.reduce(self.data))
        return int(v) if v.is_integer() else v

    def get_variance(self):
        self._require_nonempty()
        # compute population variance using vectorized ops
        mean = np.sum(self.data) / self.data.size
        diffs = self.data - mean
        var = float(np.dot(diffs, diffs) / self.data.size)
        return round(var, 2)

    def get_std_deviation(self):
        self._require_nonempty()
        var = self.get_variance()
        return round(math.sqrt(var), 2)

    def get_correlation(self):
        self._require_nonempty()
        n = self.data.size
        if n < 2:
            return 0.0
        idx = np.arange(1, n + 1, dtype=float)
        x = idx - idx.mean()
        y = self.data - self.data.mean()
        denom = math.sqrt(np.dot(x, x) * np.dot(y, y))
        if denom == 0.0:
            return 0.0
        return float(np.dot(x, y) / denom)