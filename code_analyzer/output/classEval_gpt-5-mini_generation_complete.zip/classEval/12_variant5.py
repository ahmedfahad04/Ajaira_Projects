import random
from functools import reduce

class BlackjackGame:
    """
    This is a class representing a game of blackjack, which includes creating a deck, calculating the value of a hand, and determine the winner based on the hand values of the player and dealer.
    """

    def __init__(self):
        self.deck = self.create_deck()
        self.player_hand = []
        self.dealer_hand = []

    def create_deck(self):
        ranks = ['A'] + [str(i) for i in range(2, 11)] + ['J', 'Q', 'K']
        suits = ['S', 'H', 'D', 'C']
        deck = [f"{r}{s}" for s in suits for r in ranks]
        # use random.sample to return shuffled list
        return random.sample(deck, len(deck))

    def calculate_hand_value(self, hand):
        def value_for_card(acc, card):
            total, aces = acc
            rank = card[:-1]
            if rank == 'A':
                return (total + 11, aces + 1)
            if rank in ('J', 'Q', 'K'):
                return (total + 10, aces)
            return (total + int(rank), aces)
        total, aces = reduce(value_for_card, hand, (0, 0))
        while total > 21 and aces > 0:
            total -= 10
            aces -= 1
        return total

    def check_winner(self, player_hand, dealer_hand):
        pval = self.calculate_hand_value(player_hand)
        dval = self.calculate_hand_value(dealer_hand)
        # both valid
        if pval <= 21 and dval <= 21:
            if pval == dval:
                return 'Dealer wins'
            return 'Player wins' if pval > dval else 'Dealer wins'
        # otherwise lower value wins
        if pval == dval:
            return 'Dealer wins'
        return 'Player wins' if pval < dval else 'Dealer wins'