from datetime import datetime, timedelta

class CalendarUtil:
    """
    This is a class as CalendarUtil that provides functionalities to manage calendar events, schedule appointments, and perform conflict checks.
    """

    def __init__(self):
        """
        Initialize the calendar with an empty list of events.
        """
        self.events = []

    def add_event(self, event):
        """
        Add an event to the calendar.
        """
        # Normalize: ensure start_time and end_time exist; if missing use 'date' as default start and +1h as end
        ev = event.copy()
        if 'start_time' not in ev or ev['start_time'] is None:
            ev['start_time'] = ev.get('date')
        if 'end_time' not in ev or ev['end_time'] is None:
            st = ev.get('start_time')
            ev['end_time'] = st + timedelta(hours=1) if isinstance(st, datetime) else st
        self.events.append(ev)

    def remove_event(self, event):
        """
        Remove an event from the calendar.
        """
        # Remove first matching event by equality of keys
        for i, e in enumerate(self.events):
            # consider events equal if all provided keys in event match
            match = True
            for k, v in event.items():
                if k not in e or e[k] != v:
                    match = False
                    break
            if match:
                self.events.pop(i)
                return

    def get_events(self, date):
        """
        Get all events on a given date.
        """
        # Accept both date/datetime; compare by date()
        if isinstance(date, datetime):
            target = date.date()
        else:
            target = date
        out = []
        for e in self.events:
            d = e.get('date')
            if isinstance(d, datetime):
                if d.date() == target:
                    out.append(e)
            else:
                if d == target:
                    out.append(e)
        return out

    def is_available(self, start_time, end_time):
        """
        Check if the calendar is available for a given time slot.
        """
        # Overlap if not (end <= ev_start or start >= ev_end)
        for e in self.events:
            ev_start = e.get('start_time') or e.get('date')
            ev_end = e.get('end_time') or (e.get('start_time') or e.get('date'))
            if ev_start is None or ev_end is None:
                continue
            if not (end_time <= ev_start or start_time >= ev_end):
                return False
        return True

    def get_available_slots(self, date):
        """
        Get all available time slots on a given date.
        """
        if isinstance(date, datetime):
            day = date.date()
        else:
            day = date
        day_start = datetime(day.year, day.month, day.day)
        day_end = day_start + timedelta(days=1)
        # collect events that intersect the day
        intervals = []
        for e in self.events:
            ev_start = e.get('start_time') or e.get('date')
            ev_end = e.get('end_time') or ev_start
            if ev_start is None or ev_end is None:
                continue
            # if event intersects the day
            if ev_end <= day_start or ev_start >= day_end:
                continue
            start = max(ev_start, day_start)
            end = min(ev_end, day_end)
            intervals.append((start, end))
        # merge intervals
        intervals.sort(key=lambda x: x[0])
        merged = []
        for inter in intervals:
            if not merged:
                merged.append(list(inter))
            else:
                if inter[0] <= merged[-1][1]:
                    if inter[1] > merged[-1][1]:
                        merged[-1][1] = inter[1]
                else:
                    merged.append([inter[0], inter[1]])
        # compute gaps
        free = []
        cursor = day_start
        for s, e in merged:
            if cursor < s:
                free.append((cursor, s))
            cursor = max(cursor, e)
        if cursor < day_end:
            free.append((cursor, day_end))
        return free

    def get_upcoming_events(self, num_events):
        """
        Get the next n upcoming events from now.
        """
        now = datetime.now()
        normalized = []
        for e in self.events:
            ev_start = e.get('start_time') or e.get('date')
            if ev_start is None:
                continue
            normalized.append((ev_start, e))
        normalized.sort(key=lambda x: x[0])
        # select those >= now
        upcoming = [e for (t, e) in normalized if t >= now]
        # if not enough upcoming, include past events sorted ascending (alternate behavior)
        if len(upcoming) < num_events:
            # include some past events before now to fill up
            past = [e for (t, e) in normalized if t < now]
            # keep most recent past first
            past.sort(key=lambda x: x[0], reverse=False)
            combined = upcoming + [e for (t, e) in past]
        else:
            combined = upcoming
        return combined[:num_events]