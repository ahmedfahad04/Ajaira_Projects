class SQLGenerator:
    """
    This class generates SQL statements for common operations on a table, such as SELECT, INSERT, UPDATE, and DELETE.
    """

    def __init__(self, table_name):
        self.table_name = table_name

    def _format(self, v):
        if v is None:
            return "NULL"
        if isinstance(v, (int, float)):
            return str(v)
        if isinstance(v, bool):
            return "TRUE" if v else "FALSE"
        s = str(v).replace("'", "''")
        return "'" + s + "'"

    def select(self, fields=None, condition=None):
        if fields:
            if isinstance(fields, (list, tuple)):
                fields_str = ", ".join(fields)
            else:
                fields_str = str(fields)
        else:
            fields_str = "*"
        stmt = f"SELECT {fields_str} FROM {self.table_name}"
        if condition:
            stmt += f" WHERE {condition}"
        return stmt + ";"

    def insert(self, data):
        if not isinstance(data, dict) or not data:
            raise ValueError("insert requires a non-empty dict")
        keys = list(data.keys())
        cols = ", ".join(keys)
        vals = ", ".join(self._format(data[k]) for k in keys)
        return f"INSERT INTO {self.table_name} ({cols}) VALUES ({vals});"

    def update(self, data, condition):
        if not isinstance(data, dict) or not data:
            raise ValueError("update requires a non-empty dict")
        parts = []
        for k, v in data.items():
            parts.append(f"{k} = {self._format(v)}")
        stmt = f"UPDATE {self.table_name} SET " + ", ".join(parts)
        if condition:
            stmt += f" WHERE {condition}"
        return stmt + ";"

    def delete(self, condition):
        stmt = f"DELETE FROM {self.table_name}"
        if condition:
            stmt += f" WHERE {condition}"
        return stmt + ";"

    def select_female_under_age(self, age):
        return f"SELECT * FROM {self.table_name} WHERE age < {int(age)} AND gender = 'female';"

    def select_by_age_range(self, min_age, max_age):
        return f"SELECT * FROM {self.table_name} WHERE age BETWEEN {int(min_age)} AND {int(max_age)};"