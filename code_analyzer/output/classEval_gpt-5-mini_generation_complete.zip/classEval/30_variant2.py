import numpy as np
import math
from statistics import mean, pvariance

class DataStatistics2:
    """
    This is a class for performing data statistics, supporting to get the sum, minimum, maximum, variance, standard deviation, and correlation of a given dataset.
    """

    def __init__(self, data):
        """
        Initialize Data List
        :param data:list
        """
        self.data = list(data)

    def _check(self):
        if len(self.data) == 0:
            raise ValueError("data list is empty")

    def get_sum(self):
        self._check()
        s = 0
        for v in self.data:
            s += v
        return int(s) if isinstance(s, (int,)) or float(s).is_integer() else float(s)

    def get_min(self):
        self._check()
        m = self.data[0]
        for v in self.data:
            if v < m:
                m = v
        return int(m) if (isinstance(m, (int,)) or float(m).is_integer()) else float(m)

    def get_max(self):
        self._check()
        M = self.data[0]
        for v in self.data:
            if v > M:
                M = v
        return int(M) if (isinstance(M, (int,)) or float(M).is_integer()) else float(M)

    def get_variance(self):
        self._check()
        # use population variance
        var = pvariance(self.data)
        return round(var, 2)

    def get_std_deviation(self):
        self._check()
        var = pvariance(self.data)
        std = math.sqrt(var)
        return round(std, 2)

    def get_correlation(self):
        self._check()
        n = len(self.data)
        if n == 1:
            return 0.0
        # compute Pearson correlation between indices (1..n) and data
        x = [i + 1 for i in range(n)]
        y = self.data
        mx = mean(x)
        my = mean(y)
        num = 0.0
        sx = 0.0
        sy = 0.0
        for xi, yi in zip(x, y):
            dx = xi - mx
            dy = yi - my
            num += dx * dy
            sx += dx * dx
            sy += dy * dy
        if sx == 0 or sy == 0:
            return 0.0
        corr = num / math.sqrt(sx * sy)
        return float(corr)