import numpy as np
from math import isclose

class KappaCalculator:
    """
    This is a class as KappaCalculator, supporting to calculate Cohen's and Fleiss' kappa coefficient.
    """

    @staticmethod
    def kappa(testData, k):
        # defensive: accept flat lists
        arr = np.array(testData, dtype=float)
        if arr.size == 0:
            return 0.0
        if arr.ndim == 1:
            if arr.size == k * k:
                arr = arr.reshape((k, k))
            else:
                raise ValueError("testData must be k x k")
        if arr.shape != (k, k):
            raise ValueError("testData must be k x k")
        total = arr.sum()
        if total == 0:
            return 0.0
        obs = np.trace(arr) / total
        r = arr.sum(axis=1) / total
        c = arr.sum(axis=0) / total
        exp = (r * c).sum()
        if isclose(1.0, exp):
            return 1.0 if isclose(obs, exp) else 0.0
        return (obs - exp) / (1.0 - exp)

    @staticmethod
    def fleiss_kappa(testData, N, k, n):
        arr = np.array(testData, dtype=float)
        if arr.size == 0:
            return 0.0
        if arr.ndim == 1:
            if arr.size == N * k:
                arr = arr.reshape((N, k))
            else:
                raise ValueError("testData must be N x k")
        if arr.shape != (N, k):
            raise ValueError("testData must be N x k")
        # compute Pj
        sum_sq = (arr * arr).sum(axis=1)
        if n <= 1:
            Pbar = 0.0
        else:
            Pj = (sum_sq - n) / (n * (n - 1))
            Pbar = float(Pj.mean())
        pk = arr.sum(axis=0) / (N * n)
        Pe = float((pk * pk).sum())
        if isclose(1.0, Pe):
            return 1.0 if isclose(Pbar, Pe) else 0.0
        return (Pbar - Pe) / (1.0 - Pe)