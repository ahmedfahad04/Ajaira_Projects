import sqlite3

class MovieTicketDB:
    """
    This is a class for movie database operations, which allows for inserting movie information, searching for movie information by name, and deleting movie information by name.
    """

    def __init__(self, db_name):
        self.db_name = db_name
        self.connection = sqlite3.connect(db_name)
        self.connection.row_factory = sqlite3.Row
        self.cursor = self.connection.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute(
            """CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                movie_name TEXT NOT NULL,
                theater_name TEXT,
                seat_number TEXT,
                customer_name TEXT
            )"""
        )
        self.connection.commit()

    def insert_ticket(self, movie_name, theater_name, seat_number, customer_name):
        cur = self.connection.cursor()
        cur.execute(
            "INSERT INTO tickets (movie_name, theater_name, seat_number, customer_name) VALUES (?, ?, ?, ?)",
            (movie_name, theater_name, seat_number, customer_name)
        )
        self.connection.commit()
        return cur.lastrowid

    def search_tickets_by_customer(self, customer_name):
        cur = self.connection.cursor()
        cur.execute(
            "SELECT id, movie_name, theater_name, seat_number, customer_name FROM tickets WHERE customer_name = ?",
            (customer_name,)
        )
        rows = cur.fetchall()
        result = []
        for r in rows:
            result.append({k: r[k] for k in r.keys()})
        return result

    def delete_ticket(self, ticket_id):
        cur = self.connection.cursor()
        cur.execute("DELETE FROM tickets WHERE id = ?", (ticket_id,))
        self.connection.commit()
        return cur.rowcount

    def __del__(self):
        try:
            self.connection.close()
        except Exception:
            pass

# Classification response:
# temporary variable; accumulator list; dict comprehension; try-except wrapper; error suppression; standard library helper; input validation; literal rewrite; behavior change