import re

class JobMarketplace:
    """
    This is a class that provides functionalities to publish positions, remove positions, submit resumes, withdraw resumes, search for positions, and obtain candidate information.
    """

    def __init__(self):
        self.job_listings = []
        self.resumes = []

    def post_job(self, job_title, company, requirements):
        """
        This function is used to publish positions,and add the position information to the job_listings list.
        """
        self.job_listings.append({'job_title': job_title, 'company': company, 'requirements': list(requirements) if requirements is not None else []})

    def remove_job(self, job):
        """
        This function is used to remove positions,and remove the position information from the job_listings list.
        """
        # Remove by regex-safe matching of fields
        jt = job.get('job_title') if isinstance(job, dict) else None
        co = job.get('company') if isinstance(job, dict) else None
        req = job.get('requirements') if isinstance(job, dict) else None
        new_list = []
        for j in self.job_listings:
            if jt is not None and co is not None and req is not None and j.get('job_title') == jt and j.get('company') == co and j.get('requirements') == req:
                continue
            if j == job:
                continue
            new_list.append(j)
        self.job_listings = new_list

    def submit_resume(self, name, skills, experience):
        """
        This function is used to submit resumes,and add the resume information to the resumes list.
        """
        self.resumes.append({'name': name, 'skills': list(skills) if skills is not None else [], 'experience': experience})

    def withdraw_resume(self, resume):
        """
        This function is used to withdraw resumes,and remove the resume information from the resumes list.
        """
        new_res = []
        for r in self.resumes:
            if r == resume:
                continue
            # also allow matching by fields
            if isinstance(resume, dict) and r.get('name') == resume.get('name') and r.get('skills') == resume.get('skills') and r.get('experience') == resume.get('experience'):
                continue
            new_res.append(r)
        self.resumes = new_res

    def search_jobs(self, criteria):
        """
        This function is used to search for positions,and return the position information that meets the requirements.
        """
        if criteria is None:
            return []
        pattern = re.compile(re.escape(str(criteria)), re.IGNORECASE)
        matched = []
        for j in self.job_listings:
            if pattern.search(j.get('job_title') or '') or pattern.search(j.get('company') or ''):
                matched.append(j)
                continue
            for req in j.get('requirements', []):
                if pattern.fullmatch(str(req)):
                    matched.append(j)
                    break
        return matched

    def get_job_applicants(self, job):
        """
        This function is used to obtain candidate information,and return the candidate information that meets the requirements by calling the matches_requirements function.
        """
        def matches_requirements(job_info, resume):
            job_reqs = [str(x).strip().lower() for x in (job_info.get('requirements') or [])]
            skills = [str(x).strip().lower() for x in (resume.get('skills') or [])]
            return all(req in skills for req in job_reqs)

        return [r for r in self.resumes if matches_requirements(job, r)]