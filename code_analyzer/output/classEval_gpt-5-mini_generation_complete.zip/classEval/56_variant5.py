class MetricsCalculator:
    """
    The class calculates precision, recall, F1 score, and accuracy based on predicted and true labels.
    """

    def __init__(self):
        """
        Initialize the number of all four samples to 0
        """
        self.true_positives = 0
        self.false_positives = 0
        self.false_negatives = 0
        self.true_negatives = 0

    def update(self, predicted_labels, true_labels):
        """
        Update internal counters. Accepts lists and updates cumulative counts.
        """
        for p, t in zip(predicted_labels, true_labels):
            if p == 1 and t == 1:
                self.true_positives += 1
            elif p == 1 and t != 1:
                self.false_positives += 1
            elif p != 1 and t == 1:
                self.false_negatives += 1
            else:
                self.true_negatives += 1

    def _compute(self, predicted_labels=None, true_labels=None):
        """
        If lists provided, compute counts for those lists.
        If None provided, use internal cumulative counters.
        """
        if predicted_labels is None or true_labels is None:
            tp = self.true_positives
            fp = self.false_positives
            fn = self.false_negatives
            tn = self.true_negatives
            return tp, fp, fn, tn
        tp = fp = fn = tn = 0
        for p, t in zip(predicted_labels, true_labels):
            if p == 1 and t == 1:
                tp += 1
            elif p == 1 and t != 1:
                fp += 1
            elif p != 1 and t == 1:
                fn += 1
            else:
                tn += 1
        return tp, fp, fn, tn

    def precision(self, predicted_labels, true_labels):
        tp, fp, _, _ = self._compute(predicted_labels, true_labels)
        return float(tp) / (tp + fp) if (tp + fp) > 0 else 0.0

    def recall(self, predicted_labels, true_labels):
        tp, _, fn, _ = self._compute(predicted_labels, true_labels)
        return float(tp) / (tp + fn) if (tp + fn) > 0 else 0.0

    def f1_score(self, predicted_labels, true_labels):
        p = self.precision(predicted_labels, true_labels)
        r = self.recall(predicted_labels, true_labels)
        return 2.0 * p * r / (p + r) if (p + r) > 0 else 0.0

    def accuracy(self, predicted_labels, true_labels):
        tp, fp, fn, tn = self._compute(predicted_labels, true_labels)
        total = tp + fp + fn + tn
        return float(tp + tn) / total if total > 0 else 0.0

# Classification response:
# variable renaming; helper function extraction; guard clause; conditional expression; tuple unpacking; temporary variable; type conversion; behavior change