import random
from collections import deque

class MahjongConnect:
    def __init__(self, BOARD_SIZE, ICONS):
        self.BOARD_SIZE = BOARD_SIZE
        self.ICONS = ICONS
        self.board = self.create_board()

    def create_board(self):
        rows, cols = self.BOARD_SIZE
        # Create board with random distribution but ensure variety
        board = [[random.choice(self.ICONS) for _ in range(cols)] for _ in range(rows)]
        return board

    def in_bounds(self, x, y):
        return 0 <= x < self.BOARD_SIZE[0] and 0 <= y < self.BOARD_SIZE[1]

    def is_valid_move(self, pos1, pos2):
        if not (isinstance(pos1, tuple) and isinstance(pos2, tuple)):
            return False
        if pos1 == pos2:
            return False
        x1,y1 = pos1
        x2,y2 = pos2
        if not (self.in_bounds(x1,y1) and self.in_bounds(x2,y2)):
            return False
        if self.board[x1][y1] == ' ' or self.board[x2][y2] == ' ':
            return False
        if self.board[x1][y1] != self.board[x2][y2]:
            return False
        return self.has_path(pos1,pos2)

    def has_path(self, pos1, pos2):
        # BFS in an implicit grid with an extra outer border so paths can go around edges
        rows, cols = self.BOARD_SIZE
        # build padded view function
        def cell(px,py):
            # px,py are padded coords: 0..rows+1, 0..cols+1
            if px == 0 or py == 0 or px == rows+1 or py == cols+1:
                return ' '  # outside border is empty
            return self.board[px-1][py-1]
        x1,y1 = pos1
        x2,y2 = pos2
        # convert to padded coords
        sx,sy = x1+1,y1+1
        tx,ty = x2+1,y2+1
        if (sx,sy) == (tx,ty):
            return False
        # BFS with direction and turns
        dirs = [(-1,0),(0,1),(1,0),(0,-1)]
        from collections import deque
        dq = deque()
        visited = dict()
        # start from source, go outward in straight lines
        for d_idx,(dx,dy) in enumerate(dirs):
            nx,ny = sx+dx, sy+dy
            while 0 <= nx < rows+2 and 0 <= ny < cols+2 and (cell(nx,ny) == ' ' or (nx,ny)==(tx,ty)):
                key = (nx,ny,d_idx)
                if visited.get(key, 99) > 0:
                    visited[key] = 0
                    dq.append((nx,ny,d_idx,0))
                if (nx,ny) == (tx,ty):
                    return True
                nx += dx; ny += dy
        while dq:
            x,y,d,turns = dq.popleft()
            if turns > 2:
                continue
            if (x,y) == (tx,ty):
                return True
            for nd,(dx,dy) in enumerate(dirs):
                nturns = turns + (0 if nd==d else 1)
                if nturns > 2:
                    continue
                nx,ny = x+dx,y+dy
                while 0 <= nx < rows+2 and 0 <= ny < cols+2 and (cell(nx,ny) == ' ' or (nx,ny)==(tx,ty)):
                    key = (nx,ny,nd)
                    if visited.get(key, 99) > nturns:
                        visited[key] = nturns
                        if (nx,ny) == (tx,ty):
                            return True
                        dq.append((nx,ny,nd,nturns))
                    nx += dx; ny += dy
        return False

    def remove_icons(self, pos1, pos2):
        if self.is_valid_move(pos1,pos2):
            x1,y1 = pos1
            x2,y2 = pos2
            self.board[x1][y1] = ' '
            self.board[x2][y2] = ' '

    def is_game_over(self):
        for r in self.board:
            for c in r:
                if c != ' ':
                    return False
        return True

# Classification response:
# helper function extraction; early return; guard clause; loop rewrite; while loop; queue-based; graph traversal; accumulator dict; dictionary lookup; tuple unpacking; temporary variable; import reorganization; standard library helper; input validation; behavior change