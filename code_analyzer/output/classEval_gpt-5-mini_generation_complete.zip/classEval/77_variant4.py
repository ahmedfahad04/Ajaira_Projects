import random

class Snake:
    """
    The class is a snake game, with allows snake to move and eat food, and also enables to reset, and generat a random food position.
    This implementation precomputes grid cells and uses choice from them.
    """

    def __init__(self, SCREEN_WIDTH, SCREEN_HEIGHT, BLOCK_SIZE, food_position):
        self.SCREEN_WIDTH = int(SCREEN_WIDTH)
        self.SCREEN_HEIGHT = int(SCREEN_HEIGHT)
        self.BLOCK_SIZE = int(BLOCK_SIZE)
        self.cols = max(1, self.SCREEN_WIDTH // self.BLOCK_SIZE)
        self.rows = max(1, self.SCREEN_HEIGHT // self.BLOCK_SIZE)
        self.grid = [(i * self.BLOCK_SIZE, j * self.BLOCK_SIZE) for i in range(self.cols) for j in range(self.rows)]
        self.length = 1
        self.positions = [self._center()]
        self.score = 0
        self.food_position = self._snap(food_position)
        if self.food_position in self.positions:
            self.random_food_position()

    def _center(self):
        cx = int(self.SCREEN_WIDTH / 2)
        cy = int(self.SCREEN_HEIGHT / 2)
        cx = (cx // self.BLOCK_SIZE) * self.BLOCK_SIZE
        cy = (cy // self.BLOCK_SIZE) * self.BLOCK_SIZE
        cx = max(0, min(cx, self.SCREEN_WIDTH - self.BLOCK_SIZE))
        cy = max(0, min(cy, self.SCREEN_HEIGHT - self.BLOCK_SIZE))
        return (cx, cy)

    def _snap(self, pos):
        x, y = int(pos[0]), int(pos[1])
        x = (x // self.BLOCK_SIZE) * self.BLOCK_SIZE
        y = (y // self.BLOCK_SIZE) * self.BLOCK_SIZE
        x = max(0, min(x, self.SCREEN_WIDTH - self.BLOCK_SIZE))
        y = max(0, min(y, self.SCREEN_HEIGHT - self.BLOCK_SIZE))
        return (x, y)

    def move(self, direction):
        dx = int(direction[0]) * self.BLOCK_SIZE
        dy = int(direction[1]) * self.BLOCK_SIZE
        hx, hy = self.positions[0]
        nx = (hx + dx) % self.SCREEN_WIDTH
        ny = (hy + dy) % self.SCREEN_HEIGHT
        nx = (nx // self.BLOCK_SIZE) * self.BLOCK_SIZE
        ny = (ny // self.BLOCK_SIZE) * self.BLOCK_SIZE
        new_head = (nx, ny)
        # self collision
        if new_head in self.positions:
            self.reset()
            return
        # add head
        self.positions.insert(0, new_head)
        if new_head == self.food_position:
            self.eat_food()
        else:
            # keep tail trimmed
            while len(self.positions) > self.length:
                self.positions.pop()

    def random_food_position(self):
        choices = [cell for cell in self.grid if cell not in self.positions]
        if not choices:
            return
        self.food_position = random.choice(choices)

    def reset(self):
        self.length = 1
        self.positions = [self._center()]
        self.score = 0
        self.random_food_position()

    def eat_food(self):
        self.length += 1
        self.score += 100
        self.random_food_position()