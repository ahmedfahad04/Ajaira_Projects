import threading

class BankAccount:
    """
    Thread-safe BankAccount using a lock for operations.
    """

    def __init__(self, balance=0):
        if not isinstance(balance, (int, float)):
            raise TypeError("Balance must be numeric")
        self._lock = threading.RLock()
        self._balance = balance

    def deposit(self, amount):
        if not isinstance(amount, (int, float)):
            raise TypeError("Amount must be numeric")
        if amount < 0:
            raise ValueError("Invalid amount")
        with self._lock:
            self._balance += amount
            return self._balance

    def withdraw(self, amount):
        if not isinstance(amount, (int, float)):
            raise TypeError("Amount must be numeric")
        if amount < 0:
            raise ValueError("Invalid amount")
        with self._lock:
            if amount > self._balance:
                raise ValueError("Insufficient balance.")
            self._balance -= amount
            return self._balance

    def view_balance(self):
        with self._lock:
            return self._balance

    def transfer(self, other_account, amount):
        if not isinstance(other_account, BankAccount):
            raise TypeError("other_account must be a BankAccount")
        if not isinstance(amount, (int, float)):
            raise TypeError("Amount must be numeric")
        if amount < 0:
            raise ValueError("Invalid amount")
        # Acquire both locks in a consistent order to avoid deadlock
        first, second = (self, other_account) if id(self) < id(other_account) else (other_account, self)
        with first._lock:
            with second._lock:
                if amount > self._balance:
                    raise ValueError("Insufficient balance.")
                self._balance -= amount
                other_account._balance += amount
                return (self._balance, other_account._balance)