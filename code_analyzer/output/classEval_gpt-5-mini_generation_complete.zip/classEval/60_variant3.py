import sqlite3

class MovieTicketDB:
    """
    This is a class for movie database operations, which allows for inserting movie information, searching for movie information by name, and deleting movie information by name.
    """

    def __init__(self, db_name):
        self.db_name = db_name
        self.connection = sqlite3.connect(db_name)
        self.cursor = self.connection.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute(
            "CREATE TABLE IF NOT EXISTS tickets ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "movie_name TEXT NOT NULL, "
            "theater_name TEXT, "
            "seat_number TEXT, "
            "customer_name TEXT COLLATE NOCASE)"
        )
        self.connection.commit()

    def insert_ticket(self, movie_name, theater_name, seat_number, customer_name):
        self.cursor.execute(
            "INSERT INTO tickets (movie_name, theater_name, seat_number, customer_name) VALUES (?, ?, ?, ?)",
            (movie_name, theater_name, seat_number, customer_name)
        )
        self.connection.commit()

    def search_tickets_by_customer(self, customer_name):
        like_pattern = f"%{customer_name}%"
        self.cursor.execute(
            "SELECT id, movie_name, theater_name, seat_number, customer_name FROM tickets WHERE customer_name LIKE ? COLLATE NOCASE",
            (like_pattern,)
        )
        return self.cursor.fetchall()

    def delete_ticket(self, ticket_id):
        self.cursor.execute("DELETE FROM tickets WHERE id = ?", (ticket_id,))
        self.connection.commit()

# Classification response:
# state variable; temporary variable; string formatting change; literal rewrite; behavior change