import itertools
import math

class ArrangementCalculator:
    """
    The Arrangement class provides permutation calculations and selection operations for a given set of data elements.
    """

    def __init__(self, datas):
        """
        Initializes the ArrangementCalculator object with a list of datas.
        :param datas: List, the data elements to be used for arrangements.
        """
        self.datas = list(datas)

    @staticmethod
    def count(n, m=None):
        """
        Counts the number of arrangements by choosing m items from n items (permutations).
        If m is not provided or n equals m, returns factorial(n).
        """
        if n < 0:
            return 0
        if m is None or m == n:
            return math.factorial(n) if n >= 0 else 0
        if m < 0 or m > n:
            return 0
        return math.factorial(n) // math.factorial(n - m)

    @staticmethod
    def count_all(n):
        """
        Counts the total number of all possible arrangements by choosing at least 1 item and at most n items from n items.
        """
        if n <= 0:
            return 0
        total = 0
        for k in range(1, n + 1):
            total += ArrangementCalculator.count(n, k)
        return total

    def select(self, m=None):
        """
        Generates a list of arrangements by selecting m items from the internal datas.
        If m is not provided, selects all items.
        """
        n = len(self.datas)
        if m is None:
            m = n
        if m < 0 or m > n:
            return []
        return [list(p) for p in itertools.permutations(self.datas, m)]

    def select_all(self):
        """
        Generates a list of all arrangements by selecting at least 1 item and at most the number of internal datas.
        """
        results = []
        n = len(self.datas)
        for k in range(1, n + 1):
            results.extend([list(p) for p in itertools.permutations(self.datas, k)])
        return results

    @staticmethod
    def factorial(n):
        """
        Calculates the factorial of a given number.
        """
        if n < 0:
            raise ValueError("Negative factorial is not defined")
        return math.factorial(n)