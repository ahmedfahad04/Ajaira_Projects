import datetime
import time
import calendar

class TimeUtils:
    """
    This is a time util class, including getting the current time and date, adding seconds to a datetime, converting between strings and datetime objects, calculating the time difference in minutes, and formatting a datetime object.
    """

    def __init__(self):
        self.datetime = datetime.datetime.now()

    def get_current_time(self):
        now = datetime.datetime.now()
        return "{:02d}:{:02d}:{:02d}".format(now.hour, now.minute, now.second)

    def get_current_date(self):
        now = datetime.datetime.now()
        return "{:04d}-{:02d}-{:02d}".format(now.year, now.month, now.day)

    def add_seconds(self, seconds):
        # operate on timestamp for robustness
        if not isinstance(seconds, (int, float)):
            raise TypeError("seconds must be numeric")
        ts = time.mktime(self.datetime.timetuple()) + seconds
        lt = time.localtime(ts)
        return "{:02d}:{:02d}:{:02d}".format(lt.tm_hour, lt.tm_min, lt.tm_sec)

    def string_to_datetime(self, string):
        # Try to parse with strptime first, allowing common formats
        formats = ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"]
        for fmt in formats:
            try:
                return datetime.datetime.strptime(string, fmt)
            except Exception:
                continue
        # Fallback: split non-digit separators
        parts = [int(p) for p in __import__("re").split(r"[^0-9]+", string) if p != ""]
        if len(parts) >= 3:
            parts += [0] * (6 - len(parts))
            y, m, d, h, mi, s = parts[:6]
            return datetime.datetime(y, m, d, h, mi, s)
        raise ValueError("unrecognized datetime string")

    def datetime_to_string(self, datetime):
        return "{:04d}-{:02d}-{:02d} {:02d}:{:02d}:{:02d}".format(
            datetime.year, datetime.month, datetime.day, datetime.hour, datetime.minute, datetime.second
        )

    def get_minutes(self, string_time1, string_time2):
        dt1 = self.string_to_datetime(string_time1)
        dt2 = self.string_to_datetime(string_time2)
        seconds = (dt2 - dt1).total_seconds()
        # round to nearest minute (ties to nearest even by default, so add small epsilon)
        return int(round(seconds / 60.0))

    def get_format_time(self, year, month, day, hour, minute, second):
        y, mo, d, h, mi, s = map(int, (year, month, day, hour, minute, second))
        return "{:04d}-{:02d}-{:02d} {:02d}:{:02d}:{:02d}".format(y, mo, d, h, mi, s)