class SQLQueryBuilder:
    """
    This class provides to build SQL queries, including SELECT, INSERT, UPDATE, and DELETE statements. 
    """

    @staticmethod
    def _quote(value):
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "'1'" if value else "'0'"
        txt = str(value).replace("'", "''")
        return f"'{txt}'"

    @staticmethod
    def select(table, columns='*', where=None):
        if isinstance(columns, (list, tuple)):
            columns = ", ".join(columns) if columns else "*"
        sql = f"SELECT {columns} FROM {table}"
        if where:
            conditions = []
            for k in where:
                conditions.append(f"{k}={SQLQueryBuilder._quote(where[k])}")
            sql += " WHERE " + " AND ".join(conditions)
        return sql

    @staticmethod
    def insert(table, data):
        keys = list(data.keys())
        vals = [SQLQueryBuilder._quote(data[k]) for k in keys]
        return f"INSERT INTO {table} ({', '.join(keys)}) VALUES ({', '.join(vals)})"

    @staticmethod
    def delete(table, where=None):
        sql = f"DELETE FROM {table}"
        if where:
            parts = [f"{k}={SQLQueryBuilder._quote(v)}" for k, v in where.items()]
            sql += " WHERE " + " AND ".join(parts)
        return sql

    @staticmethod
    def update(table, data, where=None):
        sets = [f"{k}={SQLQueryBuilder._quote(v)}" for k, v in data.items()]
        sql = f"UPDATE {table} SET {', '.join(sets)}"
        if where:
            parts = [f"{k}={SQLQueryBuilder._quote(v)}" for k, v in where.items()]
            sql += " WHERE " + " AND ".join(parts)
        return sql