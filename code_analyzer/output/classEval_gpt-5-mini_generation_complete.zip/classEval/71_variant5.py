class PushBoxGame:
    """
    This class implements a functionality of a sokoban game, where the player needs to move boxes to designated targets in order to win.
    """
    def __init__(self, map):
        self.map = map
        self.player_row = 0
        self.player_col = 0
        self.targets = []
        self.boxes = []
        self.target_count = 0
        self.is_game_over = False
        self._rows = len(map)
        self._cols = len(map[0]) if self._rows else 0
        self.init_game()

    def init_game(self):
        self.targets = []
        self.boxes = []
        for r in range(self._rows):
            for c in range(self._cols):
                ch = self.map[r][c]
                if ch == 'O':
                    self.player_row, self.player_col = r, c
                elif ch == 'G':
                    self.targets.append((r, c))
                elif ch == 'X':
                    self.boxes.append((r, c))
        self._targets = set(self.targets)
        self._boxes = set(self.boxes)
        self.target_count = len(self.targets)
        self.is_game_over = self.check_win()

    def check_win(self):
        # If there are no boxes but there are targets, it's not a win. Win only if every box sits on a target.
        self.is_game_over = all(b in self._targets for b in self._boxes)
        return self.is_game_over

    def move(self, direction):
        if self.is_game_over:
            return True
        moves = {'w': (-1, 0), 's': (1, 0), 'a': (0, -1), 'd': (0, 1)}
        if direction not in moves:
            return self.is_game_over
        dr, dc = moves[direction]
        new_r, new_c = self.player_row + dr, self.player_col + dc
        # bounds
        if not (0 <= new_r < self._rows and 0 <= new_c < self._cols):
            return self.is_game_over
        if self.map[new_r][new_c] == '#':
            return self.is_game_over
        # if there's a box, attempt push
        if (new_r, new_c) in self._boxes:
            push_r, push_c = new_r + dr, new_c + dc
            if not (0 <= push_r < self._rows and 0 <= push_c < self._cols):
                return self.is_game_over
            if self.map[push_r][push_c] == '#':
                return self.is_game_over
            if (push_r, push_c) in self._boxes:
                return self.is_game_over
            # perform push
            self._boxes.remove((new_r, new_c))
            self._boxes.add((push_r, push_c))
        # move player
        self.player_row, self.player_col = new_r, new_c
        self.boxes = list(self._boxes)
        return self.check_win()

# Classification response:
# guard clause; flattened conditional; set conversion; list conversion; tuple unpacking; state variable; any/all usage; dictionary lookup; membership test; in-place mutation; boundary case handling