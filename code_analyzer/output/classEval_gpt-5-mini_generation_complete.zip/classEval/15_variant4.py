class BoyerMooreSearch:
    """
    his is a class that implements the Boyer-Moore algorithm for string searching, which is used to find occurrences of a pattern within a given text.
    """

    def __init__(self, text, pattern):
        """
        Initializes the BoyerMooreSearch class with the given text and pattern.
        :param text: The text to be searched, str.
        :param pattern: The pattern to be searched for, str.
        """
        self.text, self.pattern = text, pattern
        self.textLen, self.patLen = len(text), len(pattern)
        # build last occurrence table, default -1 for chars not in pattern
        self._last = {}
        for i, ch in enumerate(pattern):
            self._last[ch] = i

    def match_in_pattern(self, char):
        """
        Finds the rightmost occurrence of a character in the pattern.
        """
        return self._last[char] if char in self._last else -1

    def mismatch_in_text(self, currentPos):
        """
        Determines the position of the first dismatch between the pattern and the text.
        """
        if self.patLen == 0:
            return -1
        # compare from the rightmost character to leftmost
        idx = self.patLen - 1
        while idx >= 0:
            if currentPos + idx >= self.textLen or self.pattern[idx] != self.text[currentPos + idx]:
                return idx
            idx -= 1
        return -1

    def bad_character_heuristic(self):
        """
        Finds all occurrences of the pattern in the text.
        """
        if self.patLen == 0:
            return list(range(self.textLen + 1))
        results = []
        i = 0
        while i <= self.textLen - self.patLen:
            j = self.mismatch_in_text(i)
            if j == -1:
                results.append(i)
                # determine shift by last occurrence of char at end of window
                end_char = self.text[i + self.patLen - 1]
                last = self._last.get(end_char, -1)
                shift = self.patLen - last
                if shift <= 0:
                    shift = 1
                i += shift
            else:
                bad_char = self.text[i + j]
                last = self._last.get(bad_char, -1)
                shift = j - last
                if shift <= 0:
                    shift = 1
                i += shift
        return results