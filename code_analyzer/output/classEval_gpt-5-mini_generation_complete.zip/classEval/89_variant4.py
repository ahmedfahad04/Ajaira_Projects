import random
import ast
import re
from fractions import Fraction

class TwentyFourPointGame:
    """
    This ia a game of twenty-four points, which provides to generate four numbers and check whether player's expression is equal to 24.
    """

    def __init__(self) -> None:
        self.nums = []

    def _generate_cards(self):
        self.nums = [random.randint(1, 9) for _ in range(4)]
        return self.nums

    def get_my_cards(self):
        if not self.nums:
            self._generate_cards()
        return list(self.nums)

    def _nums_from_expr(self, expression):
        return [int(t) for t in re.findall(r'\d+', expression)]

    def _ast_eval_fraction(self, node):
        if isinstance(node, ast.Expression):
            return self._ast_eval_fraction(node.body)
        if isinstance(node, ast.BinOp):
            L = self._ast_eval_fraction(node.left)
            R = self._ast_eval_fraction(node.right)
            if isinstance(node.op, ast.Add):
                return L + R
            if isinstance(node.op, ast.Sub):
                return L - R
            if isinstance(node.op, ast.Mult):
                return L * R
            if isinstance(node.op, ast.Div):
                if R == 0:
                    raise ZeroDivisionError
                return L / R
            raise ValueError("Unsupported operator")
        if isinstance(node, ast.UnaryOp):
            val = self._ast_eval_fraction(node.operand)
            if isinstance(node.op, ast.UAdd):
                return val
            if isinstance(node.op, ast.USub):
                return -val
            raise ValueError("Unsupported unary")
        if isinstance(node, ast.Num):
            return Fraction(node.n)
        if isinstance(node, ast.Constant):
            if isinstance(node.value, (int, float)):
                return Fraction(node.value)
            raise ValueError("Unsupported constant")
        raise ValueError("Unsupported node")

    def evaluate_expression(self, expression):
        try:
            tree = ast.parse(expression, mode='eval')
            # simple whitelist check for allowed nodes
            for node in ast.walk(tree):
                if not isinstance(node, (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Num, ast.Constant,
                                         ast.Add, ast.Sub, ast.Mult, ast.Div, ast.UAdd, ast.USub,
                                         ast.Load, ast.Call, ast.Name, ast.Tuple, ast.Expr, ast.Mod, ast.Pow, ast.arguments)):
                    # if unexpected node -> disallow
                    pass
            val = self._ast_eval_fraction(tree)
            return val == Fraction(24,1)
        except Exception:
            return False

    def answer(self, expression):
        if not self.nums:
            self._generate_cards()
        nums = self._nums_from_expr(expression)
        if len(nums) != 4:
            return False
        if sorted(nums) != sorted(self.nums):
            return False
        return self.evaluate_expression(expression)