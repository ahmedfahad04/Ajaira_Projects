from functools import reduce
from operator import add

class DiscountStrategy:
    """
    This is a class that allows to use different discount strategy based on shopping credit or shopping cart in supermarket.
    Functional/reduce style.
    """

    def __init__(self, customer, cart, promotion=None):
        self.customer = customer or {}
        self.cart = list(cart) if cart is not None else []
        self.promotion = promotion
        # call total to align with skeleton
        self.total()

    def total(self):
        def item_total(acc, item):
            return acc + item.get('quantity', 0) * item.get('price', 0.0)
        total = reduce(item_total, self.cart, 0.0)
        # store as attribute for quick access
        self._cached_total = float(total)
        return self._cached_total

    def due(self):
        total = getattr(self, '_cached_total', self.total())
        disp = 0.0
        if callable(self.promotion):
            disp = float(self.promotion(self))
        return total - disp

    @staticmethod
    def FidelityPromo(order):
        fidelity = order.customer.get('fidelity', 0)
        if fidelity > 1000:
            return order.total() * 0.05
        return 0.0

    @staticmethod
    def BulkItemPromo(order):
        # sum discounts per item where quantity >= 20
        return sum((item.get('quantity', 0) * item.get('price', 0.0) * 0.10)
                   for item in order.cart if item.get('quantity', 0) >= 20)

    @staticmethod
    def LargeOrderPromo(order):
        # number of distinct product names
        products = {item.get('product') for item in order.cart if 'product' in item}
        if len(products) >= 10:
            return order.total() * 0.07
        return 0.0