import re

class SplitSentence:
    """
    The class allows to split sentences, count words in a sentence, and process a text file to find the maximum word count.
    """

    def split_sentences(self, sentences_string):
        s = sentences_string or ""
        # initial greedy split on punctuation + following space or end
        parts = re.findall(r'.+?[\.?](?:\s|$)|.+$', s)
        # merge parts that end with abbreviations like "Mr." etc.
        abbrevs = {"Mr", "Mrs", "Dr", "Ms", "Jr", "Sr", "St"}
        results = []
        i = 0
        while i < len(parts):
            part = parts[i].strip()
            if not part:
                i += 1
                continue
            # if this part ends with a dot and the last word is an abbreviation, merge with next
            m = re.search(r'([A-Za-z]+)\.$', part)
            if m and m.group(1) in abbrevs and i + 1 < len(parts):
                # merge current and next
                merged = (part + " " + parts[i+1]).strip()
                parts[i+1] = merged
                i += 1
                continue
            results.append(part)
            i += 1
        return results

    def count_words(self, sentence):
        if not sentence:
            return 0
        # words are separated by spaces; count tokens composed only of letters
        tokens = sentence.split()
        count = 0
        for t in tokens:
            if re.fullmatch(r'[A-Za-z]+', t):
                count += 1
        return count

    def process_text_file(self, sentences_string):
        sentences = self.split_sentences(sentences_string)
        if not sentences:
            return 0
        return max(self.count_words(s) for s in sentences)