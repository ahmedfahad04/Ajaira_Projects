import datetime
import time

class TimeUtils:
    """
    This is a time util class, including getting the current time and date, adding seconds to a datetime, converting between strings and datetime objects, calculating the time difference in minutes, and formatting a datetime object.
    """

    def __init__(self):
        """
        Get the current datetime
        """
        self.datetime = datetime.datetime.now()

    def get_current_time(self):
        now = datetime.datetime.now()
        return "%02d:%02d:%02d" % (now.hour, now.minute, now.second)

    def get_current_date(self):
        now = datetime.datetime.now()
        return "%04d-%02d-%02d" % (now.year, now.month, now.day)

    def add_seconds(self, seconds):
        if not isinstance(seconds, (int, float)):
            raise TypeError("seconds must be numeric")
        dt = self.datetime + datetime.timedelta(seconds=seconds)
        return "%02d:%02d:%02d" % (dt.hour, dt.minute, dt.second)

    def string_to_datetime(self, string):
        # Try basic strptime
        try:
            return datetime.datetime.strptime(string, "%Y-%m-%d %H:%M:%S")
        except Exception:
            pass
        # Try lenient parsing by splitting and filling
        parts = string.strip().split()
        date_parts = parts[0].split('-')
        y = int(date_parts[0])
        m = int(date_parts[1]) if len(date_parts) > 1 else 1
        d = int(date_parts[2]) if len(date_parts) > 2 else 1
        h = m2 = s = 0
        h = 0
        if len(parts) > 1:
            tparts = parts[1].split(':')
            h = int(tparts[0]) if len(tparts) > 0 and tparts[0] != '' else 0
            m2 = int(tparts[1]) if len(tparts) > 1 and tparts[1] != '' else 0
            s = int(tparts[2]) if len(tparts) > 2 and tparts[2] != '' else 0
        return datetime.datetime(y, m, d, h, m2, s)

    def datetime_to_string(self, datetime):
        return "%04d-%02d-%02d %02d:%02d:%02d" % (
            datetime.year, datetime.month, datetime.day, datetime.hour, datetime.minute, datetime.second
        )

    def get_minutes(self, string_time1, string_time2):
        dt1 = self.string_to_datetime(string_time1)
        dt2 = self.string_to_datetime(string_time2)
        secs = (dt2 - dt1).total_seconds()
        # round to nearest minute
        return int(round(secs / 60.0))

    def get_format_time(self, year, month, day, hour, minute, second):
        return "%04d-%02d-%02d %02d:%02d:%02d" % (
            int(year), int(month), int(day), int(hour), int(minute), int(second)
        )