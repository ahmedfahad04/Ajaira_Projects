import random
from collections import deque

class MahjongConnect:
    def __init__(self, BOARD_SIZE, ICONS):
        self.BOARD_SIZE = BOARD_SIZE
        self.ICONS = ICONS
        self.board = self.create_board()

    def create_board(self):
        rows, cols = self.BOARD_SIZE
        # create a board with balanced pairs where possible
        cells = rows * cols
        icons_needed = []
        idx = 0
        # fill with ICONS repeated to fill
        while len(icons_needed) < cells:
            icons_needed.append(self.ICONS[idx % len(self.ICONS)])
            idx += 1
        board = []
        for r in range(rows):
            board.append(icons_needed[r*cols:(r+1)*cols])
        return board

    def in_bounds(self, x, y):
        return 0 <= x < self.BOARD_SIZE[0] and 0 <= y < self.BOARD_SIZE[1]

    def is_valid_move(self, pos1, pos2):
        if not (isinstance(pos1, tuple) and isinstance(pos2, tuple)):
            return False
        if pos1 == pos2:
            return False
        x1,y1 = pos1
        x2,y2 = pos2
        if not (self.in_bounds(x1,y1) and self.in_bounds(x2,y2)):
            return False
        if self.board[x1][y1] == ' ' or self.board[x2][y2] == ' ':
            return False
        if self.board[x1][y1] != self.board[x2][y2]:
            return False
        return self.has_path(pos1,pos2)

    def has_path(self, pos1, pos2):
        # DFS enumerating straight-line moves, limit to 2 turns
        rows, cols = self.BOARD_SIZE
        x1,y1 = pos1
        x2,y2 = pos2
        if pos1 == pos2:
            return False
        def passable(nx,ny):
            if not (0 <= nx < rows and 0 <= ny < cols):
                return False
            if (nx,ny) == (x2,y2):
                return True
            return self.board[nx][ny] == ' '
        dirs = [(-1,0),(0,1),(1,0),(0,-1)]
        visited = {}

        stack = []
        # push all straight endpoints from start (0 turns)
        for d_idx,(dx,dy) in enumerate(dirs):
            nx,ny = x1+dx,y1+dy
            while 0 <= nx < rows and 0 <= ny < cols and passable(nx,ny):
                if (nx,ny) == (x2,y2):
                    return True
                key = (nx,ny,d_idx)
                if visited.get(key, 99) > 0:
                    visited[key] = 0
                    stack.append((nx,ny,d_idx,0))
                nx+=dx; ny+=dy

        while stack:
            x,y,d,turns = stack.pop()
            if turns > 2:
                continue
            if (x,y) == (x2,y2):
                return True
            for nd,(dx,dy) in enumerate(dirs):
                new_turns = turns + (0 if nd==d else 1)
                if new_turns > 2:
                    continue
                nx,ny = x+dx,y+dy
                while 0 <= nx < rows and 0 <= ny < cols and passable(nx,ny):
                    if (nx,ny) == (x2,y2):
                        return True
                    key = (nx,ny,nd)
                    if visited.get(key, 99) > new_turns:
                        visited[key] = new_turns
                        stack.append((nx,ny,nd,new_turns))
                    nx+=dx; ny+=dy
        return False

    def remove_icons(self, pos1, pos2):
        if self.is_valid_move(pos1,pos2):
            x1,y1 = pos1
            x2,y2 = pos2
            self.board[x1][y1] = ' '
            self.board[x2][y2] = ' '

    def is_game_over(self):
        for r in self.board:
            for v in r:
                if v != ' ':
                    return False
        return True

# Classification response:
# helper function extraction;guard clause;input validation;empty input handling;accumulator list;dictionary lookup;stack-based;graph traversal;loop rewrite;tuple unpacking;behavior change;import reorganization