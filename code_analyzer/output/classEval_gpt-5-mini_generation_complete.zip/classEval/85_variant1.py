import time
import math

class Thermostat:
    """
    The class manages temperature control, including setting and retrieving the target temperature, adjusting the mode, and simulating temperature operation.
    """

    def __init__(self, current_temperature, target_temperature, mode):
        self.current_temperature = float(current_temperature)
        self.target_temperature = float(target_temperature)
        self.mode = mode

    def get_target_temperature(self):
        return self.target_temperature

    def set_target_temperature(self, temperature):
        self.target_temperature = float(temperature)

    def get_mode(self):
        return self.mode

    def set_mode(self, mode):
        if mode not in ('heat', 'cool'):
            raise ValueError("mode must be 'heat' or 'cool'")
        self.mode = mode

    def auto_set_mode(self):
        if self.current_temperature < self.target_temperature:
            self.mode = 'heat'
        else:
            self.mode = 'cool'

    def auto_check_conflict(self):
        if self.current_temperature < self.target_temperature and self.mode != 'heat':
            self.auto_set_mode()
            return False
        if self.current_temperature >= self.target_temperature and self.mode != 'cool':
            self.auto_set_mode()
            return False
        return True

    def simulate_operation(self):
        self.auto_set_mode()
        diff = abs(self.target_temperature - self.current_temperature)
        steps = math.ceil(diff)
        if steps == 0:
            return 0
        self.current_temperature = float(self.target_temperature)
        return int(steps)