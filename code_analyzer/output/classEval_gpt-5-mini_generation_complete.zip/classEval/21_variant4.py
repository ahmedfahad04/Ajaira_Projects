from datetime import datetime

class Classroom:
    def __init__(self, id):
        self.id = id
        # keep both original dicts and normalized intervals for fast checks
        self.courses = []
        self.intervals = []  # list of (start_min, end_min)

    def _to_min(self, time_str):
        dt = datetime.strptime(time_str.strip(), '%H:%M')
        return dt.hour * 60 + dt.minute

    def add_course(self, course):
        # avoid duplicate by comparing canonical tuple
        key = (course.get('name'), course.get('start_time'), course.get('end_time'))
        for c in self.courses:
            if (c.get('name'), c.get('start_time'), c.get('end_time')) == key:
                return
        self.courses.append(dict(course))
        self.intervals.append((self._to_min(course['start_time']), self._to_min(course['end_time'])))

    def remove_course(self, course):
        key = (course.get('name'), course.get('start_time'), course.get('end_time'))
        for i, c in enumerate(self.courses):
            if (c.get('name'), c.get('start_time'), c.get('end_time')) == key:
                del self.courses[i]
                del self.intervals[i]
                return

    def is_free_at(self, check_time):
        m = self._to_min(check_time)
        for s, e in self.intervals:
            if s <= m <= e:
                return False
        return True

    def check_course_conflict(self, new_course):
        ns = self._to_min(new_course['start_time'])
        ne = self._to_min(new_course['end_time'])
        for s, e in self.intervals:
            if not (ne < s or ns > e):
                return False
        return True