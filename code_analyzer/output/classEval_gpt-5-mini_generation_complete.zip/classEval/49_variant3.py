class JobMarketplace:
    """
    This is a class that provides functionalities to publish positions, remove positions, submit resumes, withdraw resumes, search for positions, and obtain candidate information.
    """

    def __init__(self):
        self.job_listings = []
        self.resumes = []

    def post_job(self, job_title, company, requirements):
        """
        This function is used to publish positions,and add the position information to the job_listings list.
        """
        self.job_listings.append({'job_title': job_title, 'company': company, 'requirements': list(requirements) if requirements is not None else []})

    def remove_job(self, job):
        """
        This function is used to remove positions,and remove the position information from the job_listings list.
        """
        # Rebuild list excluding matching job (by equality of dict contents)
        self.job_listings = [j for j in self.job_listings if not (j == job)]

    def submit_resume(self, name, skills, experience):
        """
        This function is used to submit resumes,and add the resume information to the resumes list.
        """
        self.resumes.append({'name': name, 'skills': list(skills) if skills is not None else [], 'experience': experience})

    def withdraw_resume(self, resume):
        """
        This function is used to withdraw resumes,and remove the resume information from the resumes list.
        """
        self.resumes = [r for r in self.resumes if not (r == resume)]

    def search_jobs(self, criteria):
        """
        This function is used to search for positions,and return the position information that meets the requirements.
        """
        if criteria is None:
            return []
        crit = str(criteria).lower()
        def job_matches(job):
            if crit in (job.get('job_title') or '').lower() or crit in (job.get('company') or '').lower():
                return True
            for r in job.get('requirements', []):
                if crit == str(r).lower():
                    return True
            return False
        return [j for j in self.job_listings if job_matches(j)]

    def get_job_applicants(self, job):
        """
        This function is used to obtain candidate information,and return the candidate information that meets the requirements by calling the matches_requirements function.
        """
        reqs = [str(x).lower() for x in (job.get('requirements') or [])]
        def matches(resume):
            skills = [str(x).lower() for x in (resume.get('skills') or [])]
            return all(r in skills for r in reqs)
        return [r for r in self.resumes if matches(r)]