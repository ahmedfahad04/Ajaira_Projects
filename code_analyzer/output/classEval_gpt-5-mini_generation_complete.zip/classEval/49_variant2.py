import itertools

class JobMarketplace:
    """
    This is a class that provides functionalities to publish positions, remove positions, submit resumes, withdraw resumes, search for positions, and obtain candidate information.
    """

    _job_id_counter = itertools.count(1)
    _resume_id_counter = itertools.count(1)

    def __init__(self):
        self.job_listings = []
        self.resumes = []

    def post_job(self, job_title, company, requirements):
        """
        This function is used to publish positions,and add the position information to the job_listings list.
        """
        jid = next(self._job_id_counter)
        job = {
            'id': jid,
            'job_title': job_title,
            'company': company,
            'requirements': list(requirements) if requirements is not None else []
        }
        self.job_listings.append(job)

    def remove_job(self, job):
        """
        This function is used to remove positions,and remove the position information from the job_listings list.
        """
        # Accept either a dict object (possibly from list) or a dict-like description
        target_id = job.get('id') if isinstance(job, dict) and 'id' in job else None
        if target_id is not None:
            self.job_listings = [j for j in self.job_listings if j.get('id') != target_id]
            return
        # fallback: match by fields
        jt = job.get('job_title') if isinstance(job, dict) else None
        co = job.get('company') if isinstance(job, dict) else None
        req = job.get('requirements') if isinstance(job, dict) else None
        self.job_listings = [j for j in self.job_listings if not (j.get('job_title') == jt and j.get('company') == co and j.get('requirements') == req)]

    def submit_resume(self, name, skills, experience):
        """
        This function is used to submit resumes,and add the resume information to the resumes list.
        """
        rid = next(self._resume_id_counter)
        resume = {
            'id': rid,
            'name': name,
            'skills': list(skills) if skills is not None else [],
            'experience': experience
        }
        self.resumes.append(resume)

    def withdraw_resume(self, resume):
        """
        This function is used to withdraw resumes,and remove the resume information from the resumes list.
        """
        target_id = resume.get('id') if isinstance(resume, dict) and 'id' in resume else None
        if target_id is not None:
            self.resumes = [r for r in self.resumes if r.get('id') != target_id]
            return
        nm = resume.get('name') if isinstance(resume, dict) else None
        sk = resume.get('skills') if isinstance(resume, dict) else None
        ex = resume.get('experience') if isinstance(resume, dict) else None
        self.resumes = [r for r in self.resumes if not (r.get('name') == nm and r.get('skills') == sk and r.get('experience') == ex)]

    def search_jobs(self, criteria):
        """
        This function is used to search for positions,and return the position information that meets the requirements.
        """
        if criteria is None:
            return []
        crit = str(criteria).lower()
        results = []
        for job in self.job_listings:
            if crit in (job.get('job_title') or '').lower() or crit in (job.get('company') or '').lower():
                results.append(job)
                continue
            for r in job.get('requirements', []):
                if crit == str(r).lower():
                    results.append(job)
                    break
        return results

    def get_job_applicants(self, job):
        """
        This function is used to obtain candidate information,and return the candidate information that meets the requirements by calling the matches_requirements function.
        """
        def matches_requirements(jobreqs, skills):
            jr = set([str(x).lower() for x in (jobreqs or [])])
            sk = set([str(x).lower() for x in (skills or [])])
            return jr.issubset(sk)

        reqs = job.get('requirements') if job else []
        matched = [r for r in self.resumes if matches_requirements(reqs, r.get('skills'))]
        return matched