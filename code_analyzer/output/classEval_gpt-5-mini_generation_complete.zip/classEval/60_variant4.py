import sqlite3
import threading

class MovieTicketDB:
    """
    This is a class for movie database operations, which allows for inserting movie information, searching for movie information by name, and deleting movie information by name.
    """

    def __init__(self, db_name):
        self.db_name = db_name
        self.lock = threading.Lock()
        self.connection = sqlite3.connect(db_name, check_same_thread=False)
        self.cursor = self.connection.cursor()
        self.create_table()
        self._prepare_statements()

    def _prepare_statements(self):
        self._insert_sql = "INSERT INTO tickets (movie_name, theater_name, seat_number, customer_name) VALUES (?, ?, ?, ?)"
        self._search_sql = "SELECT id, movie_name, theater_name, seat_number, customer_name FROM tickets WHERE customer_name = ?"
        self._delete_sql = "DELETE FROM tickets WHERE id = ?"

    def create_table(self):
        with self.lock:
            self.cursor.execute(
                "CREATE TABLE IF NOT EXISTS tickets ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "movie_name TEXT NOT NULL, "
                "theater_name TEXT, "
                "seat_number TEXT, "
                "customer_name TEXT)"
            )
            self.connection.commit()

    def insert_ticket(self, movie_name, theater_name, seat_number, customer_name):
        with self.lock:
            try:
                cur = self.connection.cursor()
                cur.execute(self._insert_sql, (movie_name, theater_name, seat_number, customer_name))
                self.connection.commit()
                return cur.lastrowid
            except Exception:
                self.connection.rollback()
                raise

    def search_tickets_by_customer(self, customer_name):
        with self.lock:
            cur = self.connection.cursor()
            cur.execute(self._search_sql, (customer_name,))
            return cur.fetchall()

    def delete_ticket(self, ticket_id):
        with self.lock:
            cur = self.connection.cursor()
            cur.execute(self._delete_sql, (ticket_id,))
            self.connection.commit()
            return cur.rowcount

    def __del__(self):
        try:
            self.connection.close()
        except Exception:
            pass

# Classification response:
# helper function extraction; try-except wrapper; state variable; temporary variable; literal rewrite; import reorganization; thread-safety; behavior change; error suppression