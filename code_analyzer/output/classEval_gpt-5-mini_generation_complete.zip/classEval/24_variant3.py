from decimal import Decimal, getcontext

class ComplexCalculator:
    """
    This is a class that implements addition, subtraction, multiplication, and division operations for complex numbers.
    """

    def __init__(self, precision=28):
        # precision if instance is created; static methods won't use it but kept for compatibility
        getcontext().prec = precision

    @staticmethod
    def _to_decimal_pair(x):
        if isinstance(x, complex):
            return Decimal(str(x.real)), Decimal(str(x.imag))
        if isinstance(x, (list, tuple)) and len(x) == 2:
            return Decimal(str(x[0])), Decimal(str(x[1]))
        if isinstance(x, (int, float)):
            return Decimal(str(x)), Decimal('0')
        raise TypeError("Unsupported type")

    @staticmethod
    def add(c1, c2):
        a_re, a_im = ComplexCalculator._to_decimal_pair(c1)
        b_re, b_im = ComplexCalculator._to_decimal_pair(c2)
        return complex(float(a_re + b_re), float(a_im + b_im))

    @staticmethod
    def subtract(c1, c2):
        a_re, a_im = ComplexCalculator._to_decimal_pair(c1)
        b_re, b_im = ComplexCalculator._to_decimal_pair(c2)
        return complex(float(a_re - b_re), float(a_im - b_im))

    @staticmethod
    def multiply(c1, c2):
        a_re, a_im = ComplexCalculator._to_decimal_pair(c1)
        b_re, b_im = ComplexCalculator._to_decimal_pair(c2)
        re = a_re * b_re - a_im * b_im
        im = a_re * b_im + a_im * b_re
        return complex(float(re), float(im))

    @staticmethod
    def divide(c1, c2):
        a_re, a_im = ComplexCalculator._to_decimal_pair(c1)
        b_re, b_im = ComplexCalculator._to_decimal_pair(c2)
        denom = b_re * b_re + b_im * b_im
        if denom == 0:
            raise ZeroDivisionError("division by zero")
        re = (a_re * b_re + a_im * b_im) / denom
        im = (a_im * b_re - a_re * b_im) / denom
        return complex(float(re), float(im))