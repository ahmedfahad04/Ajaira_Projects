from PIL import Image, ImageEnhance

class ImageProcessor:
    """
    This is a class to process image, including loading, saving, resizing, rotating, and adjusting the brightness of images.
    """

    def __init__(self):
        """
        Initialize self.image
        """
        self.image = None

    def load_image(self, image_path):
        """
        Use Image util in PIL to open a image
        """
        if image_path is None:
            raise ValueError("image_path must be provided")
        img = Image.open(image_path)
        # ensure image is loaded into memory
        self.image = img.copy()
        img.close()
        return self.image

    def save_image(self, save_path):
        """
        Save image to a path if image has opened
        """
        if self.image is None:
            raise ValueError("No image loaded")
        # Use the image format if available, otherwise infer from save_path
        save_kwargs = {}
        fmt = getattr(self.image, "format", None)
        if fmt:
            save_kwargs['format'] = fmt
        self.image.save(save_path, **save_kwargs)

    def resize_image(self, width, height):
        """
        Resize the image if image has opened.
        """
        if self.image is None:
            raise ValueError("No image loaded")
        if not (isinstance(width, int) and isinstance(height, int)):
            raise TypeError("width and height must be integers")
        if width <= 0 or height <= 0:
            raise ValueError("width and height must be positive")
        self.image = self.image.resize((width, height), Image.LANCZOS)
        return self.image

    def rotate_image(self, degrees):
        """
        rotate image if image has opened
        """
        if self.image is None:
            raise ValueError("No image loaded")
        try:
            deg = float(degrees)
        except Exception:
            raise TypeError("degrees must be a number")
        # rotate and expand so the whole rotated image fits
        self.image = self.image.rotate(deg, resample=Image.BICUBIC, expand=True)
        return self.image

    def adjust_brightness(self, factor):
        """
        Adjust the brightness of image if image has opened.
        """
        if self.image is None:
            raise ValueError("No image loaded")
        try:
            f = float(factor)
        except Exception:
            raise TypeError("factor must be a number")
        enhancer = ImageEnhance.Brightness(self.image)
        self.image = enhancer.enhance(f)
        return self.image