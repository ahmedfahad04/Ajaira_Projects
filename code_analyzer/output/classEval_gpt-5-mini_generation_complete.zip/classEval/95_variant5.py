class Warehouse:
    """
    The class manages inventory and orders, including adding products, updating product quantities, retrieving product quantities, creating orders, changing order statuses, and tracking orders.
    """

    def __init__(self):
        """
        Initialize two fields.
        self.inventory is a dict that stores the products.
        self.inventory = {Product ID: Product}
        self.orders is a dict that stores the products in a order.
        self.orders = {Order ID: Order}
        """
        self.inventory = {}
        self.orders = {}

    def add_product(self, product_id, name, quantity):
        # If product exists, merge quantities and keep the most recent name
        if product_id in self.inventory:
            self.inventory[product_id]['quantity'] += quantity
            self.inventory[product_id]['name'] = name
        else:
            self.inventory[product_id] = {'name': name, 'quantity': quantity}
        return True

    def update_product_quantity(self, product_id, quantity):
        # update by delta, return False if product not found
        if product_id not in self.inventory:
            return False
        self.inventory[product_id]['quantity'] += quantity
        return True

    def get_product_quantity(self, product_id):
        if product_id not in self.inventory:
            return False
        return self.inventory[product_id]['quantity']

    def create_order(self, order_id, product_id, quantity):
        # create an order only if product exists and enough quantity
        if product_id not in self.inventory:
            return False
        if quantity <= 0:
            return False
        qty = self.inventory[product_id]['quantity']
        if qty < quantity:
            return False
        self.inventory[product_id]['quantity'] = qty - quantity
        self.orders[order_id] = {'product_id': product_id, 'quantity': quantity, 'status': 'Shipped'}
        return True

    def change_order_status(self, order_id, status):
        if order_id not in self.orders:
            return False
        self.orders[order_id]['status'] = status
        return True

    def track_order(self, order_id):
        if order_id not in self.orders:
            return False
        return self.orders[order_id]['status']