import re
from collections import deque

class ExpressionCalculator:
    """
    This is a class in Python that can perform calculations with basic arithmetic operations, including addition, subtraction, multiplication, division, and modulo.
    """

    def __init__(self):
        """
        Initialize the expression calculator
        """
        self.postfix_stack = deque()
        self.operat_priority = [0, 3, 2, 1, -1, 1, 0, 2]

    def calculate(self, expression):
        """
        Calculate by safely evaluating a sanitized expression
        """
        expr = self.transform(expression)
        # Allow digits, parentheses, operators and decimal point
        if not re.fullmatch(r'[0-9+\-*/%().\s]+', expression):
            raise ValueError("Invalid characters in expression")
        # Use prepare to populate postfix_stack for compatibility
        self.prepare(expr)
        # Evaluate using Python eval on the sanitized expression
        # Replace % with modulus operator (same in Python)
        try:
            # eval in restricted namespace
            result = eval(expr, {"__builtins__": None}, {})
        except ZeroDivisionError:
            raise
        except Exception as e:
            raise ValueError("Invalid expression") from e
        return float(result)

    def prepare(self, expression):
        """
        Convert infix to postfix using shunting-yard; result in postfix_stack
        """
        tokens = re.findall(r'\d+\.\d+|\d+|[()+\-*/%]', expression)
        output = []
        stack = []
        prec = {'+': 1, '-': 1, '*': 2, '/': 2, '%': 2}
        for i, t in enumerate(tokens):
            if re.match(r'^\d+(\.\d+)?$', t):
                output.append(t)
            elif t == '(':
                stack.append(t)
            elif t == ')':
                while stack and stack[-1] != '(':
                    output.append(stack.pop())
                if stack:
                    stack.pop()
            else:
                # unary minus handling
                if t == '-' and (i == 0 or tokens[i-1] in {'(', '+', '-', '*', '/', '%'}):
                    output.append('0')
                while stack and stack[-1] != '(' and prec.get(stack[-1], 0) >= prec.get(t, 0):
                    output.append(stack.pop())
                stack.append(t)
        while stack:
            output.append(stack.pop())
        self.postfix_stack = deque(output)

    @staticmethod
    def is_operator(c):
        return c in {'+', '-', '*', '/', '(', ')', '%'}

    def compare(self, cur, peek):
        precedence = {'+': 1, '-': 1, '*': 2, '/': 2, '%': 2}
        return precedence.get(cur, 0) >= precedence.get(peek, 0)

    @staticmethod
    def _calculate(first_value, second_value, current_op):
        a = float(first_value)
        b = float(second_value)
        if current_op == '+':
            return a + b
        if current_op == '-':
            return a - b
        if current_op == '*':
            return a * b
        if current_op == '/':
            if b == 0:
                raise ZeroDivisionError("division by zero")
            return a / b
        if current_op == '%':
            if b == 0:
                raise ZeroDivisionError("modulo by zero")
            return a % b
        raise ValueError("Unsupported operator")

    @staticmethod
    def transform(expression):
        # remove double spaces and ensure proper operators format
        return ''.join(expression.split())