import numpy as np

class KappaCalculator:
    """
    This is a class as KappaCalculator, supporting to calculate Cohen's and Fleiss' kappa coefficient.
    """

    @staticmethod
    def kappa(testData, k):
        # pure python loops, robust
        if testData is None:
            return 0.0
        mat = [list(row) for row in testData]
        if len(mat) != k or any(len(row) != k for row in mat):
            raise ValueError("testData must be k x k")
        total = 0
        diag = 0
        rows = [0] * k
        cols = [0] * k
        for i in range(k):
            for j in range(k):
                v = mat[i][j]
                total += v
                rows[i] += v
                cols[j] += v
                if i == j:
                    diag += v
        if total == 0:
            return 0.0
        po = diag / total
        pe = sum(rows[i] * cols[i] for i in range(k)) / (total * total)
        denom = 1.0 - pe
        if abs(denom) < 1e-12:
            return 1.0 if abs(po - pe) < 1e-12 else 0.0
        return (po - pe) / denom

    @staticmethod
    def fleiss_kappa(testData, N, k, n):
        if testData is None:
            return 0.0
        mat = [list(map(float, row)) for row in testData]
        if len(mat) != N or any(len(row) != k for row in mat):
            raise ValueError("testData must be N x k")
        # compute Pj for each row
        Pj_list = []
        col_sums = [0.0] * k
        for row in mat:
            s = sum(row)
            sq = sum(x * x for x in row)
            # use expected sum n provided; if s differs, proceed with s in formula? We'll use provided n.
            Pj = (sq - n) / (n * (n - 1)) if n > 1 else 0.0
            Pj_list.append(Pj)
            for idx, val in enumerate(row):
                col_sums[idx] += val
        Pbar = sum(Pj_list) / N
        p_k = [cs / (N * n) for cs in col_sums]
        Pe = sum(pk * pk for pk in p_k)
        denom = 1.0 - Pe
        if abs(denom) < 1e-12:
            return 1.0 if abs(Pbar - Pe) < 1e-12 else 0.0
        return (Pbar - Pe) / denom