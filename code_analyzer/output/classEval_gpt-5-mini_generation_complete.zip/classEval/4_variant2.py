from statistics import mean

class AssessmentSystem:
    """
    This is a class as an student assessment system, which supports add student, add course score, calculate GPA, and other functions for students and courses.
    """

    def __init__(self):
        """
        Initialize the students dict in assessment system.
        """
        self.students = {}

    def add_student(self, name, grade, major):
        self.students[name] = {'name': name, 'grade': grade, 'major': major, 'courses': {}}

    def add_course_score(self, name, course, score):
        if name not in self.students:
            raise KeyError(f"Student {name} does not exist")
        self.students[name]['courses'][course] = score

    def get_gpa(self, name):
        info = self.students.get(name)
        if not info:
            return None
        scores = list(info['courses'].values())
        if not scores:
            return None
        return mean(scores)

    def get_all_students_with_fail_course(self):
        return [name for name, info in self.students.items() if any(s < 60 for s in info['courses'].values())]

    def get_course_average(self, course):
        scores = [info['courses'][course] for info in self.students.values() if course in info['courses']]
        if not scores:
            return None
        return mean(scores)

    def get_top_student(self):
        gpas = ((name, self.get_gpa(name)) for name in self.students)
        best = None
        best_gpa = None
        for name, gpa in gpas:
            if gpa is None:
                continue
            if best_gpa is None or gpa > best_gpa:
                best = name
                best_gpa = gpa
        return best