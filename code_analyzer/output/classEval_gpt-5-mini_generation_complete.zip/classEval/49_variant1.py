class JobMarketplace:
    """
    This is a class that provides functionalities to publish positions, remove positions, submit resumes, withdraw resumes, search for positions, and obtain candidate information.
    """

    def __init__(self):
        self.job_listings = []
        self.resumes = []

    def post_job(self, job_title, company, requirements):
        """
        This function is used to publish positions,and add the position information to the job_listings list.
        :param job_title: The title of the position,str.
        :param company: The company of the position,str.
        :param requirements: The requirements of the position,list.
        :return: None
        """
        job = {
            'job_title': job_title,
            'company': company,
            'requirements': list(requirements) if requirements is not None else []
        }
        self.job_listings.append(job)

    def remove_job(self, job):
        """
        This function is used to remove positions,and remove the position information from the job_listings list.
        :param job: The position information to be removed,dict.
        :return: None
        """
        try:
            self.job_listings.remove(job)
        except ValueError:
            # try to find equivalent by matching fields
            to_remove = None
            for j in self.job_listings:
                if j.get('job_title') == job.get('job_title') and j.get('company') == job.get('company') and j.get('requirements') == job.get('requirements'):
                    to_remove = j
                    break
            if to_remove:
                self.job_listings.remove(to_remove)

    def submit_resume(self, name, skills, experience):
        """
        This function is used to submit resumes,and add the resume information to the resumes list.
        :param name: The name of the resume,str.
        :param skills: The skills of the resume,list.
        :param experience: The experience of the resume,str.
        :return: None
        """
        resume = {
            'name': name,
            'skills': list(skills) if skills is not None else [],
            'experience': experience
        }
        self.resumes.append(resume)

    def withdraw_resume(self, resume):
        """
        This function is used to withdraw resumes,and remove the resume information from the resumes list.
        :param resume: The resume information to be removed,dict.
        :return: None
        """
        try:
            self.resumes.remove(resume)
        except ValueError:
            # fallback matching by fields
            to_remove = None
            for r in self.resumes:
                if r.get('name') == resume.get('name') and r.get('skills') == resume.get('skills') and r.get('experience') == resume.get('experience'):
                    to_remove = r
                    break
            if to_remove:
                self.resumes.remove(to_remove)

    def search_jobs(self, criteria):
        """
        This function is used to search for positions,and return the position information that meets the requirements.
        :param criteria: The requirements of the position,str.
        :return: The position information that meets the requirements,list.
        """
        if criteria is None:
            return []
        crit = str(criteria).lower()
        results = []
        for job in self.job_listings:
            if crit in (job.get('job_title') or '').lower() or crit in (job.get('company') or '').lower():
                results.append(job)
                continue
            reqs = job.get('requirements') or []
            for r in reqs:
                if crit == str(r).lower():
                    results.append(job)
                    break
        return results

    def get_job_applicants(self, job):
        """
        This function is used to obtain candidate information,and return the candidate information that meets the requirements by calling the matches_requirements function.
        :param job: The position information,dict.
        :return: The candidate information that meets the requirements,list.
        """
        requirements = job.get('requirements') if job else []
        results = []
        for resume in self.resumes:
            skills = resume.get('skills') or []
            if all(req in skills for req in requirements):
                results.append(resume)
        return results