class EncryptionUtils:
    """
    This is a class that provides methods for encryption, including the Caesar cipher, Vigenere cipher, and Rail Fence cipher.
    """

    def __init__(self, key):
        self.key = key or ""

    def caesar_cipher(self, plaintext, shift):
        if shift is None:
            return plaintext
        s = shift % 26
        res_chars = []
        for ch in plaintext:
            if ch.isalpha():
                base = ord('A') if ch.isupper() else ord('a')
                res_chars.append(chr((ord(ch) - base + s) % 26 + base))
            else:
                res_chars.append(ch)
        return ''.join(res_chars)

    def vigenere_cipher(self, plaintext):
        # Build list of shifts from key, but if key contains non-alpha, map them to 0 shift
        shifts = []
        for c in self.key:
            if c.isalpha():
                shifts.append(ord(c.lower()) - ord('a'))
            else:
                shifts.append(0)
        if not shifts:
            return plaintext
        res = []
        k = 0
        for ch in plaintext:
            if ch.isalpha():
                shift = shifts[k % len(shifts)]
                base = ord('A') if ch.isupper() else ord('a')
                res.append(chr((ord(ch) - base + shift) % 26 + base))
                k += 1
            else:
                res.append(ch)
        return ''.join(res)

    def rail_fence_cipher(self,plain_text, rails):
        if rails is None or rails <= 1:
            return plain_text
        if rails >= len(plain_text):
            return plain_text
        # Use cycle length method to collect characters per rail
        period = 2 * rails - 2
        result = []
        for r in range(rails):
            i = r
            while i < len(plain_text):
                result.append(plain_text[i])
                # middle rails have a second char in the period
                if r != 0 and r != rails - 1:
                    j = i + period - 2 * r
                    if j < len(plain_text):
                        result.append(plain_text[j])
                i += period
        return ''.join(result)