import json
import io

class TextFileProcessor:
    """
    The class handles reading, writing, and processing text files. It can read the file as JSON, read the raw text, write content to the file, and process the file by removing non-alphabetic characters.
    """

    def __init__(self, file_path):
        self.file_path = file_path

    def read_file_as_json(self):
        with io.open(self.file_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def read_file(self):
        with io.open(self.file_path, 'r', encoding='utf-8') as f:
            return f.read()

    def write_file(self, content):
        if isinstance(content, str):
            to_write = content
        else:
            try:
                to_write = json.dumps(content)
            except Exception:
                to_write = str(content)
        with io.open(self.file_path, 'w', encoding='utf-8') as f:
            f.write(to_write)

    def process_file(self):
        s = self.read_file()
        out_chars = []
        for ch in s:
            if ch.isalpha():
                out_chars.append(ch)
        result = ''.join(out_chars)
        with io.open(self.file_path, 'w', encoding='utf-8') as f:
            f.write(result)
        return result