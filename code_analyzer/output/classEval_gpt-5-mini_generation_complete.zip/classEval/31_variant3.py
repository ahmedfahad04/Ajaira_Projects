import math

class DataStatistics4:
    """
    This is a class that performs advanced mathematical calculations and statistics, including correlation coefficient, skewness, kurtosis, and probability density function (PDF) for a normal distribution.
    Uses an online algorithm to compute central moments for better numerical stability.
    """

    @staticmethod
    def correlation_coefficient(data1, data2):
        if len(data1) != len(data2):
            raise ValueError("Inputs must be same length")
        n = len(data1)
        if n == 0:
            raise ValueError("Inputs must be non-empty")
        mean1 = 0.0
        mean2 = 0.0
        c = 0.0
        for i, (x, y) in enumerate(zip(data1, data2), start=1):
            dx = x - mean1
            dy = y - mean2
            mean1 += dx / i
            mean2 += dy / i
            c += dx * (y - mean2)
        var1 = sum((x - mean1) ** 2 for x in data1)
        var2 = sum((y - mean2) ** 2 for y in data2)
        denom = math.sqrt(var1 * var2)
        if denom == 0:
            return 0.0
        return c / denom

    @staticmethod
    def skewness(data):
        n = 0
        mean = 0.0
        M2 = 0.0
        M3 = 0.0
        for x in data:
            n1 = n
            n += 1
            delta = x - mean
            delta_n = delta / n
            delta_n2 = delta_n * delta_n
            term1 = delta * delta_n * n1
            mean += delta_n
            M3 += term1 * delta_n * (n - 2) - 3 * delta_n * M2
            M2 += term1
        if n < 3 or M2 == 0:
            return 0.0
        # sample standard deviation
        s = math.sqrt(M2 / (n - 1))
        # adjusted Fisher-Pearson
        return (math.sqrt(n * (n - 1)) / (n - 2)) * (M3 / (n * s ** 3))

    @staticmethod
    def kurtosis(data):
        # Use online four-moment algorithm
        n = 0
        mean = 0.0
        M2 = 0.0
        M3 = 0.0
        M4 = 0.0
        for x in data:
            n1 = n
            n += 1
            delta = x - mean
            delta_n = delta / n
            delta_n2 = delta_n * delta_n
            term1 = delta * delta_n * n1
            mean += delta_n
            M4 += term1 * delta_n2 * (n * n - 3 * n + 3) + 6 * delta_n2 * M2 - 4 * delta_n * M3
            M3 += term1 * delta_n * (n - 2) - 3 * delta_n * M2
            M2 += term1
        if n < 4 or M2 == 0:
            # fallback to population excess kurtosis
            if n == 0:
                return -3.0
            m2 = M2 / n
            if m2 == 0:
                return -3.0
            # compute raw m4
            m4 = M4 / n
            return m4 / (m2 * m2) - 3.0
        # sample excess kurtosis (unbiased-ish)
        m2 = M2 / n
        m4 = M4 / n
        # Use excess kurtosis based on population moments then correct for small sample
        g2 = m4 / (m2 * m2) - 3.0
        # return corrected (approximate) value
        return ((n - 1) * ((n + 1) * g2 + 6)) / ((n - 2) * (n - 3))

    @staticmethod
    def pdf(data, mu, sigma):
        if sigma <= 0:
            raise ValueError("sigma must be positive")
        denom = sigma * math.sqrt(2 * math.pi)
        two_sig2 = 2 * sigma * sigma
        out = []
        for x in data:
            out.append((1.0 / denom) * math.exp(-((x - mu) ** 2) / two_sig2))
        return out