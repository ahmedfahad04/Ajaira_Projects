import re
from collections import deque

class Calculator:
    """
    This is a class for a calculator, capable of performing basic arithmetic calculations on numerical expressions using the operators +, -, *, /, and ^ (exponentiation).
    """

    def __init__(self):
        """
        Initialize the operations performed by the five operators'+','-','*','/','^'
        """
        self.operators = {
            '+': lambda x, y: x + y,
            '-': lambda x, y: x - y,
            '*': lambda x, y: x * y,
            '/': lambda x, y: x / y,
            '^': lambda x, y: x ** y
        }

    def precedence(self, operator):
        if operator in ('+','-'):
            return 1
        if operator in ('*','/'):
            return 2
        if operator == '^':
            return 3
        return 0

    def apply_operator(self, operand_stack, operator_stack):
        if not operator_stack or len(operand_stack) < 2:
            return operand_stack, operator_stack
        op = operator_stack.pop()
        b = operand_stack.pop()
        a = operand_stack.pop()
        operand_stack.append(self.operators[op](a, b))
        return operand_stack, operator_stack

    def _tokenize(self, expr):
        token_re = re.compile(r'\s*([()+\-*/^]|\d+(?:\.\d+)?|\.\d+)')
        pos = 0
        tokens = []
        while pos < len(expr):
            m = token_re.match(expr, pos)
            if not m:
                return None
            tok = m.group(1)
            pos = m.end()
            tokens.append(tok)
        # Merge unary signs into numbers where appropriate
        out = []
        i = 0
        while i < len(tokens):
            t = tokens[i]
            if t in ('+','-'):
                if i == 0 or tokens[i-1] in ('(', '+', '-', '*', '/', '^'):
                    # unary sign
                    if i+1 < len(tokens) and re.fullmatch(r'\d+(?:\.\d+)?|\.\d+', tokens[i+1]):
                        out.append(t + tokens[i+1])
                        i += 2
                        continue
            out.append(t)
            i += 1
        return out

    def calculate(self, expression):
        tokens = self._tokenize(expression)
        if tokens is None:
            return None
        # Convert to RPN using shunting-yard but slightly different implementation
        output = deque()
        ops = []
        right_assoc = {'^'}
        try:
            for tok in tokens:
                if re.fullmatch(r'[+-]?\d+(?:\.\d+)?|\.\d+', tok):
                    output.append(float(tok))
                elif tok in self.operators:
                    while ops and ops[-1] in self.operators:
                        top = ops[-1]
                        if (top not in right_assoc and self.precedence(top) >= self.precedence(tok)) or (top in right_assoc and self.precedence(top) > self.precedence(tok)):
                            output.append(ops.pop())
                        else:
                            break
                    ops.append(tok)
                elif tok == '(':
                    ops.append(tok)
                elif tok == ')':
                    while ops and ops[-1] != '(':
                        output.append(ops.pop())
                    if not ops or ops[-1] != '(':
                        return None
                    ops.pop()
                else:
                    return None
            while ops:
                if ops[-1] in ('(',')'):
                    return None
                output.append(ops.pop())
            # Evaluate RPN
            stack = []
            while output:
                item = output.popleft()
                if isinstance(item, float):
                    stack.append(item)
                else:
                    if len(stack) < 2:
                        return None
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(self.operators[item](a, b))
            if len(stack) != 1:
                return None
            return float(stack[0])
        except Exception:
            return None