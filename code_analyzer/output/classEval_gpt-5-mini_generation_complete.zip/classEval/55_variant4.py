class Manacher:
    """
    his is a class that implements a manacher algorithm to find the Longest palindromic substring in a given string.
    """

    def __init__(self, input_string) -> None:
        """
        Initializes the Manacher class with the given input_string.
        :param input_string: The input_string to be searched, str.
        """
        self.input_string = input_string or ""

    def palindromic_length(self, center, diff, string):
        """
        Recursively calculates the length of the palindromic substring based on a given center, difference value, and input string.
        :param center: The center of the palindromic substring, int.
        :param diff: The difference between the center and the current position, int.
        :param string: The string to be searched, str.
        :return: The length of the palindromic substring, int.
        >>> manacher = Manacher('ababa')
        >>> manacher.palindromic_length(2, 1, 'a|b|a|b|a')
        2

        """
        if center - diff < 0 or center + diff >= len(string):
            return 0
        if string[center - diff] == string[center + diff]:
            return 1 + self.palindromic_length(center, diff + 1, string)
        return 0

    def palindromic_string(self):
        """
        Finds the longest palindromic substring in the given string.
        :return: The longest palindromic substring, str.
        >>> manacher = Manacher('ababaxse')
        >>> manacher.palindromic_string()
        'ababa'

        """
        s = self.input_string
        if not s:
            return ""
        # Use center expansion on original string, checking odd and even palindromes.
        best_l = 0
        best_sub = ""
        n = len(s)

        # helper to expand around center (left, right) using recursion mapped to transformed palindromic_length
        def expand_lr(l, r):
            # return substring
            while l >= 0 and r < n and s[l] == s[r]:
                l -= 1
                r += 1
            return s[l + 1:r]

        for i in range(n):
            # odd length
            odd = expand_lr(i, i)
            if len(odd) > best_l:
                best_l = len(odd)
                best_sub = odd
            # even length
            even = expand_lr(i, i + 1)
            if len(even) > best_l:
                best_l = len(even)
                best_sub = even

        return best_sub

# Classification response:
# variable renaming; default value handling; guard clause; loop rewrite; helper function extraction; split condition; two pointer; slicing; recursion