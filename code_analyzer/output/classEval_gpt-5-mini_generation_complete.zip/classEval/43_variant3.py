import copy

class HRManagementSystem:
    """
    This is a class as personnel management system that implements functions such as adding, deleting, querying, and updating employees
    """

    def __init__(self):
        """
        Initialize the HRManagementSystem withan attribute employees, which is an empty dictionary.
        """
        # store employee dicts including employee_ID internally
        self.employees = {}

    def add_employee(self, employee_id, name, position, department, salary):
        """
        Add a new employee to the HRManagementSystem.
        """
        if employee_id in self.employees:
            return False
        self.employees[employee_id] = {
            'employee_ID': employee_id,
            'name': name,
            'position': position,
            'department': department,
            'salary': salary
        }
        return True

    def remove_employee(self, employee_id):
        """
        Remove an employee from the HRManagementSystem.
        """
        if employee_id in self.employees:
            del self.employees[employee_id]
            return True
        return False

    def update_employee(self, employee_id: int, employee_info: dict):
        """
        Update an employee's information in the HRManagementSystem.
        """
        if employee_id not in self.employees:
            return False
        # merge provided keys, but keep employee_ID intact
        for k, v in employee_info.items():
            if k == 'employee_ID':
                continue
            self.employees[employee_id][k] = v
        return True

    def get_employee(self, employee_id):
        """
        Get an employee's information from the HRManagementSystem.
        """
        e = self.employees.get(employee_id)
        if not e:
            return False
        # return a copy without employee_ID to match expected behaviour
        copy_e = copy.deepcopy(e)
        copy_e.pop('employee_ID', None)
        return copy_e

    def list_employees(self):
        """
        List all employees' information in the HRManagementSystem.
        """
        return copy.deepcopy(self.employees)