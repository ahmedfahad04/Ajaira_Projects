class Warehouse:
    """
    The class manages inventory and orders, including adding products, updating product quantities, retrieving product quantities, creating orders, changing order statuses, and tracking orders.
    """

    def __init__(self):
        """
        Initialize two fields.
        self.inventory is a dict that stores the products.
        self.inventory = {Product ID: Product}
        self.orders is a dict that stores the products in a order.
        self.orders = {Order ID: Order}
        """
        self.inventory = {}
        self.orders = {}

    def add_product(self, product_id, name, quantity):
        # If product exists, update name to the latest provided and increment quantity
        if product_id in self.inventory:
            self.inventory[product_id]['quantity'] += quantity
            self.inventory[product_id]['name'] = name
        else:
            self.inventory[product_id] = {'name': name, 'quantity': quantity}
        return True

    def update_product_quantity(self, product_id, quantity):
        # Return False if product does not exist
        prod = self.inventory.get(product_id)
        if prod is None:
            return False
        prod['quantity'] += quantity
        return True

    def get_product_quantity(self, product_id):
        prod = self.inventory.get(product_id)
        if prod is None:
            return False
        return prod['quantity']

    def create_order(self, order_id, product_id, quantity):
        # Do not allow duplicate order ids
        if product_id not in self.inventory:
            return False
        if self.inventory[product_id]['quantity'] < quantity:
            return False
        if order_id in self.orders:
            return False
        self.inventory[product_id]['quantity'] -= quantity
        order = {'product_id': product_id, 'quantity': quantity, 'status': 'Shipped'}
        self.orders[order_id] = order
        return order

    def change_order_status(self, order_id, status):
        if order_id not in self.orders:
            return False
        self.orders[order_id]['status'] = status
        return True

    def track_order(self, order_id):
        order = self.orders.get(order_id)
        if order is None:
            return False
        return order['status']