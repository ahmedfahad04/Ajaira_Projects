from datetime import datetime
import numpy as np

class MovieBookingSystem:
    """
    this is a class as movie booking system, which allows to add movies, book tickets and check the available movies within a given time range. 
    """

    def __init__(self):
        self.movies = []

    def add_movie(self, name, price, start_time, end_time, n):
        st = datetime.strptime(start_time, "%H:%M")
        et = datetime.strptime(end_time, "%H:%M")
        seats = np.zeros((n, n), dtype=float)
        movie = {
            'name': name,
            'price': float(price),
            'start_time': st,
            'end_time': et,
            'seats': seats
        }
        self.movies.append(movie)

    def book_ticket(self, name, seats_to_book):
        target = None
        for m in self.movies:
            if m['name'] == name:
                target = m
                break
        if target is None:
            return "Movie not found."
        seats = target['seats']
        nrows, ncols = seats.shape
        for (r, c) in seats_to_book:
            if not isinstance(r, int) or not isinstance(c, int):
                return "Booking failed."
            if r < 0 or r >= nrows or c < 0 or c >= ncols:
                return "Booking failed."
            if seats[r, c] != 0.0:
                return "Booking failed."
        for (r, c) in seats_to_book:
            seats[r, c] = 1.0
        return "Booking success."

    def available_movies(self, start_time, end_time):
        st = datetime.strptime(start_time, "%H:%M")
        et = datetime.strptime(end_time, "%H:%M")
        result = []
        for m in self.movies:
            if m['start_time'] >= st and m['end_time'] <= et:
                result.append(m['name'])
        return result

# Classification response:
# variable renaming; string formatting change; early return; guard clause; loop rewrite; temporary variable; tuple unpacking; in-place mutation; input validation; boundary case handling; type conversion