import csv
import os

class CSVProcessor:
    """
    This is a class for processing CSV files, including readring and writing CSV data, as well as processing specific operations and saving as a new CSV file.
    """

    def __init__(self):
        pass

    def read_csv(self, file_name):
        try:
            with open(file_name, mode='r', encoding='utf-8', newline='') as f:
                rdr = csv.reader(f)
                rows = list(rdr)
                if not rows:
                    return [], []
                header = rows[0]
                body = rows[1:]
                return header, body
        except Exception:
            return [], []

    def write_csv(self, data, file_name):
        try:
            with open(file_name, mode='w', encoding='utf-8', newline='') as f:
                w = csv.writer(f)
                for row in data:
                    # ensure all items are strings
                    w.writerow([str(x) for x in row])
            return 1
        except Exception:
            return 0

    def process_csv_data(self, N, save_file_name):
        try:
            header, rows = self.read_csv(save_file_name)
            if header == [] and rows == []:
                return 0
            out_rows = []
            for r in rows:
                if N >= 0 and N < len(r):
                    out_rows.append([r[N].upper()])
                else:
                    out_rows.append([''])
            # construct new filename with _process before extension
            base, ext = os.path.splitext(save_file_name)
            if ext:
                new_name = f"{base}_process{ext}"
            else:
                new_name = f"{save_file_name}_process"
            content = [header] + out_rows
            return self.write_csv(content, new_name)
        except Exception:
            return 0