import PyPDF2

class PDFHandler:
    """
    The class allows merging multiple PDF files into one and extracting text from PDFs using PyPDF2 library.
    """

    def __init__(self, filepaths):
        """
        takes a list of file paths filepaths as a parameter.
        It creates a list named readers using PyPDF2, where each reader opens a file from the given paths.
        """
        self.filepaths = filepaths
        self.readers = [PyPDF2.PdfFileReader(fp) for fp in filepaths]

    def merge_pdfs(self, output_filepath):
        writer = PyPDF2.PdfFileWriter()
        for reader in self.readers:
            try:
                if getattr(reader, "isEncrypted", False):
                    try:
                        reader.decrypt("")
                    except Exception:
                        pass
                if hasattr(writer, "appendPagesFromReader"):
                    try:
                        writer.appendPagesFromReader(reader)
                        continue
                    except Exception:
                        pass
                try:
                    pages = reader.getNumPages()
                    for i in range(pages):
                        writer.addPage(reader.getPage(i))
                except Exception:
                    for p in getattr(reader, "pages", []):
                        writer.addPage(p)
            except Exception:
                continue
        with open(output_filepath, "wb") as out_f:
            writer.write(out_f)
        return f"Merged PDFs saved at {output_filepath}"

    def extract_text_from_pdfs(self):
        pdf_texts = []
        for reader in self.readers:
            pieces = []
            try:
                if getattr(reader, "isEncrypted", False):
                    try:
                        reader.decrypt("")
                    except Exception:
                        pass
                if hasattr(reader, "getNumPages"):
                    for i in range(reader.getNumPages()):
                        p = reader.getPage(i)
                        txt = ""
                        if hasattr(p, "extractText"):
                            txt = p.extractText()
                        elif hasattr(p, "extract_text"):
                            txt = p.extract_text()
                        if txt:
                            pieces.append(txt)
                else:
                    for p in getattr(reader, "pages", []):
                        if hasattr(p, "extract_text"):
                            t = p.extract_text()
                        elif hasattr(p, "extractText"):
                            t = p.extractText()
                        else:
                            t = ""
                        if t:
                            pieces.append(t)
            except Exception:
                pieces.append("")
            pdf_texts.append("".join(pieces))
        return pdf_texts

# Classification response:
# variable renaming;try-except wrapper;guard clause;branch reordering;accumulator list;join/split usage;error suppression;boundary case handling;behavior change