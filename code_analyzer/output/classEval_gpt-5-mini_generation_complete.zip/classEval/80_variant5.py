class SQLQueryBuilder:
    """
    This class provides to build SQL queries, including SELECT, INSERT, UPDATE, and DELETE statements. 
    """

    @staticmethod
    def _escape_str(v):
        if v is None:
            return "NULL"
        vs = str(v).replace("'", "''")
        return "'" + vs + "'"

    @staticmethod
    def select(table, columns='*', where=None):
        if isinstance(columns, (list, tuple)):
            cols = ", ".join(columns) if columns else "*"
        else:
            cols = columns or "*"
        sql = f"SELECT {cols} FROM {table}"
        if where:
            parts = []
            for k in sorted(where.keys()):
                parts.append(f"{k}={SQLQueryBuilder._escape_str(where[k])}")
            sql += " WHERE " + " AND ".join(parts)
        return sql

    @staticmethod
    def insert(table, data):
        keys = sorted(data.keys())
        cols = ", ".join(keys)
        vals = ", ".join(SQLQueryBuilder._escape_str(data[k]) for k in keys)
        return f"INSERT INTO {table} ({cols}) VALUES ({vals})"

    @staticmethod
    def delete(table, where=None):
        sql = f"DELETE FROM {table}"
        if where:
            parts = [f"{k}={SQLQueryBuilder._escape_str(where[k])}" for k in sorted(where.keys())]
            sql += " WHERE " + " AND ".join(parts)
        return sql

    @staticmethod
    def update(table, data, where=None):
        set_parts = [f"{k}={SQLQueryBuilder._escape_str(v)}" for k, v in sorted(data.items())]
        sql = f"UPDATE {table} SET " + ", ".join(set_parts)
        if where:
            where_parts = [f"{k}={SQLQueryBuilder._escape_str(where[k])}" for k in sorted(where.keys())]
            sql += " WHERE " + " AND ".join(where_parts)
        return sql