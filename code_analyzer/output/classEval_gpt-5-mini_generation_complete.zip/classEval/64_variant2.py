class NumberConverter:
    """
    The class allows to convert  decimal to binary, octal and hexadecimal repectively and contrarily
    """

    @staticmethod
    def decimal_to_binary(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        n = abs(decimal_num)
        if n == 0:
            return '0'
        digits = []
        while n:
            digits.append(str(n % 2))
            n //= 2
        s = ''.join(reversed(digits))
        return '-' + s if decimal_num < 0 else s

    @staticmethod
    def binary_to_decimal(binary_num):
        if isinstance(binary_num, int):
            binary_num = str(binary_num)
        s = binary_num.strip()
        if s == '':
            raise ValueError("empty string")
        sign = -1 if s.startswith('-') else 1
        if s[0] in '+-':
            s = s[1:]
        total = 0
        for ch in s:
            if ch not in '01':
                raise ValueError("invalid binary digit")
            total = total * 2 + int(ch)
        return sign * total

    @staticmethod
    def decimal_to_octal(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        n = abs(decimal_num)
        if n == 0:
            return '0'
        digits = []
        while n:
            digits.append(str(n % 8))
            n //= 8
        s = ''.join(reversed(digits))
        return '-' + s if decimal_num < 0 else s

    @staticmethod
    def octal_to_decimal(octal_num):
        if isinstance(octal_num, int):
            octal_num = str(octal_num)
        s = octal_num.strip()
        if s == '':
            raise ValueError("empty string")
        sign = -1 if s.startswith('-') else 1
        if s[0] in '+-':
            s = s[1:]
        total = 0
        for ch in s:
            if ch < '0' or ch > '7':
                raise ValueError("invalid octal digit")
            total = total * 8 + (ord(ch) - ord('0'))
        return sign * total

    @staticmethod
    def decimal_to_hex(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        digits_map = "0123456789abcdef"
        n = abs(decimal_num)
        if n == 0:
            return '0'
        digits = []
        while n:
            digits.append(digits_map[n % 16])
            n //= 16
        s = ''.join(reversed(digits))
        return '-' + s if decimal_num < 0 else s

    @staticmethod
    def hex_to_decimal(hex_num):
        if isinstance(hex_num, int):
            hex_num = format(hex_num, 'x')
        s = hex_num.strip()
        if s == '':
            raise ValueError("empty string")
        sign = -1 if s.startswith('-') else 1
        if s[0] in '+-':
            s = s[1:]
        total = 0
        for ch in s:
            if '0' <= ch <= '9':
                val = ord(ch) - ord('0')
            elif 'a' <= ch.lower() <= 'f':
                val = ord(ch.lower()) - ord('a') + 10
            else:
                raise ValueError("invalid hex digit")
            total = total * 16 + val
        return sign * total

# Classification response:
# guard clause;early return;conditional expression;while loop;for loop;accumulator list;temporary variable;membership test;join/split usage;builtin function;input validation;empty input handling;type conversion;boundary case handling;exception handling;manual base conversion