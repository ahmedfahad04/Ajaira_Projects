class RPGCharacter:
    """
    The class represents a role-playing game character, which allows to attack other characters, heal, gain experience, level up, and check if the character is alive.
    """
    def __init__(self, name, hp, attack_power, defense, level=1):
        self.name = name
        self.max_hp = hp
        self.hp = hp
        self.attack_power = attack_power
        self.defense = defense
        self.level = level
        self.exp = 0

    def attack(self, other_character):
        # simple damage calculation with floor at 0
        damage = max(0, self.attack_power - other_character.defense)
        other_character.hp = max(0, other_character.hp - damage)
        return damage

    def heal(self):
        # heal up to max_hp
        new_hp = self.hp + 10
        if new_hp > self.max_hp:
            new_hp = self.max_hp
        self.hp = new_hp
        return self.hp

    def _single_level_up(self):
        if self.level >= 100:
            return False
        self.level += 1
        self.max_hp += 20
        self.hp += 20
        self.attack_power += 5
        self.defense += 5
        return True

    def gain_exp(self, amount):
        # use a recursive helper to process overflow
        self.exp += amount

        def process():
            if self.level >= 100:
                # cap exp at threshold
                self.exp = min(self.exp, 100 * self.level)
                return
            threshold = 100 * self.level
            if self.exp >= threshold:
                self.exp -= threshold
                self._single_level_up()
                process()

        process()

    def level_up(self):
        # follow spec: level up once and reset experience to zero
        if self.level < 100:
            self._single_level_up()
        self.exp = 0
        return (self.level, self.hp, self.attack_power, self.defense)

    def is_alive(self):
        return self.hp > 0

# Classification response:
# helper function extraction;recursion with base case;loop rewrite;guard clause;state variable;temporary variable;boundary case handling