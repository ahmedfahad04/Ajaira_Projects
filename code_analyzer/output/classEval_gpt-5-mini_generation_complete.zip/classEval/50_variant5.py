import json
import os

class JSONProcessor:
    """
    This is a class to process JSON file, including reading and writing JSON files, as well as processing JSON data by removing a specified key from the JSON object.
    Slightly different IO approach (explicit binary write).
    """

    def read_json(self, file_path):
        if not isinstance(file_path, str):
            return -1
        if not os.path.exists(file_path):
            return 0
        try:
            with open(file_path, 'rb') as f:
                raw = f.read()
            text = raw.decode('utf-8')
            return json.loads(text)
        except Exception:
            return -1

    def write_json(self, data, file_path):
        if not isinstance(file_path, str):
            return -1
        try:
            dirn = os.path.dirname(file_path)
            if dirn and not os.path.exists(dirn):
                os.makedirs(dirn, exist_ok=True)
            text = json.dumps(data, ensure_ascii=False, indent=4)
            with open(file_path, 'wb') as f:
                f.write(text.encode('utf-8'))
            return 1
        except Exception:
            return -1

    def process_json(self, file_path, remove_key):
        if not isinstance(file_path, str):
            return -1
        data = self.read_json(file_path)
        if data == 0:
            return 0
        if data == -1:
            return -1
        if not isinstance(data, dict):
            return 0
        if remove_key not in data:
            return 0
        try:
            data.pop(remove_key, None)
            w = self.write_json(data, file_path)
            return 1 if w == 1 else -1
        except Exception:
            return -1