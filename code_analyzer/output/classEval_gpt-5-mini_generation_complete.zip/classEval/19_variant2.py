class ChandrasekharSieve:
    """
    This is a class that uses the Chandrasekhar's Sieve method to find all prime numbers within the range
    """

    def __init__(self, n):
        self.n = int(n)
        self.primes = self.generate_primes()

    def generate_primes(self):
        n = self.n
        if n < 2:
            return []
        # handle even numbers separately and use odd-only sieve
        primes = [2] if n >= 2 else []
        # indices correspond to odd numbers: value = 2*i+1
        m = (n - 1) // 2  # number of odd numbers up to n
        sieve = [True] * (m + 1)
        limit = int(n ** 0.5)
        for i in range(1, (limit - 1) // 2 + 1):
            if sieve[i]:
                p = 2 * i + 1
                start = (p * p - 1) // 2
                for j in range(start, m + 1, p):
                    sieve[j] = False
        for i, isprime in enumerate(sieve):
            if i == 0:
                continue  # corresponds to 1
            if isprime:
                primes.append(2 * i + 1)
        return primes

    def get_primes(self):
        return list(self.primes)