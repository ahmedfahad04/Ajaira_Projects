class VendingMachine:
    """
    This is a class to simulate a vending machine, including adding products, inserting coins, purchasing products, viewing balance, replenishing product inventory, and displaying product information.
    """

    def __init__(self):
        """
        Initializes the vending machine's inventory and balance.
        """
        self.inventory = {}
        self.balance = 0

    def add_item(self, item_name, price, quantity):
        if not isinstance(item_name, str) or price < 0 or quantity <= 0:
            return
        self.inventory[item_name] = {'price': float(price), 'quantity': int(quantity)}

    def insert_coin(self, amount):
        amount = float(amount)
        if amount <= 0:
            return self.balance
        # accumulate
        self.balance = round(self.balance + amount, 2)
        return self.balance

    def purchase_item(self, item_name):
        if item_name not in self.inventory:
            return False
        item = self.inventory[item_name]
        if item['quantity'] <= 0:
            return False
        price = float(item['price'])
        if self.balance < price:
            return False
        # perform purchase
        item['quantity'] -= 1
        self.balance = round(self.balance - price, 2)
        return self.balance

    def restock_item(self, item_name, quantity):
        if item_name not in self.inventory:
            return False
        if quantity <= 0:
            return True
        self.inventory[item_name]['quantity'] += int(quantity)
        return True

    def display_items(self):
        if not self.inventory:
            return False
        parts = []
        for name, data in self.inventory.items():
            parts.append(f"{name} - ${data['price']:.2f} [{data['quantity']}]")
        return "\n".join(parts)