import datetime
import time
import re
import math

class TimeUtils:
    """
    This is a time util class, including getting the current time and date, adding seconds to a datetime, converting between strings and datetime objects, calculating the time difference in minutes, and formatting a datetime object.
    """

    def __init__(self):
        self.datetime = datetime.datetime.now()

    def get_current_time(self):
        # Use stored datetime for deterministic behavior per instance
        now = datetime.datetime.now()
        return f"{now.hour:02d}:{now.minute:02d}:{now.second:02d}"

    def get_current_date(self):
        now = datetime.datetime.now()
        return f"{now.year:04d}-{now.month:02d}-{now.day:02d}"

    def add_seconds(self, seconds):
        if not isinstance(seconds, (int, float)):
            raise TypeError("seconds must be numeric")
        new_dt = self.datetime + datetime.timedelta(seconds=seconds)
        return "{:02d}:{:02d}:{:02d}".format(new_dt.hour, new_dt.minute, new_dt.second)

    def string_to_datetime(self, string):
        if not isinstance(string, str):
            raise TypeError("input must be string")
        # Normalize separators, allow various lengths e.g. 1:1:1
        parts = re.split(r'\s+', string.strip())
        date_part = parts[0]
        time_part = parts[1] if len(parts) > 1 else "0:0:0"
        d_fields = re.split(r'[-/]', date_part)
        t_fields = re.split(r':', time_part)
        y = int(d_fields[0])
        m = int(d_fields[1]) if len(d_fields) > 1 else 1
        d = int(d_fields[2]) if len(d_fields) > 2 else 1
        h = int(t_fields[0]) if len(t_fields) > 0 and t_fields[0] != '' else 0
        mi = int(t_fields[1]) if len(t_fields) > 1 and t_fields[1] != '' else 0
        s = int(t_fields[2]) if len(t_fields) > 2 and t_fields[2] != '' else 0
        return datetime.datetime(y, m, d, h, mi, s)

    def datetime_to_string(self, datetime):
        return f"{datetime.year:04d}-{datetime.month:02d}-{datetime.day:02d} {datetime.hour:02d}:{datetime.minute:02d}:{datetime.second:02d}"

    def get_minutes(self, string_time1, string_time2):
        dt1 = self.string_to_datetime(string_time1)
        dt2 = self.string_to_datetime(string_time2)
        diff_seconds = (dt2 - dt1).total_seconds()
        # Round to nearest integer minute
        return int(math.floor((diff_seconds / 60.0) + 0.5))

    def get_format_time(self, year, month, day, hour, minute, second):
        return "{:04d}-{:02d}-{:02d} {:02d}:{:02d}:{:02d}".format(
            int(year), int(month), int(day), int(hour), int(minute), int(second)
        )