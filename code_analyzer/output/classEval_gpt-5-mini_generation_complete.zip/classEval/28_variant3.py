import sqlite3
import pandas as pd

class DatabaseProcessor:
    """
    This is a class for processing a database, supporting to create tables, insert data into the database, search for data based on name, and delete data from the database.
    """

    def __init__(self, database_name):
        """
        Initialize database name of database processor
        """
        self.database_name = database_name

    def create_table(self, table_name, key1, key2):
        if not all(isinstance(x, str) for x in (table_name, key1, key2)):
            raise ValueError("Identifiers must be strings")
        conn = sqlite3.connect(self.database_name)
        try:
            conn.execute('BEGIN')
            conn.execute(f'CREATE TABLE IF NOT EXISTS "{table_name}" (id INTEGER PRIMARY KEY, "{key1}" TEXT, "{key2}" INTEGER)')
            conn.commit()
        finally:
            conn.close()

    def insert_into_database(self, table_name, data):
        if not isinstance(data, list):
            raise ValueError("data must be a list of dicts")
        if not data:
            return
        df = pd.DataFrame.from_records(data)
        if df.empty:
            return
        cols = list(df.columns)
        col_sql = ",".join(f'"{c}"' for c in cols)
        placeholders = ",".join("?" for _ in cols)
        rows = [tuple(x) for x in df[cols].itertuples(index=False, name=None)]
        conn = sqlite3.connect(self.database_name)
        try:
            cur = conn.cursor()
            cur.executemany(f'INSERT INTO "{table_name}" ({col_sql}) VALUES ({placeholders})', rows)
            conn.commit()
        finally:
            conn.close()

    def _get_first_non_id_column(self, conn, table_name):
        cur = conn.execute(f'PRAGMA table_info("{table_name}")')
        info = cur.fetchall()
        for col in info:
            if col[1] != 'id':
                return col[1]
        return None

    def search_database(self, table_name, name):
        conn = sqlite3.connect(self.database_name)
        conn.row_factory = sqlite3.Row
        try:
            col = self._get_first_non_id_column(conn, table_name)
            if not col:
                return None
            cur = conn.execute(f'SELECT * FROM "{table_name}" WHERE "{col}" = ?', (name,))
            rows = cur.fetchall()
            if not rows:
                return None
            return [tuple(r) for r in rows]
        finally:
            conn.close()

    def delete_from_database(self, table_name, name):
        conn = sqlite3.connect(self.database_name)
        try:
            col = self._get_first_non_id_column(conn, table_name)
            if not col:
                return
            conn.execute(f'DELETE FROM "{table_name}" WHERE "{col}" = ?', (name,))
            conn.commit()
        finally:
            conn.close()