from collections import defaultdict

class ShoppingCart:
    """
    The class manages items, their prices, quantities, and allows to for add, removie, view items, and calculate the total price.
    """

    def __init__(self):
        """
        Initialize the items representing the shopping list as an empty dictionary
        """
        # each entry: item -> {"price": float, "quantity": int}
        self.items = {}

    def add_item(self, item, price, quantity=1):
        q = int(quantity)
        if q <= 0:
            return
        p = float(price)
        if item in self.items:
            current = self.items[item]
            # enforce consistent price; if different, raise to signal the caller
            if current["price"] != p:
                raise ValueError("Price mismatch for existing item")
            current["quantity"] += q
        else:
            self.items[item] = {"price": p, "quantity": q}

    def remove_item(self, item, quantity=1):
        q = int(quantity)
        if q <= 0:
            return
        if item not in self.items:
            raise KeyError("Item not in cart")
        if self.items[item]["quantity"] > q:
            self.items[item]["quantity"] -= q
        else:
            del self.items[item]

    def view_items(self) -> dict:
        return {name: {"price": info["price"], "quantity": info["quantity"]} for name, info in self.items.items()}

    def total_price(self) -> float:
        return sum(info["price"] * info["quantity"] for info in self.items.values())