from datetime import datetime

class EmailClient:
    def __init__(self, addr, capacity) -> None:
        self.addr = addr
        self.capacity = float(capacity)
        # store time as datetime objects for precise ordering
        self.inbox = []

    def send_to(self, recv, content, size):
        size = float(size)
        if not isinstance(recv, EmailClient):
            return False
        if recv.is_full_with_one_more_email(size):
            return False
        email = {
            'sender': self.addr,
            'receiver': recv.addr,
            'content': content,
            'size': size,
            'time': datetime.now(),
            'state': 'unread'
        }
        recv.inbox.append(email)
        return True

    def fetch(self):
        # find first unread email in insertion order
        for i, mail in enumerate(self.inbox):
            if mail.get('state') == 'unread':
                # convert time to formatted string when returning
                mail['state'] = 'read'
                out = dict(mail)
                t = out.get('time')
                if isinstance(t, datetime):
                    out['time'] = t.strftime("%Y-%m-%d %H:%M:%S")
                return out
        return None

    def is_full_with_one_more_email(self, size):
        size = float(size)
        return (self.get_occupied_size() + size) > self.capacity

    def get_occupied_size(self):
        total = 0.0
        for mail in self.inbox:
            s = mail.get('size', 0)
            try:
                total += float(s)
            except Exception:
                pass
        if total.is_integer():
            return int(total)
        return total

    def clear_inbox(self, size):
        size = float(size)
        # remove oldest emails first based on stored datetime; if no datetime, use list order
        # build list sorted by time ascending but we will remove from original list preserving others
        while self.is_full_with_one_more_email(size) and self.inbox:
            # find index of the oldest
            oldest_index = 0
            oldest_time = self.inbox[0].get('time')
            for idx, mail in enumerate(self.inbox):
                t = mail.get('time')
                if isinstance(t, datetime) and isinstance(oldest_time, datetime):
                    if t < oldest_time:
                        oldest_time = t
                        oldest_index = idx
                # if times are not comparable (e.g., None or strings), prefer lower index (keep as is)
            self.inbox.pop(oldest_index)