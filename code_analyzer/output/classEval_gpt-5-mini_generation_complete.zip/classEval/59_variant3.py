from datetime import datetime
import numpy as np

class MovieBookingSystem:
    class Movie:
        def __init__(self, name, price, start_time, end_time, n):
            self.name = name
            self.price = float(price)
            self.start_time = start_time
            self.end_time = end_time
            self.seats = np.zeros((n, n), dtype=float)

    def __init__(self):
        self.movies = []

    def add_movie(self, name, price, start_time, end_time, n):
        st = datetime.strptime(start_time, "%H:%M")
        et = datetime.strptime(end_time, "%H:%M")
        movie = MovieBookingSystem.Movie(name, price, st, et, n)
        self.movies.append(movie)

    def book_ticket(self, name, seats_to_book):
        movie = None
        for m in self.movies:
            if m.name == name:
                movie = m
                break
        if movie is None:
            return "Movie not found."
        seats = movie.seats
        rows, cols = seats.shape
        for seat in seats_to_book:
            if not isinstance(seat, tuple) or len(seat) != 2:
                return "Booking failed."
            r, c = seat
            if r < 0 or c < 0 or r >= rows or c >= cols:
                return "Booking failed."
            if seats[r, c] != 0.0:
                return "Booking failed."
        for r, c in seats_to_book:
            seats[r, c] = 1.0
        return "Booking success."

    def available_movies(self, start_time, end_time):
        st = datetime.strptime(start_time, "%H:%M")
        et = datetime.strptime(end_time, "%H:%M")
        return [m.name for m in self.movies if m.start_time >= st and m.end_time <= et]

# Classification response:
# helper class extraction;type conversion;temporary variable;tuple unpacking;list comprehension;input validation;sentinel flag;flattened conditional;guard clause