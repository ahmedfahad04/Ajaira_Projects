import numpy as np


class MetricsCalculator2:
    """
    The class provides to calculate Mean Reciprocal Rank (MRR) and Mean Average Precision (MAP) based on input data, where MRR measures the ranking quality and MAP measures the average precision.
    """

    def __init__(self):
        pass

    @staticmethod
    def _normalize_input(data):
        # Accept single tuple or list of tuples
        if isinstance(data, tuple) or (not isinstance(data, list) and hasattr(data, "__iter__")) and not any(isinstance(x, tuple) for x in data):
            # If it's a single tuple: (labels, gt)
            if isinstance(data, tuple):
                return [data]
        if isinstance(data, list) and data and isinstance(data[0], tuple):
            return data
        # fallback: try to treat as single data
        return [data]

    @staticmethod
    def mrr(data):
        items = MetricsCalculator2._normalize_input(data)
        scores = []
        for itm in items:
            if not isinstance(itm, tuple) and not isinstance(itm, list):
                # malformed, skip
                scores.append(0.0)
                continue
            labels = itm[0]
            # find first 1
            rr = 0.0
            try:
                for idx, v in enumerate(labels, start=1):
                    if int(v) == 1:
                        rr = 1.0 / idx
                        break
            except Exception:
                rr = 0.0
            scores.append(float(rr))
        mean = float(np.mean(scores)) if scores else 0.0
        return mean, scores

    @staticmethod
    def map(data):
        items = MetricsCalculator2._normalize_input(data)
        aps = []
        for itm in items:
            if not isinstance(itm, tuple) and not isinstance(itm, list):
                aps.append(0.0)
                continue
            labels = list(itm[0])
            gt = itm[1] if len(itm) > 1 else sum(int(x) for x in labels)
            gt = float(gt) if gt is not None else 0.0
            if gt == 0:
                aps.append(0.0)
                continue
            hit = 0
            s = 0.0
            for i, v in enumerate(labels, start=1):
                if int(v) == 1:
                    hit += 1
                    s += hit / i
            ap = s / gt
            aps.append(float(ap))
        mean = float(np.mean(aps)) if aps else 0.0
        return mean, aps

# Classification response:
# helper function extraction; flattened conditional; enumerate loop; accumulator list; list conversion; any/all usage; generator expression; exception handling; input validation; empty input handling; type conversion; error suppression