class AssessmentSystem:
    """
    This is a class as an student assessment system, which supports add student, add course score, calculate GPA, and other functions for students and courses.
    """

    def __init__(self):
        """
        Initialize the students dict in assessment system.
        """
        self.students = {}

    def add_student(self, name, grade, major):
        entry = {'name': name, 'grade': grade, 'major': major, 'courses': {}}
        self.students[name] = entry

    def add_course_score(self, name, course, score):
        if name not in self.students:
            return
        self.students[name]['courses'][course] = score

    def get_gpa(self, name):
        student = self.students.get(name)
        if not student:
            return None
        courses = student['courses']
        if not courses:
            return None
        return sum(courses.values()) / len(courses)

    def get_all_students_with_fail_course(self):
        result = []
        for name, student in self.students.items():
            if any(score < 60 for score in student['courses'].values()):
                result.append(name)
        return result

    def get_course_average(self, course):
        scores = []
        for student in self.students.values():
            if course in student['courses']:
                scores.append(student['courses'][course])
        if not scores:
            return None
        return sum(scores) / len(scores)

    def get_top_student(self):
        gpa_list = [(self.get_gpa(name), name) for name in self.students]
        gpa_list = [(g, n) for g, n in gpa_list if g is not None]
        if not gpa_list:
            return None
        gpa_list.sort(key=lambda x: (-x[0], x[1]))
        return gpa_list[0][1]