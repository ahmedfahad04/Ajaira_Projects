import random
import itertools

class BlackjackGame:
    """
    This is a class representing a game of blackjack, which includes creating a deck, calculating the value of a hand, and determine the winner based on the hand values of the player and dealer.
    """

    def __init__(self):
        self.deck = self.create_deck()
        self.player_hand = []
        self.dealer_hand = []

    def create_deck(self):
        ranks = ['A'] + [str(i) for i in range(2, 11)] + ['J', 'Q', 'K']
        suits = ['S', 'H', 'D', 'C']
        deck = [''.join((r, s)) for r, s in itertools.product(ranks, suits)]
        random.shuffle(deck)
        return deck

    def calculate_hand_value(self, hand):
        values = []
        aces = 0
        for c in hand:
            r = c[:-1]
            if r == 'A':
                values.append(11)
                aces += 1
            elif r in ('J', 'Q', 'K'):
                values.append(10)
            else:
                values.append(int(r))
        total = sum(values)
        # reduce aces as needed
        for _ in range(aces):
            if total <= 21:
                break
            total -= 10
        return total

    def check_winner(self, player_hand, dealer_hand):
        p = self.calculate_hand_value(player_hand)
        d = self.calculate_hand_value(dealer_hand)
        if p <= 21 and d <= 21:
            # closer to 21 wins; tie goes to dealer
            if abs(21 - p) < abs(21 - d):
                return 'Player wins'
            else:
                return 'Dealer wins'
        else:
            # at least one bust: lower total wins
            if p < d:
                return 'Player wins'
            else:
                return 'Dealer wins'