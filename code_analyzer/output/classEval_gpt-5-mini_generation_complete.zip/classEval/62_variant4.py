import re
class NLPDataProcessor:
    """
    The class processes NLP data by removing stop words from a list of strings using a pre-defined stop word list.
    """
    @staticmethod
    def construct_stop_word_list():
        return ['a', 'an', 'the']

    @staticmethod
    def remove_stop_words(string_list, stop_word_list):
        if string_list is None:
            return []
        stops = set(w.lower() for w in stop_word_list)
        result = []
        for line in string_list:
            tokens = line.split()
            kept = []
            for token in tokens:
                # remove leading/trailing punctuation characters for matching
                stripped = re.sub(r'^[^\w]+|[^\w]+$', '', token).lower()
                if stripped in stops and stripped != '':
                    continue
                kept.append(token)
            result.append(kept)
        return result

    @staticmethod
    def process(string_list):
        stops = NLPDataProcessor.construct_stop_word_list()
        return NLPDataProcessor.remove_stop_words(string_list, stops)

# Classification response:
# guard clause; empty input handling; set conversion; membership test; regex usage; generator expression; accumulator list; temporary variable; copy before mutation; string formatting change; behavior change