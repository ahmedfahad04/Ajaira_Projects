import json
import re

class TextFileProcessor:
    """
    The class handles reading, writing, and processing text files. It can read the file as JSON, read the raw text, write content to the file, and process the file by removing non-alphabetic characters.
    """

    def __init__(self, file_path):
        self.file_path = file_path

    def read_file_as_json(self):
        with open(self.file_path, 'r', encoding='utf-8', errors='strict') as f:
            return json.load(f)

    def read_file(self):
        with open(self.file_path, 'r', encoding='utf-8', errors='replace') as f:
            return f.read()

    def write_file(self, content):
        if isinstance(content, str):
            data = content
        else:
            try:
                data = json.dumps(content, ensure_ascii=False)
            except Exception:
                data = str(content)
        with open(self.file_path, 'w', encoding='utf-8') as f:
            f.write(data)

    def process_file(self):
        raw = self.read_file()
        processed = re.sub(r'[^A-Za-z]+', '', raw)
        with open(self.file_path, 'w', encoding='utf-8') as f:
            f.write(processed)
        return processed