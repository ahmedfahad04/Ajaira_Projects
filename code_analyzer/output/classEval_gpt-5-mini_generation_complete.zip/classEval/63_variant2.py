import re
from collections import Counter

class NLPDataProcessor2:
    """
    The class processes NLP data by extracting words from a list of strings, calculating the frequency of each word, and returning the top 5 most frequent words.
    """

    def process_data(self, string_list):
        out = []
        for s in string_list:
            words = re.findall(r'[A-Za-z]+', s)
            out.append([w.lower() for w in words])
        return out

    def calculate_word_frequency(self, words_list):
        c = Counter()
        for lst in words_list:
            c.update(lst)
        top = c.most_common(5)
        return {w: cnt for w, cnt in top}

    def process(self, string_list):
        wl = self.process_data(string_list)
        return self.calculate_word_frequency(wl)

# Classification response:
# variable renaming;import reorganization;regex usage;list comprehension;dict comprehension;standard library helper;accumulator list