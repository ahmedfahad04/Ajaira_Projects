class ShoppingCart:
    """
    The class manages items, their prices, quantities, and allows to for add, removie, view items, and calculate the total price.
    """

    def __init__(self):
        """
        Initialize the items representing the shopping list as an empty dictionary
        """
        self.items = {}

    def add_item(self, item, price, quantity=1):
        if quantity <= 0:
            return
        if item in self.items:
            # update price to the latest provided, accumulate quantity
            self.items[item]["price"] = float(price)
            self.items[item]["quantity"] += int(quantity)
        else:
            self.items[item] = {"price": float(price), "quantity": int(quantity)}

    def remove_item(self, item, quantity=1):
        if item not in self.items:
            raise KeyError(f"Item '{item}' not found in cart")
        if quantity <= 0:
            return
        remaining = self.items[item]["quantity"] - int(quantity)
        if remaining > 0:
            self.items[item]["quantity"] = remaining
        else:
            del self.items[item]

    def view_items(self) -> dict:
        # return a shallow copy to prevent external mutation
        return {k: {"price": v["price"], "quantity": v["quantity"]} for k, v in self.items.items()}

    def total_price(self) -> float:
        total = 0.0
        for v in self.items.values():
            total += v["price"] * v["quantity"]
        return float(total)