class SQLGenerator:
    """
    This class generates SQL statements for common operations on a table, such as SELECT, INSERT, UPDATE, and DELETE.
    """

    def __init__(self, table_name):
        self.table_name = table_name

    @staticmethod
    def _fmt_value(value):
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "1" if value else "0"
        if isinstance(value, (int, float)):
            return str(value)
        s = str(value).replace("'", "''")
        return "'" + s + "'"

    def select(self, fields=None, condition=None):
        fields_part = "*"
        if fields:
            fields_part = ", ".join(fields)
        sql = f"SELECT {fields_part} FROM {self.table_name}"
        if condition:
            sql += f" WHERE {condition}"
        return sql + ";"

    def insert(self, data):
        if not isinstance(data, dict) or not data:
            raise ValueError("data must be a non-empty dict")
        cols = ", ".join(data.keys())
        vals = ", ".join(self._fmt_value(v) for v in data.values())
        return f"INSERT INTO {self.table_name} ({cols}) VALUES ({vals});"

    def update(self, data, condition):
        if not isinstance(data, dict) or not data:
            raise ValueError("data must be a non-empty dict")
        assignments = ", ".join(f"{k} = {self._fmt_value(v)}" for k, v in data.items())
        sql = f"UPDATE {self.table_name} SET {assignments}"
        if condition:
            sql += f" WHERE {condition}"
        return sql + ";"

    def delete(self, condition):
        sql = f"DELETE FROM {self.table_name}"
        if condition:
            sql += f" WHERE {condition}"
        return sql + ";"

    def select_female_under_age(self, age):
        return "SELECT * FROM {} WHERE age < {} AND gender = 'female';".format(self.table_name, int(age))

    def select_by_age_range(self, min_age, max_age):
        return "SELECT * FROM {} WHERE age BETWEEN {} AND {};".format(self.table_name, int(min_age), int(max_age))