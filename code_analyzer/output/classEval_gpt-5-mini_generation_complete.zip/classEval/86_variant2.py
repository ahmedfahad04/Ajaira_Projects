class TicTacToe:
    """
    The class represents a game of Tic-Tac-Toe and its functions include making a move on the board, checking for a winner, and determining if the board is full.
    """

    def __init__(self, N=3):
        """
        Initialize an NxN game board with all empty spaces and current symble player, default is 'X'.
        """
        self.N = N
        self.board = [[' ' for _ in range(N)] for _ in range(N)]
        self.current_player = 'X'

    def make_move(self, row, col):
        """
        Place the current player's mark at the specified position on the board and switch the mark.
        :param row: int, the row index of the position (0-based)
        :param col: int, the column index of the position (0-based)
        :return: bool, indicating whether the move was successful or not
        """
        if row < 0 or col < 0 or row >= self.N or col >= self.N:
            return False
        if self.board[row][col] != ' ':
            return False
        self.board[row][col] = self.current_player
        self.current_player = 'O' if self.current_player == 'X' else 'X'
        return True

    def check_winner(self):
        """
        Check if there is a winner on the board in rows, columns and diagonals.
        :return: str or None, the mark of the winner ('X' or 'O'), or None if there is no winner yet
        """
        lines = []
        # Rows
        lines.extend(self.board)
        # Columns
        lines.extend([list(col) for col in zip(*self.board)])
        # Diagonals
        lines.append([self.board[i][i] for i in range(self.N)])
        lines.append([self.board[i][self.N - 1 - i] for i in range(self.N)])
        for line in lines:
            if line[0] != ' ' and all(cell == line[0] for cell in line):
                return line[0]
        return None

    def is_board_full(self):
        """
        Check if the game board is completely filled.
        :return: bool, indicating whether the game board is full or not
        """
        return all(cell != ' ' for row in self.board for cell in row)