import re

class Calculator:
    """
    This is a class for a calculator, capable of performing basic arithmetic calculations on numerical expressions using the operators +, -, *, /, and ^ (exponentiation).
    """

    def __init__(self):
        """
        Initialize the operations performed by the five operators'+','-','*','/','^'
        """
        self.operators = {
            '+': lambda x, y: x + y,
            '-': lambda x, y: x - y,
            '*': lambda x, y: x * y,
            '/': lambda x, y: x / y,
            '^': lambda x, y: x ** y
        }

    def precedence(self, operator):
        if operator in ('+','-'):
            return 1
        if operator in ('*','/'):
            return 2
        if operator == '^':
            return 3
        return 0

    def apply_operator(self, operand_stack, operator_stack):
        if not operator_stack or len(operand_stack) < 2:
            return operand_stack, operator_stack
        op = operator_stack.pop()
        b = operand_stack.pop()
        a = operand_stack.pop()
        res = self.operators[op](a, b)
        operand_stack.append(res)
        return operand_stack, operator_stack

    def _tokenize(self, expr):
        tokens = []
        i = 0
        n = len(expr)
        while i < n:
            c = expr[i]
            if c.isspace():
                i += 1
                continue
            if c in '()+-*/^':
                # handle unary
                if c in '+-' :
                    if i == 0 or expr[i-1] in ' (*/^+-':
                        j = i+1
                        num = c
                        dot = False
                        while j < n and (expr[j].isdigit() or expr[j]=='.'):
                            if expr[j]=='.':
                                if dot:
                                    break
                                dot = True
                            num += expr[j]
                            j += 1
                        if len(num) > 1 and (num[1].isdigit() or num[1]=='.'):
                            tokens.append(num)
                            i = j
                            continue
                tokens.append(c)
                i += 1
            elif c.isdigit() or c == '.':
                j = i
                dot = False
                num = ''
                while j < n and (expr[j].isdigit() or expr[j]=='.'):
                    if expr[j]=='.':
                        if dot:
                            break
                        dot = True
                    num += expr[j]
                    j += 1
                tokens.append(num)
                i = j
            else:
                return None
        return tokens

    def calculate(self, expression):
        tokens = self._tokenize(expression)
        if tokens is None:
            return None

        # Recursive descent parser
        self.tokens = tokens
        self.pos = 0

        def peek():
            return self.tokens[self.pos] if self.pos < len(self.tokens) else None

        def consume(tok=None):
            t = peek()
            if tok is None or t == tok:
                self.pos += 1
                return t
            return None

        def parse_primary():
            t = peek()
            if t is None:
                return None
            if t == '(':
                consume('(')
                val = parse_expression()
                if peek() != ')':
                    return None
                consume(')')
                return val
            if re.fullmatch(r'[+-]?\d+(\.\d+)?', t):
                consume()
                return float(t)
            return None

        def parse_power():
            left = parse_primary()
            if left is None:
                return None
            if peek() == '^':
                consume('^')
                right = parse_power()
                if right is None:
                    return None
                try:
                    return left ** right
                except Exception:
                    raise
            return left

        def parse_term():
            left = parse_power()
            if left is None:
                return None
            while peek() in ('*','/'):
                op = consume()
                right = parse_power()
                if right is None:
                    return None
                try:
                    left = self.operators[op](left, right)
                except Exception:
                    raise
            return left

        def parse_expression():
            left = parse_term()
            if left is None:
                return None
            while peek() in ('+','-'):
                op = consume()
                right = parse_term()
                if right is None:
                    return None
                left = self.operators[op](left, right)
            return left

        try:
            result = parse_expression()
        except Exception:
            return None
        if result is None:
            return None
        if self.pos != len(self.tokens):
            return None
        try:
            return float(result)
        except Exception:
            return None