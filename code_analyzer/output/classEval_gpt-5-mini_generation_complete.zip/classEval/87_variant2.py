import datetime
import time
import re

class TimeUtils:
    """
    This is a time util class, including getting the current time and date, adding seconds to a datetime, converting between strings and datetime objects, calculating the time difference in minutes, and formatting a datetime object.
    """

    def __init__(self):
        """
        Get the current datetime
        """
        self.datetime = datetime.datetime.now()

    def get_current_time(self):
        return time.strftime('%H:%M:%S', time.localtime())

    def get_current_date(self):
        return time.strftime('%Y-%m-%d', time.localtime())

    def add_seconds(self, seconds):
        if not isinstance(seconds, (int, float)):
            raise TypeError("seconds must be numeric")
        # use the stored datetime
        new_ts = time.mktime(self.datetime.timetuple()) + seconds
        lt = time.localtime(new_ts)
        return time.strftime('%H:%M:%S', lt)

    def string_to_datetime(self, string):
        # Accept varied separators and single-digit fields
        if not isinstance(string, str):
            raise TypeError("input must be a string")
        nums = re.findall(r'\d+', string)
        if len(nums) < 3:
            raise ValueError("invalid date time string")
        # fill missing time parts with zeros
        while len(nums) < 6:
            nums.append('0')
        y, m, d, H, M, S = (int(n) for n in nums[:6])
        return datetime.datetime(y, m, d, H, M, S)

    def datetime_to_string(self, datetime):
        return datetime.strftime('%Y-%m-%d %H:%M:%S')

    def get_minutes(self, string_time1, string_time2):
        dt1 = self.string_to_datetime(string_time1)
        dt2 = self.string_to_datetime(string_time2)
        diff = (dt2 - dt1).total_seconds()
        # round to nearest minute
        return int(round(diff / 60.0))

    def get_format_time(self, year, month, day, hour, minute, second):
        return "{:04d}-{:02d}-{:02d} {:02d}:{:02d}:{:02d}".format(
            int(year), int(month), int(day), int(hour), int(minute), int(second)
        )