import re

class PersonRequest:
    """
    This class validates input personal information data and sets invalid fields to None based to specific rules.
    """

    def __init__(self, name: str, sex: str, phoneNumber: str):
        self.name = self._validate_name(name)
        self.sex = self._validate_sex(sex)
        self.phoneNumber = self._validate_phoneNumber(phoneNumber)

    def _validate_name(self, name: str) -> str:
        if name is None:
            return None
        s = str(name).strip()
        if s == "" or len(s) > 33:
            return None
        return s

    def _validate_sex(self, sex: str) -> str:
        if sex is None:
            return None
        s = str(sex).strip()
        return s if s in ("Man", "Woman", "UGM") else None

    def _validate_phoneNumber(self, phoneNumber: str) -> str:
        if phoneNumber is None:
            return None
        s = str(phoneNumber)
        digits = re.sub(r"\D", "", s)
        if digits == "" or len(digits) != 11:
            return None
        return digits

# Classification response:
# guard clause;conditional expression;regex usage;type conversion;string formatting change;temporary variable;input validation;empty input handling;behavior change