import sqlite3

class StudentDatabaseProcessor:
    """
    This is a class with database operation, including inserting student information, searching for student information by name, and deleting student information by name.
    """

    def __init__(self, database_name):
        """
        Initializes the StudentDatabaseProcessor object with the specified database name.
        :param database_name: str, the name of the SQLite database.
        """
        self.database_name = database_name

    def create_student_table(self):
        """
        Creates a "students" table in the database if it does not exist already.Fields include ID of type int, name of type str, age of type int, gender of type str, and grade of type int
        :return: None
        """
        with sqlite3.connect(self.database_name) as conn:
            conn.execute(
                "CREATE TABLE IF NOT EXISTS students (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, age INTEGER, gender TEXT, grade INTEGER);"
            )
            conn.commit()

    def insert_student(self, student_data):
        """
        Inserts a new student into the "students" table.
        :param student_data: dict, a dictionary containing the student's information (name, age, gender, grade).
        :return: None
        """
        if not isinstance(student_data, dict):
            raise ValueError("student_data must be a dict")
        name = student_data.get("name")
        if not name:
            raise ValueError("name is required")
        age = student_data.get("age")
        gender = student_data.get("gender")
        grade = student_data.get("grade")
        with sqlite3.connect(self.database_name) as conn:
            conn.execute(
                "INSERT INTO students (name, age, gender, grade) VALUES (?, ?, ?, ?);",
                (name, age, gender, grade),
            )
            conn.commit()

    def search_student_by_name(self, name):
        """
        Searches for a student in the "students" table by their name (case-insensitive, partial match).
        :param name: str, the name of the student to search for.
        :return: list of tuples, the rows from the "students" table that match the search criteria.
        """
        pattern = f"%{name}%"
        with sqlite3.connect(self.database_name) as conn:
            cur = conn.execute(
                "SELECT id, name, age, gender, grade FROM students WHERE name LIKE ? COLLATE NOCASE;",
                (pattern,),
            )
            rows = cur.fetchall()
        return rows

    def delete_student_by_name(self, name):
        """
        Deletes a student from the "students" table by their name.
        :param name: str, the name of the student to delete.
        :return: None
        """
        with sqlite3.connect(self.database_name) as conn:
            conn.execute("DELETE FROM students WHERE name = ?;", (name,))
            conn.commit()