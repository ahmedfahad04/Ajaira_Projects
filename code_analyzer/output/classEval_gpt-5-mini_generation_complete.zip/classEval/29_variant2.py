from collections import Counter
from decimal import Decimal, ROUND_HALF_UP

class DataStatistics:
    """
    This is a class for performing data statistics, supporting to calculate the mean, median, and mode of a given data set.
    """

    def _to_decimal(self, x):
        return Decimal(str(x))

    def _round_two(self, dec):
        quant = Decimal('0.00')
        return float(dec.quantize(quant, rounding=ROUND_HALF_UP))

    def mean(self, data):
        if not data:
            raise ValueError("data must not be empty")
        total = sum(self._to_decimal(x) for x in data)
        mean_dec = total / Decimal(len(data))
        return self._round_two(mean_dec)

    def median(self, data):
        if not data:
            raise ValueError("data must not be empty")
        s = sorted(data)
        n = len(s)
        if n % 2 == 1:
            med = Decimal(str(s[n // 2]))
        else:
            med = (self._to_decimal(s[n // 2 - 1]) + self._to_decimal(s[n // 2])) / Decimal(2)
        return self._round_two(med)

    def mode(self, data):
        if not data:
            raise ValueError("data must not be empty")
        counts = Counter(data)
        maxc = max(counts.values())
        modes = [k for k, v in counts.items() if v == maxc]
        return sorted(modes)