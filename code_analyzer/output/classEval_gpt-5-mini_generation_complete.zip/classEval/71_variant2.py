class PushBoxGame:
    """
    This class implements a functionality of a sokoban game, where the player needs to move boxes to designated targets in order to win.
    """
    def __init__(self, map):
        self.map = map
        self.player_row = 0
        self.player_col = 0
        self.targets = []
        self.boxes = []
        self.target_count = 0
        self.is_game_over = False
        self._grid = [list(row) for row in map]
        self._rows = len(self._grid)
        self._cols = len(self._grid[0]) if self._rows else 0
        self.init_game()

    def init_game(self):
        self.targets = []
        self.boxes = []
        for r in range(self._rows):
            for c in range(self._cols):
                ch = self._grid[r][c]
                if ch == 'O':
                    self.player_row, self.player_col = r, c
                    self._grid[r][c] = ' '
                elif ch == 'G':
                    self.targets.append((r, c))
                    # keep as G for rendering
                elif ch == 'X':
                    self.boxes.append((r, c))
                    self._grid[r][c] = ' '
        self.target_count = len(self.targets)
        self._targets_set = set(self.targets)
        self._boxes_set = set(self.boxes)
        self.is_game_over = self.check_win()

    def check_win(self):
        self.is_game_over = all(b in self._targets_set for b in self._boxes_set)
        return self.is_game_over

    def _cell_wall(self, r, c):
        return self.map[r][c] == '#'

    def move(self, direction):
        if self.is_game_over:
            return True
        moves = {'w': (-1, 0), 's': (1, 0), 'a': (0, -1), 'd': (0, 1)}
        if direction not in moves:
            return self.is_game_over
        dr, dc = moves[direction]
        nr, nc = self.player_row + dr, self.player_col + dc
        if not (0 <= nr < self._rows and 0 <= nc < self._cols):
            return self.is_game_over
        if self._cell_wall(nr, nc):
            return self.is_game_over
        if (nr, nc) in self._boxes_set:
            br, bc = nr + dr, nc + dc
            if not (0 <= br < self._rows and 0 <= bc < self._cols):
                return self.is_game_over
            if self._cell_wall(br, bc) or (br, bc) in self._boxes_set:
                return self.is_game_over
            # push box
            self._boxes_set.remove((nr, nc))
            self._boxes_set.add((br, bc))
        self.player_row, self.player_col = nr, nc
        self.boxes = list(self._boxes_set)
        return self.check_win()

# Classification response:
# early return;guard clause;flattened conditional;set conversion;list comprehension;generator expression;any/all usage;dictionary lookup;helper function extraction;tuple unpacking;membership test;list conversion;in-place mutation;input validation;boundary case handling;empty input handling