from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
import os


class DocFileHandler:
    """
    This is a class that handles Word documents and provides functionalities for reading, writing, and modifying the content of Word documents.
    """

    def __init__(self, file_path):
        self.file_path = file_path

    def read_text(self):
        if not os.path.exists(self.file_path):
            return ""
        try:
            doc = Document(self.file_path)
        except Exception:
            return ""
        texts = []
        for p in doc.paragraphs:
            if p.text:
                texts.append(p.text)
        for table in doc.tables:
            for row in table.rows:
                texts.append(", ".join(cell.text for cell in row.cells))
        return "\n".join(texts)

    def write_text(self, content, font_size=12, alignment='left'):
        try:
            # overwrite the file by creating a fresh Document
            doc = Document()
            align_val = self._get_alignment_value(alignment)
            if isinstance(content, str):
                lines = content.splitlines()
            else:
                lines = [str(content)]
            for line in lines:
                p = doc.add_paragraph()
                p.alignment = align_val
                r = p.add_run(line)
                try:
                    r.font.size = Pt(int(font_size))
                except Exception:
                    r.font.size = Pt(12)
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def add_heading(self, heading, level=1):
        try:
            doc = Document(self.file_path) if os.path.exists(self.file_path) else Document()
            doc.add_heading(heading, level=level)
            # ensure last heading has sensible size
            try:
                par = doc.paragraphs[-1]
                size = {1: 20, 2: 16, 3: 14}.get(level, 12)
                for run in par.runs:
                    run.font.size = Pt(size)
            except Exception:
                pass
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def add_table(self, data):
        try:
            if not isinstance(data, (list, tuple)) or not data:
                return False
            cols = max((len(r) for r in data if isinstance(r, (list, tuple))), default=0)
            if cols == 0:
                return False
            doc = Document(self.file_path) if os.path.exists(self.file_path) else Document()
            table = doc.add_table(rows=len(data), cols=cols)
            table.style = 'Table Grid'
            for i, row in enumerate(data):
                for j in range(cols):
                    val = ""
                    if isinstance(row, (list, tuple)) and j < len(row):
                        val = "" if row[j] is None else str(row[j])
                    table.cell(i, j).text = val
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def _get_alignment_value(self, alignment):
        if isinstance(alignment, WD_PARAGRAPH_ALIGNMENT):
            return alignment
        if not isinstance(alignment, str):
            return WD_PARAGRAPH_ALIGNMENT.LEFT
        a = alignment.strip().lower()
        if a in ("center", "centre"):
            return WD_PARAGRAPH_ALIGNMENT.CENTER
        if a == "right":
            return WD_PARAGRAPH_ALIGNMENT.RIGHT
        return WD_PARAGRAPH_ALIGNMENT.LEFT