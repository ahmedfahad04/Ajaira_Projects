import numpy as np


class MetricsCalculator2:
    """
    The class provides to calculate Mean Reciprocal Rank (MRR) and Mean Average Precision (MAP) based on input data, where MRR measures the ranking quality and MAP measures the average precision.
    """

    def __init__(self):
        pass

    @staticmethod
    def _ensure_list(data):
        if isinstance(data, list):
            return data
        return [data]

    @staticmethod
    def mrr(data):
        data_list = MetricsCalculator2._ensure_list(data)
        rr_list = []
        for pair in data_list:
            if not isinstance(pair, (list, tuple)) or len(pair) == 0:
                rr_list.append(0.0)
                continue
            labels = np.asarray(pair[0], dtype=int)
            ones = np.nonzero(labels == 1)[0]
            if ones.size == 0:
                rr_list.append(0.0)
            else:
                rr_list.append(1.0 / float(ones[0] + 1))
        mean_rr = float(np.mean(rr_list)) if rr_list else 0.0
        return mean_rr, rr_list

    @staticmethod
    def map(data):
        data_list = MetricsCalculator2._ensure_list(data)
        ap_list = []
        for pair in data_list:
            if not isinstance(pair, (list, tuple)) or len(pair) == 0:
                ap_list.append(0.0)
                continue
            labels = np.asarray(pair[0], dtype=int)
            gt = pair[1] if len(pair) > 1 else int(labels.sum())
            if gt == 0:
                ap_list.append(0.0)
                continue
            cumsum = np.cumsum(labels)
            indices = np.nonzero(labels == 1)[0]
            if indices.size == 0:
                ap_list.append(0.0)
                continue
            precisions = cumsum[indices] / (indices + 1.0)
            ap = float(precisions.sum()) / float(gt)
            ap_list.append(ap)
        mean_ap = float(np.mean(ap_list)) if ap_list else 0.0
        return mean_ap, ap_list

# Classification response:
# variable renaming;helper function extraction;guard clause;flattened conditional;accumulator list;input validation;default value handling;behavior change;loop rewrite;numpy vectorization