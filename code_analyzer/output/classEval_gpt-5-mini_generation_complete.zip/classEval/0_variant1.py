import logging
import datetime

class AccessGatewayFilter:
    """
    This class is a filter used for accessing gateway filtering, primarily for authentication and access log recording.
    """

    def __init__(self):
        self.public_prefixes = ('/login', '/public')
        self.api_prefix = '/api'
        self.current_user = None
        logging.basicConfig(level=logging.INFO)

    def filter(self, request):
        """
        Filter the incoming request based on certain rules and conditions.
        """
        if not isinstance(request, dict):
            return False

        path = request.get('path', '/')
        method = request.get('method', 'GET')

        # Allow login and public endpoints
        if path.startswith(self.public_prefixes):
            return True

        # Allow simple health check or options
        if method.upper() == 'OPTIONS' or path == '/health':
            return True

        # API endpoints require authentication
        if path.startswith(self.api_prefix):
            user = self.get_jwt_user(request)
            if user:
                self.set_current_user_info_and_log(user)
                return True
            return False

        # Default allow
        return True

    def is_start_with(self, request_uri):
        """
        Check if the request URI starts with certain prefixes.
        """
        if not isinstance(request_uri, str):
            return False
        prefixes = ('/api', '/login')
        return request_uri.startswith(prefixes)

    def get_jwt_user(self, request):
        """
        Get the user information from the JWT token in the request.
        Expects headers: {'Authorization': {'user': {...}, 'jwt': 'usernameYYYY-MM-DD'}}
        """
        headers = request.get('headers') or {}
        auth = headers.get('Authorization') or {}
        if not isinstance(auth, dict):
            return None

        user = auth.get('user')
        token = auth.get('jwt')

        # If user object present and no token required for public internal calls
        if user and not token:
            return user

        if not token:
            return None

        # token expected to be username + todays_date (YYYY-MM-DD)
        today_str = str(datetime.date.today())
        if not token.endswith(today_str):
            return None

        username = token[: -len(today_str)]
        username = username or None

        # If user provided, verify names match (if possible)
        if user:
            if isinstance(user, dict):
                name = user.get('name') or user.get('username')
                if name and username and name != username:
                    return None
                return user
            return None

        # Construct user from token
        if username:
            return {'name': username}

        return None

    def set_current_user_info_and_log(self, user):
        """
        Set the current user information and log the access.
        """
        self.current_user = user
        now = datetime.datetime.utcnow().isoformat() + 'Z'
        try:
            name = user.get('name') if isinstance(user, dict) else str(user)
        except Exception:
            name = str(user)
        logging.info("Access log - time=%s user=%s", now, name)