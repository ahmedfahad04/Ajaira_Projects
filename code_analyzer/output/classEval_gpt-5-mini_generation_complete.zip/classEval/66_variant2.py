class NumericEntityUnescaper:
    """
    This is a class that provides functionality to replace numeric entities with their corresponding characters in a given string.
    """

    def __init__(self):
        pass

    def replace(self, string):
        if not string:
            return string
        s = string
        n = len(s)
        i = 0
        out = []
        while i < n:
            if s[i] == '&' and i + 1 < n and s[i+1] == '#':
                j = i + 2
                is_hex = False
                if j < n and (s[j] == 'x' or s[j] == 'X'):
                    is_hex = True
                    j += 1
                start_digits = j
                while j < n:
                    c = s[j]
                    if is_hex:
                        if not self.is_hex_char(c):
                            break
                    else:
                        if not c.isdigit():
                            break
                    j += 1
                # require at least one digit and a trailing semicolon
                if j > start_digits and j < n and s[j] == ';':
                    num_str = s[start_digits:j]
                    try:
                        code = int(num_str, 16 if is_hex else 10)
                        if 0 <= code <= 0x10FFFF:
                            out.append(chr(code))
                            i = j + 1
                            continue
                    except Exception:
                        pass
                # not a valid entity: fall through and treat '&' literally
                out.append(s[i])
                i += 1
            else:
                out.append(s[i])
                i += 1
        return ''.join(out)

    @staticmethod
    def is_hex_char(char):
        if not isinstance(char, str) or len(char) != 1:
            return False
        return ('0' <= char <= '9') or ('a' <= char.lower() <= 'f')

# Classification response:
# variable renaming; guard clause; flattened conditional; try-except wrapper; temporary variable; input validation; boundary case handling; type check; two pointer; brute force; behavior change