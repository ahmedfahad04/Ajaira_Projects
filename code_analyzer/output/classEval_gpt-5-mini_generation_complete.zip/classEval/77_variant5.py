import random

class Snake:
    """
    The class is a snake game, with allows snake to move and eat food, and also enables to reset, and generat a random food position.
    This variant uses a simple list and awards 10 points per food (alternative scoring).
    """

    def __init__(self, SCREEN_WIDTH, SCREEN_HEIGHT, BLOCK_SIZE, food_position):
        self.SCREEN_WIDTH = int(SCREEN_WIDTH)
        self.SCREEN_HEIGHT = int(SCREEN_HEIGHT)
        self.BLOCK_SIZE = int(BLOCK_SIZE)
        self.length = 1
        # align center to grid
        cx = int(self.SCREEN_WIDTH / 2)
        cy = int(self.SCREEN_HEIGHT / 2)
        cx = (cx // self.BLOCK_SIZE) * self.BLOCK_SIZE
        cy = (cy // self.BLOCK_SIZE) * self.BLOCK_SIZE
        cx = max(0, min(cx, self.SCREEN_WIDTH - self.BLOCK_SIZE))
        cy = max(0, min(cy, self.SCREEN_HEIGHT - self.BLOCK_SIZE))
        self.positions = [(cx, cy)]
        self.score = 0
        x, y = int(food_position[0]), int(food_position[1])
        x = max(0, min((x // self.BLOCK_SIZE) * self.BLOCK_SIZE, self.SCREEN_WIDTH - self.BLOCK_SIZE))
        y = max(0, min((y // self.BLOCK_SIZE) * self.BLOCK_SIZE, self.SCREEN_HEIGHT - self.BLOCK_SIZE))
        self.food_position = (x, y)
        if self.food_position in self.positions:
            self.random_food_position()

    def move(self, direction):
        dx = int(direction[0]) * self.BLOCK_SIZE
        dy = int(direction[1]) * self.BLOCK_SIZE
        hx, hy = self.positions[0]
        nx = (hx + dx) % self.SCREEN_WIDTH
        ny = (hy + dy) % self.SCREEN_HEIGHT
        nx = (nx // self.BLOCK_SIZE) * self.BLOCK_SIZE
        ny = (ny // self.BLOCK_SIZE) * self.BLOCK_SIZE
        new_head = (nx, ny)
        if new_head in self.positions:
            self.reset()
            return
        self.positions.insert(0, new_head)
        if new_head == self.food_position:
            # this variant awards 10 points per food (reflecting some doc examples)
            self.eat_food(points=10)
        else:
            while len(self.positions) > self.length:
                self.positions.pop()

    def random_food_position(self):
        possible = []
        for gx in range(0, self.SCREEN_WIDTH, self.BLOCK_SIZE):
            for gy in range(0, self.SCREEN_HEIGHT, self.BLOCK_SIZE):
                if (gx, gy) not in self.positions:
                    possible.append((gx, gy))
        if not possible:
            return
        self.food_position = random.choice(possible)

    def reset(self):
        # reset to initial center
        cx = int(self.SCREEN_WIDTH / 2)
        cy = int(self.SCREEN_HEIGHT / 2)
        cx = (cx // self.BLOCK_SIZE) * self.BLOCK_SIZE
        cy = (cy // self.BLOCK_SIZE) * self.BLOCK_SIZE
        cx = max(0, min(cx, self.SCREEN_WIDTH - self.BLOCK_SIZE))
        cy = max(0, min(cy, self.SCREEN_HEIGHT - self.BLOCK_SIZE))
        self.length = 1
        self.positions = [(cx, cy)]
        self.score = 0
        self.random_food_position()

    def eat_food(self, points=100):
        self.length += 1
        self.score += points
        self.random_food_position()