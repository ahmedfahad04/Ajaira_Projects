import re
class NLPDataProcessor:
    """
    The class processes NLP data by removing stop words from a list of strings using a pre-defined stop word list.
    """
    @staticmethod
    def construct_stop_word_list():
        return ['a', 'an', 'the']

    @staticmethod
    def remove_stop_words(string_list, stop_word_list):
        if not string_list:
            return []
        stop_set = set(s.lower() for s in stop_word_list)
        result = []
        for line in string_list:
            tokens = re.findall(r'\S+', line)
            kept = []
            for tok in tokens:
                # strip non-word characters from both ends for comparison
                core = re.sub(r'^\W+|\W+$', '', tok).lower()
                if core and core in stop_set:
                    continue
                kept.append(tok)
            result.append(kept)
        return result

    @staticmethod
    def process(string_list):
        stops = NLPDataProcessor.construct_stop_word_list()
        return NLPDataProcessor.remove_stop_words(string_list, stops)

# Classification response:
# variable renaming;guard clause;empty input handling;set conversion;generator expression;regex usage;membership test;accumulator list;temporary variable;import reorganization