import string
from itertools import cycle

class DecryptionUtils:
    def __init__(self, key):
        self.key = key or ""

    def caesar_decipher(self, ciphertext, shift):
        try:
            s = int(shift) % 26
        except Exception:
            s = 0
        lower = string.ascii_lowercase
        upper = string.ascii_uppercase
        trans_lower = str.maketrans(lower, lower[-s:] + lower[:-s])
        trans_upper = str.maketrans(upper, upper[-s:] + upper[:-s])
        return ciphertext.translate({**trans_lower, **trans_upper})

    def vigenere_decipher(self, ciphertext):
        raw_key = [k.lower() for k in self.key if k.isalpha()]
        if not raw_key:
            return ciphertext
        shifts = [ord(k) - ord('a') for k in raw_key]
        out = []
        si = 0
        for ch in ciphertext:
            if ch.isalpha():
                shift = shifts[si % len(shifts)]
                si += 1
                if ch.islower():
                    base = ord('a')
                else:
                    base = ord('A')
                val = (ord(ch) - base - shift) % 26
                out.append(chr(base + val))
            else:
                out.append(ch)
        return ''.join(out)

    def rail_fence_decipher(self, encrypted_text, rails):
        if rails is None or rails <= 1:
            return encrypted_text
        length = len(encrypted_text)
        cycle_len = 2 * (rails - 1)
        rail_indices = [i % cycle_len for i in range(length)]
        rail_indices = [ri if ri < rails else cycle_len - ri for ri in rail_indices]
        counts = [0] * rails
        for ri in rail_indices:
            counts[ri] += 1
        parts = []
        idx = 0
        for c in counts:
            parts.append(list(encrypted_text[idx:idx+c]))
            idx += c
        pointers = [0]*rails
        result = []
        for ri in rail_indices:
            result.append(parts[ri][pointers[ri]])
            pointers[ri] += 1
        return ''.join(result)