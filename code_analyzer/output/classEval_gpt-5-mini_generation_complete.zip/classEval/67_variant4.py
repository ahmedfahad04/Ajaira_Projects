class Order:
    def __init__(self):
        self.menu = []
        # list of dicts as in skeleton, but ensure uniqueness by dish name
        self.selected_dishes = []
        self.sales = {}

    def _find_menu_item(self, name):
        for item in self.menu:
            if item.get("dish") == name:
                return item
        return None

    def _find_selected(self, name):
        for item in self.selected_dishes:
            if item.get("dish") == name:
                return item
        return None

    def add_dish(self, dish):
        name = dish.get("dish")
        cnt = dish.get("count", 0)
        if not name or cnt <= 0:
            return False
        menu_item = self._find_menu_item(name)
        if not menu_item:
            return False
        if menu_item.get("count", 0) < cnt:
            return False
        menu_item["count"] = menu_item.get("count", 0) - cnt
        selected = self._find_selected(name)
        price = menu_item.get("price", dish.get("price"))
        if selected:
            selected["count"] = selected.get("count", 0) + cnt
        else:
            self.selected_dishes.append({"dish": name, "count": cnt, "price": price})
        return True

    def calculate_total(self):
        total = 0.0
        for s in self.selected_dishes:
            name = s.get("dish")
            total += s.get("price", 0.0) * s.get("count", 0) * self.sales.get(name, 1.0)
        return float(total)

    def checkout(self):
        if not self.selected_dishes:
            return False
        return self.calculate_total()

# Classification response:
# variable renaming; helper function extraction; guard clause; flattened conditional; in-place mutation; dictionary lookup; input validation; default value handling; frequency counting