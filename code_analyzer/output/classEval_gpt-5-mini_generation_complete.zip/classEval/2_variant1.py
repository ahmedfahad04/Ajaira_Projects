class ArgumentParser:
    """
    This is a class for parsing command line arguments to a dictionary.
    """

    def __init__(self):
        self.arguments = {}
        self.required = set()
        self.types = {}

    def parse_arguments(self, command_string):
        tokens = command_string.split()
        i = 0
        while i < len(tokens):
            tok = tokens[i]
            if tok.startswith('-'):
                name_part = tok.lstrip('-')
                # handle --arg=value
                if '=' in name_part:
                    name, val = name_part.split('=', 1)
                    conv = self._convert_type(name, val)
                    self.arguments[name] = conv
                    i += 1
                    continue
                # peek next token for a value (not starting with -)
                if i + 1 < len(tokens) and not tokens[i + 1].startswith('-'):
                    val = tokens[i + 1]
                    conv = self._convert_type(name_part, val)
                    self.arguments[name_part] = conv
                    i += 2
                    continue
                # flag without value
                self.arguments[name_part] = self._convert_type(name_part, True)
                i += 1
            else:
                # ignore non-option tokens (like 'python' and 'script.py')
                i += 1
        missing = set()
        for req in self.required:
            if req not in self.arguments:
                missing.add(req)
        if missing:
            return (False, missing)
        return (True, None)

    def get_argument(self, key):
        return self.arguments.get(key, None)

    def add_argument(self, arg, required=False, arg_type=str):
        if required:
            self.required.add(arg)
        # normalize arg_type
        if isinstance(arg_type, str):
            mapping = {'int': int, 'float': float, 'str': str, 'bool': bool}
            self.types[arg] = mapping.get(arg_type, str)
        elif callable(arg_type):
            self.types[arg] = arg_type
        else:
            self.types[arg] = str

    def _convert_type(self, arg, value):
        typ = self.types.get(arg)
        if typ is None:
            return value
        # if value is already a boolean True from flag
        if typ is bool:
            if isinstance(value, bool):
                return value
            v = str(value).lower()
            if v in ('1', 'true', 'yes', 'y', 't', 'on'):
                return True
            if v in ('0', 'false', 'no', 'n', 'f', 'off'):
                return False
            return True
        try:
            return typ(value)
        except Exception:
            # fallback for int/float conversions if passed booleans etc.
            try:
                if typ is int:
                    return int(float(value))
            except Exception:
                pass
            return value