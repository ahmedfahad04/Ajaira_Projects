from datetime import datetime, timedelta

class CalendarUtil:
    """
    Calendar that uses a sweep-line algorithm for computing availability and upcoming events.
    """

    def __init__(self):
        self.events = []

    def add_event(self, event):
        ev = event.copy()
        if 'start_time' not in ev or ev['start_time'] is None:
            ev['start_time'] = ev.get('date')
        if 'end_time' not in ev or ev['end_time'] is None:
            st = ev.get('start_time')
            ev['end_time'] = st + timedelta(hours=1) if isinstance(st, datetime) else st
        self.events.append(ev)

    def remove_event(self, event):
        for i, e in enumerate(self.events):
            match = True
            for k, v in event.items():
                if k not in e or e[k] != v:
                    match = False
                    break
            if match:
                self.events.pop(i)
                return

    def get_events(self, date):
        if isinstance(date, datetime):
            key = date.date()
        else:
            key = date
        res = []
        for e in self.events:
            ed = e.get('date')
            if isinstance(ed, datetime):
                if ed.date() == key:
                    res.append(e)
            elif ed == key:
                res.append(e)
        return res

    def is_available(self, start_time, end_time):
        # Sweep: collect all intervals that intersect the interval
        intervals = []
        for e in self.events:
            s = e.get('start_time') or e.get('date')
            en = e.get('end_time') or s
            if s is None or en is None:
                continue
            if en <= start_time or s >= end_time:
                continue
            intervals.append((s, en))
        # if any interval overlaps, not available
        return len(intervals) == 0

    def get_available_slots(self, date):
        day = date.date() if isinstance(date, datetime) else date
        start = datetime(day.year, day.month, day.day)
        end = start + timedelta(days=1)
        events = []
        for e in self.events:
            s = e.get('start_time') or e.get('date')
            en = e.get('end_time') or s
            if s is None or en is None:
                continue
            if en <= start or s >= end:
                continue
            events.append((max(s, start), min(en, end)))
        if not events:
            return [(start, end)]
        # sweep line: create points
        points = []
        for s, en in events:
            points.append((s, 1))
            points.append((en, -1))
        points.sort(key=lambda x: (x[0], -x[1]))
        free = []
        active = 0
        last = start
        for t, delta in points:
            if active == 0 and t > last:
                free.append((last, t))
            active += delta
            last = max(last, t)
        if last < end and active == 0:
            free.append((last, end))
        return free

    def get_upcoming_events(self, num_events):
        now = datetime.now()
        # collect and sort by start_time
        evs = []
        for e in self.events:
            s = e.get('start_time') or e.get('date')
            if s is None:
                continue
            evs.append((s, e))
        evs.sort(key=lambda x: x[0])
        upcoming = [e for s, e in evs if s >= now]
        return upcoming[:num_events]