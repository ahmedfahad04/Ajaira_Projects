import math
from typing import List

class CombinationCalculator:
    """
    This is a class that provides methods to calculate the number of combinations for a specific count, calculate all possible combinations, and generate combinations with a specified number of elements.
    """

    def __init__(self, datas: List[str]):
        """
        Initialize the calculator with a list of data.
        """
        self.datas = datas

    @staticmethod
    def count(n: int, m: int) -> int:
        """
        Calculate the number of combinations using math.comb.
        """
        if n < 0 or m < 0 or m > n:
            return 0
        return math.comb(n, m)

    @staticmethod
    def count_all(n: int) -> int:
        """
        Fast calculation using 2^n - 1, with overflow check.
        """
        if n < 0:
            return 0
        limit = 2**63 - 1
        total = (1 << n) - 1
        if total > limit:
            return float("inf")
        return total

    def select(self, m: int) -> List[List[str]]:
        """
        Generate combinations using an iterative next-combination algorithm on indices to guarantee lexicographic order.
        """
        n = len(self.datas)
        if m <= 0 or m > n:
            return []
        # initial indices
        indices = list(range(m))
        result: List[List[str]] = []
        while True:
            result.append([self.datas[i] for i in indices])
            # find position to increment
            for i in range(m - 1, -1, -1):
                if indices[i] != i + n - m:
                    break
            else:
                break
            indices[i] += 1
            for j in range(i + 1, m):
                indices[j] = indices[j - 1] + 1
        return result

    def select_all(self) -> List[List[str]]:
        """
        Generate all combinations by increasing size.
        """
        res: List[List[str]] = []
        n = len(self.datas)
        for k in range(1, n + 1):
            res.extend(self.select(k))
        return res

    def _select(self, dataIndex: int, resultList: List[str], resultIndex: int, result: List[List[str]]):
        """
        Standard recursive backtracking used by many implementations; matches the expected behavior.
        """
        n = len(self.datas)
        r = len(resultList)
        if resultIndex == r:
            result.append(resultList.copy())
            return
        max_start = n - (r - resultIndex)
        for i in range(dataIndex, max_start + 1):
            resultList[resultIndex] = self.datas[i]
            self._select(i + 1, resultList, resultIndex + 1, result)