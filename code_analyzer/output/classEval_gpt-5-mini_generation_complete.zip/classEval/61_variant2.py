import random
from collections import deque

class MusicPlayer:
    """
    This is a class as a music player that provides to play, stop, add songs, remove songs, set volume, shuffle, and switch to the next or previous song.
    """

    def __init__(self):
        """
        Initializes the music player with an empty playlist, no current song, and a default volume of 50.
        """
        self.playlist = deque()
        self.current_song = None
        self.volume = 50

    def add_song(self, song):
        """
        Adds a song to the playlist.
        """
        if song is None:
            return
        self.playlist.append(song)
        if self.current_song is None:
            # set current to the leftmost element
            self.current_song = self.playlist[0]

    def remove_song(self, song):
        """
        Removes a song from the playlist.
        """
        if not self.playlist:
            return False
        try:
            # remove first occurrence
            idx = list(self.playlist).index(song)
        except ValueError:
            return False
        # rotate so that item is at left, popleft, then rotate back
        self.playlist.rotate(-idx)
        removed = self.playlist.popleft()
        self.playlist.rotate(idx)
        # if removed was current, set current to new leftmost or None
        if self.current_song == removed:
            if self.playlist:
                self.current_song = self.playlist[0]
            else:
                self.current_song = None
        return True

    def play(self):
        """
        Plays the current song in the playlist.
        """
        if not self.playlist:
            self.current_song = None
            return False
        if self.current_song is None:
            self.current_song = self.playlist[0]
        return self.current_song

    def stop(self):
        """
        Stops the current song in the playlist.
        """
        if self.current_song is None:
            return False
        self.current_song = None
        return True

    def switch_song(self):
        """
        Switches to the next song in the playlist (circular).
        """
        if not self.playlist:
            return False
        # if no current set to first
        if self.current_song is None:
            self.current_song = self.playlist[0]
            # rotate so that current is leftmost
            while self.playlist[0] != self.current_song:
                self.playlist.rotate(-1)
            return True
        # rotate until current is at left then rotate -1 to move next to left
        while self.playlist[0] != self.current_song:
            self.playlist.rotate(-1)
        self.playlist.rotate(-1)
        self.current_song = self.playlist[0]
        return True

    def previous_song(self):
        """
        Switches to the previous song in the playlist (circular).
        """
        if not self.playlist:
            return False
        if self.current_song is None:
            self.current_song = self.playlist[0]
            return True
        while self.playlist[0] != self.current_song:
            self.playlist.rotate(-1)
        self.playlist.rotate(1)
        self.current_song = self.playlist[0]
        return True

    def set_volume(self, volume):
        """
        Sets the volume of the music player, if the volume is between 0 and 100 is valid.
        """
        try:
            vol = int(volume)
        except Exception:
            return False
        if 0 <= vol <= 100:
            self.volume = vol
            return True
        return False

    def shuffle(self):
        """
        Shuffles the playlist.
        """
        if not self.playlist:
            return False
        lst = list(self.playlist)
        random.shuffle(lst)
        # reorder deque and keep current song as leftmost if present
        self.playlist = deque(lst)
        if self.current_song in self.playlist:
            # rotate until current is leftmost
            while self.playlist[0] != self.current_song:
                self.playlist.rotate(-1)
        else:
            self.current_song = self.playlist[0]
        return True

# Classification response:
# import reorganization; deque conversion; guard clause; while loop; flattened conditional; circular traversal; try-except wrapper; type conversion; list conversion; state preservation; formatting only