import logging
import datetime
from functools import lru_cache

class AccessGatewayFilter:
    """
    This class is a filter used for accessing gateway filtering, primarily for authentication and access log recording.
    """

    def __init__(self):
        self.prefixes = ['/api', '/login']
        self.current_user = None
        logging.basicConfig(level=logging.INFO)

    def filter(self, request):
        if not isinstance(request, dict):
            return False
        path = request.get('path', '')
        method = request.get('method', 'GET')
        # allow login and non-api endpoints
        if path.startswith('/login'):
            return True
        if not path.startswith('/api'):
            # non-api endpoints allowed by default
            return True
        if method.upper() == 'OPTIONS':
            return True
        user = self.get_jwt_user(request)
        if not user:
            return False
        # optionally apply additional access checks here; accept if user present
        self.set_current_user_info_and_log(user)
        return True

    def is_start_with(self, request_uri):
        if not isinstance(request_uri, str):
            return False
        for p in self.prefixes:
            if request_uri.startswith(p):
                return True
        return False

    @lru_cache(maxsize=256)
    def _validate_token_format(self, token):
        # simple validation that token ends with date and has non-empty prefix
        if not isinstance(token, str):
            return None
        today = str(datetime.date.today())
        if not token.endswith(today):
            return None
        username = token[:-len(today)]
        if not username:
            return None
        return username

    def get_jwt_user(self, request):
        headers = request.get('headers') or {}
        auth = headers.get('Authorization') or {}
        if not isinstance(auth, dict):
            return None
        user = auth.get('user')
        jwt = auth.get('jwt')
        if user and not jwt:
            return user
        username = self._validate_token_format(jwt)
        if not username:
            return None
        # prefer explicit user header if consistent
        if isinstance(user, dict):
            name = user.get('name') or user.get('username')
            if name and name != username:
                return None
            return user
        return {'name': username}

    def set_current_user_info_and_log(self, user):
        self.current_user = user
        now = datetime.datetime.now().isoformat()
        name = user.get('name') if isinstance(user, dict) else str(user)
        logging.info("Access recorded: %s at %s", name, now)