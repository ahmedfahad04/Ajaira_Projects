class BoyerMooreSearch:
    """
    his is a class that implements the Boyer-Moore algorithm for string searching, which is used to find occurrences of a pattern within a given text.
    """

    def __init__(self, text, pattern):
        """
        Initializes the BoyerMooreSearch class with the given text and pattern.
        :param text: The text to be searched, str.
        :param pattern: The pattern to be searched for, str.
        """
        self.text, self.pattern = text, pattern
        self.textLen, self.patLen = len(text), len(pattern)
        # Precompute last occurrence (bad-character table)
        self._last = {}
        for i, ch in enumerate(pattern):
            self._last[ch] = i

    def match_in_pattern(self, char):
        """
        Finds the rightmost occurrence of a character in the pattern.
        :param char: The character to be searched for, str.
        :return: The index of the rightmost occurrence of the character in the pattern, int.
        >>> boyerMooreSearch = BoyerMooreSearch("ABAABA", "AB")
        >>> boyerMooreSearch.match_in_pattern("A")
        0

        """
        return self._last.get(char, -1)

    def mismatch_in_text(self, currentPos):
        """
        Determines the position of the first dismatch between the pattern and the text.
        :param currentPos: The current position in the text, int.
        :return: The position of the first dismatch between the pattern and the text, int,otherwise -1.
        >>> boyerMooreSearch = BoyerMooreSearch("ABAABA", "ABC")
        >>> boyerMooreSearch.mismatch_in_text(0)
        2

        """
        if self.patLen == 0:
            return -1
        # compare pattern to text aligned at currentPos from right to left
        for j in range(self.patLen - 1, -1, -1):
            ti = currentPos + j
            if ti >= self.textLen or self.text[ti] != self.pattern[j]:
                return j
        return -1

    def bad_character_heuristic(self):
        """
        Finds all occurrences of the pattern in the text.
        :return: A list of all positions of the pattern in the text, list.
        >>> boyerMooreSearch = BoyerMooreSearch("ABAABA", "AB")
        >>> boyerMooreSearch.bad_character_heuristic()
        [0, 3]

        """
        if self.patLen == 0:
            return list(range(self.textLen + 1))
        matches = []
        i = 0
        while i <= self.textLen - self.patLen:
            mismatch = self.mismatch_in_text(i)
            if mismatch == -1:
                matches.append(i)
                # shift by full length or at least 1
                last = self._last.get(self.text[i + self.patLen - 1], -1)
                shift = self.patLen - last
                if shift <= 0:
                    shift = 1
                i += shift
            else:
                bad_char = self.text[i + mismatch]
                last = self._last.get(bad_char, -1)
                shift = mismatch - last
                if shift <= 0:
                    shift = 1
                i += shift
        return matches