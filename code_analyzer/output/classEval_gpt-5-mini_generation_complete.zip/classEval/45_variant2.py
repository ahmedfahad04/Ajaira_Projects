from PIL import Image, ImageEnhance, ImageOps

class ImageProcessor:
    """
    This is a class to process image, including loading, saving, resizing, rotating, and adjusting the brightness of images.
    """

    def __init__(self):
        """
        Initialize self.image
        """
        self.image = None

    def load_image(self, image_path):
        """
        Use Image util in PIL to open a image
        """
        if not image_path:
            raise ValueError("image_path required")
        img = Image.open(image_path)
        # convert to RGB for consistent edits
        self.image = img.convert("RGB")
        img.close()
        return self.image

    def save_image(self, save_path):
        """
        Save image to a path if image has opened
        """
        if self.image is None:
            raise RuntimeError("No image loaded")
        # ensure directory issues will surface from PIL
        self.image.save(save_path)

    def resize_image(self, width, height):
        """
        Risize the image if image has opened.
        """
        if self.image is None:
            raise RuntimeError("No image loaded")
        if width <= 0 or height <= 0:
            raise ValueError("width and height must be > 0")
        # Use ImageOps.fit to preserve aspect ratio by cropping if needed to exactly match
        self.image = ImageOps.fit(self.image, (width, height), method=Image.LANCZOS)
        return self.image

    def rotate_image(self, degrees):
        """
        rotate image if image has opened
        """
        if self.image is None:
            raise RuntimeError("No image loaded")
        try:
            deg = float(degrees)
        except Exception:
            raise TypeError("degrees must be numeric")
        # Use transpose for multiples of 90 for lossless rotation, otherwise rotate
        deg_norm = deg % 360
        if deg_norm in (90.0, 180.0, 270.0):
            if deg_norm == 90.0:
                self.image = self.image.transpose(Image.ROTATE_90)
            elif deg_norm == 180.0:
                self.image = self.image.transpose(Image.ROTATE_180)
            else:
                self.image = self.image.transpose(Image.ROTATE_270)
        else:
            self.image = self.image.rotate(deg, resample=Image.BICUBIC, expand=True)
        return self.image

    def adjust_brightness(self, factor):
        """
        Adjust the brightness of image if image has opened.
        """
        if self.image is None:
            raise RuntimeError("No image loaded")
        try:
            f = float(factor)
        except Exception:
            raise TypeError("factor must be numeric")
        enhancer = ImageEnhance.Brightness(self.image)
        self.image = enhancer.enhance(f)
        return self.image