import xml.etree.ElementTree as ET
from xml.dom import minidom


class XMLProcessor:
    """
    XML handler that pretty-prints output via minidom and increments numeric text nodes.
    """

    def __init__(self, file_name):
        self.file_name = file_name
        self.root = None

    def read_xml(self):
        tree = ET.parse(self.file_name)
        self.root = tree.getroot()
        return self.root

    def _pretty_write_string(self, element):
        rough = ET.tostring(element, encoding="utf-8")
        parsed = minidom.parseString(rough)
        return parsed.toprettyxml(indent="  ", encoding="utf-8")

    def write_xml(self, file_name):
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return False
        try:
            pretty = self._pretty_write_string(self.root)
            with open(file_name, "wb") as f:
                f.write(pretty)
            return True
        except Exception:
            return False

    def process_xml_data(self, file_name):
        """
        Increment numeric text nodes by 1 and mark elements with attribute processed="yes".
        """
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return False
        for elem in self.root.iter():
            if elem.text:
                txt = elem.text.strip()
                try:
                    n = int(txt)
                    elem.text = str(n + 1)
                except Exception:
                    # not an integer, keep as is
                    pass
            elem.set("processed", "yes")
        return self.write_xml(file_name)

    def find_element(self, element_name):
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return []
        # support simple wildcard '*'
        if element_name == "*":
            return list(self.root.iter())
        return self.root.findall(".//" + element_name)