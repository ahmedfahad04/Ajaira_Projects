from datetime import datetime, timedelta

class CalendarUtil:
    """
    Calendar implementation that normalizes and stores events internally as tuples for efficiency.
    """

    def __init__(self):
        self.events = []  # keep original dicts for compatibility
        self._normalized = []  # list of tuples (start, end, dict)

    def _normalize(self, event):
        ev = event.copy()
        if 'start_time' not in ev or ev['start_time'] is None:
            ev['start_time'] = ev.get('date')
        if 'end_time' not in ev or ev['end_time'] is None:
            st = ev.get('start_time')
            ev['end_time'] = st + timedelta(hours=1) if isinstance(st, datetime) else st
        return ev

    def add_event(self, event):
        ev = self._normalize(event)
        self.events.append(ev)
        st = ev.get('start_time')
        en = ev.get('end_time')
        # insert into normalized keeping sorted by start
        i = 0
        while i < len(self._normalized) and self._normalized[i][0] <= st:
            i += 1
        self._normalized.insert(i, (st, en, ev))

    def remove_event(self, event):
        # remove from original list
        for i, e in enumerate(self.events):
            match = True
            for k, v in event.items():
                if k not in e or e[k] != v:
                    match = False
                    break
            if match:
                ev = self.events.pop(i)
                # remove from normalized
                for j, (s, en, d) in enumerate(list(self._normalized)):
                    if d is ev:
                        self._normalized.pop(j)
                        break
                return

    def get_events(self, date):
        target = date.date() if isinstance(date, datetime) else date
        res = []
        for s, en, d in self._normalized:
            dd = d.get('date')
            if isinstance(dd, datetime) and dd.date() == target:
                res.append(d)
            elif dd == target:
                res.append(d)
        return res

    def is_available(self, start_time, end_time):
        # binary-like scan on sorted normalized list
        for s, en, d in self._normalized:
            if en <= start_time:
                continue
            if s >= end_time:
                break
            # overlap
            return False
        return True

    def get_available_slots(self, date):
        day = date.date() if isinstance(date, datetime) else date
        day_start = datetime(day.year, day.month, day.day)
        day_end = day_start + timedelta(days=1)
        intervals = []
        for s, en, d in self._normalized:
            if en <= day_start:
                continue
            if s >= day_end:
                break
            intervals.append((max(s, day_start), min(en, day_end)))
        # merge
        merged = []
        for s, e in intervals:
            if not merged or s > merged[-1][1]:
                merged.append([s, e])
            else:
                if e > merged[-1][1]:
                    merged[-1][1] = e
        free = []
        cur = day_start
        for s, e in merged:
            if cur < s:
                free.append((cur, s))
            cur = max(cur, e)
        if cur < day_end:
            free.append((cur, day_end))
        return free

    def get_upcoming_events(self, num_events):
        now = datetime.now()
        result = []
        for s, en, d in self._normalized:
            if s >= now:
                result.append(d)
                if len(result) >= num_events:
                    break
        return result