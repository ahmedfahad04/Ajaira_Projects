from collections import OrderedDict

class Server:
    """
    This is a class as a server, which handles a white list, message sending and receiving, and information display.
    """

    def __init__(self):
        """
        Initialize the whitelist as an empty list, and initialize the sending and receiving information as an empty dictionary
        """
        self.white_list = []
        # keep an ordered lookup for deterministic behavior
        self._white_map = OrderedDict()
        self.send_struct = {}
        self.receive_struct = {}

    def add_white_list(self, addr):
        """
        Add an address to the whitelist and do nothing if it already exists
        """
        if addr in self._white_map:
            return False
        self._white_map[addr] = True
        self.white_list = list(self._white_map.keys())
        return self.white_list

    def del_white_list(self, addr):
        """
        Remove an address from the whitelist and do nothing if it does not exist
        """
        if addr not in self._white_map:
            return False
        del self._white_map[addr]
        self.white_list = list(self._white_map.keys())
        return self.white_list

    def recv(self, info):
        """
        Receive information containing address and content. If the address is on the whitelist, receive the content; otherwise, do not receive it
        """
        if not isinstance(info, dict):
            return False
        addr = info.get("addr")
        if addr in self._white_map:
            # store exactly as provided (copy)
            self.receive_struct = {"addr": addr, "content": info.get("content")}
            return self.receive_struct["content"]
        return False

    def send(self, info):
        """
        Send information containing address and content
        """
        if not isinstance(info, dict):
            return "Invalid info"
        if "addr" not in info or "content" not in info:
            return "Invalid info structure"
        # no restriction on sending address
        self.send_struct = {"addr": info["addr"], "content": info["content"]}
        # successful send: return None

    def show(self, type):
        """
        Returns struct of the specified type
        """
        if type == "send":
            return self.send_struct
        if type == "receive":
            return self.receive_struct
        return False