import re

class PersonRequest:
    """
    This class validates input personal information data and sets invalid fields to None based to specific rules.
    """

    def __init__(self, name: str, sex: str, phoneNumber: str):
        self.name = self._validate_name(name)
        self.sex = self._validate_sex(sex)
        self.phoneNumber = self._validate_phoneNumber(phoneNumber)

    def _validate_name(self, name: str) -> str:
        if not isinstance(name, str):
            try:
                name = "" if name is None else str(name)
            except Exception:
                return None
        name = name.strip()
        if name == "" or len(name) > 33:
            return None
        return name

    def _validate_sex(self, sex: str) -> str:
        if not isinstance(sex, str):
            try:
                sex = "" if sex is None else str(sex)
            except Exception:
                return None
        sex = sex.strip()
        if sex in ("Man", "Woman", "UGM"):
            return sex
        return None

    def _validate_phoneNumber(self, phoneNumber: str) -> str:
        if not isinstance(phoneNumber, str):
            try:
                phoneNumber = "" if phoneNumber is None else str(phoneNumber)
            except Exception:
                return None
        phoneNumber = phoneNumber.strip()
        if phoneNumber == "":
            return None
        if re.match(r"^\d{11}$", phoneNumber):
            return phoneNumber
        return None

# Classification response:
# input validation; type check; type conversion; try-except wrapper; empty input handling; default value handling; regex usage; membership test