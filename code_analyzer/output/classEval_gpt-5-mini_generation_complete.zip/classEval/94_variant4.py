class VendingMachine:
    """
    This is a class to simulate a vending machine, including adding products, inserting coins, purchasing products, viewing balance, replenishing product inventory, and displaying product information.
    """

    def __init__(self):
        """
        Initializes the vending machine's inventory and balance.
        """
        # store price and qty as tuple (price, qty) to show a different approach
        self.inventory = {}
        self.balance = 0.0

    def add_item(self, item_name, price, quantity):
        if quantity <= 0 or price < 0:
            return
        # store as tuple
        self.inventory[item_name] = (float(price), int(quantity))

    def insert_coin(self, amount):
        try:
            amt = float(amount)
        except Exception:
            return self.balance
        if amt <= 0:
            return self.balance
        self.balance = round(self.balance + amt, 2)
        return self.balance

    def purchase_item(self, item_name):
        if item_name not in self.inventory:
            return False
        price, qty = self.inventory[item_name]
        if qty <= 0:
            return False
        if self.balance < price:
            return False
        # update tuple
        qty -= 1
        self.inventory[item_name] = (price, qty)
        self.balance = round(self.balance - price, 2)
        return self.balance

    def restock_item(self, item_name, quantity):
        if item_name not in self.inventory:
            return False
        price, qty = self.inventory[item_name]
        if quantity > 0:
            qty += int(quantity)
        self.inventory[item_name] = (price, qty)
        return True

    def display_items(self):
        if not self.inventory:
            return False
        parts = []
        for name, (price, qty) in self.inventory.items():
            parts.append(f"{name} - ${price:.2f} [{qty}]")
        return "\n".join(parts)