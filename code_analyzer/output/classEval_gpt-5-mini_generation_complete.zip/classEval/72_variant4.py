import re

class RegexUtils:
    def match(self, pattern, text):
        # If pattern is a string, prefer fullmatch if pattern looks like a full pattern
        if isinstance(pattern, str):
            try:
                # try fullmatch first for stricter interpretation
                if re.fullmatch(pattern, text):
                    return True
                return re.search(pattern, text) is not None
            except re.error:
                return False
        else:
            return pattern.fullmatch(text) is not None or pattern.search(text) is not None

    def findall(self, pattern, text):
        if isinstance(pattern, str):
            return re.findall(pattern, text)
        return pattern.findall(text)

    def split(self, pattern, text):
        if isinstance(pattern, str):
            return re.split(pattern, text)
        return pattern.split(text)

    def sub(self, pattern, replacement, text):
        if isinstance(pattern, str):
            return re.sub(pattern, replacement, text)
        return pattern.sub(replacement, text)

    def generate_email_pattern(self):
        # Return the pattern as commonly used
        return r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'

    def generate_phone_number_pattern(self):
        return r'\b\d{3}-\d{3}-\d{4}\b'

    def generate_split_sentences_pattern(self):
        return r'[.!?][\s]{1,2}(?=[A-Z])'

    def split_sentences(self, text):
        # Use lookaround split to keep punctuation with sentence
        pattern = re.compile(r'(?<=[.!?])\s+(?=[A-Z])')
        parts = [p.strip() for p in pattern.split(text)]
        # Ensure punctuation removed for all but the last
        for i in range(len(parts) - 1):
            parts[i] = re.sub(r'[.!?]+$', '', parts[i]).strip()
        return parts

    def validate_phone_number(self, phone_number):
        pat = self.generate_phone_number_pattern()
        try:
            return bool(re.fullmatch(pat, phone_number))
        except re.error:
            return False

    def extract_email(self, text):
        pat = self.generate_email_pattern()
        try:
            # Use IGNORECASE to be forgiving on TLD case
            found = re.findall(pat, text, flags=re.IGNORECASE)
            # return unique preserving order
            seen = set()
            out = []
            for e in found:
                if e not in seen:
                    seen.add(e)
                    out.append(e)
            return out
        except re.error:
            return []

# Classification response:
# type check; try-except wrapper; guard clause; combined condition; list comprehension; index-based loop; in-place mutation; accumulator set; accumulator list; regex usage; error suppression