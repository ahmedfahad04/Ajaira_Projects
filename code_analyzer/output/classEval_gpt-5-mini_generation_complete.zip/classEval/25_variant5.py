import json
from pathlib import Path

class CookiesUtil:
    """
    This is a class as utility for managing and manipulating Cookies, including methods for retrieving, saving, and setting Cookies data.
    """

    def __init__(self, cookies_file):
        self.cookies_file = Path(cookies_file)
        self.cookies = {}

    def get_cookies(self, reponse):
        if not isinstance(reponse, dict):
            raise TypeError("reponse must be a dict")
        cookies = reponse.get('cookies', {})
        if cookies is None:
            cookies = {}
        if not isinstance(cookies, dict):
            raise TypeError("response['cookies'] must be a dict")
        # set cookies directly and persist
        self.cookies = dict(cookies)
        self._save_cookies()
        return self.cookies

    def load_cookies(self):
        if not self.cookies_file.exists():
            self.cookies = {}
            return self.cookies
        try:
            text = self.cookies_file.read_text(encoding='utf-8')
            data = json.loads(text)
            if isinstance(data, dict):
                self.cookies = data
            else:
                self.cookies = {}
        except Exception:
            self.cookies = {}
        return self.cookies

    def _save_cookies(self):
        try:
            self.cookies_file.parent.mkdir(parents=True, exist_ok=True)
            self.cookies_file.write_text(json.dumps(self.cookies, ensure_ascii=False, indent=2, sort_keys=True), encoding='utf-8')
            return True
        except Exception:
            return False