import sqlite3
import hashlib
import secrets

class UserLoginDB:
    """
    This is a database management class for user login verification, providing functions for inserting user information, searching user information, deleting user information, and validating user login.
    """

    def __init__(self, db_name):
        """
        Initializes the UserLoginDB object with the specified database name.
        """
        self.connection = sqlite3.connect(db_name)
        self.cursor = self.connection.cursor()

    def create_table(self):
        self.cursor.execute(
            "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password_hash TEXT, salt TEXT)"
        )
        self.connection.commit()

    def _hash_password(self, password, salt):
        return hashlib.sha256((salt + password).encode('utf-8')).hexdigest()

    def insert_user(self, username, password):
        """
        Inserts a new user storing a sha256(salt+password).
        """
        salt = secrets.token_hex(16)
        password_hash = self._hash_password(password, salt)
        self.cursor.execute(
            "INSERT OR IGNORE INTO users (username, password_hash, salt) VALUES (?, ?, ?)",
            (username, password_hash, salt),
        )
        self.connection.commit()

    def search_user_by_username(self, username):
        """
        Returns rows matching username.
        """
        self.cursor.execute(
            "SELECT id, username, password_hash, salt FROM users WHERE username = ?",
            (username,),
        )
        return self.cursor.fetchall()

    def delete_user_by_username(self, username):
        self.cursor.execute("DELETE FROM users WHERE username = ?", (username,))
        self.connection.commit()

    def validate_user_login(self, username, password):
        """
        Recomputes hash with stored salt and compares.
        """
        self.cursor.execute(
            "SELECT password_hash, salt FROM users WHERE username = ?", (username,)
        )
        row = self.cursor.fetchone()
        if not row:
            return False
        stored_hash, salt = row
        return stored_hash == self._hash_password(password, salt)