class BoyerMooreSearch:
    """
    his is a class that implements the Boyer-Moore algorithm for string searching, which is used to find occurrences of a pattern within a given text.
    """

    def __init__(self, text, pattern):
        """
        Initializes the BoyerMooreSearch class with the given text and pattern.
        :param text: The text to be searched, str.
        :param pattern: The pattern to be searched for, str.
        """
        self.text, self.pattern = text, pattern
        self.textLen, self.patLen = len(text), len(pattern)
        # Precompute last occurrence table by scanning pattern
        self._last = {}
        for i, ch in enumerate(pattern):
            self._last[ch] = i

    def match_in_pattern(self, char):
        """
        Finds the rightmost occurrence of a character in the pattern.
        """
        return self._last.get(char, -1)

    def mismatch_in_text(self, currentPos):
        """
        Determines the position of the first dismatch between the pattern and the text.
        """
        if self.patLen == 0:
            return -1
        # Walk backwards through the pattern
        for p_idx in range(self.patLen - 1, -1, -1):
            t_idx = currentPos + p_idx
            if t_idx >= self.textLen or self.pattern[p_idx] != self.text[t_idx]:
                return p_idx
        return -1

    def bad_character_heuristic(self):
        """
        Finds all occurrences of the pattern in the text.
        """
        if self.patLen == 0:
            return list(range(self.textLen + 1))
        matches = []
        pos = 0
        while pos <= self.textLen - self.patLen:
            mismatch_pos = self.mismatch_in_text(pos)
            if mismatch_pos == -1:
                matches.append(pos)
                last_char = self.text[pos + self.patLen - 1]
                last_idx = self._last.get(last_char, -1)
                shift = self.patLen - last_idx
                if shift <= 0:
                    shift = 1
                pos += shift
            else:
                bad_char = self.text[pos + mismatch_pos]
                last_idx = self._last.get(bad_char, -1)
                shift = mismatch_pos - last_idx
                if shift <= 0:
                    shift = 1
                pos += shift
        return matches