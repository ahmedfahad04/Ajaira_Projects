from copy import deepcopy
from dataclasses import dataclass, asdict

@dataclass
class _Job:
    job_title: str
    company: str
    requirements: list

@dataclass
class _Resume:
    name: str
    skills: list
    experience: str

class JobMarketplace:
    """
    This is a class that provides functionalities to publish positions, remove positions, submit resumes, withdraw resumes, search for positions, and obtain candidate information.
    """

    def __init__(self):
        self.job_listings = []
        self.resumes = []

    def post_job(self, job_title, company, requirements):
        """
        This function is used to publish positions,and add the position information to the job_listings list.
        """
        job_obj = _Job(job_title=job_title, company=company, requirements=list(requirements) if requirements is not None else [])
        job_dict = asdict(job_obj)
        self.job_listings.append(job_dict)

    def remove_job(self, job):
        """
        This function is used to remove positions,and remove the position information from the job_listings list.
        """
        # Remove first matching job by deep equality
        for i, j in enumerate(self.job_listings):
            if j == job:
                del self.job_listings[i]
                return
        # fallback: match on fields
        jt = job.get('job_title')
        co = job.get('company')
        req = job.get('requirements')
        for i, j in enumerate(self.job_listings):
            if j.get('job_title') == jt and j.get('company') == co and j.get('requirements') == req:
                del self.job_listings[i]
                return

    def submit_resume(self, name, skills, experience):
        """
        This function is used to submit resumes,and add the resume information to the resumes list.
        """
        res_obj = _Resume(name=name, skills=list(skills) if skills is not None else [], experience=experience)
        self.resumes.append(asdict(res_obj))

    def withdraw_resume(self, resume):
        """
        This function is used to withdraw resumes,and remove the resume information from the resumes list.
        """
        for i, r in enumerate(self.resumes):
            if r == resume:
                del self.resumes[i]
                return
        # fallback by fields
        nm = resume.get('name')
        sk = resume.get('skills')
        ex = resume.get('experience')
        for i, r in enumerate(self.resumes):
            if r.get('name') == nm and r.get('skills') == sk and r.get('experience') == ex:
                del self.resumes[i]
                return

    def search_jobs(self, criteria):
        """
        This function is used to search for positions,and return the position information that meets the requirements.
        """
        if criteria is None:
            return []
        crit = str(criteria).lower()
        out = []
        for j in self.job_listings:
            if crit in (j.get('job_title') or '').lower() or crit in (j.get('company') or '').lower():
                out.append(deepcopy(j))
                continue
            for req in j.get('requirements', []):
                if crit == str(req).lower():
                    out.append(deepcopy(j))
                    break
        return out

    def get_job_applicants(self, job):
        """
        This function is used to obtain candidate information,and return the candidate information that meets the requirements by calling the matches_requirements function.
        """
        def matches_requirements(job_info, resume):
            job_reqs = [str(x).lower() for x in (job_info.get('requirements') or [])]
            skills = [str(x).lower() for x in (resume.get('skills') or [])]
            return all(r in skills for r in job_reqs)

        return [deepcopy(r) for r in self.resumes if matches_requirements(job, r)]