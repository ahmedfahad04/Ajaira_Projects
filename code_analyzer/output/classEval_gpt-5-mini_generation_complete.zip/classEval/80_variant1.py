class SQLQueryBuilder:
    """
    This class provides to build SQL queries, including SELECT, INSERT, UPDATE, and DELETE statements. 
    """

    @staticmethod
    def _escape(val):
        if val is None:
            return "NULL"
        s = str(val)
        s = s.replace("'", "''")
        return f"'{s}'"

    @staticmethod
    def select(table, columns='*', where=None):
        if isinstance(columns, (list, tuple)):
            cols = ", ".join(columns) if columns else "*"
        else:
            cols = columns or "*"
        q = f"SELECT {cols} FROM {table}"
        if where:
            parts = []
            for k, v in where.items():
                parts.append(f"{k}={SQLQueryBuilder._escape(v)}")
            q += " WHERE " + " AND ".join(parts)
        return q

    @staticmethod
    def insert(table, data):
        if not data:
            columns = ""
            values = ""
        else:
            cols = list(data.keys())
            vals = [SQLQueryBuilder._escape(v) for v in data.values()]
            columns = ", ".join(cols)
            values = ", ".join(vals)
        return f"INSERT INTO {table} ({columns}) VALUES ({values})"

    @staticmethod
    def delete(table, where=None):
        q = f"DELETE FROM {table}"
        if where:
            parts = [f"{k}={SQLQueryBuilder._escape(v)}" for k, v in where.items()]
            q += " WHERE " + " AND ".join(parts)
        return q

    @staticmethod
    def update(table, data, where=None):
        set_parts = [f"{k}={SQLQueryBuilder._escape(v)}" for k, v in data.items()]
        q = f"UPDATE {table} SET " + ", ".join(set_parts)
        if where:
            where_parts = [f"{k}={SQLQueryBuilder._escape(v)}" for k, v in where.items()]
            q += " WHERE " + " AND ".join(where_parts)
        return q