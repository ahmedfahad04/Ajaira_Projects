import numpy as np

class KappaCalculator:
    """
    This is a class as KappaCalculator, supporting to calculate Cohen's and Fleiss' kappa coefficient.
    """

    @staticmethod
    def kappa(testData, k):
        # convert to numpy and ensure float
        A = np.array(testData, dtype=float)
        if A.size == 0:
            return 0.0
        if A.shape != (k, k):
            try:
                A = A.reshape((k, k))
            except Exception:
                raise ValueError("testData must be k x k")
        total = float(A.sum())
        if total == 0.0:
            return 0.0
        # observed agreement
        observed = np.diag(A).sum() / total
        # expected agreement
        row = A.sum(axis=1) / total
        col = A.sum(axis=0) / total
        expected = (row * col).sum()
        denom = 1.0 - expected
        if abs(denom) < 1e-12:
            return 1.0 if abs(observed - expected) < 1e-12 else 0.0
        return (observed - expected) / denom

    @staticmethod
    def fleiss_kappa(testData, N, k, n):
        M = np.array(testData, dtype=float)
        if M.size == 0:
            return 0.0
        if M.shape != (N, k):
            try:
                M = M.reshape((N, k))
            except Exception:
                raise ValueError("testData must be N x k")
        # proportions per category
        totals_per_cat = M.sum(axis=0)
        p = totals_per_cat / (N * n)
        Pe = np.dot(p, p)
        # agreement per subject
        sum_sq = np.sum(M * M, axis=1)
        Pj = (sum_sq - n) / (n * (n - 1)) if n > 1 else np.zeros(N)
        Pbar = float(Pj.mean())
        denom = 1.0 - Pe
        if abs(denom) < 1e-12:
            return 1.0 if abs(Pbar - Pe) < 1e-12 else 0.0
        return (Pbar - Pe) / denom