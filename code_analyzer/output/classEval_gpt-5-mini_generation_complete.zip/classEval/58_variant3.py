import random
from collections import deque

class MinesweeperGame:
    """
    This is a class that implements mine sweeping games including minesweeping and winning judgment.
    """

    def __init__(self, n, k) -> None:
        self.n = n
        self.k = k
        self.minesweeper_map = self.generate_mine_sweeper_map()
        self.player_map = self.generate_playerMap()
        self.score = 0

    def generate_mine_sweeper_map(self):
        n, k = self.n, self.k
        # shuffle linear indices
        indices = list(range(n * n))
        random.shuffle(indices)
        mine_set = set(indices[:min(k, n * n)])
        grid = [[0 for _ in range(n)] for _ in range(n)]
        for idx in mine_set:
            i, j = divmod(idx, n)
            grid[i][j] = 'X'
        # compute neighbor counts
        dirs = [(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]
        for idx in mine_set:
            i, j = divmod(idx, n)
            for di, dj in dirs:
                ni, nj = i + di, j + dj
                if 0 <= ni < n and 0 <= nj < n and grid[ni][nj] != 'X':
                    grid[ni][nj] += 1
        return grid

    def generate_playerMap(self):
        return [['-' for _ in range(self.n)] for _ in range(self.n)]

    def check_won(self, map):
        # All '-' must correspond to mines
        for i in range(self.n):
            for j in range(self.n):
                if map[i][j] == '-' and self.minesweeper_map[i][j] != 'X':
                    return False
        return True

    def sweep(self, x, y):
        if not (0 <= x < self.n and 0 <= y < self.n):
            return self.player_map
        if self.player_map[x][y] != '-':
            return self.player_map
        if self.minesweeper_map[x][y] == 'X':
            self.player_map[x][y] = 'X'
            return False
        # iterative DFS stack
        stack = [(x, y)]
        newly = 0
        while stack:
            i, j = stack.pop()
            if not (0 <= i < self.n and 0 <= j < self.n):
                continue
            if self.player_map[i][j] != '-':
                continue
            self.player_map[i][j] = self.minesweeper_map[i][j]
            newly += 1
            if self.minesweeper_map[i][j] == 0:
                for di in (-1, 0, 1):
                    for dj in (-1, 0, 1):
                        ni, nj = i + di, j + dj
                        if 0 <= ni < self.n and 0 <= nj < self.n and self.player_map[ni][nj] == '-':
                            stack.append((ni, nj))
        self.score += newly
        if self.check_won(self.player_map):
            return True
        return self.player_map

# Classification response:
# variable renaming;set conversion;tuple unpacking;loop rewrite;stack-based;early return;guard clause;input validation;boundary case handling;behavior change;import reorganization