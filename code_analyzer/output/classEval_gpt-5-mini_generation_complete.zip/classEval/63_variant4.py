import re
from collections import Counter

class NLPDataProcessor2:
    """
    The class processes NLP data by extracting words from a list of strings, calculating the frequency of each word, and returning the top 5 most frequent words.
    """

    def process_data(self, string_list):
        out = []
        for s in string_list:
            cleaned = ''.join(ch if (ch.isalpha() or ch.isspace()) else ' ' for ch in s)
            parts = [w for w in cleaned.lower().split() if w]
            out.append(parts)
        return out

    def calculate_word_frequency(self, words_list):
        c = Counter()
        order = []
        for sub in words_list:
            for w in sub:
                if w not in c:
                    order.append(w)
                c[w] += 1
        if not c:
            return {}
        items = sorted(c.items(), key=lambda kv: (-kv[1], order.index(kv[0])))
        return dict(items[:5])

    def process(self, string_list):
        wl = self.process_data(string_list)
        return self.calculate_word_frequency(wl)

# Classification response:
# variable renaming; loop rewrite; accumulator list; list comprehension; generator expression; sort key; frequency counting; early return; empty input handling; builtin function; order-preserving tie-break