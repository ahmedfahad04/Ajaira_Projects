import numpy as np
from gensim import matutils
from numpy import dot, array

class VectorUtil:
    """
    The class provides vector operations, including calculating similarity, cosine similarities, average similarity, and IDF weights.
    """

    @staticmethod
    def similarity(vector_1, vector_2):
        a = np.array(vector_1, dtype=float)
        b = np.array(vector_2, dtype=float)
        # fallback to zero if either is degenerate
        na = np.linalg.norm(a)
        nb = np.linalg.norm(b)
        if na == 0 or nb == 0:
            return 0.0
        return float(np.dot(a, b) / (na * nb))

    @staticmethod
    def cosine_similarities(vector_1, vectors_all):
        a = np.array(vector_1, dtype=float)
        na = np.linalg.norm(a)
        if na == 0:
            return np.array([0.0] * len(vectors_all), dtype=float)
        # try to be memory efficient when list already arrays
        res = []
        for v in vectors_all:
            v_arr = np.array(v, dtype=float)
            nv = np.linalg.norm(v_arr)
            if nv == 0:
                res.append(0.0)
            else:
                res.append(float(np.dot(a, v_arr) / (na * nv)))
        return np.array(res, dtype=float)

    @staticmethod
    def n_similarity(vector_list_1, vector_list_2):
        if not vector_list_1 or not vector_list_2:
            return 0.0
        mean1 = np.mean([np.array(v, dtype=float) for v in vector_list_1], axis=0)
        mean2 = np.mean([np.array(v, dtype=float) for v in vector_list_2], axis=0)
        return VectorUtil.similarity(mean1, mean2)

    @staticmethod
    def compute_idf_weight_dict(total_num, number_dict):
        T = float(total_num)
        out = {}
        for k, v in number_dict.items():
            out[k] = float(np.log((T + 1.0) / (float(v) + 1.0)))
        return out