import numpy as np
import math

class DataStatistics2:
    """
    This is a class for performing data statistics, supporting to get the sum, minimum, maximum, variance, standard deviation, and correlation of a given dataset.
    """

    def __init__(self, data):
        """
        Initialize Data List
        :param data:list
        """
        self.data = np.array(data, dtype=float).flatten()

    def _check_nonempty(self):
        if self.data.size == 0:
            raise ValueError("data must contain at least one element")

    def get_sum(self):
        self._check_nonempty()
        s = float(np.sum(self.data))
        # return int if it is integer-like
        if s.is_integer():
            return int(s)
        return s

    def get_min(self):
        self._check_nonempty()
        m = np.min(self.data)
        if float(m).is_integer():
            return int(m)
        return float(m)

    def get_max(self):
        self._check_nonempty()
        M = np.max(self.data)
        if float(M).is_integer():
            return int(M)
        return float(M)

    def get_variance(self):
        self._check_nonempty()
        # population variance (ddof=0)
        var = float(np.var(self.data, ddof=0))
        return round(var, 2)

    def get_std_deviation(self):
        self._check_nonempty()
        std = float(np.std(self.data, ddof=0))
        return round(std, 2)

    def get_correlation(self):
        self._check_nonempty()
        n = self.data.size
        if n == 1:
            return 0.0
        # correlate data with index sequence 1..n
        x = np.arange(1, n + 1, dtype=float)
        y = self.data
        # if either is constant, correlation undefined -> return 0.0
        if np.isclose(np.std(x), 0.0) or np.isclose(np.std(y), 0.0):
            return 0.0
        corr = np.corrcoef(x, y)[0, 1]
        return float(corr)