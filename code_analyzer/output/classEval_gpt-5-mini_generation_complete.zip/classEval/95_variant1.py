class Warehouse:
    """
    The class manages inventory and orders, including adding products, updating product quantities, retrieving product quantities, creating orders, changing order statuses, and tracking orders.
    """

    def __init__(self):
        """
        Initialize two fields.
        self.inventory is a dict that stores the products.
        self.inventory = {Product ID: Product}
        self.orders is a dict that stores the products in a order.
        self.orders = {Order ID: Order}
        """
        self.inventory = {}  # Product ID: Product
        self.orders = {}  # Order ID: Order

    def add_product(self, product_id, name, quantity):
        """
        Add product to inventory and plus the quantity if it has existed in inventory.
        Or just add new product to dict otherwise.
        """
        if product_id in self.inventory:
            # keep existing name, just increase quantity
            self.inventory[product_id]['quantity'] += quantity
        else:
            self.inventory[product_id] = {'name': name, 'quantity': quantity}
        return True

    def update_product_quantity(self, product_id, quantity):
        """
        According to product_id, add the quantity to the corresponding product in inventory.
        """
        if product_id not in self.inventory:
            return False
        self.inventory[product_id]['quantity'] += quantity
        return True

    def get_product_quantity(self, product_id):
        """
        Get the quantity of specific product by product_id.
        """
        if product_id not in self.inventory:
            return False
        return self.inventory[product_id]['quantity']

    def create_order(self, order_id, product_id, quantity):
        """
        Create a order which includes the infomation of product, like id and quantity.
        And put the new order into self.orders.
        The default value of status is 'Shipped'.
        """
        if product_id not in self.inventory:
            return False
        available = self.inventory[product_id]['quantity']
        if available < quantity:
            return False
        # Deduct inventory and create order
        self.inventory[product_id]['quantity'] -= quantity
        self.orders[order_id] = {'product_id': product_id, 'quantity': quantity, 'status': 'Shipped'}
        return True

    def change_order_status(self, order_id, status):
        """
        Change the status of order if the input order_id is in self.orders.
        """
        if order_id not in self.orders:
            return False
        self.orders[order_id]['status'] = status
        return True

    def track_order(self, order_id):
        """
        Get the status of specific order.
        """
        if order_id not in self.orders:
            return False
        return self.orders[order_id]['status']