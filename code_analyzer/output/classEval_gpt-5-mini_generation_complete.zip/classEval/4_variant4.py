class AssessmentSystem:
    """
    This is a class as an student assessment system, which supports add student, add course score, calculate GPA, and other functions for students and courses.
    """

    def __init__(self):
        """
        Initialize the students dict in assessment system.
        """
        self.students = {}

    def add_student(self, name, grade, major):
        if name in self.students:
            self.students[name].update({'grade': grade, 'major': major})
        else:
            self.students[name] = {'name': name, 'grade': grade, 'major': major, 'courses': {}}

    def add_course_score(self, name, course, score):
        if name not in self.students:
            self.students[name] = {'name': name, 'grade': None, 'major': None, 'courses': {}}
        self.students[name]['courses'][course] = score

    def get_gpa(self, name):
        info = self.students.get(name)
        if not info:
            return None
        courses = info.get('courses', {})
        if not courses:
            return None
        total, count = 0, 0
        for s in courses.values():
            total += s
            count += 1
        return total / count if count else None

    def get_all_students_with_fail_course(self):
        out = []
        for name, info in self.students.items():
            courses = info.get('courses', {})
            for s in courses.values():
                if s < 60:
                    out.append(name)
                    break
        return out

    def get_course_average(self, course):
        total = 0
        count = 0
        for info in self.students.values():
            courses = info.get('courses', {})
            if course in courses:
                total += courses[course]
                count += 1
        return (total / count) if count else None

    def get_top_student(self):
        best = None
        best_gpa = -1
        for name in self.students:
            gpa = self.get_gpa(name)
            if gpa is None:
                continue
            if best is None or gpa > best_gpa or (gpa == best_gpa and name < best):
                best = name
                best_gpa = gpa
        return best