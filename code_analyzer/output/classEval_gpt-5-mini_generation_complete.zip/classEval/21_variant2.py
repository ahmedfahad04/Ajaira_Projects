from datetime import datetime
import bisect

class Classroom:
    def __init__(self, id):
        self.id = id
        # store tuples (start_min, end_min, name, original_dict)
        self.schedule = []
        self.courses = []

    def _to_minutes(self, t):
        dt = datetime.strptime(t.strip(), '%H:%M')
        return dt.hour * 60 + dt.minute

    def add_course(self, course):
        if course in self.courses:
            return
        start = self._to_minutes(course['start_time'])
        end = self._to_minutes(course['end_time'])
        entry = (start, end, course.get('name'), course)
        # insert maintaining order by start
        idx = bisect.bisect_left(self.schedule, entry)
        self.schedule.insert(idx, entry)
        self.courses.append(course)

    def remove_course(self, course):
        if course not in self.courses:
            return
        self.courses.remove(course)
        start = self._to_minutes(course['start_time'])
        end = self._to_minutes(course['end_time'])
        name = course.get('name')
        for i, (s, e, n, orig) in enumerate(self.schedule):
            if s == start and e == end and n == name:
                del self.schedule[i]
                break

    def is_free_at(self, check_time):
        m = self._to_minutes(check_time)
        # binary search candidate by start times
        lo, hi = 0, len(self.schedule)
        while lo < hi:
            mid = (lo + hi) // 2
            if self.schedule[mid][0] <= m:
                lo = mid + 1
            else:
                hi = mid
        # check previous entry
        if lo > 0:
            s, e, _, _ = self.schedule[lo - 1]
            if s <= m <= e:
                return False
        # also check current entry (edge case where start == m)
        if lo < len(self.schedule):
            s, e, _, _ = self.schedule[lo]
            if s <= m <= e:
                return False
        return True

    def check_course_conflict(self, new_course):
        ns = self._to_minutes(new_course['start_time'])
        ne = self._to_minutes(new_course['end_time'])
        # since schedule sorted by start, check nearby possible overlaps
        import bisect
        starts = [s for s, e, n, o in self.schedule]
        idx = bisect.bisect_left(starts, ns)
        candidates = []
        if idx > 0:
            candidates.append(self.schedule[idx - 1])
        if idx < len(self.schedule):
            candidates.append(self.schedule[idx])
        if idx + 1 < len(self.schedule):
            candidates.append(self.schedule[idx + 1])
        for s, e, _, _ in candidates:
            if not (ne < s or ns > e):
                return False
        return True