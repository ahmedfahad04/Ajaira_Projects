import json
import os
import tempfile

class JSONProcessor:
    """
    This is a class to process JSON file, including reading and writing JSON files, as well as processing JSON data by removing a specified key from the JSON object.
    """

    def read_json(self, file_path):
        if not isinstance(file_path, str):
            return -1
        if not os.path.isfile(file_path):
            return 0
        try:
            with open(file_path, 'r', encoding='utf-8') as fh:
                return json.load(fh)
        except Exception:
            return -1

    def write_json(self, data, file_path):
        if not isinstance(file_path, str):
            return -1
        try:
            directory = os.path.dirname(file_path)
            if directory and not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)
            # atomic write using temporary file and replace
            dir_for_temp = directory or '.'
            fd, tmpname = tempfile.mkstemp(dir=dir_for_temp)
            try:
                with os.fdopen(fd, 'w', encoding='utf-8') as tmpf:
                    json.dump(data, tmpf, ensure_ascii=False, indent=2)
                os.replace(tmpname, file_path)
            finally:
                if os.path.exists(tmpname):
                    try:
                        os.remove(tmpname)
                    except Exception:
                        pass
            return 1
        except Exception:
            return -1

    def process_json(self, file_path, remove_key):
        if not isinstance(file_path, str):
            return -1
        data = self.read_json(file_path)
        if data == 0:
            return 0
        if data == -1:
            return -1
        if not isinstance(data, dict):
            return 0
        if remove_key not in data:
            return 0
        data.pop(remove_key, None)
        wr = self.write_json(data, file_path)
        return 1 if wr == 1 else -1