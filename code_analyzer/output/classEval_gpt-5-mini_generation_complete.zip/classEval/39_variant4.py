import re
from collections import deque

class Node:
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

class ExpressionCalculator:
    """
    This is a class in Python that can perform calculations with basic arithmetic operations, including addition, subtraction, multiplication, division, and modulo.
    """

    def __init__(self):
        """
        Initialize the expression calculator
        """
        self.postfix_stack = deque()
        self.operat_priority = [0, 3, 2, 1, -1, 1, 0, 2]

    def calculate(self, expression):
        """
        Build AST from infix and evaluate recursively. Also populate postfix_stack.
        """
        expr = self.transform(expression)
        tokens = re.findall(r'\d+\.\d+|\d+|[()+\-*/%]', expr)
        # Convert to postfix via shunting-yard
        output = []
        ops = []
        prec = {'+':1,'-':1,'*':2,'/':2,'%':2}
        for i,t in enumerate(tokens):
            if re.match(r'^\d+(\.\d+)?$', t):
                output.append(t)
            elif t == '(':
                ops.append(t)
            elif t == ')':
                while ops and ops[-1] != '(':
                    output.append(ops.pop())
                if ops: ops.pop()
            else:
                if t == '-' and (i==0 or tokens[i-1] in {'(', '+','-','*','/','%'}):
                    output.append('0')
                while ops and ops[-1] != '(' and prec.get(ops[-1],0) >= prec.get(t,0):
                    output.append(ops.pop())
                ops.append(t)
        while ops:
            output.append(ops.pop())
        self.postfix_stack = deque(output)
        # Build tree from postfix
        stack = []
        for tok in output:
            if tok in prec:
                r = stack.pop()
                l = stack.pop()
                stack.append(Node(tok, l, r))
            else:
                stack.append(Node(tok))
        if not stack:
            return 0.0
        root = stack[-1]
        return float(self._eval_node(root))

    def _eval_node(self, node):
        if node.left is None and node.right is None:
            return float(node.value)
        a = self._eval_node(node.left)
        b = self._eval_node(node.right)
        op = node.value
        if op == '+':
            return a + b
        if op == '-':
            return a - b
        if op == '*':
            return a * b
        if op == '/':
            if b == 0:
                raise ZeroDivisionError("division by zero")
            return a / b
        if op == '%':
            if b == 0:
                raise ZeroDivisionError("modulo by zero")
            return a % b
        raise ValueError("Unknown operator")

    def prepare(self, expression):
        """
        Prepare simply converts infix to postfix and stores it.
        """
        expr = self.transform(expression)
        tokens = re.findall(r'\d+\.\d+|\d+|[()+\-*/%]', expr)
        output = []
        ops = []
        prec = {'+':1,'-':1,'*':2,'/':2,'%':2}
        for i,t in enumerate(tokens):
            if re.match(r'^\d+(\.\d+)?$', t):
                output.append(t)
            elif t == '(':
                ops.append(t)
            elif t == ')':
                while ops and ops[-1] != '(':
                    output.append(ops.pop())
                if ops: ops.pop()
            else:
                if t == '-' and (i==0 or tokens[i-1] in {'(','+','-','*','/','%'}):
                    output.append('0')
                while ops and ops[-1] != '(' and prec.get(ops[-1],0) >= prec.get(t,0):
                    output.append(ops.pop())
                ops.append(t)
        while ops:
            output.append(ops.pop())
        self.postfix_stack = deque(output)

    @staticmethod
    def is_operator(c):
        return c in {'+', '-', '*', '/', '(', ')', '%'}

    def compare(self, cur, peek):
        precedence = {'+':1,'-':1,'*':2,'/':2,'%':2}
        return precedence.get(cur,0) >= precedence.get(peek,0)

    @staticmethod
    def _calculate(first_value, second_value, current_op):
        a = float(first_value)
        b = float(second_value)
        if current_op == '+':
            return a + b
        if current_op == '-':
            return a - b
        if current_op == '*':
            return a * b
        if current_op == '/':
            if b == 0:
                raise ZeroDivisionError("division by zero")
            return a / b
        if current_op == '%':
            if b == 0:
                raise ZeroDivisionError("modulo by zero")
            return a % b
        raise ValueError("Unknown operator")

    @staticmethod
    def transform(expression):
        return ''.join(expression.split())