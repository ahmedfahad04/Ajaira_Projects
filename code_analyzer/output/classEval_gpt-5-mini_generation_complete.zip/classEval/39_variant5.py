import re
from collections import deque

class ExpressionCalculator:
    """
    This is a class in Python that can perform calculations with basic arithmetic operations, including addition, subtraction, multiplication, division, and modulo.
    """

    def __init__(self):
        """
        Initialize the expression calculator
        """
        self.postfix_stack = deque()
        # example priority array preserved
        self.operat_priority = [0, 3, 2, 1, -1, 1, 0, 2]

    def calculate(self, expression):
        """
        Tokenize, convert to postfix, and then evaluate using stack operations.
        """
        expr = self.transform(expression)
        self.prepare(expr)
        stack = []
        for token in self.postfix_stack:
            if self.is_operator(token) and token not in ('(', ')'):
                b = stack.pop()
                a = stack.pop()
                stack.append(self._calculate(a, b, token))
            else:
                stack.append(token if isinstance(token, float) else float(token))
        return float(stack[-1]) if stack else 0.0

    def prepare(self, expression):
        """
        Prepare token list and convert to postfix using operator comparisons via compare()
        """
        tokens = re.findall(r'\d+\.\d+|\d+|[()+\-*/%]', expression)
        output = []
        ops = []
        # map to precedence values used by compare (own small mapping)
        precedence = {'+':1, '-':1, '*':2, '/':2, '%':2}
        for i, t in enumerate(tokens):
            if re.match(r'^\d+(\.\d+)?$', t):
                output.append(t)
            elif t == '(':
                ops.append(t)
            elif t == ')':
                while ops and ops[-1] != '(':
                    output.append(ops.pop())
                if ops:
                    ops.pop()
            else:
                # handle unary minus
                if t == '-' and (i == 0 or tokens[i-1] in {'(', '+', '-', '*', '/', '%'}):
                    output.append('0')
                while ops and ops[-1] != '(' and self.compare(t, ops[-1]):
                    # compare returns True when current has >= precedence
                    # To respect left associativity we pop when peek has higher or equal precedence
                    if precedence.get(ops[-1],0) >= precedence.get(t,0):
                        output.append(ops.pop())
                    else:
                        break
                ops.append(t)
        while ops:
            output.append(ops.pop())
        self.postfix_stack = deque(output)

    @staticmethod
    def is_operator(c):
        return c in {'+', '-', '*', '/', '(', ')', '%'}

    def compare(self, cur, peek):
        # True if current operator has higher or equal precedence than peek
        pr = {'+':1,'-':1,'*':2,'/':2,'%':2}
        return pr.get(cur,0) >= pr.get(peek,0)

    @staticmethod
    def _calculate(first_value, second_value, current_op):
        a = float(first_value)
        b = float(second_value)
        if current_op == '+':
            return a + b
        if current_op == '-':
            return a - b
        if current_op == '*':
            return a * b
        if current_op == '/':
            if b == 0:
                raise ZeroDivisionError("division by zero")
            return a / b
        if current_op == '%':
            if b == 0:
                raise ZeroDivisionError("modulo by zero")
            return a % b
        raise ValueError("Unknown operator")

    @staticmethod
    def transform(expression):
        # compact whitespace and ensure uniform formatting
        return ''.join(expression.split())