import socket
import netifaces
import ipaddress


class IpUtil:
    """
    This is a class as tool for ip that can be used to obtain the local IP address, validate its validity, and also provides the functionality to retrieve the corresponding hostname.
    """

    @staticmethod
    def is_valid_ipv4(ip_address):
        try:
            if not isinstance(ip_address, str):
                return False
            ip = ipaddress.IPv4Address(ip_address)
            return True
        except Exception:
            return False

    @staticmethod
    def is_valid_ipv6(ip_address):
        try:
            if not isinstance(ip_address, str):
                return False
            ip = ipaddress.IPv6Address(ip_address)
            return True
        except Exception:
            return False

    @staticmethod
    def get_hostname(ip_address):
        try:
            # Try a normal reverse DNS lookup
            host, _, _ = socket.gethostbyaddr(ip_address)
            return host
        except Exception:
            # If reverse DNS fails, check if this is a local address and return local hostname
            try:
                for iface in netifaces.interfaces():
                    addrs = netifaces.ifaddresses(iface)
                    for fam in (netifaces.AF_INET, netifaces.AF_INET6):
                        if fam in addrs:
                            for info in addrs[fam]:
                                addr = info.get('addr')
                                if addr and addr.split('%')[0] == ip_address:
                                    return socket.gethostname()
            except Exception:
                pass
        return None