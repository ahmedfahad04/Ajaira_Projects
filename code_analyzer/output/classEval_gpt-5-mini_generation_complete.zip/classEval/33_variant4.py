class DiscountStrategy:
    """
    This is a class that allows to use different discount strategy based on shopping credit or shopping cart in supermarket.
    Lazy evaluation and robust promotion handling.
    """

    def __init__(self, customer, cart, promotion=None):
        self.customer = customer or {}
        self.cart = list(cart) if cart is not None else []
        # allow promotion to be a single callable or iterable of callables (choose best)
        self.promotion = promotion
        # ensure total computed once
        self._total = None
        self.total()

    def total(self):
        if self._total is None:
            self._total = 0.0
            for i in range(len(self.cart)):
                item = self.cart[i]
                qty = item.get('quantity', 0)
                price = item.get('price', 0.0)
                self._total += qty * price
        return self._total

    def due(self):
        total = self.total()
        promo = self.promotion
        discount = 0.0
        if promo is None:
            discount = 0.0
        elif callable(promo):
            discount = float(promo(self))
        else:
            # if an iterable of promos provided, use the maximum discount
            try:
                discounts = [float(p(self)) for p in promo if callable(p)]
                discount = max(discounts) if discounts else 0.0
            except TypeError:
                discount = 0.0
        return total - discount

    @staticmethod
    def FidelityPromo(order):
        # use >= 1000 as threshold
        if order.customer.get('fidelity', 0) >= 1000:
            return order.total() * 0.05
        return 0.0

    @staticmethod
    def BulkItemPromo(order):
        discount = 0.0
        for item in order.cart:
            qty = item.get('quantity', 0)
            if qty >= 20:
                discount += item.get('quantity', 0) * item.get('price', 0.0) * 0.10
        return discount

    @staticmethod
    def LargeOrderPromo(order):
        seen = set()
        for item in order.cart:
            prod = item.get('product')
            if prod is not None:
                seen.add(prod)
        if len(seen) >= 10:
            return order.total() * 0.07
        return 0.0