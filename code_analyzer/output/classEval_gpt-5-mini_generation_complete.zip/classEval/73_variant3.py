class RPGCharacter:
    """
    The class represents a role-playing game character, which allows to attack other characters, heal, gain experience, level up, and check if the character is alive.
    """

    def __init__(self, name, hp, attack_power, defense, level=1):
        self.name = name
        self.max_hp = hp
        self.hp = hp
        self.attack_power = attack_power
        self.defense = defense
        self.level = level
        self.exp = 0

    def attack(self, other_character):
        damage = self.attack_power - other_character.defense
        if damage <= 0:
            damage = 0
        other_character.hp = max(0, other_character.hp - damage)
        return damage

    def heal(self):
        self.hp = self.hp + 10
        if self.hp > self.max_hp:
            self.hp = self.max_hp
        return self.hp

    def level_up(self):
        if self.level >= 100:
            self.exp = 0
            return (self.level, self.hp, self.attack_power, self.defense)
        self.level += 1
        self.max_hp += 20
        self.hp += 20
        self.attack_power += 5
        self.defense += 5
        self.exp = 0
        return (self.level, self.hp, self.attack_power, self.defense)

    def gain_exp(self, amount):
        # iterative threshold consumption using needed variable
        remaining = amount
        # first add to existing exp then try to level
        self.exp += remaining
        while self.level < 100:
            needed = 100 * self.level
            if self.exp >= needed:
                self.exp -= needed
                # apply level up effects without clearing exp
                self.level += 1
                self.max_hp += 20
                self.hp += 20
                self.attack_power += 5
                self.defense += 5
            else:
                break
        if self.level >= 100:
            self.exp = min(self.exp, 100 * self.level)

    def is_alive(self):
        return self.hp > 0

# Classification response:
# formatting only; state variable; temporary variable; loop rewrite; helper function inlining; early return; boundary case handling; behavior change