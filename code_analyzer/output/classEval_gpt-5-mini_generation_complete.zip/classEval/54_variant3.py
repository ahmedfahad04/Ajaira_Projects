import random

class MahjongConnect:
    def __init__(self, BOARD_SIZE, ICONS):
        self.BOARD_SIZE = BOARD_SIZE
        self.ICONS = ICONS
        self.board = self.create_board()

    def create_board(self):
        # create board repeating rows of ICONS to match example style
        rows, cols = self.BOARD_SIZE
        board = []
        for r in range(rows):
            row = []
            for c in range(cols):
                row.append(self.ICONS[c % len(self.ICONS)])
            board.append(row)
        return board

    def in_bounds(self, p):
        x,y = p
        return 0 <= x < self.BOARD_SIZE[0] and 0 <= y < self.BOARD_SIZE[1]

    def is_valid_move(self, pos1, pos2):
        if not (isinstance(pos1, tuple) and isinstance(pos2, tuple)):
            return False
        if pos1 == pos2:
            return False
        if not (self.in_bounds(pos1) and self.in_bounds(pos2)):
            return False
        x1,y1 = pos1
        x2,y2 = pos2
        if self.board[x1][y1] == ' ' or self.board[x2][y2] == ' ':
            return False
        if self.board[x1][y1] != self.board[x2][y2]:
            return False
        return self.has_path(pos1,pos2)

    def has_path(self, pos1, pos2):
        # check direct straight line
        rows, cols = self.BOARD_SIZE
        x1,y1 = pos1
        x2,y2 = pos2
        if pos1 == pos2:
            return False

        def straight_clear(a,b,c,d):
            # a,b to c,d in straight line
            if a==c:
                ystart, yend = sorted([b,d])
                for yy in range(ystart+1,yend):
                    if self.board[a][yy] != ' ':
                        return False
                return True
            if b==d:
                xstart, xend = sorted([a,c])
                for xx in range(xstart+1,xend):
                    if self.board[xx][b] != ' ':
                        return False
                return True
            return False

        # direct
        if straight_clear(x1,y1,x2,y2):
            return True

        # one turn via corner (x1,y2) or (x2,y1)
        corners = [(x1,y2),(x2,y1)]
        for cx,cy in corners:
            if (cx,cy) == pos1 or (cx,cy) == pos2:
                continue
            if self.board[cx][cy] != ' ' and (cx,cy) != pos2:
                continue
            if straight_clear(x1,y1,cx,cy) and straight_clear(cx,cy,x2,y2):
                return True

        # two turns: try all grid points as intermediate corner1 and corner2
        # limit search to empty cells or target
        for rx in range(rows):
            for ry in range(cols):
                if (rx,ry) in (pos1,pos2):
                    continue
                if self.board[rx][ry] != ' ':
                    continue
                # try connect pos1 -> (rx,ry) straight and (rx,ry) -> pos2 with one-turn
                if straight_clear(x1,y1,rx,ry):
                    # now check one-turn from (rx,ry) to pos2 (via its corners)
                    if straight_clear(rx,ry,x2,y2):
                        return True
                    # via corner between
                    c1 = (rx, y2)
                    c2 = (x2, ry)
                    for cx,cy in (c1,c2):
                        if 0 <= cx < rows and 0 <= cy < cols:
                            if ((cx,cy) == pos2 or self.board[cx][cy] == ' ') and straight_clear(rx,ry,cx,cy) and straight_clear(cx,cy,x2,y2):
                                return True
        return False

    def remove_icons(self, pos1, pos2):
        if self.is_valid_move(pos1,pos2):
            x1,y1 = pos1
            x2,y2 = pos2
            self.board[x1][y1] = ' '
            self.board[x2][y2] = ' '

    def is_game_over(self):
        for r in self.board:
            for c in r:
                if c != ' ':
                    return False
        return True

# Classification response:
# helper function extraction;guard clause;type check;loop rewrite;temporary variable;brute force;boundary case handling;behavior change