import random
import ast
import operator
import re

class TwentyFourPointGame:
    """
    This ia a game of twenty-four points, which provides to generate four numbers and check whether player's expression is equal to 24.
    """

    def __init__(self) -> None:
        self.nums = []

    def _generate_cards(self):
        self.nums = [random.randint(1, 9) for _ in range(4)]
        return self.nums

    def get_my_cards(self):
        if not self.nums:
            self._generate_cards()
        return list(self.nums)

    def _extract_numbers(self, expression):
        # extract integer tokens
        tokens = re.findall(r'\d+', expression)
        return [int(t) for t in tokens]

    def _check_numbers_match(self, expression):
        nums_in_expr = self._extract_numbers(expression)
        if len(nums_in_expr) != 4:
            return False
        # compare multisets
        return sorted(nums_in_expr) == sorted(self.nums)

    def _safe_eval(self, expression):
        # evaluate using AST, only allow + - * /
        node = ast.parse(expression, mode='eval')

        def _eval(n):
            if isinstance(n, ast.Expression):
                return _eval(n.body)
            if isinstance(n, ast.BinOp):
                left = _eval(n.left)
                right = _eval(n.right)
                if isinstance(n.op, ast.Add):
                    return left + right
                if isinstance(n.op, ast.Sub):
                    return left - right
                if isinstance(n.op, ast.Mult):
                    return left * right
                if isinstance(n.op, ast.Div):
                    return left / right
                raise ValueError("Unsupported binary op")
            if isinstance(n, ast.UnaryOp):
                if isinstance(n.op, ast.UAdd):
                    return +_eval(n.operand)
                if isinstance(n.op, ast.USub):
                    return -_eval(n.operand)
                raise ValueError("Unsupported unary")
            if isinstance(n, ast.Constant):
                if isinstance(n.value, (int, float)):
                    return n.value
                raise ValueError("Unsupported constant")
            if isinstance(n, ast.Num):
                return n.n
            raise ValueError("Unsupported expression")
        return _eval(node)

    def evaluate_expression(self, expression):
        try:
            val = self._safe_eval(expression)
            return abs(val - 24) < 1e-9
        except Exception:
            return False

    def answer(self, expression):
        if not self._check_numbers_match(expression):
            return False
        return self.evaluate_expression(expression)