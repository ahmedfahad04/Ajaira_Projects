from collections import OrderedDict

class BookManagement:
    """
    This is a class as managing books system, which supports to add and remove books from the inventory dict, view the inventory, and check the quantity of a specific book.
    """

    def __init__(self):
        """
        Initialize the inventory of Book Manager.
        """
        self._store = OrderedDict()
        self.inventory = {}

    def _resort_inventory(self):
        # keep self.inventory as a regular dict but with keys sorted
        self.inventory = dict(OrderedDict(sorted(self._store.items(), key=lambda kv: kv[0])))

    def add_book(self, title, quantity=1):
        """
        Add one or several books to inventory which is sorted by book title.
        """
        if not isinstance(title, str) or not isinstance(quantity, int) or quantity <= 0:
            return False
        current = self._store.get(title, 0)
        self._store[title] = current + quantity
        # re-sort underlying ordered dict
        self._store = OrderedDict(sorted(self._store.items(), key=lambda kv: kv[0]))
        self._resort_inventory()
        return True

    def remove_book(self, title, quantity):
        """
        Remove one or several books from inventory which is sorted by book title.
        Return False on invalid input.
        """
        if not isinstance(title, str) or not isinstance(quantity, int) or quantity <= 0:
            return False
        if title not in self._store:
            return False
        if quantity > self._store[title]:
            return False
        remaining = self._store[title] - quantity
        if remaining > 0:
            self._store[title] = remaining
        else:
            del self._store[title]
        self._store = OrderedDict(sorted(self._store.items(), key=lambda kv: kv[0]))
        self._resort_inventory()
        return True

    def view_inventory(self):
        """
        Get the inventory of the Book Management.
        """
        # ensure inventory is sorted
        self._resort_inventory()
        return dict(self.inventory)

    def view_book_quantity(self, title):
        """
        Get the quantity of a book.
        """
        return int(self.inventory.get(title, 0))