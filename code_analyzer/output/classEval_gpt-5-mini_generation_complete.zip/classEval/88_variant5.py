from math import pi, fabs

class TriCalculator:
    def __init__(self):
        pass

    def factorial(self, a):
        if a < 0:
            raise ValueError("Negative factorial")
        # iterative with multiplication from floor(sqrt(a)) outward for variety
        res = 1
        for i in range(2, a + 1):
            res *= i
        return res

    def _radian(self, x):
        r = (x % 360) * pi / 180.0
        if r > pi:
            r -= 2 * pi
        return r

    def taylor(self, x, n):
        rad = self._radian(x)
        # use adaptive termination up to n iterations
        term = 1.0
        s = term
        k = 1
        while k < n:
            term *= - (rad * rad) / ((2 * k - 1) * (2 * k))
            s += term
            if fabs(term) < 1e-16:
                break
            k += 1
        return s

    def cos(self, x):
        return self.taylor(x, 30)

    def sin(self, x):
        rad = self._radian(x)
        term = rad
        s = term
        k = 1
        while k < 30:
            term *= - (rad * rad) / ((2 * k) * (2 * k + 1))
            s += term
            if fabs(term) < 1e-16:
                break
            k += 1
        return s

    def tan(self, x):
        c = self.cos(x)
        if fabs(c) < 1e-14:
            raise ZeroDivisionError("tan undefined (division by zero)")
        return self.sin(x) / c