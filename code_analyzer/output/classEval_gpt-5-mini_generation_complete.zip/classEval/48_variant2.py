import socket
import netifaces
import re


class IpUtil:
    """
    This is a class as tool for ip that can be used to obtain the local IP address, validate its validity, and also provides the functionality to retrieve the corresponding hostname.
    """

    _ipv4_re = re.compile(r"""
        ^
        (?:(?:25[0-5]|2[0-4]\d|1?\d{1,2})\.){3}
        (?:25[0-5]|2[0-4]\d|1?\d{1,2})
        $
    """, re.VERBOSE)

    @staticmethod
    def is_valid_ipv4(ip_address):
        if not isinstance(ip_address, str):
            return False
        if IpUtil._ipv4_re.match(ip_address) is None:
            return False
        try:
            socket.inet_aton(ip_address)
            return True
        except Exception:
            return False

    @staticmethod
    def is_valid_ipv6(ip_address):
        if not isinstance(ip_address, str):
            return False
        try:
            socket.inet_pton(socket.AF_INET6, ip_address)
            return True
        except Exception:
            return False

    @staticmethod
    def get_hostname(ip_address):
        try:
            fqdn = socket.getfqdn(ip_address)
            if fqdn and fqdn != ip_address:
                return fqdn
        except Exception:
            pass
        try:
            name = socket.gethostbyaddr(ip_address)[0]
            return name
        except Exception:
            pass
        try:
            for iface in netifaces.interfaces():
                addrs = netifaces.ifaddresses(iface)
                for fam in (netifaces.AF_INET, netifaces.AF_INET6):
                    if fam in addrs:
                        for info in addrs[fam]:
                            addr = info.get('addr')
                            if addr and addr.split('%')[0] == ip_address:
                                return iface
        except Exception:
            pass
        return None