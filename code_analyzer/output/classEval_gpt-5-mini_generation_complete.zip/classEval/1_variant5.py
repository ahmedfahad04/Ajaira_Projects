import math
class AreaCalculator:
    """
    This is a class for calculating the area of different shapes, including circle, sphere, cylinder, sector and annulus.
    """

    def __init__(self, radius):
        """
        Initialize the radius for shapes.
        :param radius: float
        """
        r = float(radius)
        self._r = r
        # closure helpers
        self._circle_fn = lambda: math.pi * (self._r ** 2)
        self._sphere_fn = lambda: 4.0 * math.pi * (self._r ** 2)
        self._cylinder_fn = lambda h: 2.0 * math.pi * self._r * (self._r + h)
        self._sector_fn = lambda a: 0.5 * (self._r ** 2) * a
        self._annulus_fn = lambda ir, orr: math.pi * ((orr ** 2) - (ir ** 2))

    @property
    def radius(self):
        return self._r

    @radius.setter
    def radius(self, value):
        self._r = float(value)
        self._circle_fn = lambda: math.pi * (self._r ** 2)
        self._sphere_fn = lambda: 4.0 * math.pi * (self._r ** 2)
        self._cylinder_fn = lambda h: 2.0 * math.pi * self._r * (self._r + h)
        self._sector_fn = lambda a: 0.5 * (self._r ** 2) * a

    def calculate_circle_area(self):
        return self._circle_fn()

    def calculate_sphere_area(self):
        return self._sphere_fn()

    def calculate_cylinder_area(self, height):
        return self._cylinder_fn(float(height))

    def calculate_sector_area(self, angle):
        return self._sector_fn(float(angle))

    def calculate_annulus_area(self, inner_radius, outer_radius):
        return self._annulus_fn(float(inner_radius), float(outer_radius))