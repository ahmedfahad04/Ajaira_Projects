import math
class BigNumCalculator:
    """
    This is a class that implements big number calculations, including adding, subtracting and multiplying.
    """

    @staticmethod
    def _norm(s):
        if not s:
            return "0"
        s = s.strip()
        sign = ""
        if s[0] == "+":
            s = s[1:]
        if s[0] == "-":
            sign = "-"
            s = s[1:]
        s = s.lstrip("0")
        if s == "":
            return "0"
        return (sign + s) if sign == "-" else s

    @staticmethod
    def add(num1, num2):
        return str(int(num1) + int(num2))

    @staticmethod
    def subtract(num1, num2):
        return str(int(num1) - int(num2))

    @staticmethod
    def _fft(self, a, invert):
        n = len(a)
        j = 0
        for i in range(1, n):
            bit = n >> 1
            while j & bit:
                j ^= bit
                bit >>= 1
            j ^= bit
            if i < j:
                a[i], a[j] = a[j], a[i]
        length = 2
        while length <= n:
            ang = 2 * math.pi / length * (-1 if invert else 1)
            wlen = complex(math.cos(ang), math.sin(ang))
            i = 0
            while i < n:
                w = 1+0j
                for j in range(i, i + length // 2):
                    u = a[j]
                    v = a[j + length // 2] * w
                    a[j] = u + v
                    a[j + length // 2] = u - v
                    w *= wlen
                i += length
            length <<= 1
        if invert:
            for i in range(n):
                a[i] /= n

    @staticmethod
    def multiply(num1, num2):
        n1 = BigNumCalculator._norm(num1)
        n2 = BigNumCalculator._norm(num2)
        sign = 1
        if n1.startswith("-"):
            sign = -sign
            n1 = n1[1:]
        if n2.startswith("-"):
            sign = -sign
            n2 = n2[1:]
        if n1 == "0" or n2 == "0":
            return "0"
        a = [complex(int(ch), 0) for ch in n1[::-1]]
        b = [complex(int(ch), 0) for ch in n2[::-1]]
        n = 1
        while n < len(a) + len(b):
            n <<= 1
        a += [0j] * (n - len(a))
        b += [0j] * (n - len(b))
        BigNumCalculator._fft(a, False)
        BigNumCalculator._fft(b, False)
        for i in range(n):
            a[i] *= b[i]
        BigNumCalculator._fft(a, True)
        res = [0] * n
        carry = 0
        for i in range(n):
            val = int(round(a[i].real)) + carry
            res[i] = val % 10
            carry = val // 10
        while carry:
            res.append(carry % 10)
            carry //= 10
        while len(res) > 1 and res[-1] == 0:
            res.pop()
        s = ''.join(str(d) for d in res[::-1])
        return ("-" + s) if sign < 0 else s