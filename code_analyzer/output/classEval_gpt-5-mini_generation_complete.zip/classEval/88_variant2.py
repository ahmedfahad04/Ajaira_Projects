from math import pi, fabs

class TriCalculator:
    def __init__(self):
        pass

    def factorial(self, a):
        if a < 0:
            raise ValueError("Negative factorial")
        if a == 0:
            return 1
        result = 1
        for i in range(2, a + 1):
            result *= i
        return result

    def _normalize_rad(self, x):
        # convert degrees to radians and normalize to [-pi, pi]
        r = (x % 360) * pi / 180.0
        if r > pi:
            r -= 2 * pi
        return r

    def taylor(self, x, n):
        rad = self._normalize_rad(x)
        # use recurrence for terms to avoid repeated pow/factorial
        term = 1.0
        s = term
        for k in range(1, n):
            term *= - (rad * rad) / ((2 * k - 1) * (2 * k))
            s += term
        return s

    def cos(self, x):
        return self.taylor(x, 20)

    def sin(self, x):
        rad = self._normalize_rad(x)
        term = rad
        s = term
        k = 1
        # build sine via recurrence
        while k < 20:
            term *= - (rad * rad) / ((2 * k) * (2 * k + 1))
            s += term
            k += 1
        return s

    def tan(self, x):
        c = self.cos(x)
        if fabs(c) < 1e-14:
            raise ZeroDivisionError("Tangent undefined (cosine near zero)")
        return self.sin(x) / c