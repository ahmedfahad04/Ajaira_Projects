class ComplexCalculator:
    """
    This is a class that implements addition, subtraction, multiplication, and division operations for complex numbers.
    """

    def __init__(self):
        pass

    @staticmethod
    def _to_complex(value):
        if isinstance(value, complex):
            return value
        if isinstance(value, (list, tuple)) and len(value) == 2:
            return complex(value[0], value[1])
        if isinstance(value, (int, float)):
            return complex(value, 0)
        raise TypeError("Unsupported type for complex conversion")

    @staticmethod
    def add(c1, c2):
        a = ComplexCalculator._to_complex(c1)
        b = ComplexCalculator._to_complex(c2)
        return a + b

    @staticmethod
    def subtract(c1, c2):
        a = ComplexCalculator._to_complex(c1)
        b = ComplexCalculator._to_complex(c2)
        return a - b

    @staticmethod
    def multiply(c1, c2):
        a = ComplexCalculator._to_complex(c1)
        b = ComplexCalculator._to_complex(c2)
        return a * b

    @staticmethod
    def divide(c1, c2):
        a = ComplexCalculator._to_complex(c1)
        b = ComplexCalculator._to_complex(c2)
        if b.real == 0 and b.imag == 0:
            raise ZeroDivisionError("division by zero")
        return a / b