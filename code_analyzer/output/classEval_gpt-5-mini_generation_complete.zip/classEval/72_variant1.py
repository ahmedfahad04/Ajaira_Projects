import re

class RegexUtils:
    """
    The class provides to match, find all occurrences, split, and substitute text using regular expressions. It also includes predefined patterns, validating phone numbers and extracting email addresses.
    """

    def match(self, pattern, text):
        if isinstance(pattern, str):
            try:
                return re.search(pattern, text) is not None
            except re.error:
                return False
        else:
            return pattern.search(text) is not None

    def findall(self, pattern, text):
        if isinstance(pattern, str):
            return re.findall(pattern, text)
        else:
            return pattern.findall(text)

    def split(self, pattern, text):
        if isinstance(pattern, str):
            return re.split(pattern, text)
        else:
            return pattern.split(text)

    def sub(self, pattern, replacement, text):
        if isinstance(pattern, str):
            return re.sub(pattern, replacement, text)
        else:
            return pattern.sub(replacement, text)

    def generate_email_pattern(self):
        return r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'

    def generate_phone_number_pattern(self):
        return r'\b\d{3}-\d{3}-\d{4}\b'

    def generate_split_sentences_pattern(self):
        return r'[.!?][\s]{1,2}(?=[A-Z])'

    def split_sentences(self, text):
        # Split on whitespace between sentence-ending punctuation and a capital letter
        parts = re.split(r'(?<=[.!?])\s+(?=[A-Z])', text)
        # Strip outer whitespace and remove trailing punctuation for all but last
        parts = [p.strip() for p in parts if p is not None]
        for i in range(len(parts) - 1):
            parts[i] = re.sub(r'[.!?]+$', '', parts[i]).strip()
        return parts

    def validate_phone_number(self, phone_number):
        pattern = self.generate_phone_number_pattern()
        try:
            return re.fullmatch(pattern, phone_number) is not None
        except re.error:
            # Fallback: simple digit-dash pattern
            return bool(re.fullmatch(r'\d{3}-\d{3}-\d{4}', phone_number))

    def extract_email(self, text):
        pattern = self.generate_email_pattern()
        try:
            return re.findall(pattern, text, flags=re.IGNORECASE)
        except re.error:
            # fallback simpler pattern
            return re.findall(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', text)

# Classification response:
# try-except wrapper; input validation; error suppression; list comprehension; temporary variable; in-place mutation; regex usage; for loop