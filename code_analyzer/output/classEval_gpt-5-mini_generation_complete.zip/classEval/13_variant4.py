from collections import Counter

class BookManagement:
    """
    Uses Counter under the hood and exposes inventory as a sorted dict.
    """

    def __init__(self):
        """
        Initialize the inventory of Book Manager.
        """
        self._counter = Counter()
        self.inventory = {}

    def _update_view(self):
        # create a normal dict sorted by title
        self.inventory = dict(sorted(self._counter.items(), key=lambda kv: kv[0]))

    def add_book(self, title, quantity=1):
        if not isinstance(title, str) or not isinstance(quantity, int) or quantity <= 0:
            return False
        self._counter[title] += quantity
        self._update_view()
        return True

    def remove_book(self, title, quantity):
        if not isinstance(title, str) or not isinstance(quantity, int) or quantity <= 0:
            return False
        if self._counter.get(title, 0) < quantity:
            return False
        self._counter[title] -= quantity
        if self._counter[title] == 0:
            del self._counter[title]
        self._update_view()
        return True

    def view_inventory(self):
        self._update_view()
        return dict(self.inventory)

    def view_book_quantity(self, title):
        return int(self._counter.get(title, 0))