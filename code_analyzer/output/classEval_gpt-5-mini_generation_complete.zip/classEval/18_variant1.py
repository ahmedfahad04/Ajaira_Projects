class CamelCaseMap:
    """
    This is a custom class that allows keys to be in camel case style by converting them from underscore style, which provides dictionary-like functionality.
    """

    def __init__(self):
        """
        Initialize data to an empty dictionary
        """
        self._data = {}

    def __getitem__(self, key):
        """
        Return the value corresponding to the key
        """
        ck = self._convert_key(key)
        return self._data[ck]

    def __setitem__(self, key, value):
        """
        Set the value corresponding to the key to the specified value
        """
        ck = self._convert_key(key)
        self._data[ck] = value

    def __delitem__(self, key):
        """
        Delete the value corresponding to the key
        """
        ck = self._convert_key(key)
        del self._data[ck]

    def __iter__(self):
        """
        Returning Iterateable Objects with Own Data
        """
        return iter(self._data)

    def __len__(self):
        """
        Returns the length of the own data
        """
        return len(self._data)

    def _convert_key(self, key):
        """
        convert key string into camel case
        """
        if not isinstance(key, str):
            return key
        return self._to_camel_case(key)

    @staticmethod
    def _to_camel_case(key):
        """
        convert key string into camel case
        """
        if not isinstance(key, str):
            return key
        parts = key.split('_')
        if not parts:
            return ''
        first = parts[0]
        rest = ''.join(p.capitalize() if p else '' for p in parts[1:])
        return first + rest