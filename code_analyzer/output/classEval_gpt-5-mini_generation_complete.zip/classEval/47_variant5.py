class IPAddress:
    """
    This is a class to process IP Address, including validating, getting the octets and obtaining the binary representation of a valid IP address.
    """

    def __init__(self, ip_address):
        self.ip_address = ip_address

    def _clean_split(self):
        if not isinstance(self.ip_address, str):
            return None
        s = self.ip_address.strip()
        parts = s.split('.')
        return parts

    def is_valid(self):
        parts = self._clean_split()
        if parts is None or len(parts) != 4:
            return False
        for p in parts:
            if p == '':
                return False
            # Reject any sign or non-digit
            if p[0] in '+-' or not all(ch.isdigit() for ch in p):
                return False
            # No more than 3 digits
            if len(p) > 3:
                return False
            try:
                n = int(p)
            except Exception:
                return False
            if n < 0 or n > 255:
                return False
        return True

    def get_octets(self):
        if not self.is_valid():
            return []
        return self._clean_split()

    def get_binary(self):
        if not self.is_valid():
            return ''
        return '.'.join(f"{int(o):08b}" for o in self.get_octets())