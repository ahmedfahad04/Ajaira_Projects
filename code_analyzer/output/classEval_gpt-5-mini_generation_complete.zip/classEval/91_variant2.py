import urllib.parse
import re
from collections import deque

class UrlPath:
    """
    The  class is a utility for encapsulating and manipulating the path component of a URL, including adding nodes, parsing path strings, and building path strings with optional encoding.
    """

    def __init__(self):
        """
        Initializes the UrlPath object with an empty list of segments and a flag indicating the presence of an end tag.
        """
        self.segments = []
        self.with_end_tag = False

    def add(self, segment):
        """
        Adds a segment to the list of segments in the UrlPath.
        This implementation will split a provided segment on '/' and add each non-empty piece.
        """
        if segment is None:
            return self
        s = str(segment)
        # Interpret empty string as a trailing slash indicator
        if s == '':
            self.with_end_tag = True
            return self
        parts = [p for p in s.split('/') if p != '']
        for p in parts:
            self.segments.append(p)
        # Adding explicit content removes trailing-slash flag
        self.with_end_tag = False
        return self

    def parse(self, path, charset):
        """
        Parses a given path string and populates the list of segments in the UrlPath.
        Uses unquote_to_bytes then decodes with the given charset for precise control.
        Collapses multiple slashes into single boundaries between segments.
        """
        self.segments = deque()
        self.with_end_tag = False
        if path is None:
            return
        # Extract path if a full URL is provided
        try:
            path_component = urllib.parse.urlsplit(path).path
            if path_component is None:
                path_component = ''
        except Exception:
            path_component = path
        if path_component.endswith('/'):
            self.with_end_tag = True
        # Collapse multiple slashes and strip leading/trailing
        collapsed = re.sub(r'/+', '/', path_component)
        fixed = collapsed.strip('/')
        if fixed == '':
            self.segments = []
            return
        for raw in fixed.split('/'):
            if raw == '':
                continue
            # decode percent-encoded bytes and then decode to string with charset
            try:
                b = urllib.parse.unquote_to_bytes(raw)
                seg = b.decode(charset, errors='strict')
            except Exception:
                # fallback to simple unquote
                seg = urllib.parse.unquote(raw)
            self.segments.append(seg)
        # convert deque back to list
        self.segments = list(self.segments)

    @staticmethod
    def fix_path(path):
        """
        Fixes the given path string by removing leading and trailing slashes and collapsing multiple slashes.
        """
        if path is None:
            return ''
        try:
            p = urllib.parse.urlsplit(path).path
            if p is None:
                p = path
        except Exception:
            p = path
        # collapse multiple slashes then trim
        p = re.sub(r'/+', '/', p)
        return p.strip('/')