import nltk
from nltk.stem import WordNetLemmatizer
from nltk import pos_tag, word_tokenize
from nltk.corpus import wordnet
import string

nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')
nltk.download('wordnet')

class Lemmatization:
    """
    This is a class about Lemmatization, which utilizes the nltk library to perform lemmatization and part-of-speech tagging on sentences, as well as remove punctuation.
    """

    def __init__(self):
        """
        creates a WordNetLemmatizer object and stores it in the self.lemmatizer member variable.
        """
        self.lemmatizer = WordNetLemmatizer()
        self._mapping = {
            'J': wordnet.ADJ,
            'V': wordnet.VERB,
            'N': wordnet.NOUN,
            'R': wordnet.ADV
        }

    def remove_punctuation(self, sentence):
        table = str.maketrans({p: None for p in string.punctuation})
        return sentence.translate(table)

    def get_pos_tag(self, sentence):
        cleaned = self.remove_punctuation(sentence)
        tokens = word_tokenize(cleaned)
        return [tag for _, tag in pos_tag(tokens)]

    def lemmatize_sentence(self, sentence):
        cleaned = self.remove_punctuation(sentence)
        tokens = word_tokenize(cleaned)
        tags = pos_tag(tokens)
        output = []
        for word, tag in tags:
            wn_pos = self._mapping.get(tag[0], wordnet.NOUN)
            output.append(self.lemmatizer.lemmatize(word, wn_pos))
        return output