import itertools
from functools import reduce
import operator

class ArrangementCalculator:
    """
    The Arrangement class provides permutation calculations and selection operations for a given set of data elements.
    """

    def __init__(self, datas):
        self.datas = list(datas)

    @staticmethod
    def factorial(n):
        if n < 0:
            raise ValueError("Negative factorial is not defined")
        if n == 0 or n == 1:
            return 1
        result = 1
        for i in range(2, n + 1):
            result *= i
        return result

    @staticmethod
    def count(n, m=None):
        if n < 0:
            return 0
        if m is None or m == n:
            return ArrangementCalculator.factorial(n)
        if m < 0 or m > n:
            return 0
        result = 1
        for i in range(n, n - m, -1):
            result *= i
        return result

    @staticmethod
    def count_all(n):
        if n <= 0:
            return 0
        total = 0
        for k in range(1, n + 1):
            total += ArrangementCalculator.count(n, k)
        return total

    def select(self, m=None):
        n = len(self.datas)
        if m is None:
            m = n
        if m < 0 or m > n:
            return []
        return [list(p) for p in itertools.permutations(self.datas, m)]

    def select_all(self):
        n = len(self.datas)
        out = []
        for k in range(1, n + 1):
            out += [list(p) for p in itertools.permutations(self.datas, k)]
        return out