class Interpolation:
    """
    This is a class that implements the Linear interpolation operation of one-dimensional and two-dimensional data
    """

    def __init__(self):
        pass

    @staticmethod
    def _find_interval(arr, v):
        lo = 0
        hi = len(arr) - 1
        if hi <= 0:
            return 0, 0
        if v <= arr[0]:
            return 0, 1
        if v >= arr[-1]:
            return hi-1, hi
        while lo + 1 < hi:
            mid = (lo + hi) // 2
            if arr[mid] == v:
                return mid, mid
            if arr[mid] < v:
                lo = mid
            else:
                hi = mid
        return lo, hi

    @staticmethod
    def interpolate_1d(x, y, x_interp):
        if len(x) != len(y):
            raise ValueError("x and y lengths mismatch")
        n = len(x)
        if n == 0:
            return []
        out = []
        for xv in x_interp:
            if n == 1:
                out.append(float(y[0]))
                continue
            i0, i1 = Interpolation._find_interval(x, xv)
            if i0 == i1:
                out.append(float(y[i0]))
                continue
            x0, x1 = x[i0], x[i1]
            y0, y1 = y[i0], y[i1]
            if x1 == x0:
                out.append(float(y0))
            else:
                t = (xv - x0) / (x1 - x0)
                out.append(float(y0 + t * (y1 - y0)))
        return out

    @staticmethod
    def interpolate_2d(x, y, z, x_interp, y_interp):
        if len(x) == 0 or len(y) == 0:
            return []
        if len(z) != len(x) or any(len(r) != len(y) for r in z):
            raise ValueError("z must match grid dimensions")
        res = []
        for xv, yv in zip(x_interp, y_interp):
            if len(x) == 1 and len(y) == 1:
                res.append(float(z[0][0]))
                continue
            ix0, ix1 = Interpolation._find_interval(x, xv)
            iy0, iy1 = Interpolation._find_interval(y, yv)
            if ix0 == ix1 and iy0 == iy1:
                res.append(float(z[ix0][iy0]))
                continue
            x0, x1 = x[ix0], x[ix1] if ix0 != ix1 else x[ix0]
            y0, y1 = y[iy0], y[iy1] if iy0 != iy1 else y[iy0]
            z00 = z[ix0][iy0]
            if ix0 == ix1:
                z01 = z[ix0][iy1]
                if y1 == y0:
                    res.append(float(z00))
                else:
                    ty = (yv - y0) / (y1 - y0)
                    res.append(float(z00 + ty * (z01 - z00)))
                continue
            if iy0 == iy1:
                z10 = z[ix1][iy0]
                if x1 == x0:
                    res.append(float(z00))
                else:
                    tx = (xv - x0) / (x1 - x0)
                    res.append(float(z00 + tx * (z10 - z00)))
                continue
            z10 = z[ix1][iy0]
            z01 = z[ix0][iy1]
            z11 = z[ix1][iy1]
            tx = (xv - x0) / (x1 - x0) if x1 != x0 else 0.0
            ty = (yv - y0) / (y1 - y0) if y1 != y0 else 0.0
            val = (z00 * (1 - tx) * (1 - ty) +
                   z10 * tx * (1 - ty) +
                   z01 * (1 - tx) * ty +
                   z11 * tx * ty)
            res.append(float(val))
        return res