import math

class Statistics3:
    """
    This is a class that implements methods for calculating indicators such as median, mode, correlation matrix, and Z-score in statistics.
    """

    @staticmethod
    def median(data):
        if not data:
            raise ValueError("median requires at least one data point")
        sorted_data = sorted(data)
        n = len(sorted_data)
        mid = n // 2
        if n % 2 == 1:
            return float(sorted_data[mid])
        else:
            return (sorted_data[mid - 1] + sorted_data[mid]) / 2.0

    @staticmethod
    def mode(data):
        if not data:
            return []
        counts = {}
        for x in data:
            counts[x] = counts.get(x, 0) + 1
        max_count = max(counts.values())
        modes = [k for k, v in counts.items() if v == max_count]
        try:
            return sorted(modes)
        except TypeError:
            return modes

    @staticmethod
    def correlation(x, y):
        if not x or not y:
            raise ValueError("inputs must be non-empty")
        if len(x) != len(y):
            raise ValueError("inputs must have same length")
        n = len(x)
        if n < 2:
            return 0.0
        mx = Statistics3.mean(x)
        my = Statistics3.mean(y)
        cov = 0.0
        sx = 0.0
        sy = 0.0
        for xi, yi in zip(x, y):
            dx = xi - mx
            dy = yi - my
            cov += dx * dy
            sx += dx * dx
            sy += dy * dy
        cov /= (n - 1)
        sx = math.sqrt(sx / (n - 1)) if n > 1 else 0.0
        sy = math.sqrt(sy / (n - 1)) if n > 1 else 0.0
        if sx == 0 or sy == 0:
            return 0.0
        return cov / (sx * sy)

    @staticmethod
    def mean(data):
        if not data:
            raise ValueError("mean requires at least one data point")
        return float(sum(data)) / len(data)

    @staticmethod
    def correlation_matrix(data):
        if not data:
            return []
        m = len(data)
        # assume each element is a sequence representing a variable
        # compute pairwise correlations
        matrix = [[0.0] * m for _ in range(m)]
        for i in range(m):
            for j in range(m):
                if i == j:
                    matrix[i][j] = 1.0
                else:
                    matrix[i][j] = Statistics3.correlation(data[i], data[j])
        return matrix

    @staticmethod
    def standard_deviation(data):
        n = len(data)
        if n < 2:
            return 0.0
        m = Statistics3.mean(data)
        ssd = sum((x - m) ** 2 for x in data)
        variance = ssd / (n - 1)
        return math.sqrt(variance)

    @staticmethod
    def z_score(data):
        n = len(data)
        if n == 0:
            return []
        m = Statistics3.mean(data)
        sd = Statistics3.standard_deviation(data)
        if sd == 0:
            return [0.0 for _ in data]
        return [ (x - m) / sd for x in data ]