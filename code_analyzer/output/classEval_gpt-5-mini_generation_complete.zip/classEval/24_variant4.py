import cmath

class ComplexCalculator:
    """
    This is a class that implements addition, subtraction, multiplication, and division operations for complex numbers.
    """

    def __init__(self):
        pass

    @staticmethod
    def _normalize(x):
        if isinstance(x, complex):
            return x
        if isinstance(x, (tuple, list)) and len(x) == 2:
            return complex(x[0], x[1])
        if isinstance(x, (int, float)):
            return complex(x, 0)
        raise TypeError("Unsupported type")

    @staticmethod
    def add(c1, c2):
        a = ComplexCalculator._normalize(c1)
        b = ComplexCalculator._normalize(c2)
        return complex(a.real + b.real, a.imag + b.imag)

    @staticmethod
    def subtract(c1, c2):
        a = ComplexCalculator._normalize(c1)
        b = ComplexCalculator._normalize(c2)
        return complex(a.real - b.real, a.imag - b.imag)

    @staticmethod
    def multiply(c1, c2):
        a = ComplexCalculator._normalize(c1)
        b = ComplexCalculator._normalize(c2)
        # use polar multiplication
        r1, phi1 = cmath.polar(a)
        r2, phi2 = cmath.polar(b)
        r = r1 * r2
        phi = phi1 + phi2
        return cmath.rect(r, phi)

    @staticmethod
    def divide(c1, c2):
        a = ComplexCalculator._normalize(c1)
        b = ComplexCalculator._normalize(c2)
        if b.real == 0 and b.imag == 0:
            raise ZeroDivisionError("division by zero")
        # use polar division
        r1, phi1 = cmath.polar(a)
        r2, phi2 = cmath.polar(b)
        r = r1 / r2
        phi = phi1 - phi2
        return cmath.rect(r, phi)