class SQLGenerator:
    """
    This class generates SQL statements for common operations on a table, such as SELECT, INSERT, UPDATE, and DELETE.
    """

    def __init__(self, table_name):
        """
        Initialize the table name.
        :param table_name: str
        """
        self.table_name = table_name

    def _escape(self, v):
        if v is None:
            return "NULL"
        if isinstance(v, bool):
            return "TRUE" if v else "FALSE"
        if isinstance(v, (int, float)):
            return str(v)
        s = str(v)
        s = s.replace("'", "''")
        return f"'{s}'"

    def select(self, fields=None, condition=None):
        """
        Generates a SELECT SQL statement based on the specified fields and conditions.
        """
        if not fields:
            field_clause = "*"
        else:
            field_clause = ", ".join(fields)
        sql = f"SELECT {field_clause} FROM {self.table_name}"
        if condition:
            sql += f" WHERE {condition}"
        sql += ";"
        return sql

    def insert(self, data):
        """
        Generates an INSERT SQL statement based on the given data.
        """
        if not data:
            raise ValueError("data for insert cannot be empty")
        keys = list(data.keys())
        cols = ", ".join(keys)
        vals = ", ".join(self._escape(data[k]) for k in keys)
        return f"INSERT INTO {self.table_name} ({cols}) VALUES ({vals});"

    def update(self, data, condition):
        """
        Generates an UPDATE SQL statement based on the given data and condition.
        """
        if not data:
            raise ValueError("data for update cannot be empty")
        sets = ", ".join(f"{k} = {self._escape(v)}" for k, v in data.items())
        sql = f"UPDATE {self.table_name} SET {sets}"
        if condition:
            sql += f" WHERE {condition}"
        sql += ";"
        return sql

    def delete(self, condition):
        """
        Generates a DELETE SQL statement based on the given condition.
        """
        sql = f"DELETE FROM {self.table_name}"
        if condition:
            sql += f" WHERE {condition}"
        sql += ";"
        return sql

    def select_female_under_age(self, age):
        """
        Generates a SQL statement to select females under a specified age.
        """
        return f"SELECT * FROM {self.table_name} WHERE age < {int(age)} AND gender = 'female';"

    def select_by_age_range(self, min_age, max_age):
        """
        Generates a SQL statement to select records within a specified age range.
        """
        return f"SELECT * FROM {self.table_name} WHERE age BETWEEN {int(min_age)} AND {int(max_age)};"