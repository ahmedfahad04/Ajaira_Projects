import logging
import datetime
import re
from threading import local

class AccessGatewayFilter:
    """
    This class is a filter used for accessing gateway filtering, primarily for authentication and access log recording.
    """

    def __init__(self, prefixes=None):
        self._local = local()
        self._local.current_user = None
        self.allowed_prefixes = prefixes if prefixes is not None else ['/api', '/login']
        # compile a regex to check allowed prefixes quickly
        pattern = r'^(?:' + '|'.join(re.escape(p) for p in self.allowed_prefixes) + r')'
        self._prefix_re = re.compile(pattern)
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger('AccessGatewayFilter')

    def filter(self, request):
        if not isinstance(request, dict):
            return False
        path = request.get('path', '')
        method = request.get('method', 'GET')
        # quick allow for OPTIONS
        if method and method.upper() == 'OPTIONS':
            return True
        if self.is_start_with(path):
            # /login is allowed without auth
            if path.startswith('/login'):
                return True
            # other allowed prefixes might require authentication
            user = self.get_jwt_user(request)
            if user:
                self.set_current_user_info_and_log(user)
                return True
            return False
        # If not matching prefixes, default deny for safety
        return False

    def is_start_with(self, request_uri):
        if not isinstance(request_uri, str):
            return False
        return bool(self._prefix_re.match(request_uri))

    def get_jwt_user(self, request):
        headers = request.get('headers', {})
        if not isinstance(headers, dict):
            return None
        auth = headers.get('Authorization') or headers.get('authorization')
        if not isinstance(auth, dict):
            return None
        # Support token formats: 'usernameYYYY-MM-DD' or 'username|YYYY-MM-DD'
        token = auth.get('jwt')
        user_obj = auth.get('user')
        if user_obj and token is None:
            # allow if user provided e.g., internal trusted call
            return user_obj
        if not token:
            return None
        today = str(datetime.date.today())
        # If token uses separator
        if '|' in token:
            parts = token.split('|', 1)
            username, date_part = parts[0], parts[1]
        else:
            # assume last 10 chars are date
            username, date_part = token[:-10], token[-10:]
        if date_part != today:
            return None
        if user_obj and isinstance(user_obj, dict):
            # validate username if present in user_obj
            name = user_obj.get('name') or user_obj.get('username')
            if name and name != username:
                return None
            return user_obj
        return {'name': username} if username else None

    def set_current_user_info_and_log(self, user):
        self._local.current_user = user
        ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        name = user.get('name') if isinstance(user, dict) else str(user)
        self.logger.info("User accessed: %s at %s", name, ts)