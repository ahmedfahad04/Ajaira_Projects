import random
import ast
import re
from collections import Counter

class TwentyFourPointGame:
    """
    This ia a game of twenty-four points, which provides to generate four numbers and check whether player's expression is equal to 24.
    """

    def __init__(self) -> None:
        self.nums = []

    def _generate_cards(self):
        self.nums = [random.randint(1, 9) for _ in range(4)]
        return self.nums

    def get_my_cards(self):
        # always generate fresh cards when requested
        return self._generate_cards()

    def _numbers_from_expr(self, expression):
        # find all integer tokens (multi-digit guarded)
        return [int(x) for x in re.findall(r'\d+', expression)]

    def _allowed_ast(self, node):
        # ensure only safe nodes
        if isinstance(node, ast.Expression):
            return self._allowed_ast(node.body)
        if isinstance(node, ast.BinOp):
            if not isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div)):
                return False
            return self._allowed_ast(node.left) and self._allowed_ast(node.right)
        if isinstance(node, ast.UnaryOp):
            return isinstance(node.op, (ast.UAdd, ast.USub)) and self._allowed_ast(node.operand)
        if isinstance(node, (ast.Num, ast.Constant)):
            return True
        if isinstance(node, ast.Call):
            return False
        if isinstance(node, ast.Name):
            return False
        if isinstance(node, ast.Subscript):
            return False
        # other nodes disallowed
        return False

    def evaluate_expression(self, expression):
        try:
            tree = ast.parse(expression, mode='eval')
            if not self._allowed_ast(tree):
                return False
            # safe to eval using eval with empty globals and locals
            value = eval(compile(tree, '<expr>', 'eval'), {"__builtins__": {}}, {})
            return abs(value - 24) < 1e-9
        except Exception:
            return False

    def answer(self, expression):
        if not self.nums:
            # if nums not set, generate one
            self._generate_cards()
        nums_used = self._numbers_from_expr(expression)
        if len(nums_used) != 4:
            return False
        if Counter(nums_used) != Counter(self.nums):
            return False
        return self.evaluate_expression(expression)