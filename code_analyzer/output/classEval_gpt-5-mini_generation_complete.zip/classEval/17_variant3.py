from datetime import datetime, timedelta

class CalendarUtil:
    """
    Calendar implemented with a mapping from date -> list of events for fast day queries.
    """

    def __init__(self):
        self.events = []  # keep full list for compatibility
        self.by_date = {}  # date -> list of events for that date (events may span midnight)

    def _date_key(self, dt):
        if isinstance(dt, datetime):
            return dt.date()
        return dt

    def _index_event(self, ev):
        # index event into by_date for each date it touches (at most 2 days for typical events)
        start = ev.get('start_time') or ev.get('date')
        end = ev.get('end_time') or start
        if start is None or end is None:
            return
        cur = start.date()
        last = (end - timedelta(seconds=1)).date()
        d = cur
        while d <= last:
            self.by_date.setdefault(d, []).append(ev)
            d = d + timedelta(days=1)

    def add_event(self, event):
        ev = event.copy()
        if 'start_time' not in ev or ev['start_time'] is None:
            ev['start_time'] = ev.get('date')
        if 'end_time' not in ev or ev['end_time'] is None:
            st = ev.get('start_time')
            ev['end_time'] = st + timedelta(hours=1) if isinstance(st, datetime) else st
        self.events.append(ev)
        self._index_event(ev)

    def remove_event(self, event):
        # remove from events list
        for i, e in enumerate(self.events):
            match = True
            for k, v in event.items():
                if k not in e or e[k] != v:
                    match = False
                    break
            if match:
                ev = self.events.pop(i)
                # remove from by_date
                start = ev.get('start_time') or ev.get('date')
                end = ev.get('end_time') or start
                if start and end:
                    cur = start.date()
                    last = (end - timedelta(seconds=1)).date()
                    d = cur
                    while d <= last:
                        lst = self.by_date.get(d, [])
                        try:
                            lst.remove(ev)
                        except ValueError:
                            pass
                        if not lst:
                            self.by_date.pop(d, None)
                        d = d + timedelta(days=1)
                return

    def get_events(self, date):
        key = self._date_key(date)
        return list(self.by_date.get(key, []))

    def is_available(self, start_time, end_time):
        # check events on any date overlapping the interval's dates
        start_date = start_time.date()
        end_date = (end_time - timedelta(seconds=1)).date()
        d = start_date
        while d <= end_date:
            for e in self.by_date.get(d, []):
                evs = e.get('start_time') or e.get('date')
                eve = e.get('end_time') or evs
                if evs is None or eve is None:
                    continue
                if not (end_time <= evs or start_time >= eve):
                    return False
            d = d + timedelta(days=1)
        return True

    def get_available_slots(self, date):
        key = self._date_key(date)
        day_start = datetime(key.year, key.month, key.day)
        day_end = day_start + timedelta(days=1)
        evs = []
        for e in self.by_date.get(key, []):
            s = e.get('start_time') or e.get('date')
            en = e.get('end_time') or s
            if s is None or en is None:
                continue
            if en <= day_start or s >= day_end:
                continue
            evs.append((max(s, day_start), min(en, day_end)))
        evs.sort(key=lambda x: x[0])
        merged = []
        for s, e in evs:
            if not merged or s > merged[-1][1]:
                merged.append([s, e])
            else:
                if e > merged[-1][1]:
                    merged[-1][1] = e
        free = []
        cur = day_start
        for s, e in merged:
            if cur < s:
                free.append((cur, s))
            cur = max(cur, e)
        if cur < day_end:
            free.append((cur, day_end))
        return free

    def get_upcoming_events(self, num_events):
        now = datetime.now()
        future = [e for e in self.events if (e.get('start_time') or e.get('date')) and (e.get('start_time') or e.get('date')) >= now]
        future.sort(key=lambda ev: (ev.get('start_time') or ev.get('date')))
        return future[:num_events]