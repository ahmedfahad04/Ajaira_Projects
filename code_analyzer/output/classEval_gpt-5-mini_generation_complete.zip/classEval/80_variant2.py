class SQLQueryBuilder:
    """
    This class provides to build SQL queries, including SELECT, INSERT, UPDATE, and DELETE statements. 
    """

    @staticmethod
    def _format_value(v):
        if v is None:
            return "NULL"
        if isinstance(v, (list, tuple, set)):
            inner = ", ".join(SQLQueryBuilder._format_value(x) for x in v)
            return f"({inner})"
        s = str(v).replace("'", "''")
        return f"'{s}'"

    @staticmethod
    def _where_clause(where):
        if not where:
            return ""
        parts = []
        for k, v in where.items():
            if isinstance(v, (list, tuple, set)):
                parts.append(f"{k} IN {SQLQueryBuilder._format_value(v)}")
            else:
                parts.append(f"{k}={SQLQueryBuilder._format_value(v)}")
        return " WHERE " + " AND ".join(parts)

    @staticmethod
    def select(table, columns='*', where=None):
        if isinstance(columns, (list, tuple)):
            cols = ", ".join(columns) if columns else "*"
        else:
            cols = columns or "*"
        return f"SELECT {cols} FROM {table}{SQLQueryBuilder._where_clause(where)}"

    @staticmethod
    def insert(table, data):
        keys = list(data.keys())
        vals = [SQLQueryBuilder._format_value(data[k]) for k in keys]
        return f"INSERT INTO {table} ({', '.join(keys)}) VALUES ({', '.join(vals)})"

    @staticmethod
    def delete(table, where=None):
        return f"DELETE FROM {table}{SQLQueryBuilder._where_clause(where)}"

    @staticmethod
    def update(table, data, where=None):
        parts = [f"{k}={SQLQueryBuilder._format_value(v)}" for k, v in data.items()]
        return f"UPDATE {table} SET {', '.join(parts)}{SQLQueryBuilder._where_clause(where)}"