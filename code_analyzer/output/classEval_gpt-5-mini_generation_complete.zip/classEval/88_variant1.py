from math import pi, fabs

class TriCalculator:
    """
    The class allows to calculate trigonometric values, including cosine, sine, and tangent, using Taylor series approximations.
    """
    def __init__(self):
        pass

    def factorial(self, a):
        if a < 0:
            raise ValueError("factorial not defined for negative values")
        res = 1
        i = 2
        while i <= a:
            res *= i
            i += 1
        return res

    def _to_rad(self, x):
        # convert degrees to radians and reduce to [-pi, pi]
        r = (x % 360) * pi / 180.0
        if r > pi:
            r -= 2 * pi
        return r

    def taylor(self, x, n):
        rad = self._to_rad(x)
        total = 0.0
        for k in range(n):
            num = (-1) ** k * (rad ** (2 * k))
            den = self.factorial(2 * k)
            total += num / den
        return total

    def cos(self, x):
        # use a reasonably large number of terms for accuracy
        return self.taylor(x, 15)

    def sin(self, x):
        # sine Taylor series: sum_{k=0}^{inf} (-1)^k x^{2k+1} / (2k+1)!
        rad = self._to_rad(x)
        total = 0.0
        for k in range(15):
            num = (-1) ** k * (rad ** (2 * k + 1))
            den = self.factorial(2 * k + 1)
            total += num / den
        return total

    def tan(self, x):
        c = self.cos(x)
        if fabs(c) < 1e-15:
            raise ZeroDivisionError("tan undefined for this angle (cos is zero)")
        return self.sin(x) / c