import re

class BinaryDataProcessor:
    """
    This is a class used to process binary data, which includes functions such as clearing non 0 or 1 characters, counting binary string information, and converting to corresponding strings based on different encoding methods.
    """

    def __init__(self, binary_string):
        """
        Initialize the class with a binary string and clean it by removing all non 0 or 1 characters.
        """
        self.binary_string = binary_string if binary_string is not None else ""
        self.clean_non_binary_chars()

    def clean_non_binary_chars(self):
        """
        Clean the binary string by removing all non 0 or 1 characters.
        """
        # Remove any character that's not '0' or '1'
        self.binary_string = re.sub(r'[^01]', '', self.binary_string)

    def calculate_binary_info(self):
        """
        Calculate the binary string information, including the percentage of 0 and 1, and the total length of the binary string.
        """
        s = self.binary_string or ""
        length = len(s)
        if length == 0:
            return {'Zeroes': 0.0, 'Ones': 0.0, 'Bit length': 0}
        zeros = s.count('0')
        ones = length - zeros
        return {
            'Zeroes': round(zeros / length, 3),
            'Ones': round(ones / length, 3),
            'Bit length': length
        }

    def _bytes_from_bits(self):
        s = self.binary_string
        # group into 8-bit chunks, ignore incomplete trailing bits
        out = bytearray()
        for i in range(0, len(s) // 8 * 8, 8):
            byte = int(s[i:i+8], 2)
            out.append(byte)
        return bytes(out)

    def convert_to_ascii(self):
        """
        Convert the binary string to ascii string.
        """
        b = self._bytes_from_bits()
        try:
            return b.decode('ascii', errors='ignore')
        except Exception:
            # fallback manual conversion
            return ''.join(chr(c) for c in b if 32 <= c < 127)

    def convert_to_utf8(self):
        """
        Convert the binary string to utf-8 string.
        """
        b = self._bytes_from_bits()
        # decode with utf-8, replace invalid sequences
        return b.decode('utf-8', errors='replace')