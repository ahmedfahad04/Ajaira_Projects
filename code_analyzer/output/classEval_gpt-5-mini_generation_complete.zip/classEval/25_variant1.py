import json
import os

class CookiesUtil:
    """
    This is a class as utility for managing and manipulating Cookies, including methods for retrieving, saving, and setting Cookies data.
    """

    def __init__(self, cookies_file):
        """
        Initializes the CookiesUtil with the specified cookies file.
        :param cookies_file: The cookies file to use, str.
        """
        self.cookies_file = cookies_file
        self.cookies = None

    def get_cookies(self, reponse):
        """
        Gets the cookies from the specified response,and save it to cookies_file.
        """
        if not isinstance(reponse, dict):
            raise TypeError("reponse must be a dict")
        cookies = reponse.get('cookies')
        if cookies is None:
            self.cookies = {}
        elif isinstance(cookies, dict):
            self.cookies = cookies.copy()
        else:
            raise TypeError("response['cookies'] must be a dict if present")
        self._save_cookies()
        return self.cookies

    def load_cookies(self):
        """
        Loads the cookies from the cookies_file to the cookies data.
        :return: The cookies data, dict.
        """
        if not os.path.exists(self.cookies_file):
            self.cookies = {}
            return self.cookies
        try:
            with open(self.cookies_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, dict):
                    self.cookies = data
                else:
                    self.cookies = {}
        except (json.JSONDecodeError, IOError):
            self.cookies = {}
        return self.cookies

    def _save_cookies(self):
        """
        Saves the cookies to the cookies_file, and returns True if successful, False otherwise.
        """
        try:
            to_write = self.cookies if isinstance(self.cookies, dict) else {}
            with open(self.cookies_file, 'w', encoding='utf-8') as f:
                json.dump(to_write, f)
            return True
        except Exception:
            return False