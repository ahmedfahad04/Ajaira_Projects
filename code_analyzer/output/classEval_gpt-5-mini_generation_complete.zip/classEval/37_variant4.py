import itertools
class EncryptionUtils:
    """
    This is a class that provides methods for encryption, including the Caesar cipher, Vigenere cipher, and Rail Fence cipher.
    """

    def __init__(self, key):
        self.key = key or ""

    def caesar_cipher(self, plaintext, shift):
        if shift is None:
            return plaintext
        shift = shift % 26
        out = []
        for c in plaintext:
            if 'a' <= c <= 'z':
                out.append(chr((ord(c) - ord('a') + shift) % 26 + ord('a')))
            elif 'A' <= c <= 'Z':
                out.append(chr((ord(c) - ord('A') + shift) % 26 + ord('A')))
            else:
                out.append(c)
        return ''.join(out)

    def vigenere_cipher(self, plaintext):
        key_letters = [k for k in self.key if k.isalpha()]
        if not key_letters:
            return plaintext
        shifts = [ord(k.lower()) - ord('a') for k in key_letters]
        out = []
        shift_iter = itertools.cycle(shifts)
        for ch in plaintext:
            if ch.isalpha():
                s = next(shift_iter)
                if ch.islower():
                    out.append(chr((ord(ch) - ord('a') + s) % 26 + ord('a')))
                else:
                    out.append(chr((ord(ch) - ord('A') + s) % 26 + ord('A')))
            else:
                out.append(ch)
        return ''.join(out)

    def rail_fence_cipher(self,plain_text, rails):
        if rails is None or rails <= 1:
            return plain_text
        # pattern length
        n = len(plain_text)
        fence = ['' for _ in range(rails)]
        pos = 0
        down = True
        for c in plain_text:
            fence[pos] += c
            if down:
                pos += 1
            else:
                pos -= 1
            if pos == rails:
                pos = rails - 2
                down = False
            if pos < 0:
                pos = 1
                down = True
        return ''.join(fence)