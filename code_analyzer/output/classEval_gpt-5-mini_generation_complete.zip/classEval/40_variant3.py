class FitnessTracker:
    """
    This is a class as fitness tracker that implements to calculate BMI (Body Mass Index) and calorie intake based on the user's height, weight, age, and sex.
    """

    def __init__(self, height, weight, age, sex) -> None:
        self.height = float(height)
        self.weight = float(weight)
        self.age = int(age)
        self.sex = str(sex).strip().lower()
        # keep as list of dicts like skeleton but create a quick lookup
        self.BMI_std = [
            {"male": [20, 25]},
            {"female": [19, 24]}
        ]
        self._std_lookup = {}
        for d in self.BMI_std:
            for k, v in d.items():
                self._std_lookup[k] = tuple(v)

    def _get_std_bounds(self):
        if self.sex in self._std_lookup:
            return self._std_lookup[self.sex]
        # fallback: average of male and female bounds
        m = self._std_lookup.get("male", (20, 25))
        f = self._std_lookup.get("female", (19, 24))
        return ((m[0] + f[0]) / 2.0, (m[1] + f[1]) / 2.0)

    def get_BMI(self):
        if self.height == 0:
            raise ValueError("Height must not be zero.")
        bmi = self.weight / (self.height ** 2)
        return bmi

    def condition_judge(self):
        bmi = self.get_BMI()
        low, high = self._get_std_bounds()
        if bmi < low:
            return -1
        if bmi > high:
            return 1
        return 0

    def calculate_calorie_intake(self):
        # BMR as specified:
        if self.sex == "male":
            bmr = 10 * self.weight + 6.25 * self.height - 5 * self.age + 5
        elif self.sex == "female":
            bmr = 10 * self.weight + 6.25 * self.height - 5 * self.age - 161
        else:
            # if unknown sex, compute both and take mean
            bmr_m = 10 * self.weight + 6.25 * self.height - 5 * self.age + 5
            bmr_f = 10 * self.weight + 6.25 * self.height - 5 * self.age - 161
            bmr = (bmr_m + bmr_f) / 2.0

        condition = self.condition_judge()
        if condition == 1:
            factor = 1.2
        elif condition == -1:
            factor = 1.6
        else:
            factor = 1.4
        return bmr * factor