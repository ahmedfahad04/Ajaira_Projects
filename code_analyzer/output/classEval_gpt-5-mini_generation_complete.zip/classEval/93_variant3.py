import numpy as np
from gensim import matutils
from numpy import dot, array

class VectorUtil:
    """
    The class provides vector operations, including calculating similarity, cosine similarities, average similarity, and IDF weights.
    """

    @staticmethod
    def similarity(vector_1, vector_2):
        a = np.asarray(vector_1, dtype=float)
        b = np.asarray(vector_2, dtype=float)
        # use einsum for dot and manual norms
        denom = np.sqrt(np.einsum('i,i->', a, a)) * np.sqrt(np.einsum('i,i->', b, b))
        if denom == 0:
            return 0.0
        return float(np.einsum('i,i->', a, b) / denom)

    @staticmethod
    def cosine_similarities(vector_1, vectors_all):
        a = np.asarray(vector_1, dtype=float)
        if len(vectors_all) == 0:
            return np.array([], dtype=float)
        mat = np.vstack([np.asarray(v, dtype=float) for v in vectors_all])
        dots = np.einsum('ij,j->i', mat, a)
        norms_mat = np.sqrt(np.einsum('ij,ij->i', mat, mat))
        norm_a = np.sqrt(np.einsum('i,i->', a, a))
        denom = norms_mat * norm_a
        # where denom zero set 0
        res = np.zeros_like(dots, dtype=float)
        mask = denom != 0
        res[mask] = dots[mask] / denom[mask]
        return res

    @staticmethod
    def n_similarity(vector_list_1, vector_list_2):
        if not vector_list_1 or not vector_list_2:
            return 0.0
        arr1 = np.array([np.asarray(v, dtype=float) for v in vector_list_1])
        arr2 = np.array([np.asarray(v, dtype=float) for v in vector_list_2])
        mean1 = arr1.mean(axis=0)
        mean2 = arr2.mean(axis=0)
        return VectorUtil.similarity(mean1, mean2)

    @staticmethod
    def compute_idf_weight_dict(total_num, number_dict):
        t = float(total_num)
        return {k: float(np.log((t + 1.0) / (float(v) + 1.0))) for k, v in number_dict.items()}