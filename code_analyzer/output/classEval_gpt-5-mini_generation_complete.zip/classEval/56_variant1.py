class MetricsCalculator:
    """
    The class calculates precision, recall, F1 score, and accuracy based on predicted and true labels.
    """

    def __init__(self):
        """
        Initialize the number of all four samples to 0
        """
        self.true_positives = 0
        self.false_positives = 0
        self.false_negatives = 0
        self.true_negatives = 0

    def update(self, predicted_labels, true_labels):
        """
        Update the number of all four samples(true_positives, false_positives, false_negatives, true_negatives)
        """
        for p, t in zip(predicted_labels, true_labels):
            if p == 1 and t == 1:
                self.true_positives += 1
            elif p == 1 and t != 1:
                self.false_positives += 1
            elif p != 1 and t == 1:
                self.false_negatives += 1
            else:
                self.true_negatives += 1

    def _counts_from_lists(self, predicted_labels, true_labels):
        tp = fp = fn = tn = 0
        for p, t in zip(predicted_labels, true_labels):
            if p == 1 and t == 1:
                tp += 1
            elif p == 1 and t != 1:
                fp += 1
            elif p != 1 and t == 1:
                fn += 1
            else:
                tn += 1
        return tp, fp, fn, tn

    def precision(self, predicted_labels, true_labels):
        """
        Calculate precision
        """
        tp, fp, _, _ = self._counts_from_lists(predicted_labels, true_labels)
        denom = tp + fp
        return float(tp) / denom if denom != 0 else 0.0

    def recall(self, predicted_labels, true_labels):
        """
        Calculate recall
        """
        tp, _, fn, _ = self._counts_from_lists(predicted_labels, true_labels)
        denom = tp + fn
        return float(tp) / denom if denom != 0 else 0.0

    def f1_score(self, predicted_labels, true_labels):
        """
        Calculate f1 score
        """
        p = self.precision(predicted_labels, true_labels)
        r = self.recall(predicted_labels, true_labels)
        denom = p + r
        return 2.0 * p * r / denom if denom != 0 else 0.0

    def accuracy(self, predicted_labels, true_labels):
        """
        Calculate accuracy
        """
        tp, fp, fn, tn = self._counts_from_lists(predicted_labels, true_labels)
        total = tp + fp + fn + tn
        return float(tp + tn) / total if total != 0 else 0.0

# Classification response:
# helper function extraction;variable renaming;tuple unpacking;temporary variable;conditional expression;flattened conditional;state variable;type conversion;behavior change