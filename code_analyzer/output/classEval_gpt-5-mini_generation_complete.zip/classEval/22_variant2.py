from collections import Counter, defaultdict

class ClassRegistrationSystem:
    """
    This is a class as a class registration system, allowing to register students, register them for classes, retrieve students by major, get a list of all majors, and determine the most popular class within a specific major.
    """

    def __init__(self):
        self.students = []
        self.students_registration_classes = {}

    def register_student(self, student):
        if not isinstance(student, dict) or 'name' not in student or 'major' not in student:
            raise ValueError("student must be a dict with 'name' and 'major'")
        name = student['name']
        for s in self.students:
            if s.get('name') == name:
                return 0
        self.students.append({'name': name, 'major': student['major']})
        return 1

    def register_class(self, student_name, class_name):
        # keep insertion order and avoid duplicates
        if student_name not in self.students_registration_classes:
            self.students_registration_classes[student_name] = []
        lst = self.students_registration_classes[student_name]
        if class_name not in lst:
            lst.append(class_name)
        return list(lst)

    def get_students_by_major(self, major):
        return [s['name'] for s in self.students if s.get('major') == major]

    def get_all_major(self):
        majors = []
        seen = set()
        for s in self.students:
            m = s.get('major')
            if m not in seen:
                seen.add(m)
                majors.append(m)
        return majors

    def get_most_popular_class_in_major(self, major):
        # Count classes among students of the major
        students_in_major = [s['name'] for s in self.students if s.get('major') == major]
        if not students_in_major:
            return None
        counter = Counter()
        # To break ties deterministically, we'll track the first time a count reaches the current max
        first_reach = {}
        max_count = 0
        best_class = None
        seq = 0
        for student in students_in_major:
            for cls in self.students_registration_classes.get(student, []):
                seq += 1
                counter[cls] += 1
                if counter[cls] > max_count:
                    max_count = counter[cls]
                    best_class = cls
                    first_reach[cls] = seq
                elif counter[cls] == max_count and best_class is None:
                    best_class = cls
                    first_reach[cls] = seq
        return best_class