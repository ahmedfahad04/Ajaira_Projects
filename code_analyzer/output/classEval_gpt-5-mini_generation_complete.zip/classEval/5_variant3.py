from itertools import groupby

class AutomaticGuitarSimulator:
    def __init__(self, text) -> None:
        self.play_text = text or ""

    def interpret(self, display=False):
        s = self.play_text or ""
        if s.strip() == "":
            return []
        parts = []
        # group contiguous digit and non-digit runs
        runs = [''.join(g) for k, g in groupby(s, key=lambda ch: ch.isdigit())]
        i = 0
        # ensure runs alternate; remove runs that are pure whitespace
        clean_runs = []
        for r in runs:
            if r.strip() == "":
                continue
            clean_runs.append(r)
        runs = clean_runs
        # If string started with digits, start index at 0 else 0. We'll pair non-digit then digit.
        idx = 0
        while idx < len(runs):
            if not runs[idx][0].isdigit():
                chord = runs[idx].replace(" ", "")
                tune = ""
                if idx + 1 < len(runs) and runs[idx + 1] and runs[idx + 1][0].isdigit():
                    tune = ''.join(ch for ch in runs[idx + 1] if ch.isdigit())
                if chord and tune:
                    entry = {"Chord": chord, "Tune": tune}
                    parts.append(entry)
                    if display:
                        self.display(chord, tune)
                idx += 2
            else:
                idx += 1
        return parts

    def display(self, key, value):
        out = "Normal Guitar Playing -- Chord: %s, Play Tune: %s" % (key, value)
        print(out)
        return out