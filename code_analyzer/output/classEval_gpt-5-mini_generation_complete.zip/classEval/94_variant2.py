from dataclasses import dataclass

class VendingMachine:
    """
    This is a class to simulate a vending machine, including adding products, inserting coins, purchasing products, viewing balance, replenishing product inventory, and displaying product information.
    """

    @dataclass
    class Product:
        price: float
        quantity: int

    def __init__(self):
        """
        Initializes the vending machine's inventory and balance.
        """
        self.inventory = {}
        self.balance = 0.0

    def add_item(self, item_name, price, quantity):
        if quantity <= 0 or price < 0:
            return
        self.inventory[item_name] = VendingMachine.Product(float(price), int(quantity))

    def insert_coin(self, amount):
        amt = float(amount)
        if amt <= 0:
            return self.balance
        self.balance = round(self.balance + amt, 2)
        return self.balance

    def purchase_item(self, item_name):
        prod = self.inventory.get(item_name)
        if prod is None or prod.quantity <= 0:
            return False
        if self.balance < prod.price:
            return False
        prod.quantity -= 1
        self.balance = round(self.balance - prod.price, 2)
        return self.balance

    def restock_item(self, item_name, quantity):
        prod = self.inventory.get(item_name)
        if prod is None:
            return False
        if quantity > 0:
            prod.quantity += int(quantity)
        return True

    def display_items(self):
        if not self.inventory:
            return False
        lines = []
        for name, prod in self.inventory.items():
            lines.append(f"{name} - ${prod.price:.2f} [{prod.quantity}]")
        return "\n".join(lines)