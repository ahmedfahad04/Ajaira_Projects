from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT


class DocFileHandler:
    """
    This is a class that handles Word documents and provides functionalities for reading, writing, and modifying the content of Word documents.
    """

    def __init__(self, file_path):
        """
        Initializes the DocFileHandler object with the specified file path.
        :param file_path: str, the path to the Word document file.
        """
        self.file_path = file_path

    def read_text(self):
        """
        Reads the content of a Word document and returns it as a string.
        :return: str, the content of the Word document.
        """
        try:
            doc = Document(self.file_path)
        except Exception:
            return ""
        parts = []
        for p in doc.paragraphs:
            if p.text:
                parts.append(p.text)
        # also read simple table contents
        for table in doc.tables:
            rows = []
            for row in table.rows:
                cells = [cell.text for cell in row.cells]
                rows.append("\t".join(cells))
            if rows:
                parts.append("\n".join(rows))
        return "\n".join(parts)

    def write_text(self, content, font_size=12, alignment='left'):
        """
        Writes the specified content to a Word document.
        :param content: str, the text content to write.
        :param font_size: int, optional, the font size of the text (default is 12).
        :param alignment: str, optional, the alignment of the text ('left', 'center', or 'right'; default is 'left').
        :return: bool, True if the write operation is successful, False otherwise.
        """
        try:
            doc = Document()
            align_val = self._get_alignment_value(alignment)
            lines = content.splitlines() if isinstance(content, str) else [str(content)]
            for line in lines:
                p = doc.add_paragraph()
                p.alignment = align_val
                run = p.add_run(line)
                run.font.size = Pt(font_size)
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def add_heading(self, heading, level=1):
        """
        Adds a heading to the Word document.
        :param heading: str, the text of the heading.
        :param level: int, optional, the level of the heading (1, 2, 3, etc.; default is 1).
        :return: bool, True if the heading is successfully added, False otherwise.
        """
        try:
            doc = Document(self.file_path) if self._exists_doc() else Document()
            doc.add_heading(heading, level=level)
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def add_table(self, data):
        """
        Adds a table to the Word document with the specified data.
        :param data: list of lists, the data to populate the table.
        :return: bool, True if the table is successfully added, False otherwise.
        """
        try:
            if not data or not isinstance(data, (list, tuple)):
                return False
            rows = len(data)
            cols = max((len(row) for row in data if isinstance(row, (list, tuple))), default=0)
            if cols == 0:
                return False
            doc = Document(self.file_path) if self._exists_doc() else Document()
            table = doc.add_table(rows=rows, cols=cols)
            table.style = 'Table Grid'
            for i, row in enumerate(data):
                for j in range(cols):
                    text = ""
                    if isinstance(row, (list, tuple)) and j < len(row):
                        text = "" if row[j] is None else str(row[j])
                    cell = table.cell(i, j)
                    cell.text = text
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def _get_alignment_value(self, alignment):
        """
        Returns the alignment value corresponding to the given alignment string.
        :param alignment: str, the alignment string ('left', 'center', or 'right').
        :return: int, the alignment value.
        """
        if isinstance(alignment, str):
            alignment = alignment.strip().lower()
            if alignment == 'center' or alignment == 'centre':
                return WD_PARAGRAPH_ALIGNMENT.CENTER
            if alignment == 'right':
                return WD_PARAGRAPH_ALIGNMENT.RIGHT
        return WD_PARAGRAPH_ALIGNMENT.LEFT

    def _exists_doc(self):
        try:
            Document(self.file_path)
            return True
        except Exception:
            return False