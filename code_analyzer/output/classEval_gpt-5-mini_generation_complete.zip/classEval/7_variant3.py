class BalancedBrackets:
    """
    This is a class that checks for bracket matching
    """

    def __init__(self, expr):
        """
        Initializes the class with an expression.
        :param expr: The expression to check for balanced brackets,str.
        """
        self.stack = []
        self.left_brackets = ["(", "{", "["]
        self.right_brackets = [")", "}", "]"]
        self.expr = expr

    def clear_expr(self):
        """
        Clears the expression of all characters that are not brackets.
        """
        s = self.expr or ""
        res_chars = []
        for ch in s:
            if ch in self.left_brackets or ch in self.right_brackets:
                res_chars.append(ch)
        self.expr = ''.join(res_chars)

    def check_balanced_brackets(self):
        """
        Checks if the expression has balanced brackets.
        Uses iterative elimination of matching pairs until stable.
        """
        self.clear_expr()
        s = self.expr
        prev = None
        while prev != s:
            prev = s
            s = s.replace("()", "").replace("[]", "").replace("{}", "")
        return s == ""