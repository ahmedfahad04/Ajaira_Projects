import math
from typing import List

class CombinationCalculator:
    """
    This is a class that provides methods to calculate the number of combinations for a specific count, calculate all possible combinations, and generate combinations with a specified number of elements.
    """

    def __init__(self, datas: List[str]):
        """
        Initialize the calculator with a list of data.
        """
        self.datas = datas

    @staticmethod
    def count(n: int, m: int) -> int:
        """
        Calculate the number of combinations using math.comb with validation.
        """
        if n < 0 or m < 0 or m > n:
            return 0
        return math.comb(n, m)

    @staticmethod
    def count_all(n: int) -> int:
        """
        Calculate the number of all possible combinations quickly as 2^n - 1 with overflow check.
        """
        if n < 0:
            return 0
        limit = 2**63 - 1
        total = (1 << n) - 1
        if total > limit:
            return float("inf")
        return total

    def select(self, m: int) -> List[List[str]]:
        """
        Generate combinations using a recursive generator and collect results.
        """
        n = len(self.datas)
        if m <= 0 or m > n:
            return []
        return list(self._gen_select(0, [], m))

    def _gen_select(self, start: int, so_far: List[str], remaining: int):
        """
        Generator helper that yields combinations of length 'remaining' starting from 'start'.
        """
        n = len(self.datas)
        if remaining == 0:
            yield so_far.copy()
            return
        # prune if not enough elements remain
        max_start = n - remaining
        i = start
        while i <= max_start:
            so_far.append(self.datas[i])
            yield from self._gen_select(i + 1, so_far, remaining - 1)
            so_far.pop()
            i += 1

    def select_all(self) -> List[List[str]]:
        """
        Generate all combinations sizes 1..n using the select method.
        """
        all_res: List[List[str]] = []
        n = len(self.datas)
        for k in range(1, n + 1):
            all_res.extend(self.select(k))
        return all_res

    def _select(self, dataIndex: int, resultList: List[str], resultIndex: int, result: List[List[str]]):
        """
        Recursive implementation that fills provided result list, matching the signature and behavior.
        """
        n = len(self.datas)
        r = len(resultList)
        if resultIndex == r:
            result.append(resultList.copy())
            return
        max_start = n - (r - resultIndex)
        i = dataIndex
        while i <= max_start:
            resultList[resultIndex] = self.datas[i]
            self._select(i + 1, resultList, resultIndex + 1, result)
            i += 1