import re
import string

class LongestWord:
    """
    This is a class allows to add words to a list and find the longest word in a given sentence by comparing the words with the ones in the word list.
    """

    def __init__(self):
        """
        Initialize a list of word.
        """
        self.word_list = []
        self._word_set = set()

    def add_word(self, word):
        """
        append the input word into self.word_list
        :param word: str, input word
        """
        self.word_list.append(word)
        self._word_set.add(word)

    def find_longest_word(self, sentence):
        """
        Remove punctuation marks and split a sentence into a list of word. Find the longest splited word that is in the self.word_list.
        Words are strictly case sensitive.
        :param sentence: a sentence str
        :return str: longest splited word that is in the self.word_list. return '' if self.word_list is empty.
        """
        if not self.word_list:
            return ''
        cleaned = re.sub('[' + re.escape(string.punctuation) + ']', ' ', sentence)
        tokens = cleaned.split()
        # choose the longest; in tie prefer earlier token -> use (len, -index) as key for max
        candidates = []
        for idx, tok in enumerate(tokens):
            if tok in self._word_set:
                candidates.append((tok, idx))
        if not candidates:
            return ''
        best_tok, best_idx = max(candidates, key=lambda it: (len(it[0]), -it[1]))
        return best_tok