class BookManagement:
    """
    This is a class as managing books system, which supports to add and remove books from the inventory dict, view the inventory, and check the quantity of a specific book.
    """

    def __init__(self):
        """
        Initialize the inventory of Book Manager.
        """
        self.inventory = {}

    def add_book(self, title, quantity=1):
        """
        Add one or several books to inventory which is sorted by book title.
        """
        if not isinstance(title, str) or not isinstance(quantity, int) or quantity <= 0:
            return False
        self.inventory[title] = self.inventory.get(title, 0) + quantity
        # keep inventory sorted by title
        self.inventory = dict(sorted(self.inventory.items(), key=lambda x: x[0]))
        return True

    def remove_book(self, title, quantity):
        """
        Remove one or several books from inventory which is sorted by book title.
        Return False on invalid input.
        """
        if not isinstance(title, str) or not isinstance(quantity, int) or quantity <= 0:
            return False
        if title not in self.inventory:
            return False
        if quantity > self.inventory[title]:
            return False
        remaining = self.inventory[title] - quantity
        if remaining > 0:
            self.inventory[title] = remaining
        else:
            del self.inventory[title]
        self.inventory = dict(sorted(self.inventory.items(), key=lambda x: x[0]))
        return True

    def view_inventory(self):
        """
        Get the inventory of the Book Management.
        """
        # Return a copy so external modifications won't affect internal state
        return dict(self.inventory)

    def view_book_quantity(self, title):
        """
        Get the quantity of a book.
        """
        return int(self.inventory.get(title, 0))