import math

class DataStatistics4:
    """
    This is a class that performs advanced mathematical calculations and statistics, including correlation coefficient, skewness, kurtosis, and probability density function (PDF) for a normal distribution.
    """

    @staticmethod
    def correlation_coefficient(data1, data2):
        if not data1 or not data2:
            raise ValueError("Input lists must be non-empty")
        if len(data1) != len(data2):
            raise ValueError("Input lists must have the same length")
        n = len(data1)
        mean1 = sum(data1) / n
        mean2 = sum(data2) / n
        num = 0.0
        sum_sq1 = 0.0
        sum_sq2 = 0.0
        for x, y in zip(data1, data2):
            dx = x - mean1
            dy = y - mean2
            num += dx * dy
            sum_sq1 += dx * dx
            sum_sq2 += dy * dy
        denom = math.sqrt(sum_sq1 * sum_sq2)
        if denom == 0:
            return 0.0
        return num / denom

    @staticmethod
    def skewness(data):
        n = len(data)
        if n == 0:
            raise ValueError("Input list must be non-empty")
        mean = sum(data) / n
        m2 = 0.0
        m3 = 0.0
        for x in data:
            d = x - mean
            m2 += d * d
            m3 += d * d * d
        # population central moments
        m2 /= n
        m3 /= n
        if m2 == 0:
            return 0.0
        g1 = m3 / (m2 ** 1.5)
        # Fisher-Pearson adjusted (bias corrected) when possible
        if n > 2:
            factor = math.sqrt(n * (n - 1)) / (n - 2)
            return factor * g1
        return g1

    @staticmethod
    def kurtosis(data):
        n = len(data)
        if n == 0:
            raise ValueError("Input list must be non-empty")
        mean = sum(data) / n
        m2 = 0.0
        m4 = 0.0
        for x in data:
            d = x - mean
            d2 = d * d
            m2 += d2
            m4 += d2 * d2
        m2 /= n
        m4 /= n
        if m2 == 0:
            return -3.0  # define as minimum (all identical -> excess kurtosis of a Dirac is -3 in this population moment sense)
        return m4 / (m2 * m2) - 3.0  # excess kurtosis (Fisher)

    @staticmethod
    def pdf(data, mu, sigma):
        if sigma <= 0:
            raise ValueError("sigma must be positive")
        coef = 1.0 / (sigma * math.sqrt(2.0 * math.pi))
        denom = 2.0 * sigma * sigma
        result = []
        for x in data:
            e = math.exp(-((x - mu) ** 2) / denom)
            result.append(coef * e)
        return result