import re

class IPAddress:
    """
    This is a class to process IP Address, including validating, getting the octets and obtaining the binary representation of a valid IP address.
    """
    _RE = re.compile(r'^(?:25[0-5]|2[0-4]\d|1?\d{1,2})(?:\.(?:25[0-5]|2[0-4]\d|1?\d{1,2})){3}$')

    def __init__(self, ip_address):
        self.ip_address = ip_address

    def is_valid(self):
        if not isinstance(self.ip_address, str):
            return False
        return bool(self._RE.fullmatch(self.ip_address))

    def get_octets(self):
        if not self.is_valid():
            return []
        return self.ip_address.split('.')

    def get_binary(self):
        if not self.is_valid():
            return ''
        parts = self.get_octets()
        return '.'.join(f"{int(p):08b}" for p in parts)