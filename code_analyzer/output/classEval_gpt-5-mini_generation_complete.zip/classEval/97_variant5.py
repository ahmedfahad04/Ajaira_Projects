import re

class Words2Numbers:
    """
    The class provides a text-to-number conversion utility, allowing conversion of written numbers (in words) to their numerical representation.
    """

    def __init__(self):
        self.numwords = {}
        self.units = [
            "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
            "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
            "sixteen", "seventeen", "eighteen", "nineteen",
        ]
        self.tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]
        self.scales = ["hundred", "thousand", "million", "billion", "trillion"]

        self.numwords["and"] = (1, 0)
        for i, w in enumerate(self.units):
            self.numwords[w] = (1, i)
        for i, w in enumerate(self.tens):
            if w:
                self.numwords[w] = (1, i * 10)
        for i, w in enumerate(self.scales):
            self.numwords[w] = (10 ** (i * 3 or 2), 0)

        self.ordinal_words = {'first': 1, 'second': 2, 'third': 3, 'fifth': 5, 'eighth': 8, 'ninth': 9, 'twelfth': 12}
        self.ordinal_endings = [('ieth', 'y'), ('th', '')]

    def _split(self, text):
        text = text.lower().strip()
        text = re.sub(r'[,]', ' ', text)
        return [tok for tok in re.split(r'\s+|-', text) if tok]

    def _parse_chunk(self, tokens):
        total = 0
        current = 0
        i = 0
        while i < len(tokens):
            tok = tokens[i]
            if tok == 'and':
                i += 1
                continue
            if tok in self.numwords:
                scale, inc = self.numwords[tok]
            else:
                conv = None
                if tok in self.ordinal_words:
                    conv = (1, self.ordinal_words[tok])
                else:
                    for end, rep in self.ordinal_endings:
                        if tok.endswith(end):
                            base = tok[:-len(end)] + rep
                            if base in self.numwords:
                                conv = self.numwords[base]
                                break
                if conv:
                    scale, inc = conv
                else:
                    raise ValueError("Invalid token: {}".format(tok))
            if scale > 1:
                if current == 0:
                    current = 1
                current *= scale
                if scale > 100:
                    total += current
                    current = 0
            else:
                current += inc
            i += 1
        return total + current

    def text2int(self, textnum):
        if not isinstance(textnum, str):
            raise ValueError("Input must be string")
        tokens = self._split(textnum)
        if not tokens:
            return "0"
        negative = False
        if tokens[0] in ('minus', 'negative'):
            negative = True
            tokens = tokens[1:]
        result = self._parse_chunk(tokens)
        if negative:
            result = -result
        return str(result)

    def is_valid_input(self, textnum):
        if not isinstance(textnum, str):
            return False
        if '-' in textnum:
            return False
        tokens = self._split(textnum)
        if not tokens:
            return False
        for tok in tokens:
            if tok in ('and', 'minus', 'negative'):
                continue
            if tok in self.numwords or tok in self.ordinal_words:
                continue
            valid = False
            for end, rep in self.ordinal_endings:
                if tok.endswith(end) and (tok[:-len(end)] + rep) in self.numwords:
                    valid = True
                    break
            if not valid:
                return False
        return True