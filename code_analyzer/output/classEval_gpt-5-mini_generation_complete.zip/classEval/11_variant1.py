class BitStatusUtil:
    """
    This is a utility class that provides methods for manipulating and checking status using bitwise operations.
    """

    @staticmethod
    def add(states, stat):
        BitStatusUtil.check([states, stat])
        # Use bitwise OR to add flags
        return states | stat

    @staticmethod
    def has(states, stat):
        BitStatusUtil.check([states, stat])
        # True if all bits in stat are present in states
        return (states & stat) == stat

    @staticmethod
    def remove(states, stat):
        BitStatusUtil.check([states, stat])
        # Clear bits in stat from states
        return states & (~stat)

    @staticmethod
    def check(args):
        if args is None:
            return
        for a in args:
            if not isinstance(a, int):
                raise ValueError(f"{a} not int")
            if a < 0:
                raise ValueError(f"{a} < 0")
            if a % 2 != 0:
                raise ValueError(f"{a} not even