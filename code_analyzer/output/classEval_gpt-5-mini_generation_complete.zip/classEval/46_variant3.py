class Interpolation:
    """
    This is a class that implements the Linear interpolation operation of one-dimensional and two-dimensional data
    """

    def __init__(self):
        pass

    @staticmethod
    def interpolate_1d(x, y, x_interp):
        if len(x) != len(y):
            raise ValueError("x and y must be same length")
        n = len(x)
        out = []
        for xv in x_interp:
            if n == 0:
                out.append(None)
                continue
            if n == 1:
                out.append(float(y[0]))
                continue
            if xv <= x[0]:
                x0, x1 = x[0], x[1]
                y0, y1 = y[0], y[1]
            elif xv >= x[-1]:
                x0, x1 = x[-2], x[-1]
                y0, y1 = y[-2], y[-1]
            else:
                i = 0
                while not (x[i] <= xv <= x[i+1]):
                    i += 1
                x0, x1 = x[i], x[i+1]
                y0, y1 = y[i], y[i+1]
            if x1 == x0:
                out.append(float(y0))
            else:
                t = (xv - x0) / (x1 - x0)
                out.append(float(y0 + t * (y1 - y0)))
        return out

    @staticmethod
    def interpolate_2d(x, y, z, x_interp, y_interp):
        if len(x) == 0 or len(y) == 0:
            return []
        if len(z) != len(x) or any(len(row) != len(y) for row in z):
            raise ValueError("z shape mismatch")
        results = []
        for xv, yv in zip(x_interp, y_interp):
            if len(x) == 1 and len(y) == 1:
                results.append(float(z[0][0]))
                continue
            if len(x) == 1:
                col = [row[0] for row in z]
                val = Interpolation.interpolate_1d(y, col, [yv])[0]
                results.append(float(val))
                continue
            if len(y) == 1:
                row_vals = [row[0] for row in z]
                val = Interpolation.interpolate_1d(x, row_vals, [xv])[0]
                results.append(float(val))
                continue
            if xv <= x[0]:
                ix0, ix1 = 0, 1
            elif xv >= x[-1]:
                ix0, ix1 = len(x)-2, len(x)-1
            else:
                ix0 = 0
                while not (x[ix0] <= xv <= x[ix0+1]):
                    ix0 += 1
                ix1 = ix0 + 1
            if yv <= y[0]:
                iy0, iy1 = 0, 1
            elif yv >= y[-1]:
                iy0, iy1 = len(y)-2, len(y)-1
            else:
                iy0 = 0
                while not (y[iy0] <= yv <= y[iy0+1]):
                    iy0 += 1
                iy1 = iy0 + 1
            x0, x1 = x[ix0], x[ix1]
            y0, y1 = y[iy0], y[iy1]
            z00 = z[ix0][iy0]
            z10 = z[ix1][iy0]
            z01 = z[ix0][iy1]
            z11 = z[ix1][iy1]
            if x1 == x0 and y1 == y0:
                results.append(float(z00))
                continue
            if x1 == x0:
                ty = (yv - y0) / (y1 - y0) if y1 != y0 else 0.0
                results.append(float(z00 + ty * (z01 - z00)))
                continue
            if y1 == y0:
                tx = (xv - x0) / (x1 - x0) if x1 != x0 else 0.0
                results.append(float(z00 + tx * (z10 - z00)))
                continue
            tx = (xv - x0) / (x1 - x0)
            ty = (yv - y0) / (y1 - y0)
            value = (z00 * (1 - tx) * (1 - ty) +
                     z10 * tx * (1 - ty) +
                     z01 * (1 - tx) * ty +
                     z11 * tx * ty)
            results.append(float(value))
        return results