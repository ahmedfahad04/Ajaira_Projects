from datetime import datetime
from collections import defaultdict
import copy

class Chat:
    """
    This is a chat class with the functions of adding users, removing users, sending messages, and obtaining messages.
    """

    def __init__(self):
        """
        Initialize the Chat with an attribute users, which is an empty dictionary.
        """
        self.users = dict()

    def add_user(self, username):
        if username in self.users:
            return False
        self.users[username] = []
        return True

    def remove_user(self, username):
        if username in self.users:
            # safely remove user and their messages
            del self.users[username]
            return True
        return False

    def send_message(self, sender, receiver, message):
        if sender not in self.users or receiver not in self.users:
            return False
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        record = {'sender': sender, 'receiver': receiver, 'message': message, 'timestamp': timestamp}
        # store messages under sender only
        self.users[sender].append(record)
        return True

    def get_messages(self, username):
        if username not in self.users:
            return []
        # return a deep copy to prevent external mutation
        return copy.deepcopy(self.users[username])