import threading

class HRManagementSystem:
    """
    This is a class as personnel management system that implements functions such as adding, deleting, querying, and updating employees
    """

    def __init__(self):
        """
        Initialize the HRManagementSystem withan attribute employees, which is an empty dictionary.
        """
        self.employees = {}
        self._lock = threading.Lock()

    def add_employee(self, employee_id, name, position, department, salary):
        """
        Add a new employee to the HRManagementSystem.
        """
        with self._lock:
            if employee_id in self.employees:
                return False
            # basic type normalization
            self.employees[employee_id] = {
                'name': str(name),
                'position': str(position),
                'department': str(department),
                'salary': int(salary)
            }
            return True

    def remove_employee(self, employee_id):
        """
        Remove an employee from the HRManagementSystem.
        """
        with self._lock:
            if employee_id in self.employees:
                del self.employees[employee_id]
                return True
            return False

    def update_employee(self, employee_id: int, employee_info: dict):
        """
        Update an employee's information in the HRManagementSystem.
        """
        with self._lock:
            if employee_id not in self.employees:
                return False
            entry = self.employees[employee_id]
            if 'name' in employee_info:
                entry['name'] = str(employee_info['name'])
            if 'position' in employee_info:
                entry['position'] = str(employee_info['position'])
            if 'department' in employee_info:
                entry['department'] = str(employee_info['department'])
            if 'salary' in employee_info:
                entry['salary'] = int(employee_info['salary'])
            self.employees[employee_id] = entry
            return True

    def get_employee(self, employee_id):
        """
        Get an employee's information from the HRManagementSystem.
        """
        with self._lock:
            info = self.employees.get(employee_id)
            if info is None:
                return False
            return dict(info)

    def list_employees(self):
        """
        List all employees' information in the HRManagementSystem.
        """
        with self._lock:
            result = {}
            for eid, info in self.employees.items():
                entry = {'employee_ID': eid}
                entry.update(info)
                result[eid] = dict(entry)
            return result