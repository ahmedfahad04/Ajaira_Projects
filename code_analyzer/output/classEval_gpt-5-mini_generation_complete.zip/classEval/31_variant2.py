import math
import statistics

class DataStatistics4:
    """
    This is a class that performs advanced mathematical calculations and statistics, including correlation coefficient, skewness, kurtosis, and probability density function (PDF) for a normal distribution.
    """

    @staticmethod
    def correlation_coefficient(data1, data2):
        if len(data1) != len(data2):
            raise ValueError("Lists must have same length")
        n = len(data1)
        if n == 0:
            raise ValueError("Lists must be non-empty")
        mean1 = statistics.mean(data1)
        mean2 = statistics.mean(data2)
        cov = sum((x - mean1) * (y - mean2) for x, y in zip(data1, data2))
        denom1 = sum((x - mean1) ** 2 for x in data1)
        denom2 = sum((y - mean2) ** 2 for y in data2)
        denom = math.sqrt(denom1 * denom2)
        if denom == 0:
            return 0.0
        return cov / denom

    @staticmethod
    def skewness(data):
        n = len(data)
        if n < 2:
            return 0.0
        mean = statistics.mean(data)
        # use sample standard deviation (ddof=1)
        s = statistics.pstdev(data)  # population stdev
        # Use the common sample skewness estimator: m3 / s^3 with small-sample correction
        m3 = sum((x - mean) ** 3 for x in data) / n
        if s == 0:
            return 0.0
        g1 = m3 / (s ** 3)
        # apply correction to make it approximately unbiased when n>2
        if n > 2:
            return math.sqrt(n * (n - 1)) / (n - 2) * g1
        return g1

    @staticmethod
    def kurtosis(data):
        n = len(data)
        if n < 2:
            return -3.0
        mean = statistics.mean(data)
        m2 = sum((x - mean) ** 2 for x in data) / n
        m4 = sum((x - mean) ** 4 for x in data) / n
        if m2 == 0:
            return -3.0
        # excess kurtosis (population moment)
        g2 = m4 / (m2 * m2) - 3.0
        # Small sample correction if possible (only if n>3)
        if n > 3:
            # unbiased-ish correction (common formula)
            return ((n - 1) / ((n - 2) * (n - 3))) * ((n + 1) * (m4 / (m2 * m2)) - 3 * (n - 1)) 
        return g2

    @staticmethod
    def pdf(data, mu, sigma):
        if sigma <= 0:
            raise ValueError("sigma must be > 0")
        norm = 1.0 / (sigma * math.sqrt(2 * math.pi))
        var2 = 2 * sigma * sigma
        return [norm * math.exp(-((x - mu) ** 2) / var2) for x in data]