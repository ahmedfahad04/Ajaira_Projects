import sqlite3
import hashlib
import os
import binascii

class UserLoginDB:
    """
    This is a database management class for user login verification, providing functions for inserting user information, searching user information, deleting user information, and validating user login.
    """

    def __init__(self, db_name):
        """
        Initializes the UserLoginDB object with the specified database name.
        Uses PBKDF2-HMAC-SHA256 for password hashing.
        """
        self.connection = sqlite3.connect(db_name)
        self.cursor = self.connection.cursor()

    def create_table(self):
        self.cursor.execute(
            "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password_hash TEXT, salt TEXT)"
        )
        self.connection.commit()

    def _pbkdf2_hash(self, password, salt, iterations=100000):
        dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations)
        return binascii.hexlify(dk).decode('ascii')

    def insert_user(self, username, password):
        salt = os.urandom(16)
        password_hash = self._pbkdf2_hash(password, salt)
        salt_hex = binascii.hexlify(salt).decode('ascii')
        self.cursor.execute(
            "INSERT OR IGNORE INTO users (username, password_hash, salt) VALUES (?, ?, ?)",
            (username, password_hash, salt_hex),
        )
        self.connection.commit()

    def search_user_by_username(self, username):
        self.cursor.execute(
            "SELECT id, username, password_hash, salt FROM users WHERE username = ?", (username,)
        )
        rows = self.cursor.fetchall()
        return rows

    def delete_user_by_username(self, username):
        self.cursor.execute("DELETE FROM users WHERE username = ?", (username,))
        self.connection.commit()

    def validate_user_login(self, username, password):
        self.cursor.execute(
            "SELECT password_hash, salt FROM users WHERE username = ?", (username,)
        )
        row = self.cursor.fetchone()
        if not row:
            return False
        stored_hash, salt_hex = row
        salt = binascii.unhexlify(salt_hex.encode('ascii'))
        return stored_hash == self._pbkdf2_hash(password, salt)