import re

class Words2Numbers:
    """
    The class provides a text-to-number conversion utility, allowing conversion of written numbers (in words) to their numerical representation.
    """

    def __init__(self):
        self.numwords = {}
        self.units = [
            "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
            "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
            "sixteen", "seventeen", "eighteen", "nineteen",
        ]
        self.tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]
        self.scales = ["hundred", "thousand", "million", "billion", "trillion"]

        self.numwords["and"] = (1, 0)
        for i, w in enumerate(self.units):
            self.numwords[w] = (1, i)
        for i, w in enumerate(self.tens):
            if w:
                self.numwords[w] = (1, i * 10)
        for i, w in enumerate(self.scales):
            self.numwords[w] = (10 ** (i * 3 or 2), 0)

        self.ordinal_words = {'first': 1, 'second': 2, 'third': 3, 'fifth': 5, 'eighth': 8, 'ninth': 9, 'twelfth': 12}
        self.ordinal_endings = [('ieth', 'y'), ('th', '')]

    def _tokens(self, text):
        text = text.lower().strip()
        text = re.sub(r'[,]', ' ', text)
        tokens = re.split(r'\s+|-', text)
        return [t for t in tokens if t]

    def _replace_ordinal(self, word):
        if word in self.ordinal_words:
            return (1, self.ordinal_words[word])
        for end, rep in self.ordinal_endings:
            if word.endswith(end):
                base = word[:-len(end)] + rep
                if base in self.numwords:
                    return self.numwords[base]
        return None

    def text2int(self, textnum):
        if not isinstance(textnum, str):
            raise ValueError("Input must be a string")
        tokens = self._tokens(textnum)
        if not tokens:
            return "0"
        total = 0
        current = 0
        negative = False
        if tokens[0] in ("minus", "negative"):
            negative = True
            tokens = tokens[1:]
        for token in tokens:
            if token == "and":
                continue
            if token in self.numwords:
                scale, inc = self.numwords[token]
            else:
                conv = self._replace_ordinal(token)
                if conv:
                    scale, inc = conv
                else:
                    raise ValueError("Invalid token: {}".format(token))
            if scale > 1:
                if current == 0:
                    current = 1
                current *= scale
                if scale > 100:
                    total += current
                    current = 0
            else:
                current += inc
        total += current
        if negative:
            total = -total
        return str(total)

    def is_valid_input(self, textnum):
        if not isinstance(textnum, str):
            return False
        if '-' in textnum:
            return False
        tokens = self._tokens(textnum)
        if not tokens:
            return False
        for token in tokens:
            if token in ("and", "minus", "negative"):
                continue
            if token in self.numwords or token in self.ordinal_words:
                continue
            ok = False
            for end, rep in self.ordinal_endings:
                if token.endswith(end) and (token[:-len(end)] + rep) in self.numwords:
                    ok = True
                    break
            if not ok:
                return False
        return True