class PushBoxGame:
    """
    This class implements a functionality of a sokoban game, where the player needs to move boxes to designated targets in order to win.
    """
    def __init__(self, map):
        self.map = map
        self.player_row = 0
        self.player_col = 0
        self.targets = []
        self.boxes = []
        self.target_count = 0
        self.is_game_over = False
        self._rows = len(map)
        self._cols = len(map[0]) if self._rows else 0
        self.init_game()

    def init_game(self):
        # Use lists for stable ordering and a dict for fast lookup of boxes
        self.targets = []
        self.boxes = []
        self._box_index = {}
        idx = 0
        for r in range(self._rows):
            for c in range(self._cols):
                ch = self.map[r][c]
                if ch == 'O':
                    self.player_row, self.player_col = r, c
                elif ch == 'G':
                    self.targets.append((r, c))
                elif ch == 'X':
                    self.boxes.append((r, c))
                    self._box_index[(r, c)] = idx
                    idx += 1
        self._targets_set = set(self.targets)
        self._boxes_set = set(self.boxes)
        self.target_count = len(self.targets)
        self.is_game_over = self.check_win()

    def check_win(self):
        # win when every box position is a target
        self.is_game_over = all(pos in self._targets_set for pos in self._boxes_set)
        return self.is_game_over

    def move(self, direction):
        if self.is_game_over:
            return True
        moves = {'w': (-1, 0), 's': (1, 0), 'a': (0, -1), 'd': (0, 1)}
        if direction not in moves:
            return self.is_game_over
        dr, dc = moves[direction]
        nr, nc = self.player_row + dr, self.player_col + dc
        if not (0 <= nr < self._rows and 0 <= nc < self._cols):
            return self.is_game_over
        if self.map[nr][nc] == '#':
            return self.is_game_over
        if (nr, nc) in self._boxes_set:
            br, bc = nr + dr, nc + dc
            if not (0 <= br < self._rows and 0 <= bc < self._cols):
                return self.is_game_over
            if self.map[br][bc] == '#' or (br, bc) in self._boxes_set:
                return self.is_game_over
            # update box sets and index mapping
            self._boxes_set.remove((nr, nc))
            self._boxes_set.add((br, bc))
            # rebuild box list and index mapping
            self.boxes = list(self._boxes_set)
            self._box_index = {pos: i for i, pos in enumerate(self.boxes)}
        else:
            # step into empty/target
            pass
        self.player_row, self.player_col = nr, nc
        self.boxes = list(self._boxes_set)
        return self.check_win()

# Classification response:
# set conversion;dict comprehension;any/all usage;early return;guard clause;boundary case handling;empty input handling;in-place mutation;enumerate loop;temporary variable