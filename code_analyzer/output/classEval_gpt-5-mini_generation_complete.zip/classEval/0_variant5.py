import logging
import datetime

class AccessGatewayFilter:
    """
    This class is a filter used for accessing gateway filtering, primarily for authentication and access log recording.
    """

    def __init__(self):
        self.allowed_prefixes = ['/api', '/login']
        self.current_user = None
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger('AccessGatewayFilter')

    def filter(self, request):
        # validate type
        if not isinstance(request, dict):
            return False

        path = request.get('path', '')
        method = request.get('method', 'GET')

        # Allow login and simple static resources
        if path.startswith('/login') or path.startswith('/static'):
            return True

        # Allow OPTIONS preflight
        if method and method.upper() == 'OPTIONS':
            return True

        # If path starts with /api, require authentication
        if self.is_start_with(path) and path.startswith('/api'):
            user = self.get_jwt_user(request)
            if user is None:
                return False
            # set current user and perform logging
            self.set_current_user_info_and_log(user)
            return True

        # Default allow for other URIs
        return True

    def is_start_with(self, request_uri):
        if not isinstance(request_uri, str):
            return False
        for p in self.allowed_prefixes:
            if request_uri.startswith(p):
                return True
        return False

    def get_jwt_user(self, request):
        headers = request.get('headers', {}) or {}
        auth = headers.get('Authorization') or headers.get('authorization')
        if auth is None:
            return None

        # If Authorization provided as dict with 'user' and 'jwt'
        if isinstance(auth, dict):
            token = auth.get('jwt')
            user = auth.get('user')
        elif isinstance(auth, str):
            # support "user=...;jwt=..." simple parsing
            parts = {}
            for part in auth.split(';'):
                if '=' in part:
                    k, v = part.split('=', 1)
                    parts[k.strip()] = v.strip()
            user = {'name': parts.get('user')} if 'user' in parts else None
            token = parts.get('jwt')
        else:
            return None

        # If there's no token but a user object is provided, accept (internal trusted)
        if user and not token:
            return user

        if not isinstance(token, str):
            return None

        # Token format expected: username + YYYY-MM-DD
        today = str(datetime.date.today())
        if not token.endswith(today):
            return None
        username = token[:-len(today)]
        if not username:
            return None

        # If user present, ensure it matches
        if isinstance(user, dict):
            name = user.get('name') or user.get('username')
            if name and name != username:
                return None
            return user

        return {'name': username}

    def set_current_user_info_and_log(self, user):
        self.current_user = user
        ts = datetime.datetime.now().isoformat()
        username = user.get('name') if isinstance(user, dict) else str(user)
        self.logger.info("Access by %s at %s", username, ts)