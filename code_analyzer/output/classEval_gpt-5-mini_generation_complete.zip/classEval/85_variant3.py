import math
import time

class Thermostat:
    """
    The class manages temperature control, including setting and retrieving the target temperature, adjusting the mode, and simulating temperature operation.
    """

    def __init__(self, current_temperature, target_temperature, mode):
        self.current_temperature = float(current_temperature)
        self._target_temperature = float(target_temperature)
        self._mode = mode

    def get_target_temperature(self):
        return self._target_temperature

    def set_target_temperature(self, temperature):
        self._target_temperature = float(temperature)

    target_temperature = property(get_target_temperature, set_target_temperature)

    def get_mode(self):
        return self._mode

    def set_mode(self, mode):
        if mode not in ('heat', 'cool'):
            raise ValueError("mode must be 'heat' or 'cool'")
        self._mode = mode

    mode = property(get_mode, set_mode)

    def auto_set_mode(self):
        if self.current_temperature < self._target_temperature:
            self._mode = 'heat'
        else:
            self._mode = 'cool'

    def auto_check_conflict(self):
        if self.current_temperature < self._target_temperature:
            if self._mode != 'heat':
                self.auto_set_mode()
                return False
            return True
        else:
            if self._mode != 'cool':
                self.auto_set_mode()
                return False
            return True

    def simulate_operation(self):
        self.auto_set_mode()
        diff = abs(self._target_temperature - self.current_temperature)
        if diff == 0:
            return 0
        # compute steps as ceiling without importing ceil explicitly
        integer_part = int(diff)
        steps = integer_part + (1 if diff - integer_part > 0 else 0)
        self.current_temperature = float(self._target_temperature)
        return steps