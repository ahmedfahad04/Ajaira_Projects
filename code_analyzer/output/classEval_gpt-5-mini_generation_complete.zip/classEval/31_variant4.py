import math
from statistics import mean, pstdev

class DataStatistics4:
    """
    This is a class that performs advanced mathematical calculations and statistics, including correlation coefficient, skewness, kurtosis, and probability density function (PDF) for a normal distribution.
    Uses straightforward central moment formulas (population) for skewness/kurtosis.
    """

    @staticmethod
    def correlation_coefficient(data1, data2):
        if not data1 or not data2:
            raise ValueError("Inputs cannot be empty")
        if len(data1) != len(data2):
            raise ValueError("Inputs must be same length")
        m1 = mean(data1)
        m2 = mean(data2)
        num = sum((x - m1) * (y - m2) for x, y in zip(data1, data2))
        den1 = sum((x - m1) ** 2 for x in data1)
        den2 = sum((y - m2) ** 2 for y in data2)
        denom = math.sqrt(den1 * den2)
        if denom == 0:
            return 0.0
        return num / denom

    @staticmethod
    def skewness(data):
        if not data:
            raise ValueError("Input cannot be empty")
        n = len(data)
        mu = mean(data)
        # population central moments
        m2 = sum((x - mu) ** 2 for x in data) / n
        m3 = sum((x - mu) ** 3 for x in data) / n
        if m2 == 0:
            return 0.0
        skew_pop = m3 / (m2 ** 1.5)
        # if sample size small, return corrected value
        if n > 2:
            return math.sqrt(n * (n - 1)) / (n - 2) * skew_pop
        return skew_pop

    @staticmethod
    def kurtosis(data):
        if not data:
            raise ValueError("Input cannot be empty")
        n = len(data)
        mu = mean(data)
        m2 = sum((x - mu) ** 2 for x in data) / n
        m4 = sum((x - mu) ** 4 for x in data) / n
        if m2 == 0:
            return -3.0
        # excess kurtosis (population)
        return m4 / (m2 * m2) - 3.0

    @staticmethod
    def pdf(data, mu, sigma):
        if sigma <= 0:
            raise ValueError("sigma must be positive")
        coef = 1.0 / (sigma * math.sqrt(2.0 * math.pi))
        denom = 2.0 * sigma * sigma
        return [coef * math.exp(-((x - mu) ** 2) / denom) for x in data]