class NumberWordFormatter:
    """
    This is a class that provides to convert numbers into their corresponding English word representation, including handling the conversion of both the integer and decimal parts, and incorporating appropriate connectors and units.
    """
    def __init__(self):
        self.NUMBER = ["", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE"]
        self.NUMBER_TEEN = ["TEN", "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN", "SEVENTEEN",
                            "EIGHTEEN", "NINETEEN"]
        self.NUMBER_TEN = ["TEN", "TWENTY", "THIRTY", "FORTY", "FIFTY", "SIXTY", "SEVENTY", "EIGHTY", "NINETY"]
        self.NUMBER_MORE = ["", "THOUSAND", "MILLION", "BILLION"]
        self.NUMBER_SUFFIX = ["k", "w", "", "m", "", "", "b", "", "", "t", "", "", "p", "", "", "e"]

    def format(self, x):
        if isinstance(x, str):
            return self.format_string(x)
        if isinstance(x, float):
            s = format(x, 'f')
        else:
            s = str(x)
        if s.startswith('-'):
            return "MINUS " + self.format_string(s[1:])
        if 'e' in s or 'E' in s:
            s = format(float(s), 'f')
        if '.' in s:
            int_s, dec_s = s.split('.', 1)
        else:
            int_s, dec_s = s, ''
        int_s = int_s.replace(',', '').lstrip('0') or '0'
        int_words = self._build(int(int_s))
        if dec_s:
            dec_s = dec_s.rstrip('0')
        if dec_s:
            dec_words = "POINT " + " ".join(self.NUMBER[int(ch)] if ch != '0' else "ZERO" for ch in dec_s)
            return (int_words + " " + dec_words + " ONLY").strip()
        return (int_words + " ONLY").strip()

    def format_string(self, x):
        s = str(x).strip()
        if s.startswith('+'):
            s = s[1:]
        if s.startswith('-'):
            return "MINUS " + self.format_string(s[1:])
        if 'e' in s or 'E' in s:
            try:
                s = format(float(s), 'f')
            except:
                pass
        if '.' in s:
            int_s, dec_s = s.split('.', 1)
        else:
            int_s, dec_s = s, ''
        int_s = int_s.replace(',', '').lstrip('0') or '0'
        int_words = self._build(int(int_s))
        if dec_s:
            dec_s = dec_s.rstrip('0')
        if dec_s:
            dec_words = "POINT " + " ".join(self.NUMBER[int(ch)] if ch != '0' else "ZERO" for ch in dec_s)
            return (int_words + " " + dec_words + " ONLY").strip()
        return int_words + " ONLY"

    def trans_two(self, s):
        s = s.zfill(2)
        tens, ones = int(s[0]), int(s[1])
        if tens == 0:
            return self.NUMBER[ones] if ones != 0 else ""
        if tens == 1:
            return self.NUMBER_TEEN[ones]
        t = self.NUMBER_TEN[tens - 1]
        u = self.NUMBER[ones]
        return t + (" " + u if u else "")

    def trans_three(self, s):
        s = s.zfill(3)
        h = int(s[0])
        rest = s[1:]
        parts = []
        if h:
            parts.append(self.NUMBER[h] + " HUNDRED")
            if rest != "00":
                parts.append("AND")
        two = self.trans_two(rest)
        if two:
            parts.append(two)
        return " ".join(parts).strip()

    def parse_more(self, i):
        if 0 <= i < len(self.NUMBER_MORE):
            return self.NUMBER_MORE[i]
        return ""

    def _build(self, n):
        if n == 0:
            return "ZERO"
        words = []
        idx = 0
        while n > 0:
            part = n % 1000
            if part:
                chunk = self.trans_three(str(part).zfill(3))
                more = self.parse_more(idx)
                if more:
                    words.append(chunk + " " + more)
                else:
                    words.append(chunk)
            n //= 1000
            idx += 1
        return " ".join(reversed(words)).strip()

# Classification response:
# helper function extraction;loop rewrite;while loop;accumulator list;generator expression;join/split usage;try-except wrapper;error suppression;type conversion;input validation;boundary case handling;behavior change;temporary variable;guard clause