from datetime import datetime
import numpy as np

class MovieBookingSystem:
    def __init__(self):
        self.movies = []

    def add_movie(self, name, price, start_time, end_time, n):
        st = datetime.strptime(start_time, "%H:%M")
        et = datetime.strptime(end_time, "%H:%M")
        seats = np.zeros((n, n), dtype=float)
        self.movies.append({'name': name, 'price': float(price), 'start_time': st, 'end_time': et, 'seats': seats})

    def book_ticket(self, name, seats_to_book):
        movie = next((m for m in self.movies if m['name'] == name), None)
        if movie is None:
            return "Movie not found."
        seats = movie['seats']
        try:
            arr = np.array(seats_to_book, dtype=int)
            if arr.ndim != 2 or arr.shape[1] != 2:
                return "Booking failed."
            rows = arr[:, 0]
            cols = arr[:, 1]
            if (rows < 0).any() or (cols < 0).any():
                return "Booking failed."
            if rows.max() >= seats.shape[0] or cols.max() >= seats.shape[1]:
                return "Booking failed."
            if np.any(seats[rows, cols] != 0.0):
                return "Booking failed."
            seats[rows, cols] = 1.0
            return "Booking success."
        except Exception:
            return "Booking failed."

    def available_movies(self, start_time, end_time):
        st = datetime.strptime(start_time, "%H:%M")
        et = datetime.strptime(end_time, "%H:%M")
        return [m['name'] for m in self.movies if m['start_time'] >= st and m['end_time'] <= et]

# Classification response:
# variable renaming;loop rewrite;generator expression;guard clause;try-except wrapper;input validation;type conversion;list comprehension;in-place mutation;temporary variable;any/all usage;flattened conditional