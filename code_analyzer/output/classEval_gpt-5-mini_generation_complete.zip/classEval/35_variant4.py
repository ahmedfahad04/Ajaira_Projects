from collections import deque

class EightPuzzle:
    """
    This class is an implementation of the classic 8-puzzle game, including methods for finding the blank tile, making moves, getting possible moves, and solving the puzzle using a breadth-first search algorithm.
    """

    def __init__(self, initial_state):
        self.initial_state = initial_state
        self.goal_state = [[1,2,3],[4,5,6],[7,8,0]]

    def find_blank(self, state):
        for r in range(3):
            for c in range(3):
                if state[r][c] == 0:
                    return (r,c)
        return (-1,-1)

    def move(self, state, direction):
        r,c = self.find_blank(state)
        new = [row[:] for row in state]
        if direction == 'up' and r>0:
            new[r][c], new[r-1][c] = new[r-1][c], new[r][c]
        elif direction == 'down' and r<2:
            new[r][c], new[r+1][c] = new[r+1][c], new[r][c]
        elif direction == 'left' and c>0:
            new[r][c], new[r][c-1] = new[r][c-1], new[r][c]
        elif direction == 'right' and c<2:
            new[r][c], new[r][c+1] = new[r][c+1], new[r][c]
        return new

    def get_possible_moves(self, state):
        r,c = self.find_blank(state)
        # fixed order up, left, right, down to be deterministic
        moves = []
        if r-1 >= 0:
            moves.append('up')
        if c-1 >= 0:
            moves.append('left')
        if c+1 < 3:
            moves.append('right')
        if r+1 < 3:
            moves.append('down')
        return moves

    def solve(self):
        if self.initial_state == self.goal_state:
            return []
        def tostr(s):
            return ''.join(str(x) for row in s for x in row)
        start = tostr(self.initial_state)
        goal = tostr(self.goal_state)
        q = deque([start])
        prev = {start: None}
        prev_move = {start: None}
        while q:
            cur = q.popleft()
            cur_state = [[int(cur[i*3+j]) for j in range(3)] for i in range(3)]
            for mv in self.get_possible_moves(cur_state):
                nxt_state = self.move(cur_state, mv)
                nxt = tostr(nxt_state)
                if nxt in prev:
                    continue
                prev[nxt] = cur
                prev_move[nxt] = mv
                if nxt == goal:
                    path = []
                    node = nxt
                    while prev_move[node] is not None:
                        path.append(prev_move[node])
                        node = prev[node]
                    return list(reversed(path))
                q.append(nxt)
        return []