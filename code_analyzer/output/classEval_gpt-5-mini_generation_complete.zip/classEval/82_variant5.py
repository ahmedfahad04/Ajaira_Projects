class StockPortfolioTracker:
    """
    Lot-based implementation (FIFO-like) where each buy creates a lot.
    Selling consumes lots starting from earliest.
    Portfolio is presented as aggregated totals per symbol.
    """

    def __init__(self, cash_balance):
        self._lots = []  # list of {"name","price","quantity"}
        self.portfolio = []
        self.cash_balance = float(cash_balance)

    def _aggregate(self):
        agg = {}
        for lot in self._lots:
            name = lot["name"]
            if name not in agg:
                agg[name] = {"price": lot["price"], "quantity": lot["quantity"]}
            else:
                agg[name]["quantity"] += lot["quantity"]
                # keep latest price as current market price
                agg[name]["price"] = lot["price"]
        self.portfolio = [{"name": name, "price": v["price"], "quantity": v["quantity"]} for name, v in agg.items()]

    def add_stock(self, stock):
        name = stock["name"]
        price = float(stock["price"])
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        self._lots.append({"name": name, "price": price, "quantity": qty})
        self._aggregate()
        return True

    def remove_stock(self, stock):
        # remove exact lot match if exists
        for i, lot in enumerate(self._lots):
            if lot["name"] == stock["name"] and float(lot["price"]) == float(stock["price"]) and int(lot["quantity"]) == int(stock["quantity"]):
                self._lots.pop(i)
                self._aggregate()
                return True
        return False

    def buy_stock(self, stock):
        name = stock["name"]
        price = float(stock["price"])
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        cost = price * qty
        if self.cash_balance < cost:
            return False
        self.cash_balance -= cost
        # create a new lot
        self._lots.append({"name": name, "price": price, "quantity": qty})
        self._aggregate()
        return True

    def sell_stock(self, stock):
        name = stock["name"]
        sell_price = float(stock["price"])
        qty_to_sell = int(stock["quantity"])
        if qty_to_sell <= 0 or sell_price < 0:
            return False
        # check total available
        total_available = sum(l["quantity"] for l in self._lots if l["name"] == name)
        if total_available < qty_to_sell:
            return False
        # consume lots FIFO
        i = 0
        while qty_to_sell > 0 and i < len(self._lots):
            lot = self._lots[i]
            if lot["name"] != name:
                i += 1
                continue
            if lot["quantity"] <= qty_to_sell:
                qty_to_sell -= lot["quantity"]
                self._lots.pop(i)
            else:
                lot["quantity"] -= qty_to_sell
                qty_to_sell = 0
                i += 1
        self.cash_balance += sell_price * int(stock["quantity"])
        self._aggregate()
        return True

    def calculate_portfolio_value(self):
        holdings_value = sum(lot["price"] * lot["quantity"] for lot in self.portfolio)
        return float(self.cash_balance + holdings_value)

    def get_portfolio_summary(self):
        items = [{"name": p["name"], "value": float(p["price"] * p["quantity"])} for p in self.portfolio]
        return (self.calculate_portfolio_value(), items)

    def get_stock_value(self, stock):
        return float(float(stock["price"]) * int(stock["quantity"]))