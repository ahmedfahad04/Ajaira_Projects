import re
import string
import gensim
from bs4 import BeautifulSoup, NavigableString

class HtmlUtil:
    """
    This is a class as util for html, supporting for formatting and extracting code from HTML text, including cleaning up the text and converting certain elements into specific marks.
    """

    def __init__(self):
        """
        Initialize a series of labels
        """
        self.SPACE_MARK = '-SPACE-'
        self.JSON_MARK = '-JSON-'
        self.MARKUP_LANGUAGE_MARK = '-MARKUP_LANGUAGE-'
        self.URL_MARK = '-URL-'
        self.NUMBER_MARK = '-NUMBER-'
        self.TRACE_MARK = '-TRACE-'
        self.COMMAND_MARK = '-COMMAND-'
        self.COMMENT_MARK = '-COMMENT-'
        self.CODE_MARK = '-CODE-'

    @staticmethod
    def __format_line_feed(text):
        """
        Replace consecutive line breaks with a single line break
        """
        return re.sub(r'\n\s*\n+', '\n', text)

    def format_line_html_text(self, html_text):
        """
        Traverse body element children, replacing <pre> with CODE marker and collecting visible text in order.
        """
        soup = BeautifulSoup(html_text, 'html.parser')
        body = soup.body or soup
        parts = []

        block_tags = set(['p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'li', 'ul', 'ol', 'section', 'article', 'header', 'footer', 'nav', 'blockquote', 'pre', 'br', 'table', 'tr'])

        def collect(node):
            for child in node.children:
                if isinstance(child, NavigableString):
                    txt = str(child)
                    if txt.strip():
                        parts.append(txt)
                elif child.name:
                    if child.name == 'pre':
                        parts.append(self.CODE_MARK)
                    elif child.name == 'code' and child.parent.name != 'pre':
                        parts.append(self.CODE_MARK)
                    elif child.name in block_tags:
                        collect(child)
                        # add separator for block-level
                        parts.append('\n')
                    else:
                        collect(child)

        collect(body)
        # Join parts, collapse multiple newlines and whitespace
        text = ''.join(parts)
        text = re.sub(r'[ \t]+\n', '\n', text)
        text = self.__format_line_feed(text)
        # Build clean lines
        lines = [ln.strip() for ln in text.splitlines()]
        lines = [ln for ln in lines if ln != '']
        return '\n'.join(lines).strip()

    def extract_code_from_html_text(self, html_text):
        """
        Extract contents of each <pre>, preferring inner <code> if present.
        """
        soup = BeautifulSoup(html_text, 'html.parser')
        codes = []
        for pre in soup.find_all('pre'):
            code_tag = pre.find('code')
            if code_tag:
                txt = code_tag.get_text()
            else:
                txt = pre.get_text()
            # Remove only leading/trailing blank lines
            txt = re.sub(r'^\s*\n', '', txt)
            txt = re.sub(r'\n\s*$', '', txt)
            codes.append(txt)
        return codes