import numpy as np


class MetricsCalculator2:
    """
    The class provides to calculate Mean Reciprocal Rank (MRR) and Mean Average Precision (MAP) based on input data, where MRR measures the ranking quality and MAP measures the average precision.
    """

    def __init__(self):
        pass

    @staticmethod
    def _wrap(data):
        if isinstance(data, list):
            return data
        return [data]

    @staticmethod
    def mrr(data):
        data = MetricsCalculator2._wrap(data)
        results = []
        for item in data:
            if not item or not hasattr(item, "__getitem__"):
                results.append(0.0)
                continue
            labels = list(item[0])
            rr = 0.0
            try:
                pos = labels.index(1)
                rr = 1.0 / float(pos + 1)
            except ValueError:
                rr = 0.0
            except Exception:
                # handle non-int labels by searching
                found = False
                for i, v in enumerate(labels, 1):
                    if int(v) == 1:
                        rr = 1.0 / i
                        found = True
                        break
                if not found:
                    rr = 0.0
            results.append(rr)
        mean_rr = float(np.mean(results)) if results else 0.0
        return mean_rr, results

    @staticmethod
    def map(data):
        data = MetricsCalculator2._wrap(data)
        aps = []
        for item in data:
            if not item or not hasattr(item, "__getitem__"):
                aps.append(0.0)
                continue
            labels = list(item[0])
            gt = item[1] if len(item) > 1 else sum(int(x) for x in labels)
            gt = float(gt)
            if gt == 0:
                aps.append(0.0)
                continue
            hits = 0
            total = 0.0
            for idx, val in enumerate(labels, 1):
                if int(val) == 1:
                    hits += 1
                    total += hits / float(idx)
            aps.append(total / gt)
        mean_ap = float(np.mean(aps)) if aps else 0.0
        return mean_ap, aps

# Classification response:
# helper function extraction; flattened conditional; variable renaming; list conversion; enumerate loop; generator expression; accumulator list; exception handling; input validation; empty input handling; type conversion; behavior change