from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
import os


class DocFileHandler:
    """
    This is a class that handles Word documents and provides functionalities for reading, writing, and modifying the content of Word documents.
    """

    def __init__(self, file_path):
        self.file_path = file_path

    def read_text(self):
        if not os.path.exists(self.file_path):
            return ""
        try:
            doc = Document(self.file_path)
        except Exception:
            return ""
        pieces = []
        for p in doc.paragraphs:
            pieces.append(p.text)
        for t in doc.tables:
            for row in t.rows:
                pieces.append(" | ".join(cell.text for cell in row.cells))
        return "\n".join(filter(None, pieces))

    def write_text(self, content, font_size=12, alignment='left'):
        try:
            if os.path.exists(self.file_path):
                doc = Document(self.file_path)
            else:
                doc = Document()
            align_val = self._get_alignment_value(alignment)
            if isinstance(content, str):
                lines = content.splitlines()
            else:
                lines = [str(content)]
            for line in lines:
                p = doc.add_paragraph()
                p.alignment = align_val
                r = p.add_run(line)
                r.font.size = Pt(font_size)
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def add_heading(self, heading, level=1):
        try:
            doc = Document(self.file_path) if os.path.exists(self.file_path) else Document()
            doc.add_heading(heading, level=level)
            # adjust heading font size for common levels
            try:
                last = doc.paragraphs[-1]
                size_map = {1: 16, 2: 14, 3: 12}
                sz = size_map.get(level, 12)
                for run in last.runs:
                    run.font.size = Pt(sz)
            except Exception:
                pass
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def add_table(self, data):
        try:
            if not data or not isinstance(data, (list, tuple)):
                return False
            rows = len(data)
            cols = max((len(r) for r in data if isinstance(r, (list, tuple))), default=0)
            if cols == 0:
                return False
            doc = Document(self.file_path) if os.path.exists(self.file_path) else Document()
            table = doc.add_table(rows=rows, cols=cols)
            table.style = 'Table Grid'
            for i, row in enumerate(data):
                for j in range(cols):
                    txt = ""
                    if isinstance(row, (list, tuple)) and j < len(row):
                        txt = "" if row[j] is None else str(row[j])
                    table.cell(i, j).text = txt
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def _get_alignment_value(self, alignment):
        if isinstance(alignment, WD_PARAGRAPH_ALIGNMENT):
            return alignment
        if not isinstance(alignment, str):
            return WD_PARAGRAPH_ALIGNMENT.LEFT
        a = alignment.strip().lower()
        if a in ('center', 'centre'):
            return WD_PARAGRAPH_ALIGNMENT.CENTER
        if a == 'right':
            return WD_PARAGRAPH_ALIGNMENT.RIGHT
        return WD_PARAGRAPH_ALIGNMENT.LEFT