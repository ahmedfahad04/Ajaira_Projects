from collections import deque
import copy

class EightPuzzle:
    """
    This class is an implementation of the classic 8-puzzle game, including methods for finding the blank tile, making moves, getting possible moves, and solving the puzzle using a breadth-first search algorithm.
    """

    def __init__(self, initial_state):
        """
        Initializing the initial state of Eight Puzzle Game, stores in attribute self.initial_state.
        And set the goal state of this game, stores in self.goal_state. In this case, set the size as 3*3
        :param initial_state: a 3*3 size list of Integer, stores the initial state
        """
        self.initial_state = initial_state
        self.goal_state = [[1, 2, 3], [4, 5, 6], [7, 8, 0]]

    def find_blank(self, state):
        for i in range(3):
            for j in range(3):
                if state[i][j] == 0:
                    return (i, j)
        return None

    def move(self, state, direction):
        i, j = self.find_blank(state)
        new_state = [row[:] for row in state]
        if direction == 'up':
            ni, nj = i - 1, j
        elif direction == 'down':
            ni, nj = i + 1, j
        elif direction == 'left':
            ni, nj = i, j - 1
        elif direction == 'right':
            ni, nj = i, j + 1
        else:
            return new_state
        if 0 <= ni < 3 and 0 <= nj < 3:
            new_state[i][j], new_state[ni][nj] = new_state[ni][nj], new_state[i][j]
        return new_state

    def get_possible_moves(self, state):
        i, j = self.find_blank(state)
        moves = []
        # order giving priority: up, left, right, down
        if i - 1 >= 0:
            moves.append('up')
        if j - 1 >= 0:
            moves.append('left')
        if j + 1 < 3:
            moves.append('right')
        if i + 1 < 3:
            moves.append('down')
        return moves

    def solve(self):
        if self.initial_state == self.goal_state:
            return []
        start = tuple(tuple(row) for row in self.initial_state)
        goal = tuple(tuple(row) for row in self.goal_state)
        queue = deque()
        queue.append((start, []))
        visited = {start}
        while queue:
            state_t, path = queue.popleft()
            state = [list(row) for row in state_t]
            for move_dir in self.get_possible_moves(state):
                new_state = self.move(state, move_dir)
                new_t = tuple(tuple(row) for row in new_state)
                if new_t in visited:
                    continue
                new_path = path + [move_dir]
                if new_t == goal:
                    return new_path
                visited.add(new_t)
                queue.append((new_t, new_path))
        return []