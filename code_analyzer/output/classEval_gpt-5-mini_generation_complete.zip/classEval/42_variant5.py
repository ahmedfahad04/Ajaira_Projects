class Hotel:
    """
    This is a class as hotel management system, managing the booking, check-in, check-out, and availability of rooms in a hotel with different room types.
    """

    def __init__(self, name, rooms):
        self.name = name
        self.available_rooms = dict(rooms)
        self.booked_rooms = {}

    def book_room(self, room_type, room_number, name):
        if not isinstance(room_type, str) or not isinstance(name, str):
            return False
        if not isinstance(room_number, int) or room_number <= 0:
            return False
        if room_type not in self.available_rooms:
            return False
        avail = self.available_rooms[room_type]
        if room_number > avail:
            return avail if avail != 0 else False
        # success: decrement available and add to booked
        self.available_rooms[room_type] = avail - room_number
        if room_type not in self.booked_rooms:
            self.booked_rooms[room_type] = {}
        self.booked_rooms[room_type][name] = self.booked_rooms[room_type].get(name, 0) + room_number
        return 'Success!'

    def check_in(self, room_type, room_number, name):
        if not isinstance(room_type, str) or not isinstance(name, str):
            return False
        if not isinstance(room_number, int) or room_number <= 0:
            return False
        if room_type not in self.booked_rooms:
            return False
        if name not in self.booked_rooms[room_type]:
            return False
        booked = self.booked_rooms[room_type][name]
        if room_number > booked:
            return False
        if room_number == booked:
            # remove the name entry but keep an empty dict for the type
            self.booked_rooms[room_type].pop(name, None)
            self.booked_rooms[room_type] = {}
        else:
            self.booked_rooms[room_type][name] = booked - room_number

    def check_out(self, room_type, room_number):
        if not isinstance(room_type, str):
            return
        if not isinstance(room_number, int) or room_number <= 0:
            return
        self.available_rooms[room_type] = self.available_rooms.get(room_type, 0) + room_number

    def get_available_rooms(self, room_type):
        return self.available_rooms.get(room_type, 0)