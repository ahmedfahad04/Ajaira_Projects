import re

class AutomaticGuitarSimulator:
    def __init__(self, text) -> None:
        self.play_text = text or ""

    def interpret(self, display=False):
        s = self.play_text or ""
        if not s.strip():
            return []
        res = []
        i = 0
        n = len(s)
        while i < n:
            # skip spaces
            if s[i].isspace():
                i += 1
                continue
            # collect chord until first digit
            chord_chars = []
            while i < n and not s[i].isdigit() and not s[i].isspace():
                chord_chars.append(s[i])
                i += 1
            # if hit space before digits, skip until next non-space
            while i < n and s[i].isspace():
                i += 1
            # now collect digits
            tune_chars = []
            while i < n and s[i].isdigit():
                tune_chars.append(s[i])
                i += 1
            chord = ''.join(chord_chars).strip()
            tune = ''.join(tune_chars)
            if chord and tune:
                # sanitize chord to remove stray punctuation
                chord = re.sub(r'[^A-Za-z#bMm7]', '', chord)
                entry = {"Chord": chord, "Tune": tune}
                res.append(entry)
                if display:
                    self.display(chord, tune)
        return res

    def display(self, key, value):
        out = f"Normal Guitar Playing -- Chord: {key}, Play Tune: {value}"
        print(out)
        return out