import re

class SplitSentence:
    """
    The class allows to split sentences, count words in a sentence, and process a text file to find the maximum word count.
    """

    def __init__(self):
        # common abbreviations that should not end a sentence
        self._abbrevs = {"Mr", "Mrs", "Dr", "Ms", "Jr", "Sr", "St"}

    def split_sentences(self, sentences_string):
        s = sentences_string or ""
        sentences = []
        start = 0
        i = 0
        length = len(s)
        while i < length:
            ch = s[i]
            if ch in ".?":
                # check if it's followed by space or end
                next_ok = (i + 1 == length) or s[i+1].isspace()
                if next_ok:
                    # find the word token before punctuation
                    j = i - 1
                    while j >= 0 and s[j] == ' ':
                        j -= 1
                    # find start of the word before punctuation
                    end_word = j
                    while j >= 0 and s[j].isalpha():
                        j -= 1
                    word = s[j+1:end_word+1]
                    if ch == '.' and word in self._abbrevs:
                        # not a sentence end; just continue
                        i += 1
                        continue
                    # capture sentence including punctuation
                    # include trailing spaces if you want but strip later
                    sentence = s[start:i+1].strip()
                    if sentence:
                        sentences.append(sentence)
                    # move start past any following spaces
                    i += 1
                    while i < length and s[i].isspace():
                        i += 1
                    start = i
                    continue
            i += 1
        # If remaining tail (no closing punctuation) treat as one? Problem expects only sentences ending . or ?
        # We'll ignore trailing without punctuation per spec. But if there's something, include it.
        if start < length:
            tail = s[start:].strip()
            if tail:
                sentences.append(tail)
        return sentences

    def count_words(self, sentence):
        if not sentence:
            return 0
        # words are sequences of letters only
        words = re.findall(r'\b[A-Za-z]+\b', sentence)
        return len(words)

    def process_text_file(self, sentences_string):
        sentences = self.split_sentences(sentences_string)
        max_count = 0
        for sent in sentences:
            cnt = self.count_words(sent)
            if cnt > max_count:
                max_count = cnt
        return max_count