import openpyxl
from openpyxl import Workbook
import os


class ExcelProcessor:
    """
    This is a class for processing excel files, including readring and writing excel data, as well as processing specific operations and saving as a new excel file.
    """

    def __init__(self):
        self.headers = None

    def read_excel(self, file_name):
        """
        Reading data from Excel files
        :param file_name:str, Excel file name to read
        :return:list of data, Data in Excel (list of dicts if header row exists)
        """
        try:
            wb = openpyxl.load_workbook(file_name, read_only=True, data_only=True)
            ws = wb.active
            it = ws.iter_rows(values_only=True)
            rows = list(it)
            if not rows:
                return []
            # Interpret first row as header if values are all strings or mixed
            header = rows[0]
            # Use header if at least one non-empty cell exists
            if any(h is not None for h in header):
                self.headers = [str(h) if h is not None else "" for h in header]
                data = []
                for r in rows[1:]:
                    row_dict = {}
                    for i, h in enumerate(self.headers):
                        row_dict[h] = r[i] if i < len(r) else None
                    data.append(row_dict)
                return data
            else:
                return [tuple(r) for r in rows]
        except Exception:
            return []

    def write_excel(self, data, file_name):
        """
        Write data to the specified Excel file
        :param data: list, Data to be written (list of dicts or list of tuples)
        :param file_name: str, Excel file name to write to
        :return: 0 or 1, 1 represents successful writing, 0 represents failed writing
        """
        try:
            wb = Workbook()
            ws = wb.active
            if not data:
                wb.save(file_name)
                return 1
            if isinstance(data, list) and isinstance(data[0], dict):
                headers = list(data[0].keys())
                ws.append(headers)
                for d in data:
                    ws.append([d.get(h) for h in headers])
            else:
                for row in data:
                    ws.append(list(row))
            wb.save(file_name)
            return 1
        except Exception:
            return 0

    def process_excel_data(self, N, save_file_name):
        """
        Change the specified column in the Excel file to uppercase
        :param N: int, The serial number of the column that want to change
        :param save_file_name: str, source file name
        :return:(int, str), The former is the return value of write_excel, while the latter is the saved file name of the processed data
        """
        try:
            data = self.read_excel(save_file_name)
            base, ext = os.path.splitext(save_file_name)
            out = f"{base}_upper_col{N}{ext or '.xlsx'}"
            if not data:
                res = self.write_excel([], out)
                return res, out
            # If data is list of dicts
            if isinstance(data, list) and data and isinstance(data[0], dict):
                # find header key by index
                if self.headers and 1 <= N <= len(self.headers):
                    key = self.headers[N - 1]
                    new_data = []
                    for row in data:
                        new_row = dict(row)
                        val = new_row.get(key)
                        if val is not None:
                            new_row[key] = str(val).upper()
                        new_data.append(new_row)
                    res = self.write_excel(new_data, out)
                    return res, out
                else:
                    # fallback: no header info, just write unchanged
                    res = self.write_excel(data, out)
                    return res, out
            else:
                # list of tuples
                new_data = []
                for row in data:
                    row = list(row)
                    if 1 <= N <= len(row):
                        val = row[N - 1]
                        if val is not None:
                            row[N - 1] = str(val).upper()
                    new_data.append(tuple(row))
                res = self.write_excel(new_data, out)
                return res, out
        except Exception:
            base, ext = os.path.splitext(save_file_name)
            out = f"{base}_upper_col{N}{ext or '.xlsx'}"
            return 0, out