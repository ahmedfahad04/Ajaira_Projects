import json
import os

class JSONProcessor:
    """
    This is a class to process JSON file, including reading and writing JSON files, as well as processing JSON data by removing a specified key from the JSON object.
    """

    def read_json(self, file_path):
        if not isinstance(file_path, str):
            return -1
        if not os.path.exists(file_path):
            return 0
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data
        except Exception:
            return -1

    def write_json(self, data, file_path):
        if not isinstance(file_path, str):
            return -1
        try:
            # Ensure directory exists
            dirpath = os.path.dirname(file_path)
            if dirpath and not os.path.exists(dirpath):
                os.makedirs(dirpath, exist_ok=True)
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
            return 1
        except Exception:
            return -1

    def process_json(self, file_path, remove_key):
        if not isinstance(file_path, str):
            return -1
        existing = self.read_json(file_path)
        if existing == 0:
            return 0
        if existing == -1:
            return -1
        if not isinstance(existing, dict):
            return 0
        if remove_key in existing:
            existing.pop(remove_key)
            write_res = self.write_json(existing, file_path)
            return 1 if write_res == 1 else -1
        else:
            return 0