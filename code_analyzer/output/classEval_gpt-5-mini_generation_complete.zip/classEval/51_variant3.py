import numpy as np

class KappaCalculator:
    """
    This is a class as KappaCalculator, supporting to calculate Cohen's and Fleiss' kappa coefficient.
    """

    @staticmethod
    def kappa(testData, k):
        arr = np.asarray(testData, dtype=float)
        if arr.size == 0:
            return 0.0
        if arr.shape != (k, k):
            try:
                arr = arr.reshape((k, k))
            except Exception:
                raise ValueError("testData must be k x k")
        total = arr.sum()
        if total == 0:
            return 0.0
        # use einsum for diag and outer product
        diag = np.einsum('ii->', arr)
        rows = arr.sum(axis=1)
        cols = arr.sum(axis=0)
        po = diag / total
        pe = np.einsum('i,i->', rows, cols) / (total * total)
        denom = 1.0 - pe
        if abs(denom) < 1e-14:
            return 1.0 if abs(po - pe) < 1e-14 else 0.0
        return (po - pe) / denom

    @staticmethod
    def fleiss_kappa(testData, N, k, n):
        arr = np.asarray(testData, dtype=float)
        if arr.size == 0:
            return 0.0
        if arr.shape != (N, k):
            try:
                arr = arr.reshape((N, k))
            except Exception:
                raise ValueError("testData must be N x k")
        # compute Pj vectorized
        sum_sq = np.sum(arr * arr, axis=1)
        # handle n == 1 (degenerate) by returning 0.0 agreement
        if n <= 1:
            Pbar = 0.0
        else:
            Pj = (sum_sq - n) / (n * (n - 1))
            Pbar = np.mean(Pj)
        # p_k
        p_k = np.sum(arr, axis=0) / (N * n)
        Pe = np.sum(p_k * p_k)
        denom = 1.0 - Pe
        if abs(denom) < 1e-14:
            return 1.0 if abs(Pbar - Pe) < 1e-14 else 0.0
        return (Pbar - Pe) / denom