class CurrencyConverter:
    """
    This is a class for currency conversion, which supports to convert amounts between different currencies, retrieve supported currencies, add new currency rates, and update existing currency rates.
    """
    def __init__(self):
        self.rates = {
            'USD': 1.0,
            'EUR': 0.85,
            'GBP': 0.72,
            'JPY': 110.15,
            'CAD': 1.23,
            'AUD': 1.34,
            'CNY': 6.40,
        }

    def _ensure_currency(self, currency):
        if currency not in self.rates:
            raise KeyError(f"Currency {currency} not supported")

    def convert(self, amount, from_currency, to_currency):
        if not isinstance(amount, (int, float)):
            raise TypeError("amount must be numeric")
        self._ensure_currency(from_currency)
        self._ensure_currency(to_currency)
        # Use direct ratio to avoid double division
        factor = self.rates[to_currency] / self.rates[from_currency]
        return float(amount * factor)

    def get_supported_currencies(self):
        # return a snapshot list
        return [c for c in self.rates.keys()]

    def add_currency_rate(self, currency, rate):
        if currency in self.rates:
            return False
        try:
            val = float(rate)
        except (TypeError, ValueError):
            raise TypeError("rate must be numeric")
        self.rates[currency] = val

    def update_currency_rate(self, currency, new_rate):
        if currency not in self.rates:
            return False
        try:
            val = float(new_rate)
        except (TypeError, ValueError):
            raise TypeError("new_rate must be numeric")
        self.rates[currency] = val