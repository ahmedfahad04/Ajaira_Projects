import itertools
from functools import lru_cache
from itertools import chain

class ArrangementCalculator:
    """
    The Arrangement class provides permutation calculations and selection operations for a given set of data elements.
    """

    def __init__(self, datas):
        self.datas = list(datas)

    @staticmethod
    @lru_cache(maxsize=None)
    def factorial(n):
        if n < 0:
            raise ValueError("Negative factorial is not defined")
        if n == 0:
            return 1
        return n * ArrangementCalculator.factorial(n - 1)

    @staticmethod
    def count(n, m=None):
        if n < 0:
            return 0
        if m is None or m == n:
            return ArrangementCalculator.factorial(n)
        if m < 0 or m > n:
            return 0
        return ArrangementCalculator.factorial(n) // ArrangementCalculator.factorial(n - m)

    @staticmethod
    def count_all(n):
        if n <= 0:
            return 0
        return sum(ArrangementCalculator.count(n, k) for k in range(1, n + 1))

    def select(self, m=None):
        if m is None:
            m = len(self.datas)
        if m < 0 or m > len(self.datas):
            return []
        return list(map(list, itertools.permutations(self.datas, m)))

    def select_all(self):
        iterables = (itertools.permutations(self.datas, k) for k in range(1, len(self.datas) + 1))
        return [list(p) for p in chain.from_iterable(iterables)]