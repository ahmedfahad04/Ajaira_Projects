import heapq

class AssessmentSystem:
    """
    This is a class as an student assessment system, which supports add student, add course score, calculate GPA, and other functions for students and courses.
    """

    def __init__(self):
        """
        Initialize the students dict in assessment system.
        """
        self.students = {}

    def add_student(self, name, grade, major):
        self.students.setdefault(name, {'name': name, 'grade': grade, 'major': major, 'courses': {}})

    def add_course_score(self, name, course, score):
        if name not in self.students:
            self.add_student(name, None, '')
        self.students[name]['courses'][course] = score

    def get_gpa(self, name):
        if name not in self.students:
            return None
        courses = self.students[name]['courses']
        if not courses:
            return None
        return sum(courses.values()) / len(courses)

    def get_all_students_with_fail_course(self):
        return [n for n, v in self.students.items() if any(s < 60 for s in v['courses'].values())]

    def get_course_average(self, course):
        vals = [v['courses'][course] for v in self.students.values() if course in v['courses']]
        if not vals:
            return None
        return sum(vals) / len(vals)

    def get_top_student(self):
        heap = []
        for name in self.students:
            gpa = self.get_gpa(name)
            if gpa is None:
                continue
            heapq.heappush(heap, (-gpa, name))
        if not heap:
            return None
        return heapq.heappop(heap)[1]