from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
import io


class DocFileHandler:
    """
    This is a class that handles Word documents and provides functionalities for reading, writing, and modifying the content of Word documents.
    """

    def __init__(self, file_path):
        self.file_path = file_path

    def read_text(self):
        try:
            doc = Document(self.file_path)
        except Exception:
            return ""
        out_lines = []
        for para in doc.paragraphs:
            out_lines.append(para.text)
        # represent tables inline
        for tbl in doc.tables:
            for r in tbl.rows:
                out_lines.append(" | ".join(cell.text for cell in r.cells))
        return "\n".join(out_lines)

    def write_text(self, content, font_size=12, alignment='left'):
        try:
            doc = Document()
            align_val = self._get_alignment_value(alignment)
            if isinstance(content, str):
                chunks = content.split("\n")
            elif isinstance(content, (list, tuple)):
                chunks = [str(x) for x in content]
            else:
                chunks = [str(content)]
            for chunk in chunks:
                p = doc.add_paragraph()
                p.alignment = align_val
                run = p.add_run(chunk)
                run.font.size = Pt(font_size)
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def add_heading(self, heading, level=1):
        try:
            doc = Document(self.file_path) if _exists(self.file_path) else Document()
            doc.add_heading(heading, level=level)
            # ensure heading font sizes are reasonable
            par = doc.paragraphs[-1]
            size = {1: 24, 2: 18, 3: 14}.get(level, 12)
            for r in par.runs:
                r.font.size = Pt(size)
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def add_table(self, data):
        try:
            if not data:
                return False
            rows = len(data)
            cols = max((len(r) for r in data if isinstance(r, (list, tuple))), default=0)
            if cols == 0:
                return False
            doc = Document(self.file_path) if _exists(self.file_path) else Document()
            table = doc.add_table(rows=rows, cols=cols)
            table.style = 'Table Grid'
            for i, row in enumerate(data):
                for j in range(cols):
                    val = ""
                    if isinstance(row, (list, tuple)) and j < len(row):
                        val = "" if row[j] is None else str(row[j])
                    table.cell(i, j).text = val
            doc.save(self.file_path)
            return True
        except Exception:
            return False

    def _get_alignment_value(self, alignment):
        if isinstance(alignment, str):
            a = alignment.strip().lower()
            if a in ('center', 'centre'):
                return WD_PARAGRAPH_ALIGNMENT.CENTER
            if a == 'right':
                return WD_PARAGRAPH_ALIGNMENT.RIGHT
        return WD_PARAGRAPH_ALIGNMENT.LEFT


def _exists(path):
    try:
        Document(path)
        return True
    except Exception:
        return False