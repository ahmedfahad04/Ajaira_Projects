import json
import threading
import os

class CookiesUtil:
    """
    This is a class as utility for managing and manipulating Cookies, including methods for retrieving, saving, and setting Cookies data.
    """

    def __init__(self, cookies_file):
        self.cookies_file = cookies_file
        self.cookies = {}
        self._lock = threading.Lock()

    def get_cookies(self, reponse):
        if not isinstance(reponse, dict):
            raise TypeError("reponse must be a dict")
        cookies_in = reponse.get('cookies', {})
        if not isinstance(cookies_in, dict):
            raise TypeError("response['cookies'] must be a dict")
        with self._lock:
            # overwrite existing with incoming cookies
            self.cookies = (self.load_cookies() or {}).copy()
            self.cookies.update(cookies_in)
            return self._save_cookies() and self.cookies

    def load_cookies(self):
        with self._lock:
            if not os.path.exists(self.cookies_file):
                self.cookies = {}
                return self.cookies
            try:
                with open(self.cookies_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        self.cookies = data
                    else:
                        self.cookies = {}
            except (IOError, json.JSONDecodeError):
                self.cookies = {}
            return self.cookies

    def _save_cookies(self):
        with self._lock:
            try:
                to_write = self.cookies if isinstance(self.cookies, dict) else {}
                with open(self.cookies_file, 'w', encoding='utf-8') as f:
                    json.dump(to_write, f)
                return True
            except Exception:
                return False