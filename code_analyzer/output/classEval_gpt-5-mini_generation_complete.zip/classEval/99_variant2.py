import zipfile
import os
from pathlib import Path
from typing import List


class ZipFileProcessor:
    """
    This is a compressed file processing class that provides the ability to read and decompress compressed files
    """

    def __init__(self, file_name):
        self.file_name = file_name

    def read_zip_file(self):
        try:
            if not os.path.isfile(self.file_name):
                return None
            if not zipfile.is_zipfile(self.file_name):
                return None
            # Return an open ZipFile object (caller should close)
            return zipfile.ZipFile(self.file_name, mode="r", allowZip64=True)
        except Exception:
            return None

    def extract_all(self, output_path):
        try:
            if not os.path.isfile(self.file_name):
                return False
            if not zipfile.is_zipfile(self.file_name):
                return False
            output_dir = Path(output_path)
            output_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(self.file_name, "r") as z:
                z.extractall(path=str(output_dir))
            return True
        except Exception:
            return False

    def extract_file(self, file_name, output_path):
        try:
            if not os.path.isfile(self.file_name) or not zipfile.is_zipfile(self.file_name):
                return False
            output_dir = Path(output_path)
            output_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(self.file_name, "r") as z:
                # Normalize names
                namelist = z.namelist()
                if file_name in namelist:
                    z.extract(file_name, path=str(output_dir))
                    return True
                # try any match ending with file_name
                matches = [n for n in namelist if n.endswith(file_name)]
                if matches:
                    z.extract(matches[0], path=str(output_dir))
                    return True
            return False
        except Exception:
            return False

    def create_zip_file(self, files: List[str], output_file_name: str):
        try:
            if not files:
                return False
            out = Path(output_file_name)
            if out.is_dir():
                out = out / "archive.zip"
            out.parent.mkdir(parents=True, exist_ok=True)
            if out.suffix.lower() != ".zip":
                out = out.with_suffix(".zip")
            compression = zipfile.ZIP_DEFLATED if hasattr(zipfile, "ZIP_DEFLATED") else zipfile.ZIP_STORED
            added = False
            with zipfile.ZipFile(str(out), "w", compression=compression) as z:
                for f in files:
                    p = Path(f)
                    if p.exists():
                        if p.is_file():
                            z.write(str(p), arcname=str(p.name))
                            added = True
                        else:
                            # add directory recursively preserving relative structure
                            for root, _, fnames in os.walk(p):
                                for fn in fnames:
                                    full = Path(root) / fn
                                    arc = str(full.relative_to(p.parent))
                                    z.write(str(full), arcname=arc)
                                    added = True
            return added
        except Exception:
            return False