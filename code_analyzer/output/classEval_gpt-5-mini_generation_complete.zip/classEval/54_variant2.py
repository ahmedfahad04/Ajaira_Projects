import random
from heapq import heappush, heappop

class MahjongConnect:
    def __init__(self, BOARD_SIZE, ICONS):
        self.BOARD_SIZE = BOARD_SIZE
        self.ICONS = ICONS
        self.board = self.create_board()

    def create_board(self):
        # create a board by randomly assigning icons (not necessarily paired)
        rows, cols = self.BOARD_SIZE
        board = []
        for r in range(rows):
            row = [random.choice(self.ICONS) for _ in range(cols)]
            board.append(row)
        return board

    def in_bounds(self, x, y):
        r, c = self.BOARD_SIZE
        return 0 <= x < r and 0 <= y < c

    def is_valid_move(self, pos1, pos2):
        if pos1 == pos2:
            return False
        x1,y1 = pos1
        x2,y2 = pos2
        if not (self.in_bounds(x1,y1) and self.in_bounds(x2,y2)):
            return False
        if self.board[x1][y1] == ' ' or self.board[x2][y2] == ' ':
            return False
        if self.board[x1][y1] != self.board[x2][y2]:
            return False
        return self.has_path(pos1,pos2)

    def has_path(self, pos1, pos2):
        # Dijkstra-like on turns (cost), prioritize fewer turns
        rows, cols = self.BOARD_SIZE
        x1,y1 = pos1
        x2,y2 = pos2
        if pos1 == pos2:
            return False
        def passable(nx,ny):
            if not (0 <= nx < rows and 0 <= ny < cols):
                return False
            if (nx,ny) == (x2,y2):
                return True
            return self.board[nx][ny] == ' '
        dirs = [(-1,0),(0,1),(1,0),(0,-1)]
        # cost[(x,y,dir)] = cost
        INF = 10**9
        cost = {}
        pq = []
        # start by pushing neighbors
        for d_idx,(dx,dy) in enumerate(dirs):
            nx,ny = x1+dx,y1+dy
            while 0 <= nx < rows and 0 <= ny < cols and passable(nx,ny):
                key = (nx,ny,d_idx)
                if cost.get(key, INF) > 0:
                    cost[key] = 0
                    heappush(pq,(0,nx,ny,d_idx))
                if (nx,ny)==(x2,y2):
                    return True
                nx += dx; ny += dy
        while pq:
            turns,x,y,d = heappop(pq)
            if turns != cost.get((x,y,d), None):
                continue
            if turns > 2:
                continue
            if (x,y) == (x2,y2):
                return True
            for nd,(dx,dy) in enumerate(dirs):
                nturns = turns + (0 if nd==d else 1)
                if nturns > 2:
                    continue
                nx,ny = x+dx,y+dy
                while 0 <= nx < rows and 0 <= ny < cols and passable(nx,ny):
                    key = (nx,ny,nd)
                    if cost.get(key, INF) > nturns:
                        cost[key] = nturns
                        if (nx,ny)==(x2,y2):
                            return True
                        heappush(pq,(nturns,nx,ny,nd))
                    nx+=dx; ny+=dy
        return False

    def remove_icons(self, pos1, pos2):
        if not self.is_valid_move(pos1,pos2):
            return
        x1,y1 = pos1
        x2,y2 = pos2
        self.board[x1][y1] = ' '
        self.board[x2][y2] = ' '

    def is_game_over(self):
        return all(cell == ' ' for row in self.board for cell in row)

# Classification response:
# helper function extraction;heap-based;guard clause;while loop;tuple unpacking;generator expression;dictionary lookup;variable renaming;import reorganization;behavior change