class BitStatusUtil:
    """
    This is a utility class that provides methods for manipulating and checking status using bitwise operations.
    """

    @staticmethod
    def add(states, stat):
        # Parameter validation
        BitStatusUtil.check([states, stat])
        # Adding a status corresponds to bitwise OR
        return states | stat

    @staticmethod
    def has(states, stat):
        BitStatusUtil.check([states, stat])
        # Return True if every bit set in stat is set in states
        return (states & stat) == stat

    @staticmethod
    def remove(states, stat):
        BitStatusUtil.check([states, stat])
        # Remove bits using AND with inverse of stat
        return states & (~stat)

    @staticmethod
    def check(args):
        if args is None:
            return
        for a in args:
            # require integer
            if type(a) is not int:
                raise ValueError(f"{a} not int")
            if a < 0:
                raise ValueError(f"{a} < 0")
            # even check
            if a % 2 != 0:
                raise ValueError(f"{a} not even")