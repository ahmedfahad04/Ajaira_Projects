import re
from functools import reduce

class Words2Numbers:
    """
    The class provides a text-to-number conversion utility, allowing conversion of written numbers (in words) to their numerical representation.
    """

    def __init__(self):
        self.numwords = {}
        self.units = [
            "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
            "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
            "sixteen", "seventeen", "eighteen", "nineteen",
        ]
        self.tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]
        self.scales = ["hundred", "thousand", "million", "billion", "trillion"]

        self.numwords["and"] = (1, 0)
        for idx, w in enumerate(self.units):
            self.numwords[w] = (1, idx)
        for idx, w in enumerate(self.tens):
            if w:
                self.numwords[w] = (1, idx * 10)
        for idx, w in enumerate(self.scales):
            self.numwords[w] = (10 ** (idx * 3 or 2), 0)

        self.ordinal_words = {'first': 1, 'second': 2, 'third': 3, 'fifth': 5, 'eighth': 8, 'ninth': 9, 'twelfth': 12}
        self.ordinal_endings = [('ieth', 'y'), ('th', '')]

    def _split_tokens(self, text):
        t = text.lower().strip()
        t = re.sub(r'[,]', ' ', t)
        parts = re.split(r'\s+|-', t)
        return [p for p in parts if p]

    def _convert_ordinal(self, w):
        if w in self.ordinal_words:
            return (1, self.ordinal_words[w])
        for end, rep in self.ordinal_endings:
            if w.endswith(end):
                base = w[:-len(end)] + rep
                if base in self.numwords:
                    return self.numwords[base]
        return None

    def text2int(self, textnum):
        if not isinstance(textnum, str):
            raise ValueError("Input must be string")
        tokens = self._split_tokens(textnum)
        if not tokens:
            return "0"
        neg = False
        if tokens and tokens[0] in ("minus", "negative"):
            neg = True
            tokens = tokens[1:]
        def step(state, token):
            total, current = state
            if token == "and":
                return (total, current)
            if token in self.numwords:
                scale, inc = self.numwords[token]
            else:
                ov = self._convert_ordinal(token)
                if ov:
                    scale, inc = ov
                else:
                    raise ValueError("Invalid token: {}".format(token))
            if scale > 1:
                if current == 0:
                    current = 1
                current = current * scale
                if scale > 100:
                    total += current
                    current = 0
            else:
                current += inc
            return (total, current)
        total, current = reduce(step, tokens, (0, 0))
        total += current
        if neg:
            total = -total
        return str(total)

    def is_valid_input(self, textnum):
        if not isinstance(textnum, str):
            return False
        if '-' in textnum:
            return False
        tokens = self._split_tokens(textnum)
        if not tokens:
            return False
        for tok in tokens:
            if tok in ("and", "minus", "negative"):
                continue
            if tok in self.numwords or tok in self.ordinal_words:
                continue
            ok = False
            for end, rep in self.ordinal_endings:
                if tok.endswith(end) and (tok[:-len(end)] + rep) in self.numwords:
                    ok = True
                    break
            if not ok:
                return False
        return True