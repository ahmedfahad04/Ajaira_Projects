class BitStatusUtil:
    """
    This is a utility class that provides methods for manipulating and checking status using bitwise operations.
    """

    @staticmethod
    def add(states, stat):
        # validate inputs
        BitStatusUtil.check([states, stat])
        # return combined flags
        return states | stat

    @staticmethod
    def has(states, stat):
        BitStatusUtil.check([states, stat])
        # check that stat bits are included in states
        return bool((states & stat) == stat)

    @staticmethod
    def remove(states, stat):
        BitStatusUtil.check([states, stat])
        # remove bits by masking them out
        return states & ~stat

    @staticmethod
    def check(args):
        if args is None:
            return
        # allow any iterable
        for x in args:
            if not isinstance(x, int):
                raise ValueError(f"{x} is not an integer")
            if x < 0:
                raise ValueError(f"{x} is negative")
            if x & 1:
                # odd number detected
                raise ValueError(f"{x} not even")