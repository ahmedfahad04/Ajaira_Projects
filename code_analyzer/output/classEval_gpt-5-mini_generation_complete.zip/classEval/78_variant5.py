import re

class SplitSentence:
    """
    The class allows to split sentences, count words in a sentence, and process a text file to find the maximum word count.
    """

    def split_sentences(self, sentences_string):
        text = sentences_string or ""
        results = []
        idx = 0
        n = len(text)
        abbrevs = {"mr", "mrs", "dr", "ms", "jr", "sr", "st"}
        while idx < n:
            # find next punctuation mark . or ?
            m = re.search(r'[.?]', text[idx:])
            if not m:
                # remaining tail
                tail = text[idx:].strip()
                if tail:
                    results.append(tail)
                break
            pos = idx + m.start()
            # ensure punctuation is followed by space or end
            if pos + 1 < n and not text[pos+1].isspace():
                idx = pos + 1
                continue
            # check token before dot for abbrev
            # extract last token before the punctuation
            j = pos - 1
            while j >= 0 and text[j].isspace():
                j -= 1
            k = j
            while k >= 0 and text[k].isalpha():
                k -= 1
            word = text[k+1:j+1] if j >= 0 else ""
            if m.group() == '.' and word.lower() in abbrevs:
                idx = pos + 1
                continue
            # capture sentence
            sent = text[:pos+1] if idx == 0 else text[idx:pos+1]
            sent = sent.strip()
            if sent:
                results.append(sent)
            idx = pos + 1
            # skip spaces
            while idx < n and text[idx].isspace():
                idx += 1
        return results

    def count_words(self, sentence):
        if not sentence:
            return 0
        # words separated by spaces; only tokens of letters count
        tokens = sentence.split()
        count = 0
        for t in tokens:
            if re.fullmatch(r'[A-Za-z]+', t):
                count += 1
        return count

    def process_text_file(self, sentences_string):
        max_words = 0
        for s in self.split_sentences(sentences_string):
            max_words = max(max_words, self.count_words(s))
        return max_words