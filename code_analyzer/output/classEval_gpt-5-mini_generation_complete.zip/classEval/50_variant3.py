import json
import os
from collections import deque

class JSONProcessor:
    """
    This is a class to process JSON file, including reading and writing JSON files, as well as processing JSON data by removing a specified key from the JSON object.
    This implementation removes all occurrences of the key recursively.
    """

    def read_json(self, file_path):
        if not isinstance(file_path, str):
            return -1
        if not os.path.exists(file_path):
            return 0
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return -1

    def write_json(self, data, file_path):
        if not isinstance(file_path, str):
            return -1
        try:
            os.makedirs(os.path.dirname(file_path) or '.', exist_ok=True)
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return 1
        except Exception:
            return -1

    def _remove_key_recursive(self, obj, key_to_remove):
        removed = False
        if isinstance(obj, dict):
            if key_to_remove in obj:
                obj.pop(key_to_remove)
                removed = True
            # iterate over a list of keys to avoid runtime dict change issues
            for k, v in list(obj.items()):
                r = self._remove_key_recursive(v, key_to_remove)
                removed = removed or r
        elif isinstance(obj, list):
            for item in obj:
                r = self._remove_key_recursive(item, key_to_remove)
                removed = removed or r
        return removed

    def process_json(self, file_path, remove_key):
        if not isinstance(file_path, str):
            return -1
        data = self.read_json(file_path)
        if data == 0:
            return 0
        if data == -1:
            return -1
        removed_any = self._remove_key_recursive(data, remove_key)
        if not removed_any:
            return 0
        wr = self.write_json(data, file_path)
        return 1 if wr == 1 else -1