import sqlite3
import pandas as pd
import re

class DatabaseProcessor:
    """
    This is a class for processing a database, supporting to create tables, insert data into the database, search for data based on name, and delete data from the database.
    """

    IDENT_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')

    def __init__(self, database_name):
        """
        Initialize database name of database processor
        """
        self.database_name = database_name

    def _validate_identifier(self, name):
        if not isinstance(name, str) or not self.IDENT_RE.match(name):
            raise ValueError(f"Invalid identifier: {name}")
        return name

    def _get_search_column(self, conn, table_name):
        cur = conn.execute(f"PRAGMA table_info('{table_name}')")
        cols = cur.fetchall()
        for col in cols:
            if col[1] != 'id':
                return col[1]
        return None

    def create_table(self, table_name, key1, key2):
        table_name = self._validate_identifier(table_name)
        key1 = self._validate_identifier(key1)
        key2 = self._validate_identifier(key2)
        sql = f'CREATE TABLE IF NOT EXISTS "{table_name}" (id INTEGER PRIMARY KEY, "{key1}" TEXT, "{key2}" INTEGER)'
        with sqlite3.connect(self.database_name) as conn:
            conn.execute(sql)
            conn.commit()

    def insert_into_database(self, table_name, data):
        if not data:
            return
        table_name = self._validate_identifier(table_name)
        if not isinstance(data, list):
            raise ValueError("data must be a list of dicts")
        df = pd.DataFrame.from_records(data)
        if df.empty:
            return
        cols = list(df.columns)
        for c in cols:
            self._validate_identifier(c)
        placeholders = ",".join(["?"] * len(cols))
        col_sql = ",".join([f'"{c}"' for c in cols])
        rows = [tuple(row) for row in df[cols].itertuples(index=False, name=None)]
        sql = f'INSERT INTO "{table_name}" ({col_sql}) VALUES ({placeholders})'
        with sqlite3.connect(self.database_name) as conn:
            conn.executemany(sql, rows)
            conn.commit()

    def search_database(self, table_name, name):
        table_name = self._validate_identifier(table_name)
        with sqlite3.connect(self.database_name) as conn:
            search_col = self._get_search_column(conn, table_name)
            if not search_col:
                return None
            sql = f'SELECT * FROM "{table_name}" WHERE "{search_col}" = ?'
            cur = conn.execute(sql, (name,))
            rows = cur.fetchall()
            return rows if rows else None

    def delete_from_database(self, table_name, name):
        table_name = self._validate_identifier(table_name)
        with sqlite3.connect(self.database_name) as conn:
            search_col = self._get_search_column(conn, table_name)
            if not search_col:
                return
            sql = f'DELETE FROM "{table_name}" WHERE "{search_col}" = ?'
            conn.execute(sql, (name,))
            conn.commit()