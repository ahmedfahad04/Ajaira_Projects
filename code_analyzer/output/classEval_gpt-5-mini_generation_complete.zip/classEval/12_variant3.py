import random
from collections import Counter

class BlackjackGame:
    """
    This is a class representing a game of blackjack, which includes creating a deck, calculating the value of a hand, and determine the winner based on the hand values of the player and dealer.
    """

    def __init__(self):
        self.deck = self.create_deck()
        self.player_hand = []
        self.dealer_hand = []

    def create_deck(self):
        suits = ['S', 'H', 'D', 'C']
        ranks = ['A'] + [str(i) for i in range(2, 11)] + ['J', 'Q', 'K']
        deck = []
        for suit in suits:
            for rank in ranks:
                deck.append(rank + suit)
        random.shuffle(deck)
        return deck

    def calculate_hand_value(self, hand):
        cnt = Counter()
        total = 0
        for card in hand:
            rank = card[:-1]
            if rank == 'A':
                cnt['A'] += 1
                total += 11
            elif rank in ('J', 'Q', 'K'):
                total += 10
            else:
                total += int(rank)
        # Adjust aces from 11 to 1 as needed
        while total > 21 and cnt['A'] > 0:
            total -= 10
            cnt['A'] -= 1
        return total

    def check_winner(self, player_hand, dealer_hand):
        pv = self.calculate_hand_value(player_hand)
        dv = self.calculate_hand_value(dealer_hand)
        # both valid
        if pv <= 21 and dv <= 21:
            if pv == dv:
                return 'Dealer wins'
            return 'Player wins' if pv > dv else 'Dealer wins'
        # someone busted or both busted: smaller total wins
        if pv == dv:
            return 'Dealer wins'
        return 'Player wins' if pv < dv else 'Dealer wins'