import xml.etree.ElementTree as ET


class XMLProcessor:
    """
    This is a class as XML files handler, including reading, writing, processing as well as finding elements in a XML file.
    """

    def __init__(self, file_name):
        """
        Initialize the XMLProcessor object with the given file name.
        :param file_name:string, the name of the XML file to be processed.
        """
        self.file_name = file_name
        self.root = None

    def read_xml(self):
        """
        Reads the XML file and returns the root element.
        :return: Element, the root element of the XML file.
        """
        tree = ET.parse(self.file_name)
        self.root = tree.getroot()
        return self.root

    def write_xml(self, file_name):
        """
        Writes the XML data to the specified file.
        :param file_name: string, the name of the file to write the XML data.
        :return: bool, True if the write operation is successful, False otherwise.
        """
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return False
        try:
            tree = ET.ElementTree(self.root)
            tree.write(file_name, encoding="utf-8", xml_declaration=True)
            return True
        except Exception:
            return False

    def process_xml_data(self, file_name):
        """
        Modifies the data in XML elements and writes the updated XML data to a new file.
        This implementation uppercases all textual content of elements (if present)
        and sets an attribute processed="true" on each element.
        :param file_name: string, the name of the file to write the modified XML data.
        :return: bool, True if the write operation is successful, False otherwise.
        """
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return False
        for elem in self.root.iter():
            # uppercase text content
            if elem.text and elem.text.strip():
                elem.text = elem.text.strip().upper()
            elem.set("processed", "true")
        return self.write_xml(file_name)

    def find_element(self, element_name):
        """
        Finds the XML elements with the specified name.
        :param element_name: string, the name of the elements to find.
        :return: list, a list of found elements with the specified name.
        """
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return []
        # use XPath-like search for descendants
        path = ".//" + element_name
        found = self.root.findall(path)
        return found