from datetime import datetime, timedelta
import bisect

class CalendarUtil:
    """
    This is a class as CalendarUtil that provides functionalities to manage calendar events, schedule appointments, and perform conflict checks.
    """

    def __init__(self):
        """
        Initialize the calendar with an empty list of events.
        """
        # keep events sorted by start_time
        self.events = []  # list of dicts
        self._starts = []  # parallel list of start datetimes for bisect

    def _normalize(self, event):
        ev = event.copy()
        if 'start_time' not in ev or ev['start_time'] is None:
            ev['start_time'] = ev.get('date')
        if 'end_time' not in ev or ev['end_time'] is None:
            st = ev.get('start_time')
            ev['end_time'] = st + timedelta(hours=1) if isinstance(st, datetime) else st
        return ev

    def add_event(self, event):
        """
        Add an event to the calendar.
        """
        ev = self._normalize(event)
        st = ev['start_time']
        # insert while keeping sorted by start_time
        idx = bisect.bisect_left(self._starts, st)
        self._starts.insert(idx, st)
        self.events.insert(idx, ev)

    def remove_event(self, event):
        """
        Remove an event from the calendar.
        """
        # remove first matching event dict (after normalization compare keys)
        for i, e in enumerate(self.events):
            match = True
            for k, v in event.items():
                if k not in e or e[k] != v:
                    match = False
                    break
            if match:
                self.events.pop(i)
                self._starts.pop(i)
                return

    def get_events(self, date):
        """
        Get all events on a given date.
        """
        if isinstance(date, datetime):
            d = date.date()
        else:
            d = date
        res = []
        for e in self.events:
            ed = e.get('date')
            if isinstance(ed, datetime):
                if ed.date() == d:
                    res.append(e)
            else:
                if ed == d:
                    res.append(e)
        return res

    def is_available(self, start_time, end_time):
        """
        Check if the calendar is available for a given time slot.
        """
        # Use binary search to find candidate events
        i = bisect.bisect_left(self._starts, start_time)
        # check event before i and forward until starts >= end_time
        candidates = []
        if i > 0:
            candidates.append(self.events[i - 1])
        j = i
        while j < len(self.events) and self._starts[j] < end_time:
            candidates.append(self.events[j])
            j += 1
        for e in candidates:
            evs = e.get('start_time') or e.get('date')
            eve = e.get('end_time') or evs
            if evs is None or eve is None:
                continue
            if not (end_time <= evs or start_time >= eve):
                return False
        return True

    def get_available_slots(self, date):
        """
        Get all available time slots on a given date.
        """
        if isinstance(date, datetime):
            d = date.date()
        else:
            d = date
        day_start = datetime(d.year, d.month, d.day)
        day_end = day_start + timedelta(days=1)
        # pull events intersecting day (since sorted, find window)
        slots = []
        for e in self.events:
            evs = e.get('start_time') or e.get('date')
            eve = e.get('end_time') or evs
            if evs is None or eve is None:
                continue
            if eve <= day_start or evs >= day_end:
                continue
            slots.append((max(evs, day_start), min(eve, day_end)))
        # merge
        slots.sort(key=lambda x: x[0])
        merged = []
        for s, e in slots:
            if not merged or s > merged[-1][1]:
                merged.append([s, e])
            else:
                if e > merged[-1][1]:
                    merged[-1][1] = e
        free = []
        cur = day_start
        for s, e in merged:
            if cur < s:
                free.append((cur, s))
            cur = max(cur, e)
        if cur < day_end:
            free.append((cur, day_end))
        return free

    def get_upcoming_events(self, num_events):
        """
        Get the next n upcoming events from now.
        """
        now = datetime.now()
        # events already sorted by start_time
        upcoming = [e for e in self.events if (e.get('start_time') or e.get('date')) and (e.get('start_time') or e.get('date')) >= now]
        return upcoming[:num_events]