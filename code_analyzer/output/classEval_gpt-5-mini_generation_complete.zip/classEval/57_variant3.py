import numpy as np
from itertools import accumulate


class MetricsCalculator2:
    """
    The class provides to calculate Mean Reciprocal Rank (MRR) and Mean Average Precision (MAP) based on input data, where MRR measures the ranking quality and MAP measures the average precision.
    """

    def __init__(self):
        pass

    @staticmethod
    def mrr(data):
        if not isinstance(data, list):
            data = [data]
        reciprocals = []
        for entry in data:
            try:
                labels = list(entry[0])
            except Exception:
                reciprocals.append(0.0)
                continue
            rr = 0.0
            for i, v in enumerate(labels, 1):
                if int(v) == 1:
                    rr = 1.0 / i
                    break
            reciprocals.append(rr)
        mean_rr = float(np.mean(reciprocals)) if reciprocals else 0.0
        return mean_rr, reciprocals

    @staticmethod
    def map(data):
        if not isinstance(data, list):
            data = [data]
        ap_list = []
        for entry in data:
            try:
                labels = list(entry[0])
                gt = entry[1]
            except Exception:
                ap_list.append(0.0)
                continue
            if gt == 0:
                ap_list.append(0.0)
                continue
            running = list(accumulate(1 if int(x) == 1 else 0 for x in labels))
            s = 0.0
            for i, v in enumerate(labels, 1):
                if int(v) == 1:
                    s += running[i - 1] / float(i)
            ap = s / float(gt)
            ap_list.append(ap)
        mean_ap = float(np.mean(ap_list)) if ap_list else 0.0
        return mean_ap, ap_list

# Classification response:
# flattened conditional; guard clause; enumerate loop; itertools usage; generator expression; list conversion; accumulator list; prefix/suffix computation; try-except wrapper; error suppression; type conversion; behavior change