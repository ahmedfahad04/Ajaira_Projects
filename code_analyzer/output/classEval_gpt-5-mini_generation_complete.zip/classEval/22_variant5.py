from collections import OrderedDict

class ClassRegistrationSystem:
    """
    This is a class as a class registration system, allowing to register students, register them for classes, retrieve students by major, get a list of all majors, and determine the most popular class within a specific major.
    """

    def __init__(self):
        self.students = []
        self.students_registration_classes = {}

    def register_student(self, student):
        if not isinstance(student, dict) or 'name' not in student or 'major' not in student:
            raise ValueError("student must be a dict with 'name' and 'major'")
        name = student['name']
        if any(s['name'] == name for s in self.students):
            return 0
        self.students.append({'name': name, 'major': student['major']})
        return 1

    def register_class(self, student_name, class_name):
        # keep classes as insertion-order preserving and unique using OrderedDict
        if student_name not in self.students_registration_classes:
            self.students_registration_classes[student_name] = []
        lst = self.students_registration_classes[student_name]
        if class_name not in lst:
            lst.append(class_name)
        return list(lst)

    def get_students_by_major(self, major):
        return [s['name'] for s in self.students if s.get('major') == major]

    def get_all_major(self):
        # use OrderedDict to preserve insertion order of majors
        od = OrderedDict()
        for s in self.students:
            m = s.get('major')
            if m not in od:
                od[m] = True
        return list(od.keys())

    def get_most_popular_class_in_major(self, major):
        # Count classes but resolve ties by the order in which a class attains the maximum count
        students_in_major = [s['name'] for s in self.students if s.get('major') == major]
        counts = {}
        best_class = None
        best_count = 0
        # sequence counter to help stable tie behavior (first to reach max wins)
        seq = 0
        first_to_max = {}
        for student in students_in_major:
            for cls in self.students_registration_classes.get(student, []):
                seq += 1
                counts[cls] = counts.get(cls, 0) + 1
                if counts[cls] > best_count:
                    best_count = counts[cls]
                    best_class = cls
                    first_to_max[cls] = seq
        return best_class