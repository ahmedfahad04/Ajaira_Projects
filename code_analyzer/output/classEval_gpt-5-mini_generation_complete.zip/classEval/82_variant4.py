from dataclasses import dataclass

@dataclass
class _Lot:
    name: str
    price: float
    quantity: int

class StockPortfolioTracker:
    """
    Dataclass-backed holdings, uses average cost update on buys.
    Keeps external portfolio list synced as dicts.
    """

    def __init__(self, cash_balance):
        self._lots = {}  # name -> _Lot
        self.portfolio = []
        self.cash_balance = float(cash_balance)

    def _sync(self):
        self.portfolio = [{"name": lot.name, "price": lot.price, "quantity": lot.quantity} for lot in self._lots.values()]

    def add_stock(self, stock):
        name = stock["name"]
        price = float(stock["price"])
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        if name in self._lots:
            existing = self._lots[name]
            existing.quantity += qty
            existing.price = price
        else:
            self._lots[name] = _Lot(name, price, qty)
        self._sync()
        return True

    def remove_stock(self, stock):
        name = stock["name"]
        price = float(stock["price"])
        qty = int(stock["quantity"])
        if name in self._lots:
            lot = self._lots[name]
            if lot.price == price and lot.quantity == qty:
                del self._lots[name]
                self._sync()
                return True
        return False

    def buy_stock(self, stock):
        name = stock["name"]
        price = float(stock["price"])
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        cost = price * qty
        if self.cash_balance < cost:
            return False
        self.cash_balance -= cost
        if name in self._lots:
            lot = self._lots[name]
            # weighted average price
            total_qty = lot.quantity + qty
            avg_price = ((lot.price * lot.quantity) + (price * qty)) / total_qty if total_qty > 0 else price
            lot.price = avg_price
            lot.quantity = total_qty
        else:
            self._lots[name] = _Lot(name, price, qty)
        self._sync()
        return True

    def sell_stock(self, stock):
        name = stock["name"]
        price = float(stock["price"])
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        if name not in self._lots:
            return False
        lot = self._lots[name]
        if lot.quantity < qty:
            return False
        lot.quantity -= qty
        self.cash_balance += price * qty
        if lot.quantity == 0:
            del self._lots[name]
        self._sync()
        return True

    def calculate_portfolio_value(self):
        holdings_value = sum(lot.price * lot.quantity for lot in self._lots.values())
        return float(self.cash_balance + holdings_value)

    def get_portfolio_summary(self):
        items = [{"name": lot.name, "value": float(lot.price * lot.quantity)} for lot in self._lots.values()]
        return (self.calculate_portfolio_value(), items)

    def get_stock_value(self, stock):
        return float(float(stock["price"]) * int(stock["quantity"]))