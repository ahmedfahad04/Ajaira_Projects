import urllib.parse

class UrlPath:
    """
    The  class is a utility for encapsulating and manipulating the path component of a URL, including adding nodes, parsing path strings, and building path strings with optional encoding.
    """

    def __init__(self):
        """
        Initializes the UrlPath object with an empty list of segments and a flag indicating the presence of an end tag.
        """
        self.segments = []
        self.with_end_tag = False

    def add(self, segment):
        """
        Adds a segment to the list of segments in the UrlPath.
        """
        if segment is None:
            return
        seg = str(segment)
        if seg == '':
            # an empty segment indicates an end tag (trailing slash)
            self.with_end_tag = True
            return
        # normalize any accidental slashes at ends of the provided segment
        seg = seg.strip('/')
        if seg == '':
            self.with_end_tag = True
            return
        self.segments.append(seg)
        # adding a concrete segment implies no automatic trailing slash
        self.with_end_tag = False

    def parse(self, path, charset):
        """
        Parses a given path string and populates the list of segments in the UrlPath.
        """
        self.segments = []
        self.with_end_tag = False
        if path is None:
            return
        # If the input is a full URL, extract only the path part
        try:
            parts = urllib.parse.urlsplit(path)
            path_part = parts.path or ''
        except Exception:
            path_part = path or ''
        if path_part.endswith('/'):
            self.with_end_tag = True
        fixed = self.fix_path(path_part)
        if fixed == '':
            return
        raw_segments = fixed.split('/')
        for raw in raw_segments:
            if raw == '':
                continue
            # decode percent-encoding using requested charset
            seg = urllib.parse.unquote(raw, encoding=charset, errors='strict')
            self.segments.append(seg)

    @staticmethod
    def fix_path(path):
        """
        Fixes the given path string by removing leading and trailing slashes.
        """
        if path is None:
            return ''
        # If it's a full URL, extract the path component
        try:
            parts = urllib.parse.urlsplit(path)
            p = parts.path
            if p is None:
                p = path
        except Exception:
            p = path
        # Remove only leading/trailing slashes; keep internal structure
        return p.strip('/')