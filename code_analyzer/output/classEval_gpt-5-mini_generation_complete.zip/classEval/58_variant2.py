import random
import sys
sys.setrecursionlimit(10000)

class MinesweeperGame:
    """
    This is a class that implements mine sweeping games including minesweeping and winning judgment.
    """

    def __init__(self, n, k) -> None:
        self.n = n
        self.k = k
        self.minesweeper_map = self.generate_mine_sweeper_map()
        self.player_map = self.generate_playerMap()
        self.score = 0

    def generate_mine_sweeper_map(self):
        n, k = self.n, self.k
        grid = [[0 for _ in range(n)] for _ in range(n)]
        mines = set()
        # place mines by random picks until k placed
        while len(mines) < min(k, n * n):
            i = random.randrange(n)
            j = random.randrange(n)
            mines.add((i, j))
        for (i, j) in mines:
            grid[i][j] = 'X'
        for (i, j) in mines:
            for di in (-1, 0, 1):
                for dj in (-1, 0, 1):
                    ni, nj = i + di, j + dj
                    if 0 <= ni < n and 0 <= nj < n and grid[ni][nj] != 'X':
                        grid[ni][nj] += 1
        return grid

    def generate_playerMap(self):
        return [['-' for _ in range(self.n)] for _ in range(self.n)]

    def check_won(self, map):
        # Player wins when all non-mine squares are revealed
        for i in range(self.n):
            for j in range(self.n):
                if self.minesweeper_map[i][j] == 'X':
                    # may remain '-'
                    continue
                if map[i][j] == '-':
                    return False
        return True

    def sweep(self, x, y):
        if not (0 <= x < self.n and 0 <= y < self.n):
            return self.player_map
        if self.player_map[x][y] != '-':
            return self.player_map
        if self.minesweeper_map[x][y] == 'X':
            # reveal mine and lose
            self.player_map[x][y] = 'X'
            return False
        # flood reveal recursively
        newly = 0
        def reveal(i, j):
            nonlocal newly
            if not (0 <= i < self.n and 0 <= j < self.n):
                return
            if self.player_map[i][j] != '-':
                return
            self.player_map[i][j] = self.minesweeper_map[i][j]
            newly += 1
            if self.minesweeper_map[i][j] == 0:
                for di in (-1, 0, 1):
                    for dj in (-1, 0, 1):
                        if di == 0 and dj == 0:
                            continue
                        reveal(i + di, j + dj)
        reveal(x, y)
        self.score += newly
        if self.check_won(self.player_map):
            return True
        return self.player_map

# Classification response:
# variable renaming; import reorganization; accumulator set; guard clause; helper function extraction; recursion with base case; temporary variable; boundary case handling; standard library helper