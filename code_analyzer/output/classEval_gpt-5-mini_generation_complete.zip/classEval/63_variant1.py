import re
from collections import Counter

class NLPDataProcessor2:
    """
    The class processes NLP data by extracting words from a list of strings, calculating the frequency of each word, and returning the top 5 most frequent words.
    """

    _cleanup_re = re.compile(r'[^A-Za-z ]+')

    def process_data(self, string_list):
        words_list = []
        for s in string_list:
            cleaned = self._cleanup_re.sub('', s).lower()
            words = cleaned.split()
            words_list.append(words)
        return words_list

    def calculate_word_frequency(self, words_list):
        flat = []
        first_seen = {}
        idx = 0
        for sub in words_list:
            for w in sub:
                flat.append(w)
                if w not in first_seen:
                    first_seen[w] = idx
                    idx += 1
        if not flat:
            return {}
        cnt = Counter(flat)
        items = sorted(cnt.items(), key=lambda x: (-x[1], first_seen.get(x[0], 0)))
        top = items[:5]
        return {k: v for k, v in top}

    def process(self, string_list):
        words_list = self.process_data(string_list)
        return self.calculate_word_frequency(words_list)

# Classification response:
# import reorganization;constant renaming;literal rewrite;variable renaming;accumulator list;accumulator dict;state variable;membership test;sort key;dict comprehension;early return;empty input handling