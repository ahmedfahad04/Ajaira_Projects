import json
import os

class CookiesUtil:
    """
    This is a class as utility for managing and manipulating Cookies, including methods for retrieving, saving, and setting Cookies data.
    """

    def __init__(self, cookies_file):
        self.cookies_file = cookies_file
        self.cookies = {}

    def get_cookies(self, reponse):
        if not isinstance(reponse, dict):
            raise TypeError("reponse must be a dict")
        raw = reponse.get('cookies', {})
        if raw is None:
            raw = {}
        if not isinstance(raw, dict):
            raise TypeError("response['cookies'] must be a dict")
        cleaned = {}
        for k, v in raw.items():
            if not isinstance(k, str):
                k = str(k)
            if not isinstance(v, str):
                v = str(v)
            cleaned[k] = v
        self.cookies = cleaned
        return self._save_cookies() and self.cookies

    def load_cookies(self):
        if not os.path.exists(self.cookies_file):
            self.cookies = {}
            return self.cookies
        try:
            with open(self.cookies_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if not isinstance(data, dict):
                self.cookies = {}
            else:
                # coerce keys and values to str
                coerced = {}
                for k, v in data.items():
                    coerced[str(k)] = str(v)
                self.cookies = coerced
        except (IOError, json.JSONDecodeError):
            self.cookies = {}
        return self.cookies

    def _save_cookies(self):
        try:
            to_write = {str(k): str(v) for k, v in (self.cookies or {}).items()}
            with open(self.cookies_file, 'w', encoding='utf-8') as f:
                json.dump(to_write, f)
            return True
        except Exception:
            return False