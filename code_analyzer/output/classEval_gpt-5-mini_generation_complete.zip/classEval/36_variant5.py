from datetime import datetime

class EmailClient:
    def __init__(self, addr, capacity) -> None:
        self.addr = addr
        self.capacity = float(capacity)
        self.inbox = []

    def send_to(self, recv, content, size):
        size = float(size)
        if not isinstance(recv, EmailClient):
            return False
        if recv.is_full_with_one_more_email(size):
            return False
        email = {
            'sender': self.addr,
            'receiver': recv.addr,
            'content': content,
            'size': size,
            'time': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'state': 'unread'
        }
        recv.inbox.append(email)
        return True

    def fetch(self):
        # find first unread and mark read
        for i in range(len(self.inbox)):
            if self.inbox[i].get('state') == 'unread':
                self.inbox[i]['state'] = 'read'
                return self.inbox[i]
        return None

    def is_full_with_one_more_email(self, size):
        size = float(size)
        return (self.get_occupied_size() + size) > self.capacity

    def get_occupied_size(self):
        total = sum((float(m.get('size', 0) or 0) for m in self.inbox))
        if total.is_integer():
            return int(total)
        return total

    def clear_inbox(self, size):
        size = float(size)
        # remove from left (oldest) but do it by reconstructing minimal tail to keep
        occupied = self.get_occupied_size()
        if occupied + size <= self.capacity:
            return
        # keep items from the right until we have enough free space
        keep = []
        running = 0.0
        for mail in reversed(self.inbox):
            running += float(mail.get('size', 0) or 0)
            keep.append(mail)
            # if total after removing old items (i.e., sum of keep is new occupied) + size <= capacity
            if running + size <= self.capacity:
                break
        # keep currently has from newest to oldest of the ones we will keep
        self.inbox = list(reversed(keep)) if running + size <= self.capacity else []