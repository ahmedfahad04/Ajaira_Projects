import openpyxl
from openpyxl.utils import get_column_letter
import os


class ExcelProcessor:
    """
    This is a class for processing excel files, including readring and writing excel data, as well as processing specific operations and saving as a new excel file.
    """

    def __init__(self):
        pass

    def read_excel(self, file_name):
        """
        Reading data from Excel files
        :param file_name:str, Excel file name to read
        :return:list of data, Data in Excel
        """
        try:
            wb = openpyxl.load_workbook(file_name, read_only=True, data_only=True)
            ws = wb.active
            data = [tuple(r) for r in ws.iter_rows(values_only=True)]
            return data
        except Exception:
            return []

    def write_excel(self, data, file_name):
        """
        Write data to the specified Excel file
        :param data: list, Data to be written
        :param file_name: str, Excel file name to write to
        :return: 0 or 1, 1 represents successful writing, 0 represents failed writing
        """
        try:
            wb = openpyxl.Workbook()
            ws = wb.active
            if data:
                for row in data:
                    if isinstance(row, dict):
                        # write header then rows if dict (should not normally happen here)
                        headers = list(row.keys())
                        ws.append(headers)
                        break
                if isinstance(data[0], dict):
                    headers = list(data[0].keys())
                    for d in data:
                        ws.append([d.get(h) for h in headers])
                else:
                    for row in data:
                        ws.append(list(row))
            wb.save(file_name)
            return 1
        except Exception:
            return 0

    def process_excel_data(self, N, save_file_name):
        """
        Change the specified column in the Excel file to uppercase
        :param N: int, The serial number of the column that want to change
        :param save_file_name: str, source file name
        :return:(int, str), The former is the return value of write_excel, while the latter is the saved file name of the processed data
        """
        try:
            wb = openpyxl.load_workbook(save_file_name)
            ws = wb.active
            if N < 1:
                raise ValueError("Column index must be >= 1")
            col_letter = get_column_letter(N)
            max_row = ws.max_row
            for r in range(1, max_row + 1):
                cell = ws[f"{col_letter}{r}"]
                if cell.value is not None:
                    cell.value = str(cell.value).upper()
            base, ext = os.path.splitext(save_file_name)
            out = f"{base}_uppercol{N}{ext or '.xlsx'}"
            wb.save(out)
            return 1, out
        except Exception:
            base, ext = os.path.splitext(save_file_name)
            out = f"{base}_uppercol{N}{ext or '.xlsx'}"
            return 0, out