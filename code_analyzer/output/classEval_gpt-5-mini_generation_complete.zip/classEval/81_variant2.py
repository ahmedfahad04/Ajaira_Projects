import math
from collections import Counter

class Statistics3:
    """
    This is a class that implements methods for calculating indicators such as median, mode, correlation matrix, and Z-score in statistics.
    """

    @staticmethod
    def median(data):
        if not data:
            raise ValueError("median requires data")
        d = sorted(data)
        n = len(d)
        half = n // 2
        if n % 2:
            return float(d[half])
        return (d[half - 1] + d[half]) / 2.0

    @staticmethod
    def mode(data):
        if not data:
            return []
        cnt = Counter(data)
        maxfreq = max(cnt.values())
        modes = [k for k, v in cnt.items() if v == maxfreq]
        try:
            return sorted(modes)
        except TypeError:
            return modes

    @staticmethod
    def correlation(x, y):
        if len(x) != len(y):
            raise ValueError("x and y must have same length")
        n = len(x)
        if n < 2:
            return 0.0
        mean_x = sum(x) / n
        mean_y = sum(y) / n
        num = 0.0
        sx = 0.0
        sy = 0.0
        for xi, yi in zip(x, y):
            dx = xi - mean_x
            dy = yi - mean_y
            num += dx * dy
            sx += dx * dx
            sy += dy * dy
        denom = math.sqrt(sx * sy)
        if denom == 0:
            return 0.0
        # numerator is sum(dx*dy); for sample covariance divide by (n-1) but it cancels out in ratio
        return (num / (n - 1)) / (math.sqrt(sx / (n - 1)) * math.sqrt(sy / (n - 1)))

    @staticmethod
    def mean(data):
        if not data:
            raise ValueError("mean requires data")
        return float(sum(data)) / len(data)

    @staticmethod
    def correlation_matrix(data):
        if not data:
            return []
        size = len(data)
        mat = [[0.0] * size for _ in range(size)]
        for i in range(size):
            for j in range(size):
                if i == j:
                    mat[i][j] = 1.0
                else:
                    mat[i][j] = Statistics3.correlation(data[i], data[j])
        return mat

    @staticmethod
    def standard_deviation(data):
        n = len(data)
        if n < 2:
            return 0.0
        mean = Statistics3.mean(data)
        ssd = sum((x - mean) ** 2 for x in data)
        return math.sqrt(ssd / (n - 1))

    @staticmethod
    def z_score(data):
        if not data:
            return []
        m = Statistics3.mean(data)
        sd = Statistics3.standard_deviation(data)
        if sd == 0:
            return [0.0] * len(data)
        return [ (x - m) / sd for x in data ]