class AvgPartition:
    """
    This is a class that partitions the given list into different blocks by specifying the number of partitions, with each block having a uniformly distributed length.
    """

    def __init__(self, lst, limit):
        """
        Initialize the class with the given list and the number of partitions, and check if the number of partitions is greater than 0.
        """
        if not isinstance(limit, int) or limit <= 0:
            raise ValueError("limit must be a positive integer")
        self.lst = list(lst)
        self.limit = limit

    def setNum(self):
        n = len(self.lst)
        base = n // self.limit
        rem = n % self.limit
        return (base, rem)

    def get(self, index):
        if not isinstance(index, int):
            raise TypeError("index must be an integer")
        if index < 0:
            index += self.limit
        if index < 0 or index >= self.limit:
            raise IndexError("partition index out of range")
        base, rem = self.setNum()
        extra = 1 if index < rem else 0
        start = index * base + min(index, rem)
        end = start + base + extra
        return self.lst[start:end]