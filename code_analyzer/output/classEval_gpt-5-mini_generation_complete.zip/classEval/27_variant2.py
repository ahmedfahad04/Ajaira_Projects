from decimal import Decimal, getcontext, InvalidOperation

class CurrencyConverter:
    """
    This is a class for currency conversion, which supports to convert amounts between different currencies, retrieve supported currencies, add new currency rates, and update existing currency rates.
    """
    def __init__(self):
        getcontext().prec = 28
        self.rates = {
            'USD': Decimal('1.0'),
            'EUR': Decimal('0.85'),
            'GBP': Decimal('0.72'),
            'JPY': Decimal('110.15'),
            'CAD': Decimal('1.23'),
            'AUD': Decimal('1.34'),
            'CNY': Decimal('6.40'),
        }

    def convert(self, amount, from_currency, to_currency):
        if from_currency not in self.rates:
            raise ValueError("Unsupported source currency")
        if to_currency not in self.rates:
            raise ValueError("Unsupported target currency")
        try:
            amt = Decimal(str(amount))
        except (InvalidOperation, ValueError):
            raise TypeError("Amount must be numeric")
        rate_from = self.rates[from_currency]
        rate_to = self.rates[to_currency]
        if rate_from == 0:
            raise ZeroDivisionError("Source currency rate is zero")
        # amount * (rate_to / rate_from)
        result = (amt * rate_to) / rate_from
        return float(result)

    def get_supported_currencies(self):
        return list(self.rates.keys())

    def add_currency_rate(self, currency, rate):
        if currency in self.rates:
            return False
        try:
            r = Decimal(str(rate))
        except (InvalidOperation, ValueError):
            raise TypeError("Rate must be numeric")
        self.rates[currency] = r

    def update_currency_rate(self, currency, new_rate):
        if currency not in self.rates:
            return False
        try:
            r = Decimal(str(new_rate))
        except (InvalidOperation, ValueError):
            raise TypeError("new_rate must be numeric")
        self.rates[currency] = r