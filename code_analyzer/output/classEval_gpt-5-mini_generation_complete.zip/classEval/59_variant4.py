from datetime import datetime
import numpy as np
import bisect

class MovieBookingSystem:
    def __init__(self):
        self._by_start = []
        self._start_times = []
        self._map = {}

    def add_movie(self, name, price, start_time, end_time, n):
        st = datetime.strptime(start_time, "%H:%M")
        et = datetime.strptime(end_time, "%H:%M")
        seats = np.zeros((n, n), dtype=float)
        movie = {'name': name, 'price': float(price), 'start_time': st, 'end_time': et, 'seats': seats}
        if name in self._map:
            old = self._map[name]
            idx = self._by_start.index(old)
            self._by_start[idx] = movie
            self._start_times[idx] = st
            self._map[name] = movie
        else:
            pos = bisect.bisect_left(self._start_times, st)
            self._start_times.insert(pos, st)
            self._by_start.insert(pos, movie)
            self._map[name] = movie

    def book_ticket(self, name, seats_to_book):
        movie = self._map.get(name)
        if movie is None:
            return "Movie not found."
        seats = movie['seats']
        rmax, cmax = seats.shape
        for s in seats_to_book:
            if not isinstance(s, tuple) or len(s) != 2:
                return "Booking failed."
            r, c = s
            if not (isinstance(r, int) and isinstance(c, int)):
                return "Booking failed."
            if r < 0 or c < 0 or r >= rmax or c >= cmax:
                return "Booking failed."
            if seats[r, c] != 0.0:
                return "Booking failed."
        for r, c in seats_to_book:
            seats[r, c] = 1.0
        return "Booking success."

    def available_movies(self, start_time, end_time):
        st = datetime.strptime(start_time, "%H:%M")
        et = datetime.strptime(end_time, "%H:%M")
        pos = bisect.bisect_left(self._start_times, st)
        result = []
        for movie in self._by_start[pos:]:
            if movie['start_time'] > et:
                break
            if movie['end_time'] <= et:
                result.append(movie['name'])
        return result

# Classification response:
# variable renaming; import reorganization; guard clause; early return; loop rewrite; tuple unpacking; dictionary lookup; standard library helper; binary search; input validation; boundary case handling; type conversion; type check; temporary variable; membership test