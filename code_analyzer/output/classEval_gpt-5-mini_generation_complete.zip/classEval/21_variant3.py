from datetime import datetime

class Classroom:
    def __init__(self, id):
        self.id = id
        # store as dict key -> (start_min, end_min) to speed checks; allow duplicate names/times as separate entries via list
        self.courses = []

    def _parse(self, t):
        return datetime.strptime(t.strip(), '%H:%M')

    def _minutes(self, t):
        d = self._parse(t)
        return d.hour * 60 + d.minute

    def add_course(self, course):
        for c in self.courses:
            if c['name'] == course.get('name') and c['start_time'] == course.get('start_time') and c['end_time'] == course.get('end_time'):
                return
        self.courses.append(dict(course))

    def remove_course(self, course):
        for i, c in enumerate(self.courses):
            if c['name'] == course.get('name') and c['start_time'] == course.get('start_time') and c['end_time'] == course.get('end_time'):
                del self.courses[i]
                return

    def is_free_at(self, check_time):
        m = self._minutes(check_time)
        return not any(self._minutes(c['start_time']) <= m <= self._minutes(c['end_time']) for c in self.courses)

    def check_course_conflict(self, new_course):
        ns = self._minutes(new_course['start_time'])
        ne = self._minutes(new_course['end_time'])
        for c in self.courses:
            s = self._minutes(c['start_time'])
            e = self._minutes(c['end_time'])
            if ns <= e and ne >= s:
                return False
        return True