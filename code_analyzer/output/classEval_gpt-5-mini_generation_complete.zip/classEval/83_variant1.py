import sqlite3

class StudentDatabaseProcessor:
    """
    This is a class with database operation, including inserting student information, searching for student information by name, and deleting student information by name.
    """

    def __init__(self, database_name):
        """
        Initializes the StudentDatabaseProcessor object with the specified database name.
        :param database_name: str, the name of the SQLite database.
        """
        self.database_name = database_name

    def create_student_table(self):
        """
        Creates a "students" table in the database if it does not exist already.Fields include ID of type int, name of type str, age of type int, gender of type str, and grade of type int
        :return: None
        """
        create_sql = """
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER,
            gender TEXT,
            grade INTEGER
        );
        """
        with sqlite3.connect(self.database_name) as conn:
            conn.execute(create_sql)
            conn.commit()

    def insert_student(self, student_data):
        """
        Inserts a new student into the "students" table.
        :param student_data: dict, a dictionary containing the student's information (name, age, gender, grade).
        :return: None
        """
        if not isinstance(student_data, dict):
            raise ValueError("student_data must be a dict")
        name = student_data.get('name')
        age = student_data.get('age')
        gender = student_data.get('gender')
        grade = student_data.get('grade')
        if name is None:
            raise ValueError("student_data must include 'name'")

        insert_sql = "INSERT INTO students (name, age, gender, grade) VALUES (?, ?, ?, ?);"
        with sqlite3.connect(self.database_name) as conn:
            conn.execute(insert_sql, (name, age, gender, grade))
            conn.commit()

    def search_student_by_name(self, name):
        """
        Searches for a student in the "students" table by their name.
        :param name: str, the name of the student to search for.
        :return: list of tuples, the rows from the "students" table that match the search criteria.
        """
        select_sql = "SELECT id, name, age, gender, grade FROM students WHERE name = ?;"
        with sqlite3.connect(self.database_name) as conn:
            cur = conn.execute(select_sql, (name,))
            rows = cur.fetchall()
        return rows

    def delete_student_by_name(self, name):
        """
        Deletes a student from the "students" table by their name.
        :param name: str, the name of the student to delete.
        :return: None
        """
        delete_sql = "DELETE FROM students WHERE name = ?;"
        with sqlite3.connect(self.database_name) as conn:
            conn.execute(delete_sql, (name,))
            conn.commit()