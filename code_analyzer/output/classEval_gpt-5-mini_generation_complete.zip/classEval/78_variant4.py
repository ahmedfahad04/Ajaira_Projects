import re

class SplitSentence:
    """
    The class allows to split sentences, count words in a sentence, and process a text file to find the maximum word count.
    """

    def split_sentences(self, sentences_string):
        s = sentences_string or ""
        # split on boundary after '.' or '?' when followed by space or end
        parts = re.split(r'(?<=[\.\?])\s+', s)
        if not parts:
            return []
        # re.split keeps punctuation; now we must merge any pieces where the dot belonged to an abbreviation
        abbrevs = {"Mr", "Mrs", "Dr", "Ms", "Jr", "Sr", "St"}
        res = []
        i = 0
        while i < len(parts):
            part = parts[i].strip()
            if not part:
                i += 1
                continue
            # if part ends with abbreviation like "Mr." and there's a next part, merge
            if re.search(r'\b(' + '|'.join(abbrevs) + r')\.$', part):
                if i + 1 < len(parts):
                    merged = (part + " " + parts[i+1]).strip()
                    parts[i+1] = merged
                    i += 1
                    continue
            res.append(part)
            i += 1
        return res

    def count_words(self, sentence):
        if not sentence:
            return 0
        # remove punctuation and numbers, keep only letters and spaces, then split
        cleaned = re.sub(r'[^A-Za-z\s]', ' ', sentence)
        tokens = [t for t in cleaned.split() if t.isalpha()]
        return len(tokens)

    def process_text_file(self, sentences_string):
        sentences = self.split_sentences(sentences_string)
        return max((self.count_words(s) for s in sentences), default=0)