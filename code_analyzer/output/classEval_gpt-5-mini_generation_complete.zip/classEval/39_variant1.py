from collections import deque
import re

class ExpressionCalculator:
    """
    This is a class in Python that can perform calculations with basic arithmetic operations, including addition, subtraction, multiplication, division, and modulo.
    """

    def __init__(self):
        """
        Initialize the expression calculator
        """
        self.postfix_stack = deque()
        # not strictly required by implementation but kept for compatibility
        self.operat_priority = [0, 3, 2, 1, -1, 1, 0, 2]

    def calculate(self, expression):
        """
        Calculate the result of the given postfix expression
        :param expression: string, the postfix expression to be calculated
        :return: float, the calculated result
        """
        self.prepare(self.transform(expression))
        stack = []
        for token in list(self.postfix_stack):
            if token in {'+', '-', '*', '/', '%'}:
                if len(stack) < 2:
                    raise ValueError("Invalid expression")
                b = stack.pop()
                a = stack.pop()
                res = self._calculate(a, b, token)
                stack.append(res)
            else:
                # numeric token
                stack.append(float(token))
        if not stack:
            return 0.0
        return float(stack[-1])

    def prepare(self, expression):
        """
        Prepare the infix expression for conversion to postfix notation
        :param expression: string, the infix expression to be prepared
        """
        # Tokenize: numbers (including decimals), operators, parentheses
        tokens = re.findall(r'\d+\.\d+|\d+|[()+\-*/%]', expression)
        output = []
        ops = []
        prec = {'+': 1, '-': 1, '*': 2, '/': 2, '%': 2}
        for i, tok in enumerate(tokens):
            if re.match(r'^\d+(\.\d+)?$', tok):
                output.append(tok)
            elif tok == '(':
                ops.append(tok)
            elif tok == ')':
                while ops and ops[-1] != '(':
                    output.append(ops.pop())
                if ops and ops[-1] == '(':
                    ops.pop()
            else:  # operator
                # handle unary minus: if at start or previous is operator or '('
                if tok == '-' and (i == 0 or tokens[i-1] in {'(', '+', '-', '*', '/', '%'}):
                    # treat unary minus by pushing a zero before it
                    output.append('0')
                while ops and ops[-1] != '(' and prec.get(ops[-1], 0) >= prec.get(tok, 0):
                    output.append(ops.pop())
                ops.append(tok)
        while ops:
            output.append(ops.pop())
        # store in postfix_stack as deque for compatibility
        self.postfix_stack = deque(output)

    @staticmethod
    def is_operator(c):
        """
        Check if a character is an operator in {'+', '-', '*', '/', '(', ')', '%'}
        """
        return c in {'+', '-', '*', '/', '(', ')', '%'}

    def compare(self, cur, peek):
        """
        Compare precedence: True if current operator has higher or equal precedence than peek
        """
        precedence = {'+': 1, '-': 1, '*': 2, '/': 2, '%': 2}
        return precedence.get(cur, 0) >= precedence.get(peek, 0)

    @staticmethod
    def _calculate(first_value, second_value, current_op):
        """
        Perform the mathematical calculation based on the given operands and operator
        """
        a = float(first_value)
        b = float(second_value)
        if current_op == '+':
            return a + b
        if current_op == '-':
            return a - b
        if current_op == '*':
            return a * b
        if current_op == '/':
            if b == 0:
                raise ZeroDivisionError("division by zero")
            return a / b
        if current_op == '%':
            if b == 0:
                raise ZeroDivisionError("modulo by zero")
            return a % b
        raise ValueError("Unknown operator: " + str(current_op))

    @staticmethod
    def transform(expression):
        """
        Transform the infix expression to a format suitable for conversion
        """
        return ''.join(expression.split())