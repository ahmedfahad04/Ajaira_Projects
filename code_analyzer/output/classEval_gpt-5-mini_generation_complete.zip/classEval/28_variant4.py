import sqlite3
import pandas as pd
import threading

class DatabaseProcessor:
    """
    This is a class for processing a database, supporting to create tables, insert data into the database, search for data based on name, and delete data from the database.
    """

    def __init__(self, database_name):
        """
        Initialize database name of database processor
        """
        self.database_name = database_name
        self.lock = threading.Lock()
        self.conn = sqlite3.connect(self.database_name, check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL")

    def _get_search_column(self, cur, table_name):
        cur.execute(f'PRAGMA table_info("{table_name}")')
        cols = cur.fetchall()
        for c in cols:
            if c[1] != 'id':
                return c[1]
        return None

    def create_table(self, table_name, key1, key2):
        with self.lock:
            cur = self.conn.cursor()
            cur.execute(f'CREATE TABLE IF NOT EXISTS "{table_name}" (id INTEGER PRIMARY KEY, "{key1}" TEXT, "{key2}" INTEGER)')
            self.conn.commit()

    def insert_into_database(self, table_name, data):
        if not data:
            return
        df = pd.DataFrame.from_records(data)
        if df.empty:
            return
        cols = list(df.columns)
        col_sql = ",".join(f'"{c}"' for c in cols)
        placeholders = ",".join("?" for _ in cols)
        rows = [tuple(x) for x in df[cols].itertuples(index=False, name=None)]
        with self.lock:
            cur = self.conn.cursor()
            cur.executemany(f'INSERT INTO "{table_name}" ({col_sql}) VALUES ({placeholders})', rows)
            self.conn.commit()

    def search_database(self, table_name, name):
        with self.lock:
            cur = self.conn.cursor()
            col = self._get_search_column(cur, table_name)
            if col is None:
                return None
            cur.execute(f'SELECT * FROM "{table_name}" WHERE "{col}" = ?', (name,))
            rows = cur.fetchall()
            return rows if rows else None

    def delete_from_database(self, table_name, name):
        with self.lock:
            cur = self.conn.cursor()
            col = self._get_search_column(cur, table_name)
            if col is None:
                return
            cur.execute(f'DELETE FROM "{table_name}" WHERE "{col}" = ?', (name,))
            self.conn.commit()