from decimal import Decimal, getcontext

class StockPortfolioTracker:
    """
    Decimal-backed implementation to reduce floating point rounding issues.
    Exposes portfolio as list of dicts with floats for compatibility.
    """

    def __init__(self, cash_balance):
        getcontext().prec = 28
        self._cash = Decimal(str(cash_balance))
        self._holdings = {}  # name -> {"price": Decimal, "quantity": int}
        self.portfolio = []
        self.cash_balance = float(self._cash)

    def _sync(self):
        self.portfolio = [{"name": name, "price": float(v["price"]), "quantity": v["quantity"]} for name, v in self._holdings.items()]
        self.cash_balance = float(self._cash)

    def add_stock(self, stock):
        name = stock["name"]
        price = Decimal(str(stock["price"]))
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        if name in self._holdings:
            self._holdings[name]["quantity"] += qty
            self._holdings[name]["price"] = price
        else:
            self._holdings[name] = {"price": price, "quantity": qty}
        self._sync()
        return True

    def remove_stock(self, stock):
        name = stock["name"]
        price = Decimal(str(stock["price"]))
        qty = int(stock["quantity"])
        if name in self._holdings:
            h = self._holdings[name]
            if h["price"] == price and h["quantity"] == qty:
                del self._holdings[name]
                self._sync()
                return True
        return False

    def buy_stock(self, stock):
        name = stock["name"]
        price = Decimal(str(stock["price"]))
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        cost = price * qty
        if self._cash < cost:
            return False
        self._cash -= cost
        if name in self._holdings:
            self._holdings[name]["quantity"] += qty
            self._holdings[name]["price"] = price
        else:
            self._holdings[name] = {"price": price, "quantity": qty}
        self._sync()
        return True

    def sell_stock(self, stock):
        name = stock["name"]
        price = Decimal(str(stock["price"]))
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        if name not in self._holdings:
            return False
        if self._holdings[name]["quantity"] < qty:
            return False
        self._holdings[name]["quantity"] -= qty
        self._cash += price * qty
        if self._holdings[name]["quantity"] == 0:
            del self._holdings[name]
        self._sync()
        return True

    def calculate_portfolio_value(self):
        holdings_value = sum(v["price"] * v["quantity"] for v in self._holdings.values())
        total = self._cash + holdings_value
        return float(total)

    def get_portfolio_summary(self):
        items = [{"name": name, "value": float(v["price"] * v["quantity"])} for name, v in self._holdings.items()]
        return (self.calculate_portfolio_value(), items)

    def get_stock_value(self, stock):
        price = Decimal(str(stock["price"]))
        qty = int(stock["quantity"])
        return float(price * qty)