class AssessmentSystem:
    """
    This is a class as an student assessment system, which supports add student, add course score, calculate GPA, and other functions for students and courses.
    """

    def __init__(self):
        """
        Initialize the students dict in assessment system.
        """
        self.students = {}

    def add_student(self, name, grade, major):
        self.students[name] = {'name': name, 'grade': grade, 'major': major, 'courses': {}}

    def add_course_score(self, name, course, score):
        if name not in self.students:
            return
        self.students[name]['courses'][course] = score

    def get_gpa(self, name):
        if name not in self.students:
            return None
        courses = self.students[name]['courses']
        if not courses:
            return None
        total = sum(courses.values())
        count = len(courses)
        return total / count

    def get_all_students_with_fail_course(self):
        failed = []
        for name, info in self.students.items():
            for score in info['courses'].values():
                if score < 60:
                    failed.append(name)
                    break
        return failed

    def get_course_average(self, course):
        total = 0
        count = 0
        for info in self.students.values():
            if course in info['courses']:
                total += info['courses'][course]
                count += 1
        if count == 0:
            return None
        return total / count

    def get_top_student(self):
        top_name = None
        top_gpa = None
        for name in self.students:
            gpa = self.get_gpa(name)
            if gpa is None:
                continue
            if top_gpa is None or gpa > top_gpa:
                top_gpa = gpa
                top_name = name
        return top_name