from datetime import datetime
from collections import deque

class EmailClient:
    def __init__(self, addr, capacity) -> None:
        self.addr = addr
        self.capacity = float(capacity)
        # use deque internally for efficient pops from left, but expose inbox as list via property
        self._inbox = deque()

    @property
    def inbox(self):
        return list(self._inbox)

    @inbox.setter
    def inbox(self, value):
        # accept list-like to set inbox
        self._inbox = deque(value if value is not None else [])

    def send_to(self, recv, content, size):
        size = float(size)
        if not isinstance(recv, EmailClient):
            return False
        if recv.is_full_with_one_more_email(size):
            return False
        email = {
            'sender': self.addr,
            'receiver': recv.addr,
            'content': content,
            'size': size,
            'time': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'state': 'unread'
        }
        recv._inbox.append(email)
        return True

    def fetch(self):
        # iterate left-to-right over deque
        for idx, mail in enumerate(self._inbox):
            if mail.get('state') == 'unread':
                mail['state'] = 'read'
                return mail
        return None

    def is_full_with_one_more_email(self, size):
        size = float(size)
        return (self.get_occupied_size() + size) > self.capacity

    def get_occupied_size(self):
        total = 0.0
        for mail in self._inbox:
            total += float(mail.get('size', 0) or 0)
        if total.is_integer():
            return int(total)
        return total

    def clear_inbox(self, size):
        size = float(size)
        # pop from left until enough room
        while self.is_full_with_one_more_email(size) and self._inbox:
            self._inbox.popleft()