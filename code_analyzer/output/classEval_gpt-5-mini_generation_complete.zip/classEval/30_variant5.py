import numpy as np
import math
from typing import Iterable

class DataStatistics2:
    """
    This is a class for performing data statistics, supporting to get the sum, minimum, maximum, variance, standard deviation, and correlation of a given dataset.
    """

    def __init__(self, data: Iterable):
        """
        Initialize Data List
        :param data:list
        """
        self.data = np.array(list(data), dtype=float)

    def _check(self):
        if self.data.size == 0:
            raise ValueError("empty data provided")

    def get_sum(self):
        self._check()
        s = 0.0
        for v in self.data:
            s += float(v)
        if s.is_integer():
            return int(s)
        return s

    def get_min(self):
        self._check()
        # use sorted view for variety
        return int(self.data.min()) if float(self.data.min()).is_integer() else float(self.data.min())

    def get_max(self):
        self._check()
        return int(self.data.max()) if float(self.data.max()).is_integer() else float(self.data.max())

    def get_variance(self):
        self._check()
        # use numpy built-in but ensure population variance
        var = float(np.mean((self.data - np.mean(self.data)) ** 2))
        return round(var, 2)

    def get_std_deviation(self):
        self._check()
        var = self.get_variance()
        return round(math.sqrt(var), 2)

    def get_correlation(self):
        self._check()
        n = self.data.size
        if n <= 1:
            return 0.0
        x = np.arange(1, n + 1, dtype=float)
        y = self.data.astype(float)
        x_mean = x.mean()
        y_mean = y.mean()
        num = float(((x - x_mean) * (y - y_mean)).sum())
        den = math.sqrt(float(((x - x_mean) ** 2).sum()) * float(((y - y_mean) ** 2).sum()))
        if den == 0.0:
            return 0.0
        return num / den