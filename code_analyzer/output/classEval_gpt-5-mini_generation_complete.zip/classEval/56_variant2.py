class MetricsCalculator:
    """
    The class calculates precision, recall, F1 score, and accuracy based on predicted and true labels.
    """

    def __init__(self):
        """
        Initialize the number of all four samples to 0
        """
        self.true_positives = 0
        self.false_positives = 0
        self.false_negatives = 0
        self.true_negatives = 0

    def update(self, predicted_labels, true_labels):
        """
        Update internal counts using list comprehensions and sums.
        """
        preds = [1 if p == 1 else 0 for p in predicted_labels]
        trues = [1 if t == 1 else 0 for t in true_labels]
        for p, t in zip(preds, trues):
            if p and t:
                self.true_positives += 1
            elif p and not t:
                self.false_positives += 1
            elif not p and t:
                self.false_negatives += 1
            else:
                self.true_negatives += 1

    def _binary_lists(self, predicted_labels, true_labels):
        preds = [1 if p == 1 else 0 for p in predicted_labels]
        trues = [1 if t == 1 else 0 for t in true_labels]
        return preds, trues

    def precision(self, predicted_labels, true_labels):
        preds, trues = self._binary_lists(predicted_labels, true_labels)
        tp = sum(1 for p, t in zip(preds, trues) if p == 1 and t == 1)
        fp = sum(1 for p, t in zip(preds, trues) if p == 1 and t == 0)
        return tp / (tp + fp) if (tp + fp) > 0 else 0.0

    def recall(self, predicted_labels, true_labels):
        preds, trues = self._binary_lists(predicted_labels, true_labels)
        tp = sum(1 for p, t in zip(preds, trues) if p == 1 and t == 1)
        fn = sum(1 for p, t in zip(preds, trues) if p == 0 and t == 1)
        return tp / (tp + fn) if (tp + fn) > 0 else 0.0

    def f1_score(self, predicted_labels, true_labels):
        p = self.precision(predicted_labels, true_labels)
        r = self.recall(predicted_labels, true_labels)
        return (2 * p * r) / (p + r) if (p + r) > 0 else 0.0

    def accuracy(self, predicted_labels, true_labels):
        preds, trues = self._binary_lists(predicted_labels, true_labels)
        correct = sum(1 for p, t in zip(preds, trues) if p == t)
        total = sum(1 for _ in zip(preds, trues))
        return correct / total if total > 0 else 0.0

# Classification response:
# helper function extraction;list comprehension;temporary variable;generator expression;conditional expression;zip usage;builtin function;behavior change