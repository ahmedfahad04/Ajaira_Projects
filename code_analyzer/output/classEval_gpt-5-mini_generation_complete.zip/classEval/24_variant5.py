class ComplexCalculator:
    """
    This is a class that implements addition, subtraction, multiplication, and division operations for complex numbers.
    """

    def __init__(self):
        pass

    @staticmethod
    def _accept(c):
        if isinstance(c, complex):
            return c
        if isinstance(c, (tuple, list)) and len(c) == 2:
            return complex(c[0], c[1])
        if isinstance(c, (int, float)):
            return complex(c, 0)
        raise TypeError("Unsupported type")

    @staticmethod
    def add(c1, c2):
        a = ComplexCalculator._accept(c1)
        b = ComplexCalculator._accept(c2)
        return complex(a.real + b.real, a.imag + b.imag)

    @staticmethod
    def subtract(c1, c2):
        a = ComplexCalculator._accept(c1)
        b = ComplexCalculator._accept(c2)
        return complex(a.real - b.real, a.imag - b.imag)

    @staticmethod
    def multiply(c1, c2):
        a = ComplexCalculator._accept(c1)
        b = ComplexCalculator._accept(c2)
        # compute components explicitly
        ar, ai = a.real, a.imag
        br, bi = b.real, b.imag
        return complex(ar * br - ai * bi, ar * bi + ai * br)

    @staticmethod
    def divide(c1, c2):
        a = ComplexCalculator._accept(c1)
        b = ComplexCalculator._accept(c2)
        br, bi = b.real, b.imag
        denom = br * br + bi * bi
        if denom == 0:
            raise ZeroDivisionError("division by zero")
        ar, ai = a.real, a.imag
        re = (ar * br + ai * bi) / denom
        im = (ai * br - ar * bi) / denom
        return complex(re, im)