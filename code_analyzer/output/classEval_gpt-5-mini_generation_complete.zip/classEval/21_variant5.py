from datetime import datetime

class Classroom:
    def __init__(self, id):
        self.id = id
        self.courses = []

    def _parse_time(self, t):
        return datetime.strptime(t.strip(), '%H:%M')

    def add_course(self, course):
        # treat courses equal if name and times equal
        for c in self.courses:
            if c.get('name') == course.get('name') and c.get('start_time') == course.get('start_time') and c.get('end_time') == course.get('end_time'):
                return
        self.courses.append(dict(course))

    def remove_course(self, course):
        for i, c in enumerate(self.courses):
            if c.get('name') == course.get('name') and c.get('start_time') == course.get('start_time') and c.get('end_time') == course.get('end_time'):
                self.courses.pop(i)
                return

    def is_free_at(self, check_time):
        ct = self._parse_time(check_time)
        for c in self.courses:
            start = self._parse_time(c['start_time'])
            end = self._parse_time(c['end_time'])
            if start <= ct <= end:
                return False
        return True

    def check_course_conflict(self, new_course):
        ns = self._parse_time(new_course['start_time'])
        ne = self._parse_time(new_course['end_time'])
        for c in self.courses:
            s = self._parse_time(c['start_time'])
            e = self._parse_time(c['end_time'])
            # conflict if intervals overlap or touch at boundaries
            if not (ne < s or ns > e):
                return False
        return True