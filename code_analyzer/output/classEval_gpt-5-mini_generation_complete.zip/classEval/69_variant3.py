import PyPDF2

class PDFHandler:
    """
    The class allows merging multiple PDF files into one and extracting text from PDFs using PyPDF2 library.
    """

    def __init__(self, filepaths):
        """
        takes a list of file paths filepaths as a parameter.
        It creates a list named readers using PyPDF2, where each reader opens a file from the given paths.
        """
        self.filepaths = filepaths
        self.readers = [PyPDF2.PdfFileReader(fp) for fp in filepaths]
        self._use_new_api = hasattr(PyPDF2, "PdfReader") and hasattr(PyPDF2, "PdfWriter")

    def merge_pdfs(self, output_filepath):
        if self._use_new_api:
            Writer = PyPDF2.PdfWriter
            WriterObj = Writer()
            for fp in self.filepaths:
                reader = PyPDF2.PdfReader(fp)
                if getattr(reader, "is_encrypted", False):
                    try:
                        reader.decrypt("")
                    except Exception:
                        pass
                for page in getattr(reader, "pages", []):
                    WriterObj.add_page(page)
            with open(output_filepath, "wb") as f:
                WriterObj.write(f)
            return f"Merged PDFs saved at {output_filepath}"
        else:
            writer = PyPDF2.PdfFileWriter()
            for reader in self.readers:
                try:
                    if getattr(reader, "isEncrypted", False):
                        reader.decrypt("")
                except Exception:
                    pass
                for i in range(reader.getNumPages()):
                    writer.addPage(reader.getPage(i))
            with open(output_filepath, "wb") as f:
                writer.write(f)
            return f"Merged PDFs saved at {output_filepath}"

    def extract_text_from_pdfs(self):
        extracted = []
        for fp in self.filepaths:
            text_acc = []
            try:
                if self._use_new_api:
                    r = PyPDF2.PdfReader(fp)
                    if getattr(r, "is_encrypted", False):
                        try:
                            r.decrypt("")
                        except Exception:
                            pass
                    for p in getattr(r, "pages", []):
                        txt = getattr(p, "extract_text", lambda: "")()
                        if txt:
                            text_acc.append(txt)
                else:
                    r = PyPDF2.PdfFileReader(fp)
                    if getattr(r, "isEncrypted", False):
                        try:
                            r.decrypt("")
                        except Exception:
                            pass
                    for i in range(r.getNumPages()):
                        p = r.getPage(i)
                        txt = getattr(p, "extractText", lambda: "")()
                        if txt:
                            text_acc.append(txt)
            except Exception:
                pass
            extracted.append("".join(text_acc))
        return extracted

# Classification response:
# loop rewrite; split condition; exception handling; error suppression; accumulator list; temporary variable; state variable; membership test; boundary case handling