from dataclasses import dataclass

@dataclass
class RPGCharacter:
    """
    The class represents a role-playing game character, which allows to attack other characters, heal, gain experience, level up, and check if the character is alive.
    """
    name: str
    hp: int
    attack_power: int
    defense: int
    level: int = 1

    def __post_init__(self):
        # initial hp value is taken as max_hp
        self.max_hp = self.hp
        self.exp = 0

    def attack(self, other_character):
        damage = self.attack_power - other_character.defense
        if damage < 0:
            damage = 0
        other_character.hp = max(0, other_character.hp - damage)
        return damage

    def heal(self):
        self.hp = min(self.max_hp, self.hp + 10)
        return self.hp

    def _apply_level_increase(self):
        if self.level >= 100:
            return
        self.level += 1
        self.max_hp += 20
        self.hp += 20
        self.attack_power += 5
        self.defense += 5

    def gain_exp(self, amount):
        # procedural approach: consume thresholds iteratively
        self.exp += amount
        while self.level < 100:
            need = 100 * self.level
            if self.exp >= need:
                self.exp -= need
                self._apply_level_increase()
            else:
                break
        if self.level >= 100:
            self.exp = min(self.exp, 100 * self.level)

    def level_up(self):
        if self.level < 100:
            self._apply_level_increase()
        self.exp = 0
        return (self.level, self.hp, self.attack_power, self.defense)

    def is_alive(self):
        return self.hp > 0

# Classification response:
# 