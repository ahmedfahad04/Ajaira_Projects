class SQLGenerator:
    """
    This class generates SQL statements for common operations on a table, such as SELECT, INSERT, UPDATE, and DELETE.
    """

    def __init__(self, table_name):
        self.table_name = table_name

    def _quote(self, value):
        if value is None:
            return "NULL"
        if isinstance(value, (int, float)):
            return str(value)
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        s = str(value)
        return "'" + s.replace("'", "''") + "'"

    def select(self, fields=None, condition=None):
        if fields is None:
            field_list = "*"
        elif isinstance(fields, (list, tuple)) and len(fields) == 0:
            field_list = "*"
        else:
            field_list = ", ".join(fields)
        query = ["SELECT", field_list, "FROM", self.table_name]
        if condition:
            query.extend(["WHERE", condition])
        return " ".join(query) + ";"

    def insert(self, data):
        if not data:
            raise ValueError("insert data required")
        cols = []
        vals = []
        for k, v in data.items():
            cols.append(k)
            vals.append(self._quote(v))
        return "INSERT INTO {} ({}) VALUES ({});".format(self.table_name, ", ".join(cols), ", ".join(vals))

    def update(self, data, condition):
        if not data:
            raise ValueError("update data required")
        parts = []
        for k, v in data.items():
            parts.append(f"{k} = {self._quote(v)}")
        sql = "UPDATE {} SET {}".format(self.table_name, ", ".join(parts))
        if condition:
            sql += " WHERE " + condition
        sql += ";"
        return sql

    def delete(self, condition):
        sql = f"DELETE FROM {self.table_name}"
        if condition:
            sql += " WHERE " + condition
        return sql + ";"

    def select_female_under_age(self, age):
        return f"SELECT * FROM {self.table_name} WHERE age < {int(age)} AND gender = 'female';"

    def select_by_age_range(self, min_age, max_age):
        return f"SELECT * FROM {self.table_name} WHERE age BETWEEN {int(min_age)} AND {int(max_age)};"