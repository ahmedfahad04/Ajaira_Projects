from collections import Counter

class DataStatistics:
    """
    This is a class for performing data statistics, supporting to calculate the mean, median, and mode of a given data set.
    """

    def mean(self, data):
        if not data:
            raise ValueError("data must not be empty")
        total = sum(data)
        avg = total / len(data)
        return round(avg, 2)

    def median(self, data):
        if not data:
            raise ValueError("data must not be empty")
        s = sorted(data)
        n = len(s)
        mid = n // 2
        if n % 2 == 1:
            val = s[mid]
        else:
            val = (s[mid - 1] + s[mid]) / 2.0
        return round(val, 2)

    def mode(self, data):
        if not data:
            raise ValueError("data must not be empty")
        cnt = Counter(data)
        max_freq = max(cnt.values())
        modes = [k for k, v in cnt.items() if v == max_freq]
        return sorted(modes)