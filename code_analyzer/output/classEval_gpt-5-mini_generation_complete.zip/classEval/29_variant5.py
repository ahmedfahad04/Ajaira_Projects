from collections import Counter

class DataStatistics:
    """
    This is a class for performing data statistics, supporting to calculate the mean, median, and mode of a given data set.
    """

    def mean(self, data):
        if not data:
            raise ValueError("data must not be empty")
        # incremental mean to reduce large-sum issues
        n = 0
        m = 0.0
        for x in data:
            n += 1
            m += (x - m) / n
        return round(m, 2)

    def median(self, data):
        if not data:
            raise ValueError("data must not be empty")
        s = sorted(data)
        n = len(s)
        if n & 1:
            res = s[n // 2]
        else:
            res = (s[n // 2 - 1] + s[n // 2]) / 2.0
        return round(res, 2)

    def mode(self, data):
        if not data:
            raise ValueError("data must not be empty")
        cnt = Counter(data)
        if not cnt:
            return []
        most = cnt.most_common()
        maxc = most[0][1]
        modes = [k for k, v in most if v == maxc]
        # ensure unique and sorted
        return sorted(set(modes))