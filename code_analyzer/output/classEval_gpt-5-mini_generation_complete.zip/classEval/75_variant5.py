from collections import OrderedDict
import threading
import copy

class ShoppingCart:
    """
    The class manages items, their prices, quantities, and allows to for add, removie, view items, and calculate the total price.
    """

    def __init__(self):
        """
        Initialize the items representing the shopping list as an empty dictionary
        """
        self.items = OrderedDict()
        self._lock = threading.RLock()

    def add_item(self, item, price, quantity=1):
        with self._lock:
            q = int(quantity)
            if q <= 0:
                return
            p = float(price)
            if item in self.items:
                entry = self.items[item]
                # do not change price if already set; keep original price
                entry["quantity"] += q
            else:
                self.items[item] = {"price": p, "quantity": q}

    def remove_item(self, item, quantity=1):
        with self._lock:
            q = int(quantity)
            if q <= 0:
                return
            if item not in self.items:
                raise KeyError("Item not found")
            if self.items[item]["quantity"] > q:
                self.items[item]["quantity"] -= q
            else:
                del self.items[item]

    def view_items(self) -> dict:
        with self._lock:
            return {k: {"price": v["price"], "quantity": v["quantity"]} for k, v in self.items.items()}

    def total_price(self) -> float:
        with self._lock:
            total = 0.0
            for v in self.items.values():
                total += v["price"] * v["quantity"]
            return float(total)