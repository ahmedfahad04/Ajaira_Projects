class Hotel:
    """
    This is a class as hotel management system, managing the booking, check-in, check-out, and availability of rooms in a hotel with different room types.
    """

    def __init__(self, name, rooms):
        self.name = name
        # store a shallow copy to avoid external mutation surprises
        self.available_rooms = dict(rooms)
        self.booked_rooms = {}

    def book_room(self, room_type, room_number, name):
        if room_type not in self.available_rooms:
            return False
        if room_number <= 0:
            # treat non-positive requests as failure
            return False
        available = self.available_rooms.get(room_type, 0)
        if room_number > available:
            return available if available != 0 else False
        # perform booking
        self.available_rooms[room_type] = available - room_number
        if room_type not in self.booked_rooms:
            self.booked_rooms[room_type] = {}
        self.booked_rooms[room_type][name] = self.booked_rooms[room_type].get(name, 0) + room_number
        return 'Success!'

    def check_in(self, room_type, room_number, name):
        if room_type not in self.booked_rooms:
            return False
        guests = self.booked_rooms[room_type]
        if name not in guests:
            return False
        if room_number <= 0 or room_number > guests[name]:
            return False
        if room_number == guests[name]:
            # remove the guest entry but keep empty dict for the room_type
            guests.pop(name)
            self.booked_rooms[room_type] = dict(guests)
        else:
            guests[name] -= room_number

    def check_out(self, room_type, room_number):
        if room_number <= 0:
            return
        if room_type in self.available_rooms:
            self.available_rooms[room_type] += room_number
        else:
            self.available_rooms[room_type] = room_number

    def get_available_rooms(self, room_type):
        return self.available_rooms.get(room_type, 0)