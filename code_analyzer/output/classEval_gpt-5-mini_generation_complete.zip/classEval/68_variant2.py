class PageUtil:
    """
    PageUtil class is a versatile utility for handling pagination and search functionalities in an efficient and convenient manner.
    """

    def __init__(self, data, page_size):
        self.data = list(data)
        self.page_size = int(page_size) if page_size and int(page_size) > 0 else 1
        self.total_items = len(self.data)
        # Precompute pages for quick access
        self.pages = []
        for i in range(0, self.total_items, self.page_size):
            self.pages.append(self.data[i:i + self.page_size])
        self.total_pages = len(self.pages)

    def get_page(self, page_number):
        try:
            idx = int(page_number) - 1
        except Exception:
            return []
        if idx < 0 or idx >= self.total_pages:
            return []
        return self.pages[idx][:]

    def get_page_info(self, page_number):
        try:
            page_number = int(page_number)
        except Exception:
            page_number = 1
        if self.total_pages == 0:
            return {
                "current_page": 1,
                "per_page": self.page_size,
                "total_pages": 0,
                "total_items": self.total_items,
                "has_previous": False,
                "has_next": False,
                "data": []
            }
        if page_number < 1:
            page_number = 1
        if page_number > self.total_pages:
            page_number = self.total_pages
        data = self.get_page(page_number)
        return {
            "current_page": page_number,
            "per_page": self.page_size,
            "total_pages": self.total_pages,
            "total_items": self.total_items,
            "has_previous": page_number > 1,
            "has_next": page_number < self.total_pages,
            "data": data
        }

    def search(self, keyword):
        kw = "" if keyword is None else str(keyword)
        matches = [x for x in self.data if kw.lower() in str(x).lower()]
        total_results = len(matches)
        total_pages = (total_results + self.page_size - 1) // self.page_size if total_results else 0
        return {
            "keyword": kw,
            "total_results": total_results,
            "total_pages": total_pages,
            "results": matches
        }

# Classification response:
# list conversion; type conversion; accumulator list; list comprehension; copy before mutation; try-except wrapper; default value handling; input validation; boundary case handling; behavior change; membership test; string formatting change