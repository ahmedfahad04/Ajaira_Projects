from decimal import Decimal, InvalidOperation

class BankAccount:
    """
    Decimal-based BankAccount to avoid floating point issues.
    """

    def __init__(self, balance=0):
        try:
            self._balance = Decimal(balance)
        except (InvalidOperation, TypeError):
            raise TypeError("Balance must be numeric")

    def deposit(self, amount):
        try:
            amt = Decimal(amount)
        except (InvalidOperation, TypeError):
            raise TypeError("Amount must be numeric")
        if amt < 0:
            raise ValueError("Invalid amount")
        self._balance += amt
        return self._balance

    def withdraw(self, amount):
        try:
            amt = Decimal(amount)
        except (InvalidOperation, TypeError):
            raise TypeError("Amount must be numeric")
        if amt < 0:
            raise ValueError("Invalid amount")
        if amt > self._balance:
            raise ValueError("Insufficient balance.")
        self._balance -= amt
        return self._balance

    def view_balance(self):
        return self._balance

    def transfer(self, other_account, amount):
        if not isinstance(other_account, BankAccount):
            raise TypeError("other_account must be a BankAccount")
        try:
            amt = Decimal(amount)
        except (InvalidOperation, TypeError):
            raise TypeError("Amount must be numeric")
        if amt < 0:
            raise ValueError("Invalid amount")
        if amt > self._balance:
            raise ValueError("Insufficient balance.")
        self._balance -= amt
        other_account._balance += amt
        return (self._balance, other_account._balance)