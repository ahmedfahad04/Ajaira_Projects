from collections import Counter
import statistics

class DataStatistics:
    """
    This is a class for performing data statistics, supporting to calculate the mean, median, and mode of a given data set.
    """

    def mean(self, data):
        if not data:
            raise ValueError("data must not be empty")
        m = statistics.mean(data)
        # format to two decimals then convert back to float
        return float(f"{m:.2f}")

    def median(self, data):
        if not data:
            raise ValueError("data must not be empty")
        med = statistics.median(sorted(data))
        return float(f"{med:.2f}")

    def mode(self, data):
        if not data:
            raise ValueError("data must not be empty")
        cnt = Counter(data)
        maxc = max(cnt.values())
        modes = [k for k, v in cnt.items() if v == maxc]
        return sorted(modes)