from string import ascii_lowercase, ascii_uppercase

class EncryptionUtils:
    """
    This is a class that provides methods for encryption, including the Caesar cipher, Vigenere cipher, and Rail Fence cipher.
    """

    def __init__(self, key):
        self.key = key or ""

    def caesar_cipher(self, plaintext, shift):
        if shift is None:
            return plaintext
        shift = shift % 26
        lower = ascii_lowercase
        upper = ascii_uppercase
        trans_low = lower[shift:] + lower[:shift]
        trans_up = upper[shift:] + upper[:shift]
        table = str.maketrans(lower + upper, trans_low + trans_up)
        return plaintext.translate(table)

    def vigenere_cipher(self, plaintext):
        # build shifts ignoring non-letters in key
        key_shifts = [ord(c.lower()) - 97 for c in self.key if c.isalpha()]
        if not key_shifts:
            return plaintext
        out = []
        ki = 0
        for ch in plaintext:
            if ch.isalpha():
                s = key_shifts[ki % len(key_shifts)]
                base = 65 if ch.isupper() else 97
                out.append(chr((ord(ch) - base + s) % 26 + base))
                ki += 1
            else:
                out.append(ch)
        return ''.join(out)

    def rail_fence_cipher(self,plain_text, rails):
        if rails is None or rails <= 1:
            return plain_text
        rows = ['' for _ in range(min(rails, len(plain_text)))]
        cur = 0
        direction = 1
        for ch in plain_text:
            rows[cur] += ch
            cur += direction
            if cur == 0 or cur == rails - 1:
                direction *= -1
        return ''.join(rows)