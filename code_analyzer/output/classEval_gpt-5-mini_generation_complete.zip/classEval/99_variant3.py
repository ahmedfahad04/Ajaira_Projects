import zipfile
import os
from io import BufferedReader
from pathlib import Path


class ZipFileProcessor:
    """
    This is a compressed file processing class that provides the ability to read and decompress compressed files
    """

    def __init__(self, file_name):
        self.file_name = file_name

    def read_zip_file(self):
        """
        Return a raw file-like object (opened in binary) if the underlying file is a zip file, else None.
        """
        try:
            if not os.path.exists(self.file_name):
                return None
            # Return raw file object so caller can inspect bytes if needed
            f = open(self.file_name, "rb")
            # Quick check: is zip?
            try:
                if not zipfile.is_zipfile(f):
                    f.close()
                    return None
            except Exception:
                f.close()
                return None
            # Reopen to reset pointer if needed (is_zipfile may read ahead)
            f.close()
            return open(self.file_name, "rb")
        except Exception:
            return None

    def extract_all(self, output_path):
        try:
            if not zipfile.is_zipfile(self.file_name):
                return False
            out_dir = Path(output_path)
            out_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(self.file_name, "r") as zf:
                for member in zf.namelist():
                    # ensure directories exist
                    target = out_dir / member
                    if member.endswith("/"):
                        target.mkdir(parents=True, exist_ok=True)
                zf.extractall(path=str(out_dir))
            return True
        except Exception:
            return False

    def extract_file(self, file_name, output_path):
        try:
            if not zipfile.is_zipfile(self.file_name):
                return False
            out_dir = Path(output_path)
            out_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(self.file_name, "r") as zf:
                # Exact match first
                if file_name in zf.namelist():
                    zf.extract(file_name, path=str(out_dir))
                    return True
                # Try to find by basename
                base = os.path.basename(file_name)
                matches = [n for n in zf.namelist() if os.path.basename(n) == base]
                if matches:
                    zf.extract(matches[0], path=str(out_dir))
                    return True
            return False
        except Exception:
            return False

    def create_zip_file(self, files, output_file_name):
        try:
            out = Path(output_file_name)
            if out.is_dir():
                out = out / "archive.zip"
            out.parent.mkdir(parents=True, exist_ok=True)
            if out.suffix.lower() != ".zip":
                out = out.with_suffix(".zip")
            comp = zipfile.ZIP_DEFLATED if hasattr(zipfile, "ZIP_DEFLATED") else zipfile.ZIP_STORED
            added = False
            with zipfile.ZipFile(str(out), "w", compression=comp) as zf:
                for entry in files:
                    p = Path(entry)
                    if not p.exists():
                        continue
                    if p.is_file():
                        zf.write(str(p), arcname=str(p.name))
                        added = True
                    else:
                        # Add directory contents, preserving relative path under dir name
                        for root, _, filenames in os.walk(p):
                            for fname in filenames:
                                full = Path(root) / fname
                                arcname = str(full.relative_to(p.parent))
                                zf.write(str(full), arcname=arcname)
                                added = True
            return added
        except Exception:
            return False