from collections import Counter
import bisect

class DataStatistics:
    """
    This is a class for performing data statistics, supporting to calculate the mean, median, and mode of a given data set.
    """

    def mean(self, data):
        if not data:
            raise ValueError("data must not be empty")
        total = 0.0
        n = 0
        for x in data:
            total += x
            n += 1
        return round(total / n, 2)

    def median(self, data):
        if not data:
            raise ValueError("data must not be empty")
        sorted_list = []
        for x in data:
            bisect.insort(sorted_list, x)
        n = len(sorted_list)
        mid = n // 2
        if n % 2 == 1:
            val = sorted_list[mid]
        else:
            val = (sorted_list[mid - 1] + sorted_list[mid]) / 2.0
        return round(val, 2)

    def mode(self, data):
        if not data:
            raise ValueError("data must not be empty")
        counts = {}
        for x in data:
            counts[x] = counts.get(x, 0) + 1
        maxc = max(counts.values())
        modes = [k for k, v in counts.items() if v == maxc]
        return sorted(modes)