class BookManagement:
    """
    Simple list-backed implementation storing (title, quantity) pairs in a sorted list.
    """

    def __init__(self):
        """
        Initialize the inventory of Book Manager.
        """
        self._items = []  # list of (title, qty) tuples, kept sorted by title
        self.inventory = {}

    def _find_index(self, title):
        lo = 0
        hi = len(self._items)
        while lo < hi:
            mid = (lo + hi) // 2
            if self._items[mid][0] < title:
                lo = mid + 1
            else:
                hi = mid
        return lo

    def _sync_inventory(self):
        self.inventory = {t: q for t, q in self._items}

    def add_book(self, title, quantity=1):
        if not isinstance(title, str) or not isinstance(quantity, int) or quantity <= 0:
            return False
        idx = self._find_index(title)
        if idx < len(self._items) and self._items[idx][0] == title:
            t, q = self._items[idx]
            self._items[idx] = (t, q + quantity)
        else:
            self._items.insert(idx, (title, quantity))
        self._sync_inventory()
        return True

    def remove_book(self, title, quantity):
        if not isinstance(title, str) or not isinstance(quantity, int) or quantity <= 0:
            return False
        idx = self._find_index(title)
        if idx >= len(self._items) or self._items[idx][0] != title:
            return False
        t, q = self._items[idx]
        if quantity > q:
            return False
        q -= quantity
        if q == 0:
            self._items.pop(idx)
        else:
            self._items[idx] = (t, q)
        self._sync_inventory()
        return True

    def view_inventory(self):
        self._sync_inventory()
        return dict(self.inventory)

    def view_book_quantity(self, title):
        idx = self._find_index(title)
        if idx < len(self._items) and self._items[idx][0] == title:
            return int(self._items[idx][1])
        return 0