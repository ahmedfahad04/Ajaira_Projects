import sqlite3

class BookManagementDB:
    """
    This is a database class as a book management system, used to handle the operations of adding, removing, updating, and searching books.
    """

    def __init__(self, db_name):
        self.connection = sqlite3.connect(db_name)
        self.connection.row_factory = None  # default tuples
        self._cache = []
        self.create_table()
        self._load_cache()

    def create_table(self):
        self.connection.execute("""
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                available INTEGER NOT NULL DEFAULT 1
            )
        """)
        self.connection.commit()

    def _load_cache(self):
        cur = self.connection.execute("SELECT id, title, author, available FROM books ORDER BY id")
        self._cache = cur.fetchall()

    def _update_cache_after_insert(self, rowid):
        cur = self.connection.execute("SELECT id, title, author, available FROM books WHERE id = ?", (rowid,))
        row = cur.fetchone()
        if row:
            self._cache.append(row)

    def _refresh_cache(self):
        self._load_cache()

    def add_book(self, title, author):
        cur = self.connection.execute(
            "INSERT INTO books (title, author, available) VALUES (?, ?, 1)",
            (title, author)
        )
        self.connection.commit()
        rid = cur.lastrowid
        self._update_cache_after_insert(rid)
        return rid

    def remove_book(self, book_id):
        cur = self.connection.execute("DELETE FROM books WHERE id = ?", (book_id,))
        self.connection.commit()
        if cur.rowcount > 0:
            # remove from cache
            self._cache = [r for r in self._cache if r[0] != book_id]
            return True
        return False

    def borrow_book(self, book_id):
        cur = self.connection.execute("UPDATE books SET available = 0 WHERE id = ? AND available = 1", (book_id,))
        self.connection.commit()
        if cur.rowcount > 0:
            # update cache entry
            self._cache = [(rid, t, a, 0) if rid == book_id else (rid, t, a, av) for (rid, t, a, av) in self._cache]
            return True
        return False

    def return_book(self, book_id):
        cur = self.connection.execute("UPDATE books SET available = 1 WHERE id = ? AND available = 0", (book_id,))
        self.connection.commit()
        if cur.rowcount > 0:
            self._cache = [(rid, t, a, 1) if rid == book_id else (rid, t, a, av) for (rid, t, a, av) in self._cache]
            return True
        return False

    def search_books(self):
        # Return a snapshot of cache
        return list(self._cache)