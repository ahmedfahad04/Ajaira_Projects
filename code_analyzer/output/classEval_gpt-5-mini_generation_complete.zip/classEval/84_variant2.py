import json
from pathlib import Path
import re

class TextFileProcessor:
    """
    The class handles reading, writing, and processing text files. It can read the file as JSON, read the raw text, write content to the file, and process the file by removing non-alphabetic characters.
    """

    def __init__(self, file_path):
        self.file_path = Path(file_path)

    def read_file_as_json(self):
        text = self.file_path.read_text(encoding='utf-8')
        return json.loads(text)

    def read_file(self):
        return self.file_path.read_text(encoding='utf-8')

    def write_file(self, content):
        if isinstance(content, (dict, list, int, float, bool)) and not isinstance(content, str):
            data = json.dumps(content)
        elif not isinstance(content, str):
            try:
                data = json.dumps(content)
            except Exception:
                data = str(content)
        else:
            data = content
        self.file_path.write_text(data, encoding='utf-8')

    def process_file(self):
        text = self.read_file()
        processed = re.sub(r'[^A-Za-z]+', '', text)
        self.file_path.write_text(processed, encoding='utf-8')
        return processed