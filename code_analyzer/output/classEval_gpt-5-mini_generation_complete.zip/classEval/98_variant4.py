import xml.etree.ElementTree as ET
import copy


class XMLProcessor:
    """
    XML handler which indents output for readability and returns deep copies of found elements.
    """

    def __init__(self, file_name):
        self.file_name = file_name
        self.root = None

    def _indent(self, elem, level=0):
        i = "\n" + level * "  "
        if len(elem):
            if not elem.text or not elem.text.strip():
                elem.text = i + "  "
            for child in elem:
                self._indent(child, level + 1)
            if not child.tail or not child.tail.strip():
                child.tail = i
        else:
            if level and (not elem.tail or not elem.tail.strip()):
                elem.tail = i

    def read_xml(self):
        tree = ET.parse(self.file_name)
        self.root = tree.getroot()
        return self.root

    def write_xml(self, file_name):
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return False
        try:
            # make a copy to avoid changing internal whitespace
            root_copy = copy.deepcopy(self.root)
            self._indent(root_copy)
            ET.ElementTree(root_copy).write(file_name, encoding="utf-8", xml_declaration=True)
            return True
        except Exception:
            return False

    def process_xml_data(self, file_name):
        """
        Normalize tag names by replacing spaces with underscores and add attribute modified="1".
        """
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return False
        for elem in list(self.root.iter()):
            if " " in elem.tag:
                elem.tag = elem.tag.replace(" ", "_")
            elem.set("modified", "1")
        return self.write_xml(file_name)

    def find_element(self, element_name):
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return []
        found = self.root.findall(".//" + element_name)
        # return deep copies so external mutation won't affect internal state
        return [copy.deepcopy(e) for e in found]