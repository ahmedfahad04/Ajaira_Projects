import random
from collections import deque

class MinesweeperGame:
    """
    This is a class that implements mine sweeping games including minesweeping and winning judgment.
    """

    def __init__(self, n, k) -> None:
        """
        Initializes the MinesweeperGame class with the size of the board and the number of mines.
        :param n: The size of the board, int.
        :param k: The number of mines, int.
        """
        self.n = n
        self.k = k
        self.minesweeper_map = self.generate_mine_sweeper_map()
        self.player_map = self.generate_playerMap()
        self.score = 0

    def generate_mine_sweeper_map(self):
        """
        Generates a minesweeper map with the given size of the board and the number of mines,the given parameter n is the size of the board,the size of the board is n*n,the parameter k is the number of mines,'X' represents the mine,other numbers represent the number of mines around the position.
        :return: The minesweeper map, list.
        """
        n, k = self.n, self.k
        # choose k distinct positions
        all_positions = [(i, j) for i in range(n) for j in range(n)]
        mines = set(random.sample(all_positions, min(k, n * n)))
        grid = [[0 for _ in range(n)] for _ in range(n)]
        for (i, j) in mines:
            grid[i][j] = 'X'
        # count neighbors
        for i in range(n):
            for j in range(n):
                if grid[i][j] == 'X':
                    continue
                cnt = 0
                for di in (-1, 0, 1):
                    for dj in (-1, 0, 1):
                        if di == 0 and dj == 0:
                            continue
                        ni, nj = i + di, j + dj
                        if 0 <= ni < n and 0 <= nj < n and grid[ni][nj] == 'X':
                            cnt += 1
                grid[i][j] = cnt
        return grid

    def generate_playerMap(self):
        """
        Generates a player map with the given size of the board, the given parameter n is the size of the board,the size of the board is n*n,the parameter k is the number of mines,'-' represents the unknown position.
        :return: The player map, list.
        """
        return [['-' for _ in range(self.n)] for _ in range(self.n)]

    def check_won(self, map):
        """
        Checks whether the player has won the game,if there are just mines in the player map,return True,otherwise return False.
        :return: True if the player has won the game, False otherwise.
        """
        for i in range(self.n):
            for j in range(self.n):
                if map[i][j] == '-':
                    if self.minesweeper_map[i][j] != 'X':
                        return False
        return True

    def sweep(self, x, y):
        """
        Sweeps the given position.
        :param x: The x coordinate of the position, int.
        :param y: The y coordinate of the position, int.
        :return: True if the player has won the game, False otherwise,if the game still continues, return the player map, list.
        """
        if not (0 <= x < self.n and 0 <= y < self.n):
            return self.player_map
        if self.player_map[x][y] != '-':
            # already revealed
            return self.player_map
        if self.minesweeper_map[x][y] == 'X':
            # hit mine
            self.player_map[x][y] = 'X'
            return False
        # reveal using BFS for zeros
        revealed = 0
        dq = deque()
        dq.append((x, y))
        while dq:
            i, j = dq.popleft()
            if self.player_map[i][j] != '-':
                continue
            self.player_map[i][j] = self.minesweeper_map[i][j]
            revealed += 1
            # if zero, expand neighbors
            if self.minesweeper_map[i][j] == 0:
                for di in (-1, 0, 1):
                    for dj in (-1, 0, 1):
                        ni, nj = i + di, j + dj
                        if 0 <= ni < self.n and 0 <= nj < self.n and self.player_map[ni][nj] == '-':
                            if (ni, nj) not in dq:
                                dq.append((ni, nj))
        self.score += revealed
        if self.check_won(self.player_map):
            return True
        return self.player_map

# Classification response:
# guard clause; loop rewrite; queue-based; frequency counting; list comprehension; set conversion; tuple unpacking; standard library helper; membership test; input validation; boundary case handling