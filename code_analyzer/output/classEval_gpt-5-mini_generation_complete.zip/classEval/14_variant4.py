import sqlite3

class BookManagementDB:
    """
    This is a database class as a book management system, used to handle the operations of adding, removing, updating, and searching books.
    """

    def __init__(self, db_name):
        self.connection = sqlite3.connect(db_name)
        self.create_table()

    def create_table(self):
        # enforce unique title+author to avoid exact duplicates
        self.connection.execute("""
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                available INTEGER NOT NULL DEFAULT 1,
                UNIQUE(title, author)
            )
        """)
        self.connection.commit()

    def add_book(self, title, author):
        try:
            cur = self.connection.execute(
                "INSERT INTO books (title, author, available) VALUES (?, ?, 1)",
                (title, author)
            )
            self.connection.commit()
            return cur.lastrowid
        except sqlite3.IntegrityError:
            # If duplicate, return existing id
            cur = self.connection.execute(
                "SELECT id FROM books WHERE title = ? AND author = ?",
                (title, author)
            )
            row = cur.fetchone()
            return row[0] if row else None

    def remove_book(self, book_id):
        cur = self.connection.execute("DELETE FROM books WHERE id = ?", (book_id,))
        self.connection.commit()
        return cur.rowcount

    def borrow_book(self, book_id):
        # Use a single SQL statement to change state only if available
        cur = self.connection.execute(
            "UPDATE books SET available = 0 WHERE id = ? AND available = 1",
            (book_id,)
        )
        self.connection.commit()
        return cur.rowcount == 1

    def return_book(self, book_id):
        cur = self.connection.execute(
            "UPDATE books SET available = 1 WHERE id = ? AND available = 0",
            (book_id,)
        )
        self.connection.commit()
        return cur.rowcount == 1

    def search_books(self):
        cur = self.connection.execute("SELECT id, title, author, available FROM books ORDER BY id")
        return cur.fetchall()