import json

class TextFileProcessor:
    """
    The class handles reading, writing, and processing text files. It can read the file as JSON, read the raw text, write content to the file, and process the file by removing non-alphabetic characters.
    """

    def __init__(self, file_path):
        """
        Initialize the file path.
        :param file_path: str
        """
        self.file_path = file_path

    def read_file_as_json(self):
        """
        Read the self.file_path file as json format.
        if the file content doesn't obey json format, the code will raise error.
        :return data: dict if the file is stored as json format, or str/int/float.. according to the file content otherwise.
        """
        with open(self.file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return json.loads(content)

    def read_file(self):
        """
        Read the return the content of self.file_path file.
        :return: the same return as the read() method
        """
        with open(self.file_path, 'r', encoding='utf-8') as f:
            return f.read()

    def write_file(self, content):
        """
        Write content into the self.file_path file, and overwrite if the file has already existed.
        :param content: any content
        """
        to_write = content
        if not isinstance(content, str):
            try:
                to_write = json.dumps(content)
            except Exception:
                to_write = str(content)
        with open(self.file_path, 'w', encoding='utf-8') as f:
            f.write(to_write)

    def process_file(self):
        """
        Read the self.file_path file and filter out non-alphabetic characters from the content string.
        Overwrite the after-processed data into the same self.file_path file.
        """
        text = self.read_file()
        filtered = ''.join(ch for ch in text if ch.isalpha())
        with open(self.file_path, 'w', encoding='utf-8') as f:
            f.write(filtered)
        return filtered