from typing import Dict

class BinaryDataProcessor:
    """
    This is a class used to process binary data, which includes functions such as clearing non 0 or 1 characters, counting binary string information, and converting to corresponding strings based on different encoding methods.
    """

    def __init__(self, binary_string):
        self.binary_string = binary_string or ""
        self.clean_non_binary_chars()

    def clean_non_binary_chars(self):
        # keep only characters '0' and '1'
        self.binary_string = ''.join(ch for ch in self.binary_string if ch in ('0', '1'))

    def calculate_binary_info(self) -> Dict[str, object]:
        s = self.binary_string
        n = len(s)
        if n == 0:
            return {'Zeroes': 0.0, 'Ones': 0.0, 'Bit length': 0}
        zeros = s.count('0')
        ones = s.count('1')
        zero_frac = round(zeros / n + 1e-12, 3)
        one_frac = round(ones / n + 1e-12, 3)
        return {'Zeroes': zero_frac, 'Ones': one_frac, 'Bit length': n}

    def convert_to_ascii(self) -> str:
        # split into 8-bit chunks, ignore incomplete chunk
        s = self.binary_string
        res_chars = []
        for i in range(0, len(s) - (len(s) % 8), 8):
            byte = int(s[i:i+8], 2)
            try:
                res_chars.append(chr(byte))
            except Exception:
                res_chars.append('?')
        return ''.join(res_chars)

    def convert_to_utf8(self) -> str:
        s = self.binary_string
        if not s:
            return ''
        # create bytes by interpreting each full 8-bit chunk
        byte_list = []
        for i in range(0, len(s) - (len(s) % 8), 8):
            byte_list.append(int(s[i:i+8], 2))
        b = bytes(byte_list)
        return b.decode('utf-8', errors='replace')