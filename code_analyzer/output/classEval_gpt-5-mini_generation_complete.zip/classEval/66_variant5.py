import re

class NumericEntityUnescaper:
    """
    This is a class that provides functionality to replace numeric entities with their corresponding characters in a given string.
    """

    def __init__(self):
        pass

    def replace(self, string):
        if string is None:
            return string

        # allow both uppercase and lowercase X and require at least one digit, semicolon optional
        pattern = re.compile(r'&#(x[0-9A-Fa-f]+|\d+);?')

        def to_char(m):
            token = m.group(1)
            try:
                if token.lower().startswith('x'):
                    val = int(token[1:], 16)
                else:
                    val = int(token, 10)
                if 0 <= val <= 0x10FFFF:
                    return chr(val)
                else:
                    # replacement for invalid codepoints
                    return '\uFFFD'
            except Exception:
                return m.group(0)

        return pattern.sub(to_char, string)

    @staticmethod
    def is_hex_char(char):
        return isinstance(char, str) and len(char) == 1 and char.lower() in '0123456789abcdef'

# Classification response:
# regex usage;loop rewrite;early return;helper function extraction;exception handling;membership test;type check;input validation;behavior change;import reorganization