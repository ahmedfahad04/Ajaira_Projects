from PIL import Image, ImageEnhance
import io, os

class ImageProcessor:
    """
    This is a class to process image, including loading, saving, resizing, rotating, and adjusting the brightness of images.
    """

    def __init__(self):
        """
        Initialize self.image
        """
        self.image = None
        self._format = None

    def load_image(self, image_path):
        """
        Use Image util in PIL to open a image
        """
        if image_path is None:
            raise ValueError("image_path cannot be None")
        # Accept file-like objects too
        if hasattr(image_path, "read"):
            img = Image.open(image_path)
        else:
            img = Image.open(str(image_path))
        self._format = img.format
        # keep a copy to ensure independence from the file handle
        self.image = img.copy()
        img.close()
        return self.image

    def save_image(self, save_path):
        """
        Save image to a path if image has opened
        """
        if self.image is None:
            raise RuntimeError("No image loaded")
        # preserve format when possible
        kwargs = {}
        if self._format:
            ext = os.path.splitext(str(save_path))[1].lower()
            if ext:
                kwargs['format'] = None  # let PIL infer by extension
            else:
                kwargs['format'] = self._format
        self.image.save(save_path, **{k: v for k, v in kwargs.items() if v is not None})

    def resize_image(self, width, height):
        """
        Risize the image if image has opened.
        """
        if self.image is None:
            raise RuntimeError("No image loaded")
        if not (isinstance(width, int) and isinstance(height, int)):
            raise TypeError("width and height must be integers")
        if width <= 0 or height <= 0:
            raise ValueError("width and height must be positive")
        # Create a new image and paste scaled version to preserve mode
        resized = self.image.resize((width, height), resample=Image.BILINEAR)
        self.image = resized
        return self.image

    def rotate_image(self, degrees):
        """
        rotate image if image has opened
        """
        if self.image is None:
            raise RuntimeError("No image loaded")
        try:
            deg = float(degrees)
        except Exception:
            raise TypeError("degrees must be numeric")
        # Use expand to avoid cropping
        self.image = self.image.rotate(deg, resample=Image.BICUBIC, expand=True)
        return self.image

    def adjust_brightness(self, factor):
        """
        Adjust the brightness of image if image has opened.
        """
        if self.image is None:
            raise RuntimeError("No image loaded")
        try:
            f = float(factor)
        except Exception:
            raise TypeError("factor must be numeric")
        enhancer = ImageEnhance.Brightness(self.image)
        self.image = enhancer.enhance(f)
        return self.image