import shlex

class ArgumentParser:
    """
    This is a class for parsing command line arguments to a dictionary.
    """

    def __init__(self):
        self.arguments = {}
        self.required = set()
        self.types = {}

    def parse_arguments(self, command_string):
        parts = shlex.split(command_string)
        # skip leading program and script if present (first two tokens) heuristically
        start = 0
        if len(parts) >= 2 and not parts[0].startswith('-') and not parts[1].startswith('-'):
            start = 2
        i = start
        while i < len(parts):
            p = parts[i]
            if not p.startswith('-'):
                i += 1
                continue
            name = p.lstrip('-')
            if '=' in name:
                name, val = name.split('=', 1)
                self.arguments[name] = self._convert_type(name, val)
                i += 1
                continue
            # if next token looks like a value
            if i + 1 < len(parts) and not parts[i + 1].startswith('-'):
                val = parts[i + 1]
                self.arguments[name] = self._convert_type(name, val)
                i += 2
                continue
            # boolean flag
            self.arguments[name] = self._convert_type(name, True)
            i += 1
        missing = {r for r in self.required if r not in self.arguments}
        if missing:
            return (False, missing)
        return (True, None)

    def get_argument(self, key):
        return self.arguments.get(key)

    def add_argument(self, arg, required=False, arg_type=str):
        if required:
            self.required.add(arg)
        if isinstance(arg_type, str):
            choices = {'int': int, 'float': float, 'str': str, 'bool': bool}
            self.types[arg] = choices.get(arg_type, str)
        else:
            self.types[arg] = arg_type

    def _convert_type(self, arg, value):
        typ = self.types.get(arg)
        if typ is None:
            return value
        if typ is bool:
            if isinstance(value, bool):
                return value
            s = str(value).strip().lower()
            if s in ('true', '1', 'on', 'yes', 'y'):
                return True
            if s in ('false', '0', 'off', 'no', 'n'):
                return False
            return True
        try:
            return typ(value)
        except Exception:
            return value