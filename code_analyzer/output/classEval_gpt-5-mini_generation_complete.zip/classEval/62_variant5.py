class NLPDataProcessor:
    """
    The class processes NLP data by removing stop words from a list of strings using a pre-defined stop word list.
    """
    @staticmethod
    def construct_stop_word_list():
        return ['a', 'an', 'the']

    @staticmethod
    def remove_stop_words(string_list, stop_word_list):
        if not string_list:
            return []
        stopset = {w.lower() for w in stop_word_list}
        out = []
        for s in string_list:
            words = s.split()
            filtered = []
            for w in words:
                # compare lower-cased word after trimming common punctuation characters
                left = 0
                right = len(w) - 1
                while left <= right and not w[left].isalnum():
                    left += 1
                while right >= left and not w[right].isalnum():
                    right -= 1
                core = w[left:right+1].lower() if left <= right else ''
                if core and core in stopset:
                    continue
                filtered.append(w)
            out.append(filtered)
        return out

    @staticmethod
    def process(string_list):
        stops = NLPDataProcessor.construct_stop_word_list()
        return NLPDataProcessor.remove_stop_words(string_list, stops)

# Classification response:
# variable renaming; early return; while loop; set conversion; set comprehension; accumulator list; copy before mutation; membership test; empty input handling; temporary variable