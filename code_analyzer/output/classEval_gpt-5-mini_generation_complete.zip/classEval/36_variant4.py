from datetime import datetime

class EmailClient:
    def __init__(self, addr, capacity) -> None:
        self.addr = addr
        self.capacity = float(capacity)
        self.inbox = []
        # cache occupied size for performance
        self._occupied_size = 0.0

    def send_to(self, recv, content, size):
        size = float(size)
        if not isinstance(recv, EmailClient):
            return False
        if recv.is_full_with_one_more_email(size):
            return False
        email = {
            'sender': self.addr,
            'receiver': recv.addr,
            'content': content,
            'size': size,
            'time': datetime.now().isoformat(sep=' ', timespec='seconds'),
            'state': 'unread'
        }
        recv.inbox.append(email)
        recv._occupied_size = getattr(recv, '_occupied_size', 0.0) + size
        return True

    def fetch(self):
        for mail in self.inbox:
            if mail.get('state') == 'unread':
                mail['state'] = 'read'
                return mail
        return None

    def is_full_with_one_more_email(self, size):
        size = float(size)
        return (self.get_occupied_size() + size) > self.capacity

    def get_occupied_size(self):
        # prefer cached value if present and consistent
        total = 0.0
        # calculate real total to keep cache consistent
        for mail in self.inbox:
            try:
                total += float(mail.get('size', 0))
            except Exception:
                pass
        self._occupied_size = total
        if total.is_integer():
            return int(total)
        return total

    def clear_inbox(self, size):
        size = float(size)
        # remove oldest (front) until there's room
        while self.is_full_with_one_more_email(size) and self.inbox:
            removed = self.inbox.pop(0)
            try:
                self._occupied_size = max(0.0, self._occupied_size - float(removed.get('size', 0)))
            except Exception:
                # recompute if something goes wrong
                self.get_occupied_size()