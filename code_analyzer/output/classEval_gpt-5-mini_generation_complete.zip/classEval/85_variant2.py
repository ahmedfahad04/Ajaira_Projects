import time

class Thermostat:
    """
    The class manages temperature control, including setting and retrieving the target temperature, adjusting the mode, and simulating temperature operation.
    """

    def __init__(self, current_temperature, target_temperature, mode):
        self.current_temperature = float(current_temperature)
        self.target_temperature = float(target_temperature)
        self.mode = mode

    def get_target_temperature(self):
        return self.target_temperature

    def set_target_temperature(self, temperature):
        self.target_temperature = float(temperature)

    def get_mode(self):
        return self.mode

    def set_mode(self, mode):
        if mode not in ('heat', 'cool'):
            raise ValueError("Mode must be 'heat' or 'cool'")
        self.mode = mode

    def auto_set_mode(self):
        if self.current_temperature < self.target_temperature:
            self.mode = 'heat'
        else:
            self.mode = 'cool'

    def auto_check_conflict(self):
        if self.current_temperature < self.target_temperature:
            if self.mode != 'heat':
                self.auto_set_mode()
                return False
            return True
        else:
            if self.mode != 'cool':
                self.auto_set_mode()
                return False
            return True

    def simulate_operation(self):
        self.auto_set_mode()
        steps = 0
        # determine direction from mode
        direction = 1.0 if self.mode == 'heat' else -1.0
        # loop until reached target; last step may be fractional but counts as one
        while True:
            diff = self.target_temperature - self.current_temperature
            if abs(diff) < 1e-9:
                break
            step_size = 1.0 if abs(diff) >= 1.0 else abs(diff)
            self.current_temperature += direction * step_size
            steps += 1
            # clamp tiny floating point drift
            if (direction > 0 and self.current_temperature > self.target_temperature) or (direction < 0 and self.current_temperature < self.target_temperature):
                self.current_temperature = float(self.target_temperature)
                break
        return steps