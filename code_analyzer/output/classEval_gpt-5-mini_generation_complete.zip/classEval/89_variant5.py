import random
import re
import ast

class TwentyFourPointGame:
    """
    This ia a game of twenty-four points, which provides to generate four numbers and check whether player's expression is equal to 24.
    """

    def __init__(self) -> None:
        self.nums = []

    def _generate_cards(self):
        self.nums = [random.randint(1,9) for _ in range(4)]
        return self.nums

    def get_my_cards(self):
        # always return four random numbers (regenerate each call for variety)
        return self._generate_cards()

    def _extract_ints(self, expression):
        return [int(x) for x in re.findall(r'\d+', expression)]

    def _validate_chars(self, expression):
        allowed = set("0123456789+-*/() \t")
        return all(c in allowed for c in expression)

    def _ast_is_safe(self, node):
        if isinstance(node, ast.Expression):
            return self._ast_is_safe(node.body)
        if isinstance(node, ast.BinOp):
            return self._ast_is_safe(node.left) and self._ast_is_safe(node.right) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div))
        if isinstance(node, ast.UnaryOp):
            return isinstance(node.op, (ast.UAdd, ast.USub)) and self._ast_is_safe(node.operand)
        if isinstance(node, (ast.Num, ast.Constant)):
            return True
        return False

    def evaluate_expression(self, expression):
        if not self._validate_chars(expression):
            return False
        try:
            tree = ast.parse(expression, mode='eval')
            if not self._ast_is_safe(tree):
                return False
            value = eval(compile(tree, '<eval>', 'eval'), {"__builtins__": None}, {})
            return abs(value - 24) < 1e-9
        except Exception:
            return False

    def answer(self, expression):
        if not self.nums:
            self._generate_cards()
        nums_in_expr = self._extract_ints(expression)
        if len(nums_in_expr) != 4:
            return False
        if sorted(nums_in_expr) != sorted(self.nums):
            return False
        return self.evaluate_expression(expression)