class Hotel:
    """
    This is a class as hotel management system, managing the booking, check-in, check-out, and availability of rooms in a hotel with different room types.
    """

    def __init__(self, name, rooms):
        self.name = name
        # copy to avoid mutating provided dict externally
        self.available_rooms = {k: int(v) for k, v in rooms.items()}
        self.booked_rooms = {}

    def book_room(self, room_type, room_number, name):
        try:
            requested = int(room_number)
        except Exception:
            return False
        if requested <= 0:
            return False
        available = self.available_rooms.get(room_type)
        if available is None:
            return False
        if requested > available:
            return available if available != 0 else False
        # commit booking
        self.available_rooms[room_type] = available - requested
        if room_type not in self.booked_rooms:
            self.booked_rooms[room_type] = {}
        self.booked_rooms[room_type][name] = self.booked_rooms[room_type].get(name, 0) + requested
        return 'Success!'

    def check_in(self, room_type, room_number, name):
        try:
            num = int(room_number)
        except Exception:
            return False
        if num <= 0:
            return False
        if room_type not in self.booked_rooms:
            return False
        guests = self.booked_rooms[room_type]
        if name not in guests:
            return False
        if num > guests[name]:
            return False
        if num == guests[name]:
            # remove guest entry, keep empty dict for room_type
            guests.pop(name)
            self.booked_rooms[room_type] = {}
        else:
            guests[name] -= num

    def check_out(self, room_type, room_number):
        try:
            num = int(room_number)
        except Exception:
            return
        if num <= 0:
            return
        self.available_rooms[room_type] = self.available_rooms.get(room_type, 0) + num

    def get_available_rooms(self, room_type):
        return int(self.available_rooms.get(room_type, 0))