from urllib.parse import urlparse, parse_qsl, unquote_plus

class URLHandler:
    """
    The class supports to handle URLs, including extracting the scheme, host, path, query parameters, and fragment.
    """

    def __init__(self, url):
        """
        Initialize URLHandler's URL
        """
        self.url = url or ""
        self._p = urlparse(self.url)

    def get_scheme(self):
        return self._p.scheme

    def get_host(self):
        return self._p.netloc

    def get_path(self):
        path = self._p.path or ""
        query = self._p.query
        frag = self._p.fragment
        res = path
        if query:
            res += "?" + query
        if frag:
            res += "#" + frag
        return res

    def get_query_params(self):
        """
        Return a dict of query parameters keeping the first occurrence of each key.
        """
        qsl = parse_qsl(self._p.query, keep_blank_values=True)
        params = {}
        for k, v in qsl:
            if k not in params:
                # decode explicitly to handle plus signs
                params[k] = unquote_plus(v)
        return params

    def get_fragment(self):
        return self._p.fragment