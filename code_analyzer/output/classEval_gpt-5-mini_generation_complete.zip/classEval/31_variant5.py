import math

class DataStatistics4:
    """
    This is a class that performs advanced mathematical calculations and statistics, including correlation coefficient, skewness, kurtosis, and probability density function (PDF) for a normal distribution.
    A compact implementation using list comprehensions and defensive handling for degenerate inputs.
    """

    @staticmethod
    def correlation_coefficient(data1, data2):
        if len(data1) != len(data2):
            raise ValueError("Lists must be same length")
        n = len(data1)
        if n == 0:
            raise ValueError("Lists must be non-empty")
        mean1 = sum(data1) / n
        mean2 = sum(data2) / n
        num = sum((x - mean1) * (y - mean2) for x, y in zip(data1, data2))
        ss1 = sum((x - mean1) ** 2 for x in data1)
        ss2 = sum((y - mean2) ** 2 for y in data2)
        denom = math.sqrt(ss1 * ss2)
        return 0.0 if denom == 0 else num / denom

    @staticmethod
    def skewness(data):
        n = len(data)
        if n == 0:
            raise ValueError("Input must be non-empty")
        mu = sum(data) / n
        diffs = [x - mu for x in data]
        m2 = sum(d * d for d in diffs) / n
        m3 = sum(d * d * d for d in diffs) / n
        if m2 == 0:
            return 0.0
        # population skewness
        skew = m3 / (m2 ** 1.5)
        # try to provide a small-sample correction when possible
        if n > 2:
            skew = math.sqrt(n * (n - 1)) / (n - 2) * skew
        return skew

    @staticmethod
    def kurtosis(data):
        n = len(data)
        if n == 0:
            raise ValueError("Input must be non-empty")
        mu = sum(data) / n
        diffs = [x - mu for x in data]
        m2 = sum(d * d for d in diffs) / n
        m4 = sum((d ** 4) for d in diffs) / n
        if m2 == 0:
            return -3.0
        excess = m4 / (m2 * m2) - 3.0
        return excess

    @staticmethod
    def pdf(data, mu, sigma):
        if sigma <= 0:
            raise ValueError("sigma must be > 0")
        a = 1.0 / (sigma * math.sqrt(2 * math.pi))
        b = 2.0 * sigma * sigma
        return [a * math.exp(-((x - mu) ** 2) / b) for x in data]