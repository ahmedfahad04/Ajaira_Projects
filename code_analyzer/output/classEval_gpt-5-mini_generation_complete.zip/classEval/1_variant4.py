import math
class AreaCalculator:
    """
    This is a class for calculating the area of different shapes, including circle, sphere, cylinder, sector and annulus.
    """

    def __init__(self, radius):
        """
        Initialize the radius for shapes.
        :param radius: float
        """
        self.radius = radius

    @staticmethod
    def _circle_area_from(radius):
        return math.pi * (radius ** 2)

    @staticmethod
    def _sphere_area_from(radius):
        return 4.0 * math.pi * (radius ** 2)

    @staticmethod
    def _cylinder_area_from(radius, height):
        return 2.0 * math.pi * radius * (radius + height)

    @staticmethod
    def _sector_area_from(radius, angle):
        return 0.5 * (radius ** 2) * angle

    @staticmethod
    def _annulus_area_from(inner, outer):
        return math.pi * ((outer ** 2) - (inner ** 2))

    def calculate_circle_area(self):
        """
        calculate the area of circle based on self.radius
        :return: area of circle, float
        """
        return AreaCalculator._circle_area_from(self.radius)

    def calculate_sphere_area(self):
        """
        calculate the area of sphere based on self.radius
        :return: area of sphere, float
        """
        return AreaCalculator._sphere_area_from(self.radius)

    def calculate_cylinder_area(self, height):
        """
        calculate the area of cylinder based on self.radius and height
        :param height: height of cylinder, float
        :return: area of cylinder, float
        """
        return AreaCalculator._cylinder_area_from(self.radius, height)

    def calculate_sector_area(self, angle):
        """
        calculate the area of sector based on self.radius and angle
        :param angle: angle of sector, float
        :return: area of sector, float
        """
        return AreaCalculator._sector_area_from(self.radius, angle)

    def calculate_annulus_area(self, inner_radius, outer_radius):
        """
        calculate the area of annulus based on inner_radius and out_radius
        :param inner_radius: inner radius of sector, float
        :param outer_radius: outer radius of sector, float
        :return: area of annulus, float
        """
        return AreaCalculator._annulus_area_from(inner_radius, outer_radius)