import re
from urllib.parse import unquote_plus

class URLHandler:
    """
    The class supports to handle URLs, including extracting the scheme, host, path, query parameters, and fragment.
    """

    _RE = re.compile(
        r'^(?:(?P<scheme>[^:/?#]+):)?'       # scheme
        r'(?://(?P<host>[^/?#]*))?'         # host
        r'(?P<path>[^?#]*)'                 # path
        r'(?:\?(?P<query>[^#]*))?'          # query
        r'(?:#(?P<fragment>.*))?'           # fragment
        r'$'
    )

    def __init__(self, url):
        """
        Initialize URLHandler's URL
        """
        self.url = url or ""
        self._m = self._RE.match(self.url) or None

    def _group(self, name):
        if not self._m:
            return ""
        return self._m.group(name) or ""

    def get_scheme(self):
        return self._group('scheme')

    def get_host(self):
        return self._group('host')

    def get_path(self):
        path = self._group('path') or ""
        query = self._group('query')
        fragment = self._group('fragment')
        out = path
        if query:
            out += "?" + query
        if fragment:
            out += "#" + fragment
        return out

    def get_query_params(self):
        q = self._group('query')
        if not q:
            return {}
        params = {}
        for part in q.split('&'):
            if part == '':
                continue
            if '=' in part:
                k, v = part.split('=', 1)
                k = unquote_plus(k)
                v = unquote_plus(v)
            else:
                k = unquote_plus(part)
                v = ''
            # keep last occurrence (overwrite)
            params[k] = v
        return params

    def get_fragment(self):
        return self._group('fragment')