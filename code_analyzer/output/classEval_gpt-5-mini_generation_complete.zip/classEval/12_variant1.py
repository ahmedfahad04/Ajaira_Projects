import random
class BlackjackGame:
    """
    This is a class representing a game of blackjack, which includes creating a deck, calculating the value of a hand, and determine the winner based on the hand values of the player and dealer.
    """

    def __init__(self):
        self.deck = self.create_deck()
        self.player_hand = []
        self.dealer_hand = []

    def create_deck(self):
        ranks = ['A'] + [str(i) for i in range(2, 11)] + ['J', 'Q', 'K']
        suits = ['S', 'H', 'D', 'C']
        deck = [r + s for s in suits for r in ranks]
        random.shuffle(deck)
        return deck

    def calculate_hand_value(self, hand):
        total = 0
        aces = 0
        for card in hand:
            rank = card[:-1]
            if rank in ('J', 'Q', 'K'):
                total += 10
            elif rank == 'A':
                total += 11
                aces += 1
            else:
                total += int(rank)
        while total > 21 and aces > 0:
            total -= 10
            aces -= 1
        return total

    def check_winner(self, player_hand, dealer_hand):
        pv = self.calculate_hand_value(player_hand)
        dv = self.calculate_hand_value(dealer_hand)
        # both <= 21: closer to 21 wins
        if pv <= 21 and dv <= 21:
            pdiff = 21 - pv
            ddiff = 21 - dv
            if pdiff < ddiff:
                return 'Player wins'
            else:
                return 'Dealer wins'
        else:
            # otherwise lower value wins
            if pv < dv:
                return 'Player wins'
            else:
                return 'Dealer wins'