from datetime import datetime

class Classroom:
    """
    This is a class representing a classroom, capable of adding and removing courses, checking availability at a given time, and detecting conflicts when scheduling new courses.
    """

    def __init__(self, id):
        self.id = id
        self.courses = []

    def _to_minutes(self, t):
        dt = datetime.strptime(t.strip(), '%H:%M')
        return dt.hour * 60 + dt.minute

    def add_course(self, course):
        if course not in self.courses:
            self.courses.append(course)

    def remove_course(self, course):
        try:
            self.courses.remove(course)
        except ValueError:
            pass

    def is_free_at(self, check_time):
        m = self._to_minutes(check_time)
        for c in self.courses:
            start = self._to_minutes(c['start_time'])
            end = self._to_minutes(c['end_time'])
            if start <= m <= end:
                return False
        return True

    def check_course_conflict(self, new_course):
        ns = self._to_minutes(new_course['start_time'])
        ne = self._to_minutes(new_course['end_time'])
        for c in self.courses:
            s = self._to_minutes(c['start_time'])
            e = self._to_minutes(c['end_time'])
            if not (ne < s or ns > e):
                return False
        return True