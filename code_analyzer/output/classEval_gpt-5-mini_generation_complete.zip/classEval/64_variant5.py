class NumberConverter:
    """
    The class allows to convert  decimal to binary, octal and hexadecimal repectively and contrarily
    """

    @staticmethod
    def decimal_to_binary(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        n = decimal_num
        if n == 0:
            return '0'
        sign = '-' if n < 0 else ''
        n = abs(n)
        bits = []
        bl = n.bit_length()
        for i in range(bl - 1, -1, -1):
            bits.append('1' if (n >> i) & 1 else '0')
        return sign + ''.join(bits)

    @staticmethod
    def binary_to_decimal(binary_num):
        if isinstance(binary_num, int):
            binary_num = str(binary_num)
        s = binary_num.strip()
        if s == '':
            raise ValueError("empty")
        sign = 1
        if s[0] in '+-':
            if s[0] == '-':
                sign = -1
            s = s[1:]
        s = s.lstrip('0')
        if s == '':
            return 0
        total = 0
        for ch in s:
            if ch not in '01':
                raise ValueError("invalid binary digit")
            total = (total << 1) | (1 if ch == '1' else 0)
        return sign * total

    @staticmethod
    def decimal_to_octal(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        n = decimal_num
        if n == 0:
            return '0'
        sign = '-' if n < 0 else ''
        n = abs(n)
        parts = []
        while n:
            parts.append(str(n & 7))
            n >>= 3
        return sign + ''.join(reversed(parts))

    @staticmethod
    def octal_to_decimal(octal_num):
        if isinstance(octal_num, int):
            octal_num = str(octal_num)
        s = octal_num.strip()
        if s == '':
            raise ValueError("empty")
        sign = 1
        if s[0] in '+-':
            if s[0] == '-':
                sign = -1
            s = s[1:]
        s = s.strip()
        if s.startswith('0o') or s.startswith('0O'):
            s = s[2:]
        s = s.lstrip('0')
        if s == '':
            return 0
        total = 0
        for ch in s:
            if not ('0' <= ch <= '7'):
                raise ValueError("invalid octal digit")
            total = (total << 3) + (ord(ch) - ord('0'))
        return sign * total

    @staticmethod
    def decimal_to_hex(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        n = decimal_num
        if n == 0:
            return '0'
        sign = '-' if n < 0 else ''
        n = abs(n)
        hexdigits = []
        while n:
            rem = n & 15
            if rem < 10:
                hexdigits.append(chr(ord('0') + rem))
            else:
                hexdigits.append(chr(ord('a') + rem - 10))
            n >>= 4
        return sign + ''.join(reversed(hexdigits))

    @staticmethod
    def hex_to_decimal(hex_num):
        if isinstance(hex_num, int):
            hex_num = format(hex_num, 'x')
        s = hex_num.strip()
        if s == '':
            raise ValueError("empty")
        sign = 1
        if s[0] in '+-':
            if s[0] == '-':
                sign = -1
            s = s[1:]
        if s.startswith('0x') or s.startswith('0X'):
            s = s[2:]
        s = s.lstrip('0')
        if s == '':
            return 0
        total = 0
        for ch in s:
            low = ch.lower()
            if '0' <= low <= '9':
                v = ord(low) - ord('0')
            elif 'a' <= low <= 'f':
                v = ord(low) - ord('a') + 10
            else:
                raise ValueError("invalid hex digit")
            total = (total << 4) + v
        return sign * total

# Classification response:
# manual base conversion; input validation; type check; type conversion; empty input handling; guard clause; exception handling; for loop; while loop; accumulator list; temporary variable; join/split usage; membership test; formatting only