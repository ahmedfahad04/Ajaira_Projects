class BoyerMooreSearch:
    """
    his is a class that implements the Boyer-Moore algorithm for string searching, which is used to find occurrences of a pattern within a given text.
    """

    def __init__(self, text, pattern):
        """
        Initializes the BoyerMooreSearch class with the given text and pattern.
        :param text: The text to be searched, str.
        :param pattern: The pattern to be searched for, str.
        """
        self.text, self.pattern = text, pattern
        self.textLen, self.patLen = len(text), len(pattern)
        # last occurrence computed using reversed traversal to emphasize rightmost index
        self._last = {}
        for i, ch in enumerate(self.pattern):
            self._last[ch] = i

    def match_in_pattern(self, char):
        """
        Finds the rightmost occurrence of a character in the pattern.
        """
        # use dict directly
        return self._last.get(char, -1)

    def mismatch_in_text(self, currentPos):
        """
        Determines the position of the first dismatch between the pattern and the text.
        """
        if self.patLen == 0:
            return -1
        # manual unrolled-like loop from right to left
        for offset in range(self.patLen):
            j = self.patLen - 1 - offset
            t_index = currentPos + j
            if t_index >= self.textLen or self.text[t_index] != self.pattern[j]:
                return j
        return -1

    def bad_character_heuristic(self):
        """
        Finds all occurrences of the pattern in the text.
        """
        if self.patLen == 0:
            return list(range(self.textLen + 1))
        res = []
        i = 0
        while i <= self.textLen - self.patLen:
            j = self.mismatch_in_text(i)
            if j == -1:
                res.append(i)
                # shift by pattern length minus last occurrence of last char in the window
                last_char = self.text[i + self.patLen - 1]
                last_idx = self._last.get(last_char, -1)
                shift = self.patLen - last_idx
                if shift < 1:
                    shift = 1
                i += shift
            else:
                bad = self.text[i + j]
                last_idx = self._last.get(bad, -1)
                shift = j - last_idx
                if shift < 1:
                    shift = 1
                i += shift
        return res