class EightPuzzle:
    """
    This class is an implementation of the classic 8-puzzle game, including methods for finding the blank tile, making moves, getting possible moves, and solving the puzzle using a breadth-first search algorithm.
    """

    def __init__(self, initial_state):
        self.initial_state = initial_state
        self.goal_state = [[1,2,3],[4,5,6],[7,8,0]]

    def find_blank(self, state):
        for i in range(3):
            for j in range(3):
                if state[i][j] == 0:
                    return (i,j)
        return None

    def move(self, state, direction):
        i,j = self.find_blank(state)
        new = [row[:] for row in state]
        if direction == 'up' and i>0:
            new[i][j], new[i-1][j] = new[i-1][j], new[i][j]
        elif direction == 'down' and i<2:
            new[i][j], new[i+1][j] = new[i+1][j], new[i][j]
        elif direction == 'left' and j>0:
            new[i][j], new[i][j-1] = new[i][j-1], new[i][j]
        elif direction == 'right' and j<2:
            new[i][j], new[i][j+1] = new[i][j+1], new[i][j]
        return new

    def get_possible_moves(self, state):
        i,j = self.find_blank(state)
        # return in natural order: up, down, left, right
        moves = []
        if i-1 >= 0:
            moves.append('up')
        if i+1 < 3:
            moves.append('down')
        if j-1 >= 0:
            moves.append('left')
        if j+1 < 3:
            moves.append('right')
        return moves

    def _is_solvable(self, state):
        flat = [n for row in state for n in row if n != 0]
        inv = 0
        for i in range(len(flat)):
            for j in range(i+1, len(flat)):
                if flat[i] > flat[j]:
                    inv += 1
        # goal has 0 inversions -> even parity
        return inv % 2 == 0

    def solve(self):
        if self.initial_state == self.goal_state:
            return []
        if not self._is_solvable(self.initial_state):
            return []
        def key(s):
            return tuple(x for row in s for x in row)
        start = key(self.initial_state)
        goal = key(self.goal_state)
        queue = [start]
        came_from = {start: None}
        move_from = {start: None}
        while queue:
            cur = queue.pop(0)
            cur_state = [list(cur[i*3:(i+1)*3]) for i in range(3)]
            for m in self.get_possible_moves(cur_state):
                nxt_state = self.move(cur_state, m)
                nxt = key(nxt_state)
                if nxt in came_from:
                    continue
                came_from[nxt] = cur
                move_from[nxt] = m
                if nxt == goal:
                    path = []
                    node = nxt
                    while move_from[node] is not None:
                        path.append(move_from[node])
                        node = came_from[node]
                    return list(reversed(path))
                queue.append(nxt)
        return []