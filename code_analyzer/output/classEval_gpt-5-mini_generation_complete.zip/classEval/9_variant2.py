class BigNumCalculator:
    """
    This is a class that implements big number calculations, including adding, subtracting and multiplying.
    """

    @staticmethod
    def _strip(s):
        if not s:
            return "0"
        sign = ""
        if s[0] == "+":
            s = s[1:]
        if s[0] == "-":
            sign = "-"
            s = s[1:]
        s = s.lstrip("0")
        if s == "":
            return "0"
        return (sign + s) if sign == "-" else s

    @staticmethod
    def _add_abs(a, b):
        a = a[::-1]
        b = b[::-1]
        carry = 0
        res = []
        for i in range(max(len(a), len(b))):
            da = int(a[i]) if i < len(a) else 0
            db = int(b[i]) if i < len(b) else 0
            s = da + db + carry
            res.append(str(s % 10))
            carry = s // 10
        if carry:
            res.append(str(carry))
        return "".join(res[::-1])

    @staticmethod
    def _cmp_abs(a, b):
        if len(a) != len(b):
            return 1 if len(a) > len(b) else -1
        if a == b:
            return 0
        return 1 if a > b else -1

    @staticmethod
    def _sub_abs(a, b):
        # assume a >= b
        a = a[::-1]
        b = b[::-1]
        carry = 0
        res = []
        for i in range(len(a)):
            da = int(a[i])
            db = int(b[i]) if i < len(b) else 0
            val = da - db - carry
            if val < 0:
                val += 10
                carry = 1
            else:
                carry = 0
            res.append(str(val))
        while len(res) > 1 and res[-1] == "0":
            res.pop()
        return "".join(res[::-1])

    @staticmethod
    def add(num1, num2):
        n1 = BigNumCalculator._strip(num1)
        n2 = BigNumCalculator._strip(num2)
        sign1 = "-" if n1.startswith("-") else "+"
        sign2 = "-" if n2.startswith("-") else "+"
        if n1.startswith("-"):
            n1 = n1[1:]
        if n2.startswith("-"):
            n2 = n2[1:]
        if sign1 == sign2:
            res = BigNumCalculator._add_abs(n1, n2)
            if res == "0":
                return "0"
            return ("-" + res) if sign1 == "-" else res
        else:
            cmp = BigNumCalculator._cmp_abs(n1, n2)
            if cmp == 0:
                return "0"
            if cmp > 0:
                res = BigNumCalculator._sub_abs(n1, n2)
                return ("-" + res) if sign1 == "-" else res
            else:
                res = BigNumCalculator._sub_abs(n2, n1)
                return ("-" + res) if sign2 == "-" else res

    @staticmethod
    def subtract(num1, num2):
        if num2.startswith("-"):
            n2 = num2[1:]
        else:
            n2 = "-" + num2
        return BigNumCalculator.add(num1, n2)

    @staticmethod
    def multiply(num1, num2):
        n1 = BigNumCalculator._strip(num1)
        n2 = BigNumCalculator._strip(num2)
        neg = False
        if n1.startswith("-"):
            neg = not neg
            n1 = n1[1:]
        if n2.startswith("-"):
            neg = not neg
            n2 = n2[1:]
        if n1 == "0" or n2 == "0":
            return "0"
        a = [int(x) for x in n1[::-1]]
        b = [int(x) for x in n2[::-1]]
        res = [0] * (len(a) + len(b))
        for i in range(len(a)):
            carry = 0
            for j in range(len(b)):
                res[i + j] += a[i] * b[j]
                # carry handled below
            # normalize
        carry = 0
        for k in range(len(res)):
            total = res[k] + carry
            res[k] = total % 10
            carry = total // 10
        while carry:
            res.append(carry % 10)
            carry //= 10
        while len(res) > 1 and res[-1] == 0:
            res.pop()
        s = "".join(str(d) for d in res[::-1])
        return ("-" + s) if neg else s