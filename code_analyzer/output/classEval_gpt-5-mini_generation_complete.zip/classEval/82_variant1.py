class StockPortfolioTracker:
    """
    This is a class as StockPortfolioTracker that allows to add stocks, remove stocks, buy stocks, sell stocks, calculate the total value of the portfolio, and obtain a summary of the portfolio.
    """

    def __init__(self, cash_balance):
        """
        Initialize the StockPortfolioTracker class with a cash balance and an empty portfolio.
        """
        self.portfolio = []
        self.cash_balance = float(cash_balance)

    def add_stock(self, stock):
        """
        Add a stock to the portfolio.
        """
        name = stock["name"]
        price = float(stock["price"])
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        # merge by name: update quantity and latest price
        for s in self.portfolio:
            if s["name"] == name:
                s["quantity"] += qty
                s["price"] = price
                return True
        self.portfolio.append({"name": name, "price": price, "quantity": qty})
        return True

    def remove_stock(self, stock):
        """
        Remove a stock from the portfolio.
        """
        # remove if exact match exists
        for i, s in enumerate(self.portfolio):
            if s["name"] == stock["name"] and float(s["price"]) == float(stock["price"]) and int(s["quantity"]) == int(stock["quantity"]):
                self.portfolio.pop(i)
                return True
        return False

    def buy_stock(self, stock):
        """
        Buy a stock and add it to the portfolio.
        """
        name = stock["name"]
        price = float(stock["price"])
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        cost = price * qty
        if self.cash_balance < cost:
            return False
        self.cash_balance -= cost
        # merge by name: update quantity and price to latest
        for s in self.portfolio:
            if s["name"] == name:
                s["quantity"] += qty
                s["price"] = price
                return True
        self.portfolio.append({"name": name, "price": price, "quantity": qty})
        return True

    def sell_stock(self, stock):
        """
        Sell a stock and remove it from the portfolio and add the cash to the cash balance.
        """
        name = stock["name"]
        price = float(stock["price"])
        qty = int(stock["quantity"])
        if qty <= 0 or price < 0:
            return False
        for s in self.portfolio:
            if s["name"] == name:
                if s["quantity"] < qty:
                    return False
                s["quantity"] -= qty
                self.cash_balance += price * qty
                if s["quantity"] == 0:
                    self.portfolio.remove(s)
                return True
        return False

    def calculate_portfolio_value(self):
        """
        Calculate the total value of the portfolio.
        """
        holdings_value = sum(float(s["price"]) * int(s["quantity"]) for s in self.portfolio)
        return float(self.cash_balance + holdings_value)

    def get_portfolio_summary(self):
        """
        Get a summary of the portfolio.
        """
        holdings = []
        for s in self.portfolio:
            holdings.append({"name": s["name"], "value": float(s["price"]) * int(s["quantity"])})
        total = self.calculate_portfolio_value()
        return (total, holdings)

    def get_stock_value(self, stock):
        """
        Get the value of a stock.
        """
        return float(float(stock["price"]) * int(stock["quantity"]))