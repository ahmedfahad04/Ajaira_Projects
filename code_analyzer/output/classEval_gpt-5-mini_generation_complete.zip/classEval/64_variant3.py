class NumberConverter:
    """
    The class allows to convert  decimal to binary, octal and hexadecimal repectively and contrarily
    """

    @staticmethod
    def decimal_to_binary(decimal_num):
        # recursive approach
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        def rec(n):
            if n < 2:
                return '1' if n == 1 else '0'
            q, r = divmod(n, 2)
            prefix = rec(q)
            if prefix == '0':
                prefix = ''
            return prefix + str(r)
        if decimal_num == 0:
            return '0'
        sign = '-' if decimal_num < 0 else ''
        return sign + rec(abs(decimal_num))

    @staticmethod
    def binary_to_decimal(binary_num):
        if isinstance(binary_num, int):
            binary_num = str(binary_num)
        s = binary_num.strip()
        if s == '':
            raise ValueError("empty")
        sign = 1
        if s[0] in '+-':
            if s[0] == '-':
                sign = -1
            s = s[1:]
        res = 0
        for ch in s:
            if ch not in '01':
                raise ValueError("invalid binary digit")
            res = res * 2 + (ord(ch) - 48)
        return sign * res

    @staticmethod
    def decimal_to_octal(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        def rec(n):
            if n < 8:
                return str(n)
            q, r = divmod(n, 8)
            return rec(q) + str(r)
        if decimal_num == 0:
            return '0'
        sign = '-' if decimal_num < 0 else ''
        return sign + rec(abs(decimal_num))

    @staticmethod
    def octal_to_decimal(octal_num):
        if isinstance(octal_num, int):
            octal_num = str(octal_num)
        s = octal_num.strip()
        if s == '':
            raise ValueError("empty")
        sign = 1
        if s[0] in '+-':
            if s[0] == '-':
                sign = -1
            s = s[1:]
        res = 0
        for ch in s:
            if ch < '0' or ch > '7':
                raise ValueError("invalid octal digit")
            res = res * 8 + (ord(ch) - 48)
        return sign * res

    @staticmethod
    def decimal_to_hex(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        digits = "0123456789abcdef"
        def rec(n):
            if n < 16:
                return digits[n]
            q, r = divmod(n, 16)
            return rec(q) + digits[r]
        if decimal_num == 0:
            return '0'
        sign = '-' if decimal_num < 0 else ''
        return sign + rec(abs(decimal_num))

    @staticmethod
    def hex_to_decimal(hex_num):
        if isinstance(hex_num, int):
            hex_num = format(hex_num, 'x')
        s = hex_num.strip()
        if s == '':
            raise ValueError("empty")
        sign = 1
        if s[0] in '+-':
            if s[0] == '-':
                sign = -1
            s = s[1:]
        res = 0
        for ch in s:
            low = ch.lower()
            if '0' <= low <= '9':
                val = ord(low) - ord('0')
            elif 'a' <= low <= 'f':
                val = ord(low) - ord('a') + 10
            else:
                raise ValueError("invalid hex digit")
            res = res * 16 + val
        return sign * res

# Classification response:
# recursion; helper function extraction; guard clause; early return; tuple unpacking; accumulator string; temporary variable; membership test; builtin function; input validation; empty input handling; type conversion; positional digit evaluation