import random
import re
from itertools import permutations, product

class TwentyFourPointGame:
    """
    This ia a game of twenty-four points, which provides to generate four numbers and check whether player's expression is equal to 24.
    """

    def __init__(self) -> None:
        self.nums = []

    def _generate_cards(self):
        self.nums = [random.randint(1,9) for _ in range(4)]
        return self.nums

    def get_my_cards(self):
        if not self.nums:
            self._generate_cards()
        return list(self.nums)

    def evaluate_expression(self, expression):
        # permissive numeric check via eval but only after simple character validation
        # allow digits, spaces, parentheses and +-*/.
        if not all(c.isdigit() or c.isspace() or c in "+-*/()" for c in expression):
            return False
        try:
            val = eval(expression, {"__builtins__": None}, {})
            return abs(val - 24) < 1e-9
        except Exception:
            return False

    def _extract_numbers(self, expression):
        return [int(x) for x in re.findall(r'\d+', expression)]

    def answer(self, expression):
        if not self.nums:
            self._generate_cards()
        numbers = self._extract_numbers(expression)
        if len(numbers) != 4:
            return False
        if sorted(numbers) != sorted(self.nums):
            return False
        return self.evaluate_expression(expression)

    # Extra utility: brute-force solver (not required but provides alternative check)
    def has_solution(self):
        if not self.nums:
            self._generate_cards()
        ops = ['+','-','*','/']
        def valid(a,b,op):
            try:
                if op == '+': return a + b
                if op == '-': return a - b
                if op == '*': return a * b
                if op == '/':
                    if abs(b) < 1e-12: return None
                    return a / b
            except Exception:
                return None
        for nums_perm in permutations(self.nums):
            a,b,c,d = nums_perm
            for op1,op2,op3 in product(ops,repeat=3):
                # all parenthesizations
                exprs = [
                    f"(({a}{op1}{b}){op2}{c}){op3}{d}",
                    f"({a}{op1}({b}{op2}{c})){op3}{d}",
                    f"{a}{op1}(({b}{op2}{c}){op3}{d})",
                    f"{a}{op1}({b}{op2}({c}{op3}{d}))",
                    f"({a}{op1}{b}){op2}({c}{op3}{d})"
                ]
                for e in exprs:
                    try:
                        if abs(eval(e, {"__builtins__": None}, {}) - 24) < 1e-9:
                            return True
                    except Exception:
                        continue
        return False