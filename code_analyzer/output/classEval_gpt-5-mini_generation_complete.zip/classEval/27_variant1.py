class CurrencyConverter:
    """
    This is a class for currency conversion, which supports to convert amounts between different currencies, retrieve supported currencies, add new currency rates, and update existing currency rates.
    """

    def __init__(self):
        """
        Initialize the exchange rate of the US dollar against various currencies
        """
        self.rates = {
            'USD': 1.0,
            'EUR': 0.85,
            'GBP': 0.72,
            'JPY': 110.15,
            'CAD': 1.23,
            'AUD': 1.34,
            'CNY': 6.40,
        }

    def convert(self, amount, from_currency, to_currency):
        """
        Convert the value of a given currency to another currency type
        """
        if not isinstance(amount, (int, float)):
            raise TypeError("amount must be a number")
        if from_currency not in self.rates:
            raise ValueError(f"Unsupported source currency: {from_currency}")
        if to_currency not in self.rates:
            raise ValueError(f"Unsupported target currency: {to_currency}")
        if self.rates[from_currency] == 0:
            raise ZeroDivisionError("Source currency rate is zero")
        # Convert amount to USD, then to target
        amount_in_usd = amount / self.rates[from_currency]
        result = amount_in_usd * self.rates[to_currency]
        return float(result)

    def get_supported_currencies(self):
        """
        Returns a list of supported currency types
        """
        return list(self.rates.keys())

    def add_currency_rate(self, currency, rate):
        """
        Add a new supported currency type, return False if the currency type is already in the support list
        """
        if currency in self.rates:
            return False
        if not isinstance(rate, (int, float)):
            raise TypeError("rate must be a number")
        self.rates[currency] = float(rate)

    def update_currency_rate(self, currency, new_rate):
        """
        Update the exchange rate for a certain currency
        """
        if currency not in self.rates:
            return False
        if not isinstance(new_rate, (int, float)):
            raise TypeError("new_rate must be a number")
        self.rates[currency] = float(new_rate)