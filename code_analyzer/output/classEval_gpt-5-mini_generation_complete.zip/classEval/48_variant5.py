import socket
import netifaces


class IpUtil:
    """
    This is a class as tool for ip that can be used to obtain the local IP address, validate its validity, and also provides the functionality to retrieve the corresponding hostname.
    """

    @staticmethod
    def is_valid_ipv4(ip_address):
        if not isinstance(ip_address, str):
            return False
        parts = ip_address.split('.')
        if len(parts) != 4:
            return False
        for part in parts:
            if not part.isdigit():
                return False
            num = int(part)
            if num < 0 or num > 255:
                return False
            if part != '0' and part.startswith('0'):
                # allow '0' but disallow leading zeros like '01'
                return False
        return True

    @staticmethod
    def is_valid_ipv6(ip_address):
        if not isinstance(ip_address, str):
            return False
        try:
            socket.inet_pton(socket.AF_INET6, ip_address)
            return True
        except Exception:
            return False

    @staticmethod
    def get_hostname(ip_address):
        try:
            name = socket.gethostbyaddr(ip_address)[0]
            if name and name != ip_address:
                return name
        except Exception:
            pass
        try:
            for iface in netifaces.interfaces():
                addrs = netifaces.ifaddresses(iface)
                for family, infos in addrs.items():
                    for info in infos:
                        addr = info.get('addr')
                        if addr and addr.split('%')[0] == ip_address:
                            return iface
        except Exception:
            pass
        return None