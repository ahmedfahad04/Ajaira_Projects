class PushBoxGame:
    """
    This class implements a functionality of a sokoban game, where the player needs to move boxes to designated targets in order to win.
    """
    def __init__(self, map):
        self.map = map
        self.player_row = 0
        self.player_col = 0
        self.targets = []
        self.boxes = []
        self.target_count = 0
        self.is_game_over = False
        self._rows = len(map)
        self._cols = len(map[0]) if self._rows else 0
        self.init_game()

    def init_game(self):
        self.targets = []
        self.boxes = []
        for r, row in enumerate(self.map):
            for c, ch in enumerate(row):
                if ch == 'O':
                    self.player_row, self.player_col = r, c
                elif ch == 'G':
                    self.targets.append((r, c))
                elif ch == 'X':
                    self.boxes.append((r, c))
        self._targets = set(self.targets)
        self._boxes = set(self.boxes)
        self.target_count = len(self.targets)
        self.is_game_over = self.check_win()

    def check_win(self):
        self.is_game_over = all(box in self._targets for box in self._boxes)
        return self.is_game_over

    def move(self, direction):
        if self.is_game_over:
            return True
        delta = {'w': (-1, 0), 's': (1, 0), 'a': (0, -1), 'd': (0, 1)}
        if direction not in delta:
            return self.is_game_over
        dr, dc = delta[direction]
        nr, nc = self.player_row + dr, self.player_col + dc
        if not (0 <= nr < self._rows and 0 <= nc < self._cols):
            return self.is_game_over
        if self.map[nr][nc] == '#':
            return self.is_game_over
        # if empty or target
        if (nr, nc) in self._boxes:
            br, bc = nr + dr, nc + dc
            if not (0 <= br < self._rows and 0 <= bc < self._cols):
                return self.is_game_over
            if self.map[br][bc] == '#':
                return self.is_game_over
            if (br, bc) in self._boxes:
                return self.is_game_over
            # push
            self._boxes.remove((nr, nc))
            self._boxes.add((br, bc))
        self.player_row, self.player_col = nr, nc
        self.boxes = list(self._boxes)
        return self.check_win()

# Classification response:
# set conversion;any/all usage;membership test;guard clause;early return;flattened conditional;enumerate loop;tuple unpacking;dictionary lookup;boundary case handling;empty input handling;behavior change