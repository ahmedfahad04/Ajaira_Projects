class BigNumCalculator:
    """
    This is a class that implements big number calculations, including adding, subtracting and multiplying.
    """

    BASE = 10**9
    WIDTH = 9

    @staticmethod
    def _parse_blocks(s):
        sign = 1
        if s.startswith('+'):
            s = s[1:]
        if s.startswith('-'):
            sign = -1
            s = s[1:]
        s = s.lstrip('0')
        if s == '':
            return 0, [0]
        blocks = []
        i = len(s)
        while i > 0:
            start = max(0, i - BigNumCalculator.WIDTH)
            blocks.append(int(s[start:i]))
            i = start
        return sign, blocks

    @staticmethod
    def _blocks_to_str(sign, blocks):
        while len(blocks) > 1 and blocks[-1] == 0:
            blocks.pop()
        if len(blocks) == 1 and blocks[0] == 0:
            return "0"
        s = str(blocks[-1])
        for b in reversed(blocks[:-1]):
            s += str(b).zfill(BigNumCalculator.WIDTH)
        return ("-" + s) if sign < 0 else s

    @staticmethod
    def _add_blocks(a, b):
        n = max(len(a), len(b))
        res = []
        carry = 0
        for i in range(n):
            va = a[i] if i < len(a) else 0
            vb = b[i] if i < len(b) else 0
            cur = va + vb + carry
            res.append(cur % BigNumCalculator.BASE)
            carry = cur // BigNumCalculator.BASE
        if carry:
            res.append(carry)
        return res

    @staticmethod
    def _cmp_blocks(a, b):
        if len(a) != len(b):
            return 1 if len(a) > len(b) else -1
        for i in range(len(a)-1, -1, -1):
            if a[i] != b[i]:
                return 1 if a[i] > b[i] else -1
        return 0

    @staticmethod
    def _sub_blocks(a, b):
        res = []
        carry = 0
        for i in range(len(a)):
            va = a[i]
            vb = b[i] if i < len(b) else 0
            cur = va - vb - carry
            if cur < 0:
                cur += BigNumCalculator.BASE
                carry = 1
            else:
                carry = 0
            res.append(cur)
        while len(res) > 1 and res[-1] == 0:
            res.pop()
        return res

    @staticmethod
    def add(num1, num2):
        s1, b1 = BigNumCalculator._parse_blocks(num1)
        s2, b2 = BigNumCalculator._parse_blocks(num2)
        if s1 == s2:
            res_blocks = BigNumCalculator._add_blocks(b1, b2)
            return BigNumCalculator._blocks_to_str(s1, res_blocks)
        cmp = BigNumCalculator._cmp_blocks(b1, b2)
        if cmp == 0:
            return "0"
        if cmp > 0:
            res_blocks = BigNumCalculator._sub_blocks(b1, b2)
            return BigNumCalculator._blocks_to_str(s1, res_blocks)
        else:
            res_blocks = BigNumCalculator._sub_blocks(b2, b1)
            return BigNumCalculator._blocks_to_str(s2, res_blocks)

    @staticmethod
    def subtract(num1, num2):
        if num2.startswith('-'):
            n2 = num2[1:]
        else:
            n2 = "-" + num2
        return BigNumCalculator.add(num1, n2)

    @staticmethod
    def multiply(num1, num2):
        s1, b1 = BigNumCalculator._parse_blocks(num1)
        s2, b2 = BigNumCalculator._parse_blocks(num2)
        sign = s1 * s2
        if len(b1) == 1 and b1[0] == 0 or len(b2) == 1 and b2[0] == 0:
            return "0"
        res = [0] * (len(b1) + len(b2))
        for i in range(len(b1)):
            carry = 0
            for j in range(len(b2)):
                cur = res[i + j] + b1[i] * b2[j] + carry
                res[i + j] = cur % BigNumCalculator.BASE
                carry = cur // BigNumCalculator.BASE
            k = i + len(b2)
            while carry:
                cur = res[k] + carry
                res[k] = cur % BigNumCalculator.BASE
                carry = cur // BigNumCalculator.BASE
                k += 1
        return BigNumCalculator._blocks_to_str(sign, res)