class ComplexCalculator:
    """
    This is a class that implements addition, subtraction, multiplication, and division operations for complex numbers.
    """

    def __init__(self):
        pass

    @staticmethod
    def _extract(x):
        if isinstance(x, complex):
            return x.real, x.imag
        if isinstance(x, (tuple, list)) and len(x) == 2:
            return float(x[0]), float(x[1])
        if isinstance(x, (int, float)):
            return float(x), 0.0
        raise TypeError("Unsupported type")

    @staticmethod
    def add(c1, c2):
        a_re, a_im = ComplexCalculator._extract(c1)
        b_re, b_im = ComplexCalculator._extract(c2)
        return complex(a_re + b_re, a_im + b_im)

    @staticmethod
    def subtract(c1, c2):
        a_re, a_im = ComplexCalculator._extract(c1)
        b_re, b_im = ComplexCalculator._extract(c2)
        return complex(a_re - b_re, a_im - b_im)

    @staticmethod
    def multiply(c1, c2):
        a_re, a_im = ComplexCalculator._extract(c1)
        b_re, b_im = ComplexCalculator._extract(c2)
        re = a_re * b_re - a_im * b_im
        im = a_re * b_im + a_im * b_re
        return complex(re, im)

    @staticmethod
    def divide(c1, c2):
        a_re, a_im = ComplexCalculator._extract(c1)
        b_re, b_im = ComplexCalculator._extract(c2)
        denom = b_re * b_re + b_im * b_im
        if denom == 0:
            raise ZeroDivisionError("division by zero")
        re = (a_re * b_re + a_im * b_im) / denom
        im = (a_im * b_re - a_re * b_im) / denom
        return complex(re, im)