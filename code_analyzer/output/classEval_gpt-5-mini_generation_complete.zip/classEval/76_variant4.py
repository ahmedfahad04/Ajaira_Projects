class SignInSystem:
    """
    This is a class as sigin in system, including adding users, signing in/out, checking sign-in status, and retrieving signed-in/not signed-in users.
    """

    def __init__(self):
        """
        Initialize the sign-in system.
        """
        self.users = {}
        self._order = []

    def add_user(self, username):
        if username in self.users:
            return False
        self.users[username] = False
        self._order.append(username)
        return True

    def sign_in(self, username):
        if username not in self.users:
            return False
        self.users[username] = True
        return True

    def check_sign_in(self, username):
        return self.users.get(username, False)

    def all_signed_in(self):
        for v in self.users.values():
            if not v:
                return False
        return True

    def all_not_signed_in(self):
        return [u for u in self._order if not self.users.get(u, False)]