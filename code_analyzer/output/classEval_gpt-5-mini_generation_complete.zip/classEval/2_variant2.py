import shlex

class ArgumentParser:
    """
    This is a class for parsing command line arguments to a dictionary.
    """

    def __init__(self):
        self.arguments = {}
        self.required = set()
        self.types = {}

    def parse_arguments(self, command_string):
        parts = shlex.split(command_string)
        it = iter(range(len(parts)))
        i = 0
        while i < len(parts):
            tok = parts[i]
            if tok.startswith('-'):
                key = tok.lstrip('-')
                if '=' in key:
                    key, val = key.split('=', 1)
                    self.arguments[key] = self._convert_type(key, val)
                    i += 1
                    continue
                # lookahead
                if i + 1 < len(parts) and not parts[i + 1].startswith('-'):
                    val = parts[i + 1]
                    self.arguments[key] = self._convert_type(key, val)
                    i += 2
                    continue
                # flag
                self.arguments[key] = self._convert_type(key, True)
                i += 1
            else:
                i += 1
        missing = {r for r in self.required if r not in self.arguments}
        if missing:
            return (False, missing)
        return (True, None)

    def get_argument(self, key):
        return self.arguments.get(key)

    def add_argument(self, arg, required=False, arg_type=str):
        if required:
            self.required.add(arg)
        # allow passing type as string
        if isinstance(arg_type, str):
            tmap = {'int': int, 'float': float, 'str': str, 'bool': bool}
            self.types[arg] = tmap.get(arg_type, str)
        else:
            self.types[arg] = arg_type

    def _convert_type(self, arg, value):
        expected = self.types.get(arg)
        if expected is None:
            return value
        if expected is bool:
            if isinstance(value, bool):
                return value
            s = str(value).strip().lower()
            if s in ('true', '1', 'yes', 'y', 'on'):
                return True
            if s in ('false', '0', 'no', 'n', 'off'):
                return False
            return True
        try:
            return expected(value)
        except Exception:
            return value