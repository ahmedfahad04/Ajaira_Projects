from urllib.parse import unquote_plus

class URLHandler:
    """
    The class supports to handle URLs, including extracting the scheme, host, path, query parameters, and fragment.
    """

    def __init__(self, url):
        """
        Initialize URLHandler's URL
        """
        self.url = url or ""
        # Precompute parts
        self._scheme = ""
        self._host = ""
        self._path = ""
        self._query = ""
        self._fragment = ""
        self._parse_manual()

    def _parse_manual(self):
        s = self.url
        if not s:
            return
        # scheme
        i = s.find("://")
        if i != -1:
            self._scheme = s[:i]
            rest = s[i+3:]
        else:
            rest = s
        # fragment
        j = rest.find("#")
        if j != -1:
            self._fragment = rest[j+1:]
            rest = rest[:j]
        # query
        k = rest.find("?")
        if k != -1:
            self._query = rest[k+1:]
            path_host = rest[:k]
        else:
            path_host = rest
        # host and path
        if path_host.startswith('/'):
            # no explicit host
            self._host = ""
            self._path = path_host
        else:
            slash = path_host.find('/')
            if slash == -1:
                self._host = path_host
                self._path = ""
            else:
                self._host = path_host[:slash]
                self._path = path_host[slash:]
        # ensure path contains query and fragment when requested later

    def get_scheme(self):
        return self._scheme

    def get_host(self):
        return self._host

    def get_path(self):
        out = self._path or ""
        if self._query:
            out += "?" + self._query
        if self._fragment:
            out += "#" + self._fragment
        return out

    def get_query_params(self):
        if not self._query:
            return {}
        params = {}
        for part in self._query.split('&'):
            if part == '':
                continue
            if '=' in part:
                k, v = part.split('=', 1)
                k = unquote_plus(k)
                v = unquote_plus(v)
            else:
                k = unquote_plus(part)
                v = ''
            # choose last occurrence
            params[k] = v
        return params

    def get_fragment(self):
        return self._fragment