import re

class BalancedBrackets:
    """
    This is a class that checks for bracket matching
    """

    def __init__(self, expr):
        """
        Initializes the class with an expression.
        :param expr: The expression to check for balanced brackets,str.
        """
        self.stack = []
        self.left_brackets = ["(", "{", "["]
        self.right_brackets = [")", "}", "]"]
        self.expr = expr

    def clear_expr(self):
        """
        Clears the expression of all characters that are not brackets.
        """
        # Keep only characters that are one of the bracket characters
        pattern = r'[^()\{\}\[\]]'
        self.expr = re.sub(pattern, '', self.expr or '')

    def check_balanced_brackets(self):
        """
        Checks if the expression has balanced brackets.
        :return: True if the expression has balanced brackets, False otherwise.
        """
        self.clear_expr()
        self.stack = []
        pairs = {')': '(', '}': '{', ']': '['}
        for ch in self.expr:
            if ch in pairs.values():
                self.stack.append(ch)
            else:
                if ch in pairs:
                    if not self.stack:
                        return False
                    if self.stack.pop() != pairs[ch]:
                        return False
                else:
                    # ignore any non-bracket just in case
                    continue
        return len(self.stack) == 0