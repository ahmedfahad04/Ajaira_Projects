import math

class Statistics3:
    """
    This is a class that implements methods for calculating indicators such as median, mode, correlation matrix, and Z-score in statistics.
    """

    @staticmethod
    def median(data):
        if not data:
            raise ValueError("no data")
        arr = list(data)
        arr.sort()
        n = len(arr)
        if n & 1:
            return float(arr[n // 2])
        return (arr[n // 2 - 1] + arr[n // 2]) / 2.0

    @staticmethod
    def mode(data):
        if not data:
            return []
        freq = {}
        for v in data:
            freq[v] = freq.get(v, 0) + 1
        maxf = max(freq.values())
        res = [k for k, v in freq.items() if v == maxf]
        try:
            res.sort()
        except TypeError:
            pass
        return res

    @staticmethod
    def correlation(x, y):
        if len(x) != len(y):
            raise ValueError("length mismatch")
        n = len(x)
        if n < 2:
            return 0.0
        mean_x = sum(x) / n
        mean_y = sum(y) / n
        dx = [xi - mean_x for xi in x]
        dy = [yi - mean_y for yi in y]
        cov = sum(a * b for a, b in zip(dx, dy)) / (n - 1)
        sx = math.sqrt(sum(a * a for a in dx) / (n - 1))
        sy = math.sqrt(sum(b * b for b in dy) / (n - 1))
        if sx == 0 or sy == 0:
            return 0.0
        return cov / (sx * sy)

    @staticmethod
    def mean(data):
        if not data:
            raise ValueError("no data")
        return float(sum(data)) / len(data)

    @staticmethod
    def correlation_matrix(data):
        if not data:
            return []
        m = len(data)
        means = [Statistics3.mean(col) for col in data]
        sds = [Statistics3.standard_deviation(col) for col in data]
        mat = [[0.0] * m for _ in range(m)]
        for i in range(m):
            for j in range(m):
                if i == j:
                    mat[i][j] = 1.0
                    continue
                xi = data[i]
                xj = data[j]
                n = len(xi)
                if n != len(xj):
                    raise ValueError("all variables must have same length")
                if n < 2 or sds[i] == 0 or sds[j] == 0:
                    mat[i][j] = 0.0
                else:
                    num = sum((a - means[i]) * (b - means[j]) for a, b in zip(xi, xj)) / (n - 1)
                    mat[i][j] = num / (sds[i] * sds[j])
        return mat

    @staticmethod
    def standard_deviation(data):
        n = len(data)
        if n < 2:
            return 0.0
        m = Statistics3.mean(data)
        ssd = 0.0
        for v in data:
            ssd += (v - m) ** 2
        return math.sqrt(ssd / (n - 1))

    @staticmethod
    def z_score(data):
        if not data:
            return []
        m = Statistics3.mean(data)
        sd = Statistics3.standard_deviation(data)
        if sd == 0:
            return [0.0 for _ in data]
        return [ (v - m) / sd for v in data ]