from bisect import bisect_right

class Interpolation:
    """
    This is a class that implements the Linear interpolation operation of one-dimensional and two-dimensional data
    """

    def __init__(self):
        pass

    @staticmethod
    def interpolate_1d(x, y, x_interp):
        if not (isinstance(x, (list, tuple)) and isinstance(y, (list, tuple)) and isinstance(x_interp, (list, tuple))):
            raise TypeError("x, y, x_interp must be lists or tuples")
        if len(x) != len(y):
            raise ValueError("x and y must have same length")
        n = len(x)
        if n == 0:
            return []
        result = []
        for xi in x_interp:
            if n == 1:
                result.append(float(y[0]))
                continue
            i = bisect_right(x, xi)
            if i == 0:
                x0, x1 = x[0], x[1]
                y0, y1 = y[0], y[1]
            elif i >= n:
                x0, x1 = x[-2], x[-1]
                y0, y1 = y[-2], y[-1]
            else:
                x0, x1 = x[i-1], x[i]
                y0, y1 = y[i-1], y[i]
            if x1 == x0:
                result.append(float(y0))
            else:
                t = (xi - x0) / (x1 - x0)
                result.append(float(y0 + t * (y1 - y0)))
        return result

    @staticmethod
    def interpolate_2d(x, y, z, x_interp, y_interp):
        if not (isinstance(x, (list, tuple)) and isinstance(y, (list, tuple))):
            raise TypeError("x and y must be lists or tuples")
        nx, ny = len(x), len(y)
        if nx == 0 or ny == 0:
            return []
        if any(len(row) != ny for row in z) or len(z) != nx:
            raise ValueError("z must be a matrix with shape (len(x), len(y))")
        xs = Interpolation.interpolate_1d
        result = []
        for xi, yi in zip(x_interp, y_interp):
            if nx == 1 and ny == 1:
                result.append(float(z[0][0]))
                continue
            if nx == 1:
                col = [row[0] for row in z]
                result.append(xs(y, col, [yi])[0])
                continue
            if ny == 1:
                row_vals = z
                # interpolate along x using z column
                col_vals = [row[0] for row in row_vals]
                result.append(xs(x, col_vals, [xi])[0])
                continue
            ix = bisect_right(x, xi)
            iy = bisect_right(y, yi)
            if ix == 0:
                ix0, ix1 = 0, 1
            elif ix >= nx:
                ix0, ix1 = nx-2, nx-1
            else:
                ix0, ix1 = ix-1, ix
            if iy == 0:
                iy0, iy1 = 0, 1
            elif iy >= ny:
                iy0, iy1 = ny-2, ny-1
            else:
                iy0, iy1 = iy-1, iy
            x0, x1 = x[ix0], x[ix1]
            y0, y1 = y[iy0], y[iy1]
            z00 = z[ix0][iy0]
            z10 = z[ix1][iy0]
            z01 = z[ix0][iy1]
            z11 = z[ix1][iy1]
            if x1 == x0 and y1 == y0:
                result.append(float(z00))
                continue
            if x1 == x0:
                t = (yi - y0) / (y1 - y0) if y1 != y0 else 0.0
                val = z00 + t * (z01 - z00)
                result.append(float(val))
                continue
            if y1 == y0:
                t = (xi - x0) / (x1 - x0) if x1 != x0 else 0.0
                val = z00 + t * (z10 - z00)
                result.append(float(val))
                continue
            tx = (xi - x0) / (x1 - x0)
            ty = (yi - y0) / (y1 - y0)
            val = (z00 * (1 - tx) * (1 - ty) +
                   z10 * tx * (1 - ty) +
                   z01 * (1 - tx) * ty +
                   z11 * tx * ty)
            result.append(float(val))
        return result