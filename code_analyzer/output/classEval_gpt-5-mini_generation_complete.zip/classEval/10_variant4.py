from itertools import islice

class BinaryDataProcessor:
    """
    This is a class used to process binary data, which includes functions such as clearing non 0 or 1 characters, counting binary string information, and converting to corresponding strings based on different encoding methods.
    """

    def __init__(self, binary_string):
        self.binary_string = binary_string or ""
        self.clean_non_binary_chars()

    def clean_non_binary_chars(self):
        # streaming filter approach
        filtered = []
        for ch in self.binary_string:
            if ch == '0' or ch == '1':
                filtered.append(ch)
        self.binary_string = ''.join(filtered)

    def calculate_binary_info(self):
        s = self.binary_string
        total = len(s)
        if total == 0:
            return {'Zeroes': 0.0, 'Ones': 0.0, 'Bit length': 0}
        zeros = s.count('0')
        ones = total - zeros
        return {'Zeroes': round(zeros / total, 3), 'Ones': round(ones / total, 3), 'Bit length': total}

    def convert_to_ascii(self):
        # build bytes by bit shifts
        s = self.binary_string
        out = []
        cur = 0
        bits = 0
        for ch in s:
            cur = (cur << 1) | (1 if ch == '1' else 0)
            bits += 1
            if bits == 8:
                out.append(cur)
                cur = 0
                bits = 0
        return ''.join(chr(b) for b in out)

    def convert_to_utf8(self):
        s = self.binary_string
        out = bytearray()
        cur = 0
        bits = 0
        for ch in s:
            cur = (cur << 1) | (1 if ch == '1' else 0)
            bits += 1
            if bits == 8:
                out.append(cur & 0xFF)
                cur = 0
                bits = 0
        return bytes(out).decode('utf-8', errors='replace')