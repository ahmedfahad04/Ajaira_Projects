import sqlite3
import time

class StudentDatabaseProcessor:
    """
    This is a class with database operation, including inserting student information, searching for student information by name, and deleting student information by name.
    """

    def __init__(self, database_name):
        """
        Initializes the StudentDatabaseProcessor object with the specified database name.
        :param database_name: str, the name of the SQLite database.
        """
        self.database_name = database_name

    def create_student_table(self):
        """
        Creates a "students" table in the database if it does not exist already.Fields include ID of type int, name of type str, age of type int, gender of type str, and grade of type int
        :return: None
        """
        with sqlite3.connect(self.database_name) as conn:
            conn.execute(
                "CREATE TABLE IF NOT EXISTS students (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, age INTEGER, gender TEXT, grade INTEGER);"
            )
            conn.commit()

    def _execute_with_retry(self, sql, params=(), retry=5, delay=0.05):
        attempts = 0
        while True:
            try:
                with sqlite3.connect(self.database_name) as conn:
                    cur = conn.execute(sql, params)
                    conn.commit()
                    return cur
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e).lower() and attempts < retry:
                    attempts += 1
                    time.sleep(delay)
                    continue
                raise

    def insert_student(self, student_data):
        """
        Inserts a new student into the "students" table.
        :param student_data: dict, a dictionary containing the student's information (name, age, gender, grade).
        :return: None
        """
        if not isinstance(student_data, dict):
            raise ValueError("student_data must be a dict")
        name = student_data.get("name")
        if name is None:
            raise ValueError("name is required")
        age = student_data.get("age")
        gender = student_data.get("gender")
        grade = student_data.get("grade")
        self._execute_with_retry(
            "INSERT INTO students (name, age, gender, grade) VALUES (?, ?, ?, ?);",
            (name, age, gender, grade)
        )

    def search_student_by_name(self, name):
        """
        Searches for a student in the "students" table by their name.
        :param name: str, the name of the student to search for.
        :return: list of tuples, the rows from the "students" table that match the search criteria.
        """
        conn = sqlite3.connect(self.database_name)
        try:
            cur = conn.execute("SELECT id, name, age, gender, grade FROM students WHERE name = ?;", (name,))
            rows = cur.fetchall()
            return rows
        finally:
            conn.close()

    def delete_student_by_name(self, name):
        """
        Deletes a student from the "students" table by their name.
        :param name: str, the name of the student to delete.
        :return: None
        """
        self._execute_with_retry("DELETE FROM students WHERE name = ?;", (name,))