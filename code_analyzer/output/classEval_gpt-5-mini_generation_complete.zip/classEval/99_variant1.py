import zipfile
import os
from pathlib import Path


class ZipFileProcessor:
    """
    This is a compressed file processing class that provides the ability to read and decompress compressed files
    """

    def __init__(self, file_name):
        """
        Initialize file name
        :param file_name:string
        """
        self.file_name = file_name

    def read_zip_file(self):
        """
        Get open file object
        :return:If successful, returns the open file object; otherwise, returns None
        """
        try:
            if not os.path.exists(self.file_name):
                return None
            if not zipfile.is_zipfile(self.file_name):
                return None
            zf = zipfile.ZipFile(self.file_name, mode="r")
            return zf
        except Exception:
            return None

    def extract_all(self, output_path):
        """
        Extract all zip files and place them in the specified path
        :param output_path: string, The location of the extracted file
        :return: True or False, representing whether the extraction operation was successful
        """
        try:
            zf = self.read_zip_file()
            if zf is None:
                return False
            output_dir = Path(output_path)
            output_dir.mkdir(parents=True, exist_ok=True)
            with zf:
                zf.extractall(path=str(output_dir))
            return True
        except Exception:
            return False

    def extract_file(self, file_name, output_path):
        """
        Extract the file with the specified name from the zip file and place it in the specified path
        :param file_name:string, The name of the file to be uncompressed
        :param output_path:string, The location of the extracted file
        :return: True or False, representing whether the extraction operation was successful
        """
        try:
            zf = self.read_zip_file()
            if zf is None:
                return False
            if file_name not in zf.namelist():
                # try to match a trailing/leading slash-insensitive name
                matches = [n for n in zf.namelist() if n.endswith(file_name)]
                if not matches:
                    return False
                file_name = matches[0]
            output_dir = Path(output_path)
            output_dir.mkdir(parents=True, exist_ok=True)
            with zf:
                zf.extract(member=file_name, path=str(output_dir))
            return True
        except Exception:
            return False

    def create_zip_file(self, files, output_file_name):
        """
        Compress the specified file list into a zip file and place it in the specified path
        :param files:list of string, List of files to compress
        :param output_file_name: string, Specified output path
        :return:True or False, representing whether the compression operation was successful
        """
        try:
            if not files:
                return False
            out_path = Path(output_file_name)
            if out_path.is_dir():
                # if a directory provided, create a default name
                out_path = out_path / "archive.zip"
            else:
                # ensure parent exists
                out_path.parent.mkdir(parents=True, exist_ok=True)
                if out_path.suffix.lower() != ".zip":
                    out_path = out_path.with_suffix(out_path.suffix + ".zip") if out_path.suffix else out_path.with_suffix(".zip")
            compression = zipfile.ZIP_DEFLATED if hasattr(zipfile, "ZIP_DEFLATED") else zipfile.ZIP_STORED
            added_any = False
            with zipfile.ZipFile(str(out_path), mode="w", compression=compression) as zf:
                for f in files:
                    p = Path(f)
                    if p.exists():
                        if p.is_file():
                            zf.write(str(p), arcname=p.name)
                            added_any = True
                        elif p.is_dir():
                            for root, _, filenames in os.walk(p):
                                for fname in filenames:
                                    full = Path(root) / fname
                                    arc = str(full.relative_to(p.parent))
                                    zf.write(str(full), arcname=arc)
                                    added_any = True
            return added_any
        except Exception:
            return False