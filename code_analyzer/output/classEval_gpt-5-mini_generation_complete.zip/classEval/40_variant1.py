class FitnessTracker:
    """
    This is a class as fitness tracker that implements to calculate BMI (Body Mass Index) and calorie intake based on the user's height, weight, age, and sex.
    """

    def __init__(self, height, weight, age, sex) -> None:
        """
        Initialize the class with height, weight, age, and sex, and calculate the BMI standard based on sex, and male is 20-25, female is 19-24.
        """
        self.height = float(height)
        self.weight = float(weight)
        self.age = int(age)
        self.sex = str(sex).lower()
        self.BMI_std = [
            {"male": [20, 25]},
            {"female": [19, 24]}
        ]

    def get_BMI(self):
        """
        Calculate the BMI based on the height and weight.
        :return: BMI,which is the weight divide by the square of height, float.
        """
        if self.height == 0:
            raise ValueError("Height must be non-zero")
        bmi = self.weight / (self.height ** 2)
        return bmi

    def condition_judge(self):
        """
        Judge the condition of the user based on the BMI standard.
        :return: 1 if the user is too fat, -1 if the user is too thin, 0 if the user is normal, int.
        """
        bmi = self.get_BMI()
        # find bounds
        if self.sex == "male":
            low, high = 20, 25
        elif self.sex == "female":
            low, high = 19, 24
        else:
            # default to average bounds if unknown
            low = (20 + 19) / 2
            high = (25 + 24) / 2
        if bmi > high:
            return 1
        if bmi < low:
            return -1
        return 0

    def calculate_calorie_intake(self):
        """
        Calculate the calorie intake based on the user's condition and BMR.
        """
        # BMR formulas given use the provided height directly
        if self.sex == "male":
            bmr = 10 * self.weight + 6.25 * self.height - 5 * self.age + 5
        elif self.sex == "female":
            bmr = 10 * self.weight + 6.25 * self.height - 5 * self.age - 161
        else:
            # average of male and female formula if unknown
            bmr_m = 10 * self.weight + 6.25 * self.height - 5 * self.age + 5
            bmr_f = 10 * self.weight + 6.25 * self.height - 5 * self.age - 161
            bmr = (bmr_m + bmr_f) / 2.0

        cond = self.condition_judge()
        if cond == 1:
            factor = 1.2
        elif cond == -1:
            factor = 1.6
        else:
            factor = 1.4
        return bmr * factor