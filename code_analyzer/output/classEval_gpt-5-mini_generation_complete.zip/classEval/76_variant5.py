class SignInSystem:
    """
    This is a class as sigin in system, including adding users, signing in/out, checking sign-in status, and retrieving signed-in/not signed-in users.
    """

    def __init__(self):
        """
        Initialize the sign-in system.
        """
        self.users = {}

    def add_user(self, username):
        if username in self.users:
            return False
        self.users[username] = False
        return True

    def sign_in(self, username):
        if username not in self.users:
            return False
        self.users[username] = True
        return True

    def check_sign_in(self, username):
        return self.users.get(username, False)

    def all_signed_in(self):
        return all(self.users.values())

    def all_not_signed_in(self):
        return [u for u, v in sorted(self.users.items(), key=lambda x: x[0]) if not v]