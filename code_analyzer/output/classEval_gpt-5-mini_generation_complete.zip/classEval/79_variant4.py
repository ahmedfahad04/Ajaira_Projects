class SQLGenerator:
    """
    This class generates SQL statements for common operations on a table, such as SELECT, INSERT, UPDATE, and DELETE.
    """

    def __init__(self, table_name):
        self.table_name = table_name

    @staticmethod
    def _to_sql_literal(value):
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "1" if value else "0"
        if isinstance(value, (int, float)):
            return str(value)
        s = str(value)
        s = s.replace("'", "''")
        return f"'{s}'"

    def select(self, fields=None, condition=None):
        if not fields:
            fields_part = "*"
        else:
            fields_part = ", ".join(fields)
        sql = f"SELECT {fields_part} FROM {self.table_name}"
        if condition:
            sql += f" WHERE {condition}"
        return sql + ";"

    def insert(self, data):
        if not isinstance(data, dict) or not data:
            raise ValueError("data must be a non-empty dict")
        keys = list(data.keys())
        cols = ", ".join(keys)
        vals = ", ".join(self._to_sql_literal(data[k]) for k in keys)
        return f"INSERT INTO {self.table_name} ({cols}) VALUES ({vals});"

    def update(self, data, condition):
        if not isinstance(data, dict) or not data:
            raise ValueError("data must be a non-empty dict")
        assign = ", ".join(f"{k} = {self._to_sql_literal(v)}" for k, v in data.items())
        sql = f"UPDATE {self.table_name} SET {assign}"
        if condition:
            sql += f" WHERE {condition}"
        return sql + ";"

    def delete(self, condition):
        sql = f"DELETE FROM {self.table_name}"
        if condition:
            sql += f" WHERE {condition}"
        return sql + ";"

    def select_female_under_age(self, age):
        return "SELECT * FROM {} WHERE age < {} AND gender = 'female';".format(self.table_name, int(age))

    def select_by_age_range(self, min_age, max_age):
        return "SELECT * FROM {} WHERE age BETWEEN {} AND {};".format(self.table_name, int(min_age), int(max_age))