import numpy as np
from gensim import matutils
from numpy import dot, array

class VectorUtil:
    """
    The class provides vector operations, including calculating similarity, cosine similarities, average similarity, and IDF weights.
    """

    @staticmethod
    def similarity(vector_1, vector_2):
        v1 = matutils.unitvec(array(vector_1).astype(float)) if np.linalg.norm(vector_1) != 0 else None
        v2 = matutils.unitvec(array(vector_2).astype(float)) if np.linalg.norm(vector_2) != 0 else None
        if v1 is None or v2 is None:
            return 0.0
        return float(dot(v1, v2))

    @staticmethod
    def cosine_similarities(vector_1, vectors_all):
        v1 = array(vector_1).astype(float)
        if np.linalg.norm(v1) == 0:
            return np.array([0.0] * len(vectors_all))
        u1 = matutils.unitvec(v1)
        res = []
        for v in vectors_all:
            vv = array(v).astype(float)
            if np.linalg.norm(vv) == 0:
                res.append(0.0)
            else:
                res.append(float(dot(u1, matutils.unitvec(vv))))
        return np.array(res, dtype=float)

    @staticmethod
    def n_similarity(vector_list_1, vector_list_2):
        if not vector_list_1 or not vector_list_2:
            return 0.0
        m1 = np.mean([array(v).astype(float) for v in vector_list_1], axis=0)
        m2 = np.mean([array(v).astype(float) for v in vector_list_2], axis=0)
        return VectorUtil.similarity(m1, m2)

    @staticmethod
    def compute_idf_weight_dict(total_num, number_dict):
        total = float(total_num)
        out = {}
        for k, v in number_dict.items():
            count = float(v)
            out[k] = float(np.log((total + 1.0) / (count + 1.0)))
        return out