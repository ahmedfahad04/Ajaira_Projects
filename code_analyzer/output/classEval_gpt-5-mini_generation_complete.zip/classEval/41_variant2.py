class GomokuGame:
    def __init__(self, board_size):
        self.board_size = board_size
        self.board = [[' ' for _ in range(board_size)] for _ in range(board_size)]
        self.current_player = 'X'
        self.last_move = None
        self._winner = None

    def make_move(self, row, col):
        if not (0 <= row < self.board_size and 0 <= col < self.board_size):
            return False
        if self.board[row][col] != ' ':
            return False
        self.board[row][col] = self.current_player
        self.last_move = (row, col)
        # check immediate win and cache
        if self._detect_win_from_cell(row, col):
            self._winner = self.board[row][col]
        self.current_player = 'O' if self.current_player == 'X' else 'X'
        return True

    def check_winner(self):
        if self._winner is not None:
            return self._winner
        # If no cached winner, scan whole board
        for r in range(self.board_size):
            for c in range(self.board_size):
                if self.board[r][c] == ' ':
                    continue
                if self._detect_win_from_cell(r, c):
                    return self.board[r][c]
        return None

    def _detect_win_from_cell(self, row, col):
        # count both directions for each of the 4 primary directions
        directions = [(0,1), (1,0), (1,1), (1,-1)]
        player = self.board[row][col]
        if player == ' ':
            return False
        for dx, dy in directions:
            count = 1
            # forward
            r, c = row + dx, col + dy
            while 0 <= r < self.board_size and 0 <= c < self.board_size and self.board[r][c] == player:
                count += 1
                r += dx; c += dy
            # backward
            r, c = row - dx, col - dy
            while 0 <= r < self.board_size and 0 <= c < self.board_size and self.board[r][c] == player:
                count += 1
                r -= dx; c -= dy
            if count >= 5:
                return True
        return False

    def _check_five_in_a_row(self, row, col, direction):
        dx, dy = direction
        if not (0 <= row < self.board_size and 0 <= col < self.board_size):
            return False
        player = self.board[row][col]
        if player == ' ':
            return False
        r, c = row, col
        count = 0
        while 0 <= r < self.board_size and 0 <= c < self.board_size and self.board[r][c] == player:
            count += 1
            if count >= 5:
                return True
            r += dx; c += dy
        return False