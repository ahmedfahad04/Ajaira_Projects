class SignInSystem:
    """
    This is a class as sigin in system, including adding users, signing in/out, checking sign-in status, and retrieving signed-in/not signed-in users.
    """

    def __init__(self):
        """
        Initialize the sign-in system.
        """
        self.users = {}
        self._not_signed = set()

    def add_user(self, username):
        if username in self.users:
            return False
        self.users[username] = False
        self._not_signed.add(username)
        return True

    def sign_in(self, username):
        if username not in self.users:
            return False
        if self.users[username]:
            return True
        self.users[username] = True
        if username in self._not_signed:
            self._not_signed.remove(username)
        return True

    def check_sign_in(self, username):
        return self.users.get(username, False)

    def all_signed_in(self):
        if not self.users:
            return True
        return len(self._not_signed) == 0

    def all_not_signed_in(self):
        # preserve insertion order based on self.users keys
        return [u for u in self.users.keys() if u in self._not_signed]