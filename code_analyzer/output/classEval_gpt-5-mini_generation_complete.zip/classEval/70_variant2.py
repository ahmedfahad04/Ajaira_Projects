class PersonRequest:
    """
    This class validates input personal information data and sets invalid fields to None based to specific rules.
    """

    def __init__(self, name: str, sex: str, phoneNumber: str):
        self._name = None
        self._sex = None
        self._phoneNumber = None
        self.name = name
        self.sex = sex
        self.phoneNumber = phoneNumber

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        try:
            v = "" if value is None else str(value).strip()
        except Exception:
            v = ""
        if v == "" or len(v) > 33:
            self._name = None
        else:
            self._name = v

    @property
    def sex(self):
        return self._sex

    @sex.setter
    def sex(self, value):
        try:
            v = None if value is None else str(value)
        except Exception:
            v = None
        if v in ("Man", "Woman", "UGM"):
            self._sex = v
        else:
            self._sex = None

    @property
    def phoneNumber(self):
        return self._phoneNumber

    @phoneNumber.setter
    def phoneNumber(self, value):
        try:
            v = "" if value is None else str(value).strip()
        except Exception:
            v = ""
        if v != "" and len(v) == 11 and v.isdigit():
            self._phoneNumber = v
        else:
            self._phoneNumber = None

# Classification response:
# variable renaming;state variable;temporary variable;helper function inlining;combined condition;try-except wrapper;membership test;input validation;empty input handling;type conversion;error suppression