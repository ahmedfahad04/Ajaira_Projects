import numpy as np

class Interpolation:
    """
    This is a class that implements the Linear interpolation operation of one-dimensional and two-dimensional data
    """

    def __init__(self):
        pass

    @staticmethod
    def interpolate_1d(x, y, x_interp):
        xa = np.asarray(x, dtype=float)
        ya = np.asarray(y, dtype=float)
        xi = np.asarray(x_interp, dtype=float)
        if xa.size == 0:
            return []
        if xa.size == 1:
            return [float(ya[0]) for _ in xi]
        yi = np.interp(xi, xa, ya)
        return [float(v) for v in yi]

    @staticmethod
    def interpolate_2d(x, y, z, x_interp, y_interp):
        xa = np.asarray(x, dtype=float)
        ya = np.asarray(y, dtype=float)
        Zi = np.asarray(z, dtype=float)
        xi = np.asarray(x_interp, dtype=float)
        yi = np.asarray(y_interp, dtype=float)
        if xa.size == 0 or ya.size == 0:
            return []
        if Zi.shape != (xa.size, ya.size):
            raise ValueError("z must have shape (len(x), len(y))")
        results = []
        for xv, yv in zip(xi, yi):
            # interpolate along x for each y column to get values at xv
            vals_along_y = np.empty(ya.size, dtype=float)
            for j in range(ya.size):
                col = Zi[:, j]
                if xa.size == 1:
                    vals_along_y[j] = col[0]
                else:
                    vals_along_y[j] = np.interp(xv, xa, col)
            # now interpolate these values along y
            if ya.size == 1:
                final = vals_along_y[0]
            else:
                final = np.interp(yv, ya, vals_along_y)
            results.append(float(final))
        return results