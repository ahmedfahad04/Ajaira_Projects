class PageUtil:
    """
    PageUtil class is a versatile utility for handling pagination and search functionalities in an efficient and convenient manner.
    """

    def __init__(self, data, page_size):
        self.data = list(data)
        # fallback to 1 when invalid page_size to ensure safe behavior
        try:
            page_size = int(page_size)
        except Exception:
            page_size = 1
        if page_size <= 0:
            page_size = 1
        self.page_size = page_size
        self.total_items = len(self.data)
        self.total_pages = (self.total_items + self.page_size - 1) // self.page_size

    def get_page(self, page_number):
        # Accept floats that are ints, strings etc.
        try:
            page = int(page_number)
        except Exception:
            return []
        if self.total_pages == 0:
            return []
        # If page too large or small, return empty list rather than error
        if page < 1 or page > self.total_pages:
            return []
        start = (page - 1) * self.page_size
        end = start + self.page_size
        return self.data[start:end]

    def get_page_info(self, page_number):
        try:
            page = int(page_number)
        except Exception:
            page = 1
        if self.total_pages == 0:
            return {
                "current_page": 1,
                "per_page": self.page_size,
                "total_pages": 0,
                "total_items": self.total_items,
                "has_previous": False,
                "has_next": False,
                "data": []
            }
        if page < 1:
            page = 1
        if page > self.total_pages:
            page = self.total_pages
        data = self.get_page(page)
        return {
            "current_page": page,
            "per_page": self.page_size,
            "total_pages": self.total_pages,
            "total_items": self.total_items,
            "has_previous": page > 1,
            "has_next": page < self.total_pages,
            "data": data
        }

    def search(self, keyword):
        if keyword is None:
            keyword = ""
        key = str(keyword)
        lk = key.lower()
        # preserve original order
        matches = []
        for item in self.data:
            if lk in str(item).lower():
                matches.append(item)
        total_results = len(matches)
        total_pages = (total_results + self.page_size - 1) // self.page_size if total_results else 0
        return {
            "keyword": key,
            "total_results": total_results,
            "total_pages": total_pages,
            "results": matches
        }

# Classification response:
# variable renaming; try-except wrapper; guard clause; early return; loop rewrite; accumulator list; list conversion; temporary variable; membership test; input validation; type conversion; default value handling; empty input handling; error suppression; behavior change