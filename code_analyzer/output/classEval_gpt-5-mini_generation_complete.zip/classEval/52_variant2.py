import nltk
from nltk.stem import WordNetLemmatizer
from nltk import pos_tag, word_tokenize
from nltk.corpus import wordnet
import string
import re

nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')
nltk.download('wordnet')

class Lemmatization:
    """
    This is a class about Lemmatization, which utilizes the nltk library to perform lemmatization and part-of-speech tagging on sentences, as well as remove punctuation.
    """

    def __init__(self):
        """
        creates a WordNetLemmatizer object and stores it in the self.lemmatizer member variable.
        """
        self.lemmatizer = WordNetLemmatizer()

    def remove_punctuation(self, sentence):
        pattern = "[" + re.escape(string.punctuation) + "]"
        return re.sub(pattern, "", sentence)

    def get_pos_tag(self, sentence):
        cleaned = self.remove_punctuation(sentence)
        tokens = word_tokenize(cleaned)
        return [tag for _, tag in pos_tag(tokens)]

    def _map_tag(self, tag):
        if tag.startswith('J'):
            return wordnet.ADJ
        if tag.startswith('V'):
            return wordnet.VERB
        if tag.startswith('N'):
            return wordnet.NOUN
        if tag.startswith('R'):
            return wordnet.ADV
        return wordnet.NOUN

    def lemmatize_sentence(self, sentence):
        cleaned = self.remove_punctuation(sentence)
        tokens = word_tokenize(cleaned)
        tagged = pos_tag(tokens)
        return [self.lemmatizer.lemmatize(w, self._map_tag(t)) for w, t in tagged]