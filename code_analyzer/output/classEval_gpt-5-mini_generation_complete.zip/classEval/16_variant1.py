import re
from collections import deque

class Calculator:
    """
    This is a class for a calculator, capable of performing basic arithmetic calculations on numerical expressions using the operators +, -, *, /, and ^ (exponentiation).
    """

    def __init__(self):
        """
        Initialize the operations performed by the five operators'+','-','*','/','^'
        """
        self.operators = {
            '+': lambda x, y: x + y,
            '-': lambda x, y: x - y,
            '*': lambda x, y: x * y,
            '/': lambda x, y: x / y,
            '^': lambda x, y: x ** y
        }

    def precedence(self, operator):
        if operator == '+' or operator == '-':
            return 1
        if operator == '*' or operator == '/':
            return 2
        if operator == '^':
            return 3
        return 0

    def apply_operator(self, operand_stack, operator_stack):
        if not operator_stack or len(operand_stack) < 2:
            return operand_stack, operator_stack
        op = operator_stack.pop()
        b = operand_stack.pop()
        a = operand_stack.pop()
        try:
            res = self.operators[op](a, b)
        except Exception:
            raise
        operand_stack.append(res)
        return operand_stack, operator_stack

    def _tokenize(self, expression):
        tokens = []
        i = 0
        n = len(expression)
        while i < n:
            ch = expression[i]
            if ch.isspace():
                i += 1
                continue
            if ch in '+-' :
                # Determine if unary: at start or after '(' or another operator
                if not tokens or tokens[-1] in ('+', '-', '*', '/', '^', '('):
                    # unary sign for number
                    j = i + 1
                    num = ch
                    dot_seen = False
                    while j < n and (expression[j].isdigit() or expression[j] == '.'):
                        if expression[j] == '.':
                            if dot_seen:
                                break
                            dot_seen = True
                        num += expression[j]
                        j += 1
                    if len(num) > 1 and (num[1].isdigit() or num[1]=='.'):
                        tokens.append(num)
                        i = j
                        continue
                tokens.append(ch)
                i += 1
                continue
            if ch.isdigit() or ch == '.':
                j = i
                dot_seen = False
                num = ''
                while j < n and (expression[j].isdigit() or expression[j] == '.'):
                    if expression[j] == '.':
                        if dot_seen:
                            break
                        dot_seen = True
                    num += expression[j]
                    j += 1
                tokens.append(num)
                i = j
                continue
            if ch in ('*','/','^','(',')'):
                tokens.append(ch)
                i += 1
                continue
            # invalid char
            return None
        return tokens

    def calculate(self, expression):
        tokens = self._tokenize(expression)
        if tokens is None:
            return None
        # shunting-yard: to RPN
        output = []
        ops = []
        right_assoc = {'^'}
        for tok in tokens:
            if re.fullmatch(r'[+-]?\d+(\.\d+)?', tok):
                output.append(float(tok))
            elif tok in self.operators:
                while ops and ops[-1] in self.operators:
                    top = ops[-1]
                    if (top not in right_assoc and self.precedence(top) >= self.precedence(tok)) or (top in right_assoc and self.precedence(top) > self.precedence(tok)):
                        output.append(ops.pop())
                    else:
                        break
                ops.append(tok)
            elif tok == '(':
                ops.append(tok)
            elif tok == ')':
                while ops and ops[-1] != '(':
                    output.append(ops.pop())
                if not ops or ops[-1] != '(':
                    return None
                ops.pop()
            else:
                return None
        while ops:
            if ops[-1] in ('(',')'):
                return None
            output.append(ops.pop())
        # evaluate RPN
        stack = []
        try:
            for item in output:
                if isinstance(item, float):
                    stack.append(item)
                else:
                    if len(stack) < 2:
                        return None
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(self.operators[item](a, b))
        except Exception:
            return None
        if len(stack) != 1:
            return None
        return float(stack[0])