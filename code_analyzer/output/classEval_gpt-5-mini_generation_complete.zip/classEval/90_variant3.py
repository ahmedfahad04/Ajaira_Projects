from urllib.parse import urlsplit, parse_qs

class URLHandler:
    """
    The class supports to handle URLs, including extracting the scheme, host, path, query parameters, and fragment.
    """

    def __init__(self, url):
        """
        Initialize URLHandler's URL
        """
        self.url = url or ""
        self._split = urlsplit(self.url)

    def get_scheme(self):
        return self._split.scheme

    def get_host(self):
        return self._split.netloc

    def get_path(self):
        path = self._split.path or ""
        query = self._split.query
        fragment = self._split.fragment
        out = path
        if query:
            out += "?" + query
        if fragment:
            out += "#" + fragment
        return out

    def get_query_params(self):
        """
        Uses parse_qs and returns a dict with the first value for each key.
        """
        parsed = parse_qs(self._split.query, keep_blank_values=True)
        return {k: (v[0] if v else '') for k, v in parsed.items()}

    def get_fragment(self):
        return self._split.fragment