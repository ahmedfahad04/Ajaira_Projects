class CamelCaseMap:
    """
    This is a custom class that allows keys to be in camel case style by converting them from underscore style, which provides dictionary-like functionality.
    """

    def __init__(self):
        """
        Initialize data to an empty dictionary
        """
        self._data = {}
        # map of seen keys (original provided) to canonical camel key
        self._key_map = {}

    def __getitem__(self, key):
        ck = self._resolve_key(key)
        return self._data[ck]

    def __setitem__(self, key, value):
        ck = self._to_camel_case(key) if isinstance(key, str) else key
        # remember mapping from provided key to canonical
        self._key_map[key] = ck
        self._key_map[ck] = ck
        self._data[ck] = value

    def __delitem__(self, key):
        ck = self._resolve_key(key)
        # remove all mappings that pointed to ck
        to_remove = [k for k, v in list(self._key_map.items()) if v == ck]
        for k in to_remove:
            del self._key_map[k]
        del self._data[ck]

    def __iter__(self):
        return iter(self._data)

    def __len__(self):
        return len(self._data)

    def _convert_key(self, key):
        return self._to_camel_case(key) if isinstance(key, str) else key

    def _resolve_key(self, key):
        if not isinstance(key, str):
            return key
        if key in self._key_map:
            return self._key_map[key]
        ck = self._to_camel_case(key)
        # cache resolution
        self._key_map[key] = ck
        self._key_map[ck] = ck
        return ck

    @staticmethod
    def _to_camel_case(key):
        if not isinstance(key, str):
            return key
        parts = key.split('_')
        if not parts:
            return ''
        head = parts[0]
        tail = []
        for p in parts[1:]:
            if p:
                tail.append(p[0].upper() + p[1:])
        return head + ''.join(tail)