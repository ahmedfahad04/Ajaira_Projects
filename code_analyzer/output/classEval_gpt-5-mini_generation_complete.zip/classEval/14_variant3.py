import sqlite3
import threading

class BookManagementDB:
    """
    This is a database class as a book management system, used to handle the operations of adding, removing, updating, and searching books.
    """

    def __init__(self, db_name):
        self._lock = threading.Lock()
        # allow access from multiple threads by disabling check_same_thread
        self.connection = sqlite3.connect(db_name, check_same_thread=False)
        self.cursor = self.connection.cursor()
        self.create_table()

    def create_table(self):
        with self._lock:
            self.cursor.execute("""CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                available INTEGER NOT NULL DEFAULT 1
            )""")
            self.connection.commit()

    def add_book(self, title, author):
        with self._lock:
            self.cursor.execute(
                "INSERT INTO books (title, author, available) VALUES (?, ?, ?)",
                (title, author, 1)
            )
            self.connection.commit()
            return self.cursor.lastrowid

    def remove_book(self, book_id):
        with self._lock:
            self.cursor.execute("DELETE FROM books WHERE id = ?", (book_id,))
            self.connection.commit()
            return self.cursor.rowcount > 0

    def borrow_book(self, book_id):
        with self._lock:
            # Start a transaction to avoid race conditions
            self.cursor.execute("SELECT available FROM books WHERE id = ?", (book_id,))
            row = self.cursor.fetchone()
            if row is None:
                return False
            if row[0] == 0:
                return False
            self.cursor.execute("UPDATE books SET available = 0 WHERE id = ?", (book_id,))
            self.connection.commit()
            return True

    def return_book(self, book_id):
        with self._lock:
            self.cursor.execute("SELECT available FROM books WHERE id = ?", (book_id,))
            row = self.cursor.fetchone()
            if row is None:
                return False
            if row[0] == 1:
                return False
            self.cursor.execute("UPDATE books SET available = 1 WHERE id = ?", (book_id,))
            self.connection.commit()
            return True

    def search_books(self):
        with self._lock:
            self.cursor.execute("SELECT id, title, author, available FROM books ORDER BY id")
            return self.cursor.fetchall()