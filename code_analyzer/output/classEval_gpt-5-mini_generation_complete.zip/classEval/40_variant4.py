from dataclasses import dataclass

@dataclass
class FitnessTracker:
    """
    This is a class as fitness tracker that implements to calculate BMI (Body Mass Index) and calorie intake based on the user's height, weight, age, and sex.
    """
    height: float
    weight: float
    age: int
    sex: str

    def __post_init__(self):
        self.height = float(self.height)
        self.weight = float(self.weight)
        self.age = int(self.age)
        self.sex = str(self.sex).lower()
        self.BMI_std = {"male": (20.0, 25.0), "female": (19.0, 24.0)}

    def get_BMI(self):
        if self.height == 0:
            raise ValueError("Height cannot be zero.")
        bmi = self.weight / (self.height ** 2)
        return bmi

    def condition_judge(self):
        bmi = self.get_BMI()
        bounds = self.BMI_std.get(self.sex)
        if bounds is None:
            low = (self.BMI_std["male"][0] + self.BMI_std["female"][0]) / 2.0
            high = (self.BMI_std["male"][1] + self.BMI_std["female"][1]) / 2.0
        else:
            low, high = bounds
        if bmi < low:
            return -1
        if bmi > high:
            return 1
        return 0

    def calculate_calorie_intake(self):
        # Use provided formula with height as given
        if self.sex == "male":
            bmr = 10 * self.weight + 6.25 * self.height - 5 * self.age + 5
        elif self.sex == "female":
            bmr = 10 * self.weight + 6.25 * self.height - 5 * self.age - 161
        else:
            bmr = (10 * self.weight + 6.25 * self.height - 5 * self.age + 5 + 10 * self.weight + 6.25 * self.height - 5 * self.age - 161) / 2.0

        cond = self.condition_judge()
        factor = 1.2 if cond == 1 else (1.6 if cond == -1 else 1.4)
        return bmr * factor