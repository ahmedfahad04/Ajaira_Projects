import random

class MusicPlayer:
    """
    This is a class as a music player that provides to play, stop, add songs, remove songs, set volume, shuffle, and switch to the next or previous song.
    """

    def __init__(self):
        """
        Initializes the music player with an empty playlist, no current song, and a default volume of 50.
        """
        self.playlist = []
        self.current_song = None
        self.volume = 50

    def add_song(self, song):
        """
        Adds a song to the playlist.
        """
        if song is None:
            return
        self.playlist.append(song)
        if self.current_song is None:
            self.current_song = song

    def remove_song(self, song):
        """
        Removes a song from the playlist. Removes all occurrences.
        """
        if not self.playlist:
            return False
        removed_any = False
        new_list = []
        for s in self.playlist:
            if s == song:
                removed_any = True
            else:
                new_list.append(s)
        if not removed_any:
            return False
        # update playlist
        self.playlist = new_list
        # adjust current song
        if self.current_song == song:
            # try to keep same index position if possible
            if self.playlist:
                self.current_song = self.playlist[0]
            else:
                self.current_song = None
        return True

    def play(self):
        """
        Plays the current song in the playlist.
        """
        if not self.playlist:
            self.current_song = None
            return False
        if self.current_song is None or self.current_song not in self.playlist:
            self.current_song = self.playlist[0]
        return self.current_song

    def stop(self):
        """
        Stops the current song in the playlist.
        """
        if self.current_song is None:
            return False
        self.current_song = None
        return True

    def switch_song(self):
        """
        Switches to the next song in the playlist.
        """
        if not self.playlist:
            return False
        if self.current_song is None or self.current_song not in self.playlist:
            self.current_song = self.playlist[0]
            return True
        idx = self.playlist.index(self.current_song)
        if idx + 1 < len(self.playlist):
            self.current_song = self.playlist[idx + 1]
            return True
        return False

    def previous_song(self):
        """
        Switches to the previous song in the playlist.
        """
        if not self.playlist:
            return False
        if self.current_song is None or self.current_song not in self.playlist:
            self.current_song = self.playlist[0]
            return True
        idx = self.playlist.index(self.current_song)
        if idx - 1 >= 0:
            self.current_song = self.playlist[idx - 1]
            return True
        return False

    def set_volume(self, volume):
        """
        Sets the volume of the music player, if the volume is between 0 and 100 is valid.
        """
        if not isinstance(volume, int):
            try:
                volume = int(volume)
            except Exception:
                return False
        if 0 <= volume <= 100:
            self.volume = volume
            return True
        return False

    def shuffle(self):
        """
        Shuffles the playlist.
        """
        if not self.playlist:
            return False
        current = self.current_song
        shuffled = random.sample(self.playlist, len(self.playlist))
        self.playlist = shuffled
        if current in self.playlist:
            self.current_song = current
        else:
            self.current_song = self.playlist[0] if self.playlist else None
        return True

# Classification response:
# import reorganization;standard library helper;guard clause;accumulator list;copy before mutation;temporary variable;membership test;type conversion;try-except wrapper;input validation;default value handling;behavior change