import math
from typing import List
import itertools

class CombinationCalculator:
    """
    This is a class that provides methods to calculate the number of combinations for a specific count, calculate all possible combinations, and generate combinations with a specified number of elements.
    """

    def __init__(self, datas: List[str]):
        """
        Initialize the calculator with a list of data.
        """
        self.datas = datas

    @staticmethod
    def count(n: int, m: int) -> int:
        """
        Calculate the number of combinations for a specific count.
        """
        if n < 0 or m < 0 or m > n:
            return 0
        # multiplicative approach to avoid large intermediate factorials
        k = m if m <= n - m else n - m
        if k == 0:
            return 1
        num = 1
        den = 1
        for i in range(1, k + 1):
            num *= n - k + i
            den *= i
        return num // den

    @staticmethod
    def count_all(n: int) -> int:
        """
        Calculate the number of all possible combinations.
        """
        if n < 0:
            return 0
        limit = 2**63 - 1
        # sum_{k=1}^n C(n,k) = 2^n - 1
        total = (1 << n) - 1
        if total > limit:
            return float("inf")
        return total

    def select(self, m: int) -> List[List[str]]:
        """
        Generate combinations with a specified number of elements.
        Uses itertools.combinations for simplicity.
        """
        n = len(self.datas)
        if m <= 0 or m > n:
            return []
        return [list(c) for c in itertools.combinations(self.datas, m)]

    def select_all(self) -> List[List[str]]:
        """
        Generate all possible combinations using select method.
        """
        res: List[List[str]] = []
        n = len(self.datas)
        for k in range(1, n + 1):
            res.extend(self.select(k))
        return res

    def _select(self, dataIndex: int, resultList: List[str], resultIndex: int, result: List[List[str]]):
        """
        Recursive implementation compatible with the example usage.
        """
        n = len(self.datas)
        r = len(resultList)
        if resultIndex == r:
            result.append(resultList.copy())
            return
        max_start = n - (r - resultIndex)
        for i in range(dataIndex, max_start + 1):
            resultList[resultIndex] = self.datas[i]
            self._select(i + 1, resultList, resultIndex + 1, result)