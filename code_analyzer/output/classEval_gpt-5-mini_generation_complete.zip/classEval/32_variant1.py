import string

class DecryptionUtils:
    def __init__(self, key):
        self.key = key or ""

    def caesar_decipher(self, ciphertext, shift):
        if not isinstance(shift, int):
            shift = int(shift)
        s = shift % 26
        result = []
        for ch in ciphertext:
            if 'a' <= ch <= 'z':
                o = ord('a') + (ord(ch) - ord('a') - s) % 26
                result.append(chr(o))
            elif 'A' <= ch <= 'Z':
                o = ord('A') + (ord(ch) - ord('A') - s) % 26
                result.append(chr(o))
            else:
                result.append(ch)
        return ''.join(result)

    def vigenere_decipher(self, ciphertext):
        key = [ord(c.lower()) - ord('a') for c in self.key if c.isalpha()]
        if not key:
            return ciphertext
        out = []
        ki = 0
        for ch in ciphertext:
            if ch.isalpha():
                base = ord('A') if ch.isupper() else ord('a')
                k = key[ki % len(key)]
                val = (ord(ch) - base - k) % 26
                out.append(chr(base + val))
                ki += 1
            else:
                out.append(ch)
        return ''.join(out)

    def rail_fence_decipher(self, encrypted_text, rails):
        if rails is None or rails <= 1:
            return encrypted_text
        n = len(encrypted_text)
        rail_map = [[] for _ in range(rails)]
        pattern = []
        r = 0
        step = 1
        for i in range(n):
            pattern.append(r)
            rail_map[r].append(None)
            if r == 0:
                step = 1
            elif r == rails - 1:
                step = -1
            r += step
        idx = 0
        rails_chars = []
        for r in range(rails):
            count = len(rail_map[r])
            rails_chars.append(list(encrypted_text[idx:idx+count]))
            idx += count
        res = []
        pointers = [0]*rails
        for p in pattern:
            res.append(rails_chars[p][pointers[p]])
            pointers[p] += 1
        return ''.join(res)