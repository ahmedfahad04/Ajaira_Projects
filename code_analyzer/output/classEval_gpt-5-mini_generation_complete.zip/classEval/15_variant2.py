class BoyerMooreSearch:
    """
    his is a class that implements the Boyer-Moore algorithm for string searching, which is used to find occurrences of a pattern within a given text.
    """

    def __init__(self, text, pattern):
        """
        Initializes the BoyerMooreSearch class with the given text and pattern.
        :param text: The text to be searched, str.
        :param pattern: The pattern to be searched for, str.
        """
        self.text, self.pattern = text, pattern
        self.textLen, self.patLen = len(text), len(pattern)
        # Build last occurrence table using enumerate over reversed to ensure rightmost wins
        self._last = {}
        for idx in range(self.patLen):
            self._last[self.pattern[idx]] = idx

    def match_in_pattern(self, char):
        """
        Finds the rightmost occurrence of a character in the pattern.
        """
        return self._last.get(char, -1)

    def mismatch_in_text(self, currentPos):
        """
        Determines the position of the first dismatch between the pattern and the text.
        """
        if self.patLen == 0:
            return -1
        # compare from rightmost character of the pattern to left
        j = self.patLen - 1
        while j >= 0:
            if currentPos + j >= self.textLen or self.pattern[j] != self.text[currentPos + j]:
                return j
            j -= 1
        return -1

    def bad_character_heuristic(self):
        """
        Finds all occurrences of the pattern in the text.
        """
        if self.patLen == 0:
            return list(range(self.textLen + 1))
        result = []
        i = 0
        while i <= self.textLen - self.patLen:
            j = self.mismatch_in_text(i)
            if j == -1:
                result.append(i)
                # use last occurrence of trailing character
                trailing = self.text[i + self.patLen - 1]
                last_pos = self._last.get(trailing, -1)
                shift = self.patLen - last_pos
                if shift <= 0:
                    shift = 1
                i += shift
            else:
                bad = self.text[i + j]
                last_pos = self._last.get(bad, -1)
                shift = j - last_pos
                if shift <= 0:
                    shift = 1
                i += shift
        return result