class NumberConverter:
    """
    The class allows to convert  decimal to binary, octal and hexadecimal repectively and contrarily
    """

    @staticmethod
    def decimal_to_binary(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        n = decimal_num
        if n == 0:
            return '0'
        sign = '-' if n < 0 else ''
        n = abs(n)
        # use built-in but strip prefix
        return sign + bin(n)[2:]

    @staticmethod
    def binary_to_decimal(binary_num):
        if isinstance(binary_num, int):
            binary_num = str(binary_num)
        s = binary_num.strip()
        if s.startswith('-'):
            return -int(s[1:].lstrip('0') or '0', 2)
        s = s.lstrip('0') or '0'
        # allow optional 0b prefix
        if s.startswith('0b') or s.startswith('0B'):
            s = s[2:]
        return int(s, 2)

    @staticmethod
    def decimal_to_octal(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        n = decimal_num
        sign = '-' if n < 0 else ''
        n = abs(n)
        return sign + oct(n)[2:]

    @staticmethod
    def octal_to_decimal(octal_num):
        if isinstance(octal_num, int):
            octal_num = str(octal_num)
        s = octal_num.strip()
        neg = False
        if s.startswith('-'):
            neg = True
            s = s[1:]
        if s.startswith('0o') or s.startswith('0O'):
            s = s[2:]
        s = s.lstrip('0') or '0'
        val = int(s, 8)
        return -val if neg else val

    @staticmethod
    def decimal_to_hex(decimal_num):
        if not isinstance(decimal_num, int):
            raise TypeError("decimal_num must be int")
        n = decimal_num
        sign = '-' if n < 0 else ''
        n = abs(n)
        return sign + hex(n)[2:]

    @staticmethod
    def hex_to_decimal(hex_num):
        if isinstance(hex_num, int):
            hex_num = format(hex_num, 'x')
        s = hex_num.strip()
        neg = False
        if s.startswith('-'):
            neg = True
            s = s[1:]
        if s.startswith('0x') or s.startswith('0X'):
            s = s[2:]
        s = s.lstrip('0') or '0'
        val = int(s, 16)
        return -val if neg else val

# Classification response:
# guard clause; early return; conditional expression; temporary variable; builtin function; input validation; boundary case handling; type conversion; behavior change