import zipfile
import os
from pathlib import Path


class ZipFileProcessor:
    """
    This is a compressed file processing class that provides the ability to read and decompress compressed files
    """

    def __init__(self, file_name):
        self.file_name = file_name

    def read_zip_file(self):
        try:
            if not Path(self.file_name).exists():
                return None
            # Return a ZipFile instance for further operations
            z = zipfile.ZipFile(self.file_name, mode="r")
            # Validate by listing names (will raise if not a real zip)
            _ = z.namelist()
            return z
        except Exception:
            try:
                z.close()
            except Exception:
                pass
            return None

    def extract_all(self, output_path):
        try:
            z = self.read_zip_file()
            if z is None:
                return False
            out = Path(output_path)
            out.mkdir(parents=True, exist_ok=True)
            with z:
                z.extractall(path=str(out))
            return True
        except Exception:
            return False

    def extract_file(self, file_name, output_path):
        try:
            z = self.read_zip_file()
            if z is None:
                return False
            out = Path(output_path)
            out.mkdir(parents=True, exist_ok=True)
            with z:
                # try exact then fuzzy matching
                if file_name in z.namelist():
                    z.extract(file_name, path=str(out))
                    return True
                for n in z.namelist():
                    if n.endswith("/"):
                        continue
                    if os.path.basename(n) == file_name or n.endswith(file_name):
                        z.extract(n, path=str(out))
                        return True
            return False
        except Exception:
            return False

    def create_zip_file(self, files, output_file_name):
        try:
            files = list(files or [])
            if not files:
                return False
            out = Path(output_file_name)
            if out.is_dir():
                out = out / "archive.zip"
            out.parent.mkdir(parents=True, exist_ok=True)
            if out.suffix.lower() != ".zip":
                out = out.with_suffix(".zip")
            compression = zipfile.ZIP_DEFLATED if hasattr(zipfile, "ZIP_DEFLATED") else zipfile.ZIP_STORED
            wrote_any = False
            with zipfile.ZipFile(str(out), "w", compression=compression) as z:
                for f in files:
                    p = Path(f)
                    if not p.exists():
                        continue
                    if p.is_file():
                        z.write(str(p), arcname=str(p.name))
                        wrote_any = True
                    else:
                        for root, _, names in os.walk(p):
                            for name in names:
                                full = Path(root) / name
                                # preserve directory structure relative to the provided path
                                arc = str(full.relative_to(p))
                                if arc.startswith(".."):
                                    arc = str(full.name)
                                z.write(str(full), arcname=arc)
                                wrote_any = True
            return wrote_any
        except Exception:
            return False