import openpyxl
from openpyxl import Workbook
import os
import time


class ExcelProcessor:
    """
    This is a class for processing excel files, including readring and writing excel data, as well as processing specific operations and saving as a new excel file.
    """

    def __init__(self):
        self.last_file = None

    def read_excel(self, file_name):
        """
        Reading data from Excel files
        :param file_name:str, Excel file name to read
        :return:list of data, Data in Excel
        """
        try:
            wb = openpyxl.load_workbook(file_name, read_only=True, data_only=True)
            ws = wb.active
            data = []
            for row in ws.iter_rows(values_only=True):
                data.append(tuple(row))
            self.last_file = file_name
            return data
        except Exception:
            return []

    def write_excel(self, data, file_name):
        """
        Write data to the specified Excel file
        :param data: list, Data to be written
        :param file_name: str, Excel file name to write to
        :return: 0 or 1, 1 represents successful writing, 0 represents failed writing
        """
        try:
            wb = Workbook()
            ws = wb.active
            if data:
                for row in data:
                    if isinstance(row, dict):
                        headers = list(row.keys())
                        ws.append(headers)
                        break
                if isinstance(data[0], dict):
                    headers = list(data[0].keys())
                    for d in data:
                        ws.append([d.get(h) for h in headers])
                else:
                    for row in data:
                        ws.append(list(row))
            wb.save(file_name)
            return 1
        except Exception:
            return 0

    def process_excel_data(self, N, save_file_name):
        """
        Change the specified column in the Excel file to uppercase
        :param N: int, The serial number of the column that want to change
        :param save_file_name: str, source file name
        :return:(int, str), The former is the return value of write_excel, while the latter is the saved file name of the processed data
        """
        try:
            data = self.read_excel(save_file_name)
            # Only uppercase actual string values; preserve numbers/None
            new_data = []
            for row in data:
                row = list(row)
                if 1 <= N <= len(row):
                    v = row[N - 1]
                    if isinstance(v, str):
                        row[N - 1] = v.upper()
                new_data.append(tuple(row))
            base, ext = os.path.splitext(save_file_name)
            ts = int(time.time())
            out = f"{base}_proc_{N}_{ts}{ext or '.xlsx'}"
            res = self.write_excel(new_data, out)
            return res, out
        except Exception:
            base, ext = os.path.splitext(save_file_name)
            out = f"{base}_proc_{N}{ext or '.xlsx'}"
            return 0, out