from itertools import cycle

class DecryptionUtils:
    def __init__(self, key):
        self.key = key or ""

    def caesar_decipher(self, ciphertext, shift):
        try:
            s = int(shift) % 26
        except Exception:
            s = 0
        def dec_char(c):
            if 'a' <= c <= 'z':
                return chr((ord(c) - ord('a') - s) % 26 + ord('a'))
            if 'A' <= c <= 'Z':
                return chr((ord(c) - ord('A') - s) % 26 + ord('A'))
            return c
        return ''.join(dec_char(c) for c in ciphertext)

    def vigenere_decipher(self, ciphertext):
        key_stream = [ord(k.lower()) - ord('a') for k in self.key if k.isalpha()]
        if not key_stream:
            return ciphertext
        it = cycle(key_stream)
        out = []
        for ch in ciphertext:
            if ch.isalpha():
                k = next(it)
                if ch.islower():
                    base = ord('a')
                else:
                    base = ord('A')
                out.append(chr((ord(ch) - base - k) % 26 + base))
            else:
                out.append(ch)
        return ''.join(out)

    def rail_fence_decipher(self, encrypted_text, rails):
        if rails is None or rails <= 1:
            return encrypted_text
        n = len(encrypted_text)
        pattern = []
        r = 0
        dir = 1
        for _ in range(n):
            pattern.append(r)
            if r == 0:
                dir = 1
            elif r == rails - 1:
                dir = -1
            r += dir
        counts = [0]*rails
        for p in pattern:
            counts[p] += 1
        parts = []
        idx = 0
        for c in counts:
            parts.append(list(encrypted_text[idx:idx+c]))
            idx += c
        pointers = [0]*rails
        res = []
        for p in pattern:
            res.append(parts[p][pointers[p]])
            pointers[p] += 1
        return ''.join(res)