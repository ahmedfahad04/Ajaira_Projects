class PushBoxGame:
    """
    This class implements a functionality of a sokoban game, where the player needs to move boxes to designated targets in order to win.
    """

    def __init__(self, map):
        self.map = map
        self.player_row = 0
        self.player_col = 0
        self.targets = []
        self.boxes = []
        self.target_count = 0
        self.is_game_over = False
        self._rows = len(map)
        self._cols = len(map[0]) if self._rows > 0 else 0
        self.init_game()

    def init_game(self):
        self.targets = []
        self.boxes = []
        self.player_row = 0
        self.player_col = 0
        for r, line in enumerate(self.map):
            for c, ch in enumerate(line):
                if ch == 'O':
                    self.player_row, self.player_col = r, c
                elif ch == 'G':
                    self.targets.append((r, c))
                elif ch == 'X':
                    self.boxes.append((r, c))
        self.target_count = len(self.targets)
        # keep sets for quick checks internally
        self._targets_set = set(self.targets)
        self._boxes_set = set(self.boxes)
        self.is_game_over = self.check_win()

    def check_win(self):
        if not self._boxes_set:
            self.is_game_over = (self.target_count == 0)
            return self.is_game_over
        self.is_game_over = all(pos in self._targets_set for pos in self._boxes_set)
        return self.is_game_over

    def move(self, direction):
        if self.is_game_over:
            return True
        dirs = {'w': (-1, 0), 's': (1, 0), 'a': (0, -1), 'd': (0, 1)}
        if direction not in dirs:
            return self.is_game_over
        dr, dc = dirs[direction]
        nr, nc = self.player_row + dr, self.player_col + dc
        # boundary check
        if not (0 <= nr < self._rows and 0 <= nc < self._cols):
            return self.is_game_over
        dest_char = self.map[nr][nc]
        # if wall, blocked
        if dest_char == '#':
            return self.is_game_over
        # if there's a box
        if (nr, nc) in self._boxes_set:
            # position beyond box
            br, bc = nr + dr, nc + dc
            if not (0 <= br < self._rows and 0 <= bc < self._cols):
                return self.is_game_over
            beyond_char = self.map[br][bc]
            if beyond_char == '#' or (br, bc) in self._boxes_set:
                return self.is_game_over
            # move box
            self._boxes_set.remove((nr, nc))
            self._boxes_set.add((br, bc))
        # move player
        self.player_row, self.player_col = nr, nc
        self.boxes = list(self._boxes_set)
        return self.check_win()

# Classification response:
# enumerate loop; set conversion; membership test; any/all usage; early return; guard clause; input validation; boundary case handling; tuple unpacking; list conversion; in-place mutation; dictionary lookup; state variable; flattened conditional