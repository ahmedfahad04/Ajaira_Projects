class MetricsCalculator:
    """
    The class calculates precision, recall, F1 score, and accuracy based on predicted and true labels.
    """

    def __init__(self):
        """
        Initialize the number of all four samples to 0
        """
        self.true_positives = 0
        self.false_positives = 0
        self.false_negatives = 0
        self.true_negatives = 0

    def update(self, predicted_labels, true_labels):
        """
        Update using index sets for positives.
        """
        pred_pos = {i for i, p in enumerate(predicted_labels) if p == 1}
        true_pos = {i for i, t in enumerate(true_labels) if t == 1}
        tp = len(pred_pos & true_pos)
        fp = len(pred_pos - true_pos)
        fn = len(true_pos - pred_pos)
        total_positions = len(list(zip(predicted_labels, true_labels)))
        tn = total_positions - tp - fp - fn
        self.true_positives += tp
        self.false_positives += fp
        self.false_negatives += fn
        self.true_negatives += tn

    def _counts(self, predicted_labels, true_labels):
        pred_pos = {i for i, p in enumerate(predicted_labels) if p == 1}
        true_pos = {i for i, t in enumerate(true_labels) if t == 1}
        tp = len(pred_pos & true_pos)
        fp = len(pred_pos - true_pos)
        fn = len(true_pos - pred_pos)
        total_positions = len(list(zip(predicted_labels, true_labels)))
        tn = total_positions - tp - fp - fn
        return tp, fp, fn, tn

    def precision(self, predicted_labels, true_labels):
        tp, fp, _, _ = self._counts(predicted_labels, true_labels)
        return tp / (tp + fp) if (tp + fp) > 0 else 0.0

    def recall(self, predicted_labels, true_labels):
        tp, _, fn, _ = self._counts(predicted_labels, true_labels)
        return tp / (tp + fn) if (tp + fn) > 0 else 0.0

    def f1_score(self, predicted_labels, true_labels):
        p = self.precision(predicted_labels, true_labels)
        r = self.recall(predicted_labels, true_labels)
        return (2 * p * r) / (p + r) if (p + r) > 0 else 0.0

    def accuracy(self, predicted_labels, true_labels):
        tp, fp, fn, tn = self._counts(predicted_labels, true_labels)
        total = tp + fp + fn + tn
        return (tp + tn) / total if total > 0 else 0.0

# Classification response:
# set comprehension; enumerate loop; helper function extraction; conditional expression; list conversion; zip usage; temporary variable; behavior change