import logging
import datetime

class AccessGatewayFilter:
    """
    This class is a filter used for accessing gateway filtering, primarily for authentication and access log recording.
    """

    def __init__(self):
        # allowlist and denylist can be extended
        self.allow_without_auth = ['/login', '/signup']
        self.api_prefix = '/api'
        self.current_user = None
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger('AccessGatewayFilter')

    def filter(self, request):
        # Basic structure and robustness checks
        if request is None or not isinstance(request, dict):
            return False
        path = request.get('path', '')
        method = (request.get('method') or 'GET').upper()

        # Always allow simple endpoints and preflight calls
        if any(path.startswith(p) for p in self.allow_without_auth):
            return True
        if method == 'OPTIONS':
            return True

        # For API paths require JWT auth
        if path.startswith(self.api_prefix):
            user = self.get_jwt_user(request)
            if not user:
                return False
            self.set_current_user_info_and_log(user)
            return True

        # Non-API endpoints default to allow
        return True

    def is_start_with(self, request_uri):
        if not isinstance(request_uri, str):
            return False
        return request_uri.startswith('/api') or request_uri.startswith('/login')

    def get_jwt_user(self, request):
        headers = request.get('headers') or {}
        # Support Authorization value either as dict or string "user:jwt"
        auth = headers.get('Authorization') or headers.get('authorization')
        if auth is None:
            return None
        if isinstance(auth, dict):
            user = auth.get('user')
            jwt = auth.get('jwt')
        elif isinstance(auth, str):
            # parse "user:jwt" or "user|jwt"
            if ':' in auth:
                parts = auth.split(':', 1)
            elif '|' in auth:
                parts = auth.split('|', 1)
            else:
                parts = [None, auth]
            user = None
            jwt = parts[1] if len(parts) > 1 else None
            if parts[0]:
                user = {'name': parts[0]}
        else:
            return None

        # if user object present without jwt, accept as internal auth
        if user and not jwt:
            return user

        if not jwt or not isinstance(jwt, str):
            return None

        # token should end with today's date string
        today = str(datetime.date.today())
        if not jwt.endswith(today):
            return None

        # username is token prefix
        username = jwt[:-len(today)]
        if username == '':
            return None

        # if user provided, verify match
        if isinstance(user, dict):
            uname = user.get('name') or user.get('username')
            if uname and uname != username:
                return None
            return user

        return {'name': username}

    def set_current_user_info_and_log(self, user):
        self.current_user = user
        t = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
        name = user.get('name') if isinstance(user, dict) else str(user)
        self.logger.info("User %s accessed at %s", name, t)