class Order:
    def __init__(self):
        self.menu = []
        # use mapping for quick lookup of selected dishes
        self.selected_dishes = {}  # dish -> {"count": int, "price": float}
        self.sales = {}

    def add_dish(self, dish):
        name = dish.get("dish")
        count = int(dish.get("count", 0))
        if not name or count <= 0:
            return False
        # find menu entry index
        for i, m in enumerate(self.menu):
            if m.get("dish") == name:
                if m.get("count", 0) < count:
                    return False
                # decrease inventory
                self.menu[i]["count"] = m.get("count", 0) - count
                price = m.get("price", dish.get("price"))
                if name in self.selected_dishes:
                    self.selected_dishes[name]["count"] += count
                else:
                    self.selected_dishes[name] = {"count": count, "price": price}
                return True
        return False

    def calculate_total(self):
        total = 0.0
        for name, info in self.selected_dishes.items():
            price = info.get("price", 0.0)
            count = info.get("count", 0)
            sale = self.sales.get(name, 1.0)
            total += price * count * sale
        return float(total)

    def checkout(self):
        if not self.selected_dishes:
            return False
        return self.calculate_total()

# Classification response:
# variable renaming;accumulator dict;enumerate usage;guard clause;in-place mutation;tuple unpacking;membership test;input validation;type conversion;default value handling;frequency counting;empty input handling