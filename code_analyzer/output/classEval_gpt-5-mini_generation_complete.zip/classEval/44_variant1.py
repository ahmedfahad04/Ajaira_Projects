import re
import string
import gensim
from bs4 import BeautifulSoup
from bs4 import NavigableString

class HtmlUtil:
    """
    This is a class as util for html, supporting for formatting and extracting code from HTML text, including cleaning up the text and converting certain elements into specific marks.
    """

    def __init__(self):
        """
        Initialize a series of labels
        """
        self.SPACE_MARK = '-SPACE-'
        self.JSON_MARK = '-JSON-'
        self.MARKUP_LANGUAGE_MARK = '-MARKUP_LANGUAGE-'
        self.URL_MARK = '-URL-'
        self.NUMBER_MARK = '-NUMBER-'
        self.TRACE_MARK = '-TRACE-'
        self.COMMAND_MARK = '-COMMAND-'
        self.COMMENT_MARK = '-COMMENT-'
        self.CODE_MARK = '-CODE-'

    @staticmethod
    def __format_line_feed(text):
        """
        Replace consecutive line breaks with a single line break
        :param text: string with consecutive line breaks
        :return:string, replaced text with single line break
        """
        # Collapse multiple blank lines (allow whitespace between)
        return re.sub(r'\n\s*\n+', '\n', text)

    def format_line_html_text(self, html_text):
        """
        get the html text without the code, and add the code tag -CODE- where the code is
        :param html_text:string
        :return:string
        """
        soup = BeautifulSoup(html_text, 'html.parser')
        # Replace all <pre> tags with a text node that is the CODE_MARK so that get_text keeps order
        for pre in soup.find_all('pre'):
            pre.replace_with(NavigableString(self.CODE_MARK))
        # Also replace standalone <code> blocks not inside <pre>
        for code in soup.find_all('code'):
            if code.parent.name != 'pre':
                code.replace_with(NavigableString(self.CODE_MARK))
        body = soup.body or soup
        text = body.get_text(separator='\n')
        # Normalize line feeds
        text = self.__format_line_feed(text)
        # Trim whitespace at start/end of lines but keep indentation inside code markers (there is no code content here)
        lines = [line.strip() for line in text.splitlines()]
        # Remove empty lines except when they represent code marker lines
        out_lines = []
        for line in lines:
            if not line:
                continue
            out_lines.append(line)
        return '\n'.join(out_lines).strip()

    def extract_code_from_html_text(self, html_text):
        """
        extract codes from the html body
        :param html_text: string, html text
        :return: the list of code
        """
        soup = BeautifulSoup(html_text, 'html.parser')
        codes = []
        # Extract text from each <pre>; if it contains <code>, prefer the inner <code>
        for pre in soup.find_all('pre'):
            inner_code = pre.find('code')
            if inner_code:
                txt = inner_code.get_text()
            else:
                txt = pre.get_text()
            # Strip only leading/trailing linebreaks, keep indentation and internal spaces
            txt = txt.strip('\r\n')
            codes.append(txt)
        return codes