class Order:
    def __init__(self):
        self.menu = []
        # store selected as dict to simplify updates, but also maintain list for external access
        self.selected_map = {}
        self.selected_dishes = []
        self.sales = {}

    def _rebuild_selected_list(self):
        self.selected_dishes = []
        for name, info in self.selected_map.items():
            self.selected_dishes.append({"dish": name, "count": info["count"], "price": info["price"]})

    def add_dish(self, dish):
        # Validate input
        name = dish.get("dish")
        count = dish.get("count", 0)
        if not name or count <= 0:
            return False
        # find menu entry
        for entry in self.menu:
            if entry.get("dish") == name:
                if entry.get("count", 0) < count:
                    return False
                # deduct inventory
                entry["count"] = entry.get("count", 0) - count
                price = entry.get("price", dish.get("price"))
                if name in self.selected_map:
                    self.selected_map[name]["count"] += count
                else:
                    self.selected_map[name] = {"count": count, "price": price}
                self._rebuild_selected_list()
                return True
        return False

    def calculate_total(self):
        total = 0.0
        for name, info in self.selected_map.items():
            price = info.get("price", 0.0)
            count = info.get("count", 0)
            multiplier = self.sales.get(name, 1.0)
            total += price * count * multiplier
        return float(total)

    def checkout(self):
        if not self.selected_map:
            return False
        return self.calculate_total()

# Classification response:
# helper function extraction;accumulator dict;dictionary lookup;guard clause;early return;membership test;frequency counting;input validation;default value handling;type conversion;behavior change