class AutomaticGuitarSimulator:
    def __init__(self, text) -> None:
        self.play_text = text if text is not None else ""

    def interpret(self, display=False):
        s = (self.play_text or "").strip()
        if not s:
            return []
        result = []
        for token in s.split():
            # find first digit in token
            idx = 0
            while idx < len(token) and not token[idx].isdigit():
                idx += 1
            if idx == len(token):
                continue
            chord = token[:idx]
            tune = token[idx:]
            entry = {"Chord": chord, "Tune": tune}
            result.append(entry)
            if display:
                self.display(chord, tune)
        return result

    def display(self, key, value):
        out = "Normal Guitar Playing -- Chord: %s, Play Tune: %s" % (key, value)
        print(out)
        return out