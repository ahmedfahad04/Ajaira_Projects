from collections import OrderedDict

class SignInSystem:
    """
    This is a class as sigin in system, including adding users, signing in/out, checking sign-in status, and retrieving signed-in/not signed-in users.
    """

    def __init__(self):
        """
        Initialize the sign-in system.
        """
        self.users = OrderedDict()
        self._signed_in = set()

    def add_user(self, username):
        if username in self.users:
            return False
        self.users[username] = False
        return True

    def sign_in(self, username):
        if username not in self.users:
            return False
        self.users[username] = True
        self._signed_in.add(username)
        return True

    def check_sign_in(self, username):
        return username in self._signed_in and self.users.get(username, False)

    def all_signed_in(self):
        if not self.users:
            return True
        return len(self._signed_in) == len(self.users)

    def all_not_signed_in(self):
        return [u for u in self.users.keys() if u not in self._signed_in]