import xml.etree.ElementTree as ET


class XMLProcessor:
    """
    XML handler using iterparse for scalable reading and recursive search for finding.
    """

    def __init__(self, file_name):
        self.file_name = file_name
        self.root = None

    def read_xml(self):
        # use iterparse to get root (helps with large files)
        context = ET.iterparse(self.file_name, events=("start", "end"))
        root = None
        for event, elem in context:
            if event == "start" and root is None:
                root = elem
        # parse normally to ensure tree structure is available
        tree = ET.parse(self.file_name)
        self.root = tree.getroot()
        return self.root

    def write_xml(self, file_name):
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return False
        try:
            ET.ElementTree(self.root).write(file_name, encoding="utf-8", xml_declaration=True)
            return True
        except Exception:
            return False

    def process_xml_data(self, file_name):
        """
        Appends '-processed' to text nodes of leaf elements (no child elements).
        """
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return False
        for elem in list(self.root.iter()):
            children = list(elem)
            if not children:
                if elem.text and elem.text.strip():
                    elem.text = elem.text.strip() + "-processed"
        return self.write_xml(file_name)

    def find_element(self, element_name):
        if self.root is None:
            try:
                self.read_xml()
            except Exception:
                return []

        # recursive generator to find elements by tag name
        results = []

        def recurse(node):
            if node.tag == element_name:
                results.append(node)
            for child in node:
                recurse(child)

        recurse(self.root)
        return results