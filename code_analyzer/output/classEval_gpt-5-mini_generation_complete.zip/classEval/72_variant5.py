import re

class RegexUtils:
    def _ensure_compiled(self, pattern, flags=0):
        if hasattr(pattern, 'search'):
            return pattern
        return re.compile(pattern, flags)

    def match(self, pattern, text):
        cp = self._ensure_compiled(pattern)
        # prefer fullmatch semantics if possible
        try:
            return cp.fullmatch(text) is not None
        except Exception:
            return cp.search(text) is not None

    def findall(self, pattern, text):
        cp = self._ensure_compiled(pattern)
        return cp.findall(text)

    def split(self, pattern, text):
        cp = self._ensure_compiled(pattern)
        return cp.split(text)

    def sub(self, pattern, replacement, text):
        cp = self._ensure_compiled(pattern)
        return cp.sub(replacement, text)

    def generate_email_pattern(self):
        # produce a conventional email regex
        return r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'

    def generate_phone_number_pattern(self):
        return r'\b\d{3}-\d{3}-\d{4}\b'

    def generate_split_sentences_pattern(self):
        return r'[.!?][\s]{1,2}(?=[A-Z])'

    def split_sentences(self, text):
        # find sentence boundaries by scanning punctuation and capitalization
        if not text:
            return []
        boundaries = [0]
        for m in re.finditer(r'([.!?])\s+(?=[A-Z])', text):
            # include end of punctuation as boundary
            end = m.start(0) + 1  # keep punctuation as part of left sentence
            boundaries.append(end)
        boundaries.append(len(text))
        sentences = []
        for i in range(len(boundaries)-1):
            s = text[boundaries[i]:boundaries[i+1]].strip()
            sentences.append(s)
        # Remove punctuation from all but last
        for i in range(len(sentences)-1):
            sentences[i] = re.sub(r'[.!?]+$', '', sentences[i]).strip()
        return sentences

    def validate_phone_number(self, phone_number):
        pat = self.generate_phone_number_pattern()
        try:
            return re.fullmatch(pat, phone_number) is not None
        except re.error:
            return False

    def extract_email(self, text):
        pat = self.generate_email_pattern()
        try:
            return re.findall(pat, text, flags=re.IGNORECASE)
        except re.error:
            return []

# Classification response:
# helper function extraction;regex usage;try-except wrapper;error suppression;guard clause;empty input handling;loop rewrite;accumulator list;in-place mutation;index-based loop