import random

class MusicPlayer:
    """
    This is a class as a music player that provides to play, stop, add songs, remove songs, set volume, shuffle, and switch to the next or previous song.
    Implements playlist as immutable tuple internally to emphasize state changes as replacements.
    """

    def __init__(self):
        """
        Initializes the music player with an empty playlist, no current song, and a default volume of 50.
        """
        self.playlist = tuple()
        self.current_song = None
        self.volume = 50

    def add_song(self, song):
        """
        Adds a song to the playlist.
        """
        if song is None:
            return
        self.playlist = self.playlist + (song,)
        if self.current_song is None:
            self.current_song = song

    def remove_song(self, song):
        """
        Removes a song from the playlist. Removes first occurrence only.
        """
        if song not in self.playlist:
            return False
        lst = list(self.playlist)
        idx = lst.index(song)
        lst.pop(idx)
        self.playlist = tuple(lst)
        if self.current_song == song:
            if idx < len(self.playlist):
                self.current_song = self.playlist[idx]
            elif self.playlist:
                self.current_song = self.playlist[-1]
            else:
                self.current_song = None
        return True

    def play(self):
        """
        Plays the current song in the playlist.
        """
        if not self.playlist:
            self.current_song = None
            return False
        if self.current_song is None or self.current_song not in self.playlist:
            self.current_song = self.playlist[0]
        return self.current_song

    def stop(self):
        """
        Stops the current song in the playlist.
        """
        if self.current_song is None:
            return False
        self.current_song = None
        return True

    def switch_song(self):
        """
        Switches to the next song in the playlist.
        """
        if not self.playlist:
            return False
        if self.current_song is None:
            self.current_song = self.playlist[0]
            return True
        try:
            idx = self.playlist.index(self.current_song)
        except ValueError:
            self.current_song = self.playlist[0]
            return True
        if idx + 1 < len(self.playlist):
            self.current_song = self.playlist[idx + 1]
            return True
        return False

    def previous_song(self):
        """
        Switches to the previous song in the playlist.
        """
        if not self.playlist:
            return False
        if self.current_song is None:
            self.current_song = self.playlist[0]
            return True
        try:
            idx = self.playlist.index(self.current_song)
        except ValueError:
            self.current_song = self.playlist[0]
            return True
        if idx - 1 >= 0:
            self.current_song = self.playlist[idx - 1]
            return True
        return False

    def set_volume(self, volume):
        """
        Sets the volume of the music player, if the volume is between 0 and 100 is valid.
        """
        try:
            v = int(volume)
        except Exception:
            return False
        if 0 <= v <= 100:
            self.volume = v
            return True
        return False

    def shuffle(self):
        """
        Shuffles the playlist.
        """
        if not self.playlist:
            return False
        lst = list(self.playlist)
        random.shuffle(lst)
        self.playlist = tuple(lst)
        if self.current_song not in self.playlist:
            self.current_song = self.playlist[0] if self.playlist else None
        return True

# Classification response:
# import reorganization; list conversion; copy before mutation; temporary variable; guard clause; exception handling; empty input handling; type conversion; default value handling