from datetime import datetime

class EmailClient:
    """
    This is a class that serves as an email client, implementing functions such as checking emails, determining whether there is sufficient space, and cleaning up space
    """

    def __init__(self, addr, capacity) -> None:
        """
        Initializes the EmailClient class with the email address and the capacity of the email box.
        :param addr: The email address, str.
        :param capacity: The capacity of the email box, float.
        """
        self.addr = addr
        self.capacity = float(capacity)
        self.inbox = []

    def send_to(self, recv, content, size):
        """
        Sends an email to the given email address.
        """
        if not isinstance(recv, EmailClient):
            return False
        size = float(size)
        # If receiver would be over capacity, do not send
        if recv.is_full_with_one_more_email(size):
            return False
        email = {
            'sender': self.addr,
            'receiver': recv.addr,
            'content': content,
            'size': size,
            'time': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'state': 'unread'
        }
        recv.inbox.append(email)
        return True

    def fetch(self):
        """
        Retrieves the first unread email in the email box and marks it as read.
        """
        for msg in self.inbox:
            if msg.get('state') == 'unread':
                msg['state'] = 'read'
                return msg
        return None

    def is_full_with_one_more_email(self, size):
        """
        Determines whether the email box is full after adding an email of the given size.
        """
        size = float(size)
        return (self.get_occupied_size() + size) > self.capacity

    def get_occupied_size(self):
        """
        Gets the total size of the emails in the email box.
        """
        total = 0.0
        for msg in self.inbox:
            try:
                total += float(msg.get('size', 0))
            except Exception:
                continue
        # If total is integer-like return int for consistency with examples
        if total.is_integer():
            return int(total)
        return total

    def clear_inbox(self, size):
        """
        Clears the email box by deleting the oldest emails until the email box has enough space to accommodate the given size.
        Oldest is considered the earliest element in the list (index 0).
        """
        size = float(size)
        # Remove from the front until enough space
        while self.is_full_with_one_more_email(size) and self.inbox:
            self.inbox.pop(0)