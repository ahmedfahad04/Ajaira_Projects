class AvgPartition:
    """
    This is a class that partitions the given list into different blocks by specifying the number of partitions, with each block having a uniformly distributed length.
    """

    def __init__(self, lst, limit):
        if not isinstance(limit, int):
            raise TypeError("limit must be an integer")
        if limit <= 0:
            raise ValueError("limit must be > 0")
        self.lst = list(lst)
        self.limit = limit

    def setNum(self):
        n = len(self.lst)
        q, r = divmod(n, self.limit)
        return (q, r)

    def get(self, index):
        if not isinstance(index, int):
            raise TypeError("index must be an integer")
        if index < 0:
            index += self.limit
        if index < 0 or index >= self.limit:
            raise IndexError("partition index out of range")
        q, r = self.setNum()
        # start = sum of sizes of previous partitions = index*q + min(index, r)
        start = index * q + (index if index < r else r)
        size = q + (1 if index < r else 0)
        end = start + size
        return self.lst[start:end]