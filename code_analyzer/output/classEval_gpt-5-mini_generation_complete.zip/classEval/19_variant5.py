class ChandrasekharSieve:
    """
    This is a class that uses the Chandrasekhar's Sieve method to find all prime numbers within the range
    """

    def __init__(self, n):
        self.n = int(n)
        self.primes = self.generate_primes()

    def generate_primes(self):
        n = self.n
        if n < 2:
            return []
        candidates = set(range(2, n + 1))
        primes = []
        i = 2
        while i <= n:
            if i in candidates:
                primes.append(i)
                # remove multiples of i
                mult = i * i
                while mult <= n:
                    if mult in candidates:
                        candidates.discard(mult)
                    mult += i
            i += 1
        return primes

    def get_primes(self):
        return list(self.primes)