import socket
import netifaces
import re


class IpUtil:
    """
    This is a class as tool for ip that can be used to obtain the local IP address, validate its validity, and also provides the functionality to retrieve the corresponding hostname.
    """

    @staticmethod
    def is_valid_ipv4(ip_address):
        if not isinstance(ip_address, str):
            return False
        parts = ip_address.split('.')
        if len(parts) != 3 + 1:
            return False
        for p in parts:
            if not p.isdigit():
                return False
            if p[0] == '0' and len(p) > 1:
                # allow "0" or no leading zeros for others
                pass
            val = int(p)
            if val < 0 or val > 255:
                return False
        return True

    @staticmethod
    def is_valid_ipv6(ip_address):
        if not isinstance(ip_address, str):
            return False
        # Very permissive quick check: use inet_pton if available
        try:
            socket.inet_pton(socket.AF_INET6, ip_address)
            return True
        except Exception:
            # fallback regex for typical IPv6 with :: compression
            hextet = r'(?:[0-9a-fA-F]{1,4})'
            pattern = '^(' + hextet + r':){2,7}' + hextet + r'$|^::'  # simple coverage
            return re.match(pattern, ip_address) is not None

    @staticmethod
    def get_hostname(ip_address):
        try:
            return socket.gethostbyaddr(ip_address)[0]
        except Exception:
            pass
        try:
            for iface in netifaces.interfaces():
                addrs = netifaces.ifaddresses(iface)
                for fam in (netifaces.AF_INET, netifaces.AF_INET6):
                    if fam in addrs:
                        for addrinfo in addrs[fam]:
                            addr = addrinfo.get('addr')
                            if addr and addr.split('%')[0] == ip_address:
                                try:
                                    return socket.gethostname()
                                except Exception:
                                    return iface
        except Exception:
            pass
        return None