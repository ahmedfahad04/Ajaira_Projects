class DiscountStrategy:
    """
    This is a class that allows to use different discount strategy based on shopping credit or shopping cart in supermarket.
    Minimal and recomputing implementation.
    """

    def __init__(self, customer, cart, promotion=None):
        self.customer = customer or {}
        self.cart = list(cart) if cart is not None else []
        self.promotion = promotion
        # Trigger total calculation for compatibility with skeleton
        self.total()

    def total(self):
        # recompute every time to avoid stale cache if cart mutated externally
        return float(sum((item.get('quantity', 0) * item.get('price', 0.0)) for item in self.cart))

    def due(self):
        tot = self.total()
        if not self.promotion:
            return tot
        if callable(self.promotion):
            disc = float(self.promotion(self))
            return tot - disc
        # if promotion is a dict mapping names to functions, apply all
        if isinstance(self.promotion, dict):
            total_disc = 0.0
            for key, func in self.promotion.items():
                if callable(func):
                    total_disc += float(func(self))
            return tot - total_disc
        return tot

    @staticmethod
    def FidelityPromo(order):
        if order.customer.get('fidelity', 0) > 1000:
            return order.total() * 0.05
        return 0.0

    @staticmethod
    def BulkItemPromo(order):
        return sum((item.get('quantity', 0) * item.get('price', 0.0) * 0.10)
                   for item in order.cart if item.get('quantity', 0) >= 20)

    @staticmethod
    def LargeOrderPromo(order):
        products = {item.get('product') for item in order.cart if 'product' in item}
        return order.total() * 0.07 if len(products) >= 10 else 0.0