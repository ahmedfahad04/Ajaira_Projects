from urllib.parse import urlparse, parse_qsl, unquote_plus

class URLHandler:
    """
    The class supports to handle URLs, including extracting the scheme, host, path, query parameters, and fragment.
    """

    def __init__(self, url):
        """
        Initialize URLHandler's URL
        """
        self.url = url or ""
        self._parsed = urlparse(self.url)

    def get_scheme(self):
        """
        get the scheme of the URL
        """
        return self._parsed.scheme

    def get_host(self):
        """
        Get the host domain name
        """
        return self._parsed.netloc

    def get_path(self):
        """
        Return path including query and fragment as in the example.
        """
        path = self._parsed.path or ""
        query = self._parsed.query
        frag = self._parsed.fragment
        out = path
        if query:
            out += "?" + query
        if frag:
            out += "#" + frag
        return out

    def get_query_params(self):
        """
        Return dict of query parameters. If a key occurs multiple times, the last value is kept.
        """
        qsl = parse_qsl(self._parsed.query, keep_blank_values=True)
        params = {}
        for k, v in qsl:
            params[k] = v
        return params

    def get_fragment(self):
        """
        Return fragment string after '#'
        """
        return self._parsed.fragment