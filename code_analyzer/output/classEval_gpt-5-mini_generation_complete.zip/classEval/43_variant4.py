from collections import OrderedDict
import copy

class HRManagementSystem:
    """
    This is a class as personnel management system that implements functions such as adding, deleting, querying, and updating employees
    """

    def __init__(self):
        """
        Initialize the HRManagementSystem withan attribute employees, which is an empty dictionary.
        """
        self.employees = OrderedDict()

    def add_employee(self, employee_id, name, position, department, salary):
        """
        Add a new employee to the HRManagementSystem.
        """
        if employee_id in self.employees:
            return False
        self.employees[employee_id] = {
            'name': name,
            'position': position,
            'department': department,
            'salary': salary
        }
        return True

    def remove_employee(self, employee_id):
        """
        Remove an employee from the HRManagementSystem.
        """
        if employee_id in self.employees:
            del self.employees[employee_id]
            return True
        return False

    def update_employee(self, employee_id: int, employee_info: dict):
        """
        Update an employee's information in the HRManagementSystem.
        """
        if employee_id not in self.employees:
            return False
        # support partial updates
        current = self.employees[employee_id]
        for k, v in employee_info.items():
            if k in ('name', 'position', 'department', 'salary'):
                current[k] = v
        self.employees[employee_id] = current
        return True

    def get_employee(self, employee_id):
        """
        Get an employee's information from the HRManagementSystem.
        """
        if employee_id not in self.employees:
            return False
        return copy.deepcopy(self.employees[employee_id])

    def list_employees(self):
        """
        List all employees' information in the HRManagementSystem.
        """
        out = OrderedDict()
        for eid, info in self.employees.items():
            entry = {'employee_ID': eid}
            entry.update(copy.deepcopy(info))
            out[eid] = entry
        return dict(out)