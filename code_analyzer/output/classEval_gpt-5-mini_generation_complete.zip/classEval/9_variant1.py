class BigNumCalculator:
    """
    This is a class that implements big number calculations, including adding, subtracting and multiplying.
    """

    @staticmethod
    def add(num1, num2):
        a = int(num1)
        b = int(num2)
        return str(a + b)

    @staticmethod
    def subtract(num1, num2):
        a = int(num1)
        b = int(num2)
        return str(a - b)

    @staticmethod
    def multiply(num1, num2):
        a = int(num1)
        b = int(num2)
        return str(a * b)