import math
from itertools import combinations_with_replacement

class Statistics3:
    """
    This is a class that implements methods for calculating indicators such as median, mode, correlation matrix, and Z-score in statistics.
    """

    @staticmethod
    def median(data):
        if not data:
            raise ValueError("no data")
        data_sorted = sorted(data)
        n = len(data_sorted)
        mid = n // 2
        if n % 2 == 1:
            return float(data_sorted[mid])
        return (data_sorted[mid - 1] + data_sorted[mid]) / 2.0

    @staticmethod
    def mode(data):
        if not data:
            return []
        freq = {}
        for x in data:
            freq[x] = freq.get(x, 0) + 1
        maxf = max(freq.values())
        modes = [k for k, v in freq.items() if v == maxf]
        try:
            modes.sort()
        except TypeError:
            pass
        return modes

    @staticmethod
    def correlation(x, y):
        if len(x) != len(y):
            raise ValueError("vectors must be same length")
        n = len(x)
        if n < 2:
            return 0.0
        mx = sum(x) / n
        my = sum(y) / n
        num = sum((xi - mx) * (yi - my) for xi, yi in zip(x, y))
        sxx = sum((xi - mx) ** 2 for xi in x)
        syy = sum((yi - my) ** 2 for yi in y)
        # use sample standard deviations (divide by n-1)
        denom = math.sqrt((sxx / (n - 1)) * (syy / (n - 1)))
        if denom == 0:
            return 0.0
        return (num / (n - 1)) / denom

    @staticmethod
    def mean(data):
        if not data:
            raise ValueError("no data")
        return float(sum(data)) / len(data)

    @staticmethod
    def correlation_matrix(data):
        if not data:
            return []
        m = len(data)
        matrix = [[0.0] * m for _ in range(m)]
        # compute only upper triangle and mirror
        for i, j in combinations_with_replacement(range(m), 2):
            if i == j:
                val = 1.0
            else:
                val = Statistics3.correlation(data[i], data[j])
            matrix[i][j] = val
            matrix[j][i] = val
        return matrix

    @staticmethod
    def standard_deviation(data):
        n = len(data)
        if n < 2:
            return 0.0
        m = Statistics3.mean(data)
        var = sum((x - m) ** 2 for x in data) / (n - 1)
        return math.sqrt(var)

    @staticmethod
    def z_score(data):
        if not data:
            return []
        m = Statistics3.mean(data)
        sd = Statistics3.standard_deviation(data)
        if sd == 0:
            return [0.0] * len(data)
        return [ (x - m) / sd for x in data ]