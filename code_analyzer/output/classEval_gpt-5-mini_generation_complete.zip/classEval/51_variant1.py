import numpy as np

class KappaCalculator:
    """
    This is a class as KappaCalculator, supporting to calculate Cohen's and Fleiss' kappa coefficient.
    """

    @staticmethod
    def kappa(testData, k):
        mat = np.array(testData, dtype=float)
        if mat.size == 0:
            return 0.0
        # Ensure square k x k
        if mat.shape != (k, k):
            # try to reshape if possible
            try:
                mat = mat.reshape((k, k))
            except Exception:
                raise ValueError("testData must be k x k")
        total = mat.sum()
        if total == 0:
            return 0.0
        po = np.trace(mat) / total
        row_tot = mat.sum(axis=1)
        col_tot = mat.sum(axis=0)
        pe = float((row_tot * col_tot).sum()) / (total * total)
        denom = 1.0 - pe
        if abs(denom) < 1e-12:
            return 1.0 if abs(po - pe) < 1e-12 else 0.0
        return (po - pe) / denom

    @staticmethod
    def fleiss_kappa(testData, N, k, n):
        mat = np.array(testData, dtype=float)
        if mat.size == 0:
            return 0.0
        if mat.shape != (N, k):
            try:
                mat = mat.reshape((N, k))
            except Exception:
                raise ValueError("testData must be N x k")
        # Check each row sums to n (not strictly required, but standard)
        row_sums = mat.sum(axis=1)
        # Compute Pj for each subject j
        # Pj = (1/(n*(n-1))) * (sum_k n_jk^2 - n)
        with np.errstate(invalid='ignore', divide='ignore'):
            Pj = (np.sum(mat * mat, axis=1) - n) / (n * (n - 1))
        Pbar = np.nanmean(Pj)
        # category proportions
        p_k = np.sum(mat, axis=0) / (N * n)
        Pe = np.sum(p_k * p_k)
        denom = 1.0 - Pe
        if abs(denom) < 1e-12:
            return 1.0 if abs(Pbar - Pe) < 1e-12 else 0.0
        return (Pbar - Pe) / denom