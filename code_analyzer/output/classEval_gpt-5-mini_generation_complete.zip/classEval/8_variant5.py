class BankAccount:
    """
    Minimalistic implementation with integer enforcement: treats amounts as integers (cents).
    """

    def __init__(self, balance=0):
        if not isinstance(balance, int):
            # try to convert float that represents whole cents
            if isinstance(balance, float) and balance.is_integer():
                balance = int(balance)
            else:
                raise TypeError("Balance must be int")
        self.balance = balance

    def _ensure_int_amount(self, amount):
        if not isinstance(amount, int):
            if isinstance(amount, float) and amount.is_integer():
                amount = int(amount)
            else:
                raise TypeError("Amount must be int")
        return amount

    def deposit(self, amount):
        amount = self._ensure_int_amount(amount)
        if amount < 0:
            raise ValueError("Invalid amount")
        self.balance += amount
        return self.balance

    def withdraw(self, amount):
        amount = self._ensure_int_amount(amount)
        if amount < 0:
            raise ValueError("Invalid amount")
        if amount > self.balance:
            raise ValueError("Insufficient balance.")
        self.balance -= amount
        return self.balance

    def view_balance(self):
        return self.balance

    def transfer(self, other_account, amount):
        if not isinstance(other_account, BankAccount):
            raise TypeError("other_account must be a BankAccount")
        amount = self._ensure_int_amount(amount)
        if amount < 0:
            raise ValueError("Invalid amount")
        if amount > self.balance:
            raise ValueError("Insufficient balance.")
        self.balance -= amount
        other_account.balance += amount
        return (self.balance, other_account.balance)