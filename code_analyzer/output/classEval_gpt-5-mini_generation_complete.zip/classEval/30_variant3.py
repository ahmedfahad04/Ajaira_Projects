import numpy as np
import math

class DataStatistics2:
    """
    This is a class for performing data statistics, supporting to get the sum, minimum, maximum, variance, standard deviation, and correlation of a given dataset.
    """

    def __init__(self, data):
        """
        Initialize Data List
        :param data:list
        """
        arr = np.asarray(data)
        if arr.ndim > 1:
            arr = arr.ravel()
        self.data = arr.astype(float)

    def _ensure(self):
        if self.data.size == 0:
            raise ValueError("empty data")

    def get_sum(self):
        self._ensure()
        s = 0.0
        # use numpy iterator for speed
        for v in np.nditer(self.data):
            s += float(v)
        if s.is_integer():
            return int(s)
        return s

    def get_min(self):
        self._ensure()
        # manual min using numpy where
        idx = np.argmin(self.data)
        val = float(self.data[idx])
        return int(val) if val.is_integer() else val

    def get_max(self):
        self._ensure()
        idx = np.argmax(self.data)
        val = float(self.data[idx])
        return int(val) if val.is_integer() else val

    def get_variance(self):
        self._ensure()
        mean = float(np.mean(self.data))
        diffs = self.data - mean
        var = float((diffs * diffs).sum() / self.data.size)
        return round(var, 2)

    def get_std_deviation(self):
        self._ensure()
        var = self.get_variance()
        std = math.sqrt(var)
        return round(std, 2)

    def get_correlation(self):
        self._ensure()
        n = self.data.size
        if n == 1:
            return 0.0
        x = np.arange(1, n + 1, dtype=float)
        y = self.data.astype(float)
        xm = x.mean()
        ym = y.mean()
        cx = x - xm
        cy = y - ym
        denom = math.sqrt((cx * cx).sum() * (cy * cy).sum())
        if denom == 0:
            return 0.0
        corr = float((cx * cy).sum() / denom)
        return corr