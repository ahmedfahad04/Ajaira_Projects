class Order:
    def __init__(self):
        self.menu = []
        self.selected_dishes = []
        self.sales = {}

    def add_dish(self, dish):
        # dish: {"dish": name, "price": price, "count": count}
        name = dish.get("dish")
        req_count = dish.get("count", 0)
        if not name or req_count <= 0:
            return False
        # find menu entry
        for m in self.menu:
            if m.get("dish") == name:
                available = m.get("count", 0)
                if available < req_count:
                    return False
                # decrement menu
                m["count"] = available - req_count
                # add to selected_dishes (merge if exists)
                for s in self.selected_dishes:
                    if s.get("dish") == name:
                        s["count"] = s.get("count", 0) + req_count
                        return True
                # else create new selection using menu price if present else provided price
                price = m.get("price", dish.get("price"))
                self.selected_dishes.append({"dish": name, "count": req_count, "price": price})
                return True
        return False

    def calculate_total(self):
        total = 0.0
        for s in self.selected_dishes:
            name = s.get("dish")
            count = s.get("count", 0)
            price = s.get("price", 0.0)
            multiplier = self.sales.get(name, 1.0)
            total += price * count * multiplier
        return float(total)

    def checkout(self):
        if not self.selected_dishes:
            return False
        return self.calculate_total()

# Classification response:
# variable renaming;guard clause;in-place mutation;temporary variable;dictionary lookup;default value handling;input validation;empty input handling;type conversion;behavior change;accumulator list