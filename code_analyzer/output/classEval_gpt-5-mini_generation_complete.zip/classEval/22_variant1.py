from collections import defaultdict

class ClassRegistrationSystem:
    """
    This is a class as a class registration system, allowing to register students, register them for classes, retrieve students by major, get a list of all majors, and determine the most popular class within a specific major.
    """

    def __init__(self):
        """
        Initialize the registration system with the attribute students and students_registration_classs.
        students is a list of student dictionaries, each student dictionary has the key of name and major.
        students_registration_classes is a dictionary, key is the student name, value is a list of class names
        """
        self.students = []
        self.students_registration_classes = {}

    def register_student(self, student):
        """
        register a student to the system, add the student to the students list, if the student is already registered, return 0, else return 1
        """
        if not isinstance(student, dict) or 'name' not in student or 'major' not in student:
            raise ValueError("student must be a dict with 'name' and 'major'")
        name = student['name']
        for s in self.students:
            if s.get('name') == name:
                return 0
        # add student
        self.students.append({'name': name, 'major': student['major']})
        return 1

    def register_class(self, student_name, class_name):
        """
        register a class to the student.
        :param student_name: str
        :param class_name: str
        :return a list of class names that the student has registered
        """
        if student_name not in self.students_registration_classes:
            self.students_registration_classes[student_name] = []
        classes = self.students_registration_classes[student_name]
        if class_name not in classes:
            classes.append(class_name)
        return list(classes)

    def get_students_by_major(self, major):
        """
        get all students in the major
        :param major: str
        :return a list of student name
        """
        return [s['name'] for s in self.students if s.get('major') == major]

    def get_all_major(self):
        """
        get all majors in the system
        :return a list of majors
        """
        seen = set()
        majors = []
        for s in self.students:
            m = s.get('major')
            if m not in seen:
                seen.add(m)
                majors.append(m)
        return majors

    def get_most_popular_class_in_major(self, major):
        """
        get the class with the highest enrollment in the major.
        :return  a string of the most popular class in this major
        """
        # gather student names of the major in registration order
        students_in_major = [s['name'] for s in self.students if s.get('major') == major]
        counts = defaultdict(int)
        best_class = None
        best_count = 0
        # iterate students and their classes in order to break ties by first reaching count
        for student in students_in_major:
            classes = self.students_registration_classes.get(student, [])
            for c in classes:
                counts[c] += 1
                if counts[c] > best_count:
                    best_count = counts[c]
                    best_class = c
        return best_class