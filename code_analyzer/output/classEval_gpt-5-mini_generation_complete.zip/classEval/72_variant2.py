import re

class RegexUtils:
    def __init__(self):
        self._cache = {}

    def _compile(self, pattern, flags=0):
        key = (pattern, flags)
        if key in self._cache:
            return self._cache[key]
        if isinstance(pattern, str):
            c = re.compile(pattern, flags)
        else:
            c = pattern
        self._cache[key] = c
        return c

    def match(self, pattern, text):
        # Use fullmatch when pattern not intended for partial matching
        if isinstance(pattern, str) and (pattern.startswith('^') or pattern.endswith('$')):
            return self._compile(pattern).fullmatch(text) is not None
        return self._compile(pattern).search(text) is not None

    def findall(self, pattern, text):
        return self._compile(pattern).findall(text)

    def split(self, pattern, text):
        return self._compile(pattern).split(text)

    def sub(self, pattern, replacement, text):
        return self._compile(pattern).sub(replacement, text)

    def generate_email_pattern(self):
        return r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'

    def generate_phone_number_pattern(self):
        return r'\b\d{3}-\d{3}-\d{4}\b'

    def generate_split_sentences_pattern(self):
        return r'[.!?][\s]{1,2}(?=[A-Z])'

    def split_sentences(self, text):
        # Split keeping punctuation with previous sentence
        sep = re.compile(r'(?<=[.!?])\s+(?=[A-Z])')
        sentences = sep.split(text)
        sentences = [s.strip() for s in sentences if s.strip() != '']
        # Remove trailing punctuation for all but last
        for i in range(len(sentences)-1):
            sentences[i] = re.sub(r'[.!?]+$', '', sentences[i]).strip()
        return sentences

    def validate_phone_number(self, phone_number):
        pat = self.generate_phone_number_pattern()
        return re.fullmatch(pat, phone_number) is not None

    def extract_email(self, text):
        pat = self.generate_email_pattern()
        try:
            return re.findall(pat, text, flags=re.IGNORECASE)
        except re.error:
            return []

# Classification response:
# helper function extraction;state variable;dictionary lookup;membership test;list comprehension;in-place mutation;for loop;try-except wrapper;type check;empty input handling;error suppression;behavior change;regex usage