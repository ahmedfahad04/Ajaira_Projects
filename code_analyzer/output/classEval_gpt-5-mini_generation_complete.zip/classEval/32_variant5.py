class DecryptionUtils:
    def __init__(self, key):
        self.key = key or ""

    def caesar_decipher(self, ciphertext, shift):
        try:
            s = int(shift) % 26
        except Exception:
            s = 0
        res_chars = []
        for ch in ciphertext:
            if ch.isalpha():
                if ch.isupper():
                    res_chars.append(chr((ord(ch) - ord('A') - s) % 26 + ord('A')))
                else:
                    res_chars.append(chr((ord(ch) - ord('a') - s) % 26 + ord('a')))
            else:
                res_chars.append(ch)
        return ''.join(res_chars)

    def vigenere_decipher(self, ciphertext):
        key_shifts = [ord(c.lower()) - ord('a') for c in self.key if c.isalpha()]
        if not key_shifts:
            return ciphertext
        res = []
        klen = len(key_shifts)
        kidx = 0
        for ch in ciphertext:
            if ch.isalpha():
                shift = key_shifts[kidx % klen]
                kidx += 1
                if ch.isupper():
                    base = ord('A')
                else:
                    base = ord('a')
                res.append(chr((ord(ch) - base - shift) % 26 + base))
            else:
                res.append(ch)
        return ''.join(res)

    def rail_fence_decipher(self, encrypted_text, rails):
        if rails is None or rails <= 1:
            return encrypted_text
        n = len(encrypted_text)
        pos_list = []
        row = 0
        step = 1
        for i in range(n):
            pos_list.append(row)
            if row == 0:
                step = 1
            elif row == rails - 1:
                step = -1
            row += step
        counts = [0]*rails
        for r in pos_list:
            counts[r] += 1
        segments = []
        idx = 0
        for c in counts:
            segments.append(list(encrypted_text[idx:idx+c]))
            idx += c
        pointers = [0]*rails
        output = []
        for r in pos_list:
            output.append(segments[r][pointers[r]])
            pointers[r] += 1
        return ''.join(output)