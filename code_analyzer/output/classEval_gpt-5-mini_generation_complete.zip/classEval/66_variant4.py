import re

class NumericEntityUnescaper:
    """
    This is a class that provides functionality to replace numeric entities with their corresponding characters in a given string.
    """

    def __init__(self):
        # Precompile patterns
        self._hex_pat = re.compile(r'&#[xX]([0-9A-Fa-f]+);')
        self._dec_pat = re.compile(r'&#([0-9]+);')

    def replace(self, string):
        if string is None:
            return string

        def hex_repl(m):
            digits = m.group(1)
            try:
                code = int(digits, 16)
                if 0 <= code <= 0x10FFFF:
                    return chr(code)
            except Exception:
                pass
            return m.group(0)

        def dec_repl(m):
            digits = m.group(1)
            try:
                code = int(digits, 10)
                if 0 <= code <= 0x10FFFF:
                    return chr(code)
            except Exception:
                pass
            return m.group(0)

        # Replace hex first, then decimal
        step1 = self._hex_pat.sub(hex_repl, string)
        step2 = self._dec_pat.sub(dec_repl, step1)
        return step2

    @staticmethod
    def is_hex_char(char):
        try:
            if not isinstance(char, str) or len(char) != 1:
                return False
            int(char, 16)
            return True
        except Exception:
            return False

# Classification response:
# regex usage; loop rewrite; helper function extraction; state variable; input validation; boundary case handling; type check; exception handling; behavior change; branch reordering