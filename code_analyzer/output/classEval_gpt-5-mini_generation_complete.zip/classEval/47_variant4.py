class IPAddress:
    """
    This is a class to process IP Address, including validating, getting the octets and obtaining the binary representation of a valid IP address.
    """
    def __init__(self, ip_address):
        self.ip_address = ip_address
        self._checked = False
        self._valid = False
        self._octets = []

    def _parse(self):
        if self._checked:
            return
        self._checked = True
        s = self.ip_address
        if not isinstance(s, str):
            return
        # disallow spaces inside
        if any(c.isspace() for c in s):
            return
        parts = s.split('.')
        if len(parts) != 4:
            return
        octs = []
        for part in parts:
            if part == '':
                return
            if not all('0' <= ch <= '9' for ch in part):
                return
            if len(part) > 3:
                return
            try:
                v = int(part)
            except Exception:
                return
            if v < 0 or v > 255:
                return
            octs.append(part)
        self._valid = True
        self._octets = octs

    def is_valid(self):
        self._parse()
        return self._valid

    def get_octets(self):
        self._parse()
        return list(self._octets) if self._valid else []

    def get_binary(self):
        self._parse()
        if not self._valid:
            return ''
        return '.'.join(f"{int(x):08b}" for x in self._octets)