import bisect

class BookManagement:
    """
    This implementation maintains two parallel lists (titles and quantities) kept sorted and exposes inventory as a dict.
    """

    def __init__(self):
        """
        Initialize the inventory of Book Manager.
        """
        self.titles = []
        self.quantities = []
        self.inventory = {}

    def _sync_inventory(self):
        self.inventory = {t: q for t, q in zip(self.titles, self.quantities)}

    def add_book(self, title, quantity=1):
        if not isinstance(title, str) or not isinstance(quantity, int) or quantity <= 0:
            return False
        idx = bisect.bisect_left(self.titles, title)
        if idx < len(self.titles) and self.titles[idx] == title:
            self.quantities[idx] += quantity
        else:
            self.titles.insert(idx, title)
            self.quantities.insert(idx, quantity)
        self._sync_inventory()
        return True

    def remove_book(self, title, quantity):
        if not isinstance(title, str) or not isinstance(quantity, int) or quantity <= 0:
            return False
        idx = bisect.bisect_left(self.titles, title)
        if idx >= len(self.titles) or self.titles[idx] != title:
            return False
        if quantity > self.quantities[idx]:
            return False
        self.quantities[idx] -= quantity
        if self.quantities[idx] == 0:
            del self.titles[idx]
            del self.quantities[idx]
        self._sync_inventory()
        return True

    def view_inventory(self):
        self._sync_inventory()
        return dict(self.inventory)

    def view_book_quantity(self, title):
        idx = bisect.bisect_left(self.titles, title)
        if idx < len(self.titles) and self.titles[idx] == title:
            return int(self.quantities[idx])
        return 0