class BitStatusUtil:
    """
    This is a utility class that provides methods for manipulating and checking status using bitwise operations.
    """

    @staticmethod
    def add(states, stat):
        BitStatusUtil.check([states, stat])
        # use bitwise or
        return states | stat

    @staticmethod
    def has(states, stat):
        BitStatusUtil.check([states, stat])
        # True if all bits in stat exist in states
        return ((states & stat) ^ stat) == 0

    @staticmethod
    def remove(states, stat):
        BitStatusUtil.check([states, stat])
        # clear bits
        return states & (~stat)

    @staticmethod
    def check(args):
        if args is None:
            return
        for item in args:
            if not isinstance(item, int):
                raise ValueError(f"{item} not int")
            if item < 0:
                raise ValueError(f"{item} < 0")
            # check evenness
            if (item & 1) != 0:
                raise ValueError(f"{item} not even")