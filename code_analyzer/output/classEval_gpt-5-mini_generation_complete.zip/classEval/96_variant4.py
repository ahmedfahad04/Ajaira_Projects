class WeatherSystem:
    """
    This is a class representing a weather system that provides functionality to query weather information for a specific city and convert temperature units between Celsius and Fahrenheit.
    """

    def __init__(self, city) -> None:
        """
        Initialize the weather system with a city name.
        """
        self.temperature = None
        self.weather = None
        self.city = city
        self.weather_list = {}

    def query(self, weather_list, tmp_units = 'celsius'):
        """
        Query and convert. If city missing returns (None, None).
        Be permissive about unit string forms (e.g. 'C', 'celsius', 'F', 'fahrenheit').
        """
        if not isinstance(weather_list, dict):
            raise TypeError("weather_list must be a dict")
        self.weather_list = weather_list
        # exact match first
        entry = weather_list.get(self.city)
        if entry is None:
            # try normalized key matching
            target_name = self.city.lower() if isinstance(self.city, str) else self.city
            for k, v in weather_list.items():
                if isinstance(k, str) and k.lower() == target_name:
                    entry = v
                    break
        if entry is None:
            return (None, None)
        temp = entry.get('temperature')
        src_units = entry.get('temperature units', 'celsius')
        self.weather = entry.get('weather')
        self.temperature = temp
        if temp is None:
            return (None, self.weather)
        src = src_units.strip().lower()
        dst = tmp_units.strip().lower() if isinstance(tmp_units, str) else 'celsius'
        def is_c(u): return u.startswith('c')
        def is_f(u): return u.startswith('f')
        if is_c(src) and is_f(dst):
            val = self.celsius_to_fahrenheit()
            # update internal temp to converted value
            self.temperature = val
            return (val, self.weather)
        if is_f(src) and is_c(dst):
            val = self.fahrenheit_to_celsius()
            self.temperature = val
            return (val, self.weather)
        # same units or unrecognized -> return original
        return (self.temperature, self.weather)

    def set_city(self, city):
        """
        Set the city of the weather system.
        """
        self.city = city

    def celsius_to_fahrenheit(self):
        """
        Convert the temperature from Celsius to Fahrenheit.
        """
        if self.temperature is None:
            return None
        # ensure float result
        return float(self.temperature) * 9.0 / 5.0 + 32.0

    def fahrenheit_to_celsius(self):
        """
        Convert the temperature from Fahrenheit to Celsius.
        """
        if self.temperature is None:
            return None
        return (float(self.temperature) - 32.0) * 5.0 / 9.0