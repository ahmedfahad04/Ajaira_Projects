import re
import string
import gensim
from bs4 import BeautifulSoup

class HtmlUtil:
    """
    This is a class as util for html, supporting for formatting and extracting code from HTML text, including cleaning up the text and converting certain elements into specific marks.
    """

    def __init__(self):
        """
        Initialize a series of labels
        """
        self.SPACE_MARK = '-SPACE-'
        self.JSON_MARK = '-JSON-'
        self.MARKUP_LANGUAGE_MARK = '-MARKUP_LANGUAGE-'
        self.URL_MARK = '-URL-'
        self.NUMBER_MARK = '-NUMBER-'
        self.TRACE_MARK = '-TRACE-'
        self.COMMAND_MARK = '-COMMAND-'
        self.COMMENT_MARK = '-COMMENT-'
        self.CODE_MARK = '-CODE-'

    @staticmethod
    def __format_line_feed(text):
        """
        Replace consecutive line breaks with a single line break
        """
        # keep single newline, collapse multiple
        return re.sub(r'(\r\n|\r|\n){2,}', '\n', text)

    def format_line_html_text(self, html_text):
        """
        Convert <pre> and <code> regions to -CODE- and return cleaned text lines.
        """
        soup = BeautifulSoup(html_text, 'html.parser')
        # Convert each pre into a paragraph containing the CODE_MARK to ensure it's on its own line
        for pre in soup.find_all('pre'):
            new_tag = soup.new_tag('p')
            new_tag.string = self.CODE_MARK
            pre.replace_with(new_tag)
        # Convert standalone code elements to paragraphs as well
        for code in soup.find_all('code'):
            if code.parent.name != 'pre':
                new_tag = soup.new_tag('p')
                new_tag.string = self.CODE_MARK
                code.replace_with(new_tag)
        body = soup.body or soup
        text = body.get_text(separator='\n')
        text = self.__format_line_feed(text)
        # Normalize spaces: collapse multiple spaces into one except within CODE_MARK lines
        lines = []
        for ln in text.splitlines():
            if ln.strip() == self.CODE_MARK:
                lines.append(self.CODE_MARK)
            else:
                cleaned = re.sub(r'\s+', ' ', ln).strip()
                if cleaned:
                    lines.append(cleaned)
        return '\n'.join(lines).strip()

    def extract_code_from_html_text(self, html_text):
        """
        Extract code text blocks from <pre> tags, keeping internal formatting.
        """
        soup = BeautifulSoup(html_text, 'html.parser')
        result = []
        for pre in soup.find_all('pre'):
            code = pre.find('code')
            if code:
                txt = code.get_text()
            else:
                txt = pre.get_text()
            # Remove only a single leading/trailing blank line if present
            txt = re.sub(r'^\n+', '', txt)
            txt = re.sub(r'\n+$', '', txt)
            result.append(txt)
        return result