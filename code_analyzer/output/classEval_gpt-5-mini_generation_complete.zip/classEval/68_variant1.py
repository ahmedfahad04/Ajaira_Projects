class PageUtil:
    """
    PageUtil class is a versatile utility for handling pagination and search functionalities in an efficient and convenient manner.
    """

    def __init__(self, data, page_size):
        """
        Initialize the PageUtil object with the given data and page size.
        :param data: list, the data to be paginated
        :param page_size: int, the number of items per page
        """
        self.data = list(data)
        self.page_size = max(1, int(page_size))
        self.total_items = len(self.data)
        self.total_pages = (self.total_items + self.page_size - 1) // self.page_size

    def get_page(self, page_number):
        """
        Retrieve a specific page of data.
        :param page_number: int, the page number to fetch
        :return: list, the data on the specified page
        """
        try:
            page_number = int(page_number)
        except Exception:
            return []
        if page_number < 1 or self.total_pages == 0 or page_number > self.total_pages:
            return []
        start = (page_number - 1) * self.page_size
        end = start + self.page_size
        return self.data[start:end]

    def get_page_info(self, page_number):
        """
        Retrieve information about a specific page.
        :param page_number: int, the page number to fetch information about
        :return: dict, containing page information such as current page number, total pages, etc.
        """
        try:
            page_number = int(page_number)
        except Exception:
            page_number = 1
        if self.total_pages == 0:
            page_number = 1
        if page_number < 1:
            page_number = 1
        if page_number > self.total_pages:
            page_number = self.total_pages
        data = self.get_page(page_number) if self.total_pages > 0 else []
        return {
            "current_page": page_number,
            "per_page": self.page_size,
            "total_pages": self.total_pages,
            "total_items": self.total_items,
            "has_previous": page_number > 1,
            "has_next": page_number < self.total_pages,
            "data": data
        }

    def search(self, keyword):
        """
        Search for items in the data that contain the given keyword.
        :param keyword: str, the keyword to search for
        :return: dict, containing search information such as total results and matching items
        """
        kw = "" if keyword is None else str(keyword)
        lk = kw.lower()
        results = [item for item in self.data if lk in str(item).lower()]
        total_results = len(results)
        total_pages = (total_results + self.page_size - 1) // self.page_size if total_results > 0 else 0
        return {
            "keyword": kw,
            "total_results": total_results,
            "total_pages": total_pages,
            "results": results
        }

# Classification response:
# variable renaming; list conversion; copy before mutation; type conversion; input validation; try-except wrapper; boundary case handling; default value handling; behavior change; helper function extraction