from collections import Counter

class MetricsCalculator:
    """
    The class calculates precision, recall, F1 score, and accuracy based on predicted and true labels.
    """

    def __init__(self):
        """
        Initialize the number of all four samples to 0
        """
        self.true_positives = 0
        self.false_positives = 0
        self.false_negatives = 0
        self.true_negatives = 0

    def update(self, predicted_labels, true_labels):
        """
        Update counts using Counter on pairs.
        """
        pairs = [(1 if p == 1 else 0, 1 if t == 1 else 0) for p, t in zip(predicted_labels, true_labels)]
        cnt = Counter(pairs)
        self.true_positives += cnt.get((1, 1), 0)
        self.false_positives += cnt.get((1, 0), 0)
        self.false_negatives += cnt.get((0, 1), 0)
        self.true_negatives += cnt.get((0, 0), 0)

    def _get_counts(self, predicted_labels, true_labels):
        pairs = [(1 if p == 1 else 0, 1 if t == 1 else 0) for p, t in zip(predicted_labels, true_labels)]
        cnt = Counter(pairs)
        tp = cnt.get((1, 1), 0)
        fp = cnt.get((1, 0), 0)
        fn = cnt.get((0, 1), 0)
        tn = cnt.get((0, 0), 0)
        return tp, fp, fn, tn

    def precision(self, predicted_labels, true_labels):
        tp, fp, _, _ = self._get_counts(predicted_labels, true_labels)
        return float(tp) / (tp + fp) if (tp + fp) > 0 else 0.0

    def recall(self, predicted_labels, true_labels):
        tp, _, fn, _ = self._get_counts(predicted_labels, true_labels)
        return float(tp) / (tp + fn) if (tp + fn) > 0 else 0.0

    def f1_score(self, predicted_labels, true_labels):
        p = self.precision(predicted_labels, true_labels)
        r = self.recall(predicted_labels, true_labels)
        return 2 * p * r / (p + r) if (p + r) > 0 else 0.0

    def accuracy(self, predicted_labels, true_labels):
        tp, fp, fn, tn = self._get_counts(predicted_labels, true_labels)
        total = tp + fp + fn + tn
        return float(tp + tn) / total if total > 0 else 0.0

# Classification response:
# standard library helper; list comprehension; frequency counting; helper function extraction; tuple unpacking; dictionary lookup; conditional expression; zip usage; type conversion; behavior change