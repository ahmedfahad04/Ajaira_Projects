import time
import math

class Thermostat:
    """
    The class manages temperature control, including setting and retrieving the target temperature, adjusting the mode, and simulating temperature operation.
    """

    def __init__(self, current_temperature, target_temperature, mode):
        self.current_temperature = float(current_temperature)
        self.target_temperature = float(target_temperature)
        self.mode = mode.lower() if isinstance(mode, str) else mode

    def get_target_temperature(self):
        return self.target_temperature

    def set_target_temperature(self, temperature):
        self.target_temperature = float(temperature)

    def get_mode(self):
        return self.mode

    def set_mode(self, mode):
        m = mode.lower() if isinstance(mode, str) else mode
        if m not in ('heat', 'cool'):
            raise ValueError("mode must be 'heat' or 'cool'")
        self.mode = m

    def auto_set_mode(self):
        self.mode = 'heat' if self.current_temperature < self.target_temperature else 'cool'

    def auto_check_conflict(self):
        desired = 'heat' if self.current_temperature < self.target_temperature else 'cool'
        if self.mode != desired:
            self.mode = desired
            return False
        return True

    def simulate_operation(self):
        self.auto_set_mode()
        delta = abs(self.target_temperature - self.current_temperature)
        steps = int(math.ceil(delta))
        # perform simulated steps without sleeping
        if steps == 0:
            return 0
        step_dir = 1 if self.mode == 'heat' else -1
        for i in range(steps):
            remaining = self.target_temperature - self.current_temperature
            if abs(remaining) <= 1.0:
                self.current_temperature = float(self.target_temperature)
                break
            self.current_temperature += step_dir * 1.0
        # ensure exact target at end
        self.current_temperature = float(self.target_temperature)
        return steps