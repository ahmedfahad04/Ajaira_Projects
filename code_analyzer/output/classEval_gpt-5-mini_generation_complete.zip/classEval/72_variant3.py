import re

class RegexUtils:
    def match(self, pattern, text):
        # Accept either compiled pattern or string
        if hasattr(pattern, 'search'):
            return pattern.search(text) is not None
        try:
            return bool(re.search(pattern, text))
        except re.error:
            return False

    def findall(self, pattern, text):
        if hasattr(pattern, 'findall'):
            return pattern.findall(text)
        return re.findall(pattern, text)

    def split(self, pattern, text):
        if hasattr(pattern, 'split'):
            return pattern.split(text)
        return re.split(pattern, text)

    def sub(self, pattern, replacement, text):
        if hasattr(pattern, 'sub'):
            return pattern.sub(replacement, text)
        return re.sub(pattern, replacement, text)

    def generate_email_pattern(self):
        user = r'[A-Za-z0-9._%+-]+'
        domain = r'[A-Za-z0-9.-]+'
        tld = r'[A-Za-z]{2,}'
        return rf'\b{user}@{domain}\.{tld}\b'

    def generate_phone_number_pattern(self):
        parts = r'\d{3}-\d{3}-\d{4}'
        return r'\b' + parts + r'\b'

    def generate_split_sentences_pattern(self):
        return r'[.!?][\s]{1,2}(?=[A-Z])'

    def split_sentences(self, text):
        # Use finditer to collect sentences robustly
        sentences = []
        for m in re.finditer(r'[^.!?]+[.!?]?', text):
            s = m.group(0).strip()
            if s:
                sentences.append(s)
        # Remove punctuation from all except potentially last if it ends with punctuation
        for i in range(len(sentences) - 1):
            sentences[i] = re.sub(r'[.!?]+$', '', sentences[i]).strip()
        return sentences

    def validate_phone_number(self, phone_number):
        pat = self.generate_phone_number_pattern()
        try:
            return re.fullmatch(pat, phone_number) is not None
        except re.error:
            return False

    def extract_email(self, text):
        pat = self.generate_email_pattern()
        return re.findall(pat, text, flags=re.IGNORECASE)

# Classification response:
# try-except wrapper; type check; accumulator list; for loop; in-place mutation; temporary variable; f-string; standard library helper; error suppression; behavior change; boundary case handling