import sqlite3
import threading

class UserLoginDB:
    """
    This is a database management class for user login verification, providing functions for inserting user information, searching user information, deleting user information, and validating user login.
    This implementation keeps an in-memory cache for fast lookups synchronized with the database.
    """

    def __init__(self, db_name):
        """
        Initializes the UserLoginDB object with the specified database name.
        """
        self.db_name = db_name
        self.connection = sqlite3.connect(self.db_name)
        self.cursor = self.connection.cursor()
        self._lock = threading.Lock()
        self._cache = {}  # username -> password
        self._initialized = False

    def create_table(self):
        with self._lock:
            self.cursor.execute(
                "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT)"
            )
            self.connection.commit()
            self._load_cache()
            self._initialized = True

    def _load_cache(self):
        self.cursor.execute("SELECT username, password FROM users")
        rows = self.cursor.fetchall()
        self._cache = {r[0]: r[1] for r in rows}

    def insert_user(self, username, password):
        with self._lock:
            self.cursor.execute(
                "INSERT OR IGNORE INTO users (username, password) VALUES (?, ?)",
                (username, password),
            )
            self.connection.commit()
            # reload that user into cache
            self.cursor.execute("SELECT password FROM users WHERE username = ?", (username,))
            row = self.cursor.fetchone()
            if row:
                self._cache[username] = row[0]

    def search_user_by_username(self, username):
        with self._lock:
            if username in self._cache:
                # find the id from DB to conform to table row format
                self.cursor.execute("SELECT id, username, password FROM users WHERE username = ?", (username,))
                rows = self.cursor.fetchall()
                return rows
            return []

    def delete_user_by_username(self, username):
        with self._lock:
            self.cursor.execute("DELETE FROM users WHERE username = ?", (username,))
            self.connection.commit()
            if username in self._cache:
                del self._cache[username]

    def validate_user_login(self, username, password):
        with self._lock:
            stored = self._cache.get(username)
            if stored is None:
                # ensure DB isn't stale
                self.cursor.execute("SELECT password FROM users WHERE username = ?", (username,))
                row = self.cursor.fetchone()
                if not row:
                    return False
                stored = row[0]
                self._cache[username] = stored
            return stored == password