class BitStatusUtil:
    """
    This is a utility class that provides methods for manipulating and checking status using bitwise operations.
    """

    @staticmethod
    def add(states, stat):
        # ensure parameters are legal
        BitStatusUtil.check([states, stat])
        # use arithmetic when combining disjoint flags is equivalent to bitwise OR
        return states | stat

    @staticmethod
    def has(states, stat):
        BitStatusUtil.check([states, stat])
        # if stat is zero, define as True only if states also has zero bits (always True)
        # standard check: all bits in stat are set in states
        return (states & stat) == stat

    @staticmethod
    def remove(states, stat):
        BitStatusUtil.check([states, stat])
        # clear the requested bits
        return states & (~stat)

    @staticmethod
    def check(args):
        if args is None:
            return
        # convert to list to support single values too
        for val in list(args):
            if not isinstance(val, int):
                raise ValueError(f"{val} not int")
            if val < 0:
                raise ValueError(f"{val} < 0")
            # must be even
            if val % 2 != 0:
                raise ValueError(f"{val} not even")