import random
from collections import deque

class Snake:
    """
    The class is a snake game, with allows snake to move and eat food, and also enables to reset, and generat a random food position.
    """

    def __init__(self, SCREEN_WIDTH, SCREEN_HEIGHT, BLOCK_SIZE, food_position):
        self.SCREEN_WIDTH = int(SCREEN_WIDTH)
        self.SCREEN_HEIGHT = int(SCREEN_HEIGHT)
        self.BLOCK_SIZE = int(BLOCK_SIZE)
        self.length = 1
        self.positions = deque()
        self.positions.append(self._center())
        self.occupied = {self.positions[0]}
        self.score = 0
        self.food_position = self._align(food_position)

    def _center(self):
        cx = int(self.SCREEN_WIDTH / 2)
        cy = int(self.SCREEN_HEIGHT / 2)
        return (self._align_coord(cx, self.SCREEN_WIDTH), self._align_coord(cy, self.SCREEN_HEIGHT))

    def _align_coord(self, val, limit):
        coord = (val // self.BLOCK_SIZE) * self.BLOCK_SIZE
        if coord < 0:
            coord = 0
        maxc = max(0, limit - self.BLOCK_SIZE)
        if coord > maxc:
            coord = maxc
        return coord

    def _align(self, pos):
        x, y = pos
        return (self._align_coord(int(x), self.SCREEN_WIDTH), self._align_coord(int(y), self.SCREEN_HEIGHT))

    def move(self, direction):
        dx = int(direction[0]) * self.BLOCK_SIZE
        dy = int(direction[1]) * self.BLOCK_SIZE
        hx, hy = self.positions[0]
        nx = (hx + dx) % self.SCREEN_WIDTH
        ny = (hy + dy) % self.SCREEN_HEIGHT
        nx = self._align_coord(nx, self.SCREEN_WIDTH)
        ny = self._align_coord(ny, self.SCREEN_HEIGHT)
        new_head = (nx, ny)
        # collision
        if new_head in self.occupied:
            self.reset()
            return
        # add head
        self.positions.appendleft(new_head)
        self.occupied.add(new_head)
        if new_head == self.food_position:
            self.eat_food()
        else:
            # remove tail to maintain length
            while len(self.positions) > self.length:
                tail = self.positions.pop()
                self.occupied.discard(tail)

    def random_food_position(self):
        cols = max(1, self.SCREEN_WIDTH // self.BLOCK_SIZE)
        rows = max(1, self.SCREEN_HEIGHT // self.BLOCK_SIZE)
        all_cells = [(i * self.BLOCK_SIZE, j * self.BLOCK_SIZE) for i in range(cols) for j in range(rows)]
        available = [c for c in all_cells if c not in self.occupied]
        if not available:
            # no space, keep food where it is
            return
        self.food_position = random.choice(available)

    def reset(self):
        self.length = 1
        self.positions = deque([self._center()])
        self.occupied = {self.positions[0]}
        self.score = 0
        self.random_food_position()

    def eat_food(self):
        self.length += 1
        self.score += 100
        self.random_food_position()