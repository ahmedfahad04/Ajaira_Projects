class FitnessTracker:
    """
    This is a class as fitness tracker that implements to calculate BMI (Body Mass Index) and calorie intake based on the user's height, weight, age, and sex.
    """

    def __init__(self, height, weight, age, sex) -> None:
        self.height = float(height)
        self.weight = float(weight)
        self.age = int(age)
        self.sex = str(sex).lower()
        # use mapping for clarity
        self.BMI_std = {"male": (20.0, 25.0), "female": (19.0, 24.0)}
        self._bmi_cache = None

    def get_BMI(self):
        if self._bmi_cache is not None:
            return self._bmi_cache
        if self.height == 0:
            raise ValueError("Height cannot be zero.")
        # allow height provided in cm (common mistake): if height > 3 assume cm and convert
        height_m = self.height if self.height <= 3 else self.height / 100.0
        bmi = self.weight / (height_m * height_m)
        self._bmi_cache = bmi
        return bmi

    def condition_judge(self):
        bmi = self.get_BMI()
        bounds = self.BMI_std.get(self.sex)
        if bounds is None:
            # if sex unknown, use average of both standards
            low = (self.BMI_std["male"][0] + self.BMI_std["female"][0]) / 2.0
            high = (self.BMI_std["male"][1] + self.BMI_std["female"][1]) / 2.0
        else:
            low, high = bounds
        if bmi < low:
            return -1
        if bmi > high:
            return 1
        return 0

    def calculate_calorie_intake(self):
        # BMR uses the raw height as given in the formula; follow same cm/m heuristic used for BMI
        height_for_bmr = self.height if self.height <= 3 else self.height / 100.0
        # Compute BMR according to sex
        if self.sex == "male":
            bmr = 10 * self.weight + 6.25 * height_for_bmr - 5 * self.age + 5
        elif self.sex == "female":
            bmr = 10 * self.weight + 6.25 * height_for_bmr - 5 * self.age - 161
        else:
            # average of male and female BMR if sex not given
            bmr_m = 10 * self.weight + 6.25 * height_for_bmr - 5 * self.age + 5
            bmr_f = 10 * self.weight + 6.25 * height_for_bmr - 5 * self.age - 161
            bmr = (bmr_m + bmr_f) / 2.0

        cond = self.condition_judge()
        multiplier = {1: 1.2, 0: 1.4, -1: 1.6}[cond]
        return bmr * multiplier