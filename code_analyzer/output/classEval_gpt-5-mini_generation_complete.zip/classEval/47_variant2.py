class IPAddress:
    """
    This is a class to process IP Address, including validating, getting the octets and obtaining the binary representation of a valid IP address.
    """
    def __init__(self, ip_address):
        self.ip_address = ip_address

    def is_valid(self):
        s = self.ip_address
        if not isinstance(s, str):
            return False
        parts = s.split('.')
        if len(parts) != 4:
            return False
        for p in parts:
            if p == '':
                return False
            if not p.isdigit():
                return False
            if len(p) > 3:
                return False
            try:
                v = int(p)
            except ValueError:
                return False
            if v < 0 or v > 255:
                return False
        return True

    def get_octets(self):
        if not self.is_valid():
            return []
        return self.ip_address.split('.')

    def get_binary(self):
        if not self.is_valid():
            return ''
        return '.'.join(format(int(p), '08b') for p in self.get_octets())