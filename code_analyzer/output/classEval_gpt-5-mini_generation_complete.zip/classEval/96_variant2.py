class WeatherSystem:
    """
    This is a class representing a weather system that provides functionality to query weather information for a specific city and convert temperature units between Celsius and Fahrenheit.
    """

    def __init__(self, city) -> None:
        """
        Initialize the weather system with a city name.
        """
        self.temperature = None
        self.weather = None
        self.city = city
        self.weather_list = {}
        self.units = None  # track current units

    def query(self, weather_list, tmp_units = 'celsius'):
        """
        Query the weather system for the weather and temperature of the city,and convert the temperature units based on the input parameter.
        If city key is not found, try case-insensitive match. Returns (temperature, weather) or (None, None) if not available.
        """
        self.weather_list = weather_list
        # allow case-insensitive city match
        if self.city in weather_list:
            key = self.city
        else:
            key = None
            low = self.city.lower() if isinstance(self.city, str) else None
            for k in weather_list:
                if isinstance(k, str) and k.lower() == low:
                    key = k
                    break
        if key is None:
            return (None, None)
        entry = weather_list[key]
        temp = entry.get('temperature')
        src_units = entry.get('temperature units', 'celsius')
        self.weather = entry.get('weather')
        self.temperature = temp
        self.units = src_units.lower() if isinstance(src_units, str) else 'celsius'
        target = tmp_units.lower() if isinstance(tmp_units, str) else 'celsius'
        if temp is None:
            return (None, self.weather)
        if self.units.startswith('c') and target.startswith('f'):
            converted = self.celsius_to_fahrenheit()
            # update internal state to reflect returned units
            self.temperature = converted
            self.units = 'fahrenheit'
            return (converted, self.weather)
        if self.units.startswith('f') and target.startswith('c'):
            converted = self.fahrenheit_to_celsius()
            self.temperature = converted
            self.units = 'celsius'
            return (converted, self.weather)
        # same units requested
        return (self.temperature, self.weather)

    def set_city(self, city):
        """
        Set the city of the weather system.
        """
        self.city = city

    def celsius_to_fahrenheit(self):
        """
        Convert the temperature from Celsius to Fahrenheit.
        """
        if self.temperature is None:
            return None
        # preserve original self.temperature, return converted value
        return self.temperature * 9.0 / 5.0 + 32.0

    def fahrenheit_to_celsius(self):
        """
        Convert the temperature from Fahrenheit to Celsius.
        """
        if self.temperature is None:
            return None
        return (self.temperature - 32.0) * 5.0 / 9.0