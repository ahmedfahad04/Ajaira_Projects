import re
import string
import gensim
from bs4 import BeautifulSoup
import html as _html

class HtmlUtil:
    """
    This is a class as util for html, supporting for formatting and extracting code from HTML text, including cleaning up the text and converting certain elements into specific marks.
    """

    def __init__(self):
        """
        Initialize a series of labels
        """
        self.SPACE_MARK = '-SPACE-'
        self.JSON_MARK = '-JSON-'
        self.MARKUP_LANGUAGE_MARK = '-MARKUP_LANGUAGE-'
        self.URL_MARK = '-URL-'
        self.NUMBER_MARK = '-NUMBER-'
        self.TRACE_MARK = '-TRACE-'
        self.COMMAND_MARK = '-COMMAND-'
        self.COMMENT_MARK = '-COMMENT-'
        self.CODE_MARK = '-CODE-'

    @staticmethod
    def __format_line_feed(text):
        """
        Replace consecutive line breaks with a single line break
        """
        # Replace two or more consecutive newlines (possibly with whitespace) with a single newline
        return re.sub(r'\n[\t ]*\n+', '\n', text)

    def format_line_html_text(self, html_text):
        """
        Regex-driven approach: remove <pre> content and replace with marker, then strip tags
        """
        # Find all <pre> blocks and replace them with a placeholder
        pre_pattern = re.compile(r'(<pre\b[^>]*>)(.*?)(</pre>)', re.I | re.S)
        def _replace_pre(m):
            return '\n' + self.CODE_MARK + '\n'
        temp = pre_pattern.sub(_replace_pre, html_text)
        # Also handle <code> not inside pre
        code_pattern = re.compile(r'(<code\b[^>]*>)(.*?)(