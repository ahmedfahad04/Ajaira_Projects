class WeatherSystem:
    """
    This is a class representing a weather system that provides functionality to query weather information for a specific city and convert temperature units between Celsius and Fahrenheit.
    """

    def __init__(self, city) -> None:
        """
        Initialize the weather system with a city name.
        """
        self.temperature = None
        self.weather = None
        self.city = city
        self.weather_list = {}

    def query(self, weather_list, tmp_units = 'celsius'):
        """
        Query the weather system for the weather and temperature of the city,and convert the temperature units based on the input parameter.
        """
        if not isinstance(weather_list, dict):
            raise TypeError("weather_list must be a dict")
        if self.city not in weather_list:
            raise KeyError(f"City '{self.city}' not found in weather_list")
        entry = weather_list[self.city]
        temp = entry.get('temperature')
        src_units = entry.get('temperature units', 'celsius')
        self.weather = entry.get('weather')
        self.temperature = temp
        target = (tmp_units or 'celsius').strip().lower()
        src = (src_units or 'celsius').strip().lower()
        if temp is None:
            return (None, self.weather)
        if src == target or (src.startswith('c') and target.startswith('c')) or (src.startswith('f') and target.startswith('f')):
            # no conversion needed
            return (self.temperature, self.weather)
        if src.startswith('c') and target.startswith('f'):
            converted = self.celsius_to_fahrenheit()
            self.temperature = converted
            return (converted, self.weather)
        if src.startswith('f') and target.startswith('c'):
            converted = self.fahrenheit_to_celsius()
            self.temperature = converted
            return (converted, self.weather)
        # fallback: no conversion
        return (self.temperature, self.weather)

    def set_city(self, city):
        """
        Set the city of the weather system.
        """
        self.city = city

    def celsius_to_fahrenheit(self):
        """
        Convert the temperature from Celsius to Fahrenheit.
        """
        if self.temperature is None:
            return None
        # standard conversion
        result = self.temperature * 9.0 / 5.0 + 32.0
        return result

    def fahrenheit_to_celsius(self):
        """
        Convert the temperature from Fahrenheit to Celsius.
        """
        if self.temperature is None:
            return None
        result = (self.temperature - 32.0) * 5.0 / 9.0
        return result