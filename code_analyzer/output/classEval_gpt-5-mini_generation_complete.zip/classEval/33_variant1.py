class DiscountStrategy:
    """
    This is a class that allows to use different discount strategy based on shopping credit or shopping cart in supermarket.
    """

    def __init__(self, customer, cart, promotion=None):
        self.customer = customer or {}
        self.cart = list(cart) if cart is not None else []
        self.promotion = promotion
        # cache total for reuse
        self._total = None
        self.total()

    def total(self):
        if self._total is None:
            total = 0.0
            for item in self.cart:
                qty = item.get('quantity', 0)
                price = item.get('price', 0.0)
                total += qty * price
            self._total = float(total)
        return self._total

    def due(self):
        total = self.total()
        discount = 0.0
        promo = self.promotion
        if promo is None:
            discount = 0.0
        elif callable(promo):
            discount = float(promo(self))
        else:
            # if invalid promotion provided, ignore
            discount = 0.0
        return total - discount

    @staticmethod
    def FidelityPromo(order):
        fidelity = order.customer.get('fidelity', 0)
        if fidelity >= 1000:
            return order.total() * 0.05
        return 0.0

    @staticmethod
    def BulkItemPromo(order):
        discount = 0.0
        for item in order.cart:
            if item.get('quantity', 0) >= 20:
                discount += item.get('quantity', 0) * item.get('price', 0.0) * 0.10
        return discount

    @staticmethod
    def LargeOrderPromo(order):
        products = {item.get('product') for item in order.cart if 'product' in item}
        if len(products) >= 10:
            return order.total() * 0.07
        return 0.0