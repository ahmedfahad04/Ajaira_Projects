import numpy as np
from gensim import matutils
from numpy import dot, array

class VectorUtil:
    """
    The class provides vector operations, including calculating similarity, cosine similarities, average similarity, and IDF weights.
    """

    @staticmethod
    def similarity(vector_1, vector_2):
        v1 = np.asarray(vector_1, dtype=float).ravel()
        v2 = np.asarray(vector_2, dtype=float).ravel()
        n1 = np.linalg.norm(v1)
        n2 = np.linalg.norm(v2)
        if n1 <= 0 or n2 <= 0:
            return 0.0
        return (v1 @ v2) / (n1 * n2)

    @staticmethod
    def cosine_similarities(vector_1, vectors_all):
        v1 = np.asarray(vector_1, dtype=float).ravel()
        if np.linalg.norm(v1) == 0:
            return np.array([0.0 for _ in vectors_all], dtype=float)
        results = []
        for v in vectors_all:
            vv = np.asarray(v, dtype=float).ravel()
            n = np.linalg.norm(vv)
            if n == 0:
                results.append(0.0)
            else:
                results.append((v1 @ vv) / (np.linalg.norm(v1) * n))
        return np.array(results, dtype=float)

    @staticmethod
    def n_similarity(vector_list_1, vector_list_2):
        if not vector_list_1 or not vector_list_2:
            return 0.0
        sum1 = None
        for v in vector_list_1:
            v = np.asarray(v, dtype=float)
            sum1 = v if sum1 is None else sum1 + v
        sum2 = None
        for v in vector_list_2:
            v = np.asarray(v, dtype=float)
            sum2 = v if sum2 is None else sum2 + v
        mean1 = sum1 / len(vector_list_1)
        mean2 = sum2 / len(vector_list_2)
        return float(VectorUtil.similarity(mean1, mean2))

    @staticmethod
    def compute_idf_weight_dict(total_num, number_dict):
        tot = float(total_num)
        out = {}
        for k, count in number_dict.items():
            c = float(count)
            out[k] = float(np.log((tot + 1.0) / (c + 1.0)))
        return out