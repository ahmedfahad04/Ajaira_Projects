class WeatherSystem:
    """
    This is a class representing a weather system that provides functionality to query weather information for a specific city and convert temperature units between Celsius and Fahrenheit.
    """

    def __init__(self, city) -> None:
        """
        Initialize the weather system with a city name.
        """
        self.temperature = None
        self.weather = None
        self.city = city
        self.weather_list = {}

    def query(self, weather_list, tmp_units = 'celsius'):
        """
        Robust query: accepts weather_list as dict or list of dicts.
        Converts temperature in-place to requested units and returns (temp, weather).
        If city not found returns (None, None).
        """
        self.weather_list = weather_list
        entry = None
        if isinstance(weather_list, dict):
            entry = weather_list.get(self.city)
            if entry is None:
                # try case-insensitive
                for k, v in weather_list.items():
                    if isinstance(k, str) and isinstance(self.city, str) and k.lower() == self.city.lower():
                        entry = v
                        break
        elif isinstance(weather_list, list):
            for e in weather_list:
                if not isinstance(e, dict):
                    continue
                if e.get('city') == self.city or (isinstance(e.get('city'), str) and isinstance(self.city, str) and e.get('city').lower() == self.city.lower()):
                    entry = e
                    break
        if not entry:
            return (None, None)
        temp = entry.get('temperature')
        units = entry.get('temperature units', 'celsius')
        self.weather = entry.get('weather')
        self.temperature = temp
        if temp is None:
            return (None, self.weather)
        src = units.lower() if isinstance(units, str) else 'celsius'
        tgt = tmp_units.lower() if isinstance(tmp_units, str) else 'celsius'
        if src.startswith('c') and tgt.startswith('f'):
            self.temperature = self.celsius_to_fahrenheit()
        elif src.startswith('f') and tgt.startswith('c'):
            self.temperature = self.fahrenheit_to_celsius()
        # otherwise keep temperature as-is
        return (self.temperature, self.weather)

    def set_city(self, city):
        """
        Set the city of the weather system.
        """
        self.city = city

    def celsius_to_fahrenheit(self):
        """
        Convert the temperature from Celsius to Fahrenheit.
        """
        if self.temperature is None:
            return None
        # update internal temperature and return
        converted = float(self.temperature) * 9.0 / 5.0 + 32.0
        return converted

    def fahrenheit_to_celsius(self):
        """
        Convert the temperature from Fahrenheit to Celsius.
        """
        if self.temperature is None:
            return None
        converted = (float(self.temperature) - 32.0) * 5.0 / 9.0
        return converted