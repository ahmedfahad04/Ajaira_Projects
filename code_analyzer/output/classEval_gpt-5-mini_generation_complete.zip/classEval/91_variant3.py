import urllib.parse

class UrlPath:
    """
    The  class is a utility for encapsulating and manipulating the path component of a URL, including adding nodes, parsing path strings, and building path strings with optional encoding.
    """

    def __init__(self):
        """
        Initializes the UrlPath object with an empty list of segments and a flag indicating the presence of an end tag.
        """
        self.segments = []
        self.with_end_tag = False

    def add(self, segment):
        """
        Adds a segment to the list of segments in the UrlPath.
        This variant treats a literal empty segment as a trailing slash indicator.
        """
        if segment is None:
            return
        seg = str(segment)
        if seg == '':
            self.with_end_tag = True
            return
        # do not allow embedded slashes; treat them as separators and add each
        parts = [p for p in seg.split('/') if p != '']
        for p in parts:
            self.segments.append(p)
        self.with_end_tag = False

    def parse(self, path, charset):
        """
        Parses a given path string and populates the list of segments in the UrlPath.
        This variant uses urlparse to be tolerant to full URLs and unquote for decoding.
        """
        self.segments = []
        self.with_end_tag = False
        if path is None:
            return
        try:
            path_only = urllib.parse.urlsplit(path).path or ''
        except Exception:
            path_only = path or ''
        if path_only.endswith('/'):
            self.with_end_tag = True
        # strip leading/trailing slashes then split; ignore empty pieces created by repeated slashes
        stripped = path_only.strip('/')
        if stripped == '':
            return
        parts = [p for p in stripped.split('/') if p != '']
        for p in parts:
            # standard unquote supports encoding parameter
            try:
                decoded = urllib.parse.unquote(p, encoding=charset, errors='replace')
            except TypeError:
                # older Python fallback: simple unquote then encode/decode
                decoded = urllib.parse.unquote(p)
            self.segments.append(decoded)

    @staticmethod
    def fix_path(path):
        """
        Fixes the given path string by removing leading and trailing slashes.
        """
        if path is None:
            return ''
        try:
            path_only = urllib.parse.urlsplit(path).path
            if path_only is None:
                path_only = path
        except Exception:
            path_only = path
        # Remove leading and trailing slashes only
        return path_only.lstrip('/').rstrip('/')