import PyPDF2

class PDFHandler:
    """
    The class allows merging multiple PDF files into one and extracting text from PDFs using PyPDF2 library.
    """

    def __init__(self, filepaths):
        """
        takes a list of file paths filepaths as a parameter.
        It creates a list named readers using PyPDF2, where each reader opens a file from the given paths.
        """
        self.filepaths = filepaths
        self.readers = [PyPDF2.PdfFileReader(fp) for fp in filepaths]

    def merge_pdfs(self, output_filepath):
        MergerClass = None
        if hasattr(PyPDF2, "PdfMerger"):
            MergerClass = PyPDF2.PdfMerger
        elif hasattr(PyPDF2, "PdfFileMerger"):
            MergerClass = PyPDF2.PdfFileMerger
        if MergerClass is not None:
            merger = MergerClass()
            for fp in self.filepaths:
                merger.append(fp)
            with open(output_filepath, "wb") as out_f:
                merger.write(out_f)
                try:
                    merger.close()
                except Exception:
                    pass
            return f"Merged PDFs saved at {output_filepath}"
        else:
            writer = PyPDF2.PdfFileWriter()
            for reader in self.readers:
                try:
                    if getattr(reader, "isEncrypted", False):
                        reader.decrypt("")
                except Exception:
                    pass
                try:
                    pages = reader.getNumPages()
                    for i in range(pages):
                        writer.addPage(reader.getPage(i))
                except Exception:
                    for p in getattr(reader, "pages", []):
                        writer.addPage(p)
            with open(output_filepath, "wb") as out_f:
                writer.write(out_f)
            return f"Merged PDFs saved at {output_filepath}"

    def extract_text_from_pdfs(self):
        texts = []
        for fp, reader in zip(self.filepaths, self.readers):
            text_accum = []
            try:
                if getattr(reader, "isEncrypted", False):
                    try:
                        reader.decrypt("")
                    except Exception:
                        pass
                if hasattr(reader, "getNumPages"):
                    for i in range(reader.getNumPages()):
                        page = reader.getPage(i)
                        txt = page.extractText() if hasattr(page, "extractText") else getattr(page, "extract_text", lambda: "")()
                        if txt:
                            text_accum.append(txt)
                else:
                    for p in getattr(reader, "pages", []):
                        txt = getattr(p, "extract_text", lambda: "")()
                        if txt:
                            text_accum.append(txt)
            except Exception:
                try:
                    r2 = PyPDF2.PdfFileReader(fp)
                    if getattr(r2, "isEncrypted", False):
                        try:
                            r2.decrypt("")
                        except Exception:
                            pass
                    for i in range(r2.getNumPages()):
                        p = r2.getPage(i)
                        t = p.extractText() if hasattr(p, "extractText") else getattr(p, "extract_text", lambda: "")()
                        if t:
                            text_accum.append(t)
                except Exception:
                    pass
            texts.append("".join(text_accum))
        return texts

# Classification response:
# class renaming; method renaming; variable renaming; early return; try-except wrapper; nested conditional; accumulator list; temporary variable; list comprehension; zip usage; join/split usage; membership test; error suppression; boundary case handling