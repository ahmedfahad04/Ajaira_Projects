class Server:
    """
    This is a class as a server, which handles a white list, message sending and receiving, and information display.
    """

    def __init__(self):
        """
        Initialize the whitelist as an empty list, and initialize the sending and receiving information as an empty dictionary
        """
        self.white_list = []
        self.send_struct = {}
        self.receive_struct = {}
        # keep history for robustness
        self._send_history = []
        self._recv_history = []

    def add_white_list(self, addr):
        """
        Add an address to the whitelist and do nothing if it already exists
        """
        try:
            # coerce to int if possible
            addr_int = int(addr)
        except Exception:
            addr_int = addr
        if addr_int in self.white_list:
            return False
        self.white_list.append(addr_int)
        return self.white_list

    def del_white_list(self, addr):
        """
        Remove an address from the whitelist and do nothing if it does not exist
        """
        try:
            addr_int = int(addr)
        except Exception:
            addr_int = addr
        if addr_int not in self.white_list:
            return False
        self.white_list.remove(addr_int)
        return self.white_list

    def recv(self, info):
        """
        Receive information containing address and content. If the address is on the whitelist, receive the content; otherwise, do not receive it
        """
        if not isinstance(info, dict):
            return False
        if "addr" not in info or "content" not in info:
            return False
        addr = info["addr"]
        if addr in self.white_list:
            self.receive_struct = {"addr": addr, "content": info["content"]}
            self._recv_history.append(self.receive_struct.copy())
            return info["content"]
        return False

    def send(self, info):
        """
        Send information containing address and content
        """
        if not isinstance(info, dict):
            return "send failed: info must be dict"
        if "addr" not in info or "content" not in info:
            return "send failed: missing keys"
        # allow send regardless of whitelist
        self.send_struct = {"addr": info["addr"], "content": info["content"]}
        self._send_history.append(self.send_struct.copy())

    def show(self, type):
        """
        Returns struct of the specified type
        """
        if type == "send":
            return self.send_struct
        if type == "receive":
            return self.receive_struct
        return False