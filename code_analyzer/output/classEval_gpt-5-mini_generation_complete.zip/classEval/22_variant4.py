class ClassRegistrationSystem:
    """
    This is a class as a class registration system, allowing to register students, register them for classes, retrieve students by major, get a list of all majors, and determine the most popular class within a specific major.
    """

    def __init__(self):
        self.students = []
        self.students_registration_classes = {}

    def register_student(self, student):
        if not isinstance(student, dict) or 'name' not in student or 'major' not in student:
            raise ValueError("student must be a dict with 'name' and 'major'")
        name = student['name']
        for s in self.students:
            if s.get('name') == name:
                return 0
        self.students.append({'name': name, 'major': student['major']})
        return 1

    def register_class(self, student_name, class_name):
        # allow registering classes even if student not registered as a student dict
        if student_name not in self.students_registration_classes:
            self.students_registration_classes[student_name] = []
        classes = self.students_registration_classes[student_name]
        # keep unique classes, preserve order
        if class_name not in classes:
            classes.append(class_name)
        return list(classes)

    def get_students_by_major(self, major):
        return [s['name'] for s in self.students if s.get('major') == major]

    def get_all_major(self):
        majors = []
        seen = set()
        for s in self.students:
            m = s.get('major')
            if m not in seen:
                seen.add(m)
                majors.append(m)
        return majors

    def get_most_popular_class_in_major(self, major):
        students_in_major = [s['name'] for s in self.students if s.get('major') == major]
        if not students_in_major:
            return None
        counts = {}
        best_class = None
        best_count = 0
        # iterate in student order and class order, update counts and best when strictly greater
        for student in students_in_major:
            for cls in self.students_registration_classes.get(student, []):
                counts[cls] = counts.get(cls, 0) + 1
                if counts[cls] > best_count:
                    best_count = counts[cls]
                    best_class = cls
        return best_class