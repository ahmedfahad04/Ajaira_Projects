import math
class AreaCalculator:
    """
    This is a class for calculating the area of different shapes, including circle, sphere, cylinder, sector and annulus.
    """

    def __init__(self, radius):
        """
        Initialize the radius for shapes.
        :param radius: float
        """
        self.radius = float(radius)

    @property
    def _circle_area(self):
        return math.pi * (self.radius ** 2)

    def calculate_circle_area(self):
        """
        calculate the area of circle based on self.radius
        :return: area of circle, float
        """
        return self._circle_area

    def calculate_sphere_area(self):
        """
        calculate the area of sphere based on self.radius
        :return: area of sphere, float
        """
        return 4.0 * self._circle_area

    def calculate_cylinder_area(self, height):
        """
        calculate the area of cylinder based on self.radius and height
        :param height: height of cylinder, float
        :return: area of cylinder, float
        """
        h = float(height)
        # total surface area = lateral + 2*base = 2*pi*r*h + 2*pi*r^2
        return 2.0 * math.pi * self.radius * h + 2.0 * self._circle_area

    def calculate_sector_area(self, angle):
        """
        calculate the area of sector based on self.radius and angle
        :param angle: angle of sector, float
        :return: area of sector, float
        """
        a = float(angle)
        return 0.5 * (self.radius ** 2) * a

    def calculate_annulus_area(self, inner_radius, outer_radius):
        """
        calculate the area of annulus based on inner_radius and out_radius
        :param inner_radius: inner radius of sector, float
        :param outer_radius: outer radius of sector, float
        :return: area of annulus, float
        """
        ir = float(inner_radius)
        orr = float(outer_radius)
        return math.pi * (orr * orr - ir * ir)