import json
import os
from collections import OrderedDict

class JSONProcessor:
    """
    This is a class to process JSON file, including reading and writing JSON files, as well as processing JSON data by removing a specified key from the JSON object.
    This variant uses OrderedDict to preserve insertion order explicitly.
    """

    def read_json(self, file_path):
        if not isinstance(file_path, str):
            return -1
        if not os.path.exists(file_path):
            return 0
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f, object_pairs_hook=OrderedDict)
        except Exception:
            return -1

    def write_json(self, data, file_path):
        if not isinstance(file_path, str):
            return -1
        try:
            dirn = os.path.dirname(file_path)
            if dirn and not os.path.exists(dirn):
                os.makedirs(dirn, exist_ok=True)
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return 1
        except Exception:
            return -1

    def process_json(self, file_path, remove_key):
        if not isinstance(file_path, str):
            return -1
        data = self.read_json(file_path)
        if data == 0:
            return 0
        if data == -1:
            return -1
        if not isinstance(data, (dict, OrderedDict)):
            return 0
        if remove_key in data:
            # produce a new OrderedDict without the key
            new_data = OrderedDict((k, v) for k, v in data.items() if k != remove_key)
            res = self.write_json(new_data, file_path)
            return 1 if res == 1 else -1
        return 0