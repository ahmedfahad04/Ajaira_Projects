from datetime import datetime
import numpy as np

class MovieBookingSystem:
    def __init__(self):
        self.movies = []
        self._map = {}

    def add_movie(self, name, price, start_time, end_time, n):
        st = datetime.strptime(start_time, "%H:%M")
        et = datetime.strptime(end_time, "%H:%M")
        seats = np.zeros((n, n), dtype=float)
        movie = {'name': name, 'price': float(price), 'start_time': st, 'end_time': et, 'seats': seats}
        if name in self._map:
            old = self._map[name]
            idx = self.movies.index(old)
            self.movies[idx] = movie
            self._map[name] = movie
        else:
            self.movies.append(movie)
            self._map[name] = movie

    def book_ticket(self, name, seats_to_book):
        movie = self._map.get(name)
        if movie is None:
            return "Movie not found."
        seats = movie['seats']
        n, m = seats.shape
        for pos in seats_to_book:
            if not isinstance(pos, tuple) or len(pos) != 2:
                return "Booking failed."
            r, c = pos
            if not (isinstance(r, int) and isinstance(c, int)):
                return "Booking failed."
            if r < 0 or c < 0 or r >= n or c >= m:
                return "Booking failed."
            if seats[r, c] != 0.0:
                return "Booking failed."
        for r, c in seats_to_book:
            seats[r, c] = 1.0
        return "Booking success."

    def available_movies(self, start_time, end_time):
        st = datetime.strptime(start_time, "%H:%M")
        et = datetime.strptime(end_time, "%H:%M")
        return [m['name'] for m in self.movies if m['start_time'] >= st and m['end_time'] <= et]

# Classification response:
# variable renaming; guard clause; early return; loop rewrite; dictionary lookup; membership test; list comprehension; tuple unpacking; in-place mutation; temporary variable; input validation; boundary case handling; type conversion