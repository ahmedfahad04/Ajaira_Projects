import random

class Snake:
    """
    The class is a snake game, with allows snake to move and eat food, and also enables to reset, and generat a random food position.
    """

    def __init__(self, SCREEN_WIDTH, SCREEN_HEIGHT, BLOCK_SIZE, food_position):
        self.length = 1
        self.SCREEN_WIDTH = int(SCREEN_WIDTH)
        self.SCREEN_HEIGHT = int(SCREEN_HEIGHT)
        self.BLOCK_SIZE = int(BLOCK_SIZE)
        self.positions = [self._center()]
        self.score = 0
        self.food_position = self._align(food_position)

    def _center(self):
        cx = int(self.SCREEN_WIDTH / 2)
        cy = int(self.SCREEN_HEIGHT / 2)
        return (self._align_coord(cx, self.SCREEN_WIDTH), self._align_coord(cy, self.SCREEN_HEIGHT))

    def _align_coord(self, val, limit):
        # snap to grid; ensure within bounds
        coord = (val // self.BLOCK_SIZE) * self.BLOCK_SIZE
        max_coord = limit - self.BLOCK_SIZE
        if coord < 0:
            coord = 0
        if coord > max_coord:
            coord = max_coord
        return coord

    def _align(self, pos):
        x, y = pos
        return (self._align_coord(int(x), self.SCREEN_WIDTH), self._align_coord(int(y), self.SCREEN_HEIGHT))

    def move(self, direction):
        dx = int(direction[0]) * self.BLOCK_SIZE
        dy = int(direction[1]) * self.BLOCK_SIZE
        head_x, head_y = self.positions[0]
        new_x = (head_x + dx) % self.SCREEN_WIDTH
        new_y = (head_y + dy) % self.SCREEN_HEIGHT
        # align to grid boundaries
        new_head = (self._align_coord(new_x, self.SCREEN_WIDTH), self._align_coord(new_y, self.SCREEN_HEIGHT))
        # collision with self
        if new_head in self.positions:
            self.reset()
            return
        # move head
        self.positions.insert(0, new_head)
        # if food eaten
        if new_head == self.food_position:
            self.eat_food()
        else:
            # trim tail to length
            while len(self.positions) > self.length:
                self.positions.pop()

    def random_food_position(self):
        max_x = (self.SCREEN_WIDTH - self.BLOCK_SIZE) // self.BLOCK_SIZE
        max_y = (self.SCREEN_HEIGHT - self.BLOCK_SIZE) // self.BLOCK_SIZE
        attempts = 0
        while True:
            attempts += 1
            fx = random.randint(0, max_x) * self.BLOCK_SIZE
            fy = random.randint(0, max_y) * self.BLOCK_SIZE
            if (fx, fy) not in self.positions:
                self.food_position = (fx, fy)
                return
            if attempts > 10000:
                # fallback: pick first free cell by scan
                for ix in range(0, self.SCREEN_WIDTH, self.BLOCK_SIZE):
                    for iy in range(0, self.SCREEN_HEIGHT, self.BLOCK_SIZE):
                        if (ix, iy) not in self.positions:
                            self.food_position = (ix, iy)
                            return

    def reset(self):
        self.length = 1
        self.positions = [self._center()]
        self.score = 0
        self.random_food_position()

    def eat_food(self):
        self.length += 1
        self.score += 100
        self.random_food_position()