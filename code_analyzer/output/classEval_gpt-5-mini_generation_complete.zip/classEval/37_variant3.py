class EncryptionUtils:
    """
    This is a class that provides methods for encryption, including the Caesar cipher, Vigenere cipher, and Rail Fence cipher.
    """

    def __init__(self, key):
        self.key = str(key)

    def caesar_cipher(self, plaintext, shift):
        if shift is None:
            return plaintext
        s = shift % 26
        def shift_char(c):
            if 'a' <= c <= 'z':
                return chr((ord(c) - 97 + s) % 26 + 97)
            if 'A' <= c <= 'Z':
                return chr((ord(c) - 65 + s) % 26 + 65)
            return c
        return ''.join(shift_char(c) for c in plaintext)

    def vigenere_cipher(self, plaintext):
        # If key contains non-alpha, use their positions mod 26
        key_shifts = [ (ord(k.lower()) - 97) % 26 for k in self.key if k.isalpha() ]
        if not key_shifts:
            return plaintext
        result = []
        j = 0
        n = len(key_shifts)
        for ch in plaintext:
            if ch.isalpha():
                shift = key_shifts[j % n]
                j += 1
                if ch.islower():
                    result.append(chr((ord(ch) - 97 + shift) % 26 + 97))
                else:
                    result.append(chr((ord(ch) - 65 + shift) % 26 + 65))
            else:
                result.append(ch)
        return ''.join(result)

    def rail_fence_cipher(self,plain_text, rails):
        if rails is None or rails <= 1:
            return plain_text
        if rails >= len(plain_text):
            return plain_text
        matrix = [[] for _ in range(rails)]
        row = 0
        direction = 1
        for ch in plain_text:
            matrix[row].append(ch)
            row += direction
            if row == 0 or row == rails - 1:
                direction *= -1
        return ''.join(''.join(r) for r in matrix)