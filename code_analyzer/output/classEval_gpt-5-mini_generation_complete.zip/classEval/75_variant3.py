from decimal import Decimal, getcontext
import copy

class ShoppingCart:
    """
    The class manages items, their prices, quantities, and allows to for add, removie, view items, and calculate the total price.
    """

    def __init__(self):
        """
        Initialize the items representing the shopping list as an empty dictionary
        """
        self.items = {}

    def add_item(self, item, price, quantity=1):
        if quantity <= 0:
            return
        p = Decimal(str(price))
        q = int(quantity)
        if item in self.items:
            # always keep the most recent price
            self.items[item]["price"] = p
            self.items[item]["quantity"] += q
        else:
            self.items[item] = {"price": p, "quantity": q}

    def remove_item(self, item, quantity=1):
        if item not in self.items:
            raise KeyError("Item not found")
        q = int(quantity)
        if q <= 0:
            return
        current_q = self.items[item]["quantity"]
        if q >= current_q:
            del self.items[item]
        else:
            self.items[item]["quantity"] = current_q - q

    def view_items(self) -> dict:
        # return plain python types (floats for price) to match expectations
        out = {}
        for k, v in self.items.items():
            out[k] = {"price": float(v["price"]), "quantity": v["quantity"]}
        return out

    def total_price(self) -> float:
        total = Decimal('0')
        for v in self.items.values():
            total += v["price"] * v["quantity"]
        return float(total)