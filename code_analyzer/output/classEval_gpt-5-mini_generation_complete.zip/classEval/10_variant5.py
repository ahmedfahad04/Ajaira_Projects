class BinaryDataProcessor:
    """
    This is a class used to process binary data, which includes functions such as clearing non 0 or 1 characters, counting binary string information, and converting to corresponding strings based on different encoding methods.
    """

    def __init__(self, binary_string):
        self.binary_string = binary_string or ""
        self.clean_non_binary_chars()

    def clean_non_binary_chars(self):
        # simple membership filter
        self.binary_string = ''.join(ch for ch in self.binary_string if ch in '01')

    def calculate_binary_info(self):
        s = self.binary_string
        n = len(s)
        if n == 0:
            return {'Zeroes': 0.0, 'Ones': 0.0, 'Bit length': 0}
        z = s.count('0')
        o = n - z
        return {'Zeroes': round(z / n, 3), 'Ones': round(o / n, 3), 'Bit length': n}

    def convert_to_ascii(self):
        # Using slicing with step-of-8 and ignoring leftover bits
        s = self.binary_string
        out = []
        for i in range(0, len(s) - (len(s) % 8), 8):
            b = int(s[i:i+8], 2)
            out.append(chr(b))
        return ''.join(out)

    def convert_to_utf8(self):
        # Build bytes list and decode with 'ignore' to avoid errors
        s = self.binary_string
        byte_vals = []
        for i in range(0, len(s) - (len(s) % 8), 8):
            byte_vals.append(int(s[i:i+8], 2))
        return bytes(byte_vals).decode('utf-8', errors='ignore')