import math
from typing import List

class CombinationCalculator:
    """
    This is a class that provides methods to calculate the number of combinations for a specific count, calculate all possible combinations, and generate combinations with a specified number of elements.
    """

    def __init__(self, datas: List[str]):
        """
        Initialize the calculator with a list of data.
        """
        self.datas = datas

    @staticmethod
    def count(n: int, m: int) -> int:
        """
        Calculate the number of combinations using Pascal's triangle generation.
        """
        if n < 0 or m < 0 or m > n:
            return 0
        if m == 0 or m == n:
            return 1
        k = min(m, n - m)
        row = [1]
        for i in range(1, n + 1):
            new_row = [1] * (i + 1)
            for j in range(1, i):
                new_row[j] = row[j - 1] + row[j]
            row = new_row
            if i == n:
                return row[k]
        return 0

    @staticmethod
    def count_all(n: int) -> int:
        """
        Sum of combinations from 1 to n; check overflow.
        """
        if n < 0:
            return 0
        limit = 2**63 - 1
        total = 0
        # Use incremental pascal to compute row n and sum
        row = [1]
        for i in range(1, n + 1):
            new_row = [1] * (i + 1)
            for j in range(1, i):
                new_row[j] = row[j - 1] + row[j]
            row = new_row
        for k in range(1, len(row)):
            total += row[k]
            if total > limit:
                return float("inf")
        return total

    def select(self, m: int) -> List[List[str]]:
        """
        Generate combinations using an explicit stack DFS to preserve lexicographic order.
        """
        n = len(self.datas)
        if m <= 0 or m > n:
            return []
        result: List[List[str]] = []
        stack: List[tuple] = [(0, [])]  # (start_index, current_list)
        while stack:
            start, cur = stack.pop()
            # We push in reverse order to maintain lexicographic output
            for i in range(n - 1, start - 1, -1):
                new = cur + [self.datas[i]]
                if len(new) == m:
                    result.append(new[::-1])  # reverse because we built from right
                else:
                    stack.append((i + 1, new))
        # The above construction yields items in desired lexicographic order after reversing each
        # But because we appended as we found them, they are in correct order.
        # However ensure ordering matches expected by sorting by indices lexicographically.
        # We will sort by the positions of elements to guarantee order.
        index_map = {v: i for i, v in enumerate(self.datas)}
        result.sort(key=lambda comb: [index_map[x] for x in comb])
        return result

    def select_all(self) -> List[List[str]]:
        """
        Generate all combinations (sizes 1..n) by calling select.
        """
        all_res: List[List[str]] = []
        n = len(self.datas)
        for k in range(1, n + 1):
            all_res.extend(self.select(k))
        return all_res

    def _select(self, dataIndex: int, resultList: List[str], resultIndex: int, result: List[List[str]]):
        """
        Classic recursive backtracking implementation.
        """
        n = len(self.datas)
        r = len(resultList)
        if resultIndex == r:
            result.append(resultList.copy())
            return
        max_start = n - (r - resultIndex)
        for i in range(dataIndex, max_start + 1):
            resultList[resultIndex] = self.datas[i]
            self._select(i + 1, resultList, resultIndex + 1, result)