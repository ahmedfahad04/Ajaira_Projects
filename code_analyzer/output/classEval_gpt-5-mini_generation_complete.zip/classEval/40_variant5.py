class FitnessTracker:
    """
    This is a class as fitness tracker that implements to calculate BMI (Body Mass Index) and calorie intake based on the user's height, weight, age, and sex.
    """

    def __init__(self, height, weight, age, sex) -> None:
        # Accept many numeric types and normalize
        try:
            self.height = float(height)
        except Exception:
            raise TypeError("Height must be numeric")
        try:
            self.weight = float(weight)
        except Exception:
            raise TypeError("Weight must be numeric")
        self.age = int(age)
        self.sex = str(sex).strip().lower()
        self.BMI_std = [
            {"male": [20, 25]},
            {"female": [19, 24]}
        ]

    def _lookup_bounds(self):
        for d in self.BMI_std:
            if self.sex in d:
                lo, hi = d[self.sex]
                return float(lo), float(hi)
        # fallback: return male bounds if unknown sex
        return 20.0, 25.0

    def get_BMI(self):
        if self.height == 0:
            raise ValueError("Height must be non-zero.")
        return self.weight / (self.height ** 2)

    def condition_judge(self):
        bmi = self.get_BMI()
        low, high = self._lookup_bounds()
        if bmi < low:
            return -1
        if bmi > high:
            return 1
        return 0

    def calculate_calorie_intake(self):
        # gracefully handle unknown sex by treating as male by default
        if self.sex == "female":
            bmr = 10 * self.weight + 6.25 * self.height - 5 * self.age - 161
        else:
            bmr = 10 * self.weight + 6.25 * self.height - 5 * self.age + 5

        cond = self.condition_judge()
        if cond == 1:
            multiplier = 1.2
        elif cond == -1:
            multiplier = 1.6
        else:
            multiplier = 1.4
        return bmr * multiplier