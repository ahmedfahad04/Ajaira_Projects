from itertools import accumulate

class AvgPartition:
    """
    This is a class that partitions the given list into different blocks by specifying the number of partitions, with each block having a uniformly distributed length.
    """

    def __init__(self, lst, limit):
        if not isinstance(limit, int) or limit <= 0:
            raise ValueError("limit must be a positive integer")
        self.lst = list(lst)
        self.limit = limit
        self._bounds = None

    def setNum(self):
        n = len(self.lst)
        base = n // self.limit
        rem = n % self.limit
        return (base, rem)

    def _compute_bounds(self):
        if self._bounds is not None:
            return self._bounds
        base, rem = self.setNum()
        sizes = [(base + 1) if i < rem else base for i in range(self.limit)]
        # produce cumulative starts
        starts = [0] + list(accumulate(sizes))[:-1]
        ends = list(accumulate(sizes))
        self._bounds = list(zip(starts, ends))
        return self._bounds

    def get(self, index):
        if not isinstance(index, int):
            raise TypeError("index must be an integer")
        if index < 0:
            index += self.limit
        if index < 0 or index >= self.limit:
            raise IndexError("partition index out of range")
        bounds = self._compute_bounds()
        s, e = bounds[index]
        return self.lst[s:e]