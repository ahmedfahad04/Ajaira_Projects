from decimal import Decimal, ROUND_HALF_UP

class VendingMachine:
    """
    This is a class to simulate a vending machine, including adding products, inserting coins, purchasing products, viewing balance, replenishing product inventory, and displaying product information.
    """

    def __init__(self):
        """
        Initializes the vending machine's inventory and balance.
        """
        self.inventory = {}
        self.balance = Decimal('0.00')

    def _to_decimal(self, value):
        return Decimal(str(value)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

    def add_item(self, item_name, price, quantity):
        if quantity <= 0 or price < 0:
            return
        self.inventory[item_name] = {'price': self._to_decimal(price), 'quantity': int(quantity)}

    def insert_coin(self, amount):
        amt = self._to_decimal(amount)
        if amt <= Decimal('0.00'):
            return float(self.balance)
        self.balance = (self.balance + amt).quantize(Decimal('0.01'))
        return float(self.balance)

    def purchase_item(self, item_name):
        if item_name not in self.inventory:
            return False
        item = self.inventory[item_name]
        if item['quantity'] <= 0:
            return False
        price = item['price']
        if self.balance < price:
            return False
        item['quantity'] -= 1
        self.balance = (self.balance - price).quantize(Decimal('0.01'))
        return float(self.balance)

    def restock_item(self, item_name, quantity):
        if item_name not in self.inventory:
            return False
        if quantity > 0:
            self.inventory[item_name]['quantity'] += int(quantity)
        return True

    def display_items(self):
        if not self.inventory:
            return False
        out = []
        for name, item in self.inventory.items():
            price = f"{item['price']:.2f}"
            out.append(f"{name} - ${price} [{item['quantity']}]")
        return "\n".join(out)