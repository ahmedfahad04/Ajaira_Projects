class Manacher:
    """
    his is a class that implements a manacher algorithm to find the Longest palindromic substring in a given string.
    """

    def __init__(self, input_string) -> None:
        """
        Initializes the Manacher class with the given input_string.
        :param input_string: The input_string to be searched, str.
        """
        self.input_string = input_string or ""

    def palindromic_length(self, center, diff, string):
        """
        Recursively calculates the length of the palindromic substring based on a given center, difference value, and input string.
        :param center: The center of the palindromic substring, int.
        :param diff: The difference between the center and the current position, int.
        :param string: The string to be searched, str.
        :return: The length of the palindromic substring, int.
        >>> manacher = Manacher('ababa')
        >>> manacher.palindromic_length(2, 1, 'a|b|a|b|a')
        2

        """
        if center - diff < 0 or center + diff >= len(string):
            return 0
        if string[center - diff] == string[center + diff]:
            return 1 + self.palindromic_length(center, diff + 1, string)
        return 0

    def palindromic_string(self):
        """
        Finds the longest palindromic substring in the given string.
        :return: The longest palindromic substring, str.
        >>> manacher = Manacher('ababaxse')
        >>> manacher.palindromic_string()
        'ababa'

        """
        s = self.input_string
        if not s:
            return ""
        # Build transformed with sentinel characters to simplify expansions
        # using format: ^#a#b#b#a#$ (we'll use '|' as separator, add sentinels)
        t_body = "|".join(s)
        t = "^|" + t_body + "|$" if t_body else "^|$"
        n = len(t)
        p = [0] * n
        center = 0
        right = 0
        for i in range(1, n - 1):
            mirror = 2 * center - i
            if i < right:
                p[i] = min(right - i, p[mirror])
            # expand
            while i - (p[i] + 1) >= 0 and i + (p[i] + 1) < n and t[i - (p[i] + 1)] == t[i + (p[i] + 1)]:
                p[i] += 1
            if i + p[i] > right:
                center = i
                right = i + p[i]
        # find max
        max_i = 0
        max_r = 0
        for i in range(n):
            if p[i] > max_r:
                max_r = p[i]
                max_i = i
        # compute bounds in t
        start = max_i - max_r
        end = max_i + max_r + 1
        substr = t[start:end]
        # strip sentinel characters and separators
        # remove ^ and $ and leading/trailing |
        substr = substr.replace("^", "").replace("$", "")
        result = substr.replace("|", "")
        return result

# Classification response:
# variable renaming;loop rewrite;guard clause;accumulator list;join/split usage;manacher algorithm;empty input handling;default value handling