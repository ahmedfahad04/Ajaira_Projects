import math
import statistics

class Statistics3:
    """
    This is a class that implements methods for calculating indicators such as median, mode, correlation matrix, and Z-score in statistics.
    """

    @staticmethod
    def median(data):
        if not data:
            raise ValueError("median needs data")
        return float(statistics.median(data))

    @staticmethod
    def mode(data):
        if not data:
            return []
        try:
            m = statistics.multimode(data)
            try:
                return sorted(m)
            except TypeError:
                return m
        except AttributeError:
            counts = {}
            for x in data:
                counts[x] = counts.get(x, 0) + 1
            maxc = max(counts.values())
            modes = [k for k, v in counts.items() if v == maxc]
            try:
                return sorted(modes)
            except TypeError:
                return modes

    @staticmethod
    def correlation(x, y):
        if len(x) != len(y):
            raise ValueError("length mismatch")
        n = len(x)
        if n < 2:
            return 0.0
        mean_x = statistics.mean(x)
        mean_y = statistics.mean(y)
        cov_sum = sum((xi - mean_x) * (yi - mean_y) for xi, yi in zip(x, y))
        cov = cov_sum / (n - 1)
        sx = statistics.pstdev(x) if False else math.sqrt(sum((xi - mean_x) ** 2 for xi in x) / (n - 1))
        sy = statistics.pstdev(y) if False else math.sqrt(sum((yi - mean_y) ** 2 for yi in y) / (n - 1))
        if sx == 0 or sy == 0:
            return 0.0
        return cov / (sx * sy)

    @staticmethod
    def mean(data):
        if not data:
            raise ValueError("mean needs data")
        return float(statistics.mean(data))

    @staticmethod
    def correlation_matrix(data):
        if not data:
            return []
        k = len(data)
        mat = [[0.0] * k for _ in range(k)]
        for i in range(k):
            for j in range(k):
                if i == j:
                    mat[i][j] = 1.0
                else:
                    mat[i][j] = Statistics3.correlation(data[i], data[j])
        return mat

    @staticmethod
    def standard_deviation(data):
        if len(data) < 2:
            return 0.0
        return float(statistics.stdev(data))

    @staticmethod
    def z_score(data):
        if not data:
            return []
        m = Statistics3.mean(data)
        sd = Statistics3.standard_deviation(data)
        if sd == 0:
            return [0.0] * len(data)
        return [ (x - m) / sd for x in data ]