class BinaryDataProcessor:
    """
    This is a class used to process binary data, which includes functions such as clearing non 0 or 1 characters, counting binary string information, and converting to corresponding strings based on different encoding methods.
    """

    def __init__(self, binary_string):
        self.binary_string = binary_string or ""
        self.clean_non_binary_chars()

    def clean_non_binary_chars(self):
        # Use translate-like mapping by building new string with comprehension
        bs = self.binary_string
        self.binary_string = ''.join([c for c in bs if c == '0' or c == '1'])

    def calculate_binary_info(self):
        s = self.binary_string
        L = len(s)
        if L == 0:
            return {'Zeroes': 0.0, 'Ones': 0.0, 'Bit length': 0}
        z = s.count('0')
        o = L - z
        return {'Zeroes': round(z / L, 3), 'Ones': round(o / L, 3), 'Bit length': L}

    def convert_to_ascii(self):
        # Convert by using integer conversion on each 8-bit chunk; ignore incomplete final chunk
        s = self.binary_string
        out_chars = []
        for i in range(0, len(s), 8):
            chunk = s[i:i+8]
            if len(chunk) < 8:
                break
            val = int(chunk, 2)
            out_chars.append(chr(val))
        return ''.join(out_chars)

    def convert_to_utf8(self):
        # Use int-to-bytes conversion for the whole bitstring, preserving leading zeros by specifying length
        s = self.binary_string
        if not s:
            return ''
        # drop trailing incomplete byte
        usable_len = (len(s) // 8) * 8
        if usable_len == 0:
            return ''
        s_use = s[:usable_len]
        # convert each byte
        byte_vals = [int(s_use[i:i+8], 2) for i in range(0, len(s_use), 8)]
        b = bytes(byte_vals)
        return b.decode('utf-8', errors='replace')