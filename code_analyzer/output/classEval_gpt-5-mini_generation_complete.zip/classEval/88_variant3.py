from math import pi, fabs

class TriCalculator:
    def __init__(self):
        self._fact_cache = {0: 1, 1: 1}

    def factorial(self, a):
        if a < 0:
            raise ValueError("Negative factorial not allowed")
        if a in self._fact_cache:
            return self._fact_cache[a]
        last = max(self._fact_cache.keys())
        prod = self._fact_cache[last]
        for i in range(last + 1, a + 1):
            prod *= i
            self._fact_cache[i] = prod
        return self._fact_cache[a]

    def _to_rad(self, x):
        # reduce angle for better convergence
        r = (x % 360) * pi / 180.0
        if r > pi:
            r -= 2 * pi
        # further reduce to [-pi/2, pi/2] using cosine symmetry
        if r > pi/2:
            r = pi - r
        if r < -pi/2:
            r = -pi - r
        return r

    def taylor(self, x, n):
        rad = self._to_rad(x)
        s = 0.0
        for k in range(n):
            s += ((-1) ** k) * (rad ** (2 * k)) / self.factorial(2 * k)
        return s

    def cos(self, x):
        return self.taylor(x, 18)

    def sin(self, x):
        # compute sin by using series and cached factorials
        rad = self._to_rad(x)
        s = 0.0
        for k in range(18):
            s += ((-1) ** k) * (rad ** (2 * k + 1)) / self.factorial(2 * k + 1)
        return s

    def tan(self, x):
        c = self.cos(x)
        if fabs(c) < 1e-14:
            raise ZeroDivisionError("tan undefined (cosine is zero)")
        return self.sin(x) / c