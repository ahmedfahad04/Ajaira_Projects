class CurrencyConverter:
    """
    This is a class for currency conversion, which supports to convert amounts between different currencies, retrieve supported currencies, add new currency rates, and update existing currency rates.
    """
    def __init__(self):
        self.rates = {
            'USD': 1.0,
            'EUR': 0.85,
            'GBP': 0.72,
            'JPY': 110.15,
            'CAD': 1.23,
            'AUD': 1.34,
            'CNY': 6.40,
        }

    def convert(self, amount, from_currency, to_currency):
        # Allow case-insensitive currency codes
        if not isinstance(amount, (int, float)):
            raise TypeError("amount must be numeric")
        fc = from_currency.upper()
        tc = to_currency.upper()
        if fc not in self.rates:
            raise ValueError(f"Unsupported currency: {from_currency}")
        if tc not in self.rates:
            raise ValueError(f"Unsupported currency: {to_currency}")
        if self.rates[fc] == 0:
            raise ZeroDivisionError("Source rate is zero")
        return float(amount * (self.rates[tc] / self.rates[fc]))

    def get_supported_currencies(self):
        return list(self.rates.keys())

    def add_currency_rate(self, currency, rate):
        key = currency.upper()
        if key in self.rates:
            return False
        try:
            r = float(rate)
        except (TypeError, ValueError):
            raise TypeError("rate must be numeric")
        self.rates[key] = r

    def update_currency_rate(self, currency, new_rate):
        key = currency.upper()
        if key not in self.rates:
            return False
        try:
            r = float(new_rate)
        except (TypeError, ValueError):
            raise TypeError("new_rate must be numeric")
        self.rates[key] = r