class SQLQueryBuilder:
    """
    This class provides to build SQL queries, including SELECT, INSERT, UPDATE, and DELETE statements. 
    """

    @staticmethod
    def _val(v):
        if v is None:
            return "NULL"
        s = str(v)
        s = s.replace("'", "''")
        return "'" + s + "'"

    @staticmethod
    def select(table, columns='*', where=None):
        if isinstance(columns, (list, tuple)):
            columns_part = ", ".join(columns) if columns else "*"
        else:
            columns_part = columns or "*"
        sql = "SELECT " + columns_part + " FROM " + table
        if where:
            conds = list(map(lambda kv: f"{kv[0]}={SQLQueryBuilder._val(kv[1])}", where.items()))
            sql += " WHERE " + " AND ".join(conds)
        return sql

    @staticmethod
    def insert(table, data):
        keys = list(data.keys())
        vals = [SQLQueryBuilder._val(data[k]) for k in keys]
        return "INSERT INTO " + table + " (" + ", ".join(keys) + ") VALUES (" + ", ".join(vals) + ")"

    @staticmethod
    def delete(table, where=None):
        sql = "DELETE FROM " + table
        if where:
            conds = [f"{k}={SQLQueryBuilder._val(v)}" for k, v in where.items()]
            sql += " WHERE " + " AND ".join(conds)
        return sql

    @staticmethod
    def update(table, data, where=None):
        sets = [f"{k}={SQLQueryBuilder._val(v)}" for k, v in data.items()]
        sql = "UPDATE " + table + " SET " + ", ".join(sets)
        if where:
            conds = [f"{k}={SQLQueryBuilder._val(v)}" for k, v in where.items()]
            sql += " WHERE " + " AND ".join(conds)
        return sql