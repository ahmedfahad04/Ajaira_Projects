class DecryptionUtils:
    def __init__(self, key):
        self.key = key or ""

    def caesar_decipher(self, ciphertext, shift):
        try:
            s = int(shift) % 26
        except Exception:
            s = 0
        out = []
        for ch in ciphertext:
            if ch.isalpha():
                if ch.islower():
                    base = ord('a')
                else:
                    base = ord('A')
                out.append(chr((ord(ch) - base - s) % 26 + base))
            else:
                out.append(ch)
        return ''.join(out)

    def vigenere_decipher(self, ciphertext):
        k = [ord(c.lower()) - ord('a') for c in self.key if c.isalpha()]
        if not k:
            return ciphertext
        out = []
        j = 0
        for ch in ciphertext:
            if ch.isalpha():
                shift = k[j % len(k)]
                j += 1
                if ch.islower():
                    base = ord('a')
                else:
                    base = ord('A')
                out.append(chr((ord(ch) - base - shift) % 26 + base))
            else:
                out.append(ch)
        return ''.join(out)

    def rail_fence_decipher(self, encrypted_text, rails):
        if rails is None or rails <= 1:
            return encrypted_text
        n = len(encrypted_text)
        rail_indices = []
        direction = 1
        r = 0
        for i in range(n):
            rail_indices.append(r)
            if r == 0:
                direction = 1
            elif r == rails - 1:
                direction = -1
            r += direction
        rails_pos = [[] for _ in range(rails)]
        for idx, rail in enumerate(rail_indices):
            rails_pos[rail].append(idx)
        result = [''] * n
        pos = 0
        for rail in range(rails):
            for index in rails_pos[rail]:
                result[index] = encrypted_text[pos]
                pos += 1
        return ''.join(result)