class ChandrasekharSieve:
    """
    This is a class that uses the Chandrasekhar's Sieve method to find all prime numbers within the range
    """

    def __init__(self, n):
        self.n = int(n)
        self.primes = self.generate_primes()

    def generate_primes(self):
        n = self.n
        if n < 2:
            return []
        primes = []
        for candidate in range(2, n + 1):
            is_prime = True
            limit = int(candidate ** 0.5)
            for p in primes:
                if p > limit:
                    break
                if candidate % p == 0:
                    is_prime = False
                    break
            if is_prime:
                primes.append(candidate)
        return primes

    def get_primes(self):
        return list(self.primes)