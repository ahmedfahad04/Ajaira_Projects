import re

class ArgumentParser:
    """
    This is a class for parsing command line arguments to a dictionary.
    """

    def __init__(self):
        self.arguments = {}
        self.required = set()
        self.types = {}

    def parse_arguments(self, command_string):
        # Use regex to find --key=value, -k value or flags
        # Tokenize preserving quoted values roughly by splitting on spaces but keeping '=' forms
        tokens = command_string.split()
        i = 0
        while i < len(tokens):
            tok = tokens[i]
            if not tok.startswith('-'):
                i += 1
                continue
            core = tok.lstrip('-')
            # direct key=value
            if '=' in core:
                name, val = core.split('=', 1)
                self.arguments[name] = self._convert_type(name, val)
                i += 1
                continue
            # next token as value if present and not starting with dash
            if i + 1 < len(tokens) and not tokens[i + 1].startswith('-'):
                val = tokens[i + 1]
                self.arguments[core] = self._convert_type(core, val)
                i += 2
                continue
            # boolean flag
            self.arguments[core] = self._convert_type(core, True)
            i += 1
        missing = set(filter(lambda r: r not in self.arguments, self.required))
        if missing:
            return (False, missing)
        return (True, None)

    def get_argument(self, key):
        return self.arguments.get(key, None)

    def add_argument(self, arg, required=False, arg_type=str):
        if required:
            self.required.add(arg)
        if isinstance(arg_type, str):
            mp = {'int': int, 'float': float, 'str': str, 'bool': bool}
            self.types[arg] = mp.get(arg_type, str)
        else:
            self.types[arg] = arg_type

    def _convert_type(self, arg, value):
        t = self.types.get(arg)
        if t is None:
            return value
        # handle booleans specially
        if t is bool:
            if isinstance(value, bool):
                return value
            s = str(value).lower()
            if s in ('true', '1', 'yes', 'y', 'on'):
                return True
            if s in ('false', '0', 'no', 'n', 'off'):
                return False
            return True
        try:
            return t(value)
        except Exception:
            return value