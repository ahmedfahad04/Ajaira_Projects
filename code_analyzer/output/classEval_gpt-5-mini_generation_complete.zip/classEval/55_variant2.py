from functools import lru_cache

class Manacher:
    """
    his is a class that implements a manacher algorithm to find the Longest palindromic substring in a given string.
    """

    def __init__(self, input_string) -> None:
        """
        Initializes the Manacher class with the given input_string.
        :param input_string: The input_string to be searched, str.
        """
        self.input_string = input_string or ""

    def palindromic_length(self, center, diff, string):
        """
        Recursively calculates the length of the palindromic substring based on a given center, difference value, and input string.
        :param center: The center of the palindromic substring, int.
        :param diff: The difference between the center and the current position, int.
        :param string: The string to be searched, str.
        :return: The length of the palindromic substring, int.
        >>> manacher = Manacher('ababa')
        >>> manacher.palindromic_length(2, 1, 'a|b|a|b|a')
        2

        """
        if center - diff < 0 or center + diff >= len(string):
            return 0
        if string[center - diff] == string[center + diff]:
            return 1 + self.palindromic_length(center, diff + 1, string)
        return 0

    def palindromic_string(self):
        """
        Finds the longest palindromic substring in the given string.
        :return: The longest palindromic substring, str.
        >>> manacher = Manacher('ababaxse')
        >>> manacher.palindromic_string()
        'ababa'

        """
        s = self.input_string
        if not s:
            return ""
        # naive center expansion using recursion, but memoize comparisons to reduce repeated work
        t = "|".join(s)
        n = len(t)

        @lru_cache(maxsize=None)
        def expand(c, d):
            # return number of matching pairs
            if c - d < 0 or c + d >= n:
                return 0
            if t[c - d] == t[c + d]:
                return 1 + expand(c, d + 1)
            return 0

        best_start = 0
        best_len = 1  # length in original string
        for c in range(n):
            r = expand(c, 1)
            # transformed substring boundaries
            start = c - r
            end = c + r + 1
            substr_trans = t[start:end]
            candidate = substr_trans.replace("|", "")
            if len(candidate) > best_len:
                best_len = len(candidate)
                best_start = candidate  # store string directly
        # If best_start is string stored, return it; else compute from center 0
        if isinstance(best_start, str):
            return best_start
        # fallback
        return s[0] if s else ""

# Classification response:
# variable renaming; split condition; helper function extraction; memoization; standard library helper; join/split usage; empty input handling; default value handling