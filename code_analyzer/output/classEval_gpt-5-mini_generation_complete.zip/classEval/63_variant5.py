import re
from collections import Counter

class NLPDataProcessor2:
    """
    The class processes NLP data by extracting words from a list of strings, calculating the frequency of each word, and returning the top 5 most frequent words.
    """

    def process_data(self, string_list):
        clean = []
        for s in string_list:
            s2 = re.sub('[^A-Za-z ]', ' ', s)
            clean.append([w.lower() for w in s2.split() if w])
        return clean

    def calculate_word_frequency(self, words_list):
        c = Counter(sum(words_list, []))
        most = c.most_common()
        if not most:
            return {}
        return {w: cnt for w, cnt in most[:5]}

    def process(self, string_list):
        words = self.process_data(string_list)
        return self.calculate_word_frequency(words)

# Classification response:
# variable renaming; import reorganization; guard clause; list comprehension; standard library helper; literal rewrite