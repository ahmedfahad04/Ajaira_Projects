import datetime
import time
from typing import Any

class TimeUtils:
    """
    This is a time util class, including getting the current time and date, adding seconds to a datetime, converting between strings and datetime objects, calculating the time difference in minutes, and formatting a datetime object.
    """

    def __init__(self):
        """
        Get the current datetime
        """
        self.datetime = datetime.datetime.now()

    def get_current_time(self):
        """
        Return the current time in the format of '%H:%M:%S'
        """
        return datetime.datetime.now().strftime('%H:%M:%S')

    def get_current_date(self):
        """
        Return the current date in the format of "%Y-%m-%d"
        """
        return datetime.datetime.now().strftime('%Y-%m-%d')

    def add_seconds(self, seconds):
        """
        Add the specified number of seconds to the current time
        """
        if not isinstance(seconds, (int, float)):
            raise TypeError("seconds must be a number")
        new_dt = self.datetime + datetime.timedelta(seconds=seconds)
        return new_dt.strftime('%H:%M:%S')

    def string_to_datetime(self, string: str):
        """
        Convert the time string to a datetime instance
        Accepts strings like "2001-7-18 1:1:1" or "2001-07-18 01:01:01"
        """
        if not isinstance(string, str):
            raise TypeError("input must be a string")
        # Try standard parsing first
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
            try:
                return datetime.datetime.strptime(string, fmt)
            except Exception:
                pass
        # Fallback: parse integers manually
        parts = string.strip().split()
        date_parts = parts[0].split('-')
        time_parts = ["0", "0", "0"]
        if len(parts) > 1:
            time_parts = parts[1].split(':')
        y, m, d = (int(x) for x in date_parts)
        h = int(time_parts[0]) if len(time_parts) > 0 and time_parts[0] else 0
        mi = int(time_parts[1]) if len(time_parts) > 1 and time_parts[1] else 0
        s = int(time_parts[2]) if len(time_parts) > 2 and time_parts[2] else 0
        return datetime.datetime(y, m, d, h, mi, s)

    def datetime_to_string(self, datetime):
        """
        Convert a datetime instance to a string
        """
        if not hasattr(datetime, "strftime"):
            raise TypeError("expected a datetime instance")
        return datetime.strftime("%Y-%m-%d %H:%M:%S")

    def get_minutes(self, string_time1, string_time2):
        """
        Calculate how many minutes have passed between two times, rounded to nearest
        """
        dt1 = self.string_to_datetime(string_time1)
        dt2 = self.string_to_datetime(string_time2)
        seconds = (dt2 - dt1).total_seconds()
        minutes = round(seconds / 60.0)
        return int(minutes)

    def get_format_time(self, year, month, day, hour, minute, second):
        """
        get format time
        """
        dt = datetime.datetime(int(year), int(month), int(day), int(hour), int(minute), int(second))
        return dt.strftime("%Y-%m-%d %H:%M:%S")