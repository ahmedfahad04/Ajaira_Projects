from collections import Counter

class Order:
    def __init__(self):
        self.menu = []
        # maintain counts and prices separately
        self._selected_counts = Counter()
        self._selected_prices = {}
        self.sales = {}
        # expose selected_dishes in required format when needed
        self.selected_dishes = []

    def _sync_selected_list(self):
        self.selected_dishes = []
        for dish, cnt in self._selected_counts.items():
            self.selected_dishes.append({"dish": dish, "count": cnt, "price": self._selected_prices.get(dish, 0.0)})

    def add_dish(self, dish):
        name = dish.get("dish")
        cnt = int(dish.get("count", 0))
        if not name or cnt <= 0:
            return False
        for m in self.menu:
            if m.get("dish") == name:
                avail = m.get("count", 0)
                if avail < cnt:
                    return False
                m["count"] = avail - cnt
                self._selected_counts[name] += cnt
                # prefer menu price
                price = m.get("price", dish.get("price"))
                self._selected_prices[name] = price
                self._sync_selected_list()
                return True
        return False

    def calculate_total(self):
        total = 0.0
        for dish, cnt in self._selected_counts.items():
            price = self._selected_prices.get(dish, 0.0)
            sale = self.sales.get(dish, 1.0)
            total += price * cnt * sale
        return float(total)

    def checkout(self):
        if not any(self._selected_counts.values()):
            return False
        return self.calculate_total()

# Classification response:
# standard library helper; accumulator dict; helper function extraction; guard clause; any/all usage; input validation; type conversion; default value handling; variable renaming; state variable; behavior change