import sqlite3

class MovieTicketDB:
    """
    This is a class for movie database operations, which allows for inserting movie information, searching for movie information by name, and deleting movie information by name.
    """

    def __init__(self, db_name):
        self.db_name = db_name
        self.connection = sqlite3.connect(db_name)
        self.cursor = self.connection.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.executescript("""
        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            movie_name TEXT NOT NULL,
            theater_name TEXT,
            seat_number TEXT,
            customer_name TEXT
        );
        """)
        self.connection.commit()

    def insert_ticket(self, movie_name, theater_name, seat_number, customer_name):
        if not movie_name or not customer_name:
            raise ValueError("movie_name and customer_name are required")
        with self.connection:
            cur = self.connection.execute(
                "INSERT INTO tickets (movie_name, theater_name, seat_number, customer_name) VALUES (?, ?, ?, ?)",
                (movie_name, theater_name, seat_number, customer_name)
            )
            return cur.lastrowid

    def search_tickets_by_customer(self, customer_name):
        conn = sqlite3.connect(self.db_name)
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT id, movie_name, theater_name, seat_number, customer_name FROM tickets WHERE customer_name = ?",
                (customer_name,)
            )
            rows = cur.fetchall()
            return rows
        finally:
            conn.close()

    def delete_ticket(self, ticket_id):
        with self.connection:
            cur = self.connection.execute("DELETE FROM tickets WHERE id = ?", (ticket_id,))
            return cur.rowcount

    def __del__(self):
        try:
            self.connection.close()
        except Exception:
            pass

# Classification response:
# guard clause; exception handling; state variable; temporary variable; standard library helper; literal rewrite; input validation; error suppression; behavior change