import socket
import netifaces
import ipaddress
from functools import lru_cache


class IpUtil:
    """
    This is a class as tool for ip that can be used to obtain the local IP address, validate its validity, and also provides the functionality to retrieve the corresponding hostname.
    """

    @staticmethod
    def is_valid_ipv4(ip_address):
        try:
            if not isinstance(ip_address, str):
                return False
            ipaddress.ip_address(ip_address)
            return ip_address.count(':') == 0
        except Exception:
            return False

    @staticmethod
    def is_valid_ipv6(ip_address):
        try:
            if not isinstance(ip_address, str):
                return False
            ip = ipaddress.ip_address(ip_address)
            return ':' in ip.exploded or isinstance(ip, ipaddress.IPv6Address)
        except Exception:
            return False

    @staticmethod
    @lru_cache(maxsize=256)
    def get_hostname(ip_address):
        try:
            return socket.gethostbyaddr(ip_address)[0]
        except Exception:
            pass
        try:
            for iface in netifaces.interfaces():
                addrs = netifaces.ifaddresses(iface)
                for fam in (netifaces.AF_INET, netifaces.AF_INET6):
                    if fam in addrs:
                        for info in addrs[fam]:
                            addr = info.get('addr')
                            if addr and addr.split('%')[0] == ip_address:
                                return socket.gethostname()
        except Exception:
            pass
        return None