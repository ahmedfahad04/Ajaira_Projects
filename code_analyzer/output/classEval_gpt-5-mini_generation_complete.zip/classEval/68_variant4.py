import re

class PageUtil:
    """
    PageUtil class is a versatile utility for handling pagination and search functionalities in an efficient and convenient manner.
    """

    def __init__(self, data, page_size):
        self.data = list(data)
        self.page_size = int(page_size) if page_size and int(page_size) > 0 else 1
        self.total_items = len(self.data)
        self.total_pages = (self.total_items + self.page_size - 1) // self.page_size

    def get_page(self, page_number):
        try:
            p = int(page_number)
        except Exception:
            return []
        if p < 1 or self.total_pages == 0 or p > self.total_pages:
            return []
        start = (p - 1) * self.page_size
        return self.data[start:start + self.page_size]

    def get_page_info(self, page_number):
        try:
            p = int(page_number)
        except Exception:
            p = 1
        if self.total_pages == 0:
            return {
                "current_page": 1,
                "per_page": self.page_size,
                "total_pages": 0,
                "total_items": self.total_items,
                "has_previous": False,
                "has_next": False,
                "data": []
            }
        if p < 1:
            p = 1
        if p > self.total_pages:
            p = self.total_pages
        data = self.get_page(p)
        return {
            "current_page": p,
            "per_page": self.page_size,
            "total_pages": self.total_pages,
            "total_items": self.total_items,
            "has_previous": p > 1,
            "has_next": p < self.total_pages,
            "data": data
        }

    def search(self, keyword):
        kw = "" if keyword is None else str(keyword)
        # If keyword is given as a regex (e.g. "/pat/"), use regex; otherwise substring match
        pattern = None
        if len(kw) >= 2 and kw.startswith("/") and kw.rfind("/") > 0:
            try:
                regex_body = kw[1:kw.rfind("/")]
                flags_str = kw[kw.rfind("/") + 1 :]
                flags = 0
                if "i" in flags_str:
                    flags |= re.IGNORECASE
                pattern = re.compile(regex_body, flags)
            except re.error:
                pattern = None
        results = []
        if pattern:
            for item in self.data:
                if pattern.search(str(item)):
                    results.append(item)
        else:
            low = kw.lower()
            for item in self.data:
                if low in str(item).lower():
                    results.append(item)
        total_results = len(results)
        total_pages = (total_results + self.page_size - 1) // self.page_size if total_results else 0
        return {
            "keyword": kw,
            "total_results": total_results,
            "total_pages": total_pages,
            "results": results
        }

# Classification response:
# variable renaming;loop rewrite;try-except wrapper;guard clause;early return;list conversion;accumulator list;temporary variable;regex usage;membership test;brute force;helper function extraction;input validation;type conversion;empty input handling;default value handling