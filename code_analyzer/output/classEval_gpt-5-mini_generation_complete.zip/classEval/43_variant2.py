from dataclasses import dataclass, asdict

class HRManagementSystem:
    """
    This is a class as personnel management system that implements functions such as adding, deleting, querying, and updating employees
    """

    @dataclass
    class Employee:
        name: str
        position: str
        department: str
        salary: int

    def __init__(self):
        """
        Initialize the HRManagementSystem withan attribute employees, which is an empty dictionary.
        """
        self.employees = {}

    def add_employee(self, employee_id, name, position, department, salary):
        """
        Add a new employee to the HRManagementSystem.
        """
        if employee_id in self.employees:
            return False
        self.employees[employee_id] = HRManagementSystem.Employee(name, position, department, salary)
        return True

    def remove_employee(self, employee_id):
        """
        Remove an employee from the HRManagementSystem.
        """
        if employee_id in self.employees:
            del self.employees[employee_id]
            return True
        return False

    def update_employee(self, employee_id: int, employee_info: dict):
        """
        Update an employee's information in the HRManagementSystem.
        """
        if employee_id not in self.employees:
            return False
        emp = self.employees[employee_id]
        updated = {
            'name': employee_info.get('name', emp.name),
            'position': employee_info.get('position', emp.position),
            'department': employee_info.get('department', emp.department),
            'salary': employee_info.get('salary', emp.salary)
        }
        self.employees[employee_id] = HRManagementSystem.Employee(**updated)
        return True

    def get_employee(self, employee_id):
        """
        Get an employee's information from the HRManagementSystem.
        """
        emp = self.employees.get(employee_id)
        if emp is None:
            return False
        return asdict(emp)

    def list_employees(self):
        """
        List all employees' information in the HRManagementSystem.
        """
        output = {}
        for eid, emp in self.employees.items():
            d = asdict(emp)
            d_with_id = {'employee_ID': eid}
            d_with_id.update(d)
            output[eid] = d_with_id
        return output