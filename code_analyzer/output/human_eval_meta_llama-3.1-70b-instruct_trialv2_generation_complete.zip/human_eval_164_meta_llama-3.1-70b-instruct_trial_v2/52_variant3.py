def below_threshold(l: list, t: int):
    return max(l) < t