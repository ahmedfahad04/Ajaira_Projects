def get_positive(l: list):
    def recursive_get_positive(nums):
        if not nums:
            return []
        elif nums[0] > 0:
            return [nums[0]] + recursive_get_positive(nums[1:])
        else:
            return recursive_get_positive(nums[1:])
    return recursive_get_positive(l)