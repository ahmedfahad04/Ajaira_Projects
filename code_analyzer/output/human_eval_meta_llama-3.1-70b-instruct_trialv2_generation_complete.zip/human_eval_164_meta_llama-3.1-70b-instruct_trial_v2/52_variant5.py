def below_threshold(l: list, t: int):
    return sum(1 for _ in l if _ >= t) == 0