def modp(n: int, p: int) -> int:
    binary = bin(n)[2:]
    result = 1
    for i, bit in enumerate(binary[::-1]):
        if bit == '1':
            result = (result * (2 ** (2 ** i))) % p
    return result