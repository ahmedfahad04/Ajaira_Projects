def circular_shift(x, shift):
    x_str = str(x)
    if shift >= len(x_str):
        return x_str[::-1]
    x_list = list(x_str)
    x_list = x_list[-shift:] + x_list[:-shift]
    return ''.join(x_list)