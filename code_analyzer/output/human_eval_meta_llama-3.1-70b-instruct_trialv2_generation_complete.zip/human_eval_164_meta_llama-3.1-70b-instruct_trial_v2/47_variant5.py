def median(l: list):
    n = len(l)
    if n == 0:
        raise ValueError("Cannot calculate median of empty list")
    sorted_l = sorted(l)
    if n % 2 == 1:
        return sorted_l[n // 2]
    else:
        return (sorted_l[n // 2 - 1] + sorted_l[n // 2]) / 2.0