def strlen(string: str) -> int:
    count = 0
    while string:
        string = string[1:]
        count += 1
    return count