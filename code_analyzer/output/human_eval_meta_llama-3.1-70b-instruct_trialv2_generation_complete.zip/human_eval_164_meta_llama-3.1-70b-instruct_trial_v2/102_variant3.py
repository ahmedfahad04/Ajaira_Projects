def choose_num(x, y):
    if x > y:
        return -1
    while y >= x:
        if y % 2 == 0:
            return y
        y -= 1
    return -1