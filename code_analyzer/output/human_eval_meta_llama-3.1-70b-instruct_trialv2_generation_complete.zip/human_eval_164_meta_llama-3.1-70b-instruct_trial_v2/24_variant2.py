def largest_divisor(n: int) -> int:
    i = 2
    while i * i <= n:
        if n % i == 0:
            return n // i
        i += 1
    return 1