def total_match(lst1, lst2):
    from functools import reduce
    def total_chars(lst):
        return reduce(lambda x, y: x + len(y), lst, 0)
    return lst1 if total_chars(lst1) <= total_chars(lst2) else lst2