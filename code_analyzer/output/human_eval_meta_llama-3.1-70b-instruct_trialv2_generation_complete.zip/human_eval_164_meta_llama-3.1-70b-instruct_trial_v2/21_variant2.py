def rescale_to_unit(numbers: List[float]) -> List[float]:
    min_num = numbers[0]
    max_num = numbers[0]
    for num in numbers:
        if num < min_num:
            min_num = num
        elif num > max_num:
            max_num = num
    return [(num - min_num) / (max_num - min_num) for num in numbers]