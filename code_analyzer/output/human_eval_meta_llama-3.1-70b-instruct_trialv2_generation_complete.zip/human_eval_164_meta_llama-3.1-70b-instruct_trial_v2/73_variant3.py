def smallest_change(arr):
    return sum(a != b for a, b in zip(arr, arr[::-1])) // 2