def largest_prime_factor(n: int):
    sieve = [True] * (n + 1)
    sieve[0:2] = [False, False]
    for current_prime in range(2, int(n ** 0.5) + 1):
        if sieve[current_prime]:
            for multiple in range(current_prime * current_prime, n + 1, current_prime):
                sieve[multiple] = False
    primes = [num for num, is_prime in enumerate(sieve) if is_prime]
    for prime in reversed(primes):
        if n % prime == 0:
            return prime