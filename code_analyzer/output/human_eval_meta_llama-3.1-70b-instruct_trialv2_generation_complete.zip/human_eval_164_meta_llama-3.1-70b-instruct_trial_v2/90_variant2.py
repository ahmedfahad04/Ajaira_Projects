def next_smallest(lst):
    if len(lst) < 2:
        return None
    min_val = min(lst)
    min_val_count = lst.count(min_val)
    if min_val_count == len(lst):
        return None
    return min(i for i in lst if i != min_val)