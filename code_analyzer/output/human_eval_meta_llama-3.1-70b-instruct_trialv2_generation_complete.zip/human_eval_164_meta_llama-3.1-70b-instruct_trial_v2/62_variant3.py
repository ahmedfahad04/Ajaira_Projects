def derivative(xs: list):
    result = []
    exponent = 1
    for coefficient in xs[1:]:
        result.append(coefficient * exponent)
        exponent += 1
    return result