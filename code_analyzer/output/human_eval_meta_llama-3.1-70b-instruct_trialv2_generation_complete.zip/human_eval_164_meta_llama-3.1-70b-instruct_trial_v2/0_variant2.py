import itertools

def has_close_elements(numbers, threshold):
    for num1, num2 in itertools.combinations(numbers, 2):
        if abs(num1 - num2) < threshold:
            return True
    return False