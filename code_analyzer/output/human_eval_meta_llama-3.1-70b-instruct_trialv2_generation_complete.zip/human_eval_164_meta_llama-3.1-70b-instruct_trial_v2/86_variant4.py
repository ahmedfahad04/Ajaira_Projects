def anti_shuffle(s):
    def sort_word(word):
        if word.isalpha():
            return ''.join(sorted(word))
        return word

    return ' '.join(sort_word(word) for word in s.split())