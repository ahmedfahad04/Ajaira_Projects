def triangle_area(a, h):
    import math
    return math.sqrt((a * h) / 2) * math.sqrt((a * h) / 2)