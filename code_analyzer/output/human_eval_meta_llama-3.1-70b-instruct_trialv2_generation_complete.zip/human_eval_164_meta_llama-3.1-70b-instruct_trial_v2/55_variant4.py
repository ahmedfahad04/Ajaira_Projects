def fib(n: int):
    if n <= 0:
        return "Input should be a positive integer"
    elif n == 1 or n == 2:
        return 1
    else:
        fib_sequence = {1: 1, 2: 1}
        for i in range(3, n+1):
            fib_sequence[i] = fib_sequence[i-1] + fib_sequence[i-2]
        return fib_sequence[n]