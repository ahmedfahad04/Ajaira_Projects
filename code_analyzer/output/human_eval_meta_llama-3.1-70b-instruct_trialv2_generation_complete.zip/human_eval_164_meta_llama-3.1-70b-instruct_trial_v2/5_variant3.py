def intersperse(numbers, delimeter):
    result = []
    for num in numbers:
        result.append(num)
        result.append(delimeter)
    return result[:-1]