def vowels_count(s):
    s = s.lower()
    vowels = 'aeiou'
    count = sum(1 for char in s if char in vowels)
    return count + (1 if s.endswith('y') else 0)