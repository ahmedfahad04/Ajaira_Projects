def pairs_sum_to_zero(l):
    hash_table = {}
    for num in l:
        if num in hash_table:
            hash_table[num] += 1
        else:
            hash_table[num] = 1
    for num in hash_table:
        if -num in hash_table and num != 0:
            return True
        if num == 0 and hash_table[num] > 1:
            return True
    return False