def incr_list(l: list):
    return [1] * len(l) if not l else [l[0] + 1] + incr_list(l[1:])