def solve(N):
    sum_of_digits = 0
    while N > 0:
        sum_of_digits += N % 2
        N //= 2
    return bin(sum_of_digits)[2:]