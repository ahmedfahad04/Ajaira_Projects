def rescale_to_unit(numbers: List[float]) -> List[float]:
    numbers.sort()
    min_num = numbers[0]
    max_num = numbers[-1]
    return [(num - min_num) / (max_num - min_num) for num in numbers]