def below_threshold(l: list, t: int):
    return all(map(lambda x: x < t, l))