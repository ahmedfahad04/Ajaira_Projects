def smallest_change(arr):
    def helper(left, right, count):
        if left >= right:
            return count
        if arr[left] != arr[right]:
            return helper(left + 1, right - 1, count + 1)
        return helper(left + 1, right - 1, count)
    return helper(0, len(arr) - 1, 0)