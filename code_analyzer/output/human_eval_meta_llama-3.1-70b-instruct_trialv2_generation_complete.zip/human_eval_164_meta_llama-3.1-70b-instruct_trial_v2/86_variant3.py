def anti_shuffle(s):
    result = []
    for word in s.split():
        chars = [char for char in word]
        chars.sort()
        result.append(''.join(chars))
    return ' '.join(result)