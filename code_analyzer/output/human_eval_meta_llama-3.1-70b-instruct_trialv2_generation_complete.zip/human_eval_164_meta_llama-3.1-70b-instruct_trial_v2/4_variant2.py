from typing import List
import numpy as np

def mean_absolute_deviation(numbers: List[float]) -> float:
    mean = np.mean(numbers)
    return np.mean(np.abs(np.array(numbers) - mean))