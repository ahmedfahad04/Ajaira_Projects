def largest_divisor(n: int) -> int:
    def gcd(a, b):
        while b:
            a, b = b, a % b
        return a
    for i in range(n - 1, 0, -1):
        if gcd(n, i) == i:
            return i