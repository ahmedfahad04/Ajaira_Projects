def encode_cyclic(s: str):
    encoded_chars = []
    for i in range(len(s)):
        if (i % 3) == 0 and i != 0:
            encoded_chars.append(s[i-2])
        else:
            encoded_chars.append(s[i])
    return "".join(encoded_chars)