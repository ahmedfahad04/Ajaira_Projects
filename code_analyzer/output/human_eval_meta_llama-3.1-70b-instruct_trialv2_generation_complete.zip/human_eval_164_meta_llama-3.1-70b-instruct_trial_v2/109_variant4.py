def move_one_ball(arr):
    if not arr:
        return True
    arr = arr + arr
    for i in range(len(arr)//2):
        if arr[i:i+len(arr)//2] == sorted(arr[:len(arr)//2]):
            return True
    return False