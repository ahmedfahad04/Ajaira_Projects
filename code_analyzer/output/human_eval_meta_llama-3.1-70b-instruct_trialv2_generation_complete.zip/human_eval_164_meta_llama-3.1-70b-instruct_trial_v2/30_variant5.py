def get_positive(l: list):
    positive_nums = []
    for num in l:
        if isinstance(num, (int, float)) and num > 0:
            positive_nums.append(num)
    return positive_nums