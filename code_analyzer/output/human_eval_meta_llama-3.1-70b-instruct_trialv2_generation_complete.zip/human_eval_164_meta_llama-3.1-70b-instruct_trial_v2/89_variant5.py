def encrypt(s):
    result = ""
    for char in s:
        if char.isalpha():
            shift = 4
            start = ord('A') if char.isupper() else ord('a')
            result += chr(start + (ord(char) - start + shift) % 26)
        else:
            result += char
    return result