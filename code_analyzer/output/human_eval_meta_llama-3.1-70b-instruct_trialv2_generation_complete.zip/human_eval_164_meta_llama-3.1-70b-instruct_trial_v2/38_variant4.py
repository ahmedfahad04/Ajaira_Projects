def encode_cyclic(s: str):
    def cycle_group(group):
        if len(group) == 3:
            return group[1:] + group[0]
        else:
            return group

    return "".join(map(cycle_group, [s[i:i+3] for i in range(0, len(s), 3)]))