def move_one_ball(arr):
    if len(arr) == 0:
        return True
    min_index = arr.index(min(arr))
    new_arr = arr[min_index:] + arr[:min_index]
    return all(new_arr[i] <= new_arr[i+1] for i in range(len(new_arr)-1))