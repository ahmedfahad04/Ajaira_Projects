def fruit_distribution(s,n):
    s = s.replace(' apples', '').replace(' oranges', '')
    numbers = [int(i) for i in s.split(' and ')]
    return n - sum(numbers)