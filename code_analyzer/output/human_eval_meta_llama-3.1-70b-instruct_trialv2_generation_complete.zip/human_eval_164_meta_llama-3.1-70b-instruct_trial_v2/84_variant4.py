def solve(N):
    binary = ''
    sum_of_digits = 0
    while N > 0:
        digit = N % 2
        binary = str(digit) + binary
        sum_of_digits += digit
        N //= 2
    return bin(sum_of_digits)[2:]