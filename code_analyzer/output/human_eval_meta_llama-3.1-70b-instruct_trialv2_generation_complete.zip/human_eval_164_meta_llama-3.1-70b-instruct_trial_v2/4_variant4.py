from typing import List

def mean_absolute_deviation(numbers: List[float]) -> float:
    numbers.sort()
    n = len(numbers)
    if n % 2 == 1:
        mean = numbers[n // 2]
    else:
        mean = (numbers[n // 2 - 1] + numbers[n // 2]) / 2
    return sum(abs(num - mean) for num in numbers) / n