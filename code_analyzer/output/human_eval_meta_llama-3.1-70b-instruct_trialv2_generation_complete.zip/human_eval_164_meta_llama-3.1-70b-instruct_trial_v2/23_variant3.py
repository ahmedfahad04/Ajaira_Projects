def strlen(string: str) -> int:
    return sum(1 for _ in string)