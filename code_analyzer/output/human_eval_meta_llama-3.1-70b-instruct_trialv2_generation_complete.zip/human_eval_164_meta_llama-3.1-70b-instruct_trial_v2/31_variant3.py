def is_prime(n):
    if n <= 1:
        return False
    sieve = [True] * (n + 1)
    sieve[0:2] = [False, False]
    for current_prime in range(2, int(n**0.5) + 1):
        if sieve[current_prime]:
            sieve[current_prime*2::current_prime] = [False] * len(sieve[current_prime*2::current_prime])
    return sieve[n]