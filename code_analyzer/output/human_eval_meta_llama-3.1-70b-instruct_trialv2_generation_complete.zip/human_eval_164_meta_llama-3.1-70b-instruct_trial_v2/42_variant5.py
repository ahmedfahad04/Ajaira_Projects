def incr_list(l: list):
    return list(map(lambda x: x.__add__(1), l))