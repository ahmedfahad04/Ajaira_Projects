def pluck(arr):
    even_nodes = [(val, idx) for idx, val in enumerate(arr) if val % 2 == 0]
    return min(even_nodes, default=[None, None]) if even_nodes else []