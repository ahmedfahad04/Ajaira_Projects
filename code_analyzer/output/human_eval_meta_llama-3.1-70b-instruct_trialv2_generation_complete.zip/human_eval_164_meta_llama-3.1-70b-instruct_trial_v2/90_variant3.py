def next_smallest(lst):
    if len(lst) < 2:
        return None
    lst = list(set(lst))
    lst.sort()
    if len(lst) < 2:
        return None
    return lst[1]