from typing import List

def concatenate(strings: List[str]) -> str:
    if not strings:
        return ''
    result = strings[0]
    for string in strings[1:]:
        result += string
    return result