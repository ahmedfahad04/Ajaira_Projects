def greatest_common_divisor(a: int, b: int) -> int:
    def prime_factors(n):
        i = 2
        factors = []
        while i * i <= n:
            if n % i:
                i += 1
            else:
                n //= i
                factors.append(i)
        if n > 1:
            factors.append(n)
        return factors
    a_factors = set(prime_factors(a))
    b_factors = set(prime_factors(b))
    common_factors = a_factors.intersection(b_factors)
    result = 1
    for factor in common_factors:
        result *= factor
    return result