def closest_integer(value):
    num = float(value)
    decimal_part = num - int(num)
    if decimal_part == 0.5:
        return int(num) + (1 if num > 0 else -1)
    elif decimal_part > 0.5:
        return int(num) + 1
    elif decimal_part < 0.5:
        return int(num)
    else:
        return int(num)