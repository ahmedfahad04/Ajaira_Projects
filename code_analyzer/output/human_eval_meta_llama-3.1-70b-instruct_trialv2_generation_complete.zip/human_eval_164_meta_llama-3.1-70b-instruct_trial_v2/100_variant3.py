def make_a_pile(n):
    result = [n]
    while len(result) < n:
        result.append(result[-1] + (2 if n % 2 == 0 else 2))
    return result