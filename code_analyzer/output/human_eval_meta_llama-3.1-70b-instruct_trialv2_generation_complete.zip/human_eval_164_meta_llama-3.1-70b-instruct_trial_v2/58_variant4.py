def common(l1: list, l2: list):
    l1_set = set(l1)
    return sorted([element for element in l2 if element in l1_set])