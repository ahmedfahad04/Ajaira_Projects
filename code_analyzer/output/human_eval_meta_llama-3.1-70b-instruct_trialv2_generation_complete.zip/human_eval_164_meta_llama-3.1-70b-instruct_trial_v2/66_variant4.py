def digitSum(s):
    result = 0
    for i in range(len(s)):
        if s[i].isupper():
            result += ord(s[i])
    return result