def search(lst):
    freq = {}
    for num in lst:
        freq[num] = freq.get(num, 0) + 1
    for num in sorted(freq, reverse=True):
        if freq[num] >= num:
            return num
    return -1