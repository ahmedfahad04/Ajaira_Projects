def poly(xs: list, x: float):
    result = 0
    i = 0
    while i < len(xs):
        result += xs[i] * (x ** i)
        i += 1
    return result