def intersperse(numbers, delimeter):
    return sum(([num, delimeter] for num in numbers[:-1]), []) + [numbers[-1]] if numbers else []