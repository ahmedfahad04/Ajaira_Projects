def fib(n: int):
    if n <= 0:
        return "Input should be a positive integer"
    elif n == 1 or n == 2:
        return 1
    else:
        sqrt_5 = 5 ** 0.5
        phi = (1 + sqrt_5) / 2
        psi = (1 - sqrt_5) / 2
        return int((phi ** n - psi ** n) / sqrt_5)