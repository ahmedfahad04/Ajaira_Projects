def make_a_pile(n):
    result = []
    for i in range(n):
        result.append(n + 2 * i if n % 2 == 0 else n + 2 * i)
    return result