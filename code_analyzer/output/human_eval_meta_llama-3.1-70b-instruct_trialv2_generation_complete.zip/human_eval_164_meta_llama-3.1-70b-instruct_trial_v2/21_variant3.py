def rescale_to_unit(numbers: List[float]) -> List[float]:
    min_num = min(numbers)
    max_num = max(numbers)
    diff = max_num - min_num
    return [((num - min_num) / diff) if diff != 0 else 0 for num in numbers]