def pluck(arr):
    even_nodes = [(val, idx) for idx, val in enumerate(arr) if val % 2 == 0]
    if not even_nodes:
        return []
    min_val = min(even_nodes, key=lambda x: x[0])[0]
    min_idx = min([idx for val, idx in even_nodes if val == min_val])
    return [min_val, min_idx]