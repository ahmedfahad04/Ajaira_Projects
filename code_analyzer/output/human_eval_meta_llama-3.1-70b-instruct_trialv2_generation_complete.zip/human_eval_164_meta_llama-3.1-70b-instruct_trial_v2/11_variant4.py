def string_xor(a: str, b: str) -> str:
    result = ''
    for x, y in zip(a, b):
        result += str(int(x) != int(y))
    return result