def derivative(xs: list):
    return list(map(lambda x: x[0] * x[1], enumerate(xs[1:], start=1)))