def hex_key(num):
    return sum(1 for digit in num if digit in '2357BD')