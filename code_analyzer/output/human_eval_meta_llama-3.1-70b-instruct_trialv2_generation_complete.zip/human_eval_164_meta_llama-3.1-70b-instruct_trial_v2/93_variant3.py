def encode(message):
    vowels = 'aeiouAEIOU'
    result = list(message)
    for i in range(len(message)):
        if message[i] in vowels:
            if message[i].islower():
                result[i] = chr(((ord(message[i]) - ord('a') + 2) % 26) + ord('a'))
            else:
                result[i] = chr(((ord(message[i]) - ord('A') + 2) % 26) + ord('A'))
        result[i] = result[i].swapcase()
    return ''.join(result)