def check_dict_case(dict):
    if not dict:
        return False
    keys = dict.keys()
    key_type = type(next(iter(keys)))
    if all(isinstance(key, key_type) and isinstance(key, str) for key in keys):
        lower = next(iter(keys)).islower()
        return all(key.islower() == lower for key in keys)
    return False