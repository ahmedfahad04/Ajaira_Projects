def rounded_avg(n, m):
    if n > m:
        return -1
    total = (m * (m + 1) - (n - 1) * n) // 2
    count = m - n + 1
    return bin(round(total / count))