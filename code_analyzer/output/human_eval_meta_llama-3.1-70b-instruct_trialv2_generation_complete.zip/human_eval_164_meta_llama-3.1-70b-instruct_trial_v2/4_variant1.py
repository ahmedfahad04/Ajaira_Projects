from typing import List
import statistics

def mean_absolute_deviation(numbers: List[float]) -> float:
    mean = statistics.mean(numbers)
    return sum(abs(num - mean) for num in numbers) / len(numbers)