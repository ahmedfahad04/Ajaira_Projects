def change_base(x: int, base: int) -> str:
    result = ''
    while x > 0:
        x, remainder = divmod(x, base)
        result = str(remainder) + result
    return result