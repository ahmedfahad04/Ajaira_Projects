def sort_third(l: list):
    third_idx = [i for i in range(len(l)) if i % 3 == 0]
    third_vals = sorted([l[i] for i in third_idx])
    for i, j in zip(third_idx, range(len(third_vals))):
        l[i] = third_vals[j]
    return l