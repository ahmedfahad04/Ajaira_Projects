def correct_bracketing(brackets: str):
    opening = brackets.count("<")
    closing = brackets.count(">")
    if opening != closing:
        return False
    for i in range(len(brackets)):
        if brackets[i] == ">":
            if i == 0 or brackets[i-1] != "<":
                return False
    return True