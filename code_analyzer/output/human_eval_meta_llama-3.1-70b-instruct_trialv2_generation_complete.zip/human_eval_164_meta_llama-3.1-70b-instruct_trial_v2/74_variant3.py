def total_match(lst1, lst2):
    def total_chars(lst):
        return sum(len(s) for s in lst)
    return lst1 if total_chars(lst1) <= total_chars(lst2) else lst2