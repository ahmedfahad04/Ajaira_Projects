def separate_paren_groups(paren_string: str) -> List[str]:
    paren_string = paren_string.replace(' ', '')
    result = []
    current_group = ''
    count = 0
    for char in paren_string:
        current_group += char
        if char == '(':
            count += 1
        else:
            count -= 1
        if count < 0:
            raise ValueError("Invalid input string")
        if count == 0:
            result.append(current_group)
            current_group = ''
    if count != 0:
        raise ValueError("Invalid input string")
    return result