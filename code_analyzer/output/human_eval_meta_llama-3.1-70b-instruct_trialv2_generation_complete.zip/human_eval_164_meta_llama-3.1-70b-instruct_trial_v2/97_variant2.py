def multiply(a, b):
    unit_a = a - (a // 10) * 10
    unit_b = b - (b // 10) * 10
    return unit_a * unit_b