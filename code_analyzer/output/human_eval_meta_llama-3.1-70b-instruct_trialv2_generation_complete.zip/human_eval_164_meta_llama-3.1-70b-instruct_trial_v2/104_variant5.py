def unique_digits(x):
    def has_even(n):
        n_set = set(str(n))
        even_set = set('2468')
        return len(n_set.intersection(even_set)) > 0
    
    return sorted([n for n in x if not has_even(n)])