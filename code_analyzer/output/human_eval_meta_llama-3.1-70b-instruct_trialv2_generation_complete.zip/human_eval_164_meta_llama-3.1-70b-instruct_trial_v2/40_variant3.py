def triples_sum_to_zero(l: list):
    seen = set()
    pairs = set()
    for num in l:
        for pair in pairs:
            if -num - pair in seen:
                return True
        for seen_num in seen:
            pairs.add(seen_num + num)
        seen.add(num)
    return False