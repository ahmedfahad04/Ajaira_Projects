def has_close_elements(numbers, threshold):
    min_diff = float('inf')
    for i in range(len(numbers)):
        for j in range(i + 1, len(numbers)):
            diff = abs(numbers[i] - numbers[j])
            min_diff = min(min_diff, diff)
            if min_diff < threshold:
                return True
    return False