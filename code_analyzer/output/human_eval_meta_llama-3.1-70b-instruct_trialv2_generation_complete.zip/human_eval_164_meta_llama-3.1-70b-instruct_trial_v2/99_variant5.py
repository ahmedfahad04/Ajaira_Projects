import decimal
def closest_integer(value):
    num = decimal.Decimal(value)
    rounded = num.quantize(decimal.Decimal('1'), rounding=decimal.ROUND_HALF_UP)
    return int(rounded)