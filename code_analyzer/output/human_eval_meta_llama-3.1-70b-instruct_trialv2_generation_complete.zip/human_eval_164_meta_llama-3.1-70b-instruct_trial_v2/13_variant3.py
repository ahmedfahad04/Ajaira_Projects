def greatest_common_divisor(a: int, b: int) -> int:
    def recursive_gcd(x, y):
        if y == 0:
            return x
        else:
            return recursive_gcd(y, x % y)
    return abs(recursive_gcd(a, b))