def will_it_fly(q, w):
    def is_palindrome(lst):
        return lst == lst[::-1]
    return is_palindrome(q) and sum(q) <= w