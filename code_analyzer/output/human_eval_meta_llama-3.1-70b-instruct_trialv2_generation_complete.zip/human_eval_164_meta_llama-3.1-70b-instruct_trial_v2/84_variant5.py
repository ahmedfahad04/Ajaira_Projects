def solve(N):
    def binary_sum(n):
        if n == 0:
            return 0
        else:
            return n % 2 + binary_sum(n // 2)
    return bin(binary_sum(N))[2:]