def common(l1: list, l2: list):
    l1_set = set(l1)
    result = []
    for element in set(l2):
        if element in l1_set:
            result.append(element)
    return sorted(result)