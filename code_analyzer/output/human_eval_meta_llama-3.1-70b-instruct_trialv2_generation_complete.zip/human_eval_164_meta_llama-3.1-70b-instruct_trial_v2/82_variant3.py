def prime_length(string):
    n = len(string)
    if n < 2:
        return False
    sieve = [True] * (n + 1)
    sieve[0:2] = [False, False]
    for currentPrime in range(2, int(n**0.5) + 1):
        if sieve[currentPrime]:
            sieve[currentPrime*2::currentPrime] = [False] * len(sieve[currentPrime*2::currentPrime])
    return sieve[n]