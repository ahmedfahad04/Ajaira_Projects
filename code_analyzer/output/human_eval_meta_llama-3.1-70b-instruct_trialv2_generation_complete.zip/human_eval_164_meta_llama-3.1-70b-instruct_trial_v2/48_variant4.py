def is_palindrome(text: str):
    stack = []
    for char in text:
        stack.append(char)
    for char in text:
        if char != stack.pop():
            return False
    return True