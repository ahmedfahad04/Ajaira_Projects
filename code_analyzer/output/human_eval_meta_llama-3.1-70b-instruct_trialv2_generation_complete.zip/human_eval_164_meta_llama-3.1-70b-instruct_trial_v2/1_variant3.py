def separate_paren_groups(paren_string: str) -> List[str]:
    paren_string = paren_string.replace(' ', '')
    result = []
    start = 0
    for i, char in enumerate(paren_string):
        if char == '(':
            count = 1
            for j in range(i + 1, len(paren_string)):
                if paren_string[j] == '(':
                    count += 1
                elif paren_string[j] == ')':
                    count -= 1
                if count == 0:
                    result.append(paren_string[start:j + 1])
                    start = j + 1
                    break
    return result