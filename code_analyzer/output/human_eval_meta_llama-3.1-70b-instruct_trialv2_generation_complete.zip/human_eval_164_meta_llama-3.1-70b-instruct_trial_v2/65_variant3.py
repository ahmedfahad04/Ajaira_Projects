def circular_shift(x, shift):
    x_str = str(x)
    if shift >= len(x_str):
        return x_str[::-1]
    return ''.join([x_str[i - shift] for i in range(len(x_str))])