def count_upper(s):
    vowels = 'AEIOU'
    return sum(1 for i, char in enumerate(s) if char.isupper() and i % 2 == 0 and vowels.find(char) != -1)