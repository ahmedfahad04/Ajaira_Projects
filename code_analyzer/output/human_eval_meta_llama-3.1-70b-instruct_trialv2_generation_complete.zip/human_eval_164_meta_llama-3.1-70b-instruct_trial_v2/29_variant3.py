def filter_by_prefix(strings, prefix):
    return list(filter(lambda string: string.startswith(prefix), strings))