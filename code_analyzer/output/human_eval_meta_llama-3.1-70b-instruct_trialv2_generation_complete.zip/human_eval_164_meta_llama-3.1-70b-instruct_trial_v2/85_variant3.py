def add(lst):
    even_at_odd = [num for i, num in enumerate(lst) if i % 2 != 0 and num % 2 == 0]
    return sum(even_at_odd)