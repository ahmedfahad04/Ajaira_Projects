def is_palindrome(string: str) -> bool:
    char_array = list(string)
    left, right = 0, len(char_array) - 1
    while left < right:
        char_array[left], char_array[right] = char_array[right], char_array[left]
        left += 1
        right -= 1
    return string == ''.join(char_array)