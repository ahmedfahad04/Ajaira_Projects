def correct_bracketing(brackets: str):
    from collections import deque
    queue = deque()
    for bracket in brackets:
        if bracket == "<":
            queue.append(bracket)
        elif bracket == ">":
            if not queue:
                return False
            queue.popleft()
    return not queue