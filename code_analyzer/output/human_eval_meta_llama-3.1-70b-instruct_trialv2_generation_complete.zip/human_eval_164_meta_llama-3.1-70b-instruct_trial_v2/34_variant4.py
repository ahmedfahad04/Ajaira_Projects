def unique(l: list):
    l.sort()
    unique_l = []
    for i in l:
        if not unique_l or i != unique_l[-1]:
            unique_l.append(i)
    return unique_l