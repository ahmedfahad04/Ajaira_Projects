def filter_by_prefix(strings, prefix):
    class StringFilter:
        def __init__(self, prefix):
            self.prefix = prefix

        def __call__(self, string):
            return string.startswith(self.prefix)

    return list(filter(StringFilter(prefix), strings))