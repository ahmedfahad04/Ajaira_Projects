def common(l1: list, l2: list):
    result = []
    for element in l1:
        if element in l2 and element not in result:
            result.append(element)
    return sorted(result)