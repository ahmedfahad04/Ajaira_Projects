def sort_third(l: list):
    third_idx = [i for i in range(len(l)) if i % 3 == 0]
    third_vals = [l[i] for i in third_idx]
    third_vals.sort()
    result = l[:]
    for i, j in zip(third_idx, range(len(third_vals))):
        result[i] = third_vals[j]
    return result