def filter_by_prefix(strings, prefix):
    result = []
    for string in strings:
        if string.startswith(prefix):
            result.append(string)
    return result