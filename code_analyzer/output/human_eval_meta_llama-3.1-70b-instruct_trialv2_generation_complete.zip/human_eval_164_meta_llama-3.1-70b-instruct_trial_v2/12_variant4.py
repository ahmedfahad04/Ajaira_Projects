def longest(strings: List[str]) -> Optional[str]:
    if not strings:
        return None
    return next(s for s in sorted(strings, key=len, reverse=True))