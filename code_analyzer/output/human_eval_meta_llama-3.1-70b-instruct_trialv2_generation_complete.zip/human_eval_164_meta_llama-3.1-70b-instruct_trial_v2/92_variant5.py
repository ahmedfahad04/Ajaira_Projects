def any_int(x, y, z):
    def is_integer_and_sum(num1, num2, num3):
        if num1.is_integer() and num2.is_integer() and num3.is_integer():
            return num1 + num2 == num3 or num1 + num3 == num2 or num2 + num3 == num1
        return False
    return is_integer_and_sum(x, y, z)