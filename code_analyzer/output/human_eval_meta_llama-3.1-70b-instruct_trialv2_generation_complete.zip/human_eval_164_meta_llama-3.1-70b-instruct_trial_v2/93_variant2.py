def encode(message):
    vowels = 'aeiouAEIOU'
    result = ''
    for char in message:
        if char in vowels:
            if char.islower():
                result += chr(((ord(char) - ord('a') + 2) % 26) + ord('a')).swapcase()
            else:
                result += chr(((ord(char) - ord('A') + 2) % 26) + ord('A')).swapcase()
        else:
            result += char.swapcase()
    return result