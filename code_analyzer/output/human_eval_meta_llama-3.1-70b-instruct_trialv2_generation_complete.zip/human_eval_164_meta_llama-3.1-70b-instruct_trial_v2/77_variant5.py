def iscube(a):
    i = 0
    while True:
        cube = i * i * i
        if cube == a:
            return True
        elif cube > a:
            return False
        i += 1