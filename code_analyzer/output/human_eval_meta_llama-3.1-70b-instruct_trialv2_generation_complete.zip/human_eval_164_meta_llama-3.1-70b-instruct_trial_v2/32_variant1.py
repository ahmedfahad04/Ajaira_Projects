def poly(xs: list, x: float):
    result = 0
    for i, coeff in enumerate(xs):
        result += coeff * (x ** i)
    return result