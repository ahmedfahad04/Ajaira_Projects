def filter_by_substring(strings, substring):
    result = []
    for string in strings:
        if substring in string:
            result.append(string)
    return result