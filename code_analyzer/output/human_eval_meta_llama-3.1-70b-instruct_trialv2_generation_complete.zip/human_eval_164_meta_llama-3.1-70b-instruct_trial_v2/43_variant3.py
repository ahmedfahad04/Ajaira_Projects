def pairs_sum_to_zero(l):
    l.sort()
    left, right = 0, len(l) - 1
    while left < right:
        if l[left] + l[right] == 0:
            return True
        elif l[left] + l[right] < 0:
            left += 1
        else:
            right -= 1
    return False