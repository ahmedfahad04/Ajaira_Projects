def will_it_fly(q, w):
    balanced = all(q[i] == q[-i - 1] for i in range(len(q) // 2))
    return balanced and sum(q) <= w