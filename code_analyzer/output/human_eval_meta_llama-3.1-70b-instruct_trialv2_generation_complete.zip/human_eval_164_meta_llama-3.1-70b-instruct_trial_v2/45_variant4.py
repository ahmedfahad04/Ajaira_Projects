def triangle_area(a, h):
    def calculate_area(a, h):
        return a * h / 2
    return calculate_area(a, h)