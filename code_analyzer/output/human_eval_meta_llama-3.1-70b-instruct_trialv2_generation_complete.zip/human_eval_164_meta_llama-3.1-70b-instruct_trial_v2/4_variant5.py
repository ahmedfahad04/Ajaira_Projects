from typing import List

def mean_absolute_deviation(numbers: List[float]) -> float:
    def calculate_mean(numbers):
        return sum(numbers) / len(numbers)

    def calculate_mad(numbers, mean):
        return sum(abs(num - mean) for num in numbers) / len(numbers)

    mean = calculate_mean(numbers)
    return calculate_mad(numbers, mean)