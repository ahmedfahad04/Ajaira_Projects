def search(lst):
    freq = {}
    for num in lst:
        freq[num] = freq.get(num, 0) + 1
    for num in range(len(lst), 0, -1):
        if num in freq and freq[num] >= num:
            return num
    return -1