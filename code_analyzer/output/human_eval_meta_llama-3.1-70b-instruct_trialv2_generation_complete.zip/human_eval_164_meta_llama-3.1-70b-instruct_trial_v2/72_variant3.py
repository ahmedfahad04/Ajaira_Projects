def will_it_fly(q, w):
    left, right = 0, len(q) - 1
    while left < right:
        if q[left] != q[right]:
            return False
        left += 1
        right -= 1
    return sum(q) <= w