def sort_numbers(numbers: str) -> str:
    num_map = {'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9}
    def quicksort(arr):
        if len(arr) <= 1:
            return arr
        pivot = arr[len(arr) // 2]
        left = [x for x in arr if num_map[x] < num_map[pivot]]
        middle = [x for x in arr if num_map[x] == num_map[pivot]]
        right = [x for x in arr if num_map[x] > num_map[pivot]]
        return quicksort(left) + middle + quicksort(right)
    return ' '.join(quicksort(numbers.split()))