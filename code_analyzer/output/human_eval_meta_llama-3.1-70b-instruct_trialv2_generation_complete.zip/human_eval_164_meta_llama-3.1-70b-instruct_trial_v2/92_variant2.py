def any_int(x, y, z):
    if not all(i.is_integer() for i in [x, y, z]):
        return False
    return sorted([x, y, z])[0] + sorted([x, y, z])[1] == sorted([x, y, z])[2]