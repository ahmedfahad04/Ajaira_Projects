def modp(n: int, p: int) -> int:
    if n == 0:
        return 1
    else:
        return (2 * modp(n-1, p)) % p