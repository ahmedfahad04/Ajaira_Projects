def sum_to_n(n: int):
    def recursive_sum(i, total):
        if i > n:
            return total
        return recursive_sum(i + 1, total + i)
    return recursive_sum(1, 0)