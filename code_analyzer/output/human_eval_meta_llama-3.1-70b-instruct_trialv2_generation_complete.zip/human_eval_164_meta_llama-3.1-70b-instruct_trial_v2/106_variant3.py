def f(n):
    result = []
    for i in range(1, n + 1):
        if i % 2 == 0:
            result.append(prod(range(1, i + 1)))
        else:
            result.append(sum(range(1, i + 1)))
    return result

from functools import reduce
from operator import mul

def prod(iterable):
    return reduce(mul, iterable, 1)