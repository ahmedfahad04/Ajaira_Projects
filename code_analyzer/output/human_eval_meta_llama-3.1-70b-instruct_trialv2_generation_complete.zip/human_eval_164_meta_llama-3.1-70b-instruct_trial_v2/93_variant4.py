def encode(message):
    vowels = 'aeiouAEIOU'
    result = ''
    for char in message:
        if char in vowels:
            shift = ord('a') if char.islower() else ord('A')
            result += chr((ord(char) - shift + 2) % 26 + shift)
        else:
            result += char.swapcase()
    return result.swapcase()