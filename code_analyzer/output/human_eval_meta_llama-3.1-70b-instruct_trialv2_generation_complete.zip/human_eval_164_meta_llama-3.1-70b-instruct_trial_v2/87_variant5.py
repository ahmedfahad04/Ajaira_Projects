def get_row(lst, x):
    result = {}
    for i, row in enumerate(lst):
        for j, val in enumerate(row):
            if val == x:
                if i not in result:
                    result[i] = []
                result[i].append(j)
    return sorted([(i, j) for i in result for j in sorted(result[i], reverse=True)], key=lambda x: (x[0], -x[1]))