def is_multiply_prime(a):
    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                return False
        return True

    def check(n, count, start):
        if count == 3:
            return n == 1
        for i in range(start, int(n**0.5) + 1):
            if n % i == 0 and is_prime(i):
                if check(n // i, count + 1, i):
                    return True
        return False
    return check(a, 0, 2)