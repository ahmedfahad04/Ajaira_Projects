def circular_shift(x, shift):
    x_str = str(x)
    shift = shift % len(x_str)
    result = ''
    for i in range(len(x_str)):
        result += x_str[(i - shift) % len(x_str)]
    return result