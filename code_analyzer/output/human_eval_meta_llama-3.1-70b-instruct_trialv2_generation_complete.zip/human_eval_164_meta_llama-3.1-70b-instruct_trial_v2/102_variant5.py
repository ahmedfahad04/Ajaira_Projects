def choose_num(x, y):
    if x > y:
        return -1
    return max((i for i in range(x, y + 1) if i % 2 == 0), default=-1)