def check_dict_case(dict):
    if not dict:
        return False
    keys = list(dict.keys())
    if all(isinstance(key, str) for key in keys):
        lower_keys = [key for key in keys if key.islower()]
        upper_keys = [key for key in keys if key.isupper()]
        return len(lower_keys) == 0 or len(upper_keys) == 0
    return False