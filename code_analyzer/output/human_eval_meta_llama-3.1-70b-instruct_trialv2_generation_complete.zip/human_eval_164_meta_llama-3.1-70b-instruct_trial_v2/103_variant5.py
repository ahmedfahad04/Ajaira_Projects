def rounded_avg(n, m):
    if n > m:
        return -1
    nums = [i for i in range(n, m + 1)]
    avg = sum(nums) / len(nums)
    return bin(round(avg))