def is_palindrome(string: str) -> bool:
    stack = []
    for char in string:
        stack.append(char)
    for char in string:
        if char != stack.pop():
            return False
    return True