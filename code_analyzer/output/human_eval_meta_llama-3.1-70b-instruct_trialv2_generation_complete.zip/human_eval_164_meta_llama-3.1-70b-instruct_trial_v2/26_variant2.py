from typing import List

def remove_duplicates(numbers: List[int]) -> List[int]:
    seen = set()
    seen_once = set()
    for num in numbers:
        if num not in seen:
            if num in seen_once:
                seen_once.remove(num)
                seen.add(num)
            else:
                seen_once.add(num)
    return [num for num in numbers if num in seen_once]