def move_one_ball(arr):
    if len(arr) == 0:
        return True
    min_index = arr.index(min(arr))
    for i in range(min_index, len(arr)):
        if arr[i] > arr[i-1]:
            continue
        else:
            return False
    for i in range(min_index):
        if arr[i] > arr[i-1]:
            return False
    return True