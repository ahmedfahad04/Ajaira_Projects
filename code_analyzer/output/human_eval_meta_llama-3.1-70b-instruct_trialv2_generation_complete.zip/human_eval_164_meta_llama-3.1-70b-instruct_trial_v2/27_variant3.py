def flip_case(string: str) -> str:
    result = []
    for char in string:
        if char.islower():
            result.append(char.upper())
        else:
            result.append(char.lower())
    return ''.join(result)