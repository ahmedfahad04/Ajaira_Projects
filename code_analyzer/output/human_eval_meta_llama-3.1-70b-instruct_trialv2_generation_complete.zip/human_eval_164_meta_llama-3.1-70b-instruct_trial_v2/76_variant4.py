def is_simple_power(x, n):
    if x < 1 or n < 2:
        return x == 1
    power = 0
    result = 1
    while result < x:
        result *= n
        power += 1
    return result == x