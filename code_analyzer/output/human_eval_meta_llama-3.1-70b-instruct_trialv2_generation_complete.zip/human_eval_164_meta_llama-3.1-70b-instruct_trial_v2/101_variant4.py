def words_string(s):
    words = []
    word = ''
    for char in s:
        if char.isalpha():
            word += char
        elif word:
            words.append(word)
            word = ''
    if word:
        words.append(word)
    return words