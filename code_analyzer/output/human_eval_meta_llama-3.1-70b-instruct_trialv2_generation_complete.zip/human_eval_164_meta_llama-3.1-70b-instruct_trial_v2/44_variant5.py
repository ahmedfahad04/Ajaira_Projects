def change_base(x: int, base: int) -> str:
    result = ''
    while x > 0:
        remainder = x % base
        x = x // base
        result = str(remainder) + result
    return result if result else '0'