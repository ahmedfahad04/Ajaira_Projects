def unique_digits(x):
    result = []
    for num in x:
        num_str = str(num)
        if all(int(digit) in [1, 3, 5, 7, 9] for digit in num_str):
            result.append(num)
    return sorted(result)