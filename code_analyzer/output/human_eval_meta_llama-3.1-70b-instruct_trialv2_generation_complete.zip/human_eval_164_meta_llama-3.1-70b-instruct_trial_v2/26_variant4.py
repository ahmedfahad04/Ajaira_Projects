from typing import List
from collections import OrderedDict

def remove_duplicates(numbers: List[int]) -> List[int]:
    count = OrderedDict()
    for num in numbers:
        count[num] = count.get(num, 0) + 1
    return [num for num in count if count[num] == 1]