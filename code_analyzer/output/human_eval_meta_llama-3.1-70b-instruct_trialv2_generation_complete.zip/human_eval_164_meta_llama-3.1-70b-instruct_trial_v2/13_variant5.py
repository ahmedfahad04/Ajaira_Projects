def greatest_common_divisor(a: int, b: int) -> int:
    def find_prime_factors(n):
        factors = []
        divisor = 2
        while n > 1:
            while n % divisor == 0:
                factors.append(divisor)
                n = n // divisor
            divisor += 1
        return factors
    a_factors = find_prime_factors(a)
    b_factors = find_prime_factors(b)
    common_factors = set(a_factors) & set(b_factors)
    result = 1
    for factor in common_factors:
        result *= factor ** min(a_factors.count(factor), b_factors.count(factor))
    return result