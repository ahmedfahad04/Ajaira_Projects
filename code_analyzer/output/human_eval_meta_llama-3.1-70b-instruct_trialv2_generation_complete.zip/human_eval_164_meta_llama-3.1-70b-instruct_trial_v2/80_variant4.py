def is_happy(s):
    if len(s) < 3:
        return False
    happy = True
    for i in range(len(s) - 2):
        if s[i] == s[i+1] or s[i] == s[i+2] or s[i+1] == s[i+2]:
            happy = False
            break
    return happy