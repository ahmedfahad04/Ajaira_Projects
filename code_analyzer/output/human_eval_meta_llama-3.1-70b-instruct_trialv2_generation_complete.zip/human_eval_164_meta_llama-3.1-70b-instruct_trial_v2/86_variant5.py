def anti_shuffle(s):
    result = []
    for word in s.split():
        if word.isalpha():
            sorted_chars = sorted(word)
            result.append(''.join(sorted_chars))
        else:
            result.append(word)
    return ' '.join(result)