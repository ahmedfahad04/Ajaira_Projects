def count_upper(s):
    return len([char for i, char in enumerate(s) if i % 2 == 0 and char.isupper() and char in 'AEIOU'])