def all_prefixes(string: str) -> List[str]:
    prefixes = []
    prefix = ''
    for char in string:
        prefix += char
        prefixes.append(prefix)
    return prefixes