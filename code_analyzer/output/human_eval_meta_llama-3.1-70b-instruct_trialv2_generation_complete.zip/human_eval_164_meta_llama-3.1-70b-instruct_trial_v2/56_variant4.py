def correct_bracketing(brackets: str):
    def recursive_check(brackets, index, opening_count):
        if index == len(brackets):
            return opening_count == 0
        if brackets[index] == "<":
            return recursive_check(brackets, index + 1, opening_count + 1)
        elif brackets[index] == ">":
            if opening_count == 0:
                return False
            return recursive_check(brackets, index + 1, opening_count - 1)
    return recursive_check(brackets, 0, 0)