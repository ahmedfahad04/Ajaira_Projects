def monotonic(l: list):
    direction = None
    for i in range(len(l) - 1):
        if l[i] != l[i + 1]:
            new_direction = l[i + 1] > l[i]
            if direction is not None and new_direction != direction:
                return False
            direction = new_direction
    return True