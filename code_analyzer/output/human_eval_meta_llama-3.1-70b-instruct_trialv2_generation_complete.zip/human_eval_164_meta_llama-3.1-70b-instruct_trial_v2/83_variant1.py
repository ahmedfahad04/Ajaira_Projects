def starts_one_ends(n):
    if n == 1:
        return 1
    count = 2 * (9 * 10 ** (n - 2) + 1) - 9 * 10 ** (n - 2)
    return count