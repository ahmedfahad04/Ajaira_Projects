def count_distinct_characters(string: str) -> int:
    distinct_chars = set()
    for char in string.lower():
        distinct_chars.add(char)
    return len(distinct_chars)