def make_a_pile(n):
    result = [n]
    for _ in range(n - 1):
        if result[-1] % 2 == 0:
            result.append(result[-1] + 2)
        else:
            result.append(result[-1] + 2)
    return result