def digitSum(s):
    return sum(map(lambda c: ord(c), filter(lambda c: c.isupper(), s)))