def make_a_pile(n):
    def helper(n, level, result):
        if level == n:
            return result
        if n % 2 == 0:
            result.append(n + 2 * level)
        else:
            result.append(n + 2 * level)
        return helper(n, level + 1, result)

    return helper(n, 0, [n])