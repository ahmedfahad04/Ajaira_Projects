def incr_list(l: list):
    return list(map(lambda x: x + 1, l))