def is_bored(S):
    boredom_count = 0
    current_sentence = ''
    for char in S:
        if char in ['.', '?', '!']:
            if current_sentence.strip().startswith('I'):
                boredom_count += 1
            current_sentence = ''
        else:
            current_sentence += char
    if current_sentence.strip().startswith('I'):
        boredom_count += 1
    return boredom_count