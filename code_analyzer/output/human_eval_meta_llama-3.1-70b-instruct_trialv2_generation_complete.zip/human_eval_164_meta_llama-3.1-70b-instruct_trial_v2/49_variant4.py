def modp(n: int, p: int) -> int:
    def helper(x, y):
        if y == 0:
            return 1
        if y == 1:
            return x
        a = helper(x, y // 2)
        if y % 2 == 0:
            return (a * a) % p
        else:
            return ((a * a) % p * x) % p
    return helper(2, n)