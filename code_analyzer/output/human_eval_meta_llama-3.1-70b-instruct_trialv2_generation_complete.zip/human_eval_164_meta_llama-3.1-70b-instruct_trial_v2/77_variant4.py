import math

def iscube(a):
    root = math.pow(abs(a), 1/3)
    return root == int(root)