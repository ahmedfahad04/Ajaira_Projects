def all_prefixes(string: str) -> List[str]:
    return list(accumulate(string, lambda x, y: x + y))