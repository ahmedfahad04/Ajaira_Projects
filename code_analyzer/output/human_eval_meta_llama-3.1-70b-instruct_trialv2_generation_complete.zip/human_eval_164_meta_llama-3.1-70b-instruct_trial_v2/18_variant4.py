def how_many_times(string: str, substring: str) -> int:
    return sum(1 for i in range(len(string)) if string[i:].startswith(substring))