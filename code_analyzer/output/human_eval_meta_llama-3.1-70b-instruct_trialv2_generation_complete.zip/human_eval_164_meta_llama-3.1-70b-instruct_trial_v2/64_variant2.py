def vowels_count(s):
    s = s.lower()
    vowels = 'aeiou'
    count = 0
    for char in s:
        if char in vowels:
            count += 1
    if s[-1] == 'y':
        count += 1
    return count