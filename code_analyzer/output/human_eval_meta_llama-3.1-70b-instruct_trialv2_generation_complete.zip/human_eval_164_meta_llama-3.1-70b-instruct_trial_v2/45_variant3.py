def triangle_area(a, h):
    area = a * h
    return area / 2