def unique_digits(x):
    def is_all_odd(n):
        while n > 0:
            if n % 10 % 2 == 0:
                return False
            n //= 10
        return True
    
    return sorted([n for n in x if is_all_odd(n)])