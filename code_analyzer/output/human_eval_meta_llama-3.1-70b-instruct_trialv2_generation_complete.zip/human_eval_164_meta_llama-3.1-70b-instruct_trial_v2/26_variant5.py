from typing import List

def remove_duplicates(numbers: List[int]) -> List[int]:
    result = []
    for num in set(numbers):
        if numbers.count(num) == 1:
            result.append(next(x for x in numbers if x == num))
    return result