def unique(l: list):
    if not l:
        return []
    l.sort()
    result = [l[0]]
    for i in range(1, len(l)):
        if l[i] != l[i-1]:
            result.append(l[i])
    return result