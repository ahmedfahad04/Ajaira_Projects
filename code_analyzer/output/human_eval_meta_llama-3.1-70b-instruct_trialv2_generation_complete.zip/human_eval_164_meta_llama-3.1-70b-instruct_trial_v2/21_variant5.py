import numpy as np
def rescale_to_unit(numbers: List[float]) -> List[float]:
    numbers = np.array(numbers)
    return (numbers - np.min(numbers)) / (np.max(numbers) - np.min(numbers))