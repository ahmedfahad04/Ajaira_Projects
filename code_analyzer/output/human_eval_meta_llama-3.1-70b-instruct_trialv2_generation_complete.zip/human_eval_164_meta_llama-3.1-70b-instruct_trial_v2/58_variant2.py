def common(l1: list, l2: list):
    return sorted([element for element in set(l1) if element in set(l2)])