def filter_by_prefix(strings, prefix):
    return [string for string in strings if string[:len(prefix)] == prefix]