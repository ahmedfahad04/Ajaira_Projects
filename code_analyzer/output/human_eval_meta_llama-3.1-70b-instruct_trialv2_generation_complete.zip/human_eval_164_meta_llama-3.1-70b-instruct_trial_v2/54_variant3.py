def same_chars(s0: str, s1: str) -> bool:
    s0_count = {}
    s1_count = {}
    
    for char in s0:
        if char in s0_count:
            s0_count[char] += 1
        else:
            s0_count[char] = 1
            
    for char in s1:
        if char in s1_count:
            s1_count[char] += 1
        else:
            s1_count[char] = 1
            
    return s0_count == s1_count