def hex_key(num):
    def is_prime(digit):
        if digit.isdigit():
            digit = int(digit)
            if digit < 2:
                return False
            for i in range(2, int(digit**0.5) + 1):
                if digit % i == 0:
                    return False
            return True
        else:
            return digit in 'BD'

    return sum(1 for digit in num if is_prime(digit))