def derivative(xs: list):
    if len(xs) == 1:
        return []
    return [xs[i] * i for i in range(1, len(xs))]