import math
def closest_integer(value):
    num = float(value)
    return math.copysign(math.floor(abs(num) + 0.5), num)