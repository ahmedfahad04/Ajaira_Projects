def sort_array(array):
    arr = array[:]
    if len(arr) <= 1:
        return arr
    if (arr[0] + arr[-1]) % 2 == 0:
        arr.sort(reverse=True)
    else:
        arr.sort()
    return arr