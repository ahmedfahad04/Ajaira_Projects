def count_distinct_characters(string: str) -> int:
    distinct_chars = {}
    for char in string.lower():
        distinct_chars[char] = True
    return len(distinct_chars)