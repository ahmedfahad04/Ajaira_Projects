def fruit_distribution(s,n):
    import re
    numbers = re.findall('\d+', s)
    return n - sum(map(int, numbers))