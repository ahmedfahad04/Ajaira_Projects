def intersperse(numbers, delimeter):
    return [val for pair in zip(numbers, [delimeter] * len(numbers)) for val in pair][:-1] if numbers else []