def starts_one_ends(n):
    if n == 1:
        return 1
    starts_with_one = 9 * 10 ** (n - 2) + 1
    ends_with_one = 9 * 10 ** (n - 2) + 1
    both = 8 * 10 ** (n - 2)
    return starts_with_one + ends_with_one - both