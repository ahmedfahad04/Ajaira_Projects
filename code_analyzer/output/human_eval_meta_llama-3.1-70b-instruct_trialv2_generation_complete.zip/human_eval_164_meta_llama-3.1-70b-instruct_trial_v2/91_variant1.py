import re

def is_bored(S):
    return sum(1 for sentence in re.split('[.!?]', S) if sentence.strip().startswith('I'))