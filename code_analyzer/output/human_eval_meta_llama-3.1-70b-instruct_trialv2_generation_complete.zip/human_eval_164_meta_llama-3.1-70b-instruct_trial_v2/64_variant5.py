def vowels_count(s):
    s = s.lower()
    vowels = 'aeiouy'
    count = 0
    for char in s:
        if char in vowels:
            count += 1
    if s[-1] != 'y':
        count -= s.count('y')
    return count