def pairs_sum_to_zero(l):
    from itertools import combinations
    for pair in combinations(l, 2):
        if sum(pair) == 0:
            return True
    return False