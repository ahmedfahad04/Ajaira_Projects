def poly(xs: list, x: float):
    result = 0
    for i, coeff in enumerate(reversed(xs)):
        result = result * x + coeff
    return result