def encrypt(s):
    result = ""
    for char in s:
        if char.isalpha():
            shift = 4
            if char.isupper():
                result += chr((ord('A') + (ord(char) - ord('A') + shift)) % 26)
            else:
                result += chr((ord('a') + (ord(char) - ord('a') + shift)) % 26)
        else:
            result += char
    return result