def fib4(n: int):
    if n <= 1:
        return 0
    elif n == 2:
        return 2
    elif n == 3:
        return 0
    
    fib_dict = {0: 0, 1: 0, 2: 2, 3: 0}
    for i in range(4, n + 1):
        fib_dict[i] = sum([fib_dict.get(i - j, 0) for j in range(1, 5)])
    return fib_dict[n]