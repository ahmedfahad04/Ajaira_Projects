def any_int(x, y, z):
    def is_sum_of_others(num, other1, other2):
        return num == other1 + other2
    if not all(i.is_integer() for i in [x, y, z]):
        return False
    return is_sum_of_others(x, y, z) or is_sum_of_others(y, x, z) or is_sum_of_others(z, x, y)