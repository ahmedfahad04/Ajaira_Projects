def digitSum(s):
    return sum(ord(char) for char in filter(str.isupper, s))