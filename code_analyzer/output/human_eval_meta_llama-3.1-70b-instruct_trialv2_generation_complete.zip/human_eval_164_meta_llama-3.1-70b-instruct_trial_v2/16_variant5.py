def count_distinct_characters(string: str) -> int:
    return len(dict.fromkeys(string.lower()))