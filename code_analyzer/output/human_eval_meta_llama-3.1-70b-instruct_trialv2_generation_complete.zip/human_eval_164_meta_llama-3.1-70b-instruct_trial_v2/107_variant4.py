def even_odd_palindrome(n):
    def is_palindrome(num):
        return str(num) == str(num)[::-1]
    
    counts = [0, 0]
    for i in range(1, n+1):
        if is_palindrome(i):
            counts[i % 2] += 1
    return tuple(counts)