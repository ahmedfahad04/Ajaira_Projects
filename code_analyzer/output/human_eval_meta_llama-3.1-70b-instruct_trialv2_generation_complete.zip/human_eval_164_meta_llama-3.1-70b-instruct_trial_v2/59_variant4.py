def largest_prime_factor(n: int):
    def prime_factors(num: int):
        i = 2
        factors = []
        while i * i <= num:
            if num % i:
                i += 1
            else:
                num //= i
                factors.append(i)
        if num > 1:
            factors.append(num)
        return factors

    return max(prime_factors(n))