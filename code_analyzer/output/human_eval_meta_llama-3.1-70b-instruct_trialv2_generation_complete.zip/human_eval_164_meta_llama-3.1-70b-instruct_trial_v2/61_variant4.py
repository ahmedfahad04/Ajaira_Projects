def correct_bracketing(brackets: str):
    opening_brackets = brackets.count("(")
    closing_brackets = brackets.count(")")
    if opening_brackets != closing_brackets:
        return False
    balance = 0
    for bracket in brackets:
        if bracket == "(":
            balance += 1
        elif bracket == ")":
            balance -= 1
        if balance < 0:
            return False
    return True