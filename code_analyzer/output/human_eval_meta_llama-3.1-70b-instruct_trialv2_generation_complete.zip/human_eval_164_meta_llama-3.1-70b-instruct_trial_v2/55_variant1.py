def fib(n: int):
    if n <= 0:
        return "Input should be a positive integer"
    elif n == 1:
        return 1
    elif n == 2:
        return 1
    else:
        fib_sequence = [1, 1]
        while len(fib_sequence) < n:
            fib_sequence.append(fib_sequence[-1] + fib_sequence[-2])
        return fib_sequence[-1]