def vowels_count(s):
    s = s.lower()
    if s[-1] == 'y':
        return sum(1 for char in s[:-1] if char in 'aeiou') + 1
    else:
        return sum(1 for char in s if char in 'aeiou')