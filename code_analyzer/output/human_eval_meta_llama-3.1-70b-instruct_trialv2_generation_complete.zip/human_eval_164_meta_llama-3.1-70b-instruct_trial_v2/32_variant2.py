def poly(xs: list, x: float):
    result = 0
    power = 1
    for coeff in xs:
        result += coeff * power
        power *= x
    return result