def numerical_letter_grade(grades):
    def get_grade(grade):
        thresholds = [4.0, 3.7, 3.3, 3.0, 2.7, 2.3, 2.0, 1.7, 1.3, 1.0, 0.7, 0.0]
        grades = ['A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'D-']
        for i, threshold in enumerate(thresholds):
            if grade >= threshold:
                return grades[i]
        return 'E'

    return [get_grade(grade) for grade in grades]