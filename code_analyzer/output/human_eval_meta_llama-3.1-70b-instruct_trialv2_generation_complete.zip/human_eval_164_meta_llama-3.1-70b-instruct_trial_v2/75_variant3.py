def is_multiply_prime(a):
    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                return False
        return True

    primes = [i for i in range(2, a) if is_prime(i)]
    def check(n, count):
        if count == 3:
            return n == 1
        for i in primes:
            if n % i == 0:
                if check(n // i, count + 1):
                    return True
        return False
    return check(a, 0)