def sort_third(l: list):
    return [x if i % 3 != 0 else y for i, (x, y) in enumerate(zip(l, sorted([x for i, x in enumerate(l) if i % 3 == 0])))]