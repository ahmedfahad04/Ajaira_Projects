def triangle_area(a, b, c):
    sides = [a, b, c]
    sides.sort()
    if sides[0] + sides[1] <= sides[2]:
        return -1
    else:
        s = sum(sides) / 2
        area = (s * (s - a) * (s - b) * (s - c)) ** 0.5
        return round(area, 2)