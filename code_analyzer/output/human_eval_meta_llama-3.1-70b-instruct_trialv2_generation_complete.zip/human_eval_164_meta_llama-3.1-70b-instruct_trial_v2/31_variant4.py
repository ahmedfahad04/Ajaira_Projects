def is_prime(n):
    if n <= 1:
        return False
    def check_prime(d):
        if d * d > n:
            return True
        if n % d == 0:
            return False
        return check_prime(d + 1)
    return check_prime(2)