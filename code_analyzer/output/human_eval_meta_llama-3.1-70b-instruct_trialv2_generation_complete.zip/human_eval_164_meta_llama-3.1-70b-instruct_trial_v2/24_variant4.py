def largest_divisor(n: int) -> int:
    divisor = 1
    for i in range(2, n):
        if n % i == 0 and i > divisor:
            divisor = i
    return divisor