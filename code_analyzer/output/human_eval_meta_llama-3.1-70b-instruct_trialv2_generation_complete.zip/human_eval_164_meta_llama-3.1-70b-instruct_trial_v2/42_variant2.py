def incr_list(l: list):
    result = []
    for x in l:
        result.append(x + 1)
    return result