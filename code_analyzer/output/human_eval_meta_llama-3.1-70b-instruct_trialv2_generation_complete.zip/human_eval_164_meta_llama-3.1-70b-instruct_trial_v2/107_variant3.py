def even_odd_palindrome(n):
    counts = [0, 0]
    for i in range(1, n+1):
        if str(i) == str(i)[::-1]:
            counts[i % 2] += 1
    return tuple(counts)