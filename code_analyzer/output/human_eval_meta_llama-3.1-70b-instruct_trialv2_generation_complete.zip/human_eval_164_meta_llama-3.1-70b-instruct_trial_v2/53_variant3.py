def add(x: int, y: int) -> int:
    return sum([x, y])