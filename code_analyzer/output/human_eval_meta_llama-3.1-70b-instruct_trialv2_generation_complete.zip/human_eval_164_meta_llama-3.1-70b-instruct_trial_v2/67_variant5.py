def fruit_distribution(s,n):
    numbers = ''
    num_list = []
    for char in s:
        if char.isdigit():
            numbers += char
        elif numbers != '':
            num_list.append(int(numbers))
            numbers = ''
    if numbers != '':
        num_list.append(int(numbers))
    return n - sum(num_list)