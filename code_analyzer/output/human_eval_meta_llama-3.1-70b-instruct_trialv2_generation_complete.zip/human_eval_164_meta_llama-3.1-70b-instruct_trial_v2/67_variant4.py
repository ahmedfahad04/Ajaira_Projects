def fruit_distribution(s,n):
    import re
    numbers = [int(i) for i in re.split(' apples| oranges| and', s) if i.isdigit()]
    return n - sum(numbers)