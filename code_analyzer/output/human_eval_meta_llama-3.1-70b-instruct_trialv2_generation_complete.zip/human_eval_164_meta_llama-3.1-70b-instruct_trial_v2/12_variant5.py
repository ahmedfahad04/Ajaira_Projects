def longest(strings: List[str]) -> Optional[str]:
    if not strings:
        return None
    return strings[max(range(len(strings)), key=lambda i: len(strings[i]))]