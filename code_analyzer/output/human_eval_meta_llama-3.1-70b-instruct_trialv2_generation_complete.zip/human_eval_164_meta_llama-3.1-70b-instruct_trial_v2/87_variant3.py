def get_row(lst, x):
    def find_coords(row, x):
        return [(j) for j, val in enumerate(row) if val == x]
    
    result = []
    for i, row in enumerate(lst):
        coords = find_coords(row, x)
        result.extend([(i, coord) for coord in coords])
    return sorted(result, key=lambda x: (x[0], -x[1]))