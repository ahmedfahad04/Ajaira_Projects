def next_smallest(lst):
    if len(lst) < 2:
        return None
    seen = set()
    min_val = float('inf')
    second_min = float('inf')
    for num in lst:
        if num not in seen:
            seen.add(num)
            if num < min_val:
                second_min = min_val
                min_val = num
            elif num < second_min and num != min_val:
                second_min = num
    return second_min if second_min != float('inf') else None