def count_nums(arr):
    def has_positive_digit_sum(num):
        return sum(int(digit) for digit in str(abs(num))) > 0
    
    return sum(map(has_positive_digit_sum, arr))