def encode_cyclic(s: str):
    from itertools import zip_longest
    groups = list(zip_longest(*[s[i:] for i in range(3)], fillvalue=''))
    return "".join("".join(group[1:] + group[:1]) if len("".join(group)) == 3 else "".join(group) for group in groups)