def correct_bracketing(brackets: str):
    def recursive_check(opening, closing, brackets):
        if not brackets:
            return opening == closing
        if opening < closing:
            return False
        if brackets[0] == "(":
            return recursive_check(opening + 1, closing, brackets[1:])
        else:
            return recursive_check(opening, closing + 1, brackets[1:])
    return recursive_check(0, 0, brackets)