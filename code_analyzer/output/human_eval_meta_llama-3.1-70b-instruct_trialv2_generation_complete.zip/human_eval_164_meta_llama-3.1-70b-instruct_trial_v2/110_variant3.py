def exchange(lst1, lst2):
    lst2 = sorted(lst2, key=lambda x: x % 2, reverse=True)
    lst1 = sorted(lst1, key=lambda x: x % 2)
    
    for i in range(len(lst1)):
        if lst1[i] % 2 != 0 and lst2 and lst2[0] % 2 == 0:
            lst1[i], lst2[0] = lst2[0], lst1[i]
            lst2.pop(0)
    
    if any(num % 2 != 0 for num in lst1):
        return "NO"
    else:
        return "YES"