def intersperse(numbers, delimeter):
    return [x for x in numbers for x in ([x, delimeter], [x])][::2]