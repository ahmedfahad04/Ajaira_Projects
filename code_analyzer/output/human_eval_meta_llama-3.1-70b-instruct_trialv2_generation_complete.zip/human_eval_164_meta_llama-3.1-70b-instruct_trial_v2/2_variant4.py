def truncate_number(number: float) -> float:
    str_num = str(number)
    dot_index = str_num.find('.')
    if dot_index != -1:
        return float('0' + str_num[dot_index:])
    else:
        return 0.0