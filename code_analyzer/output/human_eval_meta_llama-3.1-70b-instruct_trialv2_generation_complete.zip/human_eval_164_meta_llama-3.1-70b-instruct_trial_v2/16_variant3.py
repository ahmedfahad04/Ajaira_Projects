def count_distinct_characters(string: str) -> int:
    return len({char for char in string.lower()})