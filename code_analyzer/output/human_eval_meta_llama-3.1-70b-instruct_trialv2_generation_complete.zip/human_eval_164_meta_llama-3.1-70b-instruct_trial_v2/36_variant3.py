def fizz_buzz(n: int):
    count = 0
    multiples = [i for i in range(1, n) if i % 11 == 0 or i % 13 == 0]
    for multiple in multiples:
        count += str(multiple).count('7')
    return count