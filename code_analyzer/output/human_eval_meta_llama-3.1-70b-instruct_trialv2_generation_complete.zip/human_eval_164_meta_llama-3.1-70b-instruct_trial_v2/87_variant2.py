def get_row(lst, x):
    result = [(i, j) for i, row in enumerate(lst) for j, val in enumerate(row) if val == x]
    return sorted(result, key=lambda x: (x[0], -x[1]))