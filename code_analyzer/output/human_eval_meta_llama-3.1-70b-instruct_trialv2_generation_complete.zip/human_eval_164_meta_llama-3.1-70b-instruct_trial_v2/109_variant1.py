def move_one_ball(arr):
    if len(arr) == 0:
        return True
    min_val = min(arr)
    min_index = arr.index(min_val)
    return arr[min_index:] + arr[:min_index] == sorted(arr)