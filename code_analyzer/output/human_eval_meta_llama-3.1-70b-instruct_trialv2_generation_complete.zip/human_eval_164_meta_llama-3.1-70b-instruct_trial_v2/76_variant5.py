import math

def is_simple_power(x, n):
    if x < 1 or n < 2:
        return x == 1
    exp = math.log(x, n)
    return math.isclose(exp, round(exp))