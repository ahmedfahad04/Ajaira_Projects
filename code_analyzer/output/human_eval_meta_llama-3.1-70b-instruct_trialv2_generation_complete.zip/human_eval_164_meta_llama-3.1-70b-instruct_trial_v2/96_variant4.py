def count_up_to(n):
    primes = []
    for possiblePrime in range(2, n):
        if all(possiblePrime % num != 0 for num in range(2, int(possiblePrime ** 0.5) + 1)):
            primes.append(possiblePrime)
    return primes