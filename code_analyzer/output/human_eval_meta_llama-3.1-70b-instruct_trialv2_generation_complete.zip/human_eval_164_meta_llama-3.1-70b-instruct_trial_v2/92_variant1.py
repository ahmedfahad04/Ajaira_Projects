def any_int(x, y, z):
    return (x + y == z or x + z == y or y + z == x) and x.is_integer() and y.is_integer() and z.is_integer()