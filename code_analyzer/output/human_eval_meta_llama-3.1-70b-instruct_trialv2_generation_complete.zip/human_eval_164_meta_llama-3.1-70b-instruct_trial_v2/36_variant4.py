def fizz_buzz(n: int):
    count = 0
    i = 1
    while i < n:
        if i % 11 == 0 or i % 13 == 0:
            count += str(i).count('7')
        i += 1
    return count