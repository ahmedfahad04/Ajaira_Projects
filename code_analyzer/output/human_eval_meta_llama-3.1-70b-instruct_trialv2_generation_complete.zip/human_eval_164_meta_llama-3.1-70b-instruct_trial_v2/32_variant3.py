import numpy as np
def poly(xs: list, x: float):
    return np.polyval(xs[::-1], x)