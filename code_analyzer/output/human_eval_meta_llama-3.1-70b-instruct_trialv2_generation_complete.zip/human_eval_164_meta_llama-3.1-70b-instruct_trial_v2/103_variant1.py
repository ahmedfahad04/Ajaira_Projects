def rounded_avg(n, m):
    if n > m:
        return -1
    total = sum(range(n, m + 1))
    return bin(round(total / (m - n + 1)))