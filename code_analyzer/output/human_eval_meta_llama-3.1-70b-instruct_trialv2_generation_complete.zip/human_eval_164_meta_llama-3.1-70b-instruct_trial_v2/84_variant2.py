def solve(N):
    binary = bin(N)[2:]
    return bin(sum(map(int, binary)))[2:]