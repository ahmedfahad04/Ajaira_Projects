def make_a_pile(n):
    return [n + 2 * i if n % 2 == 0 else n + 2 * i for i in range(n)]