def truncate_number(number: float) -> float:
    from math import floor
    return number - floor(number)