def words_string(s):
    words = []
    word = ''
    for char in s:
        if char in [',', ' ']:
            if word:
                words.append(word)
                word = ''
        else:
            word += char
    if word:
        words.append(word)
    return words