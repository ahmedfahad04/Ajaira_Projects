def get_row(lst, x):
    result = []
    for i, row in enumerate(lst):
        j = len(row) - 1
        while j >= 0:
            if row[j] == x:
                result.append((i, j))
            j -= 1
    result.sort(key=lambda x: (x[0], -x[1]))
    return result