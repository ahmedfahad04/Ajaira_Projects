def words_string(s):
    import re
    return re.findall(r'\w+', s)