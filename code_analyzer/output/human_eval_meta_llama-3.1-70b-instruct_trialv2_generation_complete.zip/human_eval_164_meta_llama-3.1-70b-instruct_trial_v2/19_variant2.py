def sort_numbers(numbers: str) -> str:
    num_map = {'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9}
    nums = numbers.split()
    for i in range(len(nums)):
        for j in range(i+1, len(nums)):
            if num_map[nums[i]] > num_map[nums[j]]:
                nums[i], nums[j] = nums[j], nums[i]
    return ' '.join(nums)