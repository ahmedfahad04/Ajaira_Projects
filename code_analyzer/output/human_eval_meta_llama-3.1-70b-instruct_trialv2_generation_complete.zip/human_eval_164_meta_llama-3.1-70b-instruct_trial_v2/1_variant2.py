def separate_paren_groups(paren_string: str) -> List[str]:
    paren_string = paren_string.replace(' ', '')
    result = []
    stack = []
    current_group = ''
    for char in paren_string:
        current_group += char
        if char == '(':
            stack.append(char)
        else:
            stack.pop()
        if not stack:
            result.append(current_group)
            current_group = ''
    return result