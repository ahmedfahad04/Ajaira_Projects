def change_base(x: int, base: int) -> str:
    result = ''
    negative = False
    if x < 0:
        x = -x
        negative = True
    while x > 0:
        x, remainder = divmod(x, base)
        result = str(remainder) + result
    if negative:
        result = '-' + result
    return result if result else '0'