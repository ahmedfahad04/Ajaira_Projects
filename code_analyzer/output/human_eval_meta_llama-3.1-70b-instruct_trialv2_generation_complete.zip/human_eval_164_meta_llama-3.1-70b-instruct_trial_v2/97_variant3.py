def multiply(a, b):
    a_str = str(abs(a))
    b_str = str(abs(b))
    return int(a_str[-1]) * int(b_str[-1])