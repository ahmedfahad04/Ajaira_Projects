def sort_third(l: list):
    third_idx = [i for i in range(len(l)) if i % 3 == 0]
    third_vals = [l[i] for i in third_idx]
    third_vals.sort()
    result = []
    j = 0
    for i in range(len(l)):
        if i % 3 == 0:
            result.append(third_vals[j])
            j += 1
        else:
            result.append(l[i])
    return result