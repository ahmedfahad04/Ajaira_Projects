from typing import List

def mean_absolute_deviation(numbers: List[float]) -> float:
    n = len(numbers)
    mean = sum(numbers) / n
    return sum(abs(num - mean) for num in numbers) / n