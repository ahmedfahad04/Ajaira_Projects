def smallest_change(arr):
    mid = len(arr) // 2
    first_half = arr[:mid]
    second_half = arr[mid:][::-1]
    return sum(a != b for a, b in zip(first_half, second_half))