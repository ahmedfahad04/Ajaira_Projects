def add(x: int, y: int) -> int:
    def recursive_add(a, b):
        if b == 0:
            return a
        return recursive_add(a ^ b, (a & b) << 1)
    return recursive_add(x, y)