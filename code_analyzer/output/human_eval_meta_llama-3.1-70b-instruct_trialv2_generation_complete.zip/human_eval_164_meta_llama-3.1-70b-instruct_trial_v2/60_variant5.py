def sum_to_n(n: int):
    i = 1
    total = 0
    while i <= n:
        total += i
        i += 1
    return total