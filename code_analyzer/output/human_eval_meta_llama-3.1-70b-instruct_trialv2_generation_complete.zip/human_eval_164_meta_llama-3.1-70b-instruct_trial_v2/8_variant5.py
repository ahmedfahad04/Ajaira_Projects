def sum_product(numbers: List[int]) -> Tuple[int, int]:
    if not numbers:
        return 0, 1
    total_sum = numbers[0]
    product = numbers[0]
    for num in numbers[1:]:
        total_sum += num
        product *= num
    return total_sum, product