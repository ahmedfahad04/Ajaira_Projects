def unique(l: list):
    seen = []
    for num in l:
        if num not in seen:
            seen.append(num)
    return sorted(seen)