def flip_case(string: str) -> str:
    result = []
    for i in range(len(string)):
        char = string[i]
        if char.islower():
            result.append(char.upper())
        else:
            result.append(char.lower())
    return ''.join(result)