def pluck(arr):
    min_even = None
    min_idx = -1
    for idx, val in enumerate(arr):
        if val % 2 == 0 and (min_even is None or val < min_even):
            min_even = val
            min_idx = idx
    return [min_even, min_idx] if min_idx != -1 else []