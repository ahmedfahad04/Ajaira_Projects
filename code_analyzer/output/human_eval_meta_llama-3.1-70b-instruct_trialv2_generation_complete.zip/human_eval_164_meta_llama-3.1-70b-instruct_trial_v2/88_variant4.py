def sort_array(array):
    arr = array[:]
    if len(arr) <= 1:
        return arr
    if (arr[0] + arr[-1]) % 2 == 0:
        for i in range(len(arr)):
            for j in range(i+1, len(arr)):
                if arr[i] < arr[j]:
                    arr[i], arr[j] = arr[j], arr[i]
    else:
        for i in range(len(arr)):
            for j in range(i+1, len(arr)):
                if arr[i] > arr[j]:
                    arr[i], arr[j] = arr[j], arr[i]
    return arr