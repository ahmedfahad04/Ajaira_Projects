from typing import List

def below_zero(operations: List[int]) -> bool:
    for i in range(1, len(operations)):
        operations[i] += operations[i-1]
        if operations[i] < 0:
            return True
    return False