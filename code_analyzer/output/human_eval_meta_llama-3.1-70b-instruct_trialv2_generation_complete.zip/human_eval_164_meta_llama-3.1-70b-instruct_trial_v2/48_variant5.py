def is_palindrome(text: str):
    from collections import deque
    d = deque(text)
    while len(d) > 1:
        if d.popleft() != d.pop():
            return False
    return True