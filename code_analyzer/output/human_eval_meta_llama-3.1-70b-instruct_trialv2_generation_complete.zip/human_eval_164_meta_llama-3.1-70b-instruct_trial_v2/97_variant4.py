def multiply(a, b):
    def get_unit_digit(n):
        return n % 10
    return get_unit_digit(a) * get_unit_digit(b)