def check_dict_case(dict):
    if not dict:
        return False
    keys = list(dict.keys())
    if all(isinstance(key, str) for key in keys):
        case = None
        for key in keys:
            if case is None:
                case = key.islower()
            elif case != key.islower():
                return False
        return True
    return False