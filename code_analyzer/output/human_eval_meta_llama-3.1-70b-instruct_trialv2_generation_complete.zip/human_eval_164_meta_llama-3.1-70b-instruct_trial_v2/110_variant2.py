def exchange(lst1, lst2):
    lst2_even = sum(1 for num in lst2 if num % 2 == 0)
    lst1_odd = sum(1 for num in lst1 if num % 2 != 0)
    
    if lst1_odd <= lst2_even:
        return "YES"
    else:
        return "NO"