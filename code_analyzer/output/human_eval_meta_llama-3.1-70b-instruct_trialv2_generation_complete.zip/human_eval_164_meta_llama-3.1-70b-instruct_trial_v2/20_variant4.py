def find_closest_elements(numbers: List[float]) -> Tuple[float, float]:
    from itertools import combinations
    return min(combinations(numbers, 2), key=lambda x: abs(x[0] - x[1]))