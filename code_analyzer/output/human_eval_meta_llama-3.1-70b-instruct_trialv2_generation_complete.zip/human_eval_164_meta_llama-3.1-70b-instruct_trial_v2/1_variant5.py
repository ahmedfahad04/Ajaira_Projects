def separate_paren_groups(paren_string: str) -> List[str]:
    paren_string = paren_string.replace(' ', '')
    result = []
    groups = paren_string.split(')(')
    for group in groups:
        if group:
            result.append('(' + group + ')')
    return result