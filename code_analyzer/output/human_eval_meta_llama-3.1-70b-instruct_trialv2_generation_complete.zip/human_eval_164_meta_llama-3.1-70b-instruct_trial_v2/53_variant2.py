def add(x: int, y: int) -> int:
    result = 0
    for _ in range(abs(y)):
        if y < 0:
            result -= 1
        else:
            result += 1
    return x + result