def filter_by_substring(strings, substring):
    def recursive_filter(strings, substring, result=None):
        if result is None:
            result = []
        if not strings:
            return result
        if substring in strings[0]:
            result.append(strings[0])
        return recursive_filter(strings[1:], substring, result)
    return recursive_filter(strings, substring)