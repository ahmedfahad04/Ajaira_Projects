def decimal_to_binary(decimal):
    binary = ''
    while decimal > 0:
        binary = str(decimal & 1) + binary
        decimal >>= 1
    return 'db' + binary + 'db'