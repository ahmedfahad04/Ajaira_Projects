def is_bored(S):
    sentences = []
    temp = ''
    for char in S:
        if char in ['.', '?', '!']:
            sentences.append(temp.strip())
            temp = ''
        else:
            temp += char
    if temp:
        sentences.append(temp.strip())
    return sum(1 for sentence in sentences if sentence.startswith('I'))