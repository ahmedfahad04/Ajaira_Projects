def fibfib(n: int):
    def matrix_multiply(a, b):
        result = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
        for i in range(3):
            for j in range(3):
                for k in range(3):
                    result[i][j] += a[i][k] * b[k][j]
        return result

    def matrix_power(matrix, n):
        if n == 1:
            return matrix
        if n % 2 == 0:
            half_pow = matrix_power(matrix, n // 2)
            return matrix_multiply(half_pow, half_pow)
        else:
            half_pow = matrix_power(matrix, n // 2)
            return matrix_multiply(matrix_multiply(half_pow, half_pow), matrix)

    if n <= 1:
        return 0
    elif n == 2:
        return 1
    else:
        matrix = [[1, 1, 1], [1, 0, 0], [0, 1, 0]]
        result_matrix = matrix_power(matrix, n - 2)
        return result_matrix[0][0] + result_matrix[1][0]