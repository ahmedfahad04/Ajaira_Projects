def iscube(a):
    if a < 0:
        a = -a
    i = 1
    while i * i * i <= a:
        if i * i * i == a:
            return True
        i += 1
    return False