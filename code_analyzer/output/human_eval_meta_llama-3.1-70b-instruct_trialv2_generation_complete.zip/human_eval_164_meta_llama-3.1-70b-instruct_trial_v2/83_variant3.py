def starts_one_ends(n):
    if n == 1:
        return 1
    count = 0
    for i in range(10**(n-1), 10**n):
        str_i = str(i)
        if str_i[0] == '1':
            count += 1
        elif str_i[-1] == '1':
            count += 1
    return count