def filter_by_substring(strings, substring):
    return list(map(lambda string: string if substring in string else None, strings))