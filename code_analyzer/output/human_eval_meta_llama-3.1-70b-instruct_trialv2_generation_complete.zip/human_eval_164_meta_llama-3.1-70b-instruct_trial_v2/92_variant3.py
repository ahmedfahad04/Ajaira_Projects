def any_int(x, y, z):
    nums = [x, y, z]
    if not all(num.is_integer() for num in nums):
        return False
    for i in range(3):
        if nums[i] == sum(nums[:i] + nums[i+1:]):
            return True
    return False