from typing import List
import functools

def concatenate(strings: List[str]) -> str:
    return functools.reduce(lambda x, y: x + y, strings, '')