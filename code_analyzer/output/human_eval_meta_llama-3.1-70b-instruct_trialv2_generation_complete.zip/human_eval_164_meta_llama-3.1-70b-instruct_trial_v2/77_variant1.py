def iscube(a):
    i = 1
    while True:
        cube = i * i * i
        if cube == a:
            return True
        elif cube > a:
            return False
        i += 1