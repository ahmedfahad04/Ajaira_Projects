def sort_third(l: list):
    third_vals = sorted([x for i, x in enumerate(l) if i % 3 == 0])
    return [third_vals.pop(0) if i % 3 == 0 else x for i, x in enumerate(l)]