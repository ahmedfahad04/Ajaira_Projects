def truncate_number(number: float) -> float:
    integer_part = int(number)
    return number / (1 + integer_part) * (number - integer_part)