def correct_bracketing(brackets: str):
    diff = 0
    for bracket in brackets:
        if bracket == "(":
            diff += 1
        elif bracket == ")":
            diff -= 1
        if diff < 0:
            return False
    return diff == 0