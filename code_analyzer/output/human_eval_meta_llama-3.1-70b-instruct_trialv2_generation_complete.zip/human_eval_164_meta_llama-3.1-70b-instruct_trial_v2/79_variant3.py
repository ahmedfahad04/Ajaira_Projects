def decimal_to_binary(decimal):
    return 'db' + ''.join(format(decimal, 'b')) + 'db'