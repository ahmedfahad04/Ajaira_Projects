def has_close_elements(numbers, threshold):
    numbers_set = set()
    for num in numbers:
        for bound in (num - threshold, num + threshold):
            if any(abs(num - n) < threshold for n in numbers_set):
                return True
        numbers_set.add(num)
    return False