def filter_by_substring(strings, substring):
    def contains_substring(string):
        return substring in string
    return list(filter(contains_substring, strings))