def exchange(lst1, lst2):
    while any(num % 2 != 0 for num in lst1) and any(num % 2 == 0 for num in lst2):
        for i, num in enumerate(lst1):
            if num % 2 != 0:
                for j, num2 in enumerate(lst2):
                    if num2 % 2 == 0:
                        lst1[i], lst2[j] = lst2[j], lst1[i]
                        break
                break
    
    if any(num % 2 != 0 for num in lst1):
        return "NO"
    else:
        return "YES"