def same_chars(s0: str, s1: str) -> bool:
    if len(s0) != len(s1):
        return False
    
    char_count = {}
    
    for char in s0:
        if char in char_count:
            char_count[char] += 1
        else:
            char_count[char] = 1
            
    for char in s1:
        if char in char_count:
            char_count[char] -= 1
        else:
            return False
            
        if char_count[char] < 0:
            return False
            
    return True