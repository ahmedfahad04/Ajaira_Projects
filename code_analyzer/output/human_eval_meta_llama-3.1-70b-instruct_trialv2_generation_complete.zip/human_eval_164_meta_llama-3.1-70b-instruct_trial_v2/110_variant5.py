def exchange(lst1, lst2):
    from collections import deque
    q = deque([num for num in lst2 if num % 2 == 0])
    
    for i in range(len(lst1)):
        if lst1[i] % 2 != 0 and q:
            lst1[i] = q.popleft()
    
    if any(num % 2 != 0 for num in lst1):
        return "NO"
    else:
        return "YES"