import sympy
def prime_length(string):
    return sympy.isprime(len(string))