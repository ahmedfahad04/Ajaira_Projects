import math

def is_simple_power(x, n):
    if x < 1 or n < 2:
        return x == 1
    log_x = math.log(x)
    log_n = math.log(n)
    return math.isclose(log_x / log_n, round(log_x / log_n))