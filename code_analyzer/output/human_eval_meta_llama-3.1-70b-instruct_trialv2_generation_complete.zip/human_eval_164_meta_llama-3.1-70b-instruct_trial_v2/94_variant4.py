def skjkasdkd(lst):
    def sieve_of_eratosthenes(n):
        sieve = [True] * (n + 1)
        sieve[0:2] = [False, False]
        for current_prime in range(2, int(n**0.5) + 1):
            if sieve[current_prime]:
                for multiple in range(current_prime**2, n + 1, current_prime):
                    sieve[multiple] = False
        return sieve

    max_num = max(lst)
    sieve = sieve_of_eratosthenes(max_num)
    primes = [num for num in lst if sieve[num]]
    if not primes:
        return 0
    max_prime = max(primes)
    return sum(int(digit) for digit in str(max_prime))