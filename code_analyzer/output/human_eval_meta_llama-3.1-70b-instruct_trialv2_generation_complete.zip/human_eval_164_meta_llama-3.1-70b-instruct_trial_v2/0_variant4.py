import numpy as np

def has_close_elements(numbers, threshold):
    numbers = np.array(numbers)
    diff = np.abs(numbers[:, None] - numbers)
    np.fill_diagonal(diff, np.inf)
    return np.any(diff < threshold)