def check_dict_case(dict):
    if not dict:
        return False
    keys = list(dict.keys())
    if all(isinstance(key, str) for key in keys):
        first_key = next(iter(keys))
        return all(key.islower() == first_key.islower() for key in keys)
    return False