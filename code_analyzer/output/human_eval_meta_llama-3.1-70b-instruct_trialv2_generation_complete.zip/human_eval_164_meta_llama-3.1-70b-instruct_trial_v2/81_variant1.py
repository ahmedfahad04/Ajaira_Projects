def numerical_letter_grade(grades):
    grade_dict = {
        'A+': (4.0, 3.7),
        'A': (3.7, 3.3),
        'A-': (3.3, 3.0),
        'B+': (3.0, 2.7),
        'B': (2.7, 2.3),
        'B-': (2.3, 2.0),
        'C+': (2.0, 1.7),
        'C': (1.7, 1.3),
        'C-': (1.3, 1.0),
        'D+': (1.0, 0.7),
        'D': (0.7, 0.0),
        'D-': (0.0, -1.0)
    }
    return [next(key for key, value in grade_dict.items() if value[0] >= grade > value[1]) for grade in grades]