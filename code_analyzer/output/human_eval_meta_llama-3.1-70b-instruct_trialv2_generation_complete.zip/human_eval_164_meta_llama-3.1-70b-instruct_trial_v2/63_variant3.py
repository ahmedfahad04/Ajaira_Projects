def fibfib(n: int):
    memo = {0: 0, 1: 0, 2: 1}
    def fibfib_helper(k):
        if k not in memo:
            memo[k] = fibfib_helper(k-1) + fibfib_helper(k-2) + fibfib_helper(k-3)
        return memo[k]
    return fibfib_helper(n)