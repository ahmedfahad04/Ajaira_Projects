def is_bored(S):
    count = 0
    for sentence in S.split('.'):
        for sub_sentence in sentence.split('?'):
            for sub_sub_sentence in sub_sentence.split('!'):
                if sub_sub_sentence.strip().startswith('I'):
                    count += 1
    return count