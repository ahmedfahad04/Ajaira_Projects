def largest_divisor(n: int) -> int:
    def recursive_divisor(n, i):
        if n % i == 0:
            return i
        else:
            return recursive_divisor(n, i - 1)
    return recursive_divisor(n, n - 1)