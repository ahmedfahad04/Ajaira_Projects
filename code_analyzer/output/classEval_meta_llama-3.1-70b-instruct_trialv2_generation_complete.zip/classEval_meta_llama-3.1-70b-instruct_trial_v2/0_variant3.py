import logging
import datetime

class AccessGatewayFilter:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.allowed_prefixes = ['/api', '/login']

    def filter(self, request):
        if not self.is_start_with(request['path']):
            return False
        user = self.get_jwt_user(request)
        if user:
            self.set_current_user_info_and_log(user)
            return True
        return False

    def is_start_with(self, request_uri):
        for prefix in self.allowed_prefixes:
            if request_uri.startswith(prefix):
                return True
        return False

    def get_jwt_user(self, request):
        try:
            token = request['headers']['Authorization']['jwt']
            user_data = token.split('.')
            return {'user': {'name': user_data[0]}}
        except (KeyError, IndexError):
            return None

    def set_current_user_info_and_log(self, user):
        self.logger.info(f'User {user["user"]["name"]} accessed')