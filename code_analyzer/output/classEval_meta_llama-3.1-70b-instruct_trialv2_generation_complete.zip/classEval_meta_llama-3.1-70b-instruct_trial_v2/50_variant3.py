import json
import os

class JSONProcessor:
    def read_json(self, file_path):
        if not os.path.exists(file_path):
            return 0
        try:
            with open(file_path, 'r') as f:
                return json.loads(f.read())
        except Exception as e:
            print(f"An error occurred: {e}")
            return -1

    def write_json(self, data, file_path):
        try:
            with open(file_path, 'w') as f:
                f.write(json.dumps(data))
            return 1
        except Exception as e:
            print(f"An error occurred: {e}")
            return -1

    def process_json(self, file_path, remove_key):
        if not os.path.exists(file_path):
            return 0
        data = self.read_json(file_path)
        if remove_key in data:
            data = {key: value for key, value in data.items() if key != remove_key}
            self.write_json(data, file_path)
            return 1
        else:
            return 0