import itertools
import math

class ArrangementCalculator:
    def __init__(self, datas):
        self.datas = datas

    @staticmethod
    def count(n, m=None):
        if m is None or n == m:
            return math.factorial(n)
        return math.factorial(n) // math.factorial(n - m)

    @staticmethod
    def count_all(n):
        return sum(math.factorial(n) // math.factorial(n - i) for i in range(1, n + 1))

    def select(self, m=None):
        if m is None:
            m = len(self.datas)
        return list(itertools.permutations(self.datas, m))

    def select_all(self):
        return [list(p) for r in range(1, len(self.datas) + 1) for p in itertools.permutations(self.datas, r)]

    @staticmethod
    def factorial(n):
        return math.factorial(n)