import math
from typing import List

class CombinationCalculator:
    def __init__(self, datas: List[str]):
        self.datas = datas

    @staticmethod
    def count(n: int, m: int) -> int:
        return math.factorial(n) // (math.factorial(m) * math.factorial(n - m))

    @staticmethod
    def count_all(n: int) -> int:
        result = 0
        for i in range(n + 1):
            result += math.comb(n, i)
        return result if result <= 2**63-1 else float("inf")

    def select(self, m: int) -> List[List[str]]:
        def backtrack(start, path):
            if len(path) == m:
                result.append(path[:])
                return
            for i in range(start, len(self.datas)):
                path.append(self.datas[i])
                backtrack(i + 1, path)
                path.pop()

        result = []
        backtrack(0, [])
        return result

    def select_all(self) -> List[List[str]]:
        result = []
        for i in range(len(self.datas) + 1):
            result.extend(self.select(i))
        return result