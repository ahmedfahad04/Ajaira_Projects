from datetime import datetime
import numpy as np

class MovieBookingSystem:
    def __init__(self):
        self.movies = []

    def add_movie(self, name, price, start_time, end_time, n):
        start_time = datetime.strptime(start_time, '%H:%M')
        start_time = start_time.replace(year=1900, month=1, day=1)
        end_time = datetime.strptime(end_time, '%H:%M')
        end_time = end_time.replace(year=1900, month=1, day=1)
        seats = np.zeros((n, n))
        self.movies.append({'name': name, 'price': price, 'start_time': start_time, 'end_time': end_time, 'seats': seats})

    def book_ticket(self, name, seats_to_book):
        for movie in self.movies:
            if movie['name'] == name:
                for seat in seats_to_book:
                    if seat[0] >= movie['seats'].shape[0] or seat[1] >= movie['seats'].shape[1]:
                        return 'Booking failed.'
                    if movie['seats'][seat[0], seat[1]] == 1:
                        return 'Booking failed.'
                for seat in seats_to_book:
                    movie['seats'][seat[0], seat[1]] = 1
                return 'Booking success.'
        return 'Movie not found.'

    def available_movies(self, start_time, end_time):
        start_time = datetime.strptime(start_time, '%H:%M')
        start_time = start_time.replace(year=1900, month=1, day=1)
        end_time = datetime.strptime(end_time, '%H:%M')
        end_time = end_time.replace(year=1900, month=1, day=1)
        available_movies = []
        for movie in self.movies:
            if start_time < movie['end_time'] and end_time > movie['start_time']:
                available_movies.append(movie['name'])
        return available_movies