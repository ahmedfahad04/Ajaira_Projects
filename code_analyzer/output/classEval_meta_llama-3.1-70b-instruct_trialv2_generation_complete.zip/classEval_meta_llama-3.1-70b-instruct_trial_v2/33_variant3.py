class DiscountStrategy:
    def __init__(self, customer, cart, promotion=None):
        self.customer = customer
        self.cart = cart
        self.promotion = promotion
        self.total_cost = self.total()

    def total(self):
        return sum(item['quantity'] * item['price'] for item in self.cart)

    def due(self):
        if self.promotion:
            discount = self.promotion(self)
            return self.total_cost - discount
        else:
            return self.total_cost

    @staticmethod
    def FidelityPromo(order):
        return order.total_cost * 0.05 if order.customer['fidelity'] > 1000 else 0

    @staticmethod
    def BulkItemPromo(order):
        discount = sum(item['price'] * item['quantity'] * 0.1 for item in order.cart if item['quantity'] >= 20)
        return discount

    @staticmethod
    def LargeOrderPromo(order):
        unique_products = len(set(item['product'] for item in order.cart))
        return order.total_cost * 0.07 if unique_products >= 10 else 0