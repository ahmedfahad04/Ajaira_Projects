from math import pi, fabs

class TriCalculator:
    def __init__(self):
        pass

    def cos(self, x):
        return self.taylor(x, 100)

    def factorial(self, a):
        if a == 0:
            return 1
        else:
            return a * self.factorial(a-1)

    def taylor(self, x, n):
        result = 0
        for i in range(n):
            result += ((-1)**i) * (self.factorial(2*i) / (2**(2*i) * (self.factorial(i)**2))) * (x / 180 * pi)**(2*i)
        return result

    def sin(self, x):
        return self.taylor_sin(x, 100)

    def tan(self, x):
        return self.sin(x) / self.cos(x)

    def taylor_sin(self, x, n):
        result = 0
        for i in range(n):
            result += ((-1)**i) * (self.factorial(2*i+1) / (2**(2*i) * (self.factorial(i)**2) * (2*i+1))) * (x / 180 * pi)**(2*i+1)
        return result