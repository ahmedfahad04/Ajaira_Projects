class LongestWord:
    def __init__(self):
        self.word_list = set()

    def add_word(self, word):
        self.word_list.add(word)

    def find_longest_word(self, sentence):
        translator = str.maketrans('', '', string.punctuation)
        sentence_no_punct = sentence.translate(translator)
        words = sentence_no_punct.split()
        filtered_words = [word for word in words if word in self.word_list]
        return max(filtered_words, key=len, default='')