import random

class MahjongConnect:
    def __init__(self, BOARD_SIZE, ICONS):
        self.BOARD_SIZE = BOARD_SIZE
        self.ICONS = ICONS
        self.board = self.create_board()

    def create_board(self):
        board = []
        for _ in range(self.BOARD_SIZE[0]):
            row = []
            for _ in range(self.BOARD_SIZE[1]):
                row.append(random.choice(self.ICONS))
            board.append(row)
        return board

    def is_valid_move(self, pos1, pos2):
        if pos1 == pos2 or pos1[0] < 0 or pos1[0] >= self.BOARD_SIZE[0] or pos1[1] < 0 or pos1[1] >= self.BOARD_SIZE[1] or pos2[0] < 0 or pos2[0] >= self.BOARD_SIZE[0] or pos2[1] < 0 or pos2[1] >= self.BOARD_SIZE[1]:
            return False
        if self.board[pos1[0]][pos1[1]] != self.board[pos2[0]][pos2[1]]:
            return False
        return self.has_path(pos1, pos2)

    def has_path(self, pos1, pos2):
        visited = set()
        queue = [pos1]
        while queue:
            x, y = queue.pop(0)
            if (x, y) == pos2:
                return True
            if (x, y) in visited:
                continue
            visited.add((x, y))
            if x > 0 and self.board[x][y] == self.board[x-1][y]:
                queue.append((x-1, y))
            if x < self.BOARD_SIZE[0] - 1 and self.board[x][y] == self.board[x+1][y]:
                queue.append((x+1, y))
            if y > 0 and self.board[x][y] == self.board[x][y-1]:
                queue.append((x, y-1))
            if y < self.BOARD_SIZE[1] - 1 and self.board[x][y] == self.board[x][y+1]:
                queue.append((x, y+1))
        return False

    def remove_icons(self, pos1, pos2):
        self.board[pos1[0]][pos1[1]] = ' '
        self.board[pos2[0]][pos2[1]] = ' '

    def is_game_over(self):
        for row in self.board:
            for icon in row:
                if icon != ' ':
                    return False
        return True