import math
import numpy as np
from scipy import stats

class DataStatistics4:
    @staticmethod
    def correlation_coefficient(data1, data2):
        return np.corrcoef(data1, data2)[0, 1]

    @staticmethod
    def skewness(data):
        return stats.skew(data)

    @staticmethod
    def kurtosis(data):
        return stats.kurtosis(data)

    @staticmethod
    def pdf(data, mu, sigma):
        return stats.norm.pdf(data, loc=mu, scale=sigma)