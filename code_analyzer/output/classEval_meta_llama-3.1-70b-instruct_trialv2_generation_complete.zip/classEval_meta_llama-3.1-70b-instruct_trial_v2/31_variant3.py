import math

class DataStatistics4:
    @staticmethod
    def correlation_coefficient(data1, data2):
        n = len(data1)
        sum1 = sum(data1)
        sum2 = sum(data2)
        sum1_sq = sum([x ** 2 for x in data1])
        sum2_sq = sum([x ** 2 for x in data2])
        p_sum = sum([data1[i] * data2[i] for i in range(n)])
        numerator = p_sum - (sum1 * sum2 / n)
        denominator = math.sqrt((sum1_sq - sum1 ** 2 / n) * (sum2_sq - sum2 ** 2 / n))
        return numerator / denominator

    @staticmethod
    def skewness(data):
        n = len(data)
        mean = sum(data) / n
        m3 = sum((x - mean) ** 3 for x in data) / n
        m2 = sum((x - mean) ** 2 for x in data) / n
        return m3 / (m2 ** 1.5)

    @staticmethod
    def kurtosis(data):
        n = len(data)
        mean = sum(data) / n
        m4 = sum((x - mean) ** 4 for x in data) / n
        m2 = sum((x - mean) ** 2 for x in data) / n
        return m4 / (m2 ** 2) - 3

    @staticmethod
    def pdf(data, mu, sigma):
        return [math.exp(-((x - mu) ** 2) / (2 * sigma ** 2)) / (sigma * math.sqrt(2 * math.pi)) for x in data]