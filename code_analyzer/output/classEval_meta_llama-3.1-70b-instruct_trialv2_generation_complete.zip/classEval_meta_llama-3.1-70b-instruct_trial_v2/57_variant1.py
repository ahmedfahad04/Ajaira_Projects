class MetricsCalculator2:
    def __init__(self):
        pass

    @staticmethod
    def mrr(data):
        if isinstance(data[0], list):
            mrr_values = []
            for d in data:
                try:
                    rank = d.index(1) + 1
                    mrr_values.append(1 / rank)
                except ValueError:
                    mrr_values.append(0)
            return sum(mrr_values) / len(mrr_values), mrr_values
        else:
            try:
                rank = data[0].index(1) + 1
                return 1 / rank, [1 / rank]
            except ValueError:
                return 0, [0]

    @staticmethod
    def map(data):
        if isinstance(data[0], list):
            map_values = []
            for d in data:
                precision_values = []
                correct_count = 0
                for i, value in enumerate(d[0]):
                    correct_count += value
                    precision_values.append(correct_count / (i + 1))
                map_values.append(sum(precision_values) / len(precision_values))
            return sum(map_values) / len(map_values), map_values
        else:
            precision_values = []
            correct_count = 0
            for i, value in enumerate(data[0]):
                correct_count += value
                precision_values.append(correct_count / (i + 1))
            return sum(precision_values) / len(precision_values), [sum(precision_values) / len(precision_values)]