import logging
import datetime
import re

class AccessGatewayFilter:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.allowed_prefixes = ['/api', '/login']

    def filter(self, request):
        if not self.is_start_with(request['path']):
            return False
        user = self.get_jwt_user(request)
        if user:
            self.set_current_user_info_and_log(user)
            return True
        return False

    def is_start_with(self, request_uri):
        pattern = '^(' + '|'.join(self.allowed_prefixes) + ')'
        return bool(re.match(pattern, request_uri))

    def get_jwt_user(self, request):
        try:
            return request['headers']['Authorization']['user']
        except KeyError:
            return None

    def set_current_user_info_and_log(self, user):
        self.logger.info(f'User {user["name"]} accessed from {user["address"]}')