import math
import numpy as np
from scipy import stats

class Statistics3:
    @staticmethod
    def median(data):
        return stats.median(data)

    @staticmethod
    def mode(data):
        return stats.mode(data).mode

    @staticmethod
    def correlation(x, y):
        return stats.pearsonr(x, y)[0]

    @staticmethod
    def mean(data):
        return stats.tmean(data)

    @staticmethod
    def correlation_matrix(data):
        return np.array([[stats.pearsonr(data[i], data[j])[0] for j in range(len(data))] for i in range(len(data))]).tolist()

    @staticmethod
    def standard_deviation(data):
        return stats.tstd(data)

    @staticmethod
    def z_score(data):
        return stats.zscore(data)