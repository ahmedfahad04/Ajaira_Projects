class BinaryDataProcessor:
    def __init__(self, binary_string):
        self.binary_string = binary_string
        self.clean_non_binary_chars()

    def clean_non_binary_chars(self):
        self.binary_string = ''.join([char for char in self.binary_string if char in '01'])

    def calculate_binary_info(self):
        zeroes = self.binary_string.count('0') / len(self.binary_string)
        ones = self.binary_string.count('1') / len(self.binary_string)
        return {'Zeroes': zeroes, 'Ones': ones, 'Bit length': len(self.binary_string)}

    def convert_to_ascii(self):
        ascii_string = ''
        for i in range(0, len(self.binary_string), 8):
            byte = self.binary_string[i:i+8]
            ascii_string += chr(int(byte, 2))
        return ascii_string

    def convert_to_utf8(self):
        return self.binary_string.encode('utf-8').decode('utf-8')