import re

class RegexUtils:
    def __init__(self):
        self.compiled_patterns = {
            'email': re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
            'phone_number': re.compile(r'\b\d{3}-\d{3}-\d{4}\b'),
            'split_sentences': re.compile(r'[.!?][\s]{1,2}(?=[A-Z])')
        }

    def match(self, pattern, text):
        return bool(re.match(pattern, text))

    def findall(self, pattern, text):
        return re.findall(pattern, text)

    def split(self, pattern, text):
        return re.split(pattern, text)

    def sub(self, pattern, replacement, text):
        return re.sub(pattern, replacement, text)

    def generate_email_pattern(self):
        return self.compiled_patterns['email'].pattern

    def generate_phone_number_pattern(self):
        return self.compiled_patterns['phone_number'].pattern

    def generate_split_sentences_pattern(self):
        return self.compiled_patterns['split_sentences'].pattern

    def split_sentences(self, text):
        sentences = self.compiled_patterns['split_sentences'].split(text)
        return [sentence.strip() for sentence in sentences if sentence]

    def validate_phone_number(self, phone_number):
        return bool(self.compiled_patterns['phone_number'].match(phone_number))

    def extract_email(self, text):
        return self.compiled_patterns['email'].findall(text)