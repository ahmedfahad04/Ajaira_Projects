class JobMarketplace:
    def __init__(self):
        self.job_listings = []
        self.resumes = []

    def post_job(self, job_title, company, requirements):
        self.job_listings.append({'job_title': job_title, 'company': company, 'requirements': requirements})

    def remove_job(self, job):
        self.job_listings = [j for j in self.job_listings if j != job]

    def submit_resume(self, name, skills, experience):
        self.resumes.append({'name': name, 'skills': skills, 'experience': experience})

    def withdraw_resume(self, resume):
        self.resumes = [r for r in self.resumes if r != resume]

    def search_jobs(self, criteria):
        return [job for job in self.job_listings if criteria in job['requirements']]

    def get_job_applicants(self, job):
        return [resume for resume in self.resumes if any(requirement in resume['skills'] for requirement in job['requirements'])]