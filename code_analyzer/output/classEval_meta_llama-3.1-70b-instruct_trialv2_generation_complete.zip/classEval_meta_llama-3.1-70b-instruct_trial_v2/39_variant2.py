from collections import deque

class ExpressionCalculator:
    def __init__(self):
        self.postfix_stack = deque()
        self.operat_priority = {'+': 3, '-': 2, '*': 1, '/': 1, '%': 0, '(': -1, ')': 1}

    def calculate(self, expression):
        self.prepare(expression)
        stack = deque()
        while self.postfix_stack:
            item = self.postfix_stack.popleft()
            if item not in self.operat_priority:
                stack.append(float(item))
            else:
                second_value = stack.pop()
                first_value = stack.pop()
                stack.append(self._calculate(first_value, second_value, item))
        return stack.pop()

    def prepare(self, expression):
        self.postfix_stack.clear()
        expression = self.transform(expression)
        operator_stack = deque()
        for item in expression:
            if self.is_operator(item):
                while operator_stack and self.compare(item, operator_stack[-1]):
                    self.postfix_stack.append(operator_stack.pop())
                if item != ')':
                    operator_stack.append(item)
                elif operator_stack[-1] == '(':
                    operator_stack.pop()
                else:
                    self.postfix_stack.append(operator_stack.pop())
            else:
                self.postfix_stack.append(item)
        while operator_stack:
            self.postfix_stack.append(operator_stack.pop())

    @staticmethod
    def is_operator(c):
        return c in {'+', '-', '*', '/', '(', ')', '%'}

    def compare(self, cur, peek):
        return self.operat_priority[cur] <= self.operat_priority[peek]

    @staticmethod
    def _calculate(first_value, second_value, current_op):
        if current_op == '+':
            return first_value + second_value
        elif current_op == '-':
            return first_value - second_value
        elif current_op == '*':
            return first_value * second_value
        elif current_op == '/':
            return first_value / second_value
        elif current_op == '%':
            return first_value % second_value

    @staticmethod
    def transform(expression):
        expression = expression.replace(' ', '')
        result = ''
        for char in expression:
            if char not in {'+', '-', '*', '/', '(', ')', '%'}:
                result += char
            else:
                result += char
        return result