import math
import statistics
import numpy as np

class DataStatistics4:
    @staticmethod
    def correlation_coefficient(data1, data2):
        mean1 = statistics.mean(data1)
        mean2 = statistics.mean(data2)
        numerator = sum((x - mean1) * (y - mean2) for x, y in zip(data1, data2))
        denominator = math.sqrt(sum((x - mean1) ** 2 for x in data1)) * math.sqrt(sum((y - mean2) ** 2 for y in data2))
        return numerator / denominator

    @staticmethod
    def skewness(data):
        mean = statistics.mean(data)
        variance = statistics.variance(data)
        std_dev = math.sqrt(variance)
        numerator = sum((x - mean) ** 3 for x in data)
        denominator = len(data) * std_dev ** 3
        return numerator / denominator

    @staticmethod
    def kurtosis(data):
        mean = statistics.mean(data)
        variance = statistics.variance(data)
        std_dev = math.sqrt(variance)
        numerator = sum((x - mean) ** 4 for x in data)
        denominator = len(data) * std_dev ** 4
        return numerator / denominator - 3

    @staticmethod
    def pdf(data, mu, sigma):
        return [math.exp(-((x - mu) ** 2) / (2 * sigma ** 2)) / (sigma * math.sqrt(2 * math.pi)) for x in data]