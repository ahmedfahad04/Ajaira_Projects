class BitStatusUtil:
    @staticmethod
    def add(states, stat):
        if states < 0 or states % 2 != 0 or stat < 0 or stat % 2 != 0:
            raise ValueError("Invalid input")
        return states | stat

    @staticmethod
    def has(states, stat):
        if states < 0 or states % 2 != 0 or stat < 0 or stat % 2 != 0:
            raise ValueError("Invalid input")
        return bool(states & stat)

    @staticmethod
    def remove(states, stat):
        if states < 0 or states % 2 != 0 or stat < 0 or stat % 2 != 0:
            raise ValueError("Invalid input")
        return states & ~stat