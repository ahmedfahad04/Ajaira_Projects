import numpy as np

class Interpolation:
    """ This is a class that implements the Linear interpolation operation of one-dimensional and two-dimensional data """
    def __init__(self):
        pass

    @staticmethod
    def interpolate_1d(x, y, x_interp):
        """ Linear interpolation of one-dimensional data
        :param x: The x-coordinate of the data point, list.
        :param y: The y-coordinate of the data point, list.
        :param x_interp: The x-coordinate of the interpolation point, list.
        :return: The y-coordinate of the interpolation point, list.
        """
        y_interp = np.interp(x_interp, x, y)
        return y_interp.tolist()

    @staticmethod
    def interpolate_2d(x, y, z, x_interp, y_interp):
        """ Linear interpolation of two-dimensional data
        :param x: The x-coordinate of the data point, list.
        :param y: The y-coordinate of the data point, list.
        :param z: The z-coordinate of the data point, list.
        :param x_interp: The x-coordinate of the interpolation point, list.
        :param y_interp: The y-coordinate of the interpolation point, list.
        :return: The z-coordinate of the interpolation point, list.
        """
        z_interp = np.zeros(len(x_interp))
        for i, (x_i, y_i) in enumerate(zip(x_interp, y_interp)):
            x_idx = np.searchsorted(x, x_i)
            y_idx = np.searchsorted(y, y_i)
            if x_idx == 0:
                x_idx = 1
            if y_idx == 0:
                y_idx = 1
            if x_idx == len(x):
                x_idx = len(x) - 1
            if y_idx == len(y):
                y_idx = len(y) - 1
            dx = (x_i - x[x_idx - 1]) / (x[x_idx] - x[x_idx - 1])
            dy = (y_i - y[y_idx - 1]) / (y[y_idx] - y[y_idx - 1])
            z_interp[i] = (1 - dx) * (1 - dy) * z[x_idx - 1][y_idx - 1] + \
                          dx * (1 - dy) * z[x_idx][y_idx - 1] + \
                          (1 - dx) * dy * z[x_idx - 1][y_idx] + \
                          dx * dy * z[x_idx][y_idx]
        return z_interp.tolist()