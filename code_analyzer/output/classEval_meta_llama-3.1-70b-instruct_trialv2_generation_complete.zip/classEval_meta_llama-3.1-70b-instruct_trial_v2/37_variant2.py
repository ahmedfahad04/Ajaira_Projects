class EncryptionUtils:
    def __init__(self, key):
        self.key = key

    def caesar_cipher(self, plaintext, shift):
        result = ""
        for char in plaintext:
            if char.isalpha():
                result += chr((ord(char) - 97 + shift) % 26 + 97) if char.islower() else chr((ord(char) - 65 + shift) % 26 + 65)
            else:
                result += char
        return result

    def vigenere_cipher(self, plaintext):
        key_index = 0
        result = ""
        for char in plaintext:
            if char.isalpha():
                shift = ord(self.key[key_index % len(self.key)].lower()) - 97
                result += chr((ord(char) - 97 + shift) % 26 + 97) if char.islower() else chr((ord(char) - 65 + shift) % 26 + 65)
                key_index += 1
            else:
                result += char
        return result

    def rail_fence_cipher(self, plain_text, rails):
        if rails == 1:
            return plain_text
        rail_strings = [""] * rails
        rail_index = 0
        step = -1
        for char in plain_text:
            rail_strings[rail_index] += char
            if rail_index == 0:
                step = 1
            elif rail_index == rails - 1:
                step = -1
            rail_index += step
        return "".join(rail_strings)