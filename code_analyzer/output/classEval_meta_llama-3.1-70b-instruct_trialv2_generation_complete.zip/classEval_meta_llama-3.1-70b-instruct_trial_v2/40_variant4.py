class FitnessTracker:
    def __init__(self, height, weight, age, sex) -> None:
        self.height = height
        self.weight = weight
        self.age = age
        self.sex = sex
        self.BMI_std = {"male": [20, 25], "female": [19, 24]}

    def get_BMI(self):
        return self.weight / (self.height ** 2)

    def condition_judge(self):
        if self.sex == "male":
            return self._judge_male()
        else:
            return self._judge_female()

    def _judge_male(self):
        BMI = self.get_BMI()
        if BMI < self.BMI_std["male"][0]:
            return -1
        elif BMI > self.BMI_std["male"][1]:
            return 1
        return 0

    def _judge_female(self):
        BMI = self.get_BMI()
        if BMI < self.BMI_std["female"][0]:
            return -1
        elif BMI > self.BMI_std["female"][1]:
            return 1
        return 0

    def calculate_calorie_intake(self):
        BMR = (10 * self.weight + 6.25 * self.height - 5 * self.age + (5 if self.sex == "male" else -161))
        condition = self.condition_judge()
        if condition == -1:
            return BMR * 1.6
        elif condition == 1:
            return BMR * 1.2
        return BMR * 1.4