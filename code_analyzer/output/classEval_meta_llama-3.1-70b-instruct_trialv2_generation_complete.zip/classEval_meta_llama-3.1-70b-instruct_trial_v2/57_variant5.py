class MetricsCalculator2:
    def __init__(self):
        pass

    @staticmethod
    def mrr(data):
        if isinstance(data[0], list):
            mrr_values = [MetricsCalculator2._mrr(d[0], d[1]) for d in data]
            return sum(mrr_values) / len(mrr_values), mrr_values
        else:
            return MetricsCalculator2._mrr(data[0], data[1]), [MetricsCalculator2._mrr(data[0], data[1])]

    @staticmethod
    def _mrr(actual, ground_truth):
        try:
            rank = [i for i, x in enumerate(actual) if x == 1][0] + 1
            return 1 / rank
        except IndexError:
            return 0

    @staticmethod
    def map(data):
        if isinstance(data[0], list):
            map_values = [MetricsCalculator2._map(d[0], d[1]) for d in data]
            return sum(map_values) / len(map_values), map_values
        else:
            return MetricsCalculator2._map(data[0], data[1]), [MetricsCalculator2._map(data[0], data[1])]

    @staticmethod
    def _map(actual, ground_truth):
        precision_values = []
        correct_count = 0
        for i, value in enumerate(actual):
            correct_count += value
            precision_values.append(correct_count / (i + 1))
        return sum(precision_values) / len(precision_values)