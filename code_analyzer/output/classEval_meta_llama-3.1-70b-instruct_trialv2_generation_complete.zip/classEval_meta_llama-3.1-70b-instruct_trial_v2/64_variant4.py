class NumberConverter:
    @staticmethod
    def decimal_to_binary(decimal_num):
        if decimal_num == 0:
            return '0'
        binary_num = ''
        while decimal_num > 0:
            binary_num = str(decimal_num & 1) + binary_num
            decimal_num >>= 1
        return binary_num

    @staticmethod
    def binary_to_decimal(binary_num):
        decimal_num = 0
        for bit in binary_num:
            decimal_num = (decimal_num << 1) | int(bit)
        return decimal_num

    @staticmethod
    def decimal_to_octal(decimal_num):
        if decimal_num == 0:
            return '0'
        octal_num = ''
        while decimal_num > 0:
            octal_num = str(decimal_num % 8) + octal_num
            decimal_num //= 8
        return octal_num

    @staticmethod
    def octal_to_decimal(octal_num):
        decimal_num = 0
        for digit in octal_num:
            decimal_num = (decimal_num << 3) | int(digit)
        return decimal_num

    @staticmethod
    def decimal_to_hex(decimal_num):
        if decimal_num == 0:
            return '0'
        hex_num = ''
        hex_map = '0123456789abcdef'
        while decimal_num > 0:
            hex_num = hex_map[decimal_num % 16] + hex_num
            decimal_num //= 16
        return hex_num

    @staticmethod
    def hex_to_decimal(hex_num):
        decimal_num = 0
        hex_map = '0123456789abcdef'
        for char in hex_num:
            decimal_num = (decimal_num << 4) | hex_map.index(char)
        return decimal_num