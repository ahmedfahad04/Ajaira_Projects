import logging
import datetime
import jwt

class AccessGatewayFilter:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.allowed_prefixes = ['/api', '/login']
        self.secret_key = 'secret_key'

    def filter(self, request):
        if not self.is_start_with(request['path']):
            return False
        user = self.get_jwt_user(request)
        if user:
            self.set_current_user_info_and_log(user)
            return True
        return False

    def is_start_with(self, request_uri):
        for prefix in self.allowed_prefixes:
            if request_uri.startswith(prefix):
                return True
        return False

    def get_jwt_user(self, request):
        try:
            token = request['headers']['Authorization']['jwt']
            return jwt.decode(token, self.secret_key, algorithms=['HS256'])
        except (KeyError, jwt.ExpiredSignatureError, jwt.InvalidTokenError):
            return None

    def set_current_user_info_and_log(self, user):
        self.logger.info(f'User {user["name"]} accessed from {user["address"]}')