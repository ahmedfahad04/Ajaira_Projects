class MusicPlayer:
    def __init__(self):
        self.playlist = []
        self.current_song_index = None
        self.volume = 50
        self.is_playing = False

    def add_song(self, song):
        self.playlist.append(song)

    def remove_song(self, song):
        if song in self.playlist:
            self.playlist.remove(song)
            if self.current_song_index == len(self.playlist):
                self.current_song_index = None
                self.is_playing = False

    def play(self):
        if self.playlist and not self.is_playing:
            self.current_song_index = 0 if self.current_song_index is None else self.current_song_index
            self.is_playing = True
            return self.playlist[self.current_song_index]
        return False

    def stop(self):
        self.is_playing = False
        return True

    def switch_song(self):
        if self.playlist and self.is_playing:
            self.current_song_index = (self.current_song_index + 1) % len(self.playlist)
            return True
        return False

    def previous_song(self):
        if self.playlist and self.is_playing:
            self.current_song_index = (self.current_song_index - 1) % len(self.playlist)
            return True
        return False

    def set_volume(self, volume):
        if 0 <= volume <= 100:
            self.volume = volume
            return True
        return False

    def shuffle(self):
        if self.playlist:
            import random
            random.shuffle(self.playlist)
            self.current_song_index = None
            self.is_playing = False
            return True
        return False