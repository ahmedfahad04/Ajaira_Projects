class CamelCaseMap:
    def __init__(self):
        self._data = {}

    def __getitem__(self, key):
        return self._data[self._to_camel_case(key)]

    def __setitem__(self, key, value):
        self._data[self._to_camel_case(key)] = value

    def __delitem__(self, key):
        del self._data[self._to_camel_case(key)]

    def __iter__(self):
        return iter(self._data)

    def __len__(self):
        return len(self._data)

    def _to_camel_case(self, key):
        import re
        return re.sub(r'_([a-z])', lambda m: m.group(1).upper(), key)

    def _convert_key(self, key):
        return self._to_camel_case(key)