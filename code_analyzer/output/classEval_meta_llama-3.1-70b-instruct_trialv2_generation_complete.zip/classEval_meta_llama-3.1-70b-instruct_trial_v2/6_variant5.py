class AvgPartition:
    def __init__(self, lst, limit):
        if limit <= 0:
            raise ValueError("Number of partitions must be greater than 0")
        self.lst = lst
        self.limit = limit

    def setNum(self):
        return divmod(len(self.lst), self.limit)

    def get(self, index):
        block_size, remainder = self.setNum()
        return [self.lst[i] for i in range(len(self.lst)) if i // block_size == index]