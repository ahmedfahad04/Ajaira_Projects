class CurrencyConverter:
    def __init__(self):
        self.rates = { 'USD': 1.0, 'EUR': 0.85, 'GBP': 0.72, 'JPY': 110.15, 'CAD': 1.23, 'AUD': 1.34, 'CNY': 6.40, }
        self.supported_currencies = self.rates.keys()

    def convert(self, amount, from_currency, to_currency):
        if from_currency not in self.supported_currencies or to_currency not in self.supported_currencies:
            raise ValueError("Unsupported currency")
        return amount * self.rates[from_currency] / self.rates[to_currency]

    def get_supported_currencies(self):
        return list(self.supported_currencies)

    def add_currency_rate(self, currency, rate):
        if currency in self.supported_currencies:
            return False
        self.supported_currencies = self.rates.keys()
        self.rates[currency] = rate

    def update_currency_rate(self, currency, new_rate):
        if currency not in self.supported_currencies:
            return False
        self.rates[currency] = new_rate