import math
from typing import List

class CombinationCalculator:
    def __init__(self, datas: List[str]):
        self.datas = datas

    @staticmethod
    def count(n: int, m: int) -> int:
        return math.comb(n, m)

    @staticmethod
    def count_all(n: int) -> int:
        result = sum(math.comb(n, i) for i in range(n + 1))
        return result if result <= 2**63-1 else float("inf")

    def select(self, m: int) -> List[List[str]]:
        def dfs(start, path):
            if len(path) == m:
                result.append(path[:])
                return
            for i in range(start, len(self.datas)):
                dfs(i + 1, path + [self.datas[i]])

        result = []
        dfs(0, [])
        return result

    def select_all(self) -> List[List[str]]:
        result = []
        for i in range(len(self.datas) + 1):
            result.extend(self.select(i))
        return result