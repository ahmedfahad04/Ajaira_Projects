from collections import Counter
import scipy.stats as stats

class DataStatistics:
    def mean(self, data):
        return round(stats.tmean(data), 2)

    def median(self, data):
        return round(stats.tmedian(data), 2)

    def mode(self, data):
        mode_data = Counter(data).most_common()
        max_count = mode_data[0][1]
        modes = [num for num, count in mode_data if count == max_count]
        return modes