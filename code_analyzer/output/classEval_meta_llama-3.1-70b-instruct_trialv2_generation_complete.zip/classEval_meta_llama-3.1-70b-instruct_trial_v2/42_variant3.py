class Hotel:
    def __init__(self, name, rooms):
        self.name = name
        self.available_rooms = rooms
        self.booked_rooms = {}

    def book_room(self, room_type, room_number, name):
        if room_type in self.available_rooms:
            available = self.available_rooms[room_type]
            if room_number <= available:
                self.available_rooms[room_type] -= room_number
                if room_type not in self.booked_rooms:
                    self.booked_rooms[room_type] = {}
                self.booked_rooms[room_type][name] = self.booked_rooms[room_type].get(name, 0) + room_number
                return 'Success!'
            else:
                return available
        return False

    def check_in(self, room_type, room_number, name):
        if room_type in self.booked_rooms and name in self.booked_rooms[room_type]:
            booked_number = self.booked_rooms[room_type][name]
            if booked_number >= room_number:
                self.booked_rooms[room_type][name] -= room_number
                if self.booked_rooms[room_type][name] == 0:
                    del self.booked_rooms[room_type][name]
                return True
        return False

    def check_out(self, room_type, room_number):
        if room_type in self.available_rooms:
            self.available_rooms[room_type] += room_number
        else:
            self.available_rooms[room_type] = room_number

    def get_available_rooms(self, room_type):
        return self.available_rooms.get(room_type, 0)