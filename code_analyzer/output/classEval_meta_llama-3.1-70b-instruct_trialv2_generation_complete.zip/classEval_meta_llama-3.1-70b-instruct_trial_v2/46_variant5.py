class Interpolation:
    """ This is a class that implements the Linear interpolation operation of one-dimensional and two-dimensional data """
    def __init__(self):
        pass

    @staticmethod
    def interpolate_1d(x, y, x_interp):
        """ Linear interpolation of one-dimensional data
        :param x: The x-coordinate of the data point, list.
        :param y: The y-coordinate of the data point, list.
        :param x_interp: The x-coordinate of the interpolation point, list.
        :return: The y-coordinate of the interpolation point, list.
        """
        y_interp = []
        for x_i in x_interp:
            x.sort()
            idx = 0
            while idx < len(x) - 1 and x[idx + 1] <= x_i:
                idx += 1
            if idx == len(x) - 1:
                y_i = y[-1]
            else:
                y_i = y[idx] + (x_i - x[idx]) * (y[idx + 1] - y[idx]) / (x[idx + 1] - x[idx])
            y_interp.append(y_i)
        return y_interp

    @staticmethod
    def interpolate_2d(x, y, z, x_interp, y_interp):
        """ Linear interpolation of two-dimensional data
        :param x: The x-coordinate of the data point, list.
        :param y: The y-coordinate of the data point, list.
        :param z: The z-coordinate of the data point, list.
        :param x_interp: The x-coordinate of the interpolation point, list.
        :param y_interp: The y-coordinate of the interpolation point, list.
        :return: The z-coordinate of the interpolation point, list.
        """
        z_interp = []
        for x_i, y_i in zip(x_interp, y_interp):
            x.sort()
            y.sort()
            idx_x = 0
            idx_y = 0
            while idx_x < len(x) - 1 and x[idx_x + 1] <= x_i:
                idx_x += 1
            while idx_y < len(y) - 1 and y[idx_y + 1] <= y_i:
                idx_y += 1
            if idx_x == len(x) - 1 and idx_y == len(y) - 1:
                z_i = z[-1][-1]
            elif idx_x == len(x) - 1:
                z_i = z[-1][idx_y] + (y_i - y[idx_y]) * (z[-1][idx_y + 1] - z[-1][idx_y]) / (y[idx_y + 1] - y[idx_y])
            elif idx_y == len(y) - 1:
                z_i = z[idx_x][-1] + (x_i - x[idx_x]) * (z[idx_x + 1][-1] - z[idx_x][-1]) / (x[idx_x + 1] - x[idx_x])
            else:
                z_i = (z[idx_x][idx_y] * (x[idx_x + 1] - x_i) * (y[idx_y + 1] - y_i) +
                        z[idx_x + 1][idx_y] * (x_i - x[idx_x]) * (y[idx_y + 1] - y_i) +
                        z[idx_x][idx_y + 1] * (x[idx_x + 1] - x_i) * (y_i - y[idx_y]) +
                        z[idx_x + 1][idx_y + 1] * (x_i - x[idx_x]) * (y_i - y[idx_y])) / ((x[idx_x + 1] - x[idx_x]) * (y[idx_y + 1] - y[idx_y]))
            z_interp.append(z_i)
        return z_interp