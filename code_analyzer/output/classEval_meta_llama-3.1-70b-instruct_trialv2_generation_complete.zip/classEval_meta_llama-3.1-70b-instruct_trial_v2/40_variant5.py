class FitnessTracker:
    def __init__(self, height, weight, age, sex) -> None:
        self.height = height
        self.weight = weight
        self.age = age
        self.sex = sex
        self.BMI_std = {"male": [20, 25], "female": [19, 24]}
        self.BMR_formula = {"male": lambda w, h, a: 10 * w + 6.25 * h - 5 * a + 5, "female": lambda w, h, a: 10 * w + 6.25 * h - 5 * a - 161}
        self.calorie_intake_multiplier = {-1: 1.6, 0: 1.4, 1: 1.2}

    def get_BMI(self):
        return self.weight / (self.height ** 2)

    def condition_judge(self):
        BMI = self.get_BMI()
        if self.sex == "male":
            if BMI < self.BMI_std["male"][0]:
                return -1
            elif BMI > self.BMI_std["male"][1]:
                return 1
        else:
            if BMI < self.BMI_std["female"][0]:
                return -1
            elif BMI > self.BMI_std["female"][1]:
                return 1
        return 0

    def calculate_calorie_intake(self):
        BMR = self.BMR_formula[self.sex](self.weight, self.height, self.age)
        return BMR * self.calorie_intake_multiplier[self.condition_judge()]