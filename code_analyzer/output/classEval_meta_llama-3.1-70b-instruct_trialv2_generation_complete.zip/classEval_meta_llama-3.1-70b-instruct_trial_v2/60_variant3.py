import sqlite3

class MovieTicketDB:
    def __init__(self, db_name):
        self.db_name = db_name
        self.connection = sqlite3.connect(db_name)
        self.cursor = self.connection.cursor()
        self.create_table()

    def create_table(self):
        query = '''
            CREATE TABLE IF NOT EXISTS tickets
            (ID INTEGER PRIMARY KEY AUTOINCREMENT, 
             movie_name TEXT, theater_name TEXT, seat_number TEXT, customer_name TEXT)
        '''
        self.cursor.execute(query)
        self.connection.commit()

    def insert_ticket(self, movie_name, theater_name, seat_number, customer_name):
        query = '''
            INSERT INTO tickets (movie_name, theater_name, seat_number, customer_name)
            VALUES (?, ?, ?, ?)
        '''
        self.cursor.execute(query, (movie_name, theater_name, seat_number, customer_name))
        self.connection.commit()

    def search_tickets_by_customer(self, customer_name):
        query = '''
            SELECT * FROM tickets WHERE customer_name = ?
        '''
        self.cursor.execute(query, (customer_name,))
        return self.cursor.fetchall()

    def delete_ticket(self, ticket_id):
        query = '''
            DELETE FROM tickets WHERE ID = ?
        '''
        self.cursor.execute(query, (ticket_id,))
        self.connection.commit()