import re

class SplitSentence:
  def split_sentences(self, sentences_string):
    sentences = re.split('(?<=[.?\s]) +(?=[A-Z])', sentences_string)
    return list(filter(None, sentences))

  def count_words(self, sentence):
    words = re.findall(r'\b\w+\b', sentence)
    return len(words)

  def process_text_file(self, sentences_string):
    sentences = self.split_sentences(sentences_string)
    return max(self.count_words(sentence) for sentence in sentences)