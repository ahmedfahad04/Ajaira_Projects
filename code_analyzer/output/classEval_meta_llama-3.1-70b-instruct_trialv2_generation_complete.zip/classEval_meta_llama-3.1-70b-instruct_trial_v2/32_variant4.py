class DecryptionUtils:
    def __init__(self, key):
        self.key = key

    def caesar_decipher(self, ciphertext, shift):
        result = ''
        for char in ciphertext:
            if char.isalpha():
                ascii_offset = 65 if char.isupper() else 97
                result += chr((ord(char) - ascii_offset - shift) % 26 + ascii_offset)
            else:
                result += char
        return result

    def vigenere_decipher(self, ciphertext):
        key_index = 0
        result = ''
        for char in ciphertext:
            if char.isalpha():
                shift = ord(self.key[key_index % len(self.key)].lower()) - 97
                ascii_offset = 65 if char.isupper() else 97
                result += chr((ord(char) - ascii_offset - shift) % 26 + ascii_offset)
                key_index += 1
            else:
                result += char
        return result

    def rail_fence_decipher(self, encrypted_text, rails):
        fence = [''] * rails
        index, step = 0, 1
        for char in encrypted_text:
            fence[index] += char
            if index == 0:
                step = 1
            elif index == rails - 1:
                step = -1
            index += step
        result = ''
        for i in range(len(encrypted_text)):
            for j in range(rails):
                if len(fence[j]) > 0:
                    result += fence[j][0]
                    fence[j] = fence[j][1:]
        return result