class NumericEntityUnescaper:
    def __init__(self):
        pass

    def replace(self, string):
        import html
        return html.unescape(string)

    @staticmethod
    def is_hex_char(char):
        return char.isdigit() or 'a' <= char.lower() <= 'f'