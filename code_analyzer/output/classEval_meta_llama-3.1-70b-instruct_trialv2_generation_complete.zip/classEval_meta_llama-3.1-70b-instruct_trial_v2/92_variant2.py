import sqlite3

class UserLoginDB:
    def __init__(self, db_name):
        self.connection = sqlite3.connect(db_name)
        self.cursor = self.connection.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS users
            (username TEXT PRIMARY KEY, password TEXT)
        ''')
        self.connection.commit()

    def insert_user(self, username, password):
        try:
            self.cursor.execute('INSERT INTO users VALUES (?, ?)', (username, password))
            self.connection.commit()
        except sqlite3.IntegrityError:
            print(f"Username {username} already exists.")

    def search_user_by_username(self, username):
        self.cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
        return self.cursor.fetchall()

    def delete_user_by_username(self, username):
        self.cursor.execute('DELETE FROM users WHERE username = ?', (username,))
        self.connection.commit()

    def validate_user_login(self, username, password):
        user = self.search_user_by_username(username)
        return len(user) == 1 and user[0][1] == password