import csv

class CSVProcessor:
    def __init__(self):
        pass

    def read_csv(self, file_name):
        with open(file_name, 'r') as file:
            reader = csv.reader(file)
            data = list(reader)
            title = data[0]
            data = data[1:]
        return title, data

    def write_csv(self, data, file_name):
        try:
            with open(file_name, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerows(data)
            return 1
        except Exception as e:
            print(e)
            return 0

    def process_csv_data(self, N, save_file_name):
        title, data = self.read_csv(save_file_name)
        try:
            processed_data = [[row[N].upper()] for row in data]
            processed_data.insert(0, [title[N]])
            self.write_csv(processed_data, save_file_name.split('.')[0]+'_process.csv')
            return 1
        except Exception as e:
            print(e)
            return 0