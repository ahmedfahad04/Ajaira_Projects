class ClassRegistrationSystem:
    def __init__(self):
        self.students = []
        self.students_registration_classes = {}

    def register_student(self, student):
        if student not in self.students:
            self.students.append(student)
            self.students_registration_classes[student['name']] = []
            return 1
        return 0

    def register_class(self, student_name, class_name):
        if student_name in self.students_registration_classes:
            self.students_registration_classes[student_name].append(class_name)
        return self.students_registration_classes[student_name]

    def get_students_by_major(self, major):
        return [student['name'] for student in self.students if student['major'] == major]

    def get_all_major(self):
        majors = []
        for student in self.students:
            if student['major'] not in majors:
                majors.append(student['major'])
        return majors

    def get_most_popular_class_in_major(self, major):
        from collections import defaultdict
        classes = defaultdict(int)
        for student in self.students:
            if student['major'] == major:
                for class_name in self.students_registration_classes[student['name']]:
                    classes[class_name] += 1
        if classes:
            return max(classes, key=classes.get)
        return None