import ipaddress

class IPAddress:
    def __init__(self, ip_address):
        self.ip_address = ip_address

    def is_valid(self):
        try:
            ipaddress.IPv4Address(self.ip_address)
            return True
        except ipaddress.AddressValueError:
            return False

    def get_octets(self):
        if self.is_valid():
            return self.ip_address.split(".")
        else:
            return []

    def get_binary(self):
        if self.is_valid():
            return ".".join(format(int(part), "08b") for part in self.ip_address.split("."))
        else:
            return ""