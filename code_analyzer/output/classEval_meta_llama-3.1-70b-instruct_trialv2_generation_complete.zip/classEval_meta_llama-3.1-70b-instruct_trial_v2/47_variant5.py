class IPAddress:
    def __init__(self, ip_address):
        self.ip_address = ip_address

    def is_valid(self):
        parts = self.ip_address.split(".")
        if len(parts) != 4:
            return False
        for part in parts:
            if not part.isdigit() or not 0 <= int(part) <= 255:
                return False
        return True

    def get_octets(self):
        if self.is_valid():
            return self.ip_address.split(".")
        else:
            return []

    def get_binary(self):
        if self.is_valid():
            binary = []
            for part in self.ip_address.split("."):
                binary_part = ''
                num = int(part)
                while num > 0:
                    binary_part = str(num % 2) + binary_part
                    num //= 2
                binary_part = binary_part.zfill(8)
                binary.append(binary_part)
            return ".".join(binary)
        else:
            return ""