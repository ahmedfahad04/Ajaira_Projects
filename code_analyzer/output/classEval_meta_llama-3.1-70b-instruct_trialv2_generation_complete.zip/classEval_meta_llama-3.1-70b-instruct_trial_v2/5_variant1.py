class AutomaticGuitarSimulator:
    def __init__(self, text):
        self.play_text = text

    def interpret(self, display=False):
        result = []
        words = self.play_text.split()
        for word in words:
            if word:
                chord, tune = self._split_chord_tune(word)
                result.append({'Chord': chord, 'Tune': tune})
                if display:
                    self.display(chord, tune)
        return result

    def display(self, key, value):
        print(f"Normal Guitar Playing -- Chord: {key}, Play Tune: {value}")

    def _split_chord_tune(self, word):
        i = 0
        while i < len(word) and word[i].isalpha():
            i += 1
        return word[:i], word[i:]