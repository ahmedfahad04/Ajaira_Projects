import numpy as np

class MetricsCalculator2:
    def __init__(self):
        pass

    @staticmethod
    def mrr(data):
        if isinstance(data[0], list):
            mrr_values = np.array([MetricsCalculator2._mrr(d) for d in data])
            return np.mean(mrr_values), mrr_values.tolist()
        else:
            return MetricsCalculator2._mrr(data), [MetricsCalculator2._mrr(data)]

    @staticmethod
    def _mrr(data):
        try:
            rank = np.where(np.array(data[0]) == 1)[0][0] + 1
            return 1 / rank
        except IndexError:
            return 0

    @staticmethod
    def map(data):
        if isinstance(data[0], list):
            map_values = np.array([MetricsCalculator2._map(d) for d in data])
            return np.mean(map_values), map_values.tolist()
        else:
            return MetricsCalculator2._map(data), [MetricsCalculator2._map(data)]

    @staticmethod
    def _map(data):
        precision_values = []
        correct_count = 0
        for i, value in enumerate(data[0]):
            correct_count += value
            precision_values.append(correct_count / (i + 1))
        return np.mean(precision_values)