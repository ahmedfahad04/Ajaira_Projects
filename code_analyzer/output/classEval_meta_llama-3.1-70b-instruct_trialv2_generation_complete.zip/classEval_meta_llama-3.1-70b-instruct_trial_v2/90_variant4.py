class URLHandler:
    """ The class supports to handle URLs, including extracting the scheme, host, path, query parameters, and fragment. """

    def __init__(self, url):
        """ Initialize URLHandler's URL """
        self.url = url
        import re
        pattern = r"(\w+:\/\/)?([\w.-]+\.[\w.-]+)?([\/\w\.-]*)\??([\w\.-=&]*)\#?([\w\.-]*)"
        match = re.match(pattern, url)
        if match:
            self.scheme = match.group(1).rstrip(":")
            self.host = match.group(2)
            self.path_without_query = match.group(3)
            self.query_params_str = match.group(4)
            self.fragment = match.group(5)

        self.query_params = {}
        query_params_list = self.query_params_str.split("&")
        for param in query_params_list:
            key_value = param.split("=")
            if len(key_value) == 2:
                self.query_params[key_value[0]] = key_value[1]

    def get_scheme(self):
        """ get the scheme of the URL :return: string, If successful, return the scheme of the URL """
        return self.scheme

    def get_host(self):
        """ Get the second part of the URL, which is the host domain name :return: string, If successful, return the host domain name of the URL """
        return self.host

    def get_path(self):
        """ Get the third part of the URL, which is the address of the resource :return: string, If successful, return the address of the resource of the URL """
        return self.path_without_query + "?" + self.query_params_str + "#" + self.fragment

    def get_query_params(self):
        """ Get the request parameters for the URL :return: dict, If successful, return the request parameters of the URL """
        return self.query_params

    def get_fragment(self):
        """ Get the fragment after '#' in the URL :return: string, If successful, return the fragment after '#' of the URL """
        return self.fragment