class Manacher:
    """This is a class that implements a manacher algorithm to find the Longest palindromic substring in a given string."""

    def __init__(self, input_string) -> None:
        """Initializes the Manacher class with the given input_string.
        :param input_string: The input_string to be searched, str."""
        self.input_string = input_string

    def palindromic_length(self, center, diff, string):
        """Calculates the length of the palindromic substring based on a given center, difference value, and input string.
        :param center: The center of the palindromic substring, int.
        :param diff: The difference between the center and the current position, int.
        :param string: The string to be searched, str.
        :return: The length of the palindromic substring, int."""
        length = 0
        while center - diff >= 0 and center + diff < len(string) and string[center - diff] == string[center + diff]:
            length += 2
            diff += 1
        return length

    def palindromic_string(self):
        """Finds the longest palindromic substring in the given string.
        :return: The longest palindromic substring, str."""
        modified_string = '|'.join(self.input_string)
        max_length = 0
        start = 0
        for i in range(len(modified_string)):
            if modified_string[i] == '|':
                continue
            length = self.palindromic_length(i, 1, modified_string)
            if length > max_length:
                max_length = length
                start = i - length + 1
        return modified_string[start:start + max_length].replace('|', '')