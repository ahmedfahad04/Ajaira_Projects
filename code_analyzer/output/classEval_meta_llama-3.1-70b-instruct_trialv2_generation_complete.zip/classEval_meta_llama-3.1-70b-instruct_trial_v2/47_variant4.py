class IPAddress:
    def __init__(self, ip_address):
        self.ip_address = ip_address

    def is_valid(self):
        parts = self.ip_address.split(".")
        if len(parts) != 4:
            return False
        for part in parts:
            if not part.isdigit():
                return False
            num = int(part)
            if not 0 <= num <= 255:
                return False
            if len(part) > 1 and part[0] == '0':
                return False
        return True

    def get_octets(self):
        if self.is_valid():
            return self.ip_address.split(".")
        else:
            return []

    def get_binary(self):
        if self.is_valid():
            return ".".join(format(int(part), "08b") for part in self.ip_address.split("."))
        else:
            return ""