from datetime import datetime

class Chat:
    def __init__(self):
        self.users = {}

    def add_user(self, username):
        if username not in self.users:
            self.users[username] = []
            return True
        return False

    def remove_user(self, username):
        if username in self.users:
            del self.users[username]
            return True
        return False

    def send_message(self, sender, receiver, message):
        if sender in self.users and receiver in self.users:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            self.users[receiver].append((sender, receiver, message, timestamp))
            return True
        return False

    def get_messages(self, username):
        messages = self.users.get(username, [])
        return [{'sender': sender, 'receiver': receiver, 'message': message, 'timestamp': timestamp} for sender, receiver, message, timestamp in messages]