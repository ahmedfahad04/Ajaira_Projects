class Words2Numbers:
    def __init__(self):
        self.numwords = {}
        self.units = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"]
        self.tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]
        self.scales = ["hundred", "thousand", "million", "billion", "trillion"]
        self.numwords["and"] = (1, 0)
        for idx, word in enumerate(self.units):
            self.numwords[word] = (1, idx)
        for idx, word in enumerate(self.tens):
            self.numwords[word] = (1, idx * 10)
        for idx, word in enumerate(self.scales):
            self.numwords[word] = (10 ** (idx * 3 or 2), 0)
        self.ordinal_words = {'first': 1, 'second': 2, 'third': 3, 'fifth': 5, 'eighth': 8, 'ninth': 9, 'twelfth': 12}
        self.ordinal_endings = [('ieth', 'y'), ('th', '')]

    def text2int(self, textnum):
        textnum = textnum.replace('-', ' ')
        textnum = textnum.replace(' and', '')
        textnum = textnum.split()
        number = 0
        temp = 0
        scale = 1
        for word in textnum:
            if word not in self.numwords:
                raise ValueError("Invalid input")
            value, power = self.numwords[word]
            if value >= 1000:
                scale = value
            else:
                temp += value * power
        number = temp * scale
        return str(number)

    def is_valid_input(self, textnum):
        textnum = textnum.replace('-', ' ')
        textnum = textnum.replace(' and', '')
        textnum = textnum.split()
        for word in textnum:
            if word not in self.numwords:
                return False
        return True