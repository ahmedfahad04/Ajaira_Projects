import sqlite3

class BookManagementDB:
    def __init__(self, db_name):
        self.connection = sqlite3.connect(db_name)
        self.cursor = self.connection.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS books
            (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, author TEXT, availability INTEGER DEFAULT 1)
        ''')
        self.connection.commit()

    def add_book(self, title, author):
        self.cursor.execute('INSERT INTO books (title, author) VALUES (?, ?)', (title, author))
        self.connection.commit()

    def remove_book(self, book_id):
        self.cursor.execute('DELETE FROM books WHERE id = ?', (book_id,))
        self.connection.commit()

    def borrow_book(self, book_id):
        self.cursor.execute('UPDATE books SET availability = 0 WHERE id = ? AND availability = 1', (book_id,))
        self.connection.commit()

    def return_book(self, book_id):
        self.cursor.execute('UPDATE books SET availability = 1 WHERE id = ? AND availability = 0', (book_id,))
        self.connection.commit()

    def search_books(self):
        self.cursor.execute('SELECT * FROM books')
        return self.cursor.fetchall()