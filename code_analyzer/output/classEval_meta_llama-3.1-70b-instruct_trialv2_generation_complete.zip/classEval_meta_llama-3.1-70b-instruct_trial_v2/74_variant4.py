class Server:
    def __init__(self):
        self.white_list = []
        self.structs = {"send": {}, "receive": {}}

    def add_white_list(self, addr):
        if addr not in self.white_list:
            self.white_list.append(addr)
            return self.white_list
        return False

    def del_white_list(self, addr):
        if addr in self.white_list:
            self.white_list.remove(addr)
            return self.white_list
        return False

    def recv(self, info):
        if info["addr"] in self.white_list:
            self.structs["receive"] = info
            return info["content"]
        return False

    def send(self, info):
        self.structs["send"] = info
        return

    def show(self, type):
        return self.structs.get(type, False)