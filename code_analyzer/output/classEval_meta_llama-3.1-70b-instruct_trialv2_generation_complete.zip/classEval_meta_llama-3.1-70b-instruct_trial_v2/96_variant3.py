class WeatherSystem:
    def __init__(self, city):
        self.temperature = None
        self.weather = None
        self.city = city
        self.weather_list = {}

    def query(self, weather_list, tmp_units='celsius'):
        if self.city in weather_list:
            self.weather_list = weather_list[self.city]
            self.temperature = self.weather_list['temperature']
            self.weather = self.weather_list['weather']
            if tmp_units == 'fahrenheit':
                self.temperature = self.convert_temperature(tmp_units)
        return self.temperature, self.weather

    def set_city(self, city):
        self.city = city

    def convert_temperature(self, tmp_units):
        if tmp_units == 'fahrenheit':
            return self.celsius_to_fahrenheit()
        else:
            return self.temperature

    def celsius_to_fahrenheit(self):
        return self.temperature * 9 / 5 + 32

    def fahrenheit_to_celsius(self):
        return (self.temperature - 32) * 5 / 9