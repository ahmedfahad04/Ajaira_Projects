import openpyxl

class ExcelProcessor:
    def __init__(self):
        pass

    def read_excel(self, file_name):
        try:
            wb = openpyxl.load_workbook(file_name)
            ws = wb.active
            data = []
            for row in ws.rows:
                data.append([cell.value for cell in row])
            return data
        except Exception as e:
            print(f"Error reading file: {e}")
            return []

    def write_excel(self, data, file_name):
        try:
            wb = openpyxl.Workbook()
            ws = wb.active
            for row in data:
                ws.append(row)
            wb.save(file_name)
            return 1
        except Exception as e:
            print(f"Error writing file: {e}")
            return 0

    def process_excel_data(self, N, save_file_name):
        data = self.read_excel(save_file_name)
        if not data:
            return 0, None
        for row in data:
            if len(row) > N - 1:
                row[N - 1] = str(row[N - 1]).upper()
        output_file_name = f"processed_{save_file_name}"
        write_status = self.write_excel(data, output_file_name)
        return write_status, output_file_name