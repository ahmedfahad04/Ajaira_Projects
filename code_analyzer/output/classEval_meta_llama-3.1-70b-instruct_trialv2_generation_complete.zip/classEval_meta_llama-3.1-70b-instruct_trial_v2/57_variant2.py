class MetricsCalculator2:
    def __init__(self):
        pass

    @staticmethod
    def mrr(data):
        if isinstance(data[0], list):
            mrr_values = [MetricsCalculator2._mrr(d) for d in data]
            return sum(mrr_values) / len(mrr_values), mrr_values
        else:
            return MetricsCalculator2._mrr(data), [MetricsCalculator2._mrr(data)]

    @staticmethod
    def _mrr(data):
        try:
            rank = data[0].index(1) + 1
            return 1 / rank
        except ValueError:
            return 0

    @staticmethod
    def map(data):
        if isinstance(data[0], list):
            map_values = [MetricsCalculator2._map(d) for d in data]
            return sum(map_values) / len(map_values), map_values
        else:
            return MetricsCalculator2._map(data), [MetricsCalculator2._map(data)]

    @staticmethod
    def _map(data):
        precision_values = []
        correct_count = 0
        for i, value in enumerate(data[0]):
            correct_count += value
            precision_values.append(correct_count / (i + 1))
        return sum(precision_values) / len(precision_values)