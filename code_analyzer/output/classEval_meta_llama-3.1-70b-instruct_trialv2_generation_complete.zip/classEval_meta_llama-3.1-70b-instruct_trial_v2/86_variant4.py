class TicTacToe:
    def __init__(self, N=3):
        self.board = [[' ' for _ in range(N)] for _ in range(N)]
        self.current_player = 'X'
        self.N = N

    def make_move(self, row, col):
        if row < 0 or row >= self.N or col < 0 or col >= self.N or self.board[row][col] != ' ':
            return False
        self.board[row][col] = self.current_player
        self.current_player = 'O' if self.current_player == 'X' else 'X'
        return True

    def check_winner(self):
        lines = []
        for i in range(self.N):
            lines.append(self.board[i])
            lines.append([self.board[j][i] for j in range(self.N)])
        lines.append([self.board[i][i] for i in range(self.N)])
        lines.append([self.board[i][self.N - i - 1] for i in range(self.N)])
        for line in lines:
            if all([cell == line[0] for cell in line]) and line[0] != ' ':
                return line[0]
        return None

    def is_board_full(self):
        for row in self.board:
            for cell in row:
                if cell == ' ':
                    return False
        return True