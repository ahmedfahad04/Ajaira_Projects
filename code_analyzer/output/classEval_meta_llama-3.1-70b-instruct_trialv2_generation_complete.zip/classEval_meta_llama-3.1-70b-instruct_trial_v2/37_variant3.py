class EncryptionUtils:
    def __init__(self, key):
        self.key = key

    def caesar_cipher(self, plaintext, shift):
        alphabet = "abcdefghijklmnopqrstuvwxyz"
        result = ""
        for char in plaintext:
            if char.isalpha():
                index = alphabet.index(char.lower())
                new_index = (index + shift) % 26
                result += alphabet[new_index] if char.islower() else alphabet[new_index].upper()
            else:
                result += char
        return result

    def vigenere_cipher(self, plaintext):
        key_index = 0
        result = ""
        for char in plaintext:
            if char.isalpha():
                alphabet = "abcdefghijklmnopqrstuvwxyz"
                shift = alphabet.index(self.key[key_index % len(self.key)].lower())
                index = alphabet.index(char.lower())
                new_index = (index + shift) % 26
                result += alphabet[new_index] if char.islower() else alphabet[new_index].upper()
                key_index += 1
            else:
                result += char
        return result

    def rail_fence_cipher(self, plain_text, rails):
        if rails == 1:
            return plain_text
        rail_strings = [""] * rails
        rail_index = 0
        step = -1
        for char in plain_text:
            rail_strings[rail_index] += char
            if rail_index == 0:
                step = 1
            elif rail_index == rails - 1:
                step = -1
            rail_index += step
        return "".join(rail_strings)