import re

class SplitSentence:
  def split_sentences(self, sentences_string):
    return re.split('(?<=[.?\s]) +(?=[A-Z])', sentences_string)

  def count_words(self, sentence):
    return len(re.findall(r'\b\w+\b', sentence))

  def process_text_file(self, sentences_string):
    sentences = self.split_sentences(sentences_string)
    return max(self.count_words(sentence) for sentence in sentences)