import re

class AutomaticGuitarSimulator:
    def __init__(self, text):
        self.play_text = text

    def interpret(self, display=False):
        result = []
        for word in self.play_text.split():
            if word:
                match = re.match(r'([a-zA-Z]+)(\d+)', word)
                if match:
                    chord, tune = match.groups()
                    result.append({'Chord': chord, 'Tune': tune})
                    if display:
                        self.display(chord, tune)
        return result

    def display(self, key, value):
        print(f"Normal Guitar Playing -- Chord: {key}, Play Tune: {value}")