class JobMarketplace:
    def __init__(self):
        self.job_listings = {}
        self.resumes = {}

    def post_job(self, job_title, company, requirements):
        self.job_listings[job_title] = {'company': company, 'requirements': requirements}

    def remove_job(self, job):
        if 'job_title' in job and job['job_title'] in self.job_listings:
            del self.job_listings[job['job_title']]

    def submit_resume(self, name, skills, experience):
        self.resumes[name] = {'skills': skills, 'experience': experience}

    def withdraw_resume(self, resume):
        if 'name' in resume and resume['name'] in self.resumes:
            del self.resumes[resume['name']]

    def search_jobs(self, criteria):
        return [{'job_title': title, **details} for title, details in self.job_listings.items() if criteria in details['requirements']]

    def get_job_applicants(self, job):
        return [{'name': name, **details} for name, details in self.resumes.items() if all(requirement in details['skills'] for requirement in job['requirements'])]