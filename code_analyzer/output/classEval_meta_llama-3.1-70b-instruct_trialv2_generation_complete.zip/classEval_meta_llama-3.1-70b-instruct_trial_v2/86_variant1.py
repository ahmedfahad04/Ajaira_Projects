class TicTacToe:
    def __init__(self, N=3):
        self.board = [[' ' for _ in range(N)] for _ in range(N)]
        self.current_player = 'X'
        self.N = N

    def make_move(self, row, col):
        if row < 0 or row >= self.N or col < 0 or col >= self.N:
            return False
        if self.board[row][col] != ' ':
            return False
        self.board[row][col] = self.current_player
        self.current_player = 'O' if self.current_player == 'X' else 'X'
        return True

    def check_winner(self):
        for i in range(self.N):
            if all([cell == self.board[i][0] for cell in self.board[i]]) and self.board[i][0] != ' ':
                return self.board[i][0]
            if all([self.board[j][i] == self.board[0][i] for j in range(self.N)]) and self.board[0][i] != ' ':
                return self.board[0][i]
        if all([self.board[i][i] == self.board[0][0] for i in range(self.N)]) and self.board[0][0] != ' ':
            return self.board[0][0]
        if all([self.board[i][self.N - i - 1] == self.board[0][self.N - 1] for i in range(self.N)]) and self.board[0][self.N - 1] != ' ':
            return self.board[0][self.N - 1]
        return None

    def is_board_full(self):
        return all([all([cell != ' ' for cell in row]) for row in self.board])