import nltk
from nltk.stem import WordNetLemmatizer
from nltk import pos_tag, word_tokenize
import string
nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')
nltk.download('wordnet')

class Lemmatization:
    def __init__(self):
        self.lemmatizer = WordNetLemmatizer()
        
    def lemmatize_sentence(self, sentence):
        sentence = self.remove_punctuation(sentence)
        tokens = word_tokenize(sentence)
        tagged = pos_tag(tokens)
        lemmatized = []
        for word, tag in tagged:
            if tag.startswith('J'):
                lemmatized.append(self.lemmatizer.lemmatize(word, 'a'))
            elif tag.startswith('V'):
                lemmatized.append(self.lemmatizer.lemmatize(word, 'v'))
            elif tag.startswith('N'):
                lemmatized.append(self.lemmatizer.lemmatize(word, 'n'))
            elif tag.startswith('R'):
                lemmatized.append(self.lemmatizer.lemmatize(word, 'r'))
            else:
                lemmatized.append(word)
        return lemmatized
    
    def get_pos_tag(self, sentence):
        sentence = self.remove_punctuation(sentence)
        tokens = word_tokenize(sentence)
        return [tag for word, tag in pos_tag(tokens)]
    
    def remove_punctuation(self, sentence):
        return ''.join(e for e in sentence if e.isalnum() or e.isspace())