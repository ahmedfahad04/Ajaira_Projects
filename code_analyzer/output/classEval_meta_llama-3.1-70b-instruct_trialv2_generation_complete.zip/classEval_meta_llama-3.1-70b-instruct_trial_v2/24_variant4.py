import cmath

class ComplexCalculator:
    """ This is a class that implements addition, subtraction, multiplication, and division operations for complex numbers. """

    def __init__(self):
        pass

    @staticmethod
    def add(c1, c2):
        """ Adds two complex numbers.
        :param c1: The first complex number,complex.
        :param c2: The second complex number,complex.
        :return: The sum of the two complex numbers,complex.
        """
        return cmath.rect(abs(c1) + abs(c2), cmath.phase(c1) + cmath.phase(c2))

    @staticmethod
    def subtract(c1, c2):
        """ Subtracts two complex numbers.
        :param c1: The first complex number,complex.
        :param c2: The second complex number,complex.
        :return: The difference of the two complex numbers,complex.
        """
        return cmath.rect(abs(c1) - abs(c2), cmath.phase(c1) - cmath.phase(c2))

    @staticmethod
    def multiply(c1, c2):
        """ Multiplies two complex numbers.
        :param c1: The first complex number,complex.
        :param c2: The second complex number,complex.
        :return: The product of the two complex numbers,complex.
        """
        return cmath.rect(abs(c1) * abs(c2), cmath.phase(c1) + cmath.phase(c2))

    @staticmethod
    def divide(c1, c2):
        """ Divides two complex numbers.
        :param c1: The first complex number,complex.
        :param c2: The second complex number,complex.
        :return: The quotient of the two complex numbers,complex.
        """
        if c2 == 0:
            raise ZeroDivisionError("Cannot divide by zero")
        return cmath.rect(abs(c1) / abs(c2), cmath.phase(c1) - cmath.phase(c2))