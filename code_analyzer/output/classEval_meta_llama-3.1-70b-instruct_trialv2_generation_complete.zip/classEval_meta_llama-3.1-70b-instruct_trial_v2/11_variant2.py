class BitStatusUtil:
    @staticmethod
    def add(states, stat):
        if not BitStatusUtil._is_valid(states) or not BitStatusUtil._is_valid(stat):
            raise ValueError("Invalid input")
        return states | stat

    @staticmethod
    def has(states, stat):
        if not BitStatusUtil._is_valid(states) or not BitStatusUtil._is_valid(stat):
            raise ValueError("Invalid input")
        return bool(states & stat)

    @staticmethod
    def remove(states, stat):
        if not BitStatusUtil._is_valid(states) or not BitStatusUtil._is_valid(stat):
            raise ValueError("Invalid input")
        return states & ~stat

    @staticmethod
    def _is_valid(arg):
        return isinstance(arg, int) and arg >= 0 and arg % 2 == 0