class ArgumentParser:
    def __init__(self):
        self.arguments = {}
        self.required = set()
        self.types = {}

    def parse_arguments(self, command_string):
        args = command_string.split()
        i = 0
        while i < len(args):
            if args[i].startswith('-'):
                key = args[i].lstrip('-')
                if key in self.required:
                    self.required.remove(key)
                if i + 1 < len(args) and not args[i + 1].startswith('-'):
                    value = args[i + 1]
                    i += 2
                else:
                    value = True
                    i += 1
                if key in self.types:
                    self.arguments[key] = self._convert_type(key, value)
                else:
                    self.arguments[key] = value
            else:
                i += 1
        if self.required:
            return False, self.required
        return True, None

    def get_argument(self, key):
        return self.arguments.get(key)

    def add_argument(self, arg, required=False, arg_type=str):
        self.types[arg] = arg_type
        if required:
            self.required.add(arg)

    def _convert_type(self, arg, value):
        arg_type = self.types.get(arg)
        if arg_type == int:
            try:
                return int(value)
            except ValueError:
                return value
        elif arg_type == float:
            try:
                return float(value)
            except ValueError:
                return value
        elif arg_type == bool:
            return value.lower() == 'true'
        else:
            return value