class SQLQueryBuilder:
    @staticmethod
    def select(table, columns='*', where=None):
        query = f"SELECT {columns} FROM {table}"
        if where:
            query += " WHERE "
            query += " AND ".join(f"{key}='{value}'" for key, value in where.items())
        return query

    @staticmethod
    def insert(table, data):
        columns = ', '.join(data.keys())
        values = ', '.join(f"'{value}'" for value in data.values())
        return f"INSERT INTO {table} ({columns}) VALUES ({values})"

    @staticmethod
    def delete(table, where=None):
        query = f"DELETE FROM {table}"
        if where:
            query += " WHERE "
            query += " AND ".join(f"{key}='{value}'" for key, value in where.items())
        return query

    @staticmethod
    def update(table, data, where=None):
        sets = [f"{key}='{value}'" for key, value in data.items()]
        query = f"UPDATE {table} SET "
        query += ", ".join(sets)
        if where:
            query += " WHERE "
            query += " AND ".join(f"{key}='{value}'" for key, value in where.items())
        return query