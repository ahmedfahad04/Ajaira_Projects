import itertools

class ArrangementCalculator:
    def __init__(self, datas):
        self.datas = datas

    @staticmethod
    def count(n, m=None):
        if m is None or n == m:
            return ArrangementCalculator.factorial(n)
        return ArrangementCalculator.factorial(n) // ArrangementCalculator.factorial(n - m)

    @staticmethod
    def count_all(n):
        total = 0
        for i in range(1, n + 1):
            total += ArrangementCalculator.factorial(n) // ArrangementCalculator.factorial(n - i)
        return total

    def select(self, m=None):
        if m is None:
            m = len(self.datas)
        return list(itertools.permutations(self.datas, m))

    def select_all(self):
        result = []
        for r in range(1, len(self.datas) + 1):
            for p in itertools.permutations(self.datas, r):
                result.append(list(p))
        return result

    @staticmethod
    def factorial(n):
        if n == 0:
            return 1
        else:
            return n * ArrangementCalculator.factorial(n - 1)