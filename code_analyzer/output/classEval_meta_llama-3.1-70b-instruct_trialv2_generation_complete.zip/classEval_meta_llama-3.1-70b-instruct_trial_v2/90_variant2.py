class URLHandler:
    """ The class supports to handle URLs, including extracting the scheme, host, path, query parameters, and fragment. """

    def __init__(self, url):
        """ Initialize URLHandler's URL """
        self.url = url
        self.scheme = None
        self.host = None
        self.path = None
        self.query_params = None
        self.fragment = None
        self.parse_url()

    def parse_url(self):
        protocol_end = self.url.find("://")
        if protocol_end != -1:
            self.scheme = self.url[:protocol_end]
            url_without_scheme = self.url[protocol_end + 3:]
        else:
            url_without_scheme = self.url

        host_end = url_without_scheme.find("/")
        if host_end != -1:
            self.host = url_without_scheme[:host_end]
            url_without_host = url_without_scheme[host_end:]
        else:
            self.host = url_without_scheme
            url_without_host = ""

        query_start = url_without_host.find("?")
        if query_start != -1:
            self.path = url_without_host[:query_start]
            query_params_str = url_without_host[query_start + 1:]
        else:
            self.path = url_without_host
            query_params_str = ""

        self.query_params = self.parse_query_params(query_params_str)

        fragment_start = self.path.find("#")
        if fragment_start != -1:
            self.fragment = self.path[fragment_start + 1:]
            self.path = self.path[:fragment_start]
        else:
            self.fragment = ""

    def parse_query_params(self, query_params_str):
        query_params = {}
        params = query_params_str.split("&")
        for param in params:
            key_value = param.split("=")
            if len(key_value) == 2:
                query_params[key_value[0]] = key_value[1]
        return query_params

    def get_scheme(self):
        """ get the scheme of the URL :return: string, If successful, return the scheme of the URL """
        return self.scheme

    def get_host(self):
        """ Get the second part of the URL, which is the host domain name :return: string, If successful, return the host domain name of the URL """
        return self.host

    def get_path(self):
        """ Get the third part of the URL, which is the address of the resource :return: string, If successful, return the address of the resource of the URL """
        return self.path

    def get_query_params(self):
        """ Get the request parameters for the URL :return: dict, If successful, return the request parameters of the URL """
        return self.query_params

    def get_fragment(self):
        """ Get the fragment after '#' in the URL :return: string, If successful, return the fragment after '#' of the URL """
        return self.fragment