import socket
import netifaces

class IpUtil:
    @staticmethod
    def is_valid_ipv4(ip_address):
        parts = ip_address.split('.')
        if len(parts) != 4:
            return False
        for item in parts:
            if not item.isdigit():
                return False
            if not 0 <= int(item) <= 255:
                return False
        return True

    @staticmethod
    def is_valid_ipv6(ip_address):
        parts = ip_address.split(':')
        if len(parts) != 8:
            return False
        for item in parts:
            if len(item) > 4:
                return False
            try:
                int(item, 16)
            except ValueError:
                return False
        return True

    @staticmethod
    def get_hostname(ip_address):
        try:
            return socket.gethostbyaddr(ip_address)[0]
        except socket.herror:
            return None