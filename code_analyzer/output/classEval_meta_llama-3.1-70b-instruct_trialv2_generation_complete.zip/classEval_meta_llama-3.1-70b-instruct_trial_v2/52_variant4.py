import nltk
from nltk.stem import WordNetLemmatizer
from nltk import pos_tag, word_tokenize
import string
nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')
nltk.download('wordnet')

class Lemmatization:
    def __init__(self):
        self.lemmatizer = WordNetLemmatizer()
        self.tag_map = {'JJ': 'a', 'VB': 'v', 'NN': 'n', 'RB': 'r'}
        
    def lemmatize_sentence(self, sentence):
        sentence = self.remove_punctuation(sentence)
        tokens = word_tokenize(sentence)
        tagged = pos_tag(tokens)
        lemmatized = [self.lemmatize_word(word, tag) for word, tag in tagged]
        return lemmatized
    
    def get_pos_tag(self, sentence):
        sentence = self.remove_punctuation(sentence)
        tokens = word_tokenize(sentence)
        return [tag for word, tag in pos_tag(tokens)]
    
    def remove_punctuation(self, sentence):
        return ''.join(c for c in sentence if c not in string.punctuation)
    
    def lemmatize_word(self, word, tag):
        return self.lemmatizer.lemmatize(word, self.tag_map.get(tag[:2], 'n'))