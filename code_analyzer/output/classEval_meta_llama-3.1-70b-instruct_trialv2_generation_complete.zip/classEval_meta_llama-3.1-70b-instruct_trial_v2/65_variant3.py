class NumberWordFormatter:
    def __init__(self):
        self.NUMBER = ["", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE"]
        self.NUMBER_TEEN = ["TEN", "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN", "SEVENTEEN", "EIGHTEEN", "NINETEEN"]
        self.NUMBER_TEN = ["TEN", "TWENTY", "THIRTY", "FORTY", "FIFTY", "SIXTY", "SEVENTY", "EIGHTY", "NINETY"]
        self.NUMBER_MORE = ["", "THOUSAND", "MILLION", "BILLION"]
        self.NUMBER_SUFFIX = ["k", "w", "", "m", "", "", "b", "", "", "t", "", "", "p", "", "", "e"]

    def format(self, x):
        return self.format_string(str(x))

    def format_string(self, x):
        if '.' in x:
            integer_part, decimal_part = x.split('.')
        else:
            integer_part, decimal_part = x, '0'
        integer_part_words = self.trans_number(integer_part)
        decimal_part_words = self.trans_number(decimal_part)
        return f"{integer_part_words} ONLY {decimal_part_words} ONLY"

    def trans_number(self, s):
        s = s.zfill(3)
        if len(s) == 3:
            return self.trans_three(s)
        elif len(s) == 2:
            return self.trans_two(s)
        elif len(s) == 1:
            return self.NUMBER[int(s)]

    def trans_two(self, s):
        if int(s) < 10:
            return self.NUMBER[int(s)]
        elif int(s) < 20:
            return self.NUMBER_TEEN[int(s) - 10]
        else:
            return self.NUMBER_TEN[int(s) // 10 - 1] + ('' if int(s) % 10 == 0 else ' ' + self.NUMBER[int(s) % 10])

    def trans_three(self, s):
        if int(s) == 0:
            return ''
        elif int(s) < 100:
            return self.trans_two(s)
        else:
            return self.NUMBER[int(s) // 100] + ' HUNDRED' + ('' if int(s) % 100 == 0 else ' AND ' + self.trans_two(s[1:]))

    def parse_more(self, i):
        return self.NUMBER_MORE[i]

    def get_more(self, i):
        return self.parse_more(i) if i < len(self.NUMBER_MORE) else ''