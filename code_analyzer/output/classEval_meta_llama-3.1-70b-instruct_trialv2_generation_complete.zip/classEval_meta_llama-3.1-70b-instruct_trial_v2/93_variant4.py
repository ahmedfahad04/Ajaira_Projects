import numpy as np
from gensim import matutils
from numpy import dot, array

class VectorUtil:
    @staticmethod
    def similarity(vector_1, vector_2):
        return dot(vector_1, vector_2) / (np.linalg.norm(vector_1) * np.linalg.norm(vector_2))

    @staticmethod
    def cosine_similarities(vector_1, vectors_all):
        return [matutils.cossim(vector_1, vector) for vector in vectors_all]

    @staticmethod
    def n_similarity(vector_list_1, vector_list_2):
        return np.mean([VectorUtil.cosine_similarities(vector1, vector_list_2)[0] for vector1 in vector_list_1])

    @staticmethod
    def compute_idf_weight_dict(total_num, number_dict):
        return {key: np.log((total_num + 1) / (value + 1)) for key, value in number_dict.items()}