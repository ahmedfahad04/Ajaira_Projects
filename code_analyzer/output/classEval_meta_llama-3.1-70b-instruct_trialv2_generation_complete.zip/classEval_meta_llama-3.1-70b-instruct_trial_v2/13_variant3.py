class BookManagement:
    def __init__(self):
        self.inventory = {}

    def add_book(self, title, quantity=1):
        if title in self.inventory:
            self.inventory[title] += quantity
        else:
            self.inventory[title] = quantity
        self.inventory = dict(sorted(self.inventory.items()))

    def remove_book(self, title, quantity):
        if title in self.inventory:
            if self.inventory[title] >= quantity:
                self.inventory[title] -= quantity
                if self.inventory[title] == 0:
                    del self.inventory[title]
            else:
                raise ValueError("Not enough quantity to remove")
        else:
            raise ValueError("Book not found in inventory")
        self.inventory = dict(sorted(self.inventory.items()))

    def view_inventory(self):
        return self.inventory

    def view_book_quantity(self, title):
        return self.inventory.get(title, 0)