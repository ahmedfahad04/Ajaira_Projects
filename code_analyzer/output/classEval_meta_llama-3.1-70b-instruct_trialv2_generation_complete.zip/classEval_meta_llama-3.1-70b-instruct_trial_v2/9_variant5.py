class BigNumCalculator:
    @staticmethod
    def add(num1, num2):
        max_len = max(len(num1), len(num2))
        num1 = num1.zfill(max_len)
        num2 = num2.zfill(max_len)
        result = [0] * (max_len + 1)
        for i in range(max_len-1, -1, -1):
            total = int(num1[i]) + int(num2[i]) + result[i+1]
            result[i+1] = total % 10
            result[i] += total // 10
        return ''.join(map(str, result)).lstrip('0') or '0'

    @staticmethod
    def subtract(num1, num2):
        max_len = max(len(num1), len(num2))
        num1 = num1.zfill(max_len)
        num2 = num2.zfill(max_len)
        result = [0] * max_len
        borrow = 0
        for i in range(max_len-1, -1, -1):
            total = int(num1[i]) - int(num2[i]) - borrow
            if total < 0:
                total += 10
                borrow = 1
            else:
                borrow = 0
            result[i] = total
        return ''.join(map(str, result)).lstrip('0') or '0'

    @staticmethod
    def multiply(num1, num2):
        result = [0] * (len(num1) + len(num2))
        for i in range(len(num1)-1, -1, -1):
            for j in range(len(num2)-1, -1, -1):
                result[i+j+1] += int(num1[i]) * int(num2[j])
                result[i+j] += result[i+j+1] // 10
                result[i+j+1] %= 10
        return ''.join(map(str, result)).lstrip('0') or '0'