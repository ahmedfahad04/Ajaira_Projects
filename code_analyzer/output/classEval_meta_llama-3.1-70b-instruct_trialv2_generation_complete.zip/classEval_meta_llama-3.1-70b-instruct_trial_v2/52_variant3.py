import nltk
from nltk.stem import WordNetLemmatizer
from nltk import pos_tag, word_tokenize
import string
nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')
nltk.download('wordnet')

class Lemmatization:
    def __init__(self):
        self.lemmatizer = WordNetLemmatizer()
        
    def lemmatize_sentence(self, sentence):
        sentence = self.remove_punctuation(sentence)
        tokens = word_tokenize(sentence)
        tagged = pos_tag(tokens)
        lemmatized = [self.get_lemmatized_word(word, tag) for word, tag in tagged]
        return lemmatized
    
    def get_pos_tag(self, sentence):
        sentence = self.remove_punctuation(sentence)
        tokens = word_tokenize(sentence)
        return [tag for word, tag in pos_tag(tokens)]
    
    def remove_punctuation(self, sentence):
        return sentence.translate(str.maketrans('', '', string.punctuation))
    
    def get_lemmatized_word(self, word, tag):
        if tag.startswith('J'):
            return self.lemmatizer.lemmatize(word, 'a')
        elif tag.startswith('V'):
            return self.lemmatizer.lemmatize(word, 'v')
        elif tag.startswith('N'):
            return self.lemmatizer.lemmatize(word, 'n')
        elif tag.startswith('R'):
            return self.lemmatizer.lemmatize(word, 'r')
        else:
            return word