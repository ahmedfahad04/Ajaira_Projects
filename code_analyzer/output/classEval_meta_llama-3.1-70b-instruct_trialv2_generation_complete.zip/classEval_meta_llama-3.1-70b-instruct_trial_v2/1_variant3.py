import math

class AreaCalculator:
    def __init__(self, radius):
        self.radius = radius

    def calculate_circle_area(self):
        return math.pi * (self.radius ** 2)

    def calculate_sphere_area(self):
        return 4 * self.calculate_circle_area()

    def calculate_cylinder_area(self, height):
        base_area = self.calculate_circle_area()
        lateral_area = 2 * math.pi * self.radius * height
        return 2 * base_area + lateral_area

    def calculate_sector_area(self, angle):
        return (angle / (2 * math.pi)) * self.calculate_circle_area()

    def calculate_annulus_area(self, inner_radius, outer_radius):
        outer_area = math.pi * (outer_radius ** 2)
        inner_area = math.pi * (inner_radius ** 2)
        return outer_area - inner_area