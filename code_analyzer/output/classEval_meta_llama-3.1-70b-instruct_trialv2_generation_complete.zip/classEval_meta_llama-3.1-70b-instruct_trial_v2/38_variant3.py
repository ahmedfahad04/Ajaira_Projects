import openpyxl
import pandas as pd

class ExcelProcessor:
    def __init__(self):
        pass

    def read_excel(self, file_name):
        try:
            df = pd.read_excel(file_name)
            return df.values.tolist()
        except Exception as e:
            print(f"Error reading file: {e}")
            return []

    def write_excel(self, data, file_name):
        try:
            df = pd.DataFrame(data)
            df.to_excel(file_name, index=False)
            return 1
        except Exception as e:
            print(f"Error writing file: {e}")
            return 0

    def process_excel_data(self, N, save_file_name):
        data = self.read_excel(save_file_name)
        if not data:
            return 0, None
        for row in data:
            if len(row) > N - 1:
                row[N - 1] = str(row[N - 1]).upper()
        output_file_name = f"processed_{save_file_name}"
        write_status = self.write_excel(data, output_file_name)
        return write_status, output_file_name