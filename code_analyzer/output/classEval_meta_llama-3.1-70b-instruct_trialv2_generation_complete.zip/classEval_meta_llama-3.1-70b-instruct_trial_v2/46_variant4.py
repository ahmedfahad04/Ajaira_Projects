import scipy.interpolate as interp

class Interpolation:
    """ This is a class that implements the Linear interpolation operation of one-dimensional and two-dimensional data """
    def __init__(self):
        pass

    @staticmethod
    def interpolate_1d(x, y, x_interp):
        """ Linear interpolation of one-dimensional data
        :param x: The x-coordinate of the data point, list.
        :param y: The y-coordinate of the data point, list.
        :param x_interp: The x-coordinate of the interpolation point, list.
        :return: The y-coordinate of the interpolation point, list.
        """
        f = interp.interp1d(x, y)
        y_interp = f(x_interp)
        return y_interp.tolist()

    @staticmethod
    def interpolate_2d(x, y, z, x_interp, y_interp):
        """ Linear interpolation of two-dimensional data
        :param x: The x-coordinate of the data point, list.
        :param y: The y-coordinate of the data point, list.
        :param z: The z-coordinate of the data point, list.
        :param x_interp: The x-coordinate of the interpolation point, list.
        :param y_interp: The y-coordinate of the interpolation point, list.
        :return: The z-coordinate of the interpolation point, list.
        """
        f = interp.interp2d(x, y, z)
        z_interp = f(x_interp, y_interp)
        return z_interp.tolist()