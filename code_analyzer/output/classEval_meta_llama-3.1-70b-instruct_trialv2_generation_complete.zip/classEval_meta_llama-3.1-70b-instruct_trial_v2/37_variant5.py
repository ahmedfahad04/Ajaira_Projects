class EncryptionUtils:
    def __init__(self, key):
        self.key = key

    def caesar_cipher(self, plaintext, shift):
        result = ""
        for char in plaintext:
            if char.isalpha():
                ascii_offset = 65 if char.isupper() else 97
                result += chr((ord(char) - ascii_offset + shift) % 26 + ascii_offset)
            else:
                result += char
        return result

    def vigenere_cipher(self, plaintext):
        key_index = 0
        result = ""
        for char in plaintext:
            if char.isalpha():
                ascii_offset = 65 if char.isupper() else 97
                shift = ord(self.key[key_index % len(self.key)].lower()) - 97
                result += chr((ord(char) - ascii_offset + shift) % 26 + ascii_offset)
                key_index += 1
            else:
                result += char
        return result

    def rail_fence_cipher(self, plain_text, rails):
        if rails == 1:
            return plain_text
        rail_strings = [""] * rails
        rail_index = 0
        step = -1
        for char in plain_text:
            rail_strings[rail_index] += char
            if rail_index == 0:
                step = 1
            elif rail_index == rails - 1:
                step = -1
            rail_index += step
        result = ""
        for rail_string in rail_strings:
            result += rail_string
        return result