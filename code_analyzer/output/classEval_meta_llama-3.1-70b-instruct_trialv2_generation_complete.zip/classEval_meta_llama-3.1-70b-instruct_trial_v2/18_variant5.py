class CamelCaseMap:
    def __init__(self):
        self._data = {}

    def __getitem__(self, key):
        return self._data[self._convert_key(key)]

    def __setitem__(self, key, value):
        self._data[self._convert_key(key)] = value

    def __delitem__(self, key):
        del self._data[self._convert_key(key)]

    def __iter__(self):
        return iter(self._data)

    def __len__(self):
        return len(self._data)

    def _convert_key(self, key):
        result = ''
        capitalize_next = False
        for char in key:
            if char == '_':
                capitalize_next = True
            else:
                if capitalize_next:
                    result += char.upper()
                    capitalize_next = False
                else:
                    result += char
        return result

    @staticmethod
    def _to_camel_case(key):
        return CamelCaseMap._convert_key(key)