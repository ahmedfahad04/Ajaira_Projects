from datetime import datetime

class Classroom:
    def __init__(self, id):
        self.id = id
        self.courses = []

    def add_course(self, course):
        if course not in self.courses:
            self.courses.append(course)

    def remove_course(self, course):
        if course in self.courses:
            self.courses.remove(course)

    def is_free_at(self, check_time):
        time_slots = [datetime.strptime(course['start_time'], '%H:%M') for course in self.courses] + [datetime.strptime(course['end_time'], '%H:%M') for course in self.courses]
        time_slots.sort()
        for i in range(0, len(time_slots), 2):
            if time_slots[i] <= datetime.strptime(check_time, '%H:%M') < time_slots[i+1]:
                return False
        return True

    def check_course_conflict(self, new_course):
        new_start_time = datetime.strptime(new_course['start_time'], '%H:%M')
        new_end_time = datetime.strptime(new_course['end_time'], '%H:%M')
        for course in self.courses:
            start_time = datetime.strptime(course['start_time'], '%H:%M')
            end_time = datetime.strptime(course['end_time'], '%H:%M')
            if (start_time < new_end_time and new_start_time < end_time) or (start_time == new_start_time and end_time == new_end_time):
                return False
        return True