class BitStatusUtil:
    @staticmethod
    def add(states, stat):
        BitStatusUtil.check(states, stat)
        return states | stat

    @staticmethod
    def has(states, stat):
        BitStatusUtil.check(states, stat)
        return bool(states & stat)

    @staticmethod
    def remove(states, stat):
        BitStatusUtil.check(states, stat)
        return states & ~stat

    @staticmethod
    def check(states, stat):
        if not (isinstance(states, int) and isinstance(stat, int) and states >= 0 and stat >= 0 and states % 2 == 0 and stat % 2 == 0):
            raise ValueError("Invalid input")