class DiscountStrategy:
    def __init__(self, customer, cart, promotion=None):
        self.customer = customer
        self.cart = cart
        self.promotion = promotion
        self.total_cost = self.total()

    def total(self):
        return sum(item['quantity'] * item['price'] for item in self.cart)

    def due(self):
        if self.promotion:
            return self.total_cost - self.promotion(self)
        else:
            return self.total_cost

    @staticmethod
    def FidelityPromo(order):
        if order.customer['fidelity'] > 1000:
            return order.total_cost * 0.05
        else:
            return 0

    @staticmethod
    def BulkItemPromo(order):
        discount = 0
        for item in order.cart:
            if item['quantity'] >= 20:
                discount += item['quantity'] * item['price'] * 0.1
        return discount

    @staticmethod
    def LargeOrderPromo(order):
        unique_products = len(set(item['product'] for item in order.cart))
        if unique_products >= 10:
            return order.total_cost * 0.07
        else:
            return 0