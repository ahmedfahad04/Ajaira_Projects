class AvgPartition:
    def __init__(self, lst, limit):
        if limit <= 0:
            raise ValueError("Number of partitions must be greater than 0")
        self.lst = lst
        self.limit = limit

    def setNum(self):
        block_size, remainder = divmod(len(self.lst), self.limit)
        return block_size, remainder

    def get(self, index):
        block_size, remainder = self.setNum()
        start = index * block_size + min(index, remainder)
        end = start + block_size + (1 if index < remainder else 0)
        return self.lst[start:end]