from math import pi, fabs

class TriCalculator:
    def __init__(self):
        pass

    def cos(self, x):
        return self.taylor(x, 100)

    def factorial(self, a):
        result = 1
        for i in range(1, a+1):
            result *= i
        return result

    def taylor(self, x, n):
        result = 0
        for i in range(n):
            result += ((-1)**i) * ((x / 180 * pi)**(2*i)) / self.factorial(2*i)
        return result

    def sin(self, x):
        return self.taylor_sin(x, 100)

    def tan(self, x):
        return self.sin(x) / self.cos(x)

    def taylor_sin(self, x, n):
        result = 0
        for i in range(n):
            result += ((-1)**i) * ((x / 180 * pi)**(2*i+1)) / self.factorial(2*i+1)
        return result