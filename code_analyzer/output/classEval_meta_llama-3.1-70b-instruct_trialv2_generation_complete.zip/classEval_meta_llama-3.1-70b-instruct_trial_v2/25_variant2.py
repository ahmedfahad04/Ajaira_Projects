import json

class CookiesUtil:
    def __init__(self, cookies_file):
        self.cookies_file = cookies_file
        self.cookies = self.load_cookies()

    def get_cookies(self, response):
        self.cookies = response.get('cookies', {})
        self._save_cookies()

    def load_cookies(self):
        try:
            with open(self.cookies_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return {}

    def _save_cookies(self):
        try:
            with open(self.cookies_file, 'w') as f:
                json.dump(self.cookies, f)
            return True
        except Exception:
            return False