class MetricsCalculator2:
    def __init__(self):
        pass

    @staticmethod
    def mrr(data):
        if isinstance(data[0], list):
            mrr_values = []
            for d in data:
                mrr_values.append(MetricsCalculator2._calculate_mrr(d[0], d[1]))
            return sum(mrr_values) / len(mrr_values), mrr_values
        else:
            return MetricsCalculator2._calculate_mrr(data[0], data[1]), [MetricsCalculator2._calculate_mrr(data[0], data[1])]

    @staticmethod
    def _calculate_mrr(actual, ground_truth):
        try:
            rank = actual.index(1) + 1
            return 1 / rank
        except ValueError:
            return 0

    @staticmethod
    def map(data):
        if isinstance(data[0], list):
            map_values = []
            for d in data:
                map_values.append(MetricsCalculator2._calculate_map(d[0], d[1]))
            return sum(map_values) / len(map_values), map_values
        else:
            return MetricsCalculator2._calculate_map(data[0], data[1]), [MetricsCalculator2._calculate_map(data[0], data[1])]

    @staticmethod
    def _calculate_map(actual, ground_truth):
        precision_values = []
        correct_count = 0
        for i, value in enumerate(actual):
            correct_count += value
            precision_values.append(correct_count / (i + 1))
        return sum(precision_values) / len(precision_values)