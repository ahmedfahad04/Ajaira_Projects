import re

class SplitSentence:
  def split_sentences(self, sentences_string):
    sentences = sentences_string.replace('?', '.').replace('..', '.').split('. ')
    return [s + '.' for s in sentences if s]

  def count_words(self, sentence):
    words = sentence.replace('.', '').split()
    return len(words)

  def process_text_file(self, sentences_string):
    sentences = self.split_sentences(sentences_string)
    return max(self.count_words(sentence) for sentence in sentences)