import math
import numpy as np

class Statistics3:
    @staticmethod
    def median(data):
        data.sort()
        n = len(data)
        if n % 2 == 0:
            return (data[n // 2 - 1] + data[n // 2]) / 2
        else:
            return data[n // 2]

    @staticmethod
    def mode(data):
        freq_dict = {}
        for num in data:
            freq_dict[num] = freq_dict.get(num, 0) + 1
        max_freq = max(freq_dict.values())
        modes = [num for num, freq in freq_dict.items() if freq == max_freq]
        return modes

    @staticmethod
    def correlation(x, y):
        n = len(x)
        mean_x = sum(x) / n
        mean_y = sum(y) / n
        numerator = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(n))
        denominator = math.sqrt(sum((x[i] - mean_x) ** 2 for i in range(n))) * math.sqrt(sum((y[i] - mean_y) ** 2 for i in range(n)))
        return numerator / denominator

    @staticmethod
    def mean(data):
        return sum(data) / len(data)

    @staticmethod
    def correlation_matrix(data):
        n = len(data)
        corr_matrix = [[1.0 for _ in range(n)] for _ in range(n)]
        for i in range(n):
            for j in range(i, n):
                corr_matrix[i][j] = Statistics3.correlation(data[i], data[j])
                corr_matrix[j][i] = corr_matrix[i][j]
        return corr_matrix

    @staticmethod
    def standard_deviation(data):
        mean = Statistics3.mean(data)
        return math.sqrt(sum((x - mean) ** 2 for x in data) / len(data))

    @staticmethod
    def z_score(data):
        mean = Statistics3.mean(data)
        std_dev = Statistics3.standard_deviation(data)
        return [(x - mean) / std_dev for x in data]