class NumericEntityUnescaper:
    def __init__(self):
        pass

    def replace(self, string):
        import re
        def replace(match):
            return chr(int(match.group(1), 16) if match.group(2) == 'x' else int(match.group(1)))
        return re.sub(r'&#x?(\d+)(?:;|$)', replace, string)

    @staticmethod
    def is_hex_char(char):
        return char.isdigit() or 'a' <= char.lower() <= 'f'