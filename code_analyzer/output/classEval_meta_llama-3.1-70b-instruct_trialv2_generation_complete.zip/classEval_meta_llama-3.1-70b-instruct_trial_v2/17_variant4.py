from datetime import datetime, timedelta

class CalendarUtil:
    def __init__(self):
        self.events = []

    def add_event(self, event):
        self.events.append(event)
        self.events.sort(key=lambda x: x['start_time'])

    def remove_event(self, event):
        self.events = [e for e in self.events if e != event]

    def get_events(self, date):
        return [e for e in self.events if e['date'] == date]

    def is_available(self, start_time, end_time):
        for event in self.events:
            if event['start_time'] < end_time and event['end_time'] > start_time:
                return False
        return True

    def get_available_slots(self, date):
        slots = []
        events = self.get_events(date)
        if not events:
            return [(date, datetime(date.year, date.month, date.day, 23, 59))]
        events.append({'start_time': datetime(date.year, date.month, date.day, 23, 59), 'end_time': datetime(date.year, date.month, date.day, 23, 59)})
        events.sort(key=lambda x: x['start_time'])
        for i in range(len(events) - 1):
            if events[i]['end_time'] < events[i+1]['start_time']:
                slots.append((events[i]['end_time'], events[i+1]['start_time']))
        return slots

    def get_upcoming_events(self, num_events):
        upcoming_events = [e for e in self.events if e['start_time'] > datetime.now()]
        return upcoming_events[:num_events]