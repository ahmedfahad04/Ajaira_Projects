import math
import pandas as pd

class DataStatistics4:
    @staticmethod
    def correlation_coefficient(data1, data2):
        df = pd.DataFrame({'A': data1, 'B': data2})
        return df['A'].corr(df['B'])

    @staticmethod
    def skewness(data):
        return pd.Series(data).skew()

    @staticmethod
    def kurtosis(data):
        return pd.Series(data).kurtosis()

    @staticmethod
    def pdf(data, mu, sigma):
        return [math.exp(-((x - mu) ** 2) / (2 * sigma ** 2)) / (sigma * math.sqrt(2 * math.pi)) for x in data]