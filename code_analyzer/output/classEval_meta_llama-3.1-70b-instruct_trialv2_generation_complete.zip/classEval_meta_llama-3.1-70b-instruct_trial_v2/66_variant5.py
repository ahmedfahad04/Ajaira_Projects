class NumericEntityUnescaper:
    def __init__(self):
        pass

    def replace(self, string):
        stack = []
        result = ''
        for char in string:
            if char == '&':
                stack.append(char)
            elif char == '#':
                if stack and stack[-1] == '&':
                    stack.append(char)
            elif char == 'x':
                if len(stack) >= 2 and stack[-2:] == ['&', '#']:
                    stack.append(char)
            elif char == ';':
                if stack:
                    code = ''.join(stack[2:])
                    if stack[1] == '#':
                        if stack[2] == 'x':
                            result += chr(int(code, 16))
                        else:
                            result += chr(int(code))
                    stack = []
                else:
                    result += char
            elif stack and stack[-1].isdigit() or (stack and len(stack) >= 3 and stack[-3:] == ['&', '#', 'x'] and char.lower() in 'abcdef'):
                stack.append(char)
            else:
                if stack:
                    result += ''.join(stack)
                    stack = []
                result += char
        if stack:
            result += ''.join(stack)
        return result

    @staticmethod
    def is_hex_char(char):
        return char.isdigit() or 'a' <= char.lower() <= 'f'