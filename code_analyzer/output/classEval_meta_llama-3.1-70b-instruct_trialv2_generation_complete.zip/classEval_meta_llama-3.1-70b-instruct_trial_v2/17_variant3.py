from datetime import datetime, timedelta

class CalendarUtil:
    def __init__(self):
        self.events = []

    def add_event(self, event):
        self.events.append(event)

    def remove_event(self, event):
        self.events = [e for e in self.events if e != event]

    def get_events(self, date):
        return [e for e in self.events if e['date'] == date]

    def is_available(self, start_time, end_time):
        for event in self.events:
            if event['start_time'] < end_time and event['end_time'] > start_time:
                return False
        return True

    def get_available_slots(self, date):
        slots = []
        events = sorted(self.get_events(date), key=lambda x: x['start_time'])
        start_time = date
        for event in events:
            if event['start_time'] > start_time:
                slots.append((start_time, event['start_time']))
            start_time = event['end_time']
        if start_time < datetime(date.year, date.month, date.day, 23, 59):
            slots.append((start_time, datetime(date.year, date.month, date.day, 23, 59)))
        return slots

    def get_upcoming_events(self, num_events):
        upcoming_events = sorted(self.events, key=lambda x: x['start_time'])
        today = datetime.now()
        upcoming_events = [e for e in upcoming_events if e['start_time'] > today]
        return upcoming_events[:num_events]