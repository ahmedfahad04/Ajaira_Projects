from datetime import datetime
from collections import defaultdict

class Chat:
    def __init__(self):
        self.users = defaultdict(list)

    def add_user(self, username):
        if not self.users[username]:
            return True
        return False

    def remove_user(self, username):
        if self.users[username]:
            del self.users[username]
            return True
        return False

    def send_message(self, sender, receiver, message):
        if self.users[sender] and self.users[receiver]:
            self.users[receiver].append({
                'sender': sender,
                'receiver': receiver,
                'message': message,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            })
            return True
        return False

    def get_messages(self, username):
        return self.users[username]