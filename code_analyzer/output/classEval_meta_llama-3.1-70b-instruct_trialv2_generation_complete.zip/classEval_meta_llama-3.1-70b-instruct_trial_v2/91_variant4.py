import urllib.parse

class UrlPath:
  def __init__(self):
    self.segments = []
    self.with_end_tag = False

  def add(self, segment):
    self.segments.append(segment)

  def parse(self, path, charset):
    fixed_path = self.fix_path(path)
    self.segments = [segment for segment in fixed_path.split('/') if segment != '']

  @staticmethod
  def fix_path(path):
    return path.strip('/')