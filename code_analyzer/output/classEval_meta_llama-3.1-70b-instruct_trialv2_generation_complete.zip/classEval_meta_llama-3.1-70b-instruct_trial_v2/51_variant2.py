import numpy as np

class KappaCalculator:
    @staticmethod
    def kappa(testData, k):
        n = len(testData)
        p_o = sum([testData[i][i] for i in range(n)]) / n
        p_e = sum([sum([x ** 2 for x in row]) for row in testData]) / (n ** 2)
        kappa = (p_o - p_e) / (1 - p_e)
        return kappa

    @staticmethod
    def fleiss_kappa(testData, N, k, n):
        p_o = sum([sum([x ** 2 for x in row]) for row in testData]) / (N * n ** 2)
        p_e = sum([sum([row[i] for row in testData]) / (N * n) for i in range(k)]) ** 2
        kappa = (p_o - p_e) / (1 - p_e)
        return kappa