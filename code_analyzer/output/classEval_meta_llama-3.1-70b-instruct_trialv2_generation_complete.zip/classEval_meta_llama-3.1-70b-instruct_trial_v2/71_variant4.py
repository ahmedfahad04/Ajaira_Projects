class PushBoxGame:
    def __init__(self, map):
        self.map = map
        self.player_row = 0
        self.player_col = 0
        self.targets = []
        self.boxes = []
        self.target_count = 0
        self.is_game_over = False
        self.init_game()

    def init_game(self):
        for i, row in enumerate(self.map):
            for j, char in enumerate(row):
                if char == 'O':
                    self.player_row = i
                    self.player_col = j
                elif char == 'G':
                    self.targets.append((i, j))
                    self.target_count += 1
                elif char == 'X':
                    self.boxes.append((i, j))

    def check_win(self):
        self.is_game_over = len(self.boxes) == self.target_count and all(box in self.targets for box in self.boxes)
        return self.is_game_over

    def move(self, direction):
        new_row = self.player_row
        new_col = self.player_col
        if direction == 'w':
            new_row -= 1
        elif direction == 's':
            new_row += 1
        elif direction == 'a':
            new_col -= 1
        elif direction == 'd':
            new_col += 1

        if self.map[new_row][new_col] == '#':
            return False

        if (new_row, new_col) in self.boxes:
            box_row = new_row
            box_col = new_col
            if direction == 'w':
                box_row -= 1
            elif direction == 's':
                box_row += 1
            elif direction == 'a':
                box_col -= 1
            elif direction == 'd':
                box_col += 1

            if self.map[box_row][box_col] == '#':
                return False
            elif (box_row, box_col) in self.boxes:
                return False

            self.boxes.remove((new_row, new_col))
            self.boxes.append((box_row, box_col))

        self.player_row = new_row
        self.player_col = new_col
        return self.check_win()