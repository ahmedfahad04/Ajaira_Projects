class EightPuzzle:
    def __init__(self, initial_state):
        self.initial_state = initial_state
        self.goal_state = [[1, 2, 3], [4, 5, 6], [7, 8, 0]]

    def find_blank(self, state):
        for i, row in enumerate(state):
            if 0 in row:
                return i, row.index(0)

    def move(self, state, direction):
        i, j = self.find_blank(state)
        new_state = [row[:] for row in state]
        if direction == 'up':
            new_state[i][j], new_state[i-1][j] = new_state[i-1][j], new_state[i][j]
        elif direction == 'down':
            new_state[i][j], new_state[i+1][j] = new_state[i+1][j], new_state[i][j]
        elif direction == 'left':
            new_state[i][j], new_state[i][j-1] = new_state[i][j-1], new_state[i][j]
        elif direction == 'right':
            new_state[i][j], new_state[i][j+1] = new_state[i][j+1], new_state[i][j]
        return new_state

    def get_possible_moves(self, state):
        i, j = self.find_blank(state)
        moves = []
        if i > 0:
            moves.append('up')
        if i < 2:
            moves.append('down')
        if j > 0:
            moves.append('left')
        if j < 2:
            moves.append('right')
        return moves

    def solve(self):
        open_list = [(self.initial_state, [])]
        visited = set(tuple(map(tuple, self.initial_state)))
        while open_list:
            state, path = open_list.pop(0)
            if state == self.goal_state:
                return path
            for move in self.get_possible_moves(state):
                new_state = self.move(state, move)
                new_state_tuple = tuple(map(tuple, new_state))
                if new_state_tuple not in visited:
                    visited.add(new_state_tuple)
                    open_list.append((new_state, path + [move]))