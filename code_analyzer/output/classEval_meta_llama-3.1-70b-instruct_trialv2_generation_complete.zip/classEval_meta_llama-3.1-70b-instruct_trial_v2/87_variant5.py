from datetime import datetime, timedelta

class TimeUtils:
    def __init__(self):
        self.datetime = datetime.now()

    def get_current_time(self):
        return self.datetime.strftime('%H:%M:%S')

    def get_current_date(self):
        return self.datetime.strftime('%Y-%m-%d')

    def add_seconds(self, seconds):
        return (self.datetime + timedelta(seconds=seconds)).strftime('%H:%M:%S')

    def string_to_datetime(self, string):
        return datetime.strptime(string, '%Y-%m-%d %H:%M:%S')

    def datetime_to_string(self, datetime):
        return datetime.strftime('%Y-%m-%d %H:%M:%S')

    def get_minutes(self, string_time1, string_time2):
        time1 = self.string_to_datetime(string_time1)
        time2 = self.string_to_datetime(string_time2)
        return round((time2 - time1).total_seconds() / 60)

    def get_format_time(self, year, month, day, hour, minute, second):
        return datetime(year, month, day, hour, minute, second).strftime('%Y-%m-%d %H:%M:%S')