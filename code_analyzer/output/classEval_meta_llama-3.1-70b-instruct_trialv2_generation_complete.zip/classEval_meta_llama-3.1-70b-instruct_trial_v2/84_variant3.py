import json

class TextFileProcessor:
    def __init__(self, file_path):
        self.file_path = file_path

    def read_file_as_json(self):
        with open(self.file_path, 'r') as file:
            data = file.read()
            return json.loads(data) if data else {}

    def read_file(self):
        with open(self.file_path, 'r') as file:
            return file.read()

    def write_file(self, content):
        with open(self.file_path, 'w') as file:
            file.write(str(content))

    def process_file(self):
        content = self.read_file()
        processed_content = ''.join(filter(str.isalpha, content))
        self.write_file(processed_content)