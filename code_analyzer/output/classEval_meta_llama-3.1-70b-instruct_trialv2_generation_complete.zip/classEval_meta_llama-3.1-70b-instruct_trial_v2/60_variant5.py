import sqlite3

class MovieTicketDB:
    table_name = "tickets"
    columns = ["ID INTEGER PRIMARY KEY AUTOINCREMENT", 
               "movie_name TEXT", "theater_name TEXT", "seat_number TEXT", "customer_name TEXT"]

    def __init__(self, db_name):
        self.db_name = db_name
        self.connection = sqlite3.connect(db_name)
        self.cursor = self.connection.cursor()
        self.create_table()

    def create_table(self):
        query = f'''
            CREATE TABLE IF NOT EXISTS {self.table_name}
            ({", ".join(self.columns)})
        '''
        self.cursor.execute(query)
        self.connection.commit()

    def insert_ticket(self, movie_name, theater_name, seat_number, customer_name):
        query = f'''
            INSERT INTO {self.table_name} (movie_name, theater_name, seat_number, customer_name)
            VALUES (?, ?, ?, ?)
        '''
        self.cursor.execute(query, (movie_name, theater_name, seat_number, customer_name))
        self.connection.commit()

    def search_tickets_by_customer(self, customer_name):
        query = f'''
            SELECT * FROM {self.table_name} WHERE customer_name = ?
        '''
        self.cursor.execute(query, (customer_name,))
        return self.cursor.fetchall()

    def delete_ticket(self, ticket_id):
        query = f'''
            DELETE FROM {self.table_name} WHERE ID = ?
        '''
        self.cursor.execute(query, (ticket_id,))
        self.connection.commit()