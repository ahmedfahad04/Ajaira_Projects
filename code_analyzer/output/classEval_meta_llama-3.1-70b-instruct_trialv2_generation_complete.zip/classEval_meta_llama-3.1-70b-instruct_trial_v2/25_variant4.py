import json

class CookiesUtil:
    def __init__(self, cookies_file):
        self.cookies_file = cookies_file
        self.cookies = None

    def get_cookies(self, response):
        self.cookies = response.get('cookies', {})
        self._save_cookies()

    def load_cookies(self):
        with open(self.cookies_file, 'r') as f:
            try:
                self.cookies = json.load(f)
            except json.JSONDecodeError:
                self.cookies = {}
        return self.cookies

    def _save_cookies(self):
        with open(self.cookies_file, 'w') as f:
            json.dump(self.cookies, f)
        return True