import socket
import netifaces
import ipaddress

class IpUtil:
    @staticmethod
    def is_valid_ipv4(ip_address):
        return ipaddress.ip_address(ip_address).is_global

    @staticmethod
    def is_valid_ipv6(ip_address):
        return ipaddress.ip_address(ip_address).is_global

    @staticmethod
    def get_hostname(ip_address):
        try:
            return socket.gethostbyaddr(ip_address)[0]
        except socket.herror:
            return None