class NumberConverter:
    @staticmethod
    def decimal_to_binary(decimal_num):
        binary_num = ''
        while decimal_num > 0:
            binary_num = str(decimal_num % 2) + binary_num
            decimal_num //= 2
        return binary_num

    @staticmethod
    def binary_to_decimal(binary_num):
        decimal_num = 0
        for i, bit in enumerate(reversed(binary_num)):
            decimal_num += int(bit) * 2**i
        return decimal_num

    @staticmethod
    def decimal_to_octal(decimal_num):
        octal_num = ''
        while decimal_num > 0:
            octal_num = str(decimal_num % 8) + octal_num
            decimal_num //= 8
        return octal_num

    @staticmethod
    def octal_to_decimal(octal_num):
        decimal_num = 0
        for i, digit in enumerate(reversed(octal_num)):
            decimal_num += int(digit) * 8**i
        return decimal_num

    @staticmethod
    def decimal_to_hex(decimal_num):
        hex_num = ''
        hex_map = '0123456789abcdef'
        while decimal_num > 0:
            hex_num = hex_map[decimal_num % 16] + hex_num
            decimal_num //= 16
        return hex_num

    @staticmethod
    def hex_to_decimal(hex_num):
        decimal_num = 0
        hex_map = '0123456789abcdef'
        for i, char in enumerate(reversed(hex_num)):
            decimal_num += hex_map.index(char) * 16**i
        return decimal_num