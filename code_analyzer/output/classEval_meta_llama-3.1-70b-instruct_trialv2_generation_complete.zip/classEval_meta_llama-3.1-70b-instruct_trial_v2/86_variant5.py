class TicTacToe:
    def __init__(self, N=3):
        self.board = [[' ' for _ in range(N)] for _ in range(N)]
        self.current_player = 'X'
        self.N = N

    def make_move(self, row, col):
        if row < 0 or row >= self.N or col < 0 or col >= self.N or self.board[row][col] != ' ':
            return False
        self.board[row][col] = self.current_player
        self.current_player = 'O' if self.current_player == 'X' else 'X'
        return True

    def check_winner(self):
        winner = None
        for direction in [(0, 1), (1, 0), (1, 1), (1, -1)]:
            for i in range(self.N):
                for j in range(self.N):
                    if self.board[i][j] != ' ':
                        winner_candidate = self.board[i][j]
                        for k in range(1, self.N):
                            x, y = i + direction[0] * k, j + direction[1] * k
                            if x < 0 or x >= self.N or y < 0 or y >= self.N or self.board[x][y] != winner_candidate:
                                break
                        else:
                            winner = winner_candidate
                            break
                if winner is not None:
                    break
            if winner is not None:
                break
        return winner

    def is_board_full(self):
        return all([all([cell != ' ' for cell in row]) for row in self.board])