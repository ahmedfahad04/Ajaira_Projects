class Interpolation:
    """ This is a class that implements the Linear interpolation operation of one-dimensional and two-dimensional data """
    def __init__(self):
        pass

    @staticmethod
    def interpolate_1d(x, y, x_interp):
        """ Linear interpolation of one-dimensional data
        :param x: The x-coordinate of the data point, list.
        :param y: The y-coordinate of the data point, list.
        :param x_interp: The x-coordinate of the interpolation point, list.
        :return: The y-coordinate of the interpolation point, list.
        """
        y_interp = []
        for x_i in x_interp:
            idx = min(range(len(x)), key=lambda i: abs(x[i] - x_i))
            if x_i < x[0]:
                y_i = y[0]
            elif x_i > x[-1]:
                y_i = y[-1]
            elif x_i == x[idx]:
                y_i = y[idx]
            else:
                if x_i < x[idx]:
                    y_i = y[idx - 1] + (x_i - x[idx - 1]) * (y[idx] - y[idx - 1]) / (x[idx] - x[idx - 1])
                else:
                    y_i = y[idx] + (x_i - x[idx]) * (y[idx + 1] - y[idx]) / (x[idx + 1] - x[idx])
            y_interp.append(y_i)
        return y_interp

    @staticmethod
    def interpolate_2d(x, y, z, x_interp, y_interp):
        """ Linear interpolation of two-dimensional data
        :param x: The x-coordinate of the data point, list.
        :param y: The y-coordinate of the data point, list.
        :param z: The z-coordinate of the data point, list.
        :param x_interp: The x-coordinate of the interpolation point, list.
        :param y_interp: The y-coordinate of the interpolation point, list.
        :return: The z-coordinate of the interpolation point, list.
        """
        z_interp = []
        for x_i, y_i in zip(x_interp, y_interp):
            idx_x = min(range(len(x)), key=lambda i: abs(x[i] - x_i))
            idx_y = min(range(len(y)), key=lambda i: abs(y[i] - y_i))
            if x_i < x[0] and y_i < y[0]:
                z_i = z[0][0]
            elif x_i > x[-1] and y_i > y[-1]:
                z_i = z[-1][-1]
            elif x_i == x[idx_x] and y_i == y[idx_y]:
                z_i = z[idx_x][idx_y]
            else:
                if x_i < x[idx_x]:
                    z_x = z[idx_x - 1][idx_y] + (x_i - x[idx_x - 1]) * (z[idx_x][idx_y] - z[idx_x - 1][idx_y]) / (x[idx_x] - x[idx_x - 1])
                else:
                    z_x = z[idx_x][idx_y] + (x_i - x[idx_x]) * (z[idx_x + 1][idx_y] - z[idx_x][idx_y]) / (x[idx_x + 1] - x[idx_x])
                if y_i < y[idx_y]:
                    z_i = z_x
                else:
                    z_i = z_x + (y_i - y[idx_y]) * (z[idx_x][idx_y + 1] - z[idx_x][idx_y]) / (y[idx_y + 1] - y[idx_y])
            z_interp.append(z_i)
        return z_interp