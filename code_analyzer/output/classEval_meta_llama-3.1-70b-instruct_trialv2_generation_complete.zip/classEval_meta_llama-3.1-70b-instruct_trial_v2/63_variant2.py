import re
from collections import Counter

class NLPDataProcessor2:
    def process_data(self, string_list):
        words_list = []
        for string in string_list:
            string = re.sub('[^a-zA-Z\s]', '', string).lower()
            words_list.append(string.split())
        return words_list

    def calculate_word_frequency(self, words_list):
        word_freq = {}
        for words in words_list:
            for word in words:
                if word in word_freq:
                    word_freq[word] += 1
                else:
                    word_freq[word] = 1
        return dict(sorted(word_freq.items(), key=lambda item: item[1], reverse=True)[:5])

    def process(self, string_list):
        words_list = self.process_data(string_list)
        return self.calculate_word_frequency(words_list)