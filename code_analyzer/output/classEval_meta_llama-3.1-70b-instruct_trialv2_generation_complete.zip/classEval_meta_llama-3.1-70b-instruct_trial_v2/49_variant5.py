class JobMarketplace:
    def __init__(self):
        self.job_listings = []
        self.resumes = []

    def post_job(self, job_title, company, requirements):
        self.job_listings.append({'job_title': job_title, 'company': company, 'requirements': requirements})

    def remove_job(self, job):
        self.job_listings = list(filter(lambda j: j != job, self.job_listings))

    def submit_resume(self, name, skills, experience):
        self.resumes.append({'name': name, 'skills': skills, 'experience': experience})

    def withdraw_resume(self, resume):
        self.resumes = list(filter(lambda r: r != resume, self.resumes))

    def search_jobs(self, criteria):
        return list(filter(lambda job: criteria in job['requirements'], self.job_listings))

    def get_job_applicants(self, job):
        return list(filter(lambda resume: all(requirement in resume['skills'] for requirement in job['requirements']), self.resumes))