import numpy as np

class KappaCalculator:
    @staticmethod
    def kappa(testData, k):
        n = len(testData)
        p_o = sum([testData[i][i] for i in range(n)]) / n
        p_e = sum([np.sum(row) ** 2 for row in testData]) / (n ** 2)
        kappa = (p_o - p_e) / (1 - p_e)
        return kappa

    @staticmethod
    def fleiss_kappa(testData, N, k, n):
        p_o = sum([np.sum(row) ** 2 for row in testData]) / (N * n ** 2)
        p_e = sum([np.sum([row[i] for row in testData]) / (N * n) for i in range(k)]) ** 2
        kappa = (p_o - p_e) / (1 - p_e)
        return kappa