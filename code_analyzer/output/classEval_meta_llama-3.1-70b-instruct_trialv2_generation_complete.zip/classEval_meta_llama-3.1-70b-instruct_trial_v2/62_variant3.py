class NLPDataProcessor:
    def construct_stop_word_list(self):
        return ['a', 'an', 'the']

    def remove_stop_words(self, string_list, stop_word_list):
        import re
        result = []
        for string in string_list:
            words = re.findall(r'\b\w+\b', string)
            words = [word for word in words if word.lower() not in stop_word_list]
            result.append(words)
        return result

    def process(self, string_list):
        stop_word_list = self.construct_stop_word_list()
        return self.remove_stop_words(string_list, stop_word_list)