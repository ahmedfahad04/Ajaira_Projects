from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT

class DocFileHandler:
    def __init__(self, file_path):
        self.file_path = file_path
        self.document = Document(self.file_path)

    def read_text(self):
        return '\n'.join([para.text for para in self.document.paragraphs])

    def write_text(self, content, font_size=12, alignment='left'):
        try:
            para = self.document.add_paragraph()
            run = para.add_run(content)
            run.font.size = Pt(font_size)
            para.alignment = self._get_alignment_value(alignment)
            self.document.save(self.file_path)
            return True
        except Exception:
            return False

    def add_heading(self, heading, level=1):
        try:
            self.document.add_heading(heading, level)
            self.document.save(self.file_path)
            return True
        except Exception:
            return False

    def add_table(self, data):
        try:
            table = self.document.add_table(rows=len(data), cols=len(data[0]))
            for i, row in enumerate(table.rows):
                for j, cell in enumerate(row.cells):
                    cell.text = str(data[i][j])
            self.document.save(self.file_path)
            return True
        except Exception:
            return False

    def _get_alignment_value(self, alignment):
        alignment_map = {
            'left': WD_PARAGRAPH_ALIGNMENT.LEFT,
            'center': WD_PARAGRAPH_ALIGNMENT.CENTER,
            'right': WD_PARAGRAPH_ALIGNMENT.RIGHT
        }
        return alignment_map.get(alignment, WD_PARAGRAPH_ALIGNMENT.LEFT)