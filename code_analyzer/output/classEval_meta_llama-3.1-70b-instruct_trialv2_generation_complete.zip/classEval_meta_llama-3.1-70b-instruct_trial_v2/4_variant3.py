class AssessmentSystem:
    def __init__(self):
        self.students = {}

    def add_student(self, name, grade, major):
        self.students[name] = {'name': name, 'grade': grade, 'major': major, 'courses': {}}

    def add_course_score(self, name, course, score):
        if name in self.students:
            self.students[name]['courses'][course] = score

    def get_gpa(self, name):
        student = self.students.get(name)
        if student and student['courses']:
            total = 0
            for score in student['courses'].values():
                total += score
            return total / len(student['courses'])
        return None

    def get_all_students_with_fail_course(self):
        return [name for name, student in self.students.items() if any(score < 60 for score in student['courses'].values())]

    def get_course_average(self, course):
        total = 0
        count = 0
        for student in self.students.values():
            if course in student['courses']:
                total += student['courses'][course]
                count += 1
        if count:
            return total / count
        return None

    def get_top_student(self):
        top_gpa = 0
        top_student = None
        for name, student in self.students.items():
            gpa = self.get_gpa(name)
            if gpa is not None and gpa > top_gpa:
                top_gpa = gpa
                top_student = name
        return top_student