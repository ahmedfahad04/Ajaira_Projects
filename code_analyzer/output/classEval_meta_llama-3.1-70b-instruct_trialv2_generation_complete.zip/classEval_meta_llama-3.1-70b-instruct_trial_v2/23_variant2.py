import math
from typing import List
import itertools

class CombinationCalculator:
    def __init__(self, datas: List[str]):
        self.datas = datas

    @staticmethod
    def count(n: int, m: int) -> int:
        return math.comb(n, m)

    @staticmethod
    def count_all(n: int) -> int:
        return sum(math.comb(n, i) for i in range(n + 1)) if sum(math.comb(n, i) for i in range(n + 1)) <= 2**63-1 else float("inf")

    def select(self, m: int) -> List[List[str]]:
        return [list(x) for x in itertools.combinations(self.datas, m)]

    def select_all(self) -> List[List[str]]:
        result = []
        for i in range(len(self.datas) + 1):
            result.extend(self.select(i))
        return result