class BigNumCalculator:
    @staticmethod
    def add(num1, num2):
        max_len = max(len(num1), len(num2))
        num1 = num1.zfill(max_len)
        num2 = num2.zfill(max_len)
        result = ''
        carry = 0
        for i in range(max_len-1, -1, -1):
            total = int(num1[i]) + int(num2[i]) + carry
            result = str(total % 10) + result
            carry = total // 10
        if carry > 0:
            result = str(carry) + result
        return result

    @staticmethod
    def subtract(num1, num2):
        max_len = max(len(num1), len(num2))
        num1 = num1.zfill(max_len)
        num2 = num2.zfill(max_len)
        result = ''
        borrow = 0
        for i in range(max_len-1, -1, -1):
            total = int(num1[i]) - int(num2[i]) - borrow
            if total < 0:
                total += 10
                borrow = 1
            else:
                borrow = 0
            result = str(total) + result
        return result.lstrip('0') or '0'

    @staticmethod
    def multiply(num1, num2):
        result = 0
        for i in range(len(num2)):
            result += int(num1) * int(num2[len(num2)-1-i]) * (10 ** i)
        return str(result)