import re

class RegexUtils:
    def __init__(self):
        self.email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        self.phone_number_pattern = r'\b\d{3}-\d{3}-\d{4}\b'
        self.split_sentences_pattern = r'[.!?][\s]{1,2}(?=[A-Z])'

    def match(self, pattern, text):
        return bool(re.match(pattern, text))

    def findall(self, pattern, text):
        return re.findall(pattern, text)

    def split(self, pattern, text):
        return re.split(pattern, text)

    def sub(self, pattern, replacement, text):
        return re.sub(pattern, replacement, text)

    def generate_email_pattern(self):
        return self.email_pattern

    def generate_phone_number_pattern(self):
        return self.phone_number_pattern

    def generate_split_sentences_pattern(self):
        return self.split_sentences_pattern

    def split_sentences(self, text):
        sentences = re.split(self.split_sentences_pattern, text)
        return [sentence.strip() for sentence in sentences if sentence]

    def validate_phone_number(self, phone_number):
        return bool(re.match(self.phone_number_pattern, phone_number))

    def extract_email(self, text):
        return re.findall(self.email_pattern, text)