import itertools

class ArrangementCalculator:
    def __init__(self, datas):
        self.datas = datas

    @staticmethod
    def count(n, m=None):
        if m is None or n == m:
            return ArrangementCalculator.factorial(n)
        return ArrangementCalculator.factorial(n) // ArrangementCalculator.factorial(n - m)

    @staticmethod
    def count_all(n):
        return sum(ArrangementCalculator.factorial(n) // ArrangementCalculator.factorial(n - i) for i in range(1, n + 1))

    def select(self, m=None):
        if m is None:
            m = len(self.datas)
        return [list(p) for p in itertools.permutations(self.datas, m)]

    def select_all(self):
        result = []
        for r in range(1, len(self.datas) + 1):
            for p in itertools.permutations(self.datas, r):
                result.append(list(p))
        return result

    @staticmethod
    def factorial(n):
        f = 1
        for i in range(1, n + 1):
            f *= i
        return f