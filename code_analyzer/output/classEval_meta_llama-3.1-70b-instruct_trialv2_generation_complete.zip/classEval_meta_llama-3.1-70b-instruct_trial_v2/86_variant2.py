class TicTacToe:
    def __init__(self, N=3):
        self.board = [[' ' for _ in range(N)] for _ in range(N)]
        self.current_player = 'X'
        self.N = N

    def make_move(self, row, col):
        if row < 0 or row >= self.N or col < 0 or col >= self.N or self.board[row][col] != ' ':
            return False
        self.board[row][col] = self.current_player
        self.current_player = 'O' if self.current_player == 'X' else 'X'
        return True

    def check_winner(self):
        winner = None
        for i in range(self.N):
            if self.board[i][0] != ' ' and all([cell == self.board[i][0] for cell in self.board[i]]):
                winner = self.board[i][0]
                break
            if self.board[0][i] != ' ' and all([self.board[j][i] == self.board[0][i] for j in range(self.N)]):
                winner = self.board[0][i]
                break
        if winner is None and self.board[0][0] != ' ' and all([self.board[i][i] == self.board[0][0] for i in range(self.N)]):
            winner = self.board[0][0]
        if winner is None and self.board[0][self.N - 1] != ' ' and all([self.board[i][self.N - i - 1] == self.board[0][self.N - 1] for i in range(self.N)]):
            winner = self.board[0][self.N - 1]
        return winner

    def is_board_full(self):
        for row in self.board:
            for cell in row:
                if cell == ' ':
                    return False
        return True