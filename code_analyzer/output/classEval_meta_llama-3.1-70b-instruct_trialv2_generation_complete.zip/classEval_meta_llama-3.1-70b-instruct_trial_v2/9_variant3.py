class BigNumCalculator:
    @staticmethod
    def add(num1, num2):
        return str(sum(map(int, [num1, num2])))

    @staticmethod
    def subtract(num1, num2):
        return str(int(num1) - int(num2))

    @staticmethod
    def multiply(num1, num2):
        result = 0
        for i in range(len(num2)):
            result += int(num1) * int(num2[len(num2)-1-i]) * (10 ** i)
        return str(result)