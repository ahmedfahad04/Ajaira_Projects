class BigNumCalculator:
    @staticmethod
    def add(num1, num2):
        from decimal import Decimal
        return str(Decimal(num1) + Decimal(num2))

    @staticmethod
    def subtract(num1, num2):
        from decimal import Decimal
        return str(Decimal(num1) - Decimal(num2))

    @staticmethod
    def multiply(num1, num2):
        from decimal import Decimal
        return str(Decimal(num1) * Decimal(num2))