import json
import os

class JSONProcessor:
    def __init__(self):
        self.data = None

    def read_json(self, file_path):
        if not os.path.exists(file_path):
            return 0
        try:
            with open(file_path, 'r') as f:
                self.data = json.load(f)
                return self.data
        except Exception as e:
            print(f"An error occurred: {e}")
            return -1

    def write_json(self, data, file_path):
        try:
            with open(file_path, 'w') as f:
                json.dump(data, f)
            return 1
        except Exception as e:
            print(f"An error occurred: {e}")
            return -1

    def process_json(self, file_path, remove_key):
        if not os.path.exists(file_path):
            return 0
        self.read_json(file_path)
        if remove_key in self.data:
            del self.data[remove_key]
            self.write_json(self.data, file_path)
            return 1
        else:
            return 0