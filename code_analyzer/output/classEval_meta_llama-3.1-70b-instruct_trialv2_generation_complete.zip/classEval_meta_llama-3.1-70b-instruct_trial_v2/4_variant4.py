class AssessmentSystem:
    def __init__(self):
        self.students = {}

    def add_student(self, name, grade, major):
        self.students[name] = {'name': name, 'grade': grade, 'major': major, 'courses': {}}

    def add_course_score(self, name, course, score):
        if name in self.students:
            self.students[name]['courses'][course] = score

    def get_gpa(self, name):
        student = self.students.get(name)
        if student and student['courses']:
            scores = list(student['courses'].values())
            return sum(scores) / len(scores)
        return None

    def get_all_students_with_fail_course(self):
        fail_students = set()
        for name, student in self.students.items():
            for score in student['courses'].values():
                if score < 60:
                    fail_students.add(name)
                    break
        return list(fail_students)

    def get_course_average(self, course):
        scores = []
        for student in self.students.values():
            if course in student['courses']:
                scores.append(student['courses'][course])
        if scores:
            return sum(scores) / len(scores)
        return None

    def get_top_student(self):
        top_gpa = 0
        top_student = None
        for name, student in self.students.items():
            gpa = self.get_gpa(name)
            if gpa is not None and gpa > top_gpa:
                top_gpa = gpa
                top_student = name
        return top_student