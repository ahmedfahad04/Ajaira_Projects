class MusicPlayer:
    def __init__(self):
        self.playlist = []
        self.current_song = None
        self.volume = 50
        self.playlist_index = 0

    def add_song(self, song):
        self.playlist.append(song)

    def remove_song(self, song):
        if song in self.playlist:
            self.playlist.remove(song)
            if self.current_song == song:
                self.current_song = self.playlist[self.playlist_index] if self.playlist else None

    def play(self):
        if self.playlist:
            self.current_song = self.playlist[self.playlist_index]
            return self.current_song
        return False

    def stop(self):
        if self.current_song:
            self.current_song = None
            return True
        return False

    def switch_song(self):
        if self.playlist:
            self.playlist_index = (self.playlist_index + 1) % len(self.playlist)
            self.current_song = self.playlist[self.playlist_index]
            return True
        return False

    def previous_song(self):
        if self.playlist:
            self.playlist_index = (self.playlist_index - 1) % len(self.playlist)
            self.current_song = self.playlist[self.playlist_index]
            return True
        return False

    def set_volume(self, volume):
        if 0 <= volume <= 100:
            self.volume = volume
            return True
        return False

    def shuffle(self):
        if self.playlist:
            import random
            random.shuffle(self.playlist)
            self.playlist_index = 0
            self.current_song = self.playlist[0]
            return True
        return False