import random

class MinesweeperGame:
    def __init__(self, n, k) -> None:
        self.n = n
        self.k = k
        self.minesweeper_map = self.generate_mine_sweeper_map()
        self.player_map = self.generate_playerMap()
        self.score = 0

    def generate_mine_sweeper_map(self):
        minesweeper_map = [['0' for _ in range(self.n)] for _ in range(self.n)]
        mines = set()
        while len(mines) < self.k:
            x, y = random.randint(0, self.n-1), random.randint(0, self.n-1)
            if (x, y) not in mines:
                minesweeper_map[x][y] = 'X'
                mines.add((x, y))
        for i in range(self.n):
            for j in range(self.n):
                if minesweeper_map[i][j] != 'X':
                    count = 0
                    for x, y in [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]:
                        nx, ny = i+x, j+y
                        if 0 <= nx < self.n and 0 <= ny < self.n and minesweeper_map[nx][ny] == 'X':
                            count += 1
                    minesweeper_map[i][j] = str(count)
        return minesweeper_map

    def generate_playerMap(self):
        return [['-' for _ in range(self.n)] for _ in range(self.n)]

    def check_won(self, map):
        for i in range(self.n):
            for j in range(self.n):
                if map[i][j] == '-' and self.minesweeper_map[i][j] != 'X':
                    return False
        return True

    def sweep(self, x, y):
        if self.minesweeper_map[x][y] == 'X':
            self.player_map[x][y] = 'X'
            return self.check_won(self.player_map)
        else:
            self.player_map[x][y] = self.minesweeper_map[x][y]
            if self.minesweeper_map[x][y] == '0':
                for nx, ny in [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]:
                    if 0 <= x+nx < self.n and 0 <= y+ny < self.n and self.player_map[x+nx][y+ny] == '-':
                        self.sweep(x+nx, y+ny)
            return self.player_map