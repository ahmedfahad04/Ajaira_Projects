class StockPortfolioTracker:
    def __init__(self, cash_balance):
        self.portfolio = {}
        self.cash_balance = cash_balance

    def add_stock(self, stock):
        if stock['name'] in self.portfolio:
            self.portfolio[stock['name']]['quantity'] += stock['quantity']
        else:
            self.portfolio[stock['name']] = stock

    def remove_stock(self, stock):
        if stock['name'] in self.portfolio:
            if self.portfolio[stock['name']]['quantity'] == stock['quantity']:
                del self.portfolio[stock['name']]
                return True
            elif self.portfolio[stock['name']]['quantity'] > stock['quantity']:
                self.portfolio[stock['name']]['quantity'] -= stock['quantity']
                return True
        return False

    def buy_stock(self, stock):
        total_cost = stock['price'] * stock['quantity']
        if self.cash_balance >= total_cost:
            self.add_stock(stock)
            self.cash_balance -= total_cost
            return True
        return False

    def sell_stock(self, stock):
        if stock['name'] in self.portfolio:
            if self.portfolio[stock['name']]['quantity'] >= stock['quantity']:
                del self.portfolio[stock['name']]
                self.cash_balance += stock['price'] * stock['quantity']
                return True
        return False

    def calculate_portfolio_value(self):
        total_value = self.cash_balance
        for stock in self.portfolio.values():
            total_value += stock['price'] * stock['quantity']
        return total_value

    def get_portfolio_summary(self):
        total_value = self.calculate_portfolio_value()
        stock_values = [{'name': name, 'value': stock['price'] * stock['quantity']} for name, stock in self.portfolio.items()]
        return total_value, stock_values

    def get_stock_value(self, stock):
        return stock['price'] * stock['quantity']