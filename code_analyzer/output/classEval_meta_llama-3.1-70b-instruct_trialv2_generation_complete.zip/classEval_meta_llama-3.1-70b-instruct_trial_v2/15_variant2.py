class BoyerMooreSearch:
    """This is a class that implements the Boyer-Moore algorithm for string searching, which is used to find occurrences of a pattern within a given text."""

    def __init__(self, text, pattern):
        """Initializes the BoyerMooreSearch class with the given text and pattern.
        :param text: The text to be searched, str.
        :param pattern: The pattern to be searched for, str."""
        self.text, self.pattern = text, pattern
        self.textLen, self.patLen = len(text), len(pattern)
        self.bad_char_table = self._build_bad_char_table()

    def _build_bad_char_table(self):
        table = {}
        for i in range(self.patLen):
            table[self.pattern[i]] = i
        return table

    def match_in_pattern(self, char):
        """Finds the rightmost occurrence of a character in the pattern.
        :param char: The character to be searched for, str.
        :return: The index of the rightmost occurrence of the character in the pattern, int."""
        return self.bad_char_table.get(char, -1)

    def mismatch_in_text(self, currentPos):
        """Determines the position of the first dismatch between the pattern and the text.
        :param currentPos: The current position in the text, int.
        :return: The position of the first dismatch between the pattern and the text, int, otherwise -1."""
        for i in range(self.patLen):
            if self.text[currentPos + i] != self.pattern[i]:
                return i
        return -1

    def bad_character_heuristic(self):
        """Finds all occurrences of the pattern in the text.
        :return: A list of all positions of the pattern in the text, list."""
        positions = []
        shift = 0
        while shift <= self.textLen - self.patLen:
            mismatch = self.mismatch_in_text(shift)
            if mismatch == -1:
                positions.append(shift)
                shift += self.patLen
            else:
                shift += max(1, mismatch - self.match_in_pattern(self.text[shift + mismatch]))
        return positions