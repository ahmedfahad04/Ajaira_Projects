class AvgPartition:
    def __init__(self, lst, limit):
        if limit <= 0:
            raise ValueError("Number of partitions must be greater than 0")
        self.lst = lst
        self.limit = limit
        self.block_size, self.remainder = self.setNum()

    def setNum(self):
        return divmod(len(self.lst), self.limit)

    def get(self, index):
        start = index * self.block_size + min(index, self.remainder)
        end = start + self.block_size + (1 if index < self.remainder else 0)
        return self.lst[start:end]