class AvgPartition:
    def __init__(self, lst, limit):
        if limit <= 0:
            raise ValueError("Number of partitions must be greater than 0")
        self.lst = lst
        self.limit = limit

    def setNum(self):
        return divmod(len(self.lst), self.limit)

    def get(self, index):
        block_size, remainder = self.setNum()
        start = sum(block_size + (1 if i < remainder else 0) for i in range(index))
        end = start + block_size + (1 if index < remainder else 0)
        return self.lst[start:end]