class Server:
    def __init__(self):
        self.white_list = set()
        self.send_struct = {}
        self.receive_struct = {}

    def add_white_list(self, addr):
        if addr not in self.white_list:
            self.white_list.add(addr)
            return list(self.white_list)
        return False

    def del_white_list(self, addr):
        if addr in self.white_list:
            self.white_list.remove(addr)
            return list(self.white_list)
        return False

    def recv(self, info):
        if info["addr"] in self.white_list:
            self.receive_struct = info
            return info["content"]
        return False

    def send(self, info):
        self.send_struct = info
        return

    def show(self, type):
        if type == "send":
            return self.send_struct
        elif type == "receive":
            return self.receive_struct
        return False