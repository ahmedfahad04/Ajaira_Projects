class SQLGenerator:
    def __init__(self, table_name):
        self.table_name = table_name

    def _build_condition(self, condition):
        if condition is None:
            return ""
        else:
            return f" WHERE {condition}"

    def _build_fields(self, fields):
        if fields is None:
            return "*"
        else:
            return ", ".join(fields)

    def select(self, fields=None, condition=None):
        return f"SELECT {self._build_fields(fields)} FROM {self.table_name}{self._build_condition(condition)};"

    def insert(self, data):
        fields = ", ".join(data.keys())
        values = ", ".join(f"'{value}'" for value in data.values())
        return f"INSERT INTO {self.table_name} ({fields}) VALUES ({values});"

    def update(self, data, condition):
        sets = ", ".join(f"{field} = '{value}'" for field, value in data.items())
        return f"UPDATE {self.table_name} SET {sets} WHERE {condition};"

    def delete(self, condition):
        return f"DELETE FROM {self.table_name} WHERE {condition};"

    def select_female_under_age(self, age):
        return f"SELECT * FROM {self.table_name} WHERE age < {age} AND gender = 'female';"

    def select_by_age_range(self, min_age, max_age):
        return f"SELECT * FROM {self.table_name} WHERE age BETWEEN {min_age} AND {max_age};"