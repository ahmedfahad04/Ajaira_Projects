class DecryptionUtils:
    def __init__(self, key):
        self.key = key

    def caesar_decipher(self, ciphertext, shift):
        alphabet = 'abcdefghijklmnopqrstuvwxyz'
        shifted_alphabet = alphabet[-shift:] + alphabet[:-shift]
        result = ''
        for char in ciphertext:
            if char.isalpha():
                if char.isupper():
                    result += shifted_alphabet[alphabet.index(char.lower())].upper()
                else:
                    result += shifted_alphabet[alphabet.index(char)]
            else:
                result += char
        return result

    def vigenere_decipher(self, ciphertext):
        key_index = 0
        result = ''
        for char in ciphertext:
            if char.isalpha():
                shift = ord(self.key[key_index % len(self.key)].lower()) - 97
                alphabet = 'abcdefghijklmnopqrstuvwxyz'
                shifted_alphabet = alphabet[-shift:] + alphabet[:-shift]
                if char.isupper():
                    result += shifted_alphabet[alphabet.index(char.lower())].upper()
                else:
                    result += shifted_alphabet[alphabet.index(char)]
                key_index += 1
            else:
                result += char
        return result

    def rail_fence_decipher(self, encrypted_text, rails):
        length = len(encrypted_text)
        fence = [''] * rails
        index, step = 0, 1
        for i in range(length):
            fence[index] += encrypted_text[i]
            if index == 0:
                step = 1
            elif index == rails - 1:
                step = -1
            index += step
        result = ''
        for i in range(length):
            for j in range(rails):
                if len(fence[j]) > 0:
                    result += fence[j][0]
                    fence[j] = fence[j][1:]
        return result