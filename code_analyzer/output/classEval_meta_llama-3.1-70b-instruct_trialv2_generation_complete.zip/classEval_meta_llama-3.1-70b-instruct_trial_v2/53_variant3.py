class LongestWord:
    def __init__(self):
        self.word_list = set()

    def add_word(self, word):
        self.word_list.add(word)

    def find_longest_word(self, sentence):
        translator = str.maketrans('', '', string.punctuation)
        sentence_no_punct = sentence.translate(translator)
        words = sentence_no_punct.split()
        longest_word = ''
        for word in words:
            if word in self.word_list and len(word) > len(longest_word):
                longest_word = word
        return longest_word