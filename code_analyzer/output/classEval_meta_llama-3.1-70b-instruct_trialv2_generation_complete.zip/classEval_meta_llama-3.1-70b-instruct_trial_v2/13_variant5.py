class BookManagement:
    def __init__(self):
        self.inventory = {}

    def add_book(self, title, quantity=1):
        if not isinstance(quantity, int) or quantity < 1:
            raise ValueError("Quantity must be a positive integer")
        if title in self.inventory:
            self.inventory[title] += quantity
        else:
            self.inventory[title] = quantity

    def remove_book(self, title, quantity):
        if not isinstance(quantity, int) or quantity < 1:
            raise ValueError("Quantity must be a positive integer")
        if title in self.inventory:
            if self.inventory[title] >= quantity:
                self.inventory[title] -= quantity
                if self.inventory[title] == 0:
                    del self.inventory[title]
            else:
                raise ValueError("Not enough quantity to remove")
        else:
            raise ValueError("Book not found in inventory")

    def view_inventory(self):
        return dict(sorted(self.inventory.items()))

    def view_book_quantity(self, title):
        return self.inventory.get(title, 0)