from datetime import datetime

class Chat:
    def __init__(self):
        self.users = {}

    def add_user(self, username):
        if username not in self.users:
            self.users[username] = {'messages': []}
            return True
        return False

    def remove_user(self, username):
        if username in self.users:
            del self.users[username]
            return True
        return False

    def send_message(self, sender, receiver, message):
        if sender in self.users and receiver in self.users:
            self.users[receiver]['messages'].append({
                'sender': sender,
                'receiver': receiver,
                'message': message,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            })
            return True
        return False

    def get_messages(self, username):
        return self.users.get(username, {}).get('messages', [])