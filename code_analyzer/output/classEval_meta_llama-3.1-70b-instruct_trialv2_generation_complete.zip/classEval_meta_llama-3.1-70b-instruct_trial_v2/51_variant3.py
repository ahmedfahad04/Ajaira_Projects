import numpy as np

class KappaCalculator:
    @staticmethod
    def kappa(testData, k):
        n = len(testData)
        p_o = np.trace(testData) / n
        p_e = np.sum(np.square(testData)) / (n ** 2)
        kappa = (p_o - p_e) / (1 - p_e)
        return kappa

    @staticmethod
    def fleiss_kappa(testData, N, k, n):
        p_o = np.sum(np.square(testData)) / (N * n ** 2)
        p_e = np.sum(np.square(np.sum(testData, axis=0))) / (N ** 2 * n ** 2)
        kappa = (p_o - p_e) / (1 - p_e)
        return kappa