class NumericEntityUnescaper:
    def __init__(self):
        pass

    def replace(self, string):
        result = ''
        i = 0
        while i < len(string):
            if string[i:i+3] == '&#x':
                j = string.find(';', i)
                if j != -1:
                    code = string[i+3:j]
                    result += chr(int(code, 16))
                    i = j + 1
                else:
                    result += '&#x'
                    i += 3
            elif string[i:i+2] == '&#':
                j = string.find(';', i)
                if j != -1:
                    code = string[i+2:j]
                    result += chr(int(code))
                    i = j + 1
                else:
                    result += '&#'
                    i += 2
            else:
                result += string[i]
                i += 1
        return result

    @staticmethod
    def is_hex_char(char):
        return char.isdigit() or 'a' <= char.lower() <= 'f'