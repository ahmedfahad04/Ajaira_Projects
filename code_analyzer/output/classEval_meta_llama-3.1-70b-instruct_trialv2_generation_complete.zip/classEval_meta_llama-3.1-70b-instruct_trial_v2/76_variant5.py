class SignInSystem:
    def __init__(self):
        self.users = {}
        self.signed_in = []

    def add_user(self, username):
        if username not in self.users:
            self.users[username] = False
            return True
        return False

    def sign_in(self, username):
        if username in self.users:
            self.users[username] = True
            self.signed_in.append(username)
            return True
        return False

    def check_sign_in(self, username):
        return self.users.get(username, False)

    def all_signed_in(self):
        return len(self.users) == len(self.signed_in)

    def all_not_signed_in(self):
        return [username for username in self.users if username not in self.signed_in]