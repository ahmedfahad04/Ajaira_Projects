class ArgumentParser:
    def __init__(self):
        self.arguments = {}
        self.required = set()
        self.types = {}

    def parse_arguments(self, command_string):
        import argparse
        parser = argparse.ArgumentParser()
        for arg in self.types:
            if arg in self.required:
                parser.add_argument('--' + arg, required=True, type=self.types[arg])
            else:
                parser.add_argument('--' + arg, type=self.types[arg])
        args = parser.parse_args(command_string.split()[1:])
        for arg in self.types:
            if hasattr(args, arg):
                self.arguments[arg] = getattr(args, arg)
            else:
                self.arguments[arg] = False
        if any(not value for value in self.arguments.values()):
            return False, {arg for arg, value in self.arguments.items() if not value}
        return True, None

    def get_argument(self, key):
        return self.arguments.get(key)

    def add_argument(self, arg, required=False, arg_type=str):
        self.types[arg] = arg_type
        if required:
            self.required.add(arg)

    def _convert_type(self, arg, value):
        arg_type = self.types.get(arg)
        if arg_type == int:
            return int(value)
        elif arg_type == float:
            return float(value)
        elif arg_type == bool:
            return value.lower() == 'true'
        else:
            return value