class AutomaticGuitarSimulator:
    def __init__(self, text):
        self.play_text = text

    def interpret(self, display=False):
        result = []
        for word in self.play_text.split():
            if word:
                chord, tune = self._split_chord_tune(word)
                result.append({'Chord': chord, 'Tune': tune})
                if display:
                    self.display(chord, tune)
        return result

    def display(self, key, value):
        print(f"Normal Guitar Playing -- Chord: {key}, Play Tune: {value}")

    def _split_chord_tune(self, word):
        for i, char in enumerate(word):
            if char.isdigit():
                return word[:i], word[i:]
        return word, ''