import itertools

class AutomaticGuitarSimulator:
    def __init__(self, text):
        self.play_text = text

    def interpret(self, display=False):
        result = []
        for word in self.play_text.split():
            if word:
                chord = ''
                tune = ''
                for char in word:
                    if char.isalpha():
                        chord += char
                    else:
                        tune += char
                result.append({'Chord': chord, 'Tune': tune})
                if display:
                    self.display(chord, tune)
        return result

    def display(self, key, value):
        print(f"Normal Guitar Playing -- Chord: {key}, Play Tune: {value}")