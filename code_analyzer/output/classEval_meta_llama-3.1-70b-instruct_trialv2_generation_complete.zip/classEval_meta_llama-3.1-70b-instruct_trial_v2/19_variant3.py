class ChandrasekharSieve:
    """ This is a class that uses the Chandrasekhar's Sieve method to find all prime numbers within the range """
    def __init__(self, n):
        """ Initialize the ChandrasekharSieve class with the given limit.
        :param n: int, the upper limit for generating prime numbers """
        self.n = n
        self.primes = self.generate_primes()

    def generate_primes(self):
        """ Generate prime numbers up to the specified limit using the Chandrasekhar sieve algorithm.
        :return: list, a list of prime numbers """
        sieve = [True] * (self.n + 1)
        sieve[0:2] = [False, False]
        for current_prime in range(2, int(self.n**0.5) + 1):
            if sieve[current_prime]:
                sieve[current_prime*2::current_prime] = [False] * len(sieve[current_prime*2::current_prime])
        return [num for num, is_prime in enumerate(sieve) if is_prime]

    def get_primes(self):
        """ Get the list of generated prime numbers.
        :return: list, a list of prime numbers """
        return self.primes