class VendingMachine:
    def __init__(self):
        self.inventory = {}
        self.balance = 0.0

    def add_item(self, item_name, price, quantity):
        self.inventory[item_name] = {'price': float(price), 'quantity': int(quantity)}

    def insert_coin(self, amount):
        self.balance += float(amount)
        return self.balance

    def purchase_item(self, item_name):
        if item_name not in self.inventory or self.inventory[item_name]['quantity'] == 0 or self.balance < self.inventory[item_name]['price']:
            return False
        self.balance -= self.inventory[item_name]['price']
        self.inventory[item_name]['quantity'] -= 1
        return self.balance

    def restock_item(self, item_name, quantity):
        if item_name in self.inventory:
            self.inventory[item_name]['quantity'] += quantity
            return True
        return False

    def display_items(self):
        if not self.inventory:
            return False
        items = [f"{item} - ${details['price']} [{details['quantity']}]}" for item, details in self.inventory.items()]
        return items