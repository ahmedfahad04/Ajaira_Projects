class Warehouse:
    def __init__(self):
        self.inventory = {}
        self.orders = {}

    def add_product(self, product_id, name, quantity):
        if product_id in self.inventory:
            self.inventory[product_id]['quantity'] = self.inventory[product_id]['quantity'] + quantity
        else:
            self.inventory[product_id] = {'name': name, 'quantity': quantity}

    def update_product_quantity(self, product_id, quantity):
        if product_id in self.inventory:
            self.inventory[product_id]['quantity'] += quantity
            if self.inventory[product_id]['quantity'] < 0:
                self.inventory[product_id]['quantity'] = 0

    def get_product_quantity(self, product_id):
        return self.inventory.get(product_id, {}).get('quantity', False)

    def create_order(self, order_id, product_id, quantity):
        if product_id in self.inventory and self.inventory[product_id]['quantity'] >= quantity:
            self.orders[order_id] = {'product_id': product_id, 'quantity': quantity, 'status': 'Shipped'}
            return True
        return False

    def change_order_status(self, order_id, status):
        if order_id in self.orders:
            self.orders[order_id]['status'] = status
            return True
        return False

    def track_order(self, order_id):
        return self.orders.get(order_id, {}).get('status', False)