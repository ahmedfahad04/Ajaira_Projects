import nltk
from nltk.stem import WordNetLemmatizer
from nltk import pos_tag, word_tokenize
import string
nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')
nltk.download('wordnet')

class Lemmatization:
    def __init__(self):
        self.lemmatizer = WordNetLemmatizer()
        
    def lemmatize_sentence(self, sentence):
        sentence = self.remove_punctuation(sentence)
        tokens = word_tokenize(sentence)
        tagged = pos_tag(tokens)
        lemmatized = []
        for word, tag in tagged:
            lemmatized.append(self.lemmatize_word(word, tag))
        return lemmatized
    
    def get_pos_tag(self, sentence):
        sentence = self.remove_punctuation(sentence)
        tokens = word_tokenize(sentence)
        return [tag for word, tag in pos_tag(tokens)]
    
    def remove_punctuation(self, sentence):
        return ''.join(char for char in sentence if char.isalnum() or char.isspace())
    
    def lemmatize_word(self, word, tag):
        pos_tag = 'n'
        if tag.startswith('J'):
            pos_tag = 'a'
        elif tag.startswith('V'):
            pos_tag = 'v'
        elif tag.startswith('N'):
            pos_tag = 'n'
        elif tag.startswith('R'):
            pos_tag = 'r'
        return self.lemmatizer.lemmatize(word, pos_tag)