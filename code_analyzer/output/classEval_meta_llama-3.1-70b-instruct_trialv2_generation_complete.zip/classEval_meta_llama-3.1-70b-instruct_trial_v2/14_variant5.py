import sqlite3
from contextlib import contextmanager

class BookManagementDB:
    def __init__(self, db_name):
        self.connection = sqlite3.connect(db_name)
        self.cursor = self.connection.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS books
            (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, author TEXT, availability INTEGER)
        ''')
        self.connection.commit()

    @contextmanager
    def transaction(self):
        try:
            yield
            self.connection.commit()
        except Exception as e:
            self.connection.rollback()
            raise e

    def add_book(self, title, author):
        with self.transaction():
            self.cursor.execute('INSERT INTO books (title, author, availability) VALUES (?, ?, 1)', (title, author))

    def remove_book(self, book_id):
        with self.transaction():
            self.cursor.execute('DELETE FROM books WHERE id = ?', (book_id,))

    def borrow_book(self, book_id):
        with self.transaction():
            self.cursor.execute('UPDATE books SET availability = 0 WHERE id = ? AND availability = 1', (book_id,))

    def return_book(self, book_id):
        with self.transaction():
            self.cursor.execute('UPDATE books SET availability = 1 WHERE id = ? AND availability = 0', (book_id,))

    def search_books(self):
        self.cursor.execute('SELECT * FROM books')
        return self.cursor.fetchall()