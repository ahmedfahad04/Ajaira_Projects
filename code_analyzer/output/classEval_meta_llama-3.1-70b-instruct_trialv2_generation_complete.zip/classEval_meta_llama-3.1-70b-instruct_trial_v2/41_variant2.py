class GomokuGame:
    def __init__(self, board_size):
        self.board_size = board_size
        self.board = [[' ' for _ in range(board_size)] for _ in range(board_size)]
        self.current_player = 'X'

    def make_move(self, row, col):
        if self.board[row][col] != ' ':
            return False
        self.board[row][col] = self.current_player
        self.current_player = 'O' if self.current_player == 'X' else 'X'
        return True

    def check_winner(self):
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for i in range(self.board_size):
            for j in range(self.board_size):
                if self.board[i][j] != ' ':
                    for direction in directions:
                        if self._check_five_in_a_row(i, j, direction):
                            return self.board[i][j]
        return None

    def _check_five_in_a_row(self, row, col, direction):
        player = self.board[row][col]
        count = 1
        dx, dy = direction
        new_row, new_col = row + dx, col + dy
        while 0 <= new_row < self.board_size and 0 <= new_col < self.board_size and self.board[new_row][new_col] == player:
            count += 1
            new_row += dx
            new_col += dy
        return count == 5