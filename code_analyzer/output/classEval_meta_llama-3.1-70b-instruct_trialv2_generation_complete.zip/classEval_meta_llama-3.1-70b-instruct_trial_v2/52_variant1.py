import nltk
from nltk.stem import WordNetLemmatizer
from nltk import pos_tag, word_tokenize
import string
nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')
nltk.download('wordnet')

class Lemmatization:
    def __init__(self):
        self.lemmatizer = WordNetLemmatizer()
        self.pos_tags = {'JJ': 'a', 'VB': 'v', 'NN': 'n', 'RB': 'r'}
        
    def lemmatize_sentence(self, sentence):
        sentence = self.remove_punctuation(sentence)
        tokens = word_tokenize(sentence)
        tagged = pos_tag(tokens)
        lemmatized = []
        for word, tag in tagged:
            pos_tag = self.pos_tags.get(tag[:2], 'n')
            lemmatized.append(self.lemmatizer.lemmatize(word, pos_tag))
        return lemmatized
    
    def get_pos_tag(self, sentence):
        sentence = self.remove_punctuation(sentence)
        tokens = word_tokenize(sentence)
        return [tag for word, tag in pos_tag(tokens)]
    
    def remove_punctuation(self, sentence):
        return sentence.translate(str.maketrans('', '', string.punctuation))