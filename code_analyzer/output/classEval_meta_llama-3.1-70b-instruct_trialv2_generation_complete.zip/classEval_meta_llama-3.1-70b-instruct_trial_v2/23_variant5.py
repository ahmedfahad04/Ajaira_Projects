import math
from typing import List

class CombinationCalculator:
    def __init__(self, datas: List[str]):
        self.datas = datas

    @staticmethod
    def count(n: int, m: int) -> int:
        if m > n:
            return 0
        return math.comb(n, m)

    @staticmethod
    def count_all(n: int) -> int:
        result = 0
        for i in range(n + 1):
            result += math.comb(n, i)
        return result if result <= 2**63-1 else float("inf")

    def select(self, m: int) -> List[List[str]]:
        def get_combinations(data, m):
            if m == 0:
                return [[]]
            combinations = []
            for i in range(len(data)):
                current = data[i]
                rest = data[i + 1:]
                for c in get_combinations(rest, m - 1):
                    combinations.append([current] + c)
            return combinations

        return get_combinations(self.datas, m)

    def select_all(self) -> List[List[str]]:
        result = []
        for i in range(len(self.datas) + 1):
            result.extend(self.select(i))
        return result