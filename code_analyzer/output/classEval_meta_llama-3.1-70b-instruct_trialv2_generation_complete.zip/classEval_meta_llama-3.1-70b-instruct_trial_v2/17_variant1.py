from datetime import datetime, timedelta

class CalendarUtil:
    def __init__(self):
        self.events = []

    def add_event(self, event):
        self.events.append(event)

    def remove_event(self, event):
        self.events = [e for e in self.events if e != event]

    def get_events(self, date):
        return [e for e in self.events if e['date'] == date]

    def is_available(self, start_time, end_time):
        for event in self.events:
            if event['start_time'] < end_time and event['end_time'] > start_time:
                return False
        return True

    def get_available_slots(self, date):
        slots = []
        events = sorted(self.get_events(date), key=lambda x: x['start_time'])
        if not events or events[0]['start_time'] > date:
            slots.append((date, events[0]['start_time'] if events else datetime(date.year, date.month, date.day, 23, 59)))
        for i in range(len(events) - 1):
            if events[i]['end_time'] < events[i+1]['start_time']:
                slots.append((events[i]['end_time'], events[i+1]['start_time']))
        if events and events[-1]['end_time'] < datetime(date.year, date.month, date.day, 23, 59):
            slots.append((events[-1]['end_time'], datetime(date.year, date.month, date.day, 23, 59)))
        return slots

    def get_upcoming_events(self, num_events):
        upcoming_events = sorted(self.events, key=lambda x: x['start_time'])
        return upcoming_events[:num_events]