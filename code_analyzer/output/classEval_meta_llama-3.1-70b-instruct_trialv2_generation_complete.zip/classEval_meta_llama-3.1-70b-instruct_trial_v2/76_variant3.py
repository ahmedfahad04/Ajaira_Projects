class SignInSystem:
    def __init__(self):
        self.users = {}

    def add_user(self, username):
        if username not in self.users:
            self.users[username] = {'signed_in': False}
            return True
        return False

    def sign_in(self, username):
        if username in self.users:
            self.users[username]['signed_in'] = True
            return True
        return False

    def check_sign_in(self, username):
        return self.users.get(username, {}).get('signed_in', False)

    def all_signed_in(self):
        return all(user['signed_in'] for user in self.users.values())

    def all_not_signed_in(self):
        return [username for username, user in self.users.items() if not user['signed_in']]