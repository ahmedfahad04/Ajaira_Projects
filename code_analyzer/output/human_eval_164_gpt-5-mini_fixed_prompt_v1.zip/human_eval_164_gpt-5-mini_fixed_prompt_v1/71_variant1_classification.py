import math

def triangle_area(a, b, c):
    # convert to floats
    try:
        a = float(a); b = float(b); c = float(c)
    except Exception:
        return -1
    # sides must be positive
    if a <= 0 or b <= 0 or c <= 0:
        return -1.0
    # use sorted sides for triangle inequality
    x, y, z = sorted((a, b, c))
    if x + y <= z:
        return -1.0
    s = (a + b + c) / 2.0
    area_sq = s * (s - a) * (s - b) * (s - c)
    if area_sq < 0:
        # numerical guard
        area_sq = 0.0
    area = math.sqrt(area_sq)
    return round(area, 2)

# Classification response:
# try-except wrapper; guard clause; input validation; type conversion; boundary case handling; tuple unpacking; temporary variable; standard library helper; import reorganization; literal rewrite