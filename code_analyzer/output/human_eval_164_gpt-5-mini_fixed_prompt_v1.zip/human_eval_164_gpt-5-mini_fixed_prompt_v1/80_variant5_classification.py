from collections import deque

def is_happy(s):
    if len(s) < 3:
        return False
    q = deque(maxlen=3)
    for ch in s:
        q.append(ch)
        if len(q) == 3:
            if len(set(q)) != 3:
                return False
    return True

# Classification response:
# sliding window; loop rewrite; set conversion; standard library helper; early return; helper function extraction; state variable; import reorganization