def correct_bracketing(brackets: str):
    bal = 0
    for ch in brackets:
        if ch == "(":
            bal += 1
        else:
            bal -= 1
        if bal < 0:
            return False
    return bal == 0

# Classification response:
# variable renaming; function renaming; helper function extraction; type annotation