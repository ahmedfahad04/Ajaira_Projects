def below_threshold(l: list, t: int):
    if not l:
        return True
    if l[0] >= t:
        return False
    return below_threshold(l[1:], t)

# Classification response:
# helper function extraction; recursion with base case; guard clause; slicing