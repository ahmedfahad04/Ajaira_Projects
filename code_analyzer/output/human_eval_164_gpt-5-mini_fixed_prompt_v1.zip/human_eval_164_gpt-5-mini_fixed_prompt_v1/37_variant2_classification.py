import heapq
def sort_even(l: list):
    ev_indices = list(range(0, len(l), 2))
    if not ev_indices:
        return list(l)
    heap = [l[i] for i in ev_indices]
    heapq.heapify(heap)
    res = list(l)
    for i in ev_indices:
        res[i] = heapq.heappop(heap)
    return res

# Classification response:
# heap-based; standard library helper; helper function extraction; early return; index-based loop; list comprehension; copy before mutation; in-place mutation