def sort_even(l: list):
    res = list(l)
    n = len(res)
    even_idxs = list(range(0, n, 2))
    for i in range(len(even_idxs)):
        min_j = i
        for j in range(i+1, len(even_idxs)):
            if res[even_idxs[j]] < res[even_idxs[min_j]]:
                min_j = j
        if min_j != i:
            a = even_idxs[i]
            b = even_idxs[min_j]
            res[a], res[b] = res[b], res[a]
    return res

# Classification response:
# function renaming; variable renaming; loop rewrite; index-based loop; brute force; copy before mutation; in-place mutation; tuple unpacking; temporary variable