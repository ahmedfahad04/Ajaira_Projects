def sort_third(l: list):
    sorted_vals = iter(sorted([x for i, x in enumerate(l) if i % 3 == 0]))
    return [next(sorted_vals) if i % 3 == 0 else x for i, x in enumerate(l)]

# Classification response:
# function renaming; list comprehension; enumerate loop; conditional expression; temporary variable; behavior change