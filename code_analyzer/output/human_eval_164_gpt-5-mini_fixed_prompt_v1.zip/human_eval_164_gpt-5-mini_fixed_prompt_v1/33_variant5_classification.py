import heapq
def sort_third(l: list):
    heap = [v for i, v in enumerate(l) if i % 3 == 0]
    heapq.heapify(heap)
    res = []
    for i, v in enumerate(l):
        if i % 3 == 0:
            res.append(heapq.heappop(heap))
        else:
            res.append(v)
    return res

# Classification response:
# heap-based; standard library helper; import reorganization; enumerate loop; list comprehension; accumulator list; temporary variable