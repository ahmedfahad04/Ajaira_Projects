import re
from typing import List

def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    pattern = re.compile(re.escape(substring))
    return [s for s in strings if pattern.search(s)]

# Classification response:
# helper function extraction; type annotations; regex usage; temporary variable; list comprehension