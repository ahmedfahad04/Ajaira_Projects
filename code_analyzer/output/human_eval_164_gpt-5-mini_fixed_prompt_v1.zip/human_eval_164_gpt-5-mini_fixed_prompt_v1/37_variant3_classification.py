def sort_even(l: list):
    ev_pairs = [(i, l[i]) for i in range(0, len(l), 2)]
    ev_pairs.sort(key=lambda x: x[1])
    res = list(l)
    for (target_index, (_, value)) in zip(range(0, len(l), 2), ev_pairs):
        res[target_index] = value
    return res

# Classification response:
# function renaming; variable renaming; list comprehension; sort key; lambda expression; zip usage; index-based loop; tuple unpacking; copy before mutation; in-place mutation; temporary variable; sorting-based approach