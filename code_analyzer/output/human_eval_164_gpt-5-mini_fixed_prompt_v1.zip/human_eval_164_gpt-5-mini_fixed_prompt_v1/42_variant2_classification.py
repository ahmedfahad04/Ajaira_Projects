def incr_list(l: list):
    return list(map(lambda x: x + 1, l))

# Classification response:
# variable renaming; helper function extraction; map/filter usage; lambda expression; list conversion; list comprehension; type annotation addition