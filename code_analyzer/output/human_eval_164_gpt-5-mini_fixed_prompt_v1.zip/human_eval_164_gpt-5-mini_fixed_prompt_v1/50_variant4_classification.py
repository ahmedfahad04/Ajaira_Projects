def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    Uses bytearray manipulation for ASCII lowercase characters; falls back per-char for non-ASCII.
    """
    try:
        b = bytearray(s, "ascii")
    except UnicodeEncodeError:
        # fallback: handle arbitrarily encoded characters by per-char processing
        res = []
        for ch in s:
            if 'a' <= ch <= 'z':
                res.append(chr((ord(ch) - ord('a') + 5) % 26 + ord('a')))
            else:
                res.append(ch)
        return "".join(res)
    for i in range(len(b)):
        if 97 <= b[i] <= 122:  # a-z
            b[i] = ((b[i] - 97 + 5) % 26) + 97
    return b.decode("ascii")

# Classification response:
# helper function extraction; try-except wrapper; early return; loop rewrite; for loop; in-place mutation; standard library helper; accumulator list; temporary variable; boundary case handling; behavior change