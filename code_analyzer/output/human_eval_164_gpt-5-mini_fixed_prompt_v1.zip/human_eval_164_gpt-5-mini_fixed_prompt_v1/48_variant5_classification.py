def is_palindrome(text: str):
    return all(text[i] == text[-i-1] for i in range(len(text) // 2))

# Classification response:
# loop rewrite; generator expression; any/all usage; two pointer; helper function extraction