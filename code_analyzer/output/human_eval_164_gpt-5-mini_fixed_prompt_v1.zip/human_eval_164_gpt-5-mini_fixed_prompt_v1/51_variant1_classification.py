def remove_vowels(text):
    vowels = set("aeiouAEIOU")
    return ''.join(ch for ch in text if ch not in vowels)

# Classification response:
# helper function extraction; variable renaming; temporary variable; set conversion; generator expression; accumulator list; literal rewrite