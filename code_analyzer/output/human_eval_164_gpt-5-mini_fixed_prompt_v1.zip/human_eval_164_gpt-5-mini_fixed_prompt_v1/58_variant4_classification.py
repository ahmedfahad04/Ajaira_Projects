def common(l1: list, l2: list):
    seen = {}
    for x in l1:
        seen[x] = True
    out = []
    added = set()
    for y in l2:
        if y in seen and y not in added:
            out.append(y)
            added.add(y)
    return sorted(out)

# Classification response:
# variable renaming; function renaming; loop rewrite; dictionary lookup; accumulator list; accumulator set; membership test; temporary variable; frequency counting