def digitSum(s):
    return sum(ord(ch) for ch in s if 'A' <= ch <= 'Z')

# Classification response:
# function renaming; variable renaming; guard clause; generator expression; conditional expression; membership test; literal rewrite