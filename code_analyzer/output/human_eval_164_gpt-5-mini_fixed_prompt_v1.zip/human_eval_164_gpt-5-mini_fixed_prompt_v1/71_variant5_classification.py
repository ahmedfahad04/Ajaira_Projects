import math

def triangle_area(a, b, c):
    # use alternative Heron form: area = 0.25*sqrt((a+b+c)(-a+b+c)(a-b+c)(a+b-c))
    try:
        a = float(a); b = float(b); c = float(c)
    except Exception:
        return -1.0
    if a <= 0 or b <= 0 or c <= 0:
        return -1.0
    P = a + b + c
    x1 = -a + b + c
    x2 = a - b + c
    x3 = a + b - c
    # check triangle inequality (all xi must be > 0)
    if not (x1 > 0 and x2 > 0 and x3 > 0):
        return -1.0
    val = P * x1 * x2 * x3
    if val < 0:
        return -1.0
    area = 0.25 * math.sqrt(val)
    return round(area, 2)

# Classification response:
# function renaming; variable renaming; temporary variable; combined condition; try-except wrapper; type conversion; input validation; standard library helper; mathematical formula; import reorganization; literal rewrite