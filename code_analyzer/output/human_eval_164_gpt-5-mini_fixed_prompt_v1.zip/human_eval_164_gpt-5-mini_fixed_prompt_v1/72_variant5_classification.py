def will_it_fly(q,w):
    from functools import reduce
    is_pal = all(q[i] == q[-1-i] for i in range(len(q)//2))
    total = reduce(lambda a,b: a+b, q, 0)
    return is_pal and total <= w

# Classification response:
# function renaming; import reorganization; functools reduce; lambda expression; any/all usage; generator expression; loop rewrite; combined condition; flattened conditional; temporary variable