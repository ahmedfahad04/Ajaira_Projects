def correct_bracketing(brackets: str):
    s = brackets
    prev = None
    while prev != s:
        prev = s
        s = s.replace('<>', '')
    return s == ''

# Classification response:
# loop rewrite; while loop; sentinel flag; copy before mutation; standard library helper; variable renaming; brute force