from functools import reduce

def intersperse(numbers: list[int], delimeter: int) -> list[int]:
    if not numbers:
        return []
    return reduce(lambda acc, x: acc + [delimeter, x], numbers[1:], [numbers[0]])

# Classification response:
# loop rewrite;functools reduce;lambda expression;accumulator list;copy before mutation;slicing;helper function extraction;import reorganization