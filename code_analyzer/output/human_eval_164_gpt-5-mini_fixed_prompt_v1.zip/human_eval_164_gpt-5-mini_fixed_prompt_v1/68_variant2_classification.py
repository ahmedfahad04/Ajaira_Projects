def pluck(arr):
    pairs = [(v, i) for i, v in enumerate(arr) if v % 2 == 0]
    if not pairs:
        return []
    val, idx = min(pairs)
    return [val, idx]

# Classification response:
# function renaming; helper function extraction; variable renaming; list comprehension; tuple unpacking; enumerate loop; early return