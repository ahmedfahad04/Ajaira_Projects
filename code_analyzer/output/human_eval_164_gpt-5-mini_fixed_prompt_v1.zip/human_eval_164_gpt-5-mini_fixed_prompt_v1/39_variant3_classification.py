import math
import random

def prime_fib(n: int):
    if n <= 0:
        raise ValueError("n must be positive")

    def is_prime_trial(x):
        if x < 2:
            return False
        if x % 2 == 0:
            return x == 2
        r = int(math.isqrt(x))
        f = 3
        while f <= r:
            if x % f == 0:
                return False
            f += 2
        return True

    def miller_rabin(n):
        if n < 2:
            return False
        small = [2,3,5,7,11,13,17,19,23]
        for p in small:
            if n % p == 0:
                return n == p
        d = n - 1
        s = 0
        while d % 2 == 0:
            d //= 2
            s += 1
        def check(a):
            x = pow(a, d, n)
            if x == 1 or x == n-1:
                return True
            for _ in range(s-1):
                x = (x*x) % n
                if x == n-1:
                    return True
            return False
        for a in [2, 7, 61]:  # deterministic for 32-bit-ish ints, probabilistic otherwise
            if a % n == 0:
                continue
            if not check(a):
                return False
        return True

    # simple fibonacci generator and test primality with Miller-Rabin
    a, b = 1, 1
    count = 0
    while True:
        a, b = b, a + b
        if a > 1 and miller_rabin(a):
            count += 1
            if count == n:
                return a

# Classification response:
# function renaming; helper function extraction; probabilistic primality test; standard library helper; builtin function; tuple unpacking; guard clause; early return; input validation; import reorganization; state variable