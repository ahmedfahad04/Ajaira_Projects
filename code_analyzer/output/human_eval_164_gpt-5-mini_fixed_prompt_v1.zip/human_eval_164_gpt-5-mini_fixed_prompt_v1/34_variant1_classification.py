def unique(l: list):
    return sorted(set(l))

# Classification response:
# helper function extraction; set conversion; list conversion; parameter type annotation