from typing import List

def rolling_max(numbers: List[int]) -> List[int]:
    def helper(i: int, curr_max: int, out: List[int]) -> List[int]:
        if i >= len(numbers):
            return out
        val = numbers[i]
        new_max = val if curr_max is None or val > curr_max else curr_max
        out.append(new_max)
        return helper(i + 1, new_max, out)
    return helper(0, None, [])

# Classification response:
# recursion; helper function extraction; loop rewrite; accumulator list; in-place mutation; conditional expression; combined condition; temporary variable; variable renaming; parameter renaming