def incr_list(l: list):
    # modify in place and return the same list
    for i in range(len(l)):
        l[i] = l[i] + 1
    return l

# Classification response:
# helper function extraction;index-based loop;list comprehension;in-place mutation;behavior change