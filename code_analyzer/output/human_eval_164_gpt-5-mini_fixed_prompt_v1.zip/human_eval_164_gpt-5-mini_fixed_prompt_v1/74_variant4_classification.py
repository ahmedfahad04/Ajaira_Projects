def total_match(lst1, lst2):
    # use min with a key; min returns the first encountered minimum on ties
    return min((lst1, lst2), key=lambda L: sum(len(s) for s in L))

# Classification response:
# helper function extraction; loop rewrite; generator expression; lambda expression; sort key; builtin function; temporary variable; conditional expression