def fib4(n: int):
    if n < 0:
        raise ValueError("n must be non-negative")
    bases = [0, 0, 2, 0]
    if n < 4:
        return bases[n]
    seq = bases[:]  # build iteratively
    for i in range(4, n + 1):
        seq.append(seq[-1] + seq[-2] + seq[-3] + seq[-4])
    return seq[n]

# Classification response:
# variable renaming; accumulator list; copy before mutation; for loop; guard clause; input validation; temporary variable