def decimal_to_binary(decimal):
    n = decimal
    if n == 0:
        return "db0db"
    sign = ""
    if n < 0:
        sign = "-"
        n = -n
    bl = n.bit_length()
    bits = []
    for i in range(bl - 1, -1, -1):
        bits.append("1" if (n >> i) & 1 else "0")
    return "db" + sign + "".join(bits) + "db"

# Classification response:
# helper function extraction; function renaming; guard clause; accumulator list; for loop; temporary variable; join/split usage; string formatting change; boundary case handling; state variable; builtin function