from functools import reduce
def max_element(l: list):
    if not l:
        raise ValueError("max_element() arg is an empty sequence")
    return reduce(lambda a, b: a if a >= b else b, l)

# Classification response:
# loop rewrite; functools reduce; lambda expression; helper function extraction; import reorganization; input validation; empty input handling