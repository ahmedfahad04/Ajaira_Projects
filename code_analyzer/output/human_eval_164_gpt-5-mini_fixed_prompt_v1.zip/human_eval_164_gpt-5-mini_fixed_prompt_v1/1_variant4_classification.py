from typing import List

def separate_paren_groups(paren_string: str) -> List[str]:
    s = ''.join(paren_string.split())
    res: List[str] = []
    stack: List[int] = []
    start = None
    for i, ch in enumerate(s):
        if ch == '(':
            if not stack:
                start = i
            stack.append(i)
        elif ch == ')':
            if stack:
                stack.pop()
                if not stack and start is not None:
                    res.append(s[start:i+1])
                    start = None
    return res

# Classification response:
# function renaming; variable renaming; enumerate loop; stack-based; accumulator list; slicing; state variable; join/split usage; standard library helper; behavior change