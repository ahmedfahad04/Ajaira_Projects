def sort_even(l: list):
    def helper(evens, odds, idx):
        if idx >= len(l):
            out = []
            ei, oi = 0, 0
            for i in range(len(l)):
                if i % 2 == 0:
                    out.append(evens[ei]); ei += 1
                else:
                    out.append(odds[oi]); oi += 1
            return out
        if idx % 2 == 0:
            evens.append(l[idx])
        else:
            odds.append(l[idx])
        return helper(evens, odds, idx+1)
    evens = []
    odds = []
    out = helper(evens, odds, 0)
    evens_sorted = sorted(out[0::2])
    res = list(out)
    ri = 0
    for i in range(0, len(res), 2):
        res[i] = evens_sorted[ri]; ri += 1
    return res

# Classification response:
# helper function extraction;recursion;guard clause;loop rewrite;index-based loop;accumulator list;slicing;in-place mutation;builtin function