def vowels_count(s):
    if not s:
        return 0
    s_lower = s.lower()
    n = len(s_lower)
    return sum(1 for i, ch in enumerate(s_lower) if (ch in 'aeiou') or (ch == 'y' and i == n - 1))

# Classification response:
# helper function extraction; early return; combined condition; enumerate loop; generator expression; membership test; temporary variable; empty input handling; literal rewrite