from typing import List
from functools import reduce
from typing import Tuple

def below_zero(operations: List[int]) -> bool:
    # reduce over operations carrying (balance, seen_negative)
    def step(state: Tuple[int, bool], op: int) -> Tuple[int, bool]:
        bal, seen = state
        if seen:
            return state
        bal += op
        return (bal, bal < 0)
    _, seen_negative = reduce(step, operations, (0, False))
    return seen_negative

# Classification response:
# loop rewrite;helper function extraction;functools reduce;tuple unpacking;state variable;sentinel flag;guard clause;import reorganization;type annotations