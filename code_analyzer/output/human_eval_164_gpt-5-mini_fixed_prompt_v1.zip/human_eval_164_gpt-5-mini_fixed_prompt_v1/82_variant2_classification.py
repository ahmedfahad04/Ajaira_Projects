def prime_length(string):
    n = len(string)
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True

# Classification response:
# helper function extraction; variable renaming; combined condition