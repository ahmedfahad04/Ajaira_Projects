def median(l: list):
    import bisect
    if not l:
        raise ValueError("median of empty list")
    s = []
    for x in l:
        bisect.insort(s, x)
    n = len(s)
    mid = n // 2
    if n % 2 == 1:
        return s[mid]
    else:
        return (s[mid - 1] + s[mid]) / 2.0

# Classification response:
# helper function extraction; import reorganization; guard clause; empty input handling; accumulator list; for loop; standard library helper; in-place mutation; temporary variable