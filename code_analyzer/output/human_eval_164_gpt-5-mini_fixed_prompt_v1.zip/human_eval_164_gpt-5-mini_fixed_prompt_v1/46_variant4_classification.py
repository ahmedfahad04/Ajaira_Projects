def fib4(n: int):
    if n < 0:
        raise ValueError("n must be non-negative")
    # base cases
    if n == 0:
        return 0
    if n == 1:
        return 0
    if n == 2:
        return 2
    if n == 3:
        return 0
    # Companion matrix for order-4 recurrence
    def mat_mul(A, B):
        size = 4
        C = [[0]*size for _ in range(size)]
        for i in range(size):
            Ai = A[i]
            Ci = C[i]
            for k in range(size):
                Aik = Ai[k]
                if Aik:
                    Bk = B[k]
                    for j in range(size):
                        Ci[j] += Aik * Bk[j]
        return C
    def mat_pow(mat, exp):
        size = 4
        # identity
        res = [[1 if i == j else 0 for j in range(size)] for i in range(size)]
        base = mat
        while exp > 0:
            if exp & 1:
                res = mat_mul(res, base)
            base = mat_mul(base, base)
            exp >>= 1
        return res
    A = [
        [1, 1, 1, 1],
        [1, 0, 0, 0],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
    ]
    # v3 = [f3, f2, f1, f0] = [0,2,0,0]
    v3 = [0, 2, 0, 0]
    power = n - 3
    M = mat_pow(A, power)
    # multiply M by v3
    res0 = M[0][0]*v3[0] + M[0][1]*v3[1] + M[0][2]*v3[2] + M[0][3]*v3[3]
    return res0

# Classification response:
# helper function extraction;matrix exponentiation;exponentiation by squaring;loop rewrite;accumulator list;in-place mutation;state variable;early return;input validation;boundary case handling