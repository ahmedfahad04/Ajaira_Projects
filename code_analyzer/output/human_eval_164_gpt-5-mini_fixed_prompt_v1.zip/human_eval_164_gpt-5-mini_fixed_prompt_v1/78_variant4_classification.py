def hex_key(num):
    primes = set("2357BD")
    if not num:
        return 0
    return (1 if num[0] in primes else 0) + hex_key(num[1:])

# Classification response:
# loop rewrite;recursion;recursion with base case;guard clause;conditional expression;set conversion;membership test;helper function extraction;empty input handling