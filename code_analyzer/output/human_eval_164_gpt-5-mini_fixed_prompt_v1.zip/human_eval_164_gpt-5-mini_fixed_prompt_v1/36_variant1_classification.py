def fizz_buzz(n: int):
    count = 0
    for i in range(n):
        if i % 11 == 0 or i % 13 == 0:
            count += str(i).count('7')
    return count

# Classification response:
# loop rewrite;accumulator list;accumulator string;temporary variable;map/filter usage;join/split usage;frequency counting