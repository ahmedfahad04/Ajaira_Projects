from typing import List
from itertools import accumulate

def rolling_max(numbers: List[int]) -> List[int]:
    return list(accumulate(numbers, max)) if numbers else []

# Classification response:
# function renaming; import reorganization; loop rewrite; itertools usage; list conversion; conditional expression; empty input handling; temporary variable