from functools import lru_cache

def fibfib(n: int):
    @lru_cache(None)
    def f(k):
        if k <= 1:
            return 0
        if k == 2:
            return 1
        return f(k - 1) + f(k - 2) + f(k - 3)
    return f(n)

# Classification response:
# helper function extraction;combined condition;parameter renaming;import reorganization;standard library helper;memoization;recursion with base case