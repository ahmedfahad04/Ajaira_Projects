def largest_prime_factor(n: int):
    import math
    largest = 1
    while n % 2 == 0:
        largest = 2
        n //= 2
    i = 3
    while i * i <= n:
        while n % i == 0:
            largest = i
            n //= i
        i += 2
    if n > 1:
        largest = n
    return int(largest)

# Classification response:
# function renaming; helper function inlining; trial division factorization; loop rewrite; while loop; in-place mutation; temporary variable; boundary case handling; type conversion; import reorganization