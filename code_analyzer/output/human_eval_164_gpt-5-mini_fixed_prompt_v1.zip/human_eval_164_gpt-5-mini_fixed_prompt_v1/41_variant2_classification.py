def car_race_collision(n: int):
    n = max(0, int(n))
    count = 0
    for _ in range(n):
        for _ in range(n):
            count += 1
    return count

# Classification response:
# function renaming; loop rewrite; for loop; temporary variable; in-place mutation; builtin function; type conversion; input validation; boundary case handling; brute force