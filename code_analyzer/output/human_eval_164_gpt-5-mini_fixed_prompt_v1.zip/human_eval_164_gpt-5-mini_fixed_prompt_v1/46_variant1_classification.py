def fib4(n: int):
    if n < 0:
        raise ValueError("n must be non-negative")
    if n == 0:
        return 0
    if n == 1:
        return 0
    if n == 2:
        return 2
    if n == 3:
        return 0
    a, b, c, d = 0, 0, 2, 0
    for _ in range(4, n + 1):
        nxt = a + b + c + d
        a, b, c, d = b, c, d, nxt
    return d

# Classification response:
# guard clause; early return; split condition; boundary case handling; input validation; state variable; tuple unpacking; temporary variable; loop rewrite; variable renaming