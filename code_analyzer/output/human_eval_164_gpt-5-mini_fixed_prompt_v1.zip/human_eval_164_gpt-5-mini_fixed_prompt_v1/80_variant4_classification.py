def is_happy(s):
    if len(s) < 3:
        return False
    for a, b, c in zip(s, s[1:], s[2:]):
        if a == b or b == c or a == c:
            return False
    return True

# Classification response:
# function renaming; loop rewrite; zip usage; tuple unpacking