def triangle_area(a, h):
    return 0.5 * a * h

# Classification response:
# helper function extraction; literal rewrite