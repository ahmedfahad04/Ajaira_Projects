def search(lst):
    from collections import Counter
    counts = Counter(lst)
    ans = -1
    for val, cnt in counts.items():
        if val > 0 and cnt >= val and val > ans:
            ans = val
    return ans

# Classification response:
# standard library helper; accumulator dict; loop rewrite; helper function extraction; combined condition; frequency counting; import reorganization