def prime_length(string):
    n = len(string)
    if n < 2:
        return False
    sieve = [True] * (n + 1)
    sieve[0:2] = [False, False]
    p = 2
    while p * p <= n:
        if sieve[p]:
            step = p
            start = p * p
            for multiple in range(start, n + 1, step):
                sieve[multiple] = False
        p += 1
    return sieve[n]

# Classification response:
# function renaming; variable renaming; guard clause; sieve of eratosthenes; accumulator list; in-place mutation; slicing; while loop; for loop