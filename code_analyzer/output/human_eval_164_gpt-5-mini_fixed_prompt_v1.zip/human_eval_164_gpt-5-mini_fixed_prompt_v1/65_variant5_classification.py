def circular_shift(x, shift):
    s = str(x)
    sign = ''
    if s.startswith('-'):
        sign = '-'
        s = s[1:]
    if s == '':
        return sign + s
    n = len(s)
    if shift > n:
        return sign + s[::-1]
    if shift == 0 or shift == n:
        return sign + s
    if shift < 0:
        # normalize negative shift to equivalent right shift
        k = (-shift) % n
        k = (n - k) % n
    else:
        k = shift
    # use doubled string and slicing to get rotation (preserves leading zeros)
    doubled = s + s
    start = n - k
    return sign + doubled[start:start + n]

# Classification response:
# helper function extraction;guard clause;flattened conditional;split condition;branch reordering;temporary variable;slicing;empty input handling;boundary case handling