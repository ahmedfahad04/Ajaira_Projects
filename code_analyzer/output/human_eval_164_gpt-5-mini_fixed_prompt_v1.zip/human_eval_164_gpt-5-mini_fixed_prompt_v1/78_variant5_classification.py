def hex_key(num):
    primes = "2357BD"
    total = 0
    for p in primes:
        total += num.count(p)
    return total

# Classification response:
# literal rewrite; helper function extraction; loop rewrite; for loop; standard library helper; frequency counting; state variable