def fizz_buzz(n: int):
    parts = []
    parts.extend(str(x) for x in range(11, n, 11))
    parts.extend(str(x) for x in range(13, n, 13))
    merged = ''.join(parts)
    return merged.count('7')

# Classification response:
# helper function extraction;loop rewrite;split condition;accumulator list;generator expression;join/split usage;builtin function;boundary case handling;behavior change