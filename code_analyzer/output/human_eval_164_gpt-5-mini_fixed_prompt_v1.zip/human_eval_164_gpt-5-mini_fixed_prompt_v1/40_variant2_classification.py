def triples_sum_to_zero(l: list):
    n = len(l)
    if n < 3:
        return False
    a = sorted(l)
    for i in range(n - 2):
        left = i + 1
        right = n - 1
        while left < right:
            s = a[i] + a[left] + a[right]
            if s == 0:
                return True
            if s < 0:
                left += 1
            else:
                right -= 1
    return False

# Classification response:
# sorting-based approach; two pointer; loop rewrite; early return; temporary variable; boundary case handling