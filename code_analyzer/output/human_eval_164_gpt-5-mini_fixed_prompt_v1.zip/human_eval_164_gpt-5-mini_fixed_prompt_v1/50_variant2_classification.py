def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    Uses str.translate with a mapping for lowercase letters.
    """
    lower = "abcdefghijklmnopqrstuvwxyz"
    shifted = lower[5:] + lower[:5]
    trans = str.maketrans(lower, shifted)
    return s.translate(trans)

# Classification response:
# list comprehension; join/split usage; standard library helper; helper function extraction; temporary variable; slicing; literal rewrite