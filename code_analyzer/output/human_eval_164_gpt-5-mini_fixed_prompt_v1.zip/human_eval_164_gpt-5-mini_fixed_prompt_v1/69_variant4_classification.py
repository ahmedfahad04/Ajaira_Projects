def search(lst):
    # iterate unique values descending, use list.count (simple brute force)
    uniques = sorted(set(lst), reverse=True)
    for v in uniques:
        if v > 0 and lst.count(v) >= v:
            return v
    return -1

# Classification response:
# set conversion; brute force; early return; reversed condition; sorting-based approach; builtin function