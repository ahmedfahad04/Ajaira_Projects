from decimal import Decimal, getcontext

def truncate_number(number: float) -> float:
    """Use Decimal for higher precision then convert back to float."""
    # set precision sufficiently high to represent the input
    getcontext().prec = 28
    d = Decimal(str(number))
    integer_part = int(d // 1)
    frac = d - Decimal(integer_part)
    return float(frac)

# Classification response:
# helper function extraction; standard library helper; type conversion; temporary variable; in-place mutation; literal rewrite