def numerical_letter_grade(grades):
    # Recursive classifier walking thresholds from highest to lowest
    pairs = [
        (4.0, 'A+'),
        (3.7, 'A'),
        (3.3, 'A-'),
        (3.0, 'B+'),
        (2.7, 'B'),
        (2.3, 'B-'),
        (2.0, 'C+'),
        (1.7, 'C'),
        (1.3, 'C-'),
        (1.0, 'D+'),
        (0.7, 'D'),
        (0.0, 'D-'),
    ]
    def classify(g, i=0):
        if i >= len(pairs):
            return 'E'
        th, label = pairs[i]
        if th == 4.0:
            if g == 4.0:
                return 'A+'
            return classify(g, i+1)
        if g > th:
            return label
        return classify(g, i+1)
    return [classify(g) if g != 0.0 else 'E' for g in grades]

# Classification response:
# function renaming; helper function extraction; recursion with base case; loop rewrite; list comprehension; tuple unpacking; state variable; early return; guard clause; boundary case handling