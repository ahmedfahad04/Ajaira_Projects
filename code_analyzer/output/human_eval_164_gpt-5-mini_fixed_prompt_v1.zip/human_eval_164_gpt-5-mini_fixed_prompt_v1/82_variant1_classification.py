import math

def prime_length(string):
    n = len(string)
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    limit = int(math.isqrt(n))
    for i in range(3, limit + 1, 2):
        if n % i == 0:
            return False
    return True

# Classification response:
# variable renaming; helper function extraction; import reorganization; loop rewrite; for loop; early return; guard clause; standard library helper; mathematical formula; boundary case handling