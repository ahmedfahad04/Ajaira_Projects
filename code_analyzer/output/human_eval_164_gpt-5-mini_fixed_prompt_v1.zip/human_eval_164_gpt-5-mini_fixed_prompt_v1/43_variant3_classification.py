from collections import Counter
def pairs_sum_to_zero(l):
    cnt = Counter(l)
    # check zero pair
    if cnt.get(0, 0) > 1:
        return True
    for x in list(cnt.keys()):
        if x != 0 and -x in cnt:
            return True
    return False

# Classification response:
# function renaming; loop rewrite; frequency counting; standard library helper; dictionary lookup; boundary case handling