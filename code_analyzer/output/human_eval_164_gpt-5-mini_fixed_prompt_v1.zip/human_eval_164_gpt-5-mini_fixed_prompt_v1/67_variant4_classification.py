import re

def fruit_distribution(s,n):
    parts = [p for p in re.split(r'\D+', s) if p != '']
    nums = [int(x) for x in parts] if parts else []
    a = nums[0] if len(nums) > 0 else 0
    b = nums[1] if len(nums) > 1 else 0
    return n - a - b

# Classification response:
# helper function extraction;regex usage;list comprehension;conditional expression;temporary variable;empty input handling;behavior change