import re

def fruit_distribution(s,n):
    nums = list(map(int, re.findall(r'-?\d+', s)))
    a = nums[0] if len(nums) > 0 else 0
    b = nums[1] if len(nums) > 1 else 0
    return n - a - b

# Classification response:
# import reorganization; regex usage; map/filter usage; list conversion; helper function extraction; conditional expression; temporary variable; default value handling; empty input handling; behavior change