def numerical_letter_grade(grades):
    # Use a list of (threshold, label) checked from highest to lowest (excluding exact 4.0 and 0.0)
    thresholds = [
        (3.7, 'A'),
        (3.3, 'A-'),
        (3.0, 'B+'),
        (2.7, 'B'),
        (2.3, 'B-'),
        (2.0, 'C+'),
        (1.7, 'C'),
        (1.3, 'C-'),
        (1.0, 'D+'),
        (0.7, 'D'),
        (0.0, 'D-'),
    ]
    out = []
    for g in grades:
        if g == 4.0:
            out.append('A+')
            continue
        if g == 0.0:
            out.append('E')
            continue
        for th, label in thresholds:
            if g > th:
                out.append(label)
                break
        else:
            out.append('E')
    return out

# Classification response:
# function renaming; variable renaming; guard clause; loop rewrite; flattened conditional; tuple unpacking; accumulator list; table-driven dispatch