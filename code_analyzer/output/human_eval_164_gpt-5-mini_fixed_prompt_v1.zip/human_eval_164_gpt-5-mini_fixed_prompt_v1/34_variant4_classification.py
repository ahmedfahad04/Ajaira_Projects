def unique(l: list):
    class Node:
        __slots__ = ("val", "left", "right")
        def __init__(self, val):
            self.val = val
            self.left = None
            self.right = None
        def insert(self, v):
            if v == self.val:
                return
            if v < self.val:
                if self.left is None:
                    self.left = Node(v)
                else:
                    self.left.insert(v)
            else:
                if self.right is None:
                    self.right = Node(v)
                else:
                    self.right.insert(v)
        def inorder(self, out):
            if self.left:
                self.left.inorder(out)
            out.append(self.val)
            if self.right:
                self.right.inorder(out)
    if not l:
        return []
    it = iter(l)
    try:
        root = Node(next(it))
    except StopIteration:
        return []
    for v in it:
        try:
            root.insert(v)
        except TypeError:
            # fallback to set-sort for incomparable types
            return sorted(set(l))
    out = []
    root.inorder(out)
    return out

# Classification response:
# guard clause; try-except wrapper; helper function extraction; tree traversal; accumulator list; state variable; set conversion; empty input handling; error suppression