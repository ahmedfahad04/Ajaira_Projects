def prime_length(string):
    n = len(string)
    if n < 2:
        return False
    d = n - 1
    s = 0
    while d % 2 == 0:
        s += 1
        d //= 2
    def check(a, s, d, n):
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            return True
        for _ in range(s - 1):
            x = (x * x) % n
            if x == n - 1:
                return True
        return False
    witnesses = [2, 3, 5, 7, 11]
    for a in witnesses:
        if a >= n:
            continue
        if not check(a, s, d, n):
            return False
    return True

# Classification response:
# function renaming; variable renaming; guard clause; helper function extraction; while loop; for loop; temporary variable; builtin function; miller-rabin primality; boundary case handling; behavior change