from typing import List
import itertools

def below_zero(operations: List[int]) -> bool:
    # use next to short-circuit finding first negative running balance
    acc = itertools.accumulate(operations, initial=0)
    first_neg = next((b for b in acc if b < 0), None)
    return first_neg is not None

# Classification response:
# function renaming; import reorganization; itertools usage; generator expression; builtin function; temporary variable