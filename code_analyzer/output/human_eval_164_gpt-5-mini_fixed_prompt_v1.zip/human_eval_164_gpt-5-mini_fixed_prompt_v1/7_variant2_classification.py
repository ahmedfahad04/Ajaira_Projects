from typing import List

def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    return list(filter(lambda s: substring in s, strings))

# Classification response:
# helper function extraction; map/filter usage; lambda expression; list conversion; import reorganization