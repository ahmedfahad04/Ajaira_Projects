from functools import reduce
def correct_bracketing(brackets: str):
    def step(acc, ch):
        count, ok = acc
        if not ok:
            return (count, False)
        if ch == '<':
            count += 1
        else:
            count -= 1
        return (count, count >= 0)
    count, ok = reduce(step, brackets, (0, True))
    return ok and count == 0

# Classification response:
# helper function extraction;functools reduce;accumulator tuple;tuple unpacking;import reorganization;state variable;sentinel flag;combined condition