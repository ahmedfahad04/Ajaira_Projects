def fruit_distribution(s,n):
    nums = []
    for token in s.replace(',', ' ').replace('.', ' ').split():
        cleaned = ''.join(ch for ch in token if (ch.isdigit() or ch == '-'))
        if cleaned and cleaned != '-':
            try:
                nums.append(int(cleaned))
            except:
                pass
    a = nums[0] if len(nums) > 0 else 0
    b = nums[1] if len(nums) > 1 else 0
    return n - a - b

# Classification response:
# variable renaming; function renaming; accumulator list; temporary variable; generator expression; join/split usage; try-except wrapper; error suppression; default value handling; empty input handling; behavior change