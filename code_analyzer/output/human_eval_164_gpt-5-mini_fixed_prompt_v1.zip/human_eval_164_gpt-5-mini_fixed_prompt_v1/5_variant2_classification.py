def intersperse(numbers: list[int], delimeter: int) -> list[int]:
    if not numbers:
        return []
    # build pairs for all but last, then add last element
    return [x for a in numbers[:-1] for x in (a, delimeter)] + [numbers[-1]]

# Classification response:
# helper function extraction; list comprehension; loop rewrite; in-place mutation; accumulator list; type annotations