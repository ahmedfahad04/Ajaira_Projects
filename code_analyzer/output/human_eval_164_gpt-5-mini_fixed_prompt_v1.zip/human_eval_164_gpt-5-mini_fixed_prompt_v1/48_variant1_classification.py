def is_palindrome(text: str):
    return text == text[::-1]

# Classification response:
# helper function extraction; loop rewrite; index-based loop; slicing; flattened conditional