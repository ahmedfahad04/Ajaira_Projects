import math

def prime_fib(n: int):
    if n <= 0:
        raise ValueError("n must be positive")

    def is_prime_small(x):
        if x < 2:
            return False
        if x % 2 == 0:
            return x == 2
        r = int(math.isqrt(x))
        i = 3
        while i <= r:
            if x % i == 0:
                return False
            i += 2
        return True

    # Fast doubling iterative
    def fib_fast(k):
        a, b = 0, 1
        # use binary method storing pairs
        def dbl(x, y):
            c = x * (2 * y - x)
            d = x * x + y * y
            return c, d
        bits = bin(k)[2:]
        for bit in bits:
            a, b = dbl(a, b)
            if bit == '1':
                a, b = b, a + b
        return a

    # simple incremental prime generator for indices using trial division
    def gen_primes():
        yield 2
        i = 3
        while True:
            if is_prime_small(i):
                yield i
            i += 2

    count = 0
    for p in gen_primes():
        # handle exceptional index 4
        if p == 2:
            f = fib_fast(2)
        else:
            f = fib_fast(p)
        if is_prime_small(f):
            count += 1
            if count == n:
                return f

# Classification response:
# function renaming; helper function extraction; input validation; boundary case handling; mathematical formula; loop rewrite; while loop; tuple unpacking; standard library helper; generator expression