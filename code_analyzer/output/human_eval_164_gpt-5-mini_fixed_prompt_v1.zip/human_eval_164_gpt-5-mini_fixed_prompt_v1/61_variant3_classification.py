def correct_bracketing(brackets: str):
    n = len(brackets)
    def helper(i, bal):
        if bal < 0:
            return False
        if i == n:
            return bal == 0
        if brackets[i] == "(":
            return helper(i + 1, bal + 1)
        else:
            return helper(i + 1, bal - 1)
    return helper(0, 0)

# Classification response:
# helper function extraction; recursion with base case; guard clause; loop rewrite; state variable; temporary variable