def iscube(a):
    if a == 0:
        return True
    n = abs(a)
    lo, hi = 0, n if n > 1 else 1
    while lo <= hi:
        mid = (lo + hi) // 2
        cube = mid * mid * mid
        if cube == n:
            return True
        if cube < n:
            lo = mid + 1
        else:
            hi = mid - 1
    return False

# Classification response:
# function renaming; guard clause; early return; while loop; binary search; temporary variable; boundary case handling; behavior change