def is_simple_power(x, n):
    # Iterative division approach
    if x == 1:
        return True
    if n == 1:
        return x == 1
    if n == 0:
        return x == 0
    if x == 0:
        return n == 0
    # repeatedly divide by n while divisible
    try:
        while x % n == 0:
            x //= n
    except Exception:
        return False
    return x == 1

# Classification response:
# function renaming; loop rewrite; guard clause; try-except wrapper; in-place mutation; boundary case handling; input validation; iterative division