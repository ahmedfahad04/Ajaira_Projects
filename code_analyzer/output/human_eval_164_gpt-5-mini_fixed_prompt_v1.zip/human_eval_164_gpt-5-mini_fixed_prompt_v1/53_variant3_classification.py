def add(x: int, y: int):
    # iterative increment/decrement to avoid using + directly in one step
    if y >= 0:
        while y:
            x += 1
            y -= 1
    else:
        while y:
            x -= 1
            y += 1
    return x

# Classification response:
# helper function extraction; while loop; split condition; brute force; in-place mutation