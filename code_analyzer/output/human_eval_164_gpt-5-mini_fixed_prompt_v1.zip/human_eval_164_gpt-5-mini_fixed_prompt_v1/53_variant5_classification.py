def add(x: int, y: int):
    return sum((x, y))

# Classification response:
# helper function extraction; builtin function; type annotations added