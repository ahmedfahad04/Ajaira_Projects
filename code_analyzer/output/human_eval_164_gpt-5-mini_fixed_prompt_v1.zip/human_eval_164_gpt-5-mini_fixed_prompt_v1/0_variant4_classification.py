from typing import List
import bisect

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    if threshold <= 0:
        return False
    sorted_list: List[float] = []
    for x in numbers:
        i = bisect.bisect_left(sorted_list, x)
        if i > 0 and x - sorted_list[i - 1] < threshold:
            return True
        if i < len(sorted_list) and sorted_list[i] - x < threshold:
            return True
        sorted_list.insert(i, x)
    return False

# Classification response:
# function renaming;helper function extraction;loop rewrite;for loop;bisect usage;sorting-based approach;accumulator list;in-place mutation;guard clause;input validation;boundary case handling