def monotonic(l: list):
    # Using differences (works for numeric types)
    if len(l) < 2:
        return True
    diffs = [l[i+1] - l[i] for i in range(len(l)-1)]
    nonzero = [d for d in diffs if d != 0]
    if not nonzero:
        return True
    return all(d >= 0 for d in nonzero) or all(d <= 0 for d in nonzero)

# Classification response:
# guard clause; empty input handling; list comprehension; generator expression; temporary variable; any/all usage; sorting-based approach; adjacent difference