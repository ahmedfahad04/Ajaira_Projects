from bisect import bisect_left

def _exists_sorted(arr, x):
    i = bisect_left(arr, x)
    return i < len(arr) and arr[i] == x

def common(l1: list, l2: list):
    b = sorted(set(l2))
    res = []
    seen = set()
    for x in set(l1):
        if x in seen:
            continue
        if _exists_sorted(b, x):
            res.append(x)
            seen.add(x)
    return sorted(res)

# Classification response:
# binary search; sorting-based approach; set conversion; accumulator list; accumulator set; helper function extraction; loop rewrite; guard clause; standard library helper; import reorganization