def prime_length(string):
    n = len(string)
    if n < 2:
        return False
    def is_prime(k, i=2):
        if i * i > k:
            return True
        if k % i == 0:
            return False
        return is_prime(k, i + 1)
    return is_prime(n)

# Classification response:
# function renaming; variable renaming; helper function extraction; loop rewrite; recursion with base case; combined condition; mathematical formula