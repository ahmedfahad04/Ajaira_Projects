def is_palindrome(text: str):
    from collections import deque
    d = deque(text)
    while len(d) > 1:
        if d.popleft() != d.pop():
            return False
    return True

# Classification response:
# helper function extraction; loop rewrite; while loop; two pointer; queue-based; standard library helper; import reorganization; temporary variable; early return