def circular_shift(x, shift):
    s = str(x)
    sign = ''
    if s.startswith('-'):
        sign = '-'
        s = s[1:]
    if not s:
        return sign + s
    n = len(s)
    if shift > n:
        return sign + s[::-1]
    if shift == 0 or n == 0:
        return sign + s
    if shift < 0:
        # convert negative right shift into equivalent positive right shift
        k = (-shift) % n
        # perform as right shift of (n-k)
        k = (n - k) % n
    else:
        k = shift
    # arithmetic approach (may drop leading zeros)
    try:
        xi = int(s)
    except:
        return sign + s
    if k == 0 or k == n:
        return sign + s
    pow_k = 10 ** k
    last = xi % pow_k
    first = xi // pow_k
    new = last * (10 ** (n - k)) + first
    return sign + str(new)

# Classification response:
# helper function extraction;guard clause;try-except wrapper;temporary variable;mathematical formula;prefix/suffix computation;empty input handling;boundary case handling;type conversion;error suppression