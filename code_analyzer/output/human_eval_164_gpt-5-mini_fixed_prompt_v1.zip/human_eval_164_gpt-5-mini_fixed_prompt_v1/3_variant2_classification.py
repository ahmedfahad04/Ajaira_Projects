from typing import List
import itertools

def below_zero(operations: List[int]) -> bool:
    # use accumulate and any to detect a negative running balance
    return any(b < 0 for b in itertools.accumulate(operations, initial=0)) if hasattr(itertools, 'accumulate') else any(b < 0 for b in __import__('itertools').accumulate(operations, initial=0))

# Classification response:
# helper function extraction; import reorganization; itertools usage; any/all usage; generator expression; loop rewrite; state variable