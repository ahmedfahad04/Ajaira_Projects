def fib4(n: int):
    if n < 0:
        raise ValueError("n must be non-negative")
    if n == 0:
        return 0
    if n == 1:
        return 0
    if n == 2:
        return 2
    if n == 3:
        return 0
    dp = [0, 0, 2, 0]
    window_sum = sum(dp)
    idx = 4
    while idx <= n:
        nxt = window_sum
        dp.append(nxt)
        window_sum += nxt
        window_sum -= dp[-5]  # remove the element that fell out of the 4-size window
        idx += 1
    return dp[n]

# Classification response:
# function renaming;guard clause;early return;split condition;loop rewrite;while loop;sliding window;accumulator list;temporary variable;builtin function;input validation;boundary case handling