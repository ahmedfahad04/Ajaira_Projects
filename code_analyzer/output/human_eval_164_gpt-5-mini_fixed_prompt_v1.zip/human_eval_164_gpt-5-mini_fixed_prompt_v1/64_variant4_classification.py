def vowels_count(s):
    s = s or ""
    s = s.lower()
    def helper(i):
        if i >= len(s):
            return 0
        ch = s[i]
        add = 0
        if ch in "aeiou":
            add = 1
        elif ch == 'y' and i == len(s) - 1:
            add = 1
        return add + helper(i + 1)
    return helper(0)

# Classification response:
# recursion with base case;helper function extraction;default value handling;boundary case handling;function renaming;literal rewrite;membership test;temporary variable;generator expression