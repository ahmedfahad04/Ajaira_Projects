def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    Recursive implementation for demonstration (handles lowercase letters only).
    """
    if s == "":
        return ""
    ch = s[0]
    if 'a' <= ch <= 'z':
        first = chr((ord(ch) - ord('a') + 5) % 26 + ord('a'))
    else:
        first = ch
    return first + encode_shift(s[1:])

# Classification response:
# list comprehension; recursion; helper function extraction; guard clause; accumulator string; temporary variable; membership test; literal rewrite; behavior change; empty input handling