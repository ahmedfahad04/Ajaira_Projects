def strange_sort_list(lst):
    s = sorted(lst)
    n = len(s)
    res = []
    for i in range((n + 1) // 2):
        res.append(s[i])
        j = n - 1 - i
        if j != i:
            res.append(s[j])
    return res

# Classification response:
# function renaming; loop rewrite; for loop; index-based loop; temporary variable; copy before mutation; builtin function; sorting-based approach; two pointer