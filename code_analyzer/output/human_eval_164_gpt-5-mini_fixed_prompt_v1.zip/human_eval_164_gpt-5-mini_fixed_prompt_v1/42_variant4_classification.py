def incr_list(l: list):
    # recursive approach
    if not l:
        return []
    return [l[0] + 1] + incr_list(l[1:])

# Classification response:
# helper function extraction; recursion with base case; guard clause; list comprehension; empty input handling