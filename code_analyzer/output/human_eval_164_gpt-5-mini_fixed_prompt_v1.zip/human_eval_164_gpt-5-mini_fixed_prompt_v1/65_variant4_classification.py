def circular_shift(x, shift):
    s = str(x)
    sign = ''
    if s.startswith('-'):
        sign = '-'
        s = s[1:]
    if s == '':
        return sign + s
    n = len(s)
    if shift > n:
        return sign + s[::-1]
    if shift == 0:
        return sign + s
    if shift < 0:
        # recursive left shifts
        k = (-shift) % n
        def left_rotate(st):
            return st[1:] + st[:1]
        res = s
        for _ in range(k):
            res = left_rotate(res)
        return sign + res
    if shift == n:
        return sign + s
    # recursive right shift by one repeated
    def right_once(st):
        return st[-1] + st[:-1]
    res = s
    for _ in range(shift):
        res = right_once(res)
    return sign + res

# Classification response:
# helper function extraction;for loop;accumulator string;brute force;early return;empty input handling;boundary case handling;input validation;type conversion