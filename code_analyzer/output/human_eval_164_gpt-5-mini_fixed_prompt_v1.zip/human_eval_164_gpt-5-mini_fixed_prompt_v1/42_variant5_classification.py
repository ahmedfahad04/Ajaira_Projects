def incr_list(l: list):
    from operator import add
    from itertools import repeat
    return list(map(add, l, repeat(1)))

# Classification response:
# map/filter usage; itertools usage; list comprehension; list conversion; standard library helper; import reorganization; helper function extraction