def encode_cyclic(s: str):
    groups = [s[i:i+3] for i in range(0, len(s), 3)]
    transformed = [(g[1:] + g[0]) if len(g) == 3 else g for g in groups]
    return "".join(transformed)

# Classification response:
# list comprehension; slicing; conditional expression; join/split usage; loop rewrite; temporary variable; accumulator list; boundary case handling; behavior change