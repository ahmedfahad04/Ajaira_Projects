def smallest_change(arr):
    def helper(l, r):
        if l >= r:
            return 0
        return (0 if arr[l] == arr[r] else 1) + helper(l + 1, r - 1)
    return helper(0, len(arr) - 1)

# Classification response:
# recursion with base case; helper function extraction; loop rewrite; conditional expression; guard clause; variable renaming