def is_happy(s):
    if len(s) < 3:
        return False
    n = len(s)
    for i in range(n - 2):
        a, b, c = s[i], s[i + 1], s[i + 2]
        if a == b or b == c or a == c:
            return False
    return True

# Classification response:
# helper function extraction; temporary variable; tuple unpacking