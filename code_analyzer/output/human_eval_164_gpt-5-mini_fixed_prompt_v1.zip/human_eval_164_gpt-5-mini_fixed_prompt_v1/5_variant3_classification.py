from itertools import chain

def intersperse(numbers: list[int], delimeter: int) -> list[int]:
    if not numbers:
        return []
    pairs = ((n, delimeter) for n in numbers[:-1])
    return list(chain.from_iterable(pairs)) + [numbers[-1]]

# Classification response:
# loop rewrite; generator expression; itertools usage; list conversion; import reorganization; temporary variable; copy before mutation