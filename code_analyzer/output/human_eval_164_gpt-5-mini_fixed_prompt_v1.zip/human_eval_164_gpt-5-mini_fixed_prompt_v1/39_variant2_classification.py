import random

def prime_fib(n: int):
    if n <= 0:
        raise ValueError("n must be positive")

    def is_probable_prime(a, d, s, n):
        x = pow(a, d, n)
        if x == 1 or x == n-1:
            return True
        for _ in range(s-1):
            x = (x * x) % n
            if x == n-1:
                return True
        return False

    def miller_rabin(n):
        if n < 2:
            return False
        small_primes = [2,3,5,7,11,13,17,19,23,29]
        for p in small_primes:
            if n % p == 0:
                return n == p
        d = n - 1
        s = 0
        while d % 2 == 0:
            d //= 2
            s += 1
        # use several random bases for probabilistic check
        for a in [2, 325, 9375, 28178, 450775, 9780504, 1795265022]:
            if a % n == 0:
                continue
            if not is_probable_prime(a, d, s, n):
                return False
        return True

    # fast doubling for Fibonacci
    def fib_pair(k):
        if k == 0:
            return (0, 1)
        a, b = fib_pair(k >> 1)
        c = a * (b * 2 - a)
        d = a * a + b * b
        if k & 1:
            return (d, c + d)
        else:
            return (c, d)

    def is_prime_index(k):
        if k < 2:
            return False
        if k % 2 == 0:
            return k == 2
        i = 3
        while i * i <= k:
            if k % i == 0:
                return False
            i += 2
        return True

    found = 0
    k = 2
    while True:
        # Only compute F_k for prime indices k (exception F_4=3 is prime but 4 composite - handle separately)
        if k == 4:
            f = 3
            if miller_rabin(f):
                found += 1
                if found == n:
                    return f
        if is_prime_index(k):
            f = fib_pair(k)[0]
            if miller_rabin(f):
                found += 1
                if found == n:
                    return f
        k += 1

# Classification response:
# function renaming;helper function extraction;loop rewrite;index-based loop;accumulator list;tuple unpacking;recursion with base case;divide and conquer;probabilistic primality;builtin function;import reorganization;guard clause;input validation;boundary case handling;state variable;behavior change