from typing import List
from itertools import accumulate

def separate_paren_groups(paren_string: str) -> List[str]:
    s = ''.join(paren_string.split())
    parens = [c for c in s if c in '()']
    if not parens:
        return []
    balances = list(accumulate(1 if c == '(' else -1 for c in parens))
    res: List[str] = []
    last = -1
    for i, b in enumerate(balances):
        if b == 0:
            res.append(''.join(parens[last+1:i+1]))
            last = i
    return res

# Classification response:
# function renaming;variable renaming;import reorganization;itertools usage;list comprehension;generator expression;enumerate loop;early return;list conversion;slicing;temporary variable;prefix/suffix computation;join/split usage;empty input handling;string formatting change