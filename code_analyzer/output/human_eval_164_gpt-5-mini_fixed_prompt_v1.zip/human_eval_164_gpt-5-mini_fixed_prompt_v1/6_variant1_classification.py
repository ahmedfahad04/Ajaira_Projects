from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    groups = paren_string.split()
    results: List[int] = []
    for grp in groups:
        max_depth = 0
        cur = 0
        for ch in grp:
            if ch == '(':
                cur += 1
                if cur > max_depth:
                    max_depth = cur
            elif ch == ')':
                cur -= 1
        results.append(max_depth)
    return results

# Classification response:
# function renaming; variable renaming; parameter renaming; helper function inlining; accumulator list; loop rewrite; split condition; join/split usage; import reorganization; standard library helper; empty input handling