def same_chars(s0: str, s1: str):
    return set(s0) == set(s1)

# Classification response:
# helper function extraction; type annotations added