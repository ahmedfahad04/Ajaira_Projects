def correct_bracketing(brackets: str):
    count = 0
    for ch in brackets:
        if ch == '<':
            count += 1
        else:
            count -= 1
        if count < 0:
            return False
    return count == 0

# Classification response:
# variable renaming; helper function extraction; literal rewrite