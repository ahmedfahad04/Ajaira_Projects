def median(l: list):
    import heapq
    if not l:
        raise ValueError("median of empty list")
    n = len(l)
    mid = n // 2
    # get smallest mid+1 elements
    k = mid + 1
    smallest = heapq.nsmallest(k, l)
    if n % 2 == 1:
        return smallest[-1]
    else:
        return (smallest[-1] + smallest[-2]) / 2.0

# Classification response:
# heap-based; standard library helper; guard clause; empty input handling; temporary variable; import reorganization; helper function extraction