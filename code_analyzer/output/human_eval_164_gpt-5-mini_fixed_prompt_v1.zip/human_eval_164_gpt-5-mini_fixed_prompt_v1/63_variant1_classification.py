def fibfib(n: int):
    if n <= 1:
        return 0
    if n == 2:
        return 1
    a, b, c = 1, 0, 0  # f2, f1, f0
    # we want to compute up to n
    for i in range(3, n + 1):
        a, b, c = a + b + c, a, b
    return a

# Classification response:
# loop rewrite; for loop; combined condition; tuple unpacking; state variable; dynamic programming