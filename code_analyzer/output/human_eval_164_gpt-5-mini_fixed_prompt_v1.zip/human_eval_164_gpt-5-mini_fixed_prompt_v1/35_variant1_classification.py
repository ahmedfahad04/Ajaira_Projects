def max_element(l: list):
    if not l:
        raise ValueError("max_element() arg is an empty sequence")
    return max(l)

# Classification response:
# helper function extraction; builtin function; empty input handling