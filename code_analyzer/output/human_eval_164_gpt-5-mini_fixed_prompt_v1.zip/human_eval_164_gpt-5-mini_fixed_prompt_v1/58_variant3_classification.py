def common(l1: list, l2: list):
    a = sorted(set(l1))
    b = sorted(set(l2))
    i = j = 0
    res = []
    while i < len(a) and j < len(b):
        if a[i] < b[j]:
            i += 1
        elif a[i] > b[j]:
            j += 1
        else:
            res.append(a[i])
            i += 1
            j += 1
    return res

# Classification response:
# variable renaming; helper function extraction; set conversion; accumulator list; loop rewrite; while loop; index-based loop; two pointer; sorting-based approach