def median(l: list):
    if not l:
        raise ValueError("median of empty list")
    s = sorted(l)
    n = len(s)
    mid = n // 2
    if n % 2 == 1:
        return s[mid]
    else:
        return (s[mid - 1] + s[mid]) / 2.0

# Classification response:
# helper function extraction;guard clause;empty input handling;exception handling;variable renaming;temporary variable;sorting-based approach