from typing import List, Tuple
import math

def sum_product(numbers: List[int]) -> Tuple[int, int]:
    # math.prod handles empty iterable by returning 1
    return sum(numbers), math.prod(numbers)

# Classification response:
# loop rewrite; helper function extraction; builtin function; standard library helper; in-place mutation; empty input handling; type annotations