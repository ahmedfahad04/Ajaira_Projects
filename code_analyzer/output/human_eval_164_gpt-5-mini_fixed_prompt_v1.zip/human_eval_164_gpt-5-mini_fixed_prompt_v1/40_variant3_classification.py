def triples_sum_to_zero(l: list):
    n = len(l)
    if n < 3:
        return False
    for i in range(n - 2):
        target = -l[i]
        seen = set()
        for j in range(i + 1, n):
            need = target - l[j]
            if need in seen:
                return True
            seen.add(l[j])
    return False

# Classification response:
# hash-based pair search; loop rewrite; accumulator set; membership test; guard clause; boundary case handling; temporary variable