def sum_to_n(n: int):
    if n <= 0:
        return 0
    return n + sum_to_n(n - 1)

# Classification response:
# recursion with base case; guard clause; builtin function; boundary case handling