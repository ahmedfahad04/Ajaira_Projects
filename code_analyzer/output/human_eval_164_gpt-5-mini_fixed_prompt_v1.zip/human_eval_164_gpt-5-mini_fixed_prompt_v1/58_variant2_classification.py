def common(l1: list, l2: list):
    s2 = set(l2)
    return sorted({x for x in l1 if x in s2})

# Classification response:
# loop rewrite; set conversion; set comprehension; membership test; temporary variable; accumulator set