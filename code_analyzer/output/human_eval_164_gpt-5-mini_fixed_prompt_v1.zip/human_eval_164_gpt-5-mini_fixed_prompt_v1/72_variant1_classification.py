def will_it_fly(q,w):
    return q == q[::-1] and sum(q) <= w

# Classification response:
# function renaming; loop rewrite; two pointer; slicing; combined condition; flattened conditional; branch reordering