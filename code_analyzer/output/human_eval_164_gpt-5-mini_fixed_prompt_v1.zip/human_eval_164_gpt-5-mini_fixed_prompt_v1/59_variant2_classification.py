def largest_prime_factor(n: int):
    import math
    if n <= 1:
        return n
    largest = 1
    while n % 2 == 0:
        largest = 2
        n //= 2
    i = 3
    while i <= math.isqrt(n):
        if n % i == 0:
            largest = i
            while n % i == 0:
                n //= i
        i += 2
    if n > 1:
        largest = n
    return int(largest)

# Classification response:
# function renaming; helper function inlining; loop rewrite; while loop; early return; in-place mutation; temporary variable; standard library helper; prime factorization; mathematical formula; boundary case handling; type conversion