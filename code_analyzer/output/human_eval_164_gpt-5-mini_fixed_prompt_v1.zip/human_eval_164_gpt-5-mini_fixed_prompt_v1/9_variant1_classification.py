from typing import List

def rolling_max(numbers: List[int]) -> List[int]:
    if not numbers:
        return []
    result: List[int] = []
    current_max = None
    for x in numbers:
        if current_max is None or x > current_max:
            current_max = x
        result.append(current_max)
    return result

# Classification response:
# variable renaming;flattened conditional;combined condition;guard clause;early return;empty input handling;import reorganization;builtin function