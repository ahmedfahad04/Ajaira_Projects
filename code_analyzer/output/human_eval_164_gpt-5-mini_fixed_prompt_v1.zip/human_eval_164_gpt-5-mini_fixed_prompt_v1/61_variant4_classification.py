def correct_bracketing(brackets: str):
    s = brackets
    prev = None
    while s and s != prev:
        prev = s
        s = s.replace("()", "")
    return s == ""

# Classification response:
# loop rewrite;while loop;accumulator string;temporary variable;brute force;variable renaming