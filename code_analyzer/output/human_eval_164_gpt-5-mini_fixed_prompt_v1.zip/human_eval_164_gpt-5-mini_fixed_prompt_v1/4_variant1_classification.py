from typing import List

def mean_absolute_deviation(numbers: List[float]) -> float:
    if not numbers:
        return 0.0
    n = len(numbers)
    mean = sum(numbers) / n
    return sum(abs(x - mean) for x in numbers) / n

# Classification response:
# helper function extraction; guard clause; empty input handling; temporary variable; standard library helper; type annotations