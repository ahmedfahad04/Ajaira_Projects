def strange_sort_list(lst):
    arr = list(lst)
    def helper(a):
        if not a:
            return []
        mn = min(a)
        a.remove(mn)
        out = [mn]
        if not a:
            return out
        mx = max(a)
        a.remove(mx)
        out.append(mx)
        return out + helper(a)
    return helper(arr)

# Classification response:
# variable renaming;helper function extraction;recursion;loop rewrite;guard clause;copy before mutation;empty input handling