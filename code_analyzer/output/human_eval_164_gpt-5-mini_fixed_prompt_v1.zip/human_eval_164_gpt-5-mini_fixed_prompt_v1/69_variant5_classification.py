def search(lst):
    import heapq
    counts = {}
    for x in lst:
        counts[x] = counts.get(x, 0) + 1
    # max-heap by value
    heap = []
    for v in counts:
        if v > 0:
            heapq.heappush(heap, -v)
    while heap:
        v = -heapq.heappop(heap)
        if counts.get(v, 0) >= v:
            return v
    return -1

# Classification response:
# accumulator dict;dictionary lookup;heap-based;standard library helper;early return;import reorganization;loop rewrite