def triples_sum_to_zero(l: list):
    from itertools import combinations
    if len(l) < 3:
        return False
    for a, b, c in combinations(l, 3):
        if a + b + c == 0:
            return True
    return False

# Classification response:
# helper function extraction; guard clause; loop rewrite; itertools usage; tuple unpacking; import reorganization