def add(x: int, y: int):
    return x + y

# Classification response:
# helper function extraction; type check