def iscube(a):
    if a == 0:
        return True
    n = abs(a)
    x = int(n ** (1.0/3.0)) + 1
    for _ in range(100):
        if x == 0:
            break
        y = (2 * x + n // (x * x)) // 3
        if y == x:
            break
        x = y
    while (x + 1) ** 3 <= n:
        x += 1
    while x ** 3 > n:
        x -= 1
    return x ** 3 == n

# Classification response:
# helper function extraction;iterative root finding;early return;loop rewrite;temporary variable;boundary case handling