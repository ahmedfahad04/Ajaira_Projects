def modp(n: int, p: int):
    if p == 0:
        raise ValueError("Modulo p must be non-zero")
    n0 = n
    n = int(n0)
    res = 1 % p
    base = 2 % p
    while n > 0:
        if n & 1:
            res = (res * base) % p
        base = (base * base) % p
        n >>= 1
    return res

# Classification response:
# variable renaming; loop rewrite; while loop; guard clause; input validation; type conversion; temporary variable; binary exponentiation