def iscube(a):
    import math
    if a == 0:
        return True
    fr = math.copysign((abs(a)) ** (1.0/3.0), a)
    r = int(round(fr))
    for cand in (r - 1, r, r + 1):
        if cand ** 3 == a:
            return True
    return False

# Classification response:
# helper function extraction; import reorganization; standard library helper; guard clause; for loop; temporary variable; boundary case handling; behavior change