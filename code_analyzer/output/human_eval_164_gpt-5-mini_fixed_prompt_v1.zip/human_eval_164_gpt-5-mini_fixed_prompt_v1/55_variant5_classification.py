def fib(n: int):
    def _fib_pair(k):
        if k == 0:
            return (0, 1)
        a, b = _fib_pair(k >> 1)
        c = a * (2 * b - a)
        d = a * a + b * b
        if k & 1:
            return (d, c + d)
        else:
            return (c, d)
    if n < 0:
        raise ValueError("n must be non-negative")
    return _fib_pair(n)[0]

# Classification response:
# helper function extraction;divide and conquer;mathematical formula;recursion with base case;tuple unpacking;input validation;exception handling