from collections import deque

def fib4(n: int):
    if n < 0:
        raise ValueError("n must be non-negative")
    base = {0: 0, 1: 0, 2: 2, 3: 0}
    if n in base:
        return base[n]
    window = deque([0, 0, 2, 0], maxlen=4)
    for _ in range(4, n + 1):
        s = sum(window)
        window.append(s)
    return window[-1]

# Classification response:
# sliding window; standard library helper; import reorganization; dictionary lookup; guard clause; input validation; membership test; builtin function; temporary variable; in-place mutation