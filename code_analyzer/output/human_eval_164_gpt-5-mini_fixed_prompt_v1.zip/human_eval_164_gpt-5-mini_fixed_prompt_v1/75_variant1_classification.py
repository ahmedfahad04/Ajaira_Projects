def is_multiply_prime(a):
    if not isinstance(a, int) or a < 2:
        return False
    # simple primality for small numbers
    def is_prime(n):
        if n <= 1:
            return False
        if n <= 3:
            return True
        if n % 2 == 0:
            return False
        i = 3
        while i * i <= n:
            if n % i == 0:
                return False
            i += 2
        return True
    # generate primes up to a
    primes = [p for p in range(2, a + 1) if is_prime(p)]
    # brute force triple nested loops
    for i in range(len(primes)):
        p = primes[i]
        if p > a:
            break
        for j in range(i, len(primes)):
            q = primes[j]
            if p * q > a:
                break
            for k in range(j, len(primes)):
                r = primes[k]
                prod = p * q * r
                if prod == a:
                    return True
                if prod > a:
                    break
    return False

# Classification response:
# function renaming;guard clause;input validation;type check;index-based loop;loop rewrite;list comprehension;temporary variable;brute force