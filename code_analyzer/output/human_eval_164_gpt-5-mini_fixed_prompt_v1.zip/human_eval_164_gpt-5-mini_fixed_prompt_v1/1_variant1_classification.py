from typing import List

def separate_paren_groups(paren_string: str) -> List[str]:
    res: List[str] = []
    buf: List[str] = []
    balance = 0
    for ch in paren_string:
        if ch == ' ':
            continue
        if ch == '(':
            buf.append(ch)
            balance += 1
        elif ch == ')':
            buf.append(ch)
            balance -= 1
        else:
            continue
        if balance == 0 and buf:
            res.append(''.join(buf))
            buf = []
    return res

# Classification response:
# function renaming; variable renaming; accumulator list; guard clause; flattened conditional; copy before mutation; import reorganization; standard library helper; behavior change