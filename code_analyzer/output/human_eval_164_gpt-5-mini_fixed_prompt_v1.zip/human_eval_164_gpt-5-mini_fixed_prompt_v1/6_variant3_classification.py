from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    def parse_group(s: str) -> int:
        n = len(s)
        i = 0
        max_overall = 0
        def parse_paren(j: int):
            # j is at '('
            j += 1
            max_child = 0
            while j < n and s[j] != ')':
                if s[j] == '(':
                    child_depth, j = parse_paren(j)
                    if child_depth > max_child:
                        max_child = child_depth
                else:
                    j += 1
            # depth of this group is 1 + max child depth
            return 1 + max_child, j + 1
        while i < n:
            if s[i] == '(':
                depth, ni = parse_paren(i)
                if depth > max_overall:
                    max_overall = depth
                i = ni
            else:
                i += 1
        return max_overall

    return [parse_group(g) for g in paren_string.split()]

# Classification response:
# function renaming; helper function extraction; recursion; index-based loop; tuple unpacking; list comprehension; join/split usage; import reorganization; temporary variable; empty input handling