def remove_vowels(text):
    return ''.join(filter(lambda c: c.lower() not in 'aeiou', text))

# Classification response:
# helper function extraction;map/filter usage;lambda expression;literal rewrite