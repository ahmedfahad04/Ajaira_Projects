def same_chars(s0: str, s1: str):
    # build presence maps and compare keys
    m0 = {}
    for ch in s0:
        if ch not in m0:
            m0[ch] = True
    m1 = {}
    for ch in s1:
        if ch not in m1:
            m1[ch] = True
    if len(m0) != len(m1):
        return False
    for k in m0:
        if k not in m1:
            return False
    return True

# Classification response:
# helper function extraction;for loop;accumulator dict;in-place mutation;dictionary lookup;guard clause;membership test