def unique(l: list):
    keys = dict.fromkeys(l)
    return sorted(keys.keys())

# Classification response:
# helper function extraction; temporary variable; standard library helper; function renaming