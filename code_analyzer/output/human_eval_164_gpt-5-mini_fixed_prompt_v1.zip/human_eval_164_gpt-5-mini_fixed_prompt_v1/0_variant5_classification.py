from typing import List

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    if threshold <= 0:
        return False
    n = len(numbers)
    if n < 2:
        return False
    s = sorted(numbers)
    left = 0
    right = 1
    while left < n - 1 and right < n:
        if left == right:
            right += 1
            continue
        diff = s[right] - s[left]
        if diff < threshold:
            return True
        # if current difference >= threshold, move left up to try smaller window
        if diff >= threshold:
            left += 1
        else:
            right += 1
    return False

# Classification response:
# guard clause; while loop; loop rewrite; index-based loop; sorting-based approach; two pointer; import reorganization; input validation; empty input handling