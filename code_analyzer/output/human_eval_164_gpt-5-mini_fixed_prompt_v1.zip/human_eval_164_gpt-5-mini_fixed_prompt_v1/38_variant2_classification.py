def encode_cyclic(s: str):
    n = len(s)
    res_chars = []
    i = 0
    while i < n:
        if i + 3 <= n:
            a, b, c = s[i], s[i+1], s[i+2]
            res_chars.extend([b, c, a])
            i += 3
        else:
            res_chars.append(s[i])
            i += 1
    return "".join(res_chars)

# Classification response:
# while loop; index-based loop; accumulator list; in-place mutation; tuple unpacking; temporary variable; join/split usage; boundary case handling