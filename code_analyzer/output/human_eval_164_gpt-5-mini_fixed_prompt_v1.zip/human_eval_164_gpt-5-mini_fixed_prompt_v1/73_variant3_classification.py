def smallest_change(arr):
    half = len(arr) // 2
    return sum(1 for a, b in zip(arr[:half], reversed(arr)) if a != b)

# Classification response:
# function renaming; loop rewrite; generator expression; zip usage; slicing; tuple unpacking; temporary variable; builtin function