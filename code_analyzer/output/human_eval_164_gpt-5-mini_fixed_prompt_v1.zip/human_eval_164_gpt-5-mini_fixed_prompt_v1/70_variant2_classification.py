from collections import deque

def strange_sort_list(lst):
    s = sorted(lst)
    dq = deque(s)
    res = []
    take_left = True
    while dq:
        if take_left:
            res.append(dq.popleft())
        else:
            res.append(dq.pop())
        take_left = not take_left
    return res

# Classification response:
# variable renaming; function renaming; import reorganization; accumulator list; temporary variable; copy before mutation; standard library helper; builtin function; while loop; sorting-based approach; queue-based; conditional expression