def modp(n: int, p: int):
    if p == 0:
        raise ValueError("Modulo p must be non-zero")
    n = int(n)
    if n >= 0:
        return pow(2, n, p)
    # handle negative exponent by using modular inverse of 2 (requires inverse to exist)
    # pow(2, -1, p) returns modular inverse in Python >=3.8
    try:
        inv2 = pow(2, -1, p)
    except ValueError:
        # inverse doesn't exist
        raise ValueError("Modular inverse does not exist for base 2 and modulus p")
    return pow(inv2, -n, p)

# Classification response:
# loop rewrite; helper function extraction; guard clause; early return; split condition; try-except wrapper; builtin function; temporary variable; input validation; type conversion; boundary case handling; behavior change; mathematical formula