from functools import reduce

def total_match(lst1, lst2):
    s1 = reduce(lambda acc, item: acc + len(item), lst1, 0)
    s2 = reduce(lambda acc, item: acc + len(item), lst2, 0)
    return lst1 if s1 <= s2 else lst2

# Classification response:
# helper function extraction; loop rewrite; conditional expression; functools reduce; lambda expression; import reorganization; temporary variable