from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    groups = paren_string.split()
    res: List[int] = []
    for g in groups:
        s = g
        depth = 0
        # remove all pairs "()" in rounds; number of rounds until empty equals max nesting
        while s:
            if '()' not in s:
                # no more direct pairs, break to avoid infinite loop
                break
            s = s.replace('()', '')
            depth += 1
        res.append(depth)
    return res

# Classification response:
# function renaming; parameter renaming; variable renaming; standard library helper; loop rewrite; while loop; list comprehension; accumulator list; temporary variable; join/split usage; guard clause; brute force; empty input handling