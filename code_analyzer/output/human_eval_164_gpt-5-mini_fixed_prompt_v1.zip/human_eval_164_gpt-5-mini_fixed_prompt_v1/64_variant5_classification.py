from collections import Counter
def vowels_count(s):
    if not s:
        return 0
    s_lower = s.lower()
    cnt = Counter(s_lower)
    total = sum(cnt[v] for v in "aeiou")
    if s_lower[-1] == 'y':
        total += 1
    return total

# Classification response:
# helper function extraction;guard clause;empty input handling;standard library helper;import reorganization;accumulator dict;dictionary lookup;frequency counting;string formatting change;temporary variable