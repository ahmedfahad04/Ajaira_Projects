def digitSum(s):
    return sum(map(ord, filter(lambda c: 65 <= ord(c) <= 90, s)))

# Classification response:
# function renaming; map/filter usage; lambda expression; literal rewrite; empty input handling; behavior change