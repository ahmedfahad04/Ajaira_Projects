def derivative(xs: list):
    res = []
    for i in range(1, len(xs)):
        res.append(xs[i] * i)
    return res

# Classification response:
# helper function extraction; loop rewrite; for loop; index-based loop; accumulator list; in-place mutation; list comprehension; slicing