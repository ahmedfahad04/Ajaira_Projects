def encode_cyclic(s: str):
    import re
    parts = re.findall('.{1,3}', s)
    return "".join((p[1:] + p[0]) if len(p) == 3 else p for p in parts)

# Classification response:
# helper function inlining;import reorganization;regex usage;generator expression;conditional expression;slicing;temporary variable;join/split usage;boundary case handling