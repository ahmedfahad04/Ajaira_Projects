def is_happy(s):
    if len(s) < 3:
        return False
    return all(len(set(s[i:i+3])) == 3 for i in range(len(s) - 2))

# Classification response:
# helper function extraction; loop rewrite; generator expression; any/all usage; set conversion; slicing; combined condition; early return