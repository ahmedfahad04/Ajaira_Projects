import math
def truncate_number(number: float) -> float:
    """Subtract floor to obtain the decimal part."""
    return number - math.floor(number)

# Classification response:
# function renaming; helper function extraction; standard library helper; import reorganization; mathematical formula