def pairs_sum_to_zero(l):
    n = len(l)
    for i in range(n):
        for j in range(i+1, n):
            if l[i] + l[j] == 0:
                return True
    return False

# Classification response:
# helper function extraction;index-based loop;loop rewrite;temporary variable