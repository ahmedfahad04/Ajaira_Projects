def fibfib(n: int):
    if n <= 1:
        return 0
    if n == 2:
        return 1
    # Precompute powers of companion matrix and multiply by bits (another style)
    M = ((1,1,1),
         (1,0,0),
         (0,1,0))
    def mat_mul(A, B):
        return (
            (A[0][0]*B[0][0] + A[0][1]*B[1][0] + A[0][2]*B[2][0],
             A[0][0]*B[0][1] + A[0][1]*B[1][1] + A[0][2]*B[2][1],
             A[0][0]*B[0][2] + A[0][1]*B[1][2] + A[0][2]*B[2][2]),
            (A[1][0]*B[0][0] + A[1][1]*B[1][0] + A[1][2]*B[2][0],
             A[1][0]*B[0][1] + A[1][1]*B[1][1] + A[1][2]*B[2][1],
             A[1][0]*B[0][2] + A[1][1]*B[1][2] + A[1][2]*B[2][2]),
            (A[2][0]*B[0][0] + A[2][1]*B[1][0] + A[2][2]*B[2][0],
             A[2][0]*B[0][1] + A[2][1]*B[1][1] + A[2][2]*B[2][1],
             A[2][0]*B[0][2] + A[2][1]*B[1][2] + A[2][2]*B[2][2])
        )
    # build list of powers M^(2^i)
    powers = []
    cur = M
    exp = n - 2
    while exp > 0:
        powers.append(cur)
        cur = mat_mul(cur, cur)
        exp >>= 1
    # multiply selected powers according to bits of (n-2)
    # start from identity
    R = ((1,0,0),(0,1,0),(0,0,1))
    e = n - 2
    i = 0
    while e > 0:
        if e & 1:
            R = mat_mul(R, powers[i])
        e >>= 1
        i += 1
    # Multiply R by base vector [1,0,0] -> first column of R
    return R[0][0]

# Classification response:
# helper function extraction; loop rewrite; while loop; combined condition; accumulator list; matrix exponentiation