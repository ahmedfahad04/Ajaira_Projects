def add(x: int, y: int):
    # Bitwise addition using 32-bit mask to handle negatives
    mask = 0xFFFFFFFF
    while y & mask:
        carry = (x & y) & mask
        x = (x ^ y) & mask
        y = (carry << 1) & mask
    # convert from 32-bit two's complement if negative
    if x & (1 << 31):
        return ~(x ^ mask)
    return x

# Classification response:
# helper function extraction; while loop; early return; temporary variable; type conversion; bitwise addition algorithm