def unique(l: list):
    if not l:
        return []
    s = sorted(l)
    res = [s[0]]
    for x in s[1:]:
        if x != res[-1]:
            res.append(x)
    return res

# Classification response:
# helper function extraction; guard clause; empty input handling; sorting-based approach; loop rewrite; for loop; accumulator list; in-place mutation; temporary variable