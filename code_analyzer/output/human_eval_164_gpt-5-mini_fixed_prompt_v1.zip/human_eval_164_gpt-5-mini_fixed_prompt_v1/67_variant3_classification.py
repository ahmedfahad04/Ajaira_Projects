def fruit_distribution(s,n):
    nums = []
    i = 0
    L = len(s)
    while i < L:
        if s[i] == '-' and i+1 < L and s[i+1].isdigit():
            sign = '-'
            i += 1
            start = i
            while i < L and s[i].isdigit():
                i += 1
            nums.append(int(sign + s[start:i]))
        elif s[i].isdigit():
            start = i
            while i < L and s[i].isdigit():
                i += 1
            nums.append(int(s[start:i]))
        else:
            i += 1
    a = nums[0] if len(nums) > 0 else 0
    b = nums[1] if len(nums) > 1 else 0
    return n - a - b

# Classification response:
# function renaming; variable renaming; loop rewrite; while loop; index-based loop; accumulator list; temporary variable; combined condition; default value handling; boundary case handling; behavior change