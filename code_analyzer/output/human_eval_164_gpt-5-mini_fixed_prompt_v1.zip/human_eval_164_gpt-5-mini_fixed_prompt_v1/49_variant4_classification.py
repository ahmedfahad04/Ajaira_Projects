def modp(n: int, p: int):
    if p == 0:
        raise ValueError("Modulo p must be non-zero")
    n = int(n)
    if n == 0:
        return 1 % p
    bits = bin(n)[2:]
    res = 1 % p
    for b in bits:
        # square for each bit
        res = (res * res) % p
        if b == '1':
            res = (res * 2) % p
    return res

# Classification response:
# binary exponentiation; loop rewrite; helper function extraction; guard clause; exception handling; early return; slicing; temporary variable; builtin function; input validation; type conversion; boundary case handling