def max_element(l: list):
    if not l:
        raise ValueError("max_element() arg is an empty sequence")
    it = iter(l)
    maxv = next(it)
    for x in it:
        if x > maxv:
            maxv = x
    return maxv

# Classification response:
# helper function extraction;variable renaming;loop rewrite;guard clause;empty input handling;exception handling;builtin function;state variable