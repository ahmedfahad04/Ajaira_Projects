def truncate_number(number: float) -> float:
    """Simple subtraction using int() for positive numbers."""
    # For positive floats int(number) gives the integer part
    return number - int(number)

# Classification response:
# helper function extraction; builtin function; mathematical formula; behavior change