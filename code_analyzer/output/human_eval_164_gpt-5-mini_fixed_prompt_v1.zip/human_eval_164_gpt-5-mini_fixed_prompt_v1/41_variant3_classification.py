def car_race_collision(n: int):
    n = int(n)
    if n <= 0:
        return 0
    return car_race_collision(n - 1) + (2 * n - 1)

# Classification response:
# function renaming; recursion with base case; guard clause; input validation; type conversion; behavior change