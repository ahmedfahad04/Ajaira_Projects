def digitSum(s):
    bs = s.encode('ascii', 'ignore')
    return sum(b for b in bs if 65 <= b <= 90)

# Classification response:
# function renaming;temporary variable;generator expression;literal rewrite;combined condition;type conversion;error suppression;standard library helper;empty input handling;behavior change