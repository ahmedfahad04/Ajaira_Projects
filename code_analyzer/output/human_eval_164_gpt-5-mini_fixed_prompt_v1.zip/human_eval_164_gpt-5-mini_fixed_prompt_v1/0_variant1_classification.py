from typing import List

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    if threshold <= 0:
        return False
    n = len(numbers)
    if n < 2:
        return False
    s = sorted(numbers)
    for i in range(1, n):
        if s[i] - s[i - 1] < threshold:
            return True
    return False

# Classification response:
# variable renaming; helper function extraction; early return; guard clause; loop rewrite; index-based loop; flattened conditional; sorting-based approach; builtin function; temporary variable; input validation; empty input handling; boundary case handling