def numerical_letter_grade(grades):
    # Functional style using generator and next()
    mapping = [
        (3.7, 'A'),
        (3.3, 'A-'),
        (3.0, 'B+'),
        (2.7, 'B'),
        (2.3, 'B-'),
        (2.0, 'C+'),
        (1.7, 'C'),
        (1.3, 'C-'),
        (1.0, 'D+'),
        (0.7, 'D'),
        (0.0, 'D-'),
    ]
    def to_letter(g):
        if g == 4.0:
            return 'A+'
        if g == 0.0:
            return 'E'
        return next((lbl for th, lbl in mapping if g > th), 'E')
    return list(map(to_letter, grades))

# Classification response:
# helper function extraction;generator expression;map/filter usage;tuple unpacking;guard clause;flattened conditional;list conversion;builtin function;function renaming