def starts_one_ends(n):
    if n <= 0:
        return 0
    if n == 1:
        return 1
    return 18 * 10 ** (n - 2)

# Classification response:
# helper function extraction; guard clause; input validation