from typing import List, Tuple

def sum_product(numbers: List[int]) -> Tuple[int, int]:
    if not numbers:
        return 0, 1
    def helper(i: int) -> Tuple[int, int]:
        if i == len(numbers) - 1:
            return numbers[i], numbers[i]
        s, p = helper(i + 1)
        return numbers[i] + s, numbers[i] * p
    return helper(0)

# Classification response:
# guard clause;helper function extraction;loop rewrite;recursion with base case;tuple unpacking;import reorganization;standard library helper;empty input handling