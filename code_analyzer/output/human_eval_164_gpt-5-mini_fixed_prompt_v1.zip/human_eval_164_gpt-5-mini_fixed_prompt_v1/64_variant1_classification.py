def vowels_count(s):
    s = s or ""
    s_lower = s.lower()
    vowels = set("aeiou")
    count = 0
    n = len(s_lower)
    for i, ch in enumerate(s_lower):
        if ch in vowels:
            count += 1
        elif ch == 'y' and i == n - 1:
            count += 1
    return count

# Classification response:
# loop rewrite; enumerate loop; set conversion; literal rewrite; membership test; state variable; empty input handling; boundary case handling