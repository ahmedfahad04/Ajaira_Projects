def is_simple_power(x, n):
    # Binary-search on exponent for n >= 2 or n <= -2, fallback otherwise
    if x == 1:
        return True
    if n == 1:
        return x == 1
    if n == 0:
        return x == 0
    if n == -1:
        return x in (1, -1)
    if x == 0:
        return n == 0
    if n >= 2 or n <= -2:
        # find an upper bound by doubling exponent
        k = 1
        val = n
        while abs(val) < abs(x):
            k *= 2
            val = pow(n, k)
            if val == 0:
                break
        lo, hi = 0, k
        while lo <= hi:
            mid = (lo + hi) // 2
            p = pow(n, mid)
            if p == x:
                return True
            if abs(p) < abs(x):
                lo = mid + 1
            else:
                hi = mid - 1
        return False
    # fallback simple division for small |n|
    try:
        while x % n == 0:
            x //= n
    except Exception:
        return False
    return x == 1

# Classification response:
# function renaming;guard clause;early return;loop rewrite;while loop;binary search;exponential search;try-except wrapper;boundary case handling;builtin function;membership test;temporary variable