def is_happy(s):
    n = len(s)
    if n < 3:
        return False
    def check(i):
        if i > n - 3:
            return True
        if len({s[i], s[i+1], s[i+2]}) != 3:
            return False
        return check(i+1)
    return check(0)

# Classification response:
# recursion with base case; helper function extraction; loop rewrite; set conversion; temporary variable; guard clause