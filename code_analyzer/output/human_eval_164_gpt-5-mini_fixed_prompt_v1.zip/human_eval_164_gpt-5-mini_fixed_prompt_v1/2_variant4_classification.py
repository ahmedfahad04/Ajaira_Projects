from decimal import Decimal, getcontext
import math

def truncate_number(number: float) -> float:
    """Try to extract fractional part via string parsing; fall back to math.modf for scientific notation."""
    s = repr(number)
    if 'e' in s or 'E' in s:
        frac, _ = math.modf(number)
        return frac
    if '.' not in s:
        return 0.0
    whole, frac = s.split('.', 1)
    # strip any trailing zeros that came from repr
    if frac == '':
        return 0.0
    # Build fractional float safely
    try:
        return float('0.' + frac)
    except Exception:
        frac_part, _ = math.modf(number)
        return frac_part

# Classification response:
# helper function extraction; guard clause; combined condition; try-except wrapper; tuple unpacking; temporary variable; join/split usage; standard library helper; builtin function; boundary case handling; error suppression; import reorganization; type conversion