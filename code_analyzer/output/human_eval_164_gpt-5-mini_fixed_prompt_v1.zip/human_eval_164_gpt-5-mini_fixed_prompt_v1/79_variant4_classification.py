def decimal_to_binary(decimal):
    def rec(n):
        if n == 0:
            return ""
        return rec(n // 2) + str(n % 2)
    if decimal == 0:
        return "db0db"
    sign = ""
    n = decimal
    if n < 0:
        sign = "-"
        n = -n
    bits = rec(n)
    return "db" + sign + bits + "db"

# Classification response:
# recursion with base case; helper function extraction; temporary variable; boundary case handling; behavior change; builtin function