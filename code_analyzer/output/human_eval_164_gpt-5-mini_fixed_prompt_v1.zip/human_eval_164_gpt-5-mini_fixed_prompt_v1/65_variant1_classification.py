def circular_shift(x, shift):
    s = str(x)
    sign = ''
    if s.startswith('-'):
        sign = '-'
        s = s[1:]
    if not s:
        return sign + s
    n = len(s)
    if shift > n:
        return sign + s[::-1]
    if shift == 0 or n == 0:
        return sign + s
    if shift < 0:
        k = (-shift) % n
        # left shift by k
        return sign + s[k:] + s[:k]
    if shift == n:
        return sign + s
    k = shift
    return sign + (s[-k:] + s[:-k])

# Classification response:
# helper function extraction; guard clause; empty input handling; boundary case handling; behavior change; temporary variable