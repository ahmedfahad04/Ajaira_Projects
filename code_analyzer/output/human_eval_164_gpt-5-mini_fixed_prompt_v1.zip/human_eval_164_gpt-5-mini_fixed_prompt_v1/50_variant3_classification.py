def encode_shift(s: str):
    """
    returns encoded string by shifting every character by 5 in the alphabet.
    Preserves case for letters and leaves other characters unchanged.
    """
    out = []
    for ch in s:
        o = ord(ch)
        if 97 <= o <= 122:  # a-z
            out.append(chr((o - 97 + 5) % 26 + 97))
        elif 65 <= o <= 90:  # A-Z
            out.append(chr((o - 65 + 5) % 26 + 65))
        else:
            out.append(ch)
    return "".join(out)

# Classification response:
# helper function extraction;for loop;accumulator list;temporary variable;split condition;boundary case handling;literal rewrite