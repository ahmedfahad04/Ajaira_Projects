def sum_to_n(n: int):
    if n <= 0:
        return 0
    return sum(range(1, n + 1))

# Classification response:
# helper function extraction;guard clause;early return;input validation