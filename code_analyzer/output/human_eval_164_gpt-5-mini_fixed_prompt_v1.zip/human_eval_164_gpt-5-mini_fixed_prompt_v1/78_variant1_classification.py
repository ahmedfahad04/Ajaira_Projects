def hex_key(num):
    primes = {'2', '3', '5', '7', 'B', 'D'}
    count = 0
    for ch in num:
        if ch in primes:
            count += 1
    return count

# Classification response:
# helper function extraction; set conversion; loop rewrite; variable renaming; membership test