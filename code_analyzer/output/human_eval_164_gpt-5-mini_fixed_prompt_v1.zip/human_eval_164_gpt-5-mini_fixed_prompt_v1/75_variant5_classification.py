def is_multiply_prime(a):
    if not isinstance(a, int) or a < 2:
        return False
    # quick primality
    def is_prime(n):
        if n <= 1:
            return False
        if n <= 3:
            return True
        if n % 2 == 0:
            return False
        i = 3
        while i * i <= n:
            if n % i == 0:
                return False
            i += 2
        return True
    # try all pairs p*q that divide a, then check if remaining is prime
    for p in range(2, a + 1):
        if a % p != 0:
            continue
        if not is_prime(p):
            continue
        rem1 = a // p
        for q in range(2, rem1 + 1):
            if rem1 % q != 0:
                continue
            if not is_prime(q):
                continue
            r = rem1 // q
            if is_prime(r):
                return True
    return False

# Classification response:
# function renaming;helper function inlining;loop rewrite;divisor enumeration;temporary variable;guard clause;early return;input validation;type check;boundary case handling