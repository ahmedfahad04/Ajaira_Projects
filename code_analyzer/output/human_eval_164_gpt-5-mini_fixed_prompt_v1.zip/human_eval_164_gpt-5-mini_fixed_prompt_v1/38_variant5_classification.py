def encode_cyclic(s: str):
    if not s:
        return ""
    if len(s) < 3:
        return s
    head = s[:3]
    rotated = head[1:] + head[0]
    return rotated + encode_cyclic(s[3:])

# Classification response:
# recursion with base case; guard clause; slicing; prefix/suffix computation; empty input handling; boundary case handling; accumulator string; behavior change