def pluck(arr):
    if not arr:
        return []
    best_val = None
    best_idx = None
    for i, v in enumerate(arr):
        if v % 2 == 0:
            if best_val is None or v < best_val:
                best_val = v
                best_idx = i
    if best_val is None:
        return []
    return [best_val, best_idx]

# Classification response:
# function renaming; loop rewrite; enumerate loop; state variable; accumulator list; early return; tuple unpacking; greedy strategy; variable renaming; boundary case handling