def will_it_fly(q,w):
    n = len(q)
    total = 0
    for i in range(n // 2):
        if q[i] != q[-1 - i]:
            return False
        total += q[i] + q[-1 - i]
        if total > w:
            return False
    if n % 2 == 1:
        total += q[n // 2]
    return total <= w

# Classification response:
# function renaming; early return; combined condition; for loop; temporary variable; two pointer; prefix/suffix computation; boundary case handling