from typing import List

def separate_paren_groups(paren_string: str) -> List[str]:
    s = ''.join(paren_string.split())
    n = len(s)
    res: List[str] = []
    def parse_at(i: int):
        buf = ['(']
        i += 1
        while i < n:
            ch = s[i]
            if ch == '(':
                sub, i = parse_at(i)
                buf.append(sub)
                continue
            if ch == ')':
                buf.append(')')
                return ''.join(buf), i + 1
            i += 1
        return ''.join(buf), i
    i = 0
    while i < n:
        if s[i] == '(':
            group, i = parse_at(i)
            res.append(group)
        else:
            i += 1
    return res

# Classification response:
# function renaming;variable renaming;recursion with base case;helper function extraction;index-based loop;accumulator list;tuple unpacking;temporary variable;standard library helper;join/split usage;behavior change