def pluck(arr):
    best = min(((v, i) for i, v in enumerate(arr) if v % 2 == 0), default=None)
    if best is None:
        return []
    v, i = best
    return [v, i]

# Classification response:
# helper function extraction;generator expression;enumerate loop;builtin function;default value handling;temporary variable