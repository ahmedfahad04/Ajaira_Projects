def digitSum(s):
    total = 0
    for ch in s:
        o = ord(ch)
        if 65 <= o <= 90:
            total += o
    return total

# Classification response:
# function renaming; loop rewrite; for loop; generator expression; conditional expression; early return; temporary variable; state variable; literal rewrite