def below_threshold(l: list, t: int):
    return all(x < t for x in l)

# Classification response:
# helper function extraction; loop rewrite; flattened conditional; any/all usage; generator expression