def sort_third(l: list):
    indices = [i for i in range(len(l)) if i % 3 == 0]
    sorted_vals = sorted(l[i] for i in indices)
    out = l[:]  # copy
    for i, val in zip(indices, sorted_vals):
        out[i] = val
    return out

# Classification response:
# function renaming;for loop;zip usage;list comprehension;generator expression;slicing;copy before mutation;temporary variable;behavior change