def hex_key(num):
    primes = set("2357BD")
    return sum(ch in primes for ch in num)

# Classification response:
# set conversion; generator expression; helper function extraction; loop rewrite; temporary variable; membership test