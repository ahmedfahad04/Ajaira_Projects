def triangle_area(a, h):
    return a * h / 2.0

# Classification response:
# helper function extraction