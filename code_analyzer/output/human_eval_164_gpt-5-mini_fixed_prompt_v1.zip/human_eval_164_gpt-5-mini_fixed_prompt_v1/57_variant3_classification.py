def monotonic(l: list):
    n = len(l)
    if n <= 2:
        return True
    inc = True
    dec = True
    for i in range(1, n):
        if l[i] > l[i - 1]:
            dec = False
        elif l[i] < l[i - 1]:
            inc = False
        if not inc and not dec:
            return False
    return True

# Classification response:
# helper function extraction; guard clause; early return; index-based loop; state variable; sorting-based approach; boundary case handling