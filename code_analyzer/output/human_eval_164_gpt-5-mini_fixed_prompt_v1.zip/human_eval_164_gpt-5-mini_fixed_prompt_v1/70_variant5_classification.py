def strange_sort_list(lst):
    a = list(lst)
    res = []
    while a:
        mn = min(a)
        a.remove(mn)
        res.append(mn)
        if not a:
            break
        mx = max(a)
        a.remove(mx)
        res.append(mx)
    return res

# Classification response:
# temporary variable; copy before mutation; accumulator list; split condition; loop rewrite; guard clause; behavior change