def remove_vowels(text):
    table = {ord(c): None for c in "aeiouAEIOU"}
    return text.translate(table)

# Classification response:
# helper function extraction; dict comprehension; list comprehension; temporary variable; builtin function