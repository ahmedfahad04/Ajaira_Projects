def digitSum(s):
    import re
    return sum(map(ord, re.findall(r'[A-Z]', s)))

# Classification response:
# helper function extraction; function renaming; regex usage; map/filter usage; import reorganization; guard clause