def sort_even(l: list):
    evens = sorted(l[0::2])
    it = iter(evens)
    res = list(l)
    for i in range(0, len(res), 2):
        res[i] = next(it)
    return res

# Classification response:
# helper function extraction; slicing; builtin function; copy before mutation; in-place mutation; index-based loop; temporary variable; flattened conditional