from decimal import Decimal, getcontext, ROUND_HALF_UP

def triangle_area(a, b, c):
    # use Decimal for more exact rounding
    try:
        A = Decimal(str(a))
        B = Decimal(str(b))
        C = Decimal(str(c))
    except Exception:
        return -1.0
    # check positivity
    if A <= 0 or B <= 0 or C <= 0:
        return -1.0
    # triangle inequality
    if not (A + B > C and A + C > B and B + C > A):
        return -1.0
    # increase precision for sqrt
    getcontext().prec = 50
    s = (A + B + C) / Decimal(2)
    val = s * (s - A) * (s - B) * (s - C)
    if val < 0:
        val = Decimal(0)
    # sqrt using Decimal's sqrt method
    try:
        area = val.sqrt()
    except Exception:
        return -1.0
    # round to 2 decimal places with HALF_UP
    quant = area.quantize(Decimal('0.00'), rounding=ROUND_HALF_UP)
    return float(quant)

# Classification response:
# variable renaming; function renaming; guard clause; early return; try-except wrapper; temporary variable; standard library helper; input validation; boundary case handling; type conversion; error suppression; behavior change