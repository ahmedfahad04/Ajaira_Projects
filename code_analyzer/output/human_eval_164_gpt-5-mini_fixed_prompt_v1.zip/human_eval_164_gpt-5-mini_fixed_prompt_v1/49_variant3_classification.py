def modp(n: int, p: int):
    if p == 0:
        raise ValueError("Modulo p must be non-zero")
    n = int(n)
    def rec(e):
        if e == 0:
            return 1 % p
        half = rec(e >> 1)
        half_sq = (half * half) % p
        if e & 1:
            return (half_sq * 2) % p
        else:
            return half_sq
    return rec(n)

# Classification response:
# loop rewrite;recursion with base case;helper function extraction;divide and conquer;guard clause;input validation;type conversion;temporary variable