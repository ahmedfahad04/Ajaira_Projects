def common(l1: list, l2: list):
    return sorted(set(l1) & set(l2))

# Classification response:
# loop rewrite; set conversion; accumulator set; helper function extraction