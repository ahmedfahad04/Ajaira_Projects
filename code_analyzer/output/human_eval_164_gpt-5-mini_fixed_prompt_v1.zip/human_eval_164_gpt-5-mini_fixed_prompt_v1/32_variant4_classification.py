def poly(xs: list, x: float):
    def _eval(idx):
        if idx >= len(xs):
            return 0.0
        return xs[idx] + x * _eval(idx + 1)
    if not xs:
        return 0.0
    return _eval(0)

# Classification response:
# helper function extraction; recursion with base case; guard clause; empty input handling; temporary variable