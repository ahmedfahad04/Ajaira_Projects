def largest_prime_factor(n: int):
    import random, math
    if n <= 1:
        return n
    def is_prime(n):
        if n < 2:
            return False
        small_primes = (2,3,5,7,11,13,17,19,23,29)
        for p in small_primes:
            if n % p == 0:
                return n == p
        d = n - 1
        s = 0
        while d % 2 == 0:
            s += 1
            d //= 2
        for a in (2, 325, 9375, 28178, 450775, 9780504, 1795265022):
            if a % n == 0:
                continue
            x = pow(a, d, n)
            if x == 1 or x == n - 1:
                continue
            for _ in range(s - 1):
                x = (x * x) % n
                if x == n - 1:
                    break
            else:
                return False
        return True
    def rho(n):
        if n % 2 == 0:
            return 2
        if is_prime(n):
            return n
        while True:
            c = random.randrange(1, n - 1)
            x = random.randrange(2, n - 1)
            y = x
            d = 1
            while d == 1:
                x = (x * x + c) % n
                y = (y * y + c) % n
                y = (y * y + c) % n
                d = math.gcd(abs(x - y), n)
                if d == n:
                    break
            if d > 1 and d < n:
                return d
    def factor(n, out):
        if n == 1:
            return
        if is_prime(n):
            out.append(n)
        else:
            d = rho(n)
            if d == n:
                out.append(n)
            else:
                factor(d, out)
                factor(n // d, out)
    factors = []
    factor(n, factors)
    return int(max(factors))

# Classification response:
# function renaming; import reorganization; guard clause; helper function extraction; recursion with base case; pollard rho; miller-rabin; accumulator list; standard library helper; boundary case handling; behavior change