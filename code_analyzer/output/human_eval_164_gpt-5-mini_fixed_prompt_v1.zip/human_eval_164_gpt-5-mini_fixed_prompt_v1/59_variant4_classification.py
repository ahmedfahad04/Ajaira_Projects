def largest_prime_factor(n: int):
    import math
    if n <= 1:
        return n
    limit = math.isqrt(n) + 1
    sieve = [True] * (limit + 1)
    primes = []
    for p in range(2, limit + 1):
        if sieve[p]:
            primes.append(p)
            step = p
            start = p * p
            if start <= limit:
                for k in range(start, limit + 1, step):
                    sieve[k] = False
    largest = 1
    for p in primes:
        if n % p == 0:
            while n % p == 0:
                n //= p
            largest = p
    if n > 1:
        largest = n
    return int(largest)

# Classification response:
# function renaming;early return;sieve-based factorization;loop rewrite;while loop;accumulator list;in-place mutation;standard library helper;import reorganization;boundary case handling;type conversion