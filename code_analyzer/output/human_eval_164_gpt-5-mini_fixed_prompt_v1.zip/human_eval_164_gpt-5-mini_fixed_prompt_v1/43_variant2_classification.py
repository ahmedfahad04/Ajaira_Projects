def pairs_sum_to_zero(l):
    if not l or len(l) < 2:
        return False
    a = sorted(l)
    i, j = 0, len(a) - 1
    while i < j:
        s = a[i] + a[j]
        if s == 0:
            return True
        if s < 0:
            i += 1
        else:
            j -= 1
    return False

# Classification response:
# helper function extraction; guard clause; input validation; early return; loop rewrite; while loop; two pointer; sorting-based approach; standard library helper