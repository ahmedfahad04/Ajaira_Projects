from functools import lru_cache

def fib(n: int):
    @lru_cache(maxsize=None)
    def _f(k):
        if k <= 0:
            return 0
        if k == 1 or k == 2:
            return 1
        return _f(k - 1) + _f(k - 2)
    return _f(n)

# Classification response:
# helper function extraction;memoization;standard library helper;parameter renaming;combined condition;boundary case handling