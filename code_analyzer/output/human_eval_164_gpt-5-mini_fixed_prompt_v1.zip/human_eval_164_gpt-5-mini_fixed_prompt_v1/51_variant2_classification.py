import re

def remove_vowels(text):
    return re.sub(r'[aeiouAEIOU]', '', text)

# Classification response:
# helper function extraction;regex usage;import reorganization;list comprehension;literal rewrite