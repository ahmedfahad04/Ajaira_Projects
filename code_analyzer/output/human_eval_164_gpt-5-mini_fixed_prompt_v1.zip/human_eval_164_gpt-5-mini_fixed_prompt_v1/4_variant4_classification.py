from typing import List

def mean_absolute_deviation(numbers: List[float]) -> float:
    # two-pass iterative accumulation without comprehensions
    total = 0.0
    count = 0
    for x in numbers:
        total += x
        count += 1
    if count == 0:
        return 0.0
    mean = total / count
    acc = 0.0
    for x in numbers:
        diff = x - mean
        if diff < 0:
            diff = -diff
        acc += diff
    return acc / count

# Classification response:
# function renaming; import reorganization; loop rewrite; for loop; generator expression; guard clause; temporary variable; empty input handling