def car_race_collision(n: int):
    n = int(n)
    if n <= 0:
        return 0
    return sum((2 * k - 1) for k in range(1, n + 1))

# Classification response:
# function renaming; guard clause; type conversion; boundary case handling; generator expression; builtin function; mathematical formula