def will_it_fly(q,w):
    from collections import deque
    d = deque(q)
    total = 0
    while len(d) > 1:
        a = d.popleft()
        b = d.pop()
        if a != b:
            return False
        total += a + b
        if total > w:
            return False
    if d:
        total += d.pop()
    return total <= w

# Classification response:
# loop rewrite; index-based loop; standard library helper; in-place mutation; temporary variable; builtin function; early return; two pointer; branch reordering