def fib(n: int):
    if n <= 0:
        return 0
    if n == 1 or n == 2:
        return 1
    return fib(n - 1) + fib(n - 2)

# Classification response:
# guard clause; combined condition; literal rewrite; boundary case handling; recursion with base case