def intersperse(numbers: list[int], delimeter: int) -> list[int]:
    res: list[int] = []
    n = len(numbers)
    for i, val in enumerate(numbers):
        res.append(val)
        if i != n - 1:
            res.append(delimeter)
    return res

# Classification response:
# enumerate loop; loop rewrite; variable renaming; function renaming; accumulator list; temporary variable; empty input handling