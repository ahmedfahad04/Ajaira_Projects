def total_match(lst1, lst2):
    def sum_len(lst, i=0):
        if i >= len(lst):
            return 0
        return len(lst[i]) + sum_len(lst, i+1)
    return lst1 if sum_len(lst1) <= sum_len(lst2) else lst2

# Classification response:
# loop rewrite;recursion with base case;helper function extraction;conditional expression