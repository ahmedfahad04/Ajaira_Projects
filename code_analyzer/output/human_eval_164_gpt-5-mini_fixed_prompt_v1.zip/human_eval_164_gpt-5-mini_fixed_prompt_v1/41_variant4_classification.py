def car_race_collision(n: int):
    import math
    n = int(n)
    if n <= 0:
        return 0
    return int(math.pow(n, 2))

# Classification response:
# helper function extraction; import reorganization; guard clause; input validation; boundary case handling; type conversion; standard library helper; behavior change