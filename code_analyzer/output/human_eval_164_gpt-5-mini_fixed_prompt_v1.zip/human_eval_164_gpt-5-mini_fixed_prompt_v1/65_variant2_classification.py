def circular_shift(x, shift):
    s = str(x)
    sign = ''
    if s.startswith('-'):
        sign = '-'
        s = s[1:]
    if not s:
        return sign + s
    n = len(s)
    if shift > n:
        return sign + s[::-1]
    if shift == 0:
        return sign + s
    if shift < 0:
        k = (-shift) % n
        # left rotate using deque
        from collections import deque
        d = deque(s)
        d.rotate(-k)
        return sign + ''.join(d)
    if shift == n:
        return sign + s
    from collections import deque
    d = deque(s)
    d.rotate(shift)
    return sign + ''.join(d)

# Classification response:
# helper function extraction;flattened conditional;guard clause;standard library helper;join/split usage;temporary variable;empty input handling;boundary case handling