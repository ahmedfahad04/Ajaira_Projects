def monotonic(l: list):
    # True if non-decreasing or non-increasing
    return all(x <= y for x, y in zip(l, l[1:])) or all(x >= y for x, y in zip(l, l[1:]))

# Classification response:
# helper function extraction; flattened conditional; sliding window; sorting-based approach; generator expression; zip usage; any/all usage; tuple unpacking