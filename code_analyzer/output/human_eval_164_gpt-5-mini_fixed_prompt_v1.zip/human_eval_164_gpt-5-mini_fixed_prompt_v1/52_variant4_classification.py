def below_threshold(l: list, t: int):
    if not l:
        return True
    return max(l) < t

# Classification response:
# helper function extraction; guard clause; loop rewrite; builtin function; empty input handling