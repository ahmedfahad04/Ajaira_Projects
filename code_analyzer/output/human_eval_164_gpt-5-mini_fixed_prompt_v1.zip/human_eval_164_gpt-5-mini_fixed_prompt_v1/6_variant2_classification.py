from typing import List

def parse_nested_parens(paren_string: str) -> List[int]:
    groups = paren_string.split()
    out: List[int] = []
    for g in groups:
        stack = []
        max_depth = 0
        for c in g:
            if c == '(':
                stack.append('(')
                if len(stack) > max_depth:
                    max_depth = len(stack)
            elif c == ')':
                if stack:
                    stack.pop()
        out.append(max_depth)
    return out

# Classification response:
# function renaming;parameter renaming;import reorganization;join/split usage;loop rewrite;accumulator list;stack-based;in-place mutation;split condition;boundary case handling;behavior change