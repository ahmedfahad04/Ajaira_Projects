def sort_third(l: list):
    sorted_vals = sorted([v for i, v in enumerate(l) if i % 3 == 0])
    it = iter(sorted_vals)
    def build(i):
        if i >= len(l):
            return []
        if i % 3 == 0:
            return [next(it)] + build(i + 1)
        return [l[i]] + build(i + 1)
    return build(0)

# Classification response:
# helper function extraction; recursion with base case; list comprehension; enumerate loop; temporary variable; accumulator list; builtin function