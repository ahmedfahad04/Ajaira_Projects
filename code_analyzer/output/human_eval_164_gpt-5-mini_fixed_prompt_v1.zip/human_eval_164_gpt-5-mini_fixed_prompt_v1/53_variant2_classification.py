import operator
def add(x: int, y: int):
    return operator.add(x, y)

# Classification response:
# helper function extraction; import reorganization; standard library helper