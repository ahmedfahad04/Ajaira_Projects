import math

def triangle_area(a, b, c):
    # place side c on x-axis and compute height from coordinates
    try:
        a = float(a); b = float(b); c = float(c)
    except Exception:
        return -1.0
    if a <= 0 or b <= 0 or c <= 0:
        return -1.0
    # check triangle inequality
    if not (a + b > c and a + c > b and b + c > a):
        return -1.0
    # avoid division by zero
    if c == 0:
        return -1.0
    # x coordinate of projection of side a onto base c
    # using formula x = (a^2 - b^2 + c^2) / (2c)
    x = (a*a - b*b + c*c) / (2.0 * c)
    # height squared = a^2 - x^2
    h2 = a*a - x*x
    if h2 < 0 and h2 > -1e-12:
        h2 = 0.0
    if h2 < 0:
        return -1.0
    h = math.sqrt(h2)
    area = 0.5 * c * h
    return round(area, 2)

# Classification response:
# try-except wrapper;type conversion;input validation;guard clause;reversed condition;temporary variable;standard library helper;mathematical formula;boundary case handling;error suppression;literal rewrite