def sum_to_n(n: int):
    if n <= 0:
        return 0
    from functools import reduce
    from operator import add
    return reduce(add, range(1, n + 1), 0)

# Classification response:
# helper function extraction; early return; boundary case handling; input validation; functools reduce; import reorganization