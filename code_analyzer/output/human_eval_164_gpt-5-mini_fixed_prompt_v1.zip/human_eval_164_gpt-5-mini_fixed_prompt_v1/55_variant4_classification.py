def fib(n: int):
    if n <= 0:
        return 0
    if n == 1:
        return 1
    def mat_mult(A, B):
        return [
            [A[0][0]*B[0][0] + A[0][1]*B[1][0], A[0][0]*B[0][1] + A[0][1]*B[1][1]],
            [A[1][0]*B[0][0] + A[1][1]*B[1][0], A[1][0]*B[0][1] + A[1][1]*B[1][1]],
        ]
    def mat_pow(M, e):
        result = [[1,0],[0,1]]
        base = M
        while e > 0:
            if e & 1:
                result = mat_mult(result, base)
            base = mat_mult(base, base)
            e >>= 1
        return result
    M = [[1,1],[1,0]]
    P = mat_pow(M, n-1)
    return P[0][0]

# Classification response:
# guard clause;helper function extraction;loop rewrite;while loop;accumulator list;matrix exponentiation;boundary case handling;behavior change