def modp(n: int, p: int):
    # Use Python's built-in fast modular exponentiation
    if p == 0:
        raise ValueError("Modulo p must be non-zero")
    return pow(2, n, p)

# Classification response:
# loop rewrite; builtin function; helper function extraction; guard clause; input validation; temporary variable