from typing import List

def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    return [s for s in strings if s.find(substring) >= 0]

# Classification response:
# helper function extraction; variable renaming; import reorganization; list comprehension; builtin function; type annotations added