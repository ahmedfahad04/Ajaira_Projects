from typing import List
import math

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    if threshold <= 0:
        return False
    buckets = {}
    for x in numbers:
        b = math.floor(x / threshold)
        if b in buckets:
            return True
        # check neighboring buckets
        v = buckets.get(b - 1)
        if v is not None and abs(x - v) < threshold:
            return True
        v = buckets.get(b + 1)
        if v is not None and abs(x - v) < threshold:
            return True
        buckets[b] = x
    return False

# Classification response:
# loop rewrite; bucket-based hashing; accumulator dict; dictionary lookup; membership test; guard clause; standard library helper