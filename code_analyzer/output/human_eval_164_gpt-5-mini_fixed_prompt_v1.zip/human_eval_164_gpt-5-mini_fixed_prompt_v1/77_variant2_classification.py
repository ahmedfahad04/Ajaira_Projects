def iscube(a):
    if a == 0:
        return True
    sign = 1 if a > 0 else -1
    r = int(round((abs(a)) ** (1.0/3.0)))
    return (sign * r) ** 3 == a

# Classification response:
# helper function extraction; guard clause; temporary variable; literal rewrite; boundary case handling; in-place mutation