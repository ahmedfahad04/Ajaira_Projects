def will_it_fly(q,w):
    def is_pal(i,j):
        if i >= j:
            return True
        if q[i] != q[j]:
            return False
        return is_pal(i+1,j-1)
    if not is_pal(0, len(q)-1):
        return False
    return sum(q) <= w

# Classification response:
# helper function extraction;recursion with base case;loop rewrite;branch reordering;guard clause