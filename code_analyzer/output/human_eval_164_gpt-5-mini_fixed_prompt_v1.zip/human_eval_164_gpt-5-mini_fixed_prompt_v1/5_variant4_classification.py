def intersperse(numbers: list[int], delimeter: int) -> list[int]:
    if not numbers:
        return []
    if len(numbers) == 1:
        return [numbers[0]]
    return [numbers[0], delimeter] + intersperse(numbers[1:], delimeter)

# Classification response:
# recursion; loop rewrite; helper function extraction; guard clause; accumulator list; in-place mutation; slicing