def search(lst):
    if not lst:
        return -1
    lst_sorted = sorted(lst)
    best = -1
    n = len(lst_sorted)
    i = 0
    while i < n:
        j = i + 1
        while j < n and lst_sorted[j] == lst_sorted[i]:
            j += 1
        val = lst_sorted[i]
        cnt = j - i
        if val > 0 and cnt >= val and val > best:
            best = val
        i = j
    return best

# Classification response:
# sorting-based approach; frequency counting; loop rewrite; while loop; early return; empty input handling; temporary variable; builtin function