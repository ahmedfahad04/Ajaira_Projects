def largest_prime_factor(n: int):
    def smallest_prime_factor(x):
        if x % 2 == 0:
            return 2
        if x % 3 == 0:
            return 3
        i = 5
        while i * i <= x:
            if x % i == 0:
                return i
            if x % (i + 2) == 0:
                return i + 2
            i += 6
        return x
    if n <= 1:
        return n
    s = smallest_prime_factor(n)
    if s == n:
        return n
    return int(max(s, largest_prime_factor(n // s)))

# Classification response:
# function renaming; helper function extraction; recursion with base case; loop rewrite; while loop; early return; guard clause; temporary variable; boundary case handling