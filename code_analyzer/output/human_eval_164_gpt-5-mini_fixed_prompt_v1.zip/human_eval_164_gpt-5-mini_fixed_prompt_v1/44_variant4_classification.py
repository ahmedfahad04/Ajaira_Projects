def change_base(x: int, base: int):
    if not (2 <= base <= 9):
        raise ValueError("base must be between 2 and 9 inclusive")
    if x == 0:
        return "0"
    neg = x < 0
    n = -x if neg else x
    # collect reversed digits then build string using reduce-like loop
    rev = []
    while n > 0:
        n, r = divmod(n, base)
        rev.append(str(r))
    s = ""
    for ch in reversed(rev):
        s += ch
    return "-" + s if neg else s

# Classification response:
# function renaming;guard clause;input validation;boundary case handling;behavior change;loop rewrite;while loop;for loop;accumulator list;in-place mutation;tuple unpacking;builtin function;temporary variable