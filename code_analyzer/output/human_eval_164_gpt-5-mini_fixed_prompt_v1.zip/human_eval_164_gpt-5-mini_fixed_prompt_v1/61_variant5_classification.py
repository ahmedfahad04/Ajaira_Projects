import re
def correct_bracketing(brackets: str):
    s = brackets
    while True:
        new = re.sub(r"\(\)", "", s)
        if new == s:
            break
        s = new
    return s == ""

# Classification response:
# loop rewrite; while loop; regex usage; accumulator string; temporary variable; brute force