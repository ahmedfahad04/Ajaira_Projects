from typing import List

def filter_by_substring(strings: List[str], substring: str) -> List[str]:
    result: List[str] = []
    for s in strings:
        if substring in s:
            result.append(s)
    return result

# Classification response:
# helper function extraction;accumulator list;for loop;temporary variable;list comprehension