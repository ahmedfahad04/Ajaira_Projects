def change_base(x: int, base: int):
    if not (2 <= base <= 9):
        raise ValueError("base must be between 2 and 9 inclusive")
    def helper(n):
        if n < base:
            return str(n)
        q, r = divmod(n, base)
        return helper(q) + str(r)
    if x == 0:
        return "0"
    if x < 0:
        return "-" + helper(-x)
    return helper(x)

# Classification response:
# function renaming;helper function extraction;recursion with base case;guard clause;early return;builtin function;accumulator string;in-place mutation;input validation;boundary case handling;behavior change