import math

def triangle_area(a, b, c):
    # validate input and triangle inequality explicitly for all pairs
    try:
        a = float(a); b = float(b); c = float(c)
    except Exception:
        return -1.0
    if a <= 0 or b <= 0 or c <= 0:
        return -1.0
    if not (a + b > c and a + c > b and b + c > a):
        return -1.0
    # Heron's but guard tiny negative under sqrt due to FP
    s = (a + b + c) / 2.0
    under = s * (s - a) * (s - b) * (s - c)
    if under < 0 and under > -1e-12:
        under = 0.0
    if under < 0:
        return -1.0
    area = math.sqrt(under)
    # format to 2 decimals then convert to float to ensure exactly two decimal precision visually not necessary but consistent
    return float("{:.2f}".format(area))

# Classification response:
# try-except wrapper;type conversion;input validation;guard clause;reversed condition;temporary variable;boundary case handling;standard library helper;string formatting change;import reorganization;behavior change