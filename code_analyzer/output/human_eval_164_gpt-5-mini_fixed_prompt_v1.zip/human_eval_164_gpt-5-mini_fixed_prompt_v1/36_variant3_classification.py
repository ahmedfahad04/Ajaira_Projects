def fizz_buzz(n: int):
    seen = set()
    total = 0
    def count_sevens(x):
        c = 0
        if x == 0:
            return 0
        while x:
            if x % 10 == 7:
                c += 1
            x //= 10
        return c
    for k in range(11, n, 11):
        if k not in seen:
            seen.add(k)
            total += count_sevens(k)
    for k in range(13, n, 13):
        if k not in seen:
            seen.add(k)
            total += count_sevens(k)
    return total

# Classification response:
# variable renaming;accumulator list;accumulator set;loop rewrite;for loop;while loop;helper function extraction;split condition;membership test;early return;frequency counting;boundary case handling