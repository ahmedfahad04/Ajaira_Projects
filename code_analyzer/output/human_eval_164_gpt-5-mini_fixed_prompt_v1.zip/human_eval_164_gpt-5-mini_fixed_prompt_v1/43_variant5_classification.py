def pairs_sum_to_zero(l):
    s = set(l)
    zero_count = l.count(0)
    if zero_count > 1:
        return True
    for x in s:
        if x != 0 and -x in s:
            return True
    return False

# Classification response:
# loop rewrite; set conversion; membership test; frequency counting; helper function extraction; guard clause