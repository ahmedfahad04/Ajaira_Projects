def monotonic(l: list):
    # Recursive/scan approach handling equal neighbors by skipping
    n = len(l)
    if n <= 2:
        return True
    i = 0
    while i + 1 < n and l[i] == l[i+1]:
        i += 1
    if i + 1 == n:
        return True
    if l[i] < l[i+1]:
        # must be non-decreasing from here
        for j in range(i+1, n):
            if l[j] < l[j-1]:
                return False
        return True
    else:
        # must be non-increasing from here
        for j in range(i+1, n):
            if l[j] > l[j-1]:
                return False
        return True

# Classification response:
# guard clause; early return; while loop; for loop; state variable; sorting-based approach; linear scan; boundary case handling; split condition