def fruit_distribution(s,n):
    transformed = ''.join(ch if (ch.isdigit() or ch == '-') else ' ' for ch in s)
    parts = [p for p in transformed.split() if p != '-']
    nums = []
    for p in parts:
        try:
            nums.append(int(p))
        except:
            pass
    a = nums[0] if len(nums) > 0 else 0
    b = nums[1] if len(nums) > 1 else 0
    return n - a - b

# Classification response:
# function renaming; variable renaming; try-except wrapper; accumulator list; list comprehension; generator expression; join/split usage; temporary variable; default value handling; error suppression; behavior change