import re
def vowels_count(s):
    if not s:
        return 0
    s = s or ""
    # count aeiou (case-insensitive)
    found = re.findall(r'[aeiou]', s, flags=re.IGNORECASE)
    count = len(found)
    # add y if last character is y or Y
    if s[-1].lower() == 'y':
        count += 1
    return count

# Classification response:
# import reorganization; regex usage; guard clause; empty input handling; temporary variable; combined condition