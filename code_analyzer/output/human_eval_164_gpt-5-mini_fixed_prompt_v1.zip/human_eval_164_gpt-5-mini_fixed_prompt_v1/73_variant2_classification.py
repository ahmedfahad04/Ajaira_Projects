def smallest_change(arr):
    i, j = 0, len(arr) - 1
    changes = 0
    while i < j:
        if arr[i] != arr[j]:
            changes += 1
        i += 1
        j -= 1
    return changes

# Classification response:
# variable renaming; loop rewrite; while loop; two pointer; helper function extraction; tuple unpacking; temporary variable