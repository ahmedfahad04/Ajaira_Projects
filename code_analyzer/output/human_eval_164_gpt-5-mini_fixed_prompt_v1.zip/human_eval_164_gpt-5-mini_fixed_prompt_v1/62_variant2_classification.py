def derivative(xs: list):
    if not xs or len(xs) < 2:
        return []
    return list(map(lambda i: i * xs[i], range(1, len(xs))))

# Classification response:
# helper function extraction; guard clause; empty input handling; map/filter usage; lambda expression; index-based loop; enumerate loop; list conversion