def monotonic(l: list):
    # Check against sorted orders
    return l == sorted(l) or l == sorted(l, reverse=True)

# Classification response:
# helper function extraction; flattened conditional; type annotation