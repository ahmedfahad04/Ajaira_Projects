def is_palindrome(text: str):
    i = 0
    j = len(text) - 1
    while i < j:
        if text[i] != text[j]:
            return False
        i += 1
        j -= 1
    return True

# Classification response:
# loop rewrite;while loop;two pointer;temporary variable;early return