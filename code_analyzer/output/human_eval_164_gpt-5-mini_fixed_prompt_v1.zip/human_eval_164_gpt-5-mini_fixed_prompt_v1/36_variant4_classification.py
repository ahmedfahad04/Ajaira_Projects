def fizz_buzz(n: int):
    def count_in_multiples(step):
        return sum(str(step * k).count('7') for k in range(1, (n - 1) // step + 1))
    total = count_in_multiples(11) + count_in_multiples(13)
    lcm = 11 * 13
    total -= count_in_multiples(lcm)
    return total

# Classification response:
# helper function extraction;split condition;inclusion-exclusion;generator expression;builtin function;loop rewrite;frequency counting