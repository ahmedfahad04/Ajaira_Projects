def median(l: list):
    import statistics
    if not l:
        raise ValueError("median of empty list")
    return statistics.median(l)

# Classification response:
# helper function extraction;guard clause;import reorganization;standard library helper;empty input handling;behavior change