def encode_cyclic(s: str):
    from itertools import islice
    it = iter(s)
    out = []
    while True:
        chunk = "".join(islice(it, 3))
        if not chunk:
            break
        if len(chunk) == 3:
            out.append(chunk[1:] + chunk[0])
        else:
            out.append(chunk)
    return "".join(out)

# Classification response:
# helper function inlining;while loop;accumulator list;temporary variable;itertools usage;join/split usage;boundary case handling