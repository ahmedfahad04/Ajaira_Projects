from itertools import accumulate
def correct_bracketing(brackets: str):
    vals = [1 if c == '<' else -1 for c in brackets]
    if not vals:
        return True
    cum = list(accumulate(vals))
    return min(cum) >= 0 and cum[-1] == 0

# Classification response:
# loop rewrite;itertools usage;list comprehension;accumulator list;list conversion;prefix/suffix computation;combined condition;empty input handling;temporary variable