def is_multiply_prime(a):
    if not isinstance(a, int) or a < 2:
        return False
    def is_prime(n):
        if n <= 1:
            return False
        if n <= 3:
            return True
        if n % 2 == 0:
            return False
        i = 3
        while i * i <= n:
            if n % i == 0:
                return False
            i += 2
        return True
    # check factors p such that remaining is product of two primes
    for p in range(2, a + 1):
        if not is_prime(p):
            continue
        if a % p != 0:
            continue
        rem = a // p
        # now check if rem is product of two primes (can be same)
        for q in range(2, rem + 1):
            if not is_prime(q):
                continue
            if rem % q != 0:
                continue
            r = rem // q
            if is_prime(r):
                return True
    return False

# Classification response:
# function renaming; loop rewrite; while loop; early return; guard clause; combined condition; temporary variable; factorization based search; sqrt trial division; input validation; boundary case handling