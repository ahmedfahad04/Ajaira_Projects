def fizz_buzz(n: int):
    nums = set(range(11, n, 11))
    nums.update(range(13, n, 13))
    return sum(str(x).count('7') for x in nums)

# Classification response:
# variable renaming;loop rewrite;split condition;set conversion;in-place mutation;generator expression;builtin function;frequency counting