def below_threshold(l: list, t: int):
    return not any(x >= t for x in l)

# Classification response:
# helper function extraction; function renaming; loop rewrite; any/all usage; generator expression