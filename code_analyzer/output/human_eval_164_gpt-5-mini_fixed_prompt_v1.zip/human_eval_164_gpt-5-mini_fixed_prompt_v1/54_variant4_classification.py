def same_chars(s0: str, s1: str):
    # compare sorted unique character sequences
    u0 = ''.join(sorted({c for c in s0}))
    u1 = ''.join(sorted({c for c in s1}))
    return u0 == u1

# Classification response:
# helper function extraction; set comprehension; sorting-based approach; join/split usage; temporary variable