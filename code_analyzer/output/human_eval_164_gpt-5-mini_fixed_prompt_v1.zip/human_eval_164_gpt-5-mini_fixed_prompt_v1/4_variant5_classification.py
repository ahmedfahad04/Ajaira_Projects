from typing import List

def mean_absolute_deviation(numbers: List[float]) -> float:
    def kahan_sum(seq):
        s = 0.0
        c = 0.0
        for v in seq:
            y = v - c
            t = s + y
            c = (t - s) - y
            s = t
        return s

    n = len(numbers)
    if n == 0:
        return 0.0
    mean = kahan_sum(numbers) / n
    diffs = ((x - mean) if x >= mean else (mean - x) for x in numbers)
    return kahan_sum(diffs) / n

# Classification response:
# guard clause; helper function extraction; generator expression; conditional expression; temporary variable; import reorganization; numerical stability