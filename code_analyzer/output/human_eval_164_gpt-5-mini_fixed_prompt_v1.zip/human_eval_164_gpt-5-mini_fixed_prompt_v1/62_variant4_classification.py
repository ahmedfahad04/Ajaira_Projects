def derivative(xs: list):
    def helper(i):
        if i >= len(xs):
            return []
        return [i * xs[i]] + helper(i + 1)
    return helper(1)

# Classification response:
# recursion with base case; helper function extraction; index-based loop; state variable