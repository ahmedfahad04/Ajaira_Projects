import math

def prime_fib(n: int):
    if n <= 0:
        raise ValueError("n must be positive")
    def is_prime(x):
        if x < 2:
            return False
        if x % 2 == 0:
            return x == 2
        r = int(math.isqrt(x))
        i = 3
        while i <= r:
            if x % i == 0:
                return False
            i += 2
        return True

    a, b = 1, 1
    count = 0
    while True:
        a, b = b, a + b  # advance: a becomes next Fibonacci
        if is_prime(a):
            count += 1
            if count == n:
                return a

# Classification response:
# function renaming;parameter renaming;variable renaming;helper function extraction;guard clause;loop rewrite;while loop;accumulator list;tuple unpacking;state variable;standard library helper;input validation;boundary case handling