from typing import List

def separate_paren_groups(paren_string: str) -> List[str]:
    s = ''.join(paren_string.split())
    res: List[str] = []
    start = None
    balance = 0
    for i, ch in enumerate(s):
        if ch == '(':
            if balance == 0:
                start = i
            balance += 1
        elif ch == ')':
            balance -= 1
        if balance == 0 and start is not None:
            res.append(s[start:i+1])
            start = None
    return res

# Classification response:
# function renaming; variable renaming; import reorganization; enumerate loop; flattened conditional; accumulator list; slicing; state variable; join/split usage; standard library helper; two pointer; behavior change