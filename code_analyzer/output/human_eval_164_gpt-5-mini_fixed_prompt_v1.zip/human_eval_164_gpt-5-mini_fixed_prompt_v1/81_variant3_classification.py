def numerical_letter_grade(grades):
    import bisect
    # Special cases for exact 4.0 and 0.0
    thresholds = [0.0, 0.7, 1.0, 1.3, 1.7, 2.0, 2.3, 2.7, 3.0, 3.3, 3.7]
    labels = ['D-', 'D', 'D+', 'C-', 'C', 'C+', 'B-', 'B', 'B+', 'A-', 'A']
    out = []
    for g in grades:
        if g == 4.0:
            out.append('A+')
        elif g == 0.0:
            out.append('E')
        else:
            # Use bisect_left so that exact threshold values are not considered greater-than
            idx = bisect.bisect_left(thresholds, g) - 1
            if idx < 0:
                out.append('E')
            else:
                out.append(labels[idx])
    return out

# Classification response:
# variable renaming;helper function extraction;flattened conditional;guard clause;standard library helper;import reorganization;temporary variable;boundary case handling;accumulator list