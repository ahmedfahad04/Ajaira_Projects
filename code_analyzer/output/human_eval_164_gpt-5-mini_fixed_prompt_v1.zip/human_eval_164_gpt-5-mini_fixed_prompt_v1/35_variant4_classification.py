def max_element(l: list):
    if not l:
        raise ValueError("max_element() arg is an empty sequence")
    def rec(a, lo, hi):
        if lo == hi:
            return a[lo]
        mid = (lo + hi) // 2
        left_max = rec(a, lo, mid)
        right_max = rec(a, mid + 1, hi)
        return left_max if left_max >= right_max else right_max
    return rec(l, 0, len(l) - 1)

# Classification response:
# recursion; helper function extraction; loop rewrite; divide and conquer; conditional expression; guard clause; input validation; empty input handling; behavior change; temporary variable