from typing import List, Tuple
from functools import reduce

def sum_product(numbers: List[int]) -> Tuple[int, int]:
    # single-pass reduce to compute both sum and product
    s, p = reduce(lambda acc, x: (acc[0] + x, acc[1] * x), numbers, (0, 1))
    return s, p

# Classification response:
# variable renaming; loop rewrite; functools reduce; lambda expression; tuple unpacking; import reorganization