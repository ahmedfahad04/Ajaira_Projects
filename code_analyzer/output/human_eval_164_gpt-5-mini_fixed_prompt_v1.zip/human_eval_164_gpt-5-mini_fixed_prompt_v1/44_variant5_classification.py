def change_base(x: int, base: int):
    if not (2 <= base <= 9):
        raise ValueError("base must be between 2 and 9 inclusive")
    # iterative with building string from least significant to most then reverse
    if x == 0:
        return "0"
    sign = "-" if x < 0 else ""
    n = abs(x)
    s = []
    while n > 0:
        n, rem = divmod(n, base)
        s.append(chr(ord('0') + rem))
    s.reverse()
    return sign + "".join(s)

# Classification response:
# helper function extraction;guard clause;input validation;empty input handling;behavior change;loop rewrite;accumulator list;in-place mutation;join/split usage;tuple unpacking;builtin function;temporary variable;string formatting change