def fibfib(n: int):
    if n <= 1:
        return 0
    if n == 2:
        return 1
    # Use 3x3 matrix as flat tuple and unrolled multiplication for speed
    # Matrix in row-major: (m00,m01,m02,m10,m11,m12,m20,m21,m22)
    T = (1,1,1, 1,0,0, 0,1,0)
    def mul(A, B):
        a00,a01,a02,a10,a11,a12,a20,a21,a22 = A
        b00,b01,b02,b10,b11,b12,b20,b21,b22 = B
        return (
            a00*b00 + a01*b10 + a02*b20,
            a00*b01 + a01*b11 + a02*b21,
            a00*b02 + a01*b12 + a02*b22,
            a10*b00 + a11*b10 + a12*b20,
            a10*b01 + a11*b11 + a12*b21,
            a10*b02 + a11*b12 + a12*b22,
            a20*b00 + a21*b10 + a22*b20,
            a20*b01 + a21*b11 + a22*b21,
            a20*b02 + a21*b12 + a22*b22
        )
    def pow_mat(mat, exp):
        # identity
        I = (1,0,0, 0,1,0, 0,0,1)
        res = I
        base = mat
        while exp:
            if exp & 1:
                res = mul(res, base)
            base = mul(base, base)
            exp >>= 1
        return res
    Mp = pow_mat(T, n-2)
    # multiply Mp by base vector [1,0,0] gives first column of Mp
    # first column entries are indices 0,3,6
    return Mp[0]

# Classification response:
# helper function extraction;loop rewrite;while loop;divide and conquer;tuple unpacking;guard clause;combined condition;state variable