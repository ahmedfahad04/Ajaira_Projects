def strange_sort_list(lst):
    n = len(lst)
    if n <= 1:
        return list(lst)
    s = sorted(lst)
    res = []
    i, j = 0, n - 1
    while i <= j:
        res.append(s[i])
        i += 1
        if i <= j:
            res.append(s[j])
            j -= 1
    return res

# Classification response:
# function renaming; variable renaming; loop rewrite; index-based loop; two pointer; sorting-based approach; standard library helper; early return; empty input handling; tuple unpacking; copy before mutation