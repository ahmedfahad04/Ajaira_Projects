def sum_to_n(n: int):
    if n <= 0:
        return 0
    return n * (n + 1) // 2

# Classification response:
# function renaming; guard clause; input validation; mathematical formula