def fibfib(n: int):
    if n <= 1:
        return 0
    if n == 2:
        return 1
    # Companion matrix T for [f(n), f(n-1), f(n-2)] = T * [f(n-1), f(n-2), f(n-3)]
    T = [[1,1,1],
         [1,0,0],
         [0,1,0]]
    def mat_mul(A, B):
        m, p = len(A), len(B[0])
        res = [[0]*p for _ in range(m)]
        for i in range(m):
            Ai = A[i]
            for k in range(len(B)):
                Bk = B[k]
                aik = Ai[k]
                if aik:
                    for j in range(p):
                        res[i][j] += aik * Bk[j]
        return res
    def mat_pow(mat, exp):
        # identity
        size = len(mat)
        res = [[0]*size for _ in range(size)]
        for i in range(size):
            res[i][i] = 1
        base = [row[:] for row in mat]
        while exp:
            if exp & 1:
                res = mat_mul(res, base)
            base = mat_mul(base, base)
            exp >>= 1
        return res
    p = n - 2
    Mp = mat_pow(T, p)
    base_vec = [[1],[0],[0]]  # f2,f1,f0
    result_vec = mat_mul(Mp, base_vec)
    return result_vec[0][0]

# Classification response:
# helper function extraction; loop rewrite; combined condition; early return; matrix exponentiation; exponentiation by squaring; accumulator list; list comprehension; copy before mutation