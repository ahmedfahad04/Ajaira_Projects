def pluck(arr):
    def helper(l, r):
        if l >= r:
            return None
        if r - l == 1:
            v = arr[l]
            return (v, l) if v % 2 == 0 else None
        m = (l + r) // 2
        left = helper(l, m)
        right = helper(m, r)
        if left is None:
            return right
        if right is None:
            return left
        if left[0] < right[0]:
            return left
        if left[0] > right[0]:
            return right
        return left if left[1] <= right[1] else right

    if not arr:
        return []
    best = helper(0, len(arr))
    if best is None:
        return []
    return [best[0], best[1]]

# Classification response:
# helper function extraction; recursion; divide and conquer; tuple unpacking; map/filter usage