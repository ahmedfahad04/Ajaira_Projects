def same_chars(s0: str, s1: str):
    # use symmetric difference: empty means same unique characters
    return len(set(s0).symmetric_difference(set(s1))) == 0

# Classification response:
# helper function extraction; set conversion