def is_simple_power(x, n):
    # Multiplicative iteration: build powers until reach or exceed target
    if x == 1:
        return True
    if n == 1:
        return x == 1
    if n == 0:
        return x == 0
    if n == -1:
        return x in (1, -1)
    if x == 0:
        return n == 0
    val = 1
    target = abs(x)
    # multiply until we either hit x or grow beyond target (for |n|>1)
    while True:
        val *= n
        if val == x:
            return True
        if val == 0:
            return x == 0
        if abs(n) > 1 and abs(val) > target:
            return False
        # If |n| == 1 handled above; loop will eventually find or break

# Classification response:
# function renaming; variable renaming; guard clause; early return; loop rewrite; temporary variable; membership test; boundary case handling; input validation; brute force