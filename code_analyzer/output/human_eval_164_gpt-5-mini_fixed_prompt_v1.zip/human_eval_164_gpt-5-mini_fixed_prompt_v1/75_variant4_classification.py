def is_multiply_prime(a):
    if not isinstance(a, int) or a < 2:
        return False
    # precompute primes up to 100 using sieve
    limit = 100
    sieve = [True] * (limit + 1)
    sieve[0:2] = [False, False]
    p = 2
    while p * p <= limit:
        if sieve[p]:
            for k in range(p * p, limit + 1, p):
                sieve[k] = False
        p += 1
    primes = [i for i, val in enumerate(sieve) if val]
    # backtracking: try to pick three primes that multiply to a
    def backtrack(idx, depth, prod):
        if depth == 3:
            return prod == a
        for i in range(len(primes)):
            p = primes[i]
            if prod * p > a:
                continue
            if a % (prod * p) != 0 and depth < 2:
                # even if not dividing now, deeper picks might, but skip for efficiency
                pass
            if backtrack(i, depth + 1, prod * p):
                return True
        return False
    return backtrack(0, 0, 1)

# Classification response:
# function renaming;helper function extraction;recursion with base case;loop rewrite;list comprehension;in-place mutation;accumulator list;early return;input validation;type check