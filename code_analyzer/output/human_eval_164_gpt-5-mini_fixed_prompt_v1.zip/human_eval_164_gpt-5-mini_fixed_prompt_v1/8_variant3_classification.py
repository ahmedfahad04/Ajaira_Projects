from typing import List, Tuple
from functools import reduce
import operator

def sum_product(numbers: List[int]) -> Tuple[int, int]:
    total = sum(numbers)
    prod = reduce(operator.mul, numbers, 1)
    return total, prod

# Classification response:
# variable renaming;helper function extraction;loop rewrite;functools reduce;builtin function;import reorganization