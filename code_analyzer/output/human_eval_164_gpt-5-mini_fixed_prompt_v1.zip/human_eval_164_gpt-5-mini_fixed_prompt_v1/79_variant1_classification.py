def decimal_to_binary(decimal):
    if decimal == 0:
        return "db0db"
    if decimal < 0:
        return "db-" + bin(-decimal)[2:] + "db"
    return "db" + bin(decimal)[2:] + "db"

# Classification response:
# helper function extraction; function renaming; early return; guard clause; boundary case handling