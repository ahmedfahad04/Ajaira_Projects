def change_base(x: int, base: int):
    if not (2 <= base <= 9):
        raise ValueError("base must be between 2 and 9 inclusive")
    if x == 0:
        return "0"
    neg = x < 0
    n = -x if neg else x
    digits = []
    while n > 0:
        n, r = divmod(n, base)
        digits.append(str(r))
    if neg:
        digits.append('-')
        return ''.join(reversed(digits))
    return ''.join(reversed(digits))

# Classification response:
# function renaming; variable renaming; accumulator list; in-place mutation; loop rewrite; builtin function; join/split usage; guard clause; early return; input validation; boundary case handling; behavior change