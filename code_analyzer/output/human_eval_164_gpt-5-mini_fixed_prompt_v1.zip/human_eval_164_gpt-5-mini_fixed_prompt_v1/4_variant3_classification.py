from typing import List
import math

def mean_absolute_deviation(numbers: List[float]) -> float:
    if not numbers:
        return 0.0
    n = len(numbers)
    m = math.fsum(numbers) / n
    return math.fsum((x - m) if x >= m else (m - x) for x in numbers) / n

# Classification response:
# helper function extraction; early return; conditional expression; generator expression; temporary variable; variable renaming; standard library helper; empty input handling; type annotations