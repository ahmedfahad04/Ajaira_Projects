def triangle_area(a, h):
    from decimal import Decimal
    A = Decimal(str(a))
    H = Decimal(str(h))
    return float((A * H) / Decimal(2))

# Classification response:
# helper function extraction;import reorganization;standard library helper;temporary variable;literal rewrite;type conversion