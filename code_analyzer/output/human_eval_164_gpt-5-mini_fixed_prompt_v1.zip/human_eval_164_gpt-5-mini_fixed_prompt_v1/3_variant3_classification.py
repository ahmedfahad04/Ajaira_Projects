from typing import List

def below_zero(operations: List[int]) -> bool:
    # recursive approach
    def helper(idx: int, bal: int) -> bool:
        if idx == len(operations):
            return False
        bal += operations[idx]
        if bal < 0:
            return True
        return helper(idx + 1, bal)
    return helper(0, 0)

# Classification response:
# recursion; helper function extraction; loop rewrite; early return; import reorganization