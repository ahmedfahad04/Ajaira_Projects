def car_race_collision(n: int):
    n = int(n)
    if n <= 0:
        return 0
    return n * n

# Classification response:
# helper function extraction; guard clause; type conversion; boundary case handling; temporary variable