def triangle_area(a, h):
    try:
        return float(a) * float(h) / 2.0
    except Exception as e:
        raise TypeError("Inputs must be numbers") from e

# Classification response:
# try-except wrapper; helper function extraction; type conversion; input validation