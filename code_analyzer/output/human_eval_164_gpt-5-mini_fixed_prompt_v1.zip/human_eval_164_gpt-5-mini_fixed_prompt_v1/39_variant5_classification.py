import random

def prime_fib(n: int):
    if n <= 0:
        raise ValueError("n must be positive")

    def is_prime_mr(nm):
        if nm < 2:
            return False
        small = [2,3,5,7,11,13,17,19,23,29]
        for p in small:
            if nm % p == 0:
                return nm == p
        d = nm - 1
        s = 0
        while d % 2 == 0:
            d //= 2
            s += 1
        def check(a):
            x = pow(a, d, nm)
            if x == 1 or x == nm - 1:
                return True
            for _ in range(s - 1):
                x = (x * x) % nm
                if x == nm - 1:
                    return True
            return False
        # probabilistic with random bases
        for a in [2, 3, 5, 7, 11]:
            if a % nm == 0:
                continue
            if not check(a):
                return False
        return True

    # Matrix exponentiation for Fibonacci
    def fib_matrix(nm):
        def mul(A, B):
            return (A[0]*B[0] + A[1]*B[2], A[0]*B[1] + A[1]*B[3],
                    A[2]*B[0] + A[3]*B[2], A[2]*B[1] + A[3]*B[3])
        def mat_pow(mat, e):
            res = (1,0,0,1)
            while e > 0:
                if e & 1:
                    res = mul(res, mat)
                mat = mul(mat, mat)
                e >>= 1
            return res
        if nm == 0:
            return 0
        M = (1,1,1,0)
        R = mat_pow(M, nm-1)
        return R[0]

    # brute force over Fibonacci sequence
    a, b = 1, 1
    count = 0
    while True:
        a, b = b, a + b
        if a > 1 and is_prime_mr(a):
            count += 1
            if count == n:
                return a

# Classification response:
# function renaming; helper function extraction; import reorganization; guard clause; input validation; state variable; accumulator list; tuple unpacking; miller-rabin; matrix exponentiation