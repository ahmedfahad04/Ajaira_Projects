def sum_to_n(n: int):
    total = 0
    if n <= 0:
        return 0
    for i in range(1, n + 1):
        total += i
    return total

# Classification response:
# helper function extraction; loop rewrite; for loop; guard clause; state variable; builtin function; boundary case handling