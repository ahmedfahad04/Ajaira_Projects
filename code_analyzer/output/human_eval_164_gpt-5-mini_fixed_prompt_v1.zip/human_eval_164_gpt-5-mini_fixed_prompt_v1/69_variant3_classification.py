def search(lst):
    # build counts then check descending values
    counts = {}
    maxval = 0
    for x in lst:
        counts[x] = counts.get(x, 0) + 1
        if x > maxval:
            maxval = x
    for v in range(maxval, 0, -1):
        if v in counts and counts[v] >= v:
            return v
    return -1

# Classification response:
# accumulator dict;temporary variable;helper function extraction;early return;loop rewrite;membership test;default value handling;empty input handling