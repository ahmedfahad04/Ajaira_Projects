def total_match(lst1, lst2):
    s1 = sum(map(len, lst1))
    s2 = sum(map(len, lst2))
    if s1 <= s2:
        return lst1
    return lst2

# Classification response:
# variable renaming; helper function extraction; loop rewrite; map/filter usage; builtin function; early return