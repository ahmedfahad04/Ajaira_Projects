from typing import List

def has_close_elements(numbers: List[float], threshold: float) -> bool:
    if threshold <= 0:
        return False
    n = len(numbers)
    for i in range(n):
        ai = numbers[i]
        for j in range(i + 1, n):
            if abs(ai - numbers[j]) < threshold:
                return True
    return False

# Classification response:
# loop rewrite; index-based loop; helper function extraction; guard clause; temporary variable; input validation; standard library helper