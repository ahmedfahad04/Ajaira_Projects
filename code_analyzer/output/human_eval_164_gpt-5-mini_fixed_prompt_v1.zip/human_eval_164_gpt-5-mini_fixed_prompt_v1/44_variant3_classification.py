def change_base(x: int, base: int):
    if not (2 <= base <= 9):
        raise ValueError("base must be between 2 and 9 inclusive")
    if x == 0:
        return "0"
    neg = x < 0
    n = -x if neg else x
    out = []
    while n:
        n, r = divmod(n, base)
        out.insert(0, str(r))
    s = ''.join(out)
    return "-" + s if neg else s

# Classification response:
# helper function extraction;guard clause;early return;input validation;boundary case handling;behavior change;variable renaming;temporary variable;accumulator list;in-place mutation;join/split usage;builtin function