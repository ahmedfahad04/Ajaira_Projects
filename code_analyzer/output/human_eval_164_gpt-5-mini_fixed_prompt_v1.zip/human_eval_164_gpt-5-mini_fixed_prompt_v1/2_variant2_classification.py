import math
def truncate_number(number: float) -> float:
    """Use math.modf to get fractional part."""
    frac, _ = math.modf(number)
    return frac

# Classification response:
# helper function extraction; import reorganization; standard library helper; tuple unpacking; behavior change