def same_chars(s0: str, s1: str):
    a = set()
    for ch in s0:
        a.add(ch)
    b = set()
    for ch in s1:
        b.add(ch)
    if len(a) != len(b):
        return False
    for ch in a:
        if ch not in b:
            return False
    return True

# Classification response:
# helper function extraction;loop rewrite;for loop;accumulator set;in-place mutation;guard clause;membership test;temporary variable