def triangle_area(a, h):
    from fractions import Fraction
    area = Fraction(a) * Fraction(h) / Fraction(2)
    return float(area)

# Classification response:
# helper function extraction; import reorganization; standard library helper; type conversion; temporary variable; literal rewrite