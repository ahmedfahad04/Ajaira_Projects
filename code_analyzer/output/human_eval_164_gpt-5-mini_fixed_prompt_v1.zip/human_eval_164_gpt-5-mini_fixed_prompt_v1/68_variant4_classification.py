from functools import reduce

def pluck(arr):
    def chooser(a, b):
        if a is None:
            return b
        if b is None:
            return a
        if b[0] < a[0]:
            return b
        if b[0] > a[0]:
            return a
        return a if a[1] <= b[1] else b

    gen = ((v, i) for i, v in enumerate(arr) if v % 2 == 0)
    best = reduce(chooser, gen, None)
    if best is None:
        return []
    return [best[0], best[1]]

# Classification response:
# helper function extraction;functools reduce;generator expression;enumerate loop;tuple unpacking;sentinel flag;state variable;early return;empty input handling