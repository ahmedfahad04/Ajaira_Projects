def unique(l: list):
    import heapq
    seen = set()
    heap = []
    for x in l:
        if x not in seen:
            seen.add(x)
            heap.append(x)
    if not heap:
        return []
    heapq.heapify(heap)
    res = []
    while heap:
        res.append(heapq.heappop(heap))
    return res

# Classification response:
# helper function extraction;heap-based;standard library helper;accumulator set;accumulator list;membership test;early return;for loop;while loop;in-place mutation