from typing import List
from functools import reduce

def rolling_max(numbers: List[int]) -> List[int]:
    if not numbers:
        return []
    def step(acc: List[int], x: int) -> List[int]:
        if not acc:
            acc.append(x)
        else:
            acc.append(acc[-1] if acc[-1] > x else x)
        return acc
    return reduce(step, numbers, [])

# Classification response:
# import reorganization;helper function extraction;early return;loop rewrite;functools reduce;accumulator list;in-place mutation;conditional expression;prefix/suffix computation;empty input handling