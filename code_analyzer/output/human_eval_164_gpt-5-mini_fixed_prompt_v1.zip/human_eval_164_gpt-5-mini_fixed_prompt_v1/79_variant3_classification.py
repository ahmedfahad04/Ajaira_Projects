def decimal_to_binary(decimal):
    n = decimal
    if n == 0:
        return "db0db"
    sign = ""
    if n < 0:
        sign = "-"
        n = -n
    digits = []
    while n > 0:
        digits.append(str(n & 1))
        n >>= 1
    bits = "".join(reversed(digits))
    return "db" + sign + bits + "db"

# Classification response:
# function renaming; early return; while loop; accumulator list; temporary variable; bitwise conversion; join/split usage; builtin function; boundary case handling