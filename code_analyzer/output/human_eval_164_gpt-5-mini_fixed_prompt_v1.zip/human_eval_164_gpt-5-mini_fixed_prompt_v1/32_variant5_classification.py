import math
def poly(xs: list, x: float):
    if not xs:
        return 0.0
    terms = (coeff * math.pow(x, i) for i, coeff in enumerate(xs))
    return math.fsum(terms)

# Classification response:
# guard clause; empty input handling; generator expression; enumerate usage; standard library helper; import reorganization