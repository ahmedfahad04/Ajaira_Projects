def iscube(a):
    if a == 0:
        return True
    n = abs(a)
    r = int(pow(n, 1.0/3.0))
    if r < 0:
        r = 0
    while (r + 1) ** 3 <= n:
        r += 1
    while r ** 3 > n:
        r -= 1
    return r ** 3 == n

# Classification response:
# helper function extraction; early return; variable renaming; temporary variable; state variable; loop rewrite; while loop; builtin function; boundary case handling