from typing import List
import itertools

def parse_nested_parens(paren_string: str) -> List[int]:
    parts = paren_string.split()
    results: List[int] = []
    for p in parts:
        vals = (1 if c == '(' else (-1 if c == ')' else 0) for c in p)
        # compute cumulative sums
        cum = list(itertools.accumulate(vals))
        results.append(max(cum) if cum else 0)
    return results

# Classification response:
# function renaming; parameter renaming; import reorganization; loop rewrite; accumulator list; generator expression; itertools usage; list conversion; conditional expression; boundary case handling