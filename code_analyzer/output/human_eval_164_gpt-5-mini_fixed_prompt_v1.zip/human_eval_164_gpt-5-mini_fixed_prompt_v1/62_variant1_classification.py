def derivative(xs: list):
    return [i * v for i, v in enumerate(xs) if i]

# Classification response:
# variable renaming; helper function extraction; list comprehension; slicing; enumerate usage