def decimal_to_binary(decimal):
    return "db" + format(decimal, "b") + "db"

# Classification response:
# helper function extraction; string formatting change; builtin function