def is_multiply_prime(a):
    if not isinstance(a, int) or a < 2:
        return False
    n = a
    count = 0
    # trial divide by 2
    while n % 2 == 0:
        n //= 2
        count += 1
        if count > 3:
            return False
    # trial divide odd numbers
    f = 3
    while f * f <= n:
        while n % f == 0:
            n //= f
            count += 1
            if count > 3:
                return False
        f += 2
    if n > 1:
        count += 1
    return count == 3

# Classification response:
# function renaming; guard clause; early return; loop rewrite; while loop; state variable; in-place mutation; frequency counting; input validation; boundary case handling