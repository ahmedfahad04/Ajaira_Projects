def smallest_change(arr):
    from collections import deque
    d = deque(arr)
    changes = 0
    while len(d) > 1:
        if d.popleft() != d.pop():
            changes += 1
    return changes

# Classification response:
# loop rewrite; while loop; helper function extraction; standard library helper; in-place mutation; temporary variable; variable renaming; import reorganization