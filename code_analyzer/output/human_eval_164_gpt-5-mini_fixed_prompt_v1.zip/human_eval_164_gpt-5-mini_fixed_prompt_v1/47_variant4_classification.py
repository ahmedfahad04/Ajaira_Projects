def median(l: list):
    import random
    if not l:
        raise ValueError("median of empty list")
    def kth(a, k):
        # returns k-th smallest (0-indexed)
        if len(a) == 1:
            return a[0]
        pivot = random.choice(a)
        lows = [x for x in a if x < pivot]
        highs = [x for x in a if x > pivot]
        pivots = [x for x in a if x == pivot]
        if k < len(lows):
            return kth(lows, k)
        elif k < len(lows) + len(pivots):
            return pivot
        else:
            return kth(highs, k - len(lows) - len(pivots))
    n = len(l)
    if n % 2 == 1:
        return kth(list(l), n // 2)
    else:
        a = kth(list(l), n // 2 - 1)
        b = kth(list(l), n // 2)
        return (a + b) / 2.0

# Classification response:
# helper function extraction; recursion with base case; divide and conquer; list comprehension; standard library helper; empty input handling; guard clause