import re
def hex_key(num):
    if not num:
        return 0
    return len(re.findall(r'[2357BD]', num))

# Classification response:
# function renaming; helper function extraction; guard clause; regex usage; loop rewrite; literal rewrite; input validation; membership test