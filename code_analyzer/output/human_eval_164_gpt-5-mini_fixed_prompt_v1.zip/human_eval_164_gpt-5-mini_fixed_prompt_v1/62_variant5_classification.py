def derivative(xs: list):
    return [i * v for i, v in zip(range(1, len(xs)), xs[1:])]

# Classification response:
# helper function extraction; zip usage; list comprehension; slicing; variable renaming; type annotation