def is_simple_power(x, n):
    # Recursive division approach
    if x == 1:
        return True
    if n == 1:
        return x == 1
    if n == 0:
        return x == 0
    if x == 0:
        return n == 0
    # If not divisible, can't be a power
    if x % n != 0:
        return False
    return is_simple_power(x // n, n)

# Classification response:
# loop rewrite; recursion with base case; guard clause; boundary case handling