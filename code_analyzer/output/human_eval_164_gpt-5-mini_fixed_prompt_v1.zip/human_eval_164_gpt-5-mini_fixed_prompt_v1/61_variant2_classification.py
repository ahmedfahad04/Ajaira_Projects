def correct_bracketing(brackets: str):
    stack = []
    for ch in brackets:
        if ch == "(":
            stack.append(ch)
        else:
            if not stack:
                return False
            stack.pop()
    return len(stack) == 0

# Classification response:
# function renaming; guard clause; accumulator list; in-place mutation; stack-based