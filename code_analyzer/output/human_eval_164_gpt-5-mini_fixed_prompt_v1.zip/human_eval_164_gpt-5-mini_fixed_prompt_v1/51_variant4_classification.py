def remove_vowels(text):
    vowels = set("aeiouAEIOU")
    def _rec(i):
        if i >= len(text):
            return ""
        if text[i] in vowels:
            return _rec(i+1)
        return text[i] + _rec(i+1)
    return _rec(0)

# Classification response:
# function renaming; helper function extraction; recursion; set conversion; membership test; guard clause; temporary variable; accumulator string