def convert_to_binary(decimal):
    return "db" + str(bin(decimal)[2:]) + "db"

# Classification response:
# function renaming; string formatting change