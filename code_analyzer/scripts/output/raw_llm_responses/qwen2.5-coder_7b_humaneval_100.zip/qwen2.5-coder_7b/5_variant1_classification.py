def intersperse(numbers, delimiter):
    if not numbers:
        return []
    return [item for pair in zip(numbers[:-1], [delimiter] * (len(numbers) - 1)) for item in pair] + [numbers[-1]]

# Classification response:
# list comprehension; zip usage