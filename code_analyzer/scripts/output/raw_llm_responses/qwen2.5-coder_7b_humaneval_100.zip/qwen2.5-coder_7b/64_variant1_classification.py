vowels = "aeiouAEIOU"
n_vowels = sum(c in vowels for c in s)
if s.endswith('y') or s.endswith('Y'):
    n_vowels += 1
return n_vowels

# Classification response:
# regex usage