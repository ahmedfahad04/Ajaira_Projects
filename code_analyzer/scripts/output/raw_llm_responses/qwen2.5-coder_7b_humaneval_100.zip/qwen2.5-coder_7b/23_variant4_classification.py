len([*string])

# Classification response:
# literal rewrite