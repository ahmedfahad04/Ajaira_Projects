ans = len([i for i in range(len(arr) // 2) if arr[i] != arr[-i-1]])
return ans

# Classification response:
# list comprehension