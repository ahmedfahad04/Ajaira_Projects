return sorted(list(set(l)))

# Classification response:
# formatting only