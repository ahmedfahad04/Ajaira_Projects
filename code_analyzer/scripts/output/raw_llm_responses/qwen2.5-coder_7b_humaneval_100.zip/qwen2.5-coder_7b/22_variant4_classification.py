def is_int(value):
    return isinstance(value, int)

return list(filter(is_int, values))

# Classification response:
# function renaming; built-in function