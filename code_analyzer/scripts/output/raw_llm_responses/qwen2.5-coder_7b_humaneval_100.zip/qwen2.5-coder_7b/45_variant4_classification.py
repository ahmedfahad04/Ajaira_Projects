def compute_area(base, height):
    return base * height / 2.0

# Classification response:
# function renaming