def is_symmetric(q, w):
    if sum(q) > w:
        return False
    return all(q[i] == q[-i-1] for i in range(len(q) // 2))

# Classification response:
# function renaming; method renaming; control flow; data structure; algorithmic