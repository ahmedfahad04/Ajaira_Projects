l1 = sum(map(len, lst1))
l2 = sum(map(len, lst2))

if l1 <= l2:
    return lst1
else:
    return lst2

# Classification response:
# builtin function; loop rewrite; data structure conversion