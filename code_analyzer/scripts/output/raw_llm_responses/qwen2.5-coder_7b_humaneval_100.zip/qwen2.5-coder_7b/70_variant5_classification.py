res = []
i = 0
while lst:
    if i % 2 == 0:
        res.append(min(lst))
    else:
        res.append(max(lst))
    lst.remove(res[-1])
    i += 1
return res

# Classification response:
# variable renaming; control flow