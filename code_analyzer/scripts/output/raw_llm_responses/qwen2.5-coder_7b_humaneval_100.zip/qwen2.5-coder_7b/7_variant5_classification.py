def filter_strings(strings, substring):
    return [x for x in strings if x.startswith(substring)]

# Classification response:
# function renaming; list comprehension; method renaming