evens = l[::2]
    odds = l[1::2]
    evens.sort()
    ans = [y for x in zip(evens, odds) for y in x]
    if len(evens) > len(odds):
        ans.append(evens[-1])
    return ans

# Classification response:
# list comprehension