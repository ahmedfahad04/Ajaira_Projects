result = [\'\'.join(segment) for segment in paren_string.split(\'()\') if segment]

# Classification response:
# list comprehension; string formatting change