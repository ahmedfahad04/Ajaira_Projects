sum(1 for _ in iter(string))

# Classification response:
# generator expression