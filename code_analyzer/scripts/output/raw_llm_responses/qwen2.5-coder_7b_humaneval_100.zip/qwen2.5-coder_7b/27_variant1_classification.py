return string.swapcase()

# Classification response:
# string formatting change