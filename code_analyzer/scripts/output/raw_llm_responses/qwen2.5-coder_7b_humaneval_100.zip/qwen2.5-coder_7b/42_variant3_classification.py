return [sum([e, 1]) for e in l]

# Classification response:
# list comprehension; literal rewrite