def filter_strings(strings, substring):
    return [x for x in strings if substring in x and x.count(substring) > 0]

# Classification response:
# function renaming; conditional expression