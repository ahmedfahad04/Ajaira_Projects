def is_balanced(brackets):
    balance = 0
    for char in brackets:
        balance += 1 if char == '(' else -1
        if balance < 0:
            return False
    return balance == 0

# Classification response:
# function renaming; variable renaming; control flow; data structure