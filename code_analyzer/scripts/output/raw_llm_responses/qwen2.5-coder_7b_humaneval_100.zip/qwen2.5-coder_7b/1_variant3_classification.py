result = [segment for segment in paren_string.replace(\'()\', \'\').split(\'(\') if segment and segment[0] == \')\']

# Classification response:
# list comprehension