def is_palindrome(text):
    for i in range(len(text) // 2):
        if text[i] != text[-(i + 1)]:
            return False
    return True

# Classification response:
# method renaming; parameter renaming; loop rewrite; index-based loop