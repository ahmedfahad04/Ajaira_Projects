def contains_zero_sum_pair(l):
    seen = set()
    for num in l:
        if -num in seen:
            return True
        seen.add(num)
    return False

# Classification response:
# two pointer; set conversion; algorithmic: two pointer