return ' '.join(str(x) for x in range(n+1))

# Classification response:
# formatting only