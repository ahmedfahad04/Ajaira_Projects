def find_min_even(arr):
        evens = [x for x in arr if x % 2 == 0]
        return [] if not evens else [min(evens), arr.index(min(evens))]

# Classification response:
# list comprehension; conditional expression; helper function extraction