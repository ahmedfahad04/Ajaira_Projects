def gcd(a, b):
    if a == 0:
        return b
    if b == 0:
        return a
    if a == b:
        return a
    if a % 2 == 0 and b % 2 == 0:
        return 2 * gcd(a // 2, b // 2)
    if a % 2 == 0:
        return gcd(a // 2, b)
    if b % 2 == 0:
        return gcd(a, b // 2)
    if a > b:
        return gcd((a - b) // 2, b)
    return gcd((b - a) // 2, a)

# Classification response:
# recursion;helper function extraction