return ' '.join([f"{x}" for x in range(n + 1)])

# Classification response:
# string formatting change