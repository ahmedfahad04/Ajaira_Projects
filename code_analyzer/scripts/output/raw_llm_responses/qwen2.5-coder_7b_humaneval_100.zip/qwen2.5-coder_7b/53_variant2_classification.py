def calculate_sum(a, b):
    return a + b

# Classification response:
# function renaming