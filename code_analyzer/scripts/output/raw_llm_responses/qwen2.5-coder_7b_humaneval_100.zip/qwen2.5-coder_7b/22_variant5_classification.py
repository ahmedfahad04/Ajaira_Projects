return [x for x in values if isinstance(x, int) and not isinstance(x, bool)]

# Classification response:
# variable renaming; conditional expression