def count_substring(string, substring):
    return sum(string[i:i+len(substring)] == substring for i in range(len(string) - len(substring) + 1))

# Classification response:
# function renaming; list comprehension