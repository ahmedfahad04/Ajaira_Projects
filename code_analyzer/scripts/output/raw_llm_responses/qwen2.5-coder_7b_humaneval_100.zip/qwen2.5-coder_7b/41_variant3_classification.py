def calculate_square(n):
    return pow(n, 2)

# Classification response:
# function renaming; builtin function