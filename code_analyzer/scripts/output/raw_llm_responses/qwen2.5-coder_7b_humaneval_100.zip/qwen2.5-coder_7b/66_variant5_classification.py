def uppercase_counter(s):
    return len(list(filter(str.isupper, s)))

# Classification response:
# function renaming; helper function extraction