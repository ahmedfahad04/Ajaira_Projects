def check_elements(l, t):
    return all(map(lambda x: x < t, l))

# Classification response:
# function renaming; lambda expression; map usage