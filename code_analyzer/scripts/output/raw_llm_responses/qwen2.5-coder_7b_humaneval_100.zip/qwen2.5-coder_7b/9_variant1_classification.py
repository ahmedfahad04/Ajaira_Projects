running_max = float('-inf')
result = []

for n in numbers:
    running_max = max(running_max, n)
    result.append(running_max)

return result

# Classification response:
# literal rewrite; built-in function