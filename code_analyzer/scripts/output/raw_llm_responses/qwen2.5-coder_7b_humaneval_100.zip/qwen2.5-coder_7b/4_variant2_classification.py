total = sum(numbers)
    count = len(numbers)
    mean = total / count
    return sum(abs(x - mean) for x in numbers) / count

# Classification response:
# variable renaming; literal rewrite