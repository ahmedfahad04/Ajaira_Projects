def filter_strings(strings, substring):
    return [x for x in strings if x.find(substring) != -1]

# Classification response:
# function renaming; parameter renaming; built-in function