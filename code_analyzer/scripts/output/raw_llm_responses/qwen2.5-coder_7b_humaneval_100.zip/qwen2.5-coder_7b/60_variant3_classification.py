total = 0
for i in range(n + 1):
    total += i
return total

# Classification response:
# loop rewrite; accumulator variable; in-place mutation