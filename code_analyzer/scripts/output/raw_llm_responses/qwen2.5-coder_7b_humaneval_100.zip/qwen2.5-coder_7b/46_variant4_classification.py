results = [0, 0, 2, 0]
if n < 4:
    return results[n]

for _ in range(n - 3):
    results.append(results[-1] + results[-2] + results[-3] + results[-4])
    results.pop(0)

return results[-1]

# Classification response:
# loop rewrite