total = sum(numbers)
    n = len(numbers)
    mean = total / n
    return sum((x - mean) ** 2 for x in numbers) / n

# Classification response:
# variable renaming; literal rewrite; data structure