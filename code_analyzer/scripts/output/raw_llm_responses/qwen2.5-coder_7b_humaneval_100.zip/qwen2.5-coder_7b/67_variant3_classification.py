def solve(s, n):
    lis = [int(i) for i in s.split(' ') if i.isnumeric()]
    return n - sum(lis)

# Classification response:
# list comprehension; string formatting change; method renaming; function renaming