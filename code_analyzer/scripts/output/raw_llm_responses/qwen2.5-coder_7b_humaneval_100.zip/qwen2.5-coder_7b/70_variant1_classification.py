res = []
for i in range(len(lst)):
    if i % 2 == 0:
        res.append(min(lst))
    else:
        res.append(max(lst))
    lst.remove(res[-1])
return res

# Classification response:
# for loop; conditional expression; index-based loop