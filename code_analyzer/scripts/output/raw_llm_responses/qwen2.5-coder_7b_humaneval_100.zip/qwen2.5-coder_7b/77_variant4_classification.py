a = abs(a)
cbrt = a ** (1. / 3)
if cbrt == int(cbrt):
    return True
return False

# Classification response:
# variable renaming; conditional expression; in-place mutation