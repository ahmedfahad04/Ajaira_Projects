return sum([x, y])

# Classification response:
# builtin function