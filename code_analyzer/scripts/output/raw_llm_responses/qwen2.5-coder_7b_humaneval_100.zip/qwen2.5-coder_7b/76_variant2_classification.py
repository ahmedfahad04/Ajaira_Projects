def is_power_of_n(n, x):
    if n == 1:
        return x == 1
    power = n
    while power < x:
        power <<= 1
    return power == x

# Classification response:
# function renaming; bitwise operation