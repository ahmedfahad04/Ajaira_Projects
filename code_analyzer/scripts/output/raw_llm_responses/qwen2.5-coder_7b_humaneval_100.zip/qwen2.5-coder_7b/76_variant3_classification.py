def is_power_of_n(n, x):
    if n == 1:
        return x == 1
    power = 1
    while power <= x:
        if power == x:
            return True
        power *= n
    return False

# Classification response:
# function renaming; loop rewrite; conditional expression; loop condition change; return statement change