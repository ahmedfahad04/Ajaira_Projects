def prefix_to_suffix(string):
    if not string:
        return ''

    for i in range(len(string) + 1):
        if is_palindrome(string[i:]):
            return string + string[:i][::-1]

    return string

# Classification response:
# loop rewrite; function renaming; control flow