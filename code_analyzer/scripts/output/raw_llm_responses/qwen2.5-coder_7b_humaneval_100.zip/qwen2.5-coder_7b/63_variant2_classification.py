def fibfib(n):
    if n in (0, 1):
        return 0
    if n == 2:
        return 1
    return fibfib(n - 1) + fibfib(n - 2) + fibfib(n - 3)

# Classification response:
# variable renaming