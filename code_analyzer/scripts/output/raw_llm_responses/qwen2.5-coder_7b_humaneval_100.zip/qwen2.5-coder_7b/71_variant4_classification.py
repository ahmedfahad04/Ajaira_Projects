from math import pow

def get_triangle_area(a, b, c):
    if a + b <= c or a + c <= b or b + c <= a:
        return -1 
    s = (a + b + c) / 2    
    area = pow(s * (s - a) * (s - b) * (s - c), 0.5)
    return round(area, 2)

# Classification response:
# import reorganization; function renaming; string formatting change