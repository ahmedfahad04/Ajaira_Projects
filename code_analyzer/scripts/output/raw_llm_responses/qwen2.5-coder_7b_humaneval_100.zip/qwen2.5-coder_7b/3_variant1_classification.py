balance = sum(op for op in operations if op < 0) > 0

# Classification response:
# list comprehension; conditional expression