def has_zero_sum_triplet(l):
    from itertools import combinations
    for triplet in combinations(l, 3):
        if sum(triplet) == 0:
            return True
    return False

# Classification response:
# itertools usage; comprehension; tuple unpacking; built-in function