def has_zero_sum_triplet(l):
    l = set(l)
    for i in l:
        for j in l:
            if -i - j in l:
                return True
    return False

# Classification response:
# set conversion; nested conditional