def encode_twice(s):
    return encode_cyclic(encode_cyclic(s))

# Classification response:
# function renaming