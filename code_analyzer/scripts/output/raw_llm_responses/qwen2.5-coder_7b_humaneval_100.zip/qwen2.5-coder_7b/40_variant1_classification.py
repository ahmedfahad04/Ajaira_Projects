def has_zero_sum_triplet(l):
    l.sort()
    n = len(l)
    for i in range(n):
        j, k = i + 1, n - 1
        while j < k:
            s = l[i] + l[j] + l[k]
            if s == 0:
                return True
            elif s < 0:
                j += 1
            else:
                k -= 1
    return False

# Classification response:
# sort key; two pointer