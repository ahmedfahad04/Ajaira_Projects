ret = 1
for i in range(n):
    ret = (ret * 2) % p
    ret = (ret * 2) % p
return ret

# Classification response:
# index-based loop; repetition