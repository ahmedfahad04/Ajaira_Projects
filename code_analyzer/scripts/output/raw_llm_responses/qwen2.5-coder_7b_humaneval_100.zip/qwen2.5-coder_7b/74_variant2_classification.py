total_length = lambda l: sum(len(st) for st in l)
if total_length(lst1) <= total_length(lst2):
    return lst1
else:
    return lst2

# Classification response:
# lambda expression; list comprehension