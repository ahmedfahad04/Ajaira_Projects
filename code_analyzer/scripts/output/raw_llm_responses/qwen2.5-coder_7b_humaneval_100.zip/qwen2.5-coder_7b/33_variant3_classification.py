l = [x for _, x in sorted(enumerate(l), key=lambda x: (x[0] % 3, x[1]))]
return l

# Classification response:
# list comprehension; generator expression; sorting; key function