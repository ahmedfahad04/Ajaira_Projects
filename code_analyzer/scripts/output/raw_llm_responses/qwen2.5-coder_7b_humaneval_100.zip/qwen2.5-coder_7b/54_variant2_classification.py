def are_sets_equal(s0, s1):
    return len(s0) == len(s1) and all(item in s1 for item in s0) and all(item in s0 for item in s1)

# Classification response:
# function renaming; data structure; algorithmic; robustness