seen = set()
    for l1 in l:
        if -l1 in seen:
            return True
        seen.add(l1)
    return False

# Classification response:
# accumulator set; set conversion; in-place mutation