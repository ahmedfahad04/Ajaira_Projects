def is_symmetric(q, w):
    if sum(q) > w:
        return False
    n = len(q)
    for i in range(n // 2):
        if q[i] != q[n - i - 1]:
            return False
    return True

# Classification response:
# function renaming; loop rewrite