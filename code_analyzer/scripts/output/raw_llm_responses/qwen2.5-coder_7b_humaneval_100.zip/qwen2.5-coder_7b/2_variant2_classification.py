return number - int(number)

# Classification response:
# method renaming; arithmetic operation