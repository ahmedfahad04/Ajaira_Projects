balance = all(op >= 0 for op in operations) == False

# Classification response:
# variable renaming; accumulator list; conditional expression