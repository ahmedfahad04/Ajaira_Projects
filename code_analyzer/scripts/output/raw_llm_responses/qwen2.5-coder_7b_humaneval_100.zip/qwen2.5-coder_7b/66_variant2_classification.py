def uppercase_count(s):
    return len([char for char in s if char.isupper()])

# Classification response:
# function renaming; list comprehension; data structure conversion