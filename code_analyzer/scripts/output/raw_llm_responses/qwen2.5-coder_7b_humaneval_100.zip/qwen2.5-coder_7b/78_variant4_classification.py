primes = {'2', '3', '5', '7', 'B', 'D'}
total = len([digit for digit in num if digit in primes])
return total

# Classification response:
# list comprehension; set conversion; variable renaming