return [x * (i + 1) for i, x in enumerate(xs)][1:]

# Classification response:
# variable renaming