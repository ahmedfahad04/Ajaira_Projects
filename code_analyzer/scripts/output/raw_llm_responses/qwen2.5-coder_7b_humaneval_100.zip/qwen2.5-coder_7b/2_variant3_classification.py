return number - number // 1

# Classification response:
# mathematical formula