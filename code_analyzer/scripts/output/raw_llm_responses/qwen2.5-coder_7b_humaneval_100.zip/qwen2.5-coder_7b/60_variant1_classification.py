return sum([i for i in range(n + 1)])

# Classification response:
# list comprehension