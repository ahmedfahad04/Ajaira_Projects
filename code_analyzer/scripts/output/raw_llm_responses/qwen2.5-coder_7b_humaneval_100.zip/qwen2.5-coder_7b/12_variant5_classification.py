if not strings:
    return None

maxlen = max(len(x) for x in strings)
return [s for s in strings if len(s) == maxlen][0]

# Classification response:
# list comprehension