sum_value = reduce(lambda x, y: x + y, numbers, 0)
prod_value = reduce(lambda x, y: x * y, numbers, 1)
return sum_value, prod_value

# Classification response:
# reduce; lambda expression