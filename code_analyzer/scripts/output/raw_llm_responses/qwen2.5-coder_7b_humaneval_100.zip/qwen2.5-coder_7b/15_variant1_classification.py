return ' '.join(map(str, range(n + 1)))

# Classification response:
# map usage