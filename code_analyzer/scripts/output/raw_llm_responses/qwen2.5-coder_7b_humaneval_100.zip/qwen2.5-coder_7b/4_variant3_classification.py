avg = sum(numbers) / len(numbers)
    return sum((x - avg) ** 2 for x in numbers) / len(numbers)

# Classification response:
# variable renaming; mathematical formula; algorithmic