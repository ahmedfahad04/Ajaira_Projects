def rescale_numbers(numbers):
    min_val = min(numbers)
    max_val = max(numbers)
    return [(x - min_val) / (max_val - min_val) for x in numbers]

# Classification response:
# function renaming