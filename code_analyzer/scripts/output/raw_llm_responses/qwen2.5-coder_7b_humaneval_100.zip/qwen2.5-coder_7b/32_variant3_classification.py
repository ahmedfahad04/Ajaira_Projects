begin, end = -1., 1.
while poly(xs, begin) * poly(xs, end) > 0:
    begin *= 1.5
    end *= 1.5
while end - begin > 1e-10:
    center = (begin + end) / 2.0
    if poly(xs, center) * poly(xs, begin) > 0:
        begin = center
    else:
        end = center
return begin

# Classification response:
# constant renaming; loop rewrite