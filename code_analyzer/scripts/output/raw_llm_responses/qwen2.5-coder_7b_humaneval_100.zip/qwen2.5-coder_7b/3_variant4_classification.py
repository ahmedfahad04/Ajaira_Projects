balance = not all(op >= 0 for op in operations)

# Classification response:
# list comprehension; algorithmic transformation; sliding window