def convert_to_binary(decimal):
    return "db" + "{:b}".format(decimal) + "db"

# Classification response:
# function renaming; string formatting change