res = []
switch = True
while lst:
    if switch:
        res.append(min(lst))
    else:
        res.append(max(lst))
    lst.remove(res[-1])
    switch = not switch
return res

# Classification response:
# control flow; variable renaming; formatting only