def is_palindrome(text):
    return text == text[::-1]

# Classification response:
# string formatting change; algorithmic: two pointer