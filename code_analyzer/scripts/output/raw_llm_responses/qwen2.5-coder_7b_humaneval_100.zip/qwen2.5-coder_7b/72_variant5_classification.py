def check_palindrome(q, w):
    if sum(q) > w:
        return False

    for i in range(len(q)//2):
        if q[i] != q[-(i+1)]:
            return False
    return True

# Classification response:
# function renaming; loop rewrite