def check_elements(l, t):
    return not any(e >= t for e in l)

# Classification response:
# function renaming; built-in function; comprehension