def is_balanced(brackets):
    stack = []
    for char in brackets:
        if char == '(':
            stack.append(char)
        else:
            if not stack:
                return False
            stack.pop()
    return not stack

# Classification response:
# method renaming; stack-based