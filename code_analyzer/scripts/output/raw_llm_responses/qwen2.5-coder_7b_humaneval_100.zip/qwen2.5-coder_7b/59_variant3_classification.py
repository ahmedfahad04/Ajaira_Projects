def is_prime(k):
    if k < 2:
        return False
    for i in range(2, k - 1, 2):
        if k % i == 0:
            return False
    return True

largest = 1
for j in range(2, n + 1):
    if n % j == 0 and is_prime(j):
        largest = max(largest, j)
return largest

# Classification response:
# variable renaming