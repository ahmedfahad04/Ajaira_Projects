def find_smallest_divisor(n):
    return next(i for i in range(1, n + 1) if n % i == 0)

# Classification response:
# function renaming; generator expression