def smallest_divisor(n):
    return min(i for i in range(1, n + 1) if n % i == 0)

# Classification response:
# list comprehension; helper function extraction; functional programming