def intersperse(numbers, delimiter):
    return [n for n in numbers] if not numbers else [numbers[0]] + [delimiter] + intersperse(numbers[1:], delimiter)

# Classification response:
# recursive function; list comprehension; accumulator list