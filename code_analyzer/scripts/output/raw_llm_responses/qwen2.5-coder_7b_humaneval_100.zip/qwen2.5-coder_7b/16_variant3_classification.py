return len(set(string.lower().translate(str.maketrans('', '', string.punctuation))))

# Classification response:
# string formatting change; set conversion