def filter_strings(strings, prefix):
    return [s for s in strings if s.startswith(prefix)]

# Classification response:
# function renaming; variable renaming