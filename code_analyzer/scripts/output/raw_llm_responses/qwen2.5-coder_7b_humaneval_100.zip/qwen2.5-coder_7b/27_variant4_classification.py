return string.upper().swapcase()

# Classification response:
# string formatting change