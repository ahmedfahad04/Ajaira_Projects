result = [string[:i+1] for i in range(len(string))]
return result

# Classification response:
# list comprehension