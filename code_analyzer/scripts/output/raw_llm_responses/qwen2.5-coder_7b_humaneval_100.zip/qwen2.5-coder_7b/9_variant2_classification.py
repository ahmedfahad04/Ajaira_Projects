result = []

for i in range(len(numbers)):
    result.append(max(numbers[:i+1]))

return result

# Classification response:
# index-based loop; slicing