sum_value = sum(numbers)
prod_value = 1
for n in numbers:
    prod_value *= n
return sum_value, prod_value

# Classification response:
# builtin function; in-place mutation