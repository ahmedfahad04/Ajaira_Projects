visited = set()
    for elem in numbers:
        for num in numbers:
            if num not in visited and abs(elem - num) < threshold:
                return True
        visited.add(elem)

    return False

# Classification response:
# set conversion; tuple unpacking; in-place mutation