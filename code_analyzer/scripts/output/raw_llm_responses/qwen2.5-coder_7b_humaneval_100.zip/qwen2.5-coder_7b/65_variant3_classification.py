s = str(x)
    shift %= len(s)
    return s[len(s) - shift:] + s[:len(s) - shift]

# Classification response:
# parameter renaming; conditional expression