return number.__mod__(1.0)

# Classification response:
# builtin function