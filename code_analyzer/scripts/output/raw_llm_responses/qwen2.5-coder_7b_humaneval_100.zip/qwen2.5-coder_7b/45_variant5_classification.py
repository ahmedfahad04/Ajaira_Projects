def calc_area(b, h):
    return b * h / 2.0

# Classification response:
# function renaming