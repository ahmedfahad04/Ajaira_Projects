def smallest_div(n):
    return next(i for i in range(2, n) if n % i == 0, 1)

# Classification response:
# function renaming; list comprehension; default value handling