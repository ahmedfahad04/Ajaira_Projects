def convert_to_binary(decimal):
    binary = ""
    while decimal > 0:
        binary = str(decimal % 2) + binary
        decimal //= 2
    return "db" + binary + "db"

# Classification response:
# function renaming; control flow; data structure; algorithmic