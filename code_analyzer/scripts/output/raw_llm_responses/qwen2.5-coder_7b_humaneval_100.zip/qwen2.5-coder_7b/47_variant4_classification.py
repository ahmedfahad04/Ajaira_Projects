l.sort()
    return (l[len(l) // 2] + l[len(l) // 2 - 1]) / 2.0 if len(l) % 2 == 0 else l[len(l) // 2]

# Classification response:
# list conversion; sort key