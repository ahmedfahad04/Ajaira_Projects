return list(filter(lambda x: x > 0, l))

# Classification response:
# builtin function; lambda expression