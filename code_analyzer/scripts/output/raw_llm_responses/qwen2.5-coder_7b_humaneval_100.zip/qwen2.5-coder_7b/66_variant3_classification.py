def num_upper(s):
    return sum(1 if char.isupper() else 0 for char in s)

# Classification response:
# function renaming; method renaming