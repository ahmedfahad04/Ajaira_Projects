ns = [i for i in range(n) if not (i % 11 and i % 13)]
s = ''.join(map(str, ns))
ans = sum(c == '7' for c in s)

# Classification response:
# list comprehension; generator expression; sum function