if n < 4:
    return [0, 0, 2, 0][n]

results = [0, 0, 2, 0]
for _ in range(4, n + 1):
    results.append(results[-1] + results[-2] + results[-3] + results[-4])
    results.pop(0)

return results[-1]

# Classification response:
# variable renaming