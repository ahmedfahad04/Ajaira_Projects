l.sort(key=lambda x: (x % 3, x % 10))
return l

# Classification response:
# sort key