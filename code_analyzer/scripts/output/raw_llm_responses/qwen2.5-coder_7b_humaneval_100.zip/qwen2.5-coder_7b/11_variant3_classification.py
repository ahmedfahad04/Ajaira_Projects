def xor(i, j):
    return '1' if (i == '1' and j == '0') or (i == '0' and j == '1') else '0'

return ''.join(xor(x, y) for x, y in zip(a, b))

# Classification response:
# string formatting change