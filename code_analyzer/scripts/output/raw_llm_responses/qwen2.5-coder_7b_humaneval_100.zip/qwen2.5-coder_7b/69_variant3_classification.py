frq = defaultdict(int)
for i in lst:
    frq[i] += 1

ans = -1
for i in range(1, len(frq) + 1):
    if frq[i] >= i:
        ans = i
return ans

# Classification response:
# defaultdict usage; in-place mutation