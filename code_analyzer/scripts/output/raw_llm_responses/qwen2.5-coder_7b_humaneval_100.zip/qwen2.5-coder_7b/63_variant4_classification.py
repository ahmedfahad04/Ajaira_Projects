def fibfib(n):
    fibfib_vals = [0, 0, 1]
    for i in range(3, n + 1):
        fibfib_vals.append(fibfib_vals[i - 1] + fibfib_vals[i - 2] + fibfib_vals[i - 3])
    return fibfib_vals[n]

# Classification response:
# variable renaming; loop rewrite; accumulator list