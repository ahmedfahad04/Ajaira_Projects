def find_min_even(arr):
        return [min(x for x in arr if x % 2 == 0), arr.index(min(x for x in arr if x % 2 == 0))]

# Classification response:
# function renaming; algorithmic