for e in l:
    if e >= t:
        return False
return True

# Classification response:
# formatting only