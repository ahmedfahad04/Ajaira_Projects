primes = {'2', '3', '5', '7', 'B', 'D'}
total = sum(map(lambda x: 1 if x in primes else 0, num))
return total

# Classification response:
# set conversion; map/filter usage; lambda expression