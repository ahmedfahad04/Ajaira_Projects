from sympy import isprime

def is_prime(n):
    return isprime(n)

# Classification response:
# builtin function; function renaming; class renaming