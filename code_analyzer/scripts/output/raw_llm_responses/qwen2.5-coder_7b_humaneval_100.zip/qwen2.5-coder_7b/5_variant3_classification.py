def intersperse(numbers, delimiter):
    return numbers if not numbers else [numbers.pop(0)] + [delimiter] + intersperse(numbers, delimiter)

# Classification response:
# recursion; helper function extraction