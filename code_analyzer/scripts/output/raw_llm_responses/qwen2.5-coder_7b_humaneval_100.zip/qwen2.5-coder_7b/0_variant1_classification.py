for idx in range(len(numbers)):
        for idx2 in range(idx + 1, len(numbers)):
            distance = abs(numbers[idx] - numbers[idx2])
            if distance < threshold:
                return True

    return False

# Classification response:
# index-based loop; nested conditional; flattened conditional