result = [max(numbers[:i+1]) for i in range(len(numbers))]

return result

# Classification response:
# list comprehension; algorithmic: sliding window