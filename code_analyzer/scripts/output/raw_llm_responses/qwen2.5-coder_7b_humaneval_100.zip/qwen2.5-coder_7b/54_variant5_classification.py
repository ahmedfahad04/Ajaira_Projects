def are_sets_equal(s0, s1):
    return not (s0 - s1) and not (s1 - s0)

# Classification response:
# function renaming; set conversion; set difference; logical negation