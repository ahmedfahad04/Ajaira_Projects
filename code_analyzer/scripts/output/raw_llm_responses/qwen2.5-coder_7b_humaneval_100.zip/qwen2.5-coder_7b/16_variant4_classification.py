return len(set(string.lower().split()))

# Classification response:
# string formatting change; set conversion