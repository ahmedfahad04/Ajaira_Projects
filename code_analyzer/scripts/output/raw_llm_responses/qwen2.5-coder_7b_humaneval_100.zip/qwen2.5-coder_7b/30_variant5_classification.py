def positive_elements(lst):
    return [e for e in lst if e > 0]

return positive_elements(l)

# Classification response:
# function renaming; variable renaming