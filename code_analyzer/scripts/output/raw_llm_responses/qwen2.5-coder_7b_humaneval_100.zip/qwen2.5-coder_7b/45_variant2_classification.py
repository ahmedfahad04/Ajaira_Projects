from math import pi

def calculate_area(a, h):
    return a * h / 2.0

# Classification response:
# function renaming; import reorganization