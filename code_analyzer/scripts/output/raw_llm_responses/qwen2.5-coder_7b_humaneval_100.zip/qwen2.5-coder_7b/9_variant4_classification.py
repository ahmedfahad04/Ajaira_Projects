result = []

for n in numbers:
    result.append(n if result == [] else max(n, result[-1]))

return result

# Classification response:
# list comprehension; conditional expression