primes = {'2', '3', '5', '7', 'B', 'D'}
total = sum(1 for digit in num if digit in primes)
return total

# Classification response:
# data structure; set conversion; list comprehension