letter_grade = [grade_map[gpa] for gpa in grades]
grade_map = {
    4.0: "A+",
    (3.8, 4.0): "A",
    (3.4, 3.8): "A-",
    (3.1, 3.4): "B+",
    (2.8, 3.1): "B",
    (2.4, 2.8): "B-",
    (2.1, 2.4): "C+",
    (1.8, 2.1): "C",
    (1.4, 1.8): "C-",
    (1.1, 1.4): "D+",
    (0.8, 1.1): "D",
    (0.0, 0.8): "D-",
    -1: "E"
}

# Classification response:
# list comprehension; dictionary lookup