def get_median(l):
        l.sort()
        n = len(l)
        if n % 2 == 1:
            return l[n // 2]
        else:
            return (l[n // 2 - 1] + l[n // 2]) / 2.0

# Classification response:
# function renaming; parameter renaming