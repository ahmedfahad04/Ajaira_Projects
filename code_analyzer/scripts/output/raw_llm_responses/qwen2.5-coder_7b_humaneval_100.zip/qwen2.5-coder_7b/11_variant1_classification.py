def xor(i, j):
    return str(int(i) ^ int(j))

return ''.join(xor(x, y) for x, y in zip(a, b))

# Classification response:
# literal rewrite; regex usage