def rotate_left(s, n):
    return s[n:] + s[:n]

return rotate_left(s, 5)

# Classification response:
# string formatting change; function renaming