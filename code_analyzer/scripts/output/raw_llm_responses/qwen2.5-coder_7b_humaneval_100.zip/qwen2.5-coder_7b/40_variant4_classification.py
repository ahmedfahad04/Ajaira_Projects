def has_zero_sum_triplet(l):
    l = list(l)
    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            for k in range(j + 1, len(l)):
                if l[i] + l[j] + l[k] == 0:
                    return True
    return False

# Classification response:
# method renaming