return number.__rmod__(1.0)

# Classification response:
# builtin function