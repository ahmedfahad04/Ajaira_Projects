if len(s) < 3:
    return False

for i in range(len(s) - 1):
    if s[i] == s[i + 1]:
        return False
return True

# Classification response:
# loop rewrite