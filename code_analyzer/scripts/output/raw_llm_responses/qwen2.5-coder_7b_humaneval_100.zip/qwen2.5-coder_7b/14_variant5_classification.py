result = [string[:i+1] for i in range(len(string)) if i % 2 == 0]
return result

# Classification response:
# list comprehension; conditional expression