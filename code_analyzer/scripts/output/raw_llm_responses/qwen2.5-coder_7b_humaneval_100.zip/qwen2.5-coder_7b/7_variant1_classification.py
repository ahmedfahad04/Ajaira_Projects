def filter_strings(strings, substring):
    return list(filter(lambda x: substring in x, strings))

# Classification response:
# function renaming; lambda expression; built-in function