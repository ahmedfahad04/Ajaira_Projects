sum_value = sum(numbers)
prod_value = reduce((lambda x, y: x * y), numbers)
return sum_value, prod_value

# Classification response:
# builtin function; functools reduce