min_diff = float('inf')
closest_pair = None

for i, num1 in enumerate(numbers):
    for j, num2 in enumerate(numbers):
        if i != j:
            diff = abs(num1 - num2)
            if diff < min_diff:
                min_diff = diff
                closest_pair = tuple(sorted([num1, num2]))

return closest_pair

# Classification response:
# variable renaming; loop rewrite; accumulator variable; formatting only