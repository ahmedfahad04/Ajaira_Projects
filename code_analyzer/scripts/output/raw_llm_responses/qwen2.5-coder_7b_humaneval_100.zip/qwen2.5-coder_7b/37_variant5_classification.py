evens = sorted(l[::2])
    odds = l[1::2]
    ans = [x for y in zip(evens, odds) for x in y]
    if len(evens) > len(odds):
        ans.append(evens[-1])
    return ans

# Classification response:
# list comprehension;sort key