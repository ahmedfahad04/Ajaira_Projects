ret = sorted(list({e for e1 in l1 for e2 in l2 if e1 == e2}))
return ret

# Classification response:
# set comprehension; tuple unpacking; list conversion; sorting