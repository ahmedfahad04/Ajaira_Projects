l1 = [x for x in l if x >= 0]
    l2 = [-x for x in l if x < 0]
    for x in l1:
        if -x in l2:
            return True
    return False

# Classification response:
# list comprehension; list conversion; set conversion; membership test