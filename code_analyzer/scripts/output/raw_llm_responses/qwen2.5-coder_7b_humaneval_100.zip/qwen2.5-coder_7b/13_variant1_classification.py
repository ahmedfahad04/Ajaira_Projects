def gcd(a, b):
    while b:
        a, b = b, a - (a // b) * b
    return a

# Classification response:
# variable renaming; algorithmic transformation