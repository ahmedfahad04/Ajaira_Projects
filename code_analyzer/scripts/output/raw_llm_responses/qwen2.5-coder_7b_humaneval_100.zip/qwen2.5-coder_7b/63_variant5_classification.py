def fibfib(n):
    a, b, c = 0, 0, 1
    for _ in range(n):
        a, b, c = b, c, a + b + c
    return a

# Classification response:
# method renaming; loop rewrite; state variable; tuple unpacking; in-place mutation