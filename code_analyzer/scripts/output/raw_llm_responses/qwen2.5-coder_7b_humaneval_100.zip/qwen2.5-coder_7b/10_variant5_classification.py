def add_reversed_prefix_to_palindrome(string):
    if not string:
        return ''

    for i in range(len(string)):
        if string[i:] == string[i:][::-1]:
            return string + string[:i][::-1]

    return string

# Classification response:
# function renaming; loop rewrite; conditional expression