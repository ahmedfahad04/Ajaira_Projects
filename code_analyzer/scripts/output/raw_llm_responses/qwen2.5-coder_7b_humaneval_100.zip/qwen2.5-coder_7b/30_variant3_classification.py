result = []
for e in l:
    if e > 0:
        result.append(e)
return result

# Classification response:
# list comprehension; for loop; accumulator list