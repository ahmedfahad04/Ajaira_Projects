def is_sorted(l):
    return l == sorted(l) or l == sorted(l)[::-1]

# Classification response:
# function renaming; control flow