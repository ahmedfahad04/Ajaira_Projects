res = []
for value in lst:
    if value in lst:
        if lst.index(value) % 2 == 0:
            res.append(min(lst))
        else:
            res.append(max(lst))
        lst.remove(value)
return res

# Classification response:
# for loop; conditional expression; list comprehension; in-place mutation