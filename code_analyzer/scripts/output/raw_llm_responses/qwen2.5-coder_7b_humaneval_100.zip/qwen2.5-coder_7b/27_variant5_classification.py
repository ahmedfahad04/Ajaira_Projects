return ''.join([char.swapcase() if char.isalpha() else char for char in string])

# Classification response:
# list comprehension; conditional expression