if not strings:
    return None

maxlen = max(len(x) for x in strings)
for s in reversed(strings):
    if len(s) == maxlen:
        return s

# Classification response:
# reversed condition