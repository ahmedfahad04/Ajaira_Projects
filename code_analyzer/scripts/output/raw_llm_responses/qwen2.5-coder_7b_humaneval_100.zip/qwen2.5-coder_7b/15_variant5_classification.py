return ' '.join(str(i) for i in range(n + 1))

# Classification response:
# string formatting change