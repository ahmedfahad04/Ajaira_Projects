a = abs(a)
return round(a ** (1. / 3)) ** 3 == a

# Classification response:
# literal rewrite; formatting only