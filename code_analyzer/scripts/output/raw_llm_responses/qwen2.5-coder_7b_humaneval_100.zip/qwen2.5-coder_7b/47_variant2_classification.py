from statistics import median

    def find_median(l):
        return median(l)

# Classification response:
# builtin function; algorithmic