return (n * (n + 1)) // 2

# Classification response:
# mathematical formula; algorithmic