return float(number) % 1.0

# Classification response:
# type conversion