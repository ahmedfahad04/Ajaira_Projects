def intersect(l1, l2):
    return sorted([x for x in set(l1) if x in l2])

# Classification response:
# list comprehension; set conversion; sorted function; list to set conversion