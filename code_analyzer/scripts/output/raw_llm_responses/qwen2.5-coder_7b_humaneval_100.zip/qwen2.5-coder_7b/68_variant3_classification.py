def find_min_even(arr):
        evens = list(filter(lambda x: x % 2 == 0, arr))
        return [min(evens), arr.index(min(evens))] if evens else []

# Classification response:
# function renaming; helper function extraction