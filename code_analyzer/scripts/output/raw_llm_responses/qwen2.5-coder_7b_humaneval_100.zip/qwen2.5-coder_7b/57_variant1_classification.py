def is_sorted(l):
    return all(l[i] <= l[i + 1] for i in range(len(l) - 1)) or all(l[i] >= l[i + 1] for i in range(len(l) - 1))

# Classification response:
# for loop; list comprehension; algorithmic approach