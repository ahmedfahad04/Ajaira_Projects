def remove_vowels(text):
    return "".join([c for c in text if c not in "aeiouAEIOU"])

# Classification response:
# function renaming; string formatting change