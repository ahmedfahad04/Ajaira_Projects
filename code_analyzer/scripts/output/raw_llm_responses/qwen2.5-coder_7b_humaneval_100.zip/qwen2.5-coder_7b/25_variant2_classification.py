def prime_factors(n):
    factors = []
    divisor = 2
    while n >= divisor * divisor:
        if n % divisor:
            divisor += 1
        else:
            n //= divisor
            factors.append(divisor)
    if n > 1:
        factors.append(n)
    return factors

# Classification response:
# function renaming; loop rewrite; variable renaming