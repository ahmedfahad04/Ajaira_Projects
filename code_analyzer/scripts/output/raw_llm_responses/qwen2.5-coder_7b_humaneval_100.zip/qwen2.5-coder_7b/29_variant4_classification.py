def filter_strings(strings, prefix):
    return [x for x in strings if x[:len(prefix)] == prefix]

# Classification response:
# function renaming; parameter renaming