def is_prime(n):
    return n > 1 and all(n % i != 0 for i in range(2, int(n**0.5) + 1))

for i in range(2, 101):
    if not is_prime(i):
        continue
    for j in range(2, 101):
        if not is_prime(j):
            continue
        for k in range(2, 101):
            if not is_prime(k):
                continue
            if i * j * k == a:
                return True
return False

# Classification response:
# variable renaming; early return; loop rewrite