balance = any(op < 0 for op in operations) if any(op < 0 for op in operations) else False

# Classification response:
# conditional expression