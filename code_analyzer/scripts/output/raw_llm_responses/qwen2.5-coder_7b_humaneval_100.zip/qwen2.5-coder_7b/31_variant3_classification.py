def is_prime(n):
    if n < 2:
        return False
    return all(n % k != 0 for k in range(2, int(n**0.5) + 1))

# Classification response:
# function renaming; loop rewrite; conditional expression; algorithmic