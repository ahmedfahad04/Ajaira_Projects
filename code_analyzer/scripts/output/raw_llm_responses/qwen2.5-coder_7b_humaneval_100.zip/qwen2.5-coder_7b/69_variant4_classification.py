frq = [0] * (max(lst) + 1)
for i in lst:
    frq[i] += 1

ans = -1
for i in range(len(frq) - 1, 0, -1):
    if frq[i] >= i:
        ans = i
return ans

# Classification response:
# reversed condition