return len(set(string.lower().strip()))

# Classification response:
# string formatting change; set conversion