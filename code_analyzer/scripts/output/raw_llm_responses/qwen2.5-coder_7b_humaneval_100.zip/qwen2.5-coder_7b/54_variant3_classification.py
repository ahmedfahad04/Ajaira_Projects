def are_sets_equal(s0, s1):
    return len(set(s0)) == len(set(s1)) and set(s0).issubset(set(s1)) and set(s1).issubset(set(s0))

# Classification response:
# function renaming; method renaming; data structure; set conversion; set comparison