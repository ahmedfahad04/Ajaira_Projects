return list(map(lambda e: e + 1, l))

# Classification response:
# list comprehension; map/filter usage; lambda expression