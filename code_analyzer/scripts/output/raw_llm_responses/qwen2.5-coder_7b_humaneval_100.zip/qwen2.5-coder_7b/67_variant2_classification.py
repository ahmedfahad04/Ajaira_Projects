def solve(s, n):
    lis = list(filter(str.isdigit, s.split(' ')))
    lis = [int(i) for i in lis]
    return n - sum(lis)

# Classification response:
# list comprehension;filter usage;int conversion;sum