results = [0, 0, 2, 0]
if n < 4:
    return results[n]

for _ in range(4, n + 1):
    results.append(results[-1] + results[-2] + results[-3] + results[-4])
    results = results[1:]

return results[-1]

# Classification response:
# index-based loop