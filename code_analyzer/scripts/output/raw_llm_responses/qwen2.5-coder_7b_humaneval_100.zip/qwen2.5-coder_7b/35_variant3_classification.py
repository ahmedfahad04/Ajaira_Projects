m = float('-inf')
for e in l:
    if e > m:
        m = e
return m

# Classification response:
# constant renaming; literal rewrite