def find_min_even(arr):
        evens = [x for x in arr if x % 2 == 0]
        if not evens:
            return []
        min_even = min(evens)
        index = arr.index(min_even)
        return [min_even, index]

# Classification response:
# list comprehension; function renaming; method renaming