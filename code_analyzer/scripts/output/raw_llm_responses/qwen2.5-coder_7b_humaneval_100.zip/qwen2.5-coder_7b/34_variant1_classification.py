return list(dict.fromkeys(sorted(l)))

# Classification response:
# set conversion; dict comprehension