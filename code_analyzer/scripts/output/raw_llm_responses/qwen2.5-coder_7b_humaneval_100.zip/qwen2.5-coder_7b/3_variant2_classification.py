balance = any(op < 0 for op in operations)

# Classification response:
# any usage