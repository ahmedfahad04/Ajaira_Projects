results = [0, 0, 2, 0]
if n < 4:
    return results[n]

for _ in range(4, n + 1):
    results.append(sum(results[-4:]))
    results.pop(0)

return results[-1]

# Classification response:
# loop rewrite; accumulator list; sum usage