def calculate_square(n):
    return n ** 2

# Classification response:
# function renaming