def append_prefix_reverse(string):
    if not string:
        return ''

    for i in range(len(string)):
        if is_palindrome(string[i:]):
            return string + string[:i][::-1]

    return string

# Classification response:
# function renaming; loop rewrite; string slicing; conditional expression; reverse condition; in-place mutation