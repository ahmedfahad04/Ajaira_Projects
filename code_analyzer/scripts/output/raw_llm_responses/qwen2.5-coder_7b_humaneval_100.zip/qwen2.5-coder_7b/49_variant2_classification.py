ret = 1
for i in range(n):
    ret = ((ret << 1) + 1) % p
return ret

# Classification response:
# bitwise operation;loop rewrite