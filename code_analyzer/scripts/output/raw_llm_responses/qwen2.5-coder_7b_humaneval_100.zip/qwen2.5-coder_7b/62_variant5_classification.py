return [x * i for i, x in enumerate(xs)][1:]

# Classification response:
# list comprehension;index-based loop