def concatenate_strings(strings):
    result = ''
    for string in strings:
        result += string
    return result

# Classification response:
# function renaming; loop rewrite; formatting only