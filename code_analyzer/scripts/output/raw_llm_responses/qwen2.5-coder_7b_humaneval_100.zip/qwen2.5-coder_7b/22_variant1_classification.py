return list(filter(lambda x: isinstance(x, int), values))

# Classification response:
# builtin function; lambda expression