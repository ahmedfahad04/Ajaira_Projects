def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)

# Classification response:
# recursion; helper function extraction