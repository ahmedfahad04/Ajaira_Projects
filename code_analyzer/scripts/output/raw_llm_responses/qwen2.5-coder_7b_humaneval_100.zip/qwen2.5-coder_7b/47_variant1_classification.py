def median(l):
        l.sort()
        mid = len(l) // 2
        return l[mid] if len(l) % 2 == 1 else (l[mid - 1] + l[mid]) / 2

# Classification response:
# function renaming; naming; control flow; algorithmic