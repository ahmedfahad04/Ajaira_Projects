for idx in range(len(numbers)):
        for idx2 in range(idx + 1, len(numbers)):
            if abs(numbers[idx] - numbers[idx2]) < threshold:
                return True

    return False

# Classification response:
# index-based loop; nested conditional