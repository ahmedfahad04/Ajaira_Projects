return [e.__add__(1) for e in l]

# Classification response:
# builtin function