if not strings:
    return None

maxlen = max(len(x) for x in strings)
return next(s for s in strings if len(s) == maxlen)

# Classification response:
# early return; generator expression