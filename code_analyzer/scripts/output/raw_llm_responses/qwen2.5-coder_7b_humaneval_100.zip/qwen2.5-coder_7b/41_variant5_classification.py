def calculate_square(n):
    return n * n

# Classification response:
# function renaming