def convert_to_base(x, base):
    return "".join(map(str, reversed([x % base] + [convert_to_base(x // base, base)] if x > 0 else [])))

# Classification response:
# recursive function; lambda expression