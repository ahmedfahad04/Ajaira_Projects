value_map = {
    'zero': 0,
    'one': 1,
    'two': 2,
    'three': 3,
    'four': 4,
    'five': 5,
    'six': 6,
    'seven': 7,
    'eight': 8,
    'nine': 9
}
return ' '.join(sorted(numbers.split(' '), key=lambda x: value_map[x] if x in value_map else 10))

# Classification response:
# default value handling