string.__len__()

# Classification response:
# builtin function