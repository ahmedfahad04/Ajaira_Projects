for i in range(len(l)):
        for j in range(i + 1, len(l)):
            if l[i] + l[j] == 0:
                return True
            if abs(l[i] + l[j]) < 1e-9:  # Handling floating-point precision
                return True
    return False

# Classification response:
# index-based loop; floating-point precision handling