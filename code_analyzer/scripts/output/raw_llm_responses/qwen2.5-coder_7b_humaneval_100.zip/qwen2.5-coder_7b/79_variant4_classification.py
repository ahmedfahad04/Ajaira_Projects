def convert_to_binary(decimal):
    return "db" + "".join(format(decimal, "b")) + "db"

# Classification response:
# function renaming; string formatting change