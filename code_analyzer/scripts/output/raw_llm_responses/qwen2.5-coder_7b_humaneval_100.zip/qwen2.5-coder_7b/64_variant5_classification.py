vowels = "aeiouAEIOU"
n_vowels = sum(c in vowels for c in s)
if s[-1].lower() == 'y':
    n_vowels += 1
return n_vowels

# Classification response:
# string formatting change;regex usage