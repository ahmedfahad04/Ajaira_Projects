return [x * i for i, x in enumerate(xs, start=1)][1:]

# Classification response:
# list comprehension; parameter renaming