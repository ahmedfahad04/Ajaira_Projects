def remove_vowels(text):
    return "".join(filter(lambda x: x.lower() not in "aeiou", text))

# Classification response:
# function renaming; list comprehension; lambda expression