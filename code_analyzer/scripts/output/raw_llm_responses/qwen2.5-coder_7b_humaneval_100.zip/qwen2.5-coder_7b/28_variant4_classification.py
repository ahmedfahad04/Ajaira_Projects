def concatenate_strings(strings):
    result = ''
    i = 0
    while i < len(strings):
        result += strings[i]
        i += 1
    return result

# Classification response:
# function renaming; loop rewrite; index-based loop