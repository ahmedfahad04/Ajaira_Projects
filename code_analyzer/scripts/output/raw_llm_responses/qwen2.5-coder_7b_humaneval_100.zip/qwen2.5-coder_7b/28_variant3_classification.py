def concatenate_strings(strings):
    return ''.join(map(str, strings))

# Classification response:
# function renaming; map/filter usage; type conversion