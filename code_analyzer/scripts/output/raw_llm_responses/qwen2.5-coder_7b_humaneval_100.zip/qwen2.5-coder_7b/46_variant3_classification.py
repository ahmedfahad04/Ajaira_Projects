results = [0, 0, 2, 0]
if n < 4:
    return results[n]

results += [results[-1] + results[-2] + results[-3] + results[-4] for _ in range(4, n + 1)]
return results[n]

# Classification response:
# list comprehension