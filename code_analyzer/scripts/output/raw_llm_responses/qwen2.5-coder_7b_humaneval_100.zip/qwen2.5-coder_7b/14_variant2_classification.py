result = []
for i in range(len(string)):
    result += [string[:i+1]]
return result

# Classification response:
# list comprehension