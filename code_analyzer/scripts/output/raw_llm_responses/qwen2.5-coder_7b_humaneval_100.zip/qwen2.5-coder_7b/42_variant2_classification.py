new_list = []
for e in l:
    new_list.append(e + 1)
return new_list

# Classification response:
# list comprehension; for loop; index-based loop