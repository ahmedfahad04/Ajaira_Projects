len(string)

# Classification response:
# formatting only