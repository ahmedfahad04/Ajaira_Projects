result = [\'\'.join(segment) for segment in paren_string.split(\'()\', 1) if segment]

# Classification response:
# list comprehension