def solve(s, n):
    lis = [int(i) for i in s.split(' ') if i.isdigit()]
    return n - sum(lis)

# Classification response:
# list comprehension; naming; loop rewrite