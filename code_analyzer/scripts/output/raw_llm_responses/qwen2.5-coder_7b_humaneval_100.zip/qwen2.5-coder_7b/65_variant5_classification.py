s = str(x)
    return s[-shift:] + s[:-shift] if shift < len(s) else s[::-1]

# Classification response:
# variable renaming; conditional expression