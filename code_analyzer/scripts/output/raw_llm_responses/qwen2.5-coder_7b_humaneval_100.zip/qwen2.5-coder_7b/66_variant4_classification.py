def count_upper(s):
    return sum(1 for char in s if char.isupper() and char.isalpha())

# Classification response:
# function renaming; helper function extraction