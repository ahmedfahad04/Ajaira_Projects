def check_elements(l, t):
    return not any(e >= t for e in l)

# Classification response:
# list comprehension; helper function extraction