def convert_to_base(x, base):
    return "".join([str(x % base)] + [convert_to_base(x // base, base)] if x > 0 else [])

# Classification response:
# recursion; function renaming; control flow