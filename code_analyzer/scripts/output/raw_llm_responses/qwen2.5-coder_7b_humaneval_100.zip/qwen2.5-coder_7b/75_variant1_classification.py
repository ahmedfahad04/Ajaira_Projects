def is_prime(n):
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True

for i in range(2, 101):
    if not is_prime(i):
        continue
    for j in range(2, 101):
        if not is_prime(j):
            continue
        for k in range(2, 101):
            if not is_prime(k):
                continue
            if i * j * k == a:
                return True
return False

# Classification response:
# early return; optimization