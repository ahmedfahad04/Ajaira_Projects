a = abs(a)
cbrt = round(a ** (1. / 3))
return cbrt ** 3 == a

# Classification response:
# variable renaming; algorithmic