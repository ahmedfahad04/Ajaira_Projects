def gcd(a, b):
    return a if b == 0 else gcd(b, a % b)

# Classification response:
# function renaming; recursion