def parse_paren_group(s):
    depth = 0
    max_depth = 0
    stack = []

    for c in s:
        if c == '(':
            stack.append(c)
            max_depth = max(len(stack), max_depth)
        elif c == ')':
            stack.pop()

    return max_depth

return [parse_paren_group(x) for x in paren_string.split(' ') if x]

# Classification response:
# stack usage; data structure change