sum(1 for _ in string)

# Classification response:
# generator expression