return "".join([chr(((ord(ch) - 5 - ord("A")) % 26) + ord("A")) for ch in s])

# Classification response:
# string formatting change