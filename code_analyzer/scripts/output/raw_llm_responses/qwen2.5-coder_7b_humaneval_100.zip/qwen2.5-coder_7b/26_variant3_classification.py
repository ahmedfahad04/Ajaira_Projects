import collections as col
c = col.Counter(numbers)
return [n for n in numbers if c[n] <= 1]

# Classification response:
# import reorganization