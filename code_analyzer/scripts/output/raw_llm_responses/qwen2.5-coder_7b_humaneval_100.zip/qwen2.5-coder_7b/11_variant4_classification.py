def xor(i, j):
    return str(int(i) ^ int(j))

result = []
for x, y in zip(a, b):
    result.append(xor(x, y))
return ''.join(result)

# Classification response:
# variable renaming; string formatting change; loop rewrite; list conversion