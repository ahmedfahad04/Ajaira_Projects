return string[::-1].swapcase()

# Classification response:
# string formatting change; slicing