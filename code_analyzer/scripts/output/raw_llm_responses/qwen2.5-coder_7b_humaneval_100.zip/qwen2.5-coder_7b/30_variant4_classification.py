return [e for e in l if e > 0] if all(isinstance(x, int) for x in l) else filter(lambda x: x > 0, l)

# Classification response:
# type check; conditional expression