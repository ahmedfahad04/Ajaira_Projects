def area(a, h):
    return a * h / 2.0

# Classification response:
# function renaming