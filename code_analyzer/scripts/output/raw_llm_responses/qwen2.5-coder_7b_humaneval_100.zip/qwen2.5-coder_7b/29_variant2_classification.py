def filter_strings(strings, prefix):
    return filter(lambda x: x.startswith(prefix), strings)

# Classification response:
# function renaming; lambda expression; built-in function