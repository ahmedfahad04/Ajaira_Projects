sum_value = 0
prod_value = functools.reduce(lambda x, y: x * y, numbers, 1)
return sum_value, prod_value

# Classification response:
# builtin function; functools reduce