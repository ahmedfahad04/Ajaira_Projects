import math

def is_prime(p):
    if p < 2:
        return False
    for k in range(2, int(math.sqrt(p)) + 1):
        if p % k == 0:
            return False
    return True

f = [0, 1]
while True:
    f.append(f[-1] + f[-2])
    if is_prime(f[-1]):
        continue
    if f[-1] > n:
        return f[-2]

# Classification response:
# early return; loop rewrite; conditional expression