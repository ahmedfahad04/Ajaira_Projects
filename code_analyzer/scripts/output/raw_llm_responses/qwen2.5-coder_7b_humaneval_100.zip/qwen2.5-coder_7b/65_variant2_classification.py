s = str(x)
    return s[len(s) - shift:] + s[:len(s) - shift] if shift < len(s) else s[::-1]

# Classification response:
# early return