def solve(s, n):
    lis = list(map(int, [i for i in s.split(' ') if i.isdigit()]))
    return n - sum(lis)

# Classification response:
# list comprehension; map function; lambda expression