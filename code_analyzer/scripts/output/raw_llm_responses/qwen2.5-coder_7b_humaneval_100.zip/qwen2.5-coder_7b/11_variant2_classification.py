def xor(i, j):
    return '1' if i != j else '0'

return ''.join(xor(x, y) for x, y in zip(a, b))

# Classification response:
# variable renaming; conditional expression