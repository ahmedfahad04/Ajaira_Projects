def count_substring(string, substring):
    times = 0
    start = 0
    while True:
        start = string.find(substring, start)
        if start == -1: break
        times += 1
        start += 1
    return times

# Classification response:
# loop rewrite; helper function extraction