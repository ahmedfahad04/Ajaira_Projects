def check(s):
    if len(s) < 3:
        return False

    for i in range(len(s) - 2):
        if s[i] == s[i + 1] or s[i + 1] == s[i + 2]:
            return False
    return s[0] != s[-1]

# Classification response:
# variable renaming; loop rewrite