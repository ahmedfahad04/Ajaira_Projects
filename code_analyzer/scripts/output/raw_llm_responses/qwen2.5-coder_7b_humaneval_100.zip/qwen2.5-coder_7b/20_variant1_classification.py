closest_pair = None
distance = None

for i in range(len(numbers)):
    for j in range(i + 1, len(numbers)):
        diff = abs(numbers[i] - numbers[j])
        if distance is None or diff < distance:
            distance = diff
            closest_pair = tuple(sorted([numbers[i], numbers[j]]))

return closest_pair

# Classification response:
# index-based loop; nested conditional; loop rewrite