def count_mismatches(arr):
    return sum(1 for i in range(len(arr) // 2) if arr[i] != arr[-i-1])
return count_mismatches(arr)

# Classification response:
# function renaming; variable renaming; accumulator list; lambda expression