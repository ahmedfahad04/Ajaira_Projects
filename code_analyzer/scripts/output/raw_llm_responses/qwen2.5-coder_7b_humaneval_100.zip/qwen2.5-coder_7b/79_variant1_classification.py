def convert_to_binary(decimal):
    return "db" + format(decimal, "b") + "db"

# Classification response:
# function renaming; string formatting change