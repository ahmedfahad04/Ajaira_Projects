note_map = {'o': 4, 'o|': 2, '.|': 1}
music_list = music_string.split(' ')
filtered_list = [x for x in music_list if x]
return [note_map[x] for x in filtered_list]

# Classification response:
# list comprehension; temporary variable