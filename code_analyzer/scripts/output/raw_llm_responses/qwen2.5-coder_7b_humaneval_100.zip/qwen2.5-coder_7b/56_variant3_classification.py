def validate_brackets(brackets):
    balance = 0
    for b in brackets:
        if b == "[":
            balance += 1
        else:
            balance -= 1
        if balance < 0:
            return False
    return balance == 0

# Classification response:
# function renaming; parameter renaming; variable renaming; naming