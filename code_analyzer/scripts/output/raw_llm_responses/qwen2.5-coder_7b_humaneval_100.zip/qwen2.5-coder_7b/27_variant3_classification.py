return ''.join(char.swapcase() for char in string)

# Classification response:
# generator expression; list comprehension; string formatting change