def count_substring(string, substring):
    times = 0
    for i in range(len(string)):
        if string[i:].startswith(substring):
            times += 1
    return times

# Classification response:
# function renaming; string formatting change; loop rewrite