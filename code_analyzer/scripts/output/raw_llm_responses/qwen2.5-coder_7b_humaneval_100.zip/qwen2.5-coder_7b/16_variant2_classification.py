return len(set(string.lower().replace(' ', '')))

# Classification response:
# set conversion; string formatting change