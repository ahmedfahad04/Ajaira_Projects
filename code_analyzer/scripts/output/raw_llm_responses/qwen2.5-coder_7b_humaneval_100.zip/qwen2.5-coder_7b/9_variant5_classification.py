result = []

for n in numbers:
    if not result or n > result[-1]:
        result.append(n)
    else:
        result.append(result[-1])

return result

# Classification response:
# variable renaming; loop rewrite; conditional expression