from functools import reduce
ret = sorted(list(reduce(lambda a, b: a & b, (set(l) for l in (l1, l2)))))

# Classification response:
# set conversion; list conversion; lambda expression; reduce; sorting; in-place mutation; copy before mutation