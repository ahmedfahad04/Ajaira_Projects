def fibfib(n):
    if n < 3:
        return [0, 0, 1][n]
    return fibfib(n - 1) + fibfib(n - 2) + fibfib(n - 3)

# Classification response:
# function renaming; conditional expression; nested conditional