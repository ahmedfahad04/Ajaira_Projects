def filter_strings(strings, prefix):
    return list(filter(lambda s: s.startswith(prefix), strings))

# Classification response:
# function renaming; lambda expression