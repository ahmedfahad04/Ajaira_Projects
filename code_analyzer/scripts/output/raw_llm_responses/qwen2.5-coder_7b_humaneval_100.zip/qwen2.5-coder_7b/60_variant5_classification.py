def sum_range(n):
    if n == 0:
        return 0
    else:
        return n + sum_range(n - 1)

# Classification response:
# recursive function