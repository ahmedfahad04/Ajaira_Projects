for i in range(len(numbers)):
        for j in range(i + 1, len(numbers)):
            if abs(numbers[i] - numbers[j]) < threshold:
                return True

    return False

# Classification response:
# index-based loop; nested conditional; reversed condition