def count_substring(string, substring):
    times = 0
    i = 0
    while i < len(string):
        if string[i:i+len(substring)] == substring:
            times += 1
            i += len(substring)
        else:
            i += 1
    return times

# Classification response:
# function renaming; loop rewrite