def count_uppercase(s):
    return sum(1 for char in s if char.isupper())

# Classification response:
# function renaming; data structure; algorithmic