l = list(set(l)); l.sort(); return l

# Classification response:
# list conversion; in-place mutation; sort key