result = []
for x in values:
    if isinstance(x, int):
        result.append(x)
return result

# Classification response:
# list comprehension; to loop and append