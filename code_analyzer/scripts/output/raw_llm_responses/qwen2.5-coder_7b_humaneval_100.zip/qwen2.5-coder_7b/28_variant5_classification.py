def concatenate_strings(strings):
    return ''.join(filter(None, strings))

# Classification response:
# function renaming; filter usage