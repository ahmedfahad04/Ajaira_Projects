def filter_strings(strings, prefix):
    return list(filter(lambda x: x.startswith(prefix), strings))

# Classification response:
# function renaming; helper function extraction; lambda expression