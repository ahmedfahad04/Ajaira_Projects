def find_min_even(arr):
        if not arr:
            return []
        evens = [x for x in arr if x % 2 == 0]
        return [] if not evens else [min(evens), arr.index(min(evens))]

# Classification response:
# function renaming; list comprehension; conditional expression