return [x for x in values if type(x) is int]

# Classification response:
# type check