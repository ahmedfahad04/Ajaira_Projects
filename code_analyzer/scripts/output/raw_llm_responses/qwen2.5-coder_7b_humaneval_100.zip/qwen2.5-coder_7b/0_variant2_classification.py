distances = [abs(a - b) for a, b in combinations(numbers, 2)]
    return any(dist < threshold for dist in distances)

# Classification response:
# list comprehension; generator expression; conditional expression