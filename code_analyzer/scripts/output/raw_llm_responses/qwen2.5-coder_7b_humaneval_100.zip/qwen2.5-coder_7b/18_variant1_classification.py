def count_substring(string, substring):
    return string.count(substring)

# Classification response:
# builtin function