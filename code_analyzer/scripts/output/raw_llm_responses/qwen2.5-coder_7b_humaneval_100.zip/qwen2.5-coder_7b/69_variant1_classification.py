frq = Counter(lst)
ans = -1
for i in range(1, len(frq) + 1):
    if frq[i] >= i:
        ans = i
return ans

# Classification response:
# frequency counting; dictionary conversion