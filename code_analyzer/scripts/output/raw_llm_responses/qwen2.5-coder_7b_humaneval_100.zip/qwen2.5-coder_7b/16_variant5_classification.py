return len({char for char in string.lower() if char.isalnum()})

# Classification response:
# set comprehension; alphanumeric filter