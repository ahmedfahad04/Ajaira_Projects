return [e for e in l if e >= 0]

# Classification response:
# conditional expression