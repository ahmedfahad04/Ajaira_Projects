def intersect(l1, l2):
    return sorted(list(set(e for e1 in l1 for e2 in l2 if e1 == e2)))

# Classification response:
# set conversion; list comprehension; sort key