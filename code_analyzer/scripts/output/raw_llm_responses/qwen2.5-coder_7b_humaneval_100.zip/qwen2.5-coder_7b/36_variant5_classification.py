ns = [i for i in range(n) if (i % 11 == 0 or i % 13 == 0) and (i % 2 != 0)]
s = ''.join(map(str, ns))
ans = sum(c == '7' for c in s)

# Classification response:
# list comprehension; string formatting change; sum function