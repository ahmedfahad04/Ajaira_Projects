a = abs(a)
cbrt = a ** (1. / 3)
return int(round(cbrt)) ** 3 == a

# Classification response:
# variable renaming