def is_palindrome(text):
    n = len(text)
    return all(text[i] == text[n - 1 - i] for i in range(n // 2))

# Classification response:
# method renaming; algorithmic (two pointer)