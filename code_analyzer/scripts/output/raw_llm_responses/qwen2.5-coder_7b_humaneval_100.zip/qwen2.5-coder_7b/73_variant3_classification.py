def get_mismatch_count(arr):
    mismatch_count = 0
    for i in range(len(arr) // 2):
        if arr[i] != arr[-i-1]:
            mismatch_count += 1
    return mismatch_count
return get_mismatch_count(arr)

# Classification response:
# function renaming; variable renaming; control flow; formatting only