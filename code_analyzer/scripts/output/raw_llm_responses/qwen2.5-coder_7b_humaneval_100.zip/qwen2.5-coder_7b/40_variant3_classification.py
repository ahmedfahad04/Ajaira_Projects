def has_zero_sum_triplet(l):
    s = set(l)
    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            target = -(l[i] + l[j])
            if target in s:
                return True
    return False

# Classification response:
# set conversion; nested conditional