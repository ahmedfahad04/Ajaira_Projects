ans = 0
for i in range(len(arr) // 2):
    if arr[i] != arr[-(i+1)]:
        ans += 1
return ans

# Classification response:
# index-based loop; string formatting change