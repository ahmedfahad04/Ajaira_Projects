lengths = lambda l: [len(st) for st in l]
if sum(lengths(lst1)) <= sum(lengths(lst2)):
    return lst1
else:
    return lst2

# Classification response:
# list comprehension; lambda expression; conditional expression