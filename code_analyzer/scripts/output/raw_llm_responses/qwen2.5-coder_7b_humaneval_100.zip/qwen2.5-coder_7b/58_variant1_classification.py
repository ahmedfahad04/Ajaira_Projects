ret = [e for e1 in l1 for e2 in l2 if e1 == e2]
return sorted(set(ret))

# Classification response:
# list comprehension; set conversion; sort key