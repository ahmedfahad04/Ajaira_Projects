result = [segment for segment in paren_string.split(\'(\') if segment and segment[0] == \')\']

# Classification response:
# list comprehension; tuple unpacking