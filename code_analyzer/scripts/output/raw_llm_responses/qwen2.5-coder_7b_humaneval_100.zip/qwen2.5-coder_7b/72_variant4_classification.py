def is_symmetric(q, w):
    if sum(q) > w:
        return False
    mid = len(q) // 2
    return q[:mid] == q[:mid-1:-1]

# Classification response:
# function renaming; method renaming