primes = set('2357BD')
total = sum(1 for char in num if char in primes)
return total

# Classification response:
# set conversion; generator expression; list comprehension