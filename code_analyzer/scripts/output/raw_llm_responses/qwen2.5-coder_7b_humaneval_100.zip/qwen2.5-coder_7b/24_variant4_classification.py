def get_smallest_divisor(n):
    return next(i for i in range(n, 0, -1) if n % i == 0)

# Classification response:
# function renaming; generator expression