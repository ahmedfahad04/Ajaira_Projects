closest_pair = None
min_diff = float('inf')

for num1 in numbers:
    for num2 in numbers:
        if num1 != num2:
            diff = abs(num1 - num2)
            if diff < min_diff:
                min_diff = diff
                closest_pair = tuple(sorted([num1, num2]))

return closest_pair

# Classification response:
# variable renaming; parameter renaming; literal rewrite; formatting only