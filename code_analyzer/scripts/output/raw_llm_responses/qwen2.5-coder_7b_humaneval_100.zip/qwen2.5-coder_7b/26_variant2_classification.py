from collections import Counter
c = Counter(numbers)
return [n for n in numbers if c[n] <= 1]

# Classification response:
# import reorganization