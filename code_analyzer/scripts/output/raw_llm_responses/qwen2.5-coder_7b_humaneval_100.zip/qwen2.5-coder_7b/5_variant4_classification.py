def intersperse(numbers, delimiter):
    result = []
    for i, n in enumerate(numbers):
        if i > 0:
            result.append(delimiter)
        result.append(n)
    return result

# Classification response:
# function renaming; loop rewrite; index-based loop