ns = list(filter(lambda i: i % 11 == 0 or i % 13 == 0, range(n)))
s = ''.join(map(str, ns))
ans = sum(c == '7' for c in s)

# Classification response:
# lambda expression; map/filter usage; generator expression; sum function