def is_power_of_n(n, x):
    if n == 1:
        return x == 1
    power = n
    while power <= x:
        power *= n
    return power == x and power != x

# Classification response:
# function renaming; variable renaming; control flow; algorithmic