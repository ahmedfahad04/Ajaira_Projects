def convert_to_base(x, base):
    result = ""
    while x > 0:
        result = str(x % base) + result
        x //= base
    return result[::-1]

# Classification response:
# function renaming; string formatting change