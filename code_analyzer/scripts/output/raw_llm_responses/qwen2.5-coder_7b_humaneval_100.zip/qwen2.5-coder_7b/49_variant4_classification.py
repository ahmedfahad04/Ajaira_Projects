ret = 1
for i in range(n):
    ret = (ret << 1) % p
    if ret == 0:
        ret = 1
return ret

# Classification response:
# bitwise left shift; conditional reset