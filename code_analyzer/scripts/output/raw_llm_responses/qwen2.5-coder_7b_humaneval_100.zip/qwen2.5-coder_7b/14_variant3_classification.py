result = []
for i in range(len(string)):
    result.extend([string[:i+1]])
return result

# Classification response:
# loop rewrite