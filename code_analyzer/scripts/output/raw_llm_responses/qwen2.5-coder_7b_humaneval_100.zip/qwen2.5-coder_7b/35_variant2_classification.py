m = max(l)
return m

# Classification response:
# builtin function