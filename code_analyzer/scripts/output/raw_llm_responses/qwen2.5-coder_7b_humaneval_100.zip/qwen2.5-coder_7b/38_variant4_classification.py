def encode_loop(s):
    return encode_cyclic(encode_cyclic(s))

# Classification response:
# function renaming