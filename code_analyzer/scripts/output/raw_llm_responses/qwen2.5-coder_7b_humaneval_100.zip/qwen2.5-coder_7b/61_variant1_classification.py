def is_balanced(brackets):
    balance = 0
    for char in brackets:
        if char == '(':
            balance += 1
        else:
            balance -= 1
        if balance < 0:
            return False
    return balance == 0

# Classification response:
# function renaming; parameter renaming; variable renaming; control flow