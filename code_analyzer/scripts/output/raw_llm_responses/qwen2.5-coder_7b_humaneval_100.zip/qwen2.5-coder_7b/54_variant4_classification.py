def are_sets_equal(s0, s1):
    return frozenset(s0) == frozenset(s1)

# Classification response:
# function renaming; set conversion