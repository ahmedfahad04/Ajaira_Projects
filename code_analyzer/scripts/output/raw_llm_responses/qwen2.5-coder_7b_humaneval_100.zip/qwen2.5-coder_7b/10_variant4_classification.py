def reverse_and_append(string):
    if not string:
        return ''

    for i in range(len(string)):
        if is_palindrome(string[i:]):
            return string + string[:i][::-1]

    return string

# Classification response:
# for loop; helper function extraction