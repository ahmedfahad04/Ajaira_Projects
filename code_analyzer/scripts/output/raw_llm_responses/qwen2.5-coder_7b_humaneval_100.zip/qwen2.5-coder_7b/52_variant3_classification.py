def check_elements(l, t):
    for e in l:
        if e >= t:
            return False
    return True

# Classification response:
# function renaming