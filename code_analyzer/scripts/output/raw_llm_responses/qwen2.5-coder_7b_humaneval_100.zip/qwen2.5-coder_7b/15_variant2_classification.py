result = ''
for i in range(n + 1):
    result += str(i) + ' '
return result.strip()

# Classification response:
# list comprehension; for loop; string concatenation; slicing; in-place mutation