closest_pair = None
min_diff = float('inf')

for num1, num2 in combinations(numbers, 2):
    diff = abs(num1 - num2)
    if diff < min_diff:
        min_diff = diff
        closest_pair = tuple(sorted([num1, num2]))

return closest_pair

# Classification response:
# itertools usage; lambda expression; tuple unpacking; dictionary lookup