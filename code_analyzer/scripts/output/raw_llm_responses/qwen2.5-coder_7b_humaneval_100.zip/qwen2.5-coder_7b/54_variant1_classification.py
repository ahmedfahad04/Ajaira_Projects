def are_sets_equal(s0, s1):
    return s0 == s1

# Classification response:
# function renaming; data structure; set conversion