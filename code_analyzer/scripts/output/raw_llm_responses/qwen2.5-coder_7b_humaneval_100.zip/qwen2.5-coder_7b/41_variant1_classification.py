def calculate_square(n):
    result = 0
    for i in range(n):
        result += n
    return result

# Classification response:
# variable renaming; loop rewrite; in-place mutation