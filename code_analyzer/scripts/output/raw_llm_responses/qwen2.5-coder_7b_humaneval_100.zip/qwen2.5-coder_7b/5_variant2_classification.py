def intersperse(numbers, delimiter):
    if not numbers:
        return []
    return sum(zip(numbers, [delimiter] * len(numbers)), ())

# Classification response:
# variable renaming; function renaming; data structure; built-in function