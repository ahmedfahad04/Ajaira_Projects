def xor(i, j):
    return '0' if i == j else '1'

return ''.join(xor(x, y) for x, y in zip(a, b))

# Classification response:
# variable renaming; conditional expression