letter_grade = [next((k for k, v in grade_scale if gpa >= v), "E") for gpa in grades]
grade_scale = [
    (4.0, "A+"),
    (3.8, "A"),
    (3.4, "A-"),
    (3.1, "B+"),
    (2.8, "B"),
    (2.4, "B-"),
    (2.1, "C+"),
    (1.8, "C"),
    (1.4, "C-"),
    (1.1, "D+"),
    (0.8, "D"),
    (0.0, "D-")
]

# Classification response:
# list comprehension; tuple unpacking