def convert_to_base(x, base):
    return "".join(str(x % base) + convert_to_base(x // base, base) for _ in range(x > 0))

# Classification response:
# recursion; helper function extraction