def solve(s, n):
    lis = list(filter(lambda x: x.isdigit(), s.split(' ')))
    lis = list(map(int, lis))
    return n - sum(lis)

# Classification response:
# builtin function; lambda expression; map/filter usage; list comprehension