result = list(map(lambda i: string[:i+1], range(len(string))))
return result

# Classification response:
# builtin function; lambda expression