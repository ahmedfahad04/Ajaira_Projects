def convert_to_base(x, base):
    if x == 0:
        return ""
    else:
        return str(x % base) + convert_to_base(x // base, base)

# Classification response:
# recursion