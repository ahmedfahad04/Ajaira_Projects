def is_power_of_n(n, x):
    if n == 1:
        return x == 1
    return x in {n**i for i in range(1, int(x**0.5) + 1)}

# Classification response:
# set conversion; generator expression; in-place mutation