closest_pair = None
min_diff = float('inf')

for i in range(len(numbers) - 1):
    diff = abs(numbers[i] - numbers[i + 1])
    if diff < min_diff:
        min_diff = diff
        closest_pair = tuple(sorted([numbers[i], numbers[i + 1]]))

return closest_pair

# Classification response:
# index-based loop;sliding window