vowels = "aeiouAEIOU"
n_vowels = sum(c.lower() in vowels for c in s)
if s[-1] == 'y':
    n_vowels += 1
return n_vowels

# Classification response:
# string formatting change; conditional expression