s = str(x)
    if shift >= len(s):
        return s[::-1]
    else:
        return s[-shift:] + s[:-shift]

# Classification response:
# variable renaming; conditional expression